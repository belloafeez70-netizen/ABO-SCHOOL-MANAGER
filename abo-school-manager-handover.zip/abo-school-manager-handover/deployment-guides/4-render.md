# 4 · Render — the server between the website and the database

## Why this step is needed

Supabase only stores the data and Netlify only shows the pages. The server that does the checking needs somewhere to run, and `render.supabase.yaml` sets it up on Render. The server:

- checks passwords, sessions and permissions;
- runs 5-minute demos and puts the demo schools back afterwards;
- checks every payment with Paystack;
- sends emails.

## Steps

1. Go to **Render › New › Blueprint**. Connect GitHub, choose `abo-school-manager`, and pick `render.supabase.yaml`.
2. Fill in the secret settings it asks for:

| Setting | Value |
|---|---|
| `DATABASE_URL`, `MIGRATION_DATABASE_URL` | The two lines printed by `supabase-db-setup.sh` (package 2) |
| `PUBLIC_ORIGIN` | Your Netlify address, e.g. `https://abosch.netlify.app` |
| `PROXY_SHARED_SECRET` | A long random value. Put the **same** value in Netlify. |
| `CSRF_SECRET`, `DATA_ENCRYPTION_KEY`, `FILE_URL_SECRET` | Long random values, each different. **Never change `DATA_ENCRYPTION_KEY` later**, because the stored payment key and two-factor secrets are locked with it. |
| `S3_*` settings | The Supabase Storage key, bucket `abo-files` |
| `SMTP_URL`, `MAIL_FROM` | Your email provider, needed for password reset, email verification and emailing parents. For example `smtps://user:pass@smtp.provider.com:465` |
| `PAYSTACK_SECRET_KEY` | Optional: school fees paid online |
| `PLATFORM_PAYSTACK_SECRET_KEY` | Optional: your A.B.O. subscription payments. You can type it later in **Payments & Plans** instead, where it is stored encrypted. |

3. Click **Apply**. When it says **Live**, open `https://<render-address>/api/v1/public/status`. It should answer `{"ok":true,"service":"abo-api"}`.
4. Create your platform-owner login with the command shown in `docs/NETLIFY_DEPLOYMENT.md`. Turn on two-factor sign-in.
5. In Paystack, go to **Settings › API Keys & Webhooks**. Set the webhook URL to the one shown in **Payments & Plans** (`…/api/v1/billing/webhook/paystack`).
6. From a computer, check everything: `npm run preflight`, then `npm run verify:deploy`.
