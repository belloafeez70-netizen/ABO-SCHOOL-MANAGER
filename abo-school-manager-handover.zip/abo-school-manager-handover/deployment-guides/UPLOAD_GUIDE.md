# Where each file goes — A.B.O. School Manager

**Updated:** 12 October 2026

## Everything is online now (12 Oct 2026)

There is **one product: the online app**. It has every feature the offline edition had, including Old Debts, Petty Cash, Questions from Teachers, Automatic Reminders, Devices, the Print Centre and the Score Sheet Layout (see `abo-erp/docs/FEATURE_MAP.md`).

- The offline edition is no longer published.
- Schools move their old data in with one click: **Backup & Data › From the Old App** finds it on the same device.
- The online app needs four services (below). Until they are set up, abosch.netlify.app keeps showing the current site.

## The online app needs four services

The online (secure, multi-school) app is made of three parts that talk to each other, plus GitHub, which keeps the code:

```
 Parents / staff / owner  ──►  NETLIFY (the website pages)  ──►  RENDER (the server that checks every request)  ──►  SUPABASE (the database)
                                         ▲                                  ▲
                                         └──────────  GITHUB (your code; Netlify and Render read it from here)  ──┘
```

| Package | Upload to | What is inside |
|---|---|---|
| `upload-1-github.zip` | **GitHub** (a *private* repository) | The whole project (`abo-erp/`): server, website, database migrations, tests and documents. It has no passwords and no secret keys. |
| `upload-2-supabase.zip` | **Supabase** | Database set-up for the online app (`server-database/`). `offline-cloud-sync/` is only for schools still using the old offline app during the move. |
| `upload-3-netlify.zip` | **Netlify** | The online app: connect your GitHub repository to the abosch site; nothing to drag. Includes how schools bring their old offline data in. |
| `upload-4-render.zip` | **Render** | The server blueprint (`render.supabase.yaml`) and the list of secret settings. Supabase only stores data and Netlify only shows pages; the server in between must run somewhere — Render is the one prepared. |

## Order

1. GitHub
2. Supabase
3. Render
4. Netlify
5. Link Netlify and Render together

The README inside each package has the exact steps.

## Never upload or paste these anywhere public

- Supabase `sb_secret_…` key and database passwords.
- Paystack `sk_live_…` secret key.
- `DATA_ENCRYPTION_KEY`, `CSRF_SECRET`, `PROXY_SHARED_SECRET`.

These go **only** into Render's or Netlify's "Environment variables" screens. The Paystack secret can also go into **Payments & Plans** in the online app, which stores it encrypted.
