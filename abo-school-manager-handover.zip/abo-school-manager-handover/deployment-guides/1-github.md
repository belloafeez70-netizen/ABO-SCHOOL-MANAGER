# 1 · GitHub — your code

## What to upload

The whole folder `abo-erp/`, as it is.

**Already left out:**
- the local test helpers (`legacy/qa`) and screenshots — they are in `abo-erp-server.zip`
- installed packages (`node_modules`)
- build output (`dist`)
- local data (`var`)
- any `.env` file with real secrets

**Must stay in the folder:** `.gitignore` and `.env.example`.

## Steps

1. Go to https://github.com/new.
2. Name the repository `abo-school-manager` and choose **Private**. Click **Create repository**.
3. Choose one way to upload (the project has about 320 files):
   - **Easiest: GitHub Desktop** (https://desktop.github.com). Click **File › Add local repository**, choose the `abo-erp` folder, then **Publish repository**, keeping **Private** ticked.
   - **With Git on a computer:**
     ```
     cd abo-erp
     git init
     git add .
     git commit -m "A.B.O. School Manager"
     git branch -M main
     git remote add origin https://github.com/<you>/abo-school-manager.git
     git push -u origin main
     ```
   - **Browser only:** GitHub's "uploading an existing file" accepts at most 100 files per upload. Upload the folders a few at a time: first `server/`, then `web/`, then everything else.
4. Check on GitHub that `package.json` is at the **top level** of the repository, not inside an extra folder.

## Important

- Keep the repository **private**.
- Never add a file containing real passwords or keys. `.gitignore` already blocks `.env`.
