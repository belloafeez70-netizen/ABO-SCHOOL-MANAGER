# 2 · Supabase — the database

**Project:** `fehpqiqqxgqugioowepu` (eu-west-1). You can also make a new one.

## A. The online app's database (`server-database/`)

**Recommended way:** run `supabase-db-setup.sh` once from any computer with Node.js 20, from inside the project downloaded from GitHub. The script does all of this:

1. Creates two database roles:
   - one that owns the tables;
   - one the app uses, which can never bypass Row Level Security.
2. Creates a separate database, `abo_erp`. Supabase's public API cannot reach it.
3. Runs all 26 migrations. These set up the tables, the security rules (RLS on every school table) and the permission list.
4. Checks that one school cannot see another school's data (12 checks).
5. Creates the two **DEMO** schools. They contain fictional data and no passwords.
6. Prints the two connection strings to paste into Render.

**Steps:**

1. In Supabase, go to **Project Settings › Database › Reset database password**. Set a temporary password.
2. Go to **Connect › Session pooler**. Copy the connection string (port **5432**).
3. On the computer, inside the project, run:
   ```
   npm ci
   SUPABASE_ADMIN_URL='postgres://postgres.<ref>:<temporary-password>@aws-0-eu-west-1.pooler.supabase.com:5432/postgres' bash scripts/supabase-db-setup.sh
   ```
4. Copy the two lines it prints (`MIGRATION_DATABASE_URL`, `DATABASE_URL`) into Render (see package 4).
5. In Supabase, **reset the database password again**, so the temporary one is no longer valid.

`abo_server_schema_reference.sql` holds the same migrations in one file, so they can be reviewed. Pasting it into the SQL Editor is **not** the recommended path, because the script also creates the roles, syncs the permission list and runs the isolation check.

## B. Files (photos, logos, documents)

1. Go to **Storage › New bucket**.
2. Name it `abo-files` and leave it **private** (do not tick "Public").
3. Go to **Project Settings › Storage › S3 access keys** and create a key. Put the key in Render (see package 4).

## C. Old offline edition Cloud Sync (`offline-cloud-sync/`) — only while schools are still moving to the online app

The online app does **not** need this: its server is the online copy. Run it only if schools still use the old offline edition's Cloud Sync until they have moved their data in (Backup & Data › From the Old App). It closes the gaps found in the security check.

1. Go to **SQL Editor › New query**.
2. Paste all of `abo_supabase_setup.sql` and click **Run**. It is safe to run again. Existing schools and their data stay.
3. The offline file only needs the **publishable** key (`sb_publishable_…`). Never type the `sb_secret_…` key into it.

**What the update adds** (tested on a local copy of the same database setup: 35/35 checks):
- Each internet address can create **at most 5 new schools per day**. This stops strangers filling your database. (If Supabase ever sent no address, those requests share a limit of 100 per day, so sign-ups never stop completely.)
- Wrong school secrets are rate-limited: after 20 tries from one address, that address is blocked for 15 minutes.
- Size limits: one school record at most 30 MB; files at most 20 MB and 40 parts.
- All tables keep Row Level Security switched on, with no direct access for the public key. Everything goes through checked functions.
- New: **Change school secret** cuts off old link codes and devices at once.
- Phones still running the old offline file keep working.

**Optional: only invited schools may create a Cloud Sync school.** Choose a code (example below: `MySchoolsInvite2026`). Run this once in the SQL Editor:

```sql
insert into public.abo_config(key, value)
values ('new_school_code_hash', extensions.crypt('MySchoolsInvite2026', extensions.gen_salt('bf', 10)))
on conflict (key) do update set value = excluded.value;
```

Give the code only to schools you approve. They type it in **Cloud Sync › Invitation code** when they connect the first time. Schools that already exist are not affected.

To switch invitations off again, run:

```sql
delete from public.abo_config where key = 'new_school_code_hash';
```

**Honest limit:** the offline edition uses **one shared secret per school**, not a separate login for each person on the server. Anyone with the school ID and secret can read and change that school's cloud copy. Keep the secret private. If a staff member leaves, use **Cloud Sync › Danger zone › Change school secret**, then link your own devices again. Per-person server logins exist in the online edition.

## Backups

- On a paid Supabase plan, turn on **Point-in-Time Recovery**.
- In any case, the app's **Backup & Data** page lets an owner download a full copy of their school.
