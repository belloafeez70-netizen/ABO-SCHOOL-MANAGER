# 3 · Netlify — the website (abosch.netlify.app)

Since 12 October 2026 **everything is online**: one online app, with every feature the offline edition had. The offline edition is no longer published.

> **Netlify alone cannot run the online app.** It needs the server (Render, package 4) and the database (Supabase, package 2). Do those first, then this page.
> Until then, abosch.netlify.app keeps showing what is there now (the old offline edition).

## Put the online app on abosch.netlify.app

You do not drag files for this. Netlify builds the site from your GitHub repository, using `netlify.toml`.

1. Open your existing site **abosch** on app.netlify.com.
2. Go to **Site configuration › Build & deploy › Link repository** and choose `abo-school-manager` (from package 1). The address stays **https://abosch.netlify.app**.
3. Build settings are read from `netlify.toml`:
   - build command `npm run build:web`
   - publish directory `dist/web`
   - edge functions in `netlify/edge-functions`
4. Go to **Site configuration › Environment variables** and add (scope: **Functions**):
   - `API_ORIGIN` = your Render address, e.g. `https://abo-api.onrender.com`
   - `PROXY_SHARED_SECRET` = the same long random value you put in Render
5. Click **Deploy**. Open https://abosch.netlify.app. You should see the sign-in page (there is no public demo button).

## Giving a demo (only you, the platform owner)

1. Sign in with your **platform** account. Go to **Demo Links › Make a demo link**.
2. Choose who it is for, the demo school (or let them choose), how long the link works (1 hour to 7 days) and how many demos it can open.
3. Press **Copy link** or **Send by WhatsApp**. Open it on your phone, in another browser or in a private window (opening it in the same browser signs you out of the console), or send it to the school.
4. Each demo lasts 5 minutes and is wiped afterwards. Cancel a link at any time on the same page.

Without a valid link the demo page only says "Demo by invitation" with your phone number.

## Bring each school's offline data in (one click)

Schools that used the offline edition on abosch.netlify.app still have their data in their own browser. After the switch:

1. On the same computer or phone, open **https://abosch.netlify.app** and sign in as the school owner.
2. Go to **Backup & Data › From the Old App**. The page shows **"Found on this device"** with the school's name, classes and learners.
3. Press **Preview moving this school**, check the numbers, then press **Commit migration**.

Nothing is changed before **Commit**. Repeat on each device that holds a different school or class.

If the data is on another device, use the old app's **Full backup** file on the same page instead.

## Phones that installed the old app

Their icon now opens the online app. Data entered online is safe on the server and the same on every device. Pages already opened can still be read without internet; saving needs the internet.

## If something looks wrong

Go to **Deploys**, click the previous deploy, then **Publish deploy**. The old version is back in seconds.

`online-edition/` in this package holds a copy of `netlify.toml` and the edge proxy, only for reference. They are already inside the GitHub repository.
