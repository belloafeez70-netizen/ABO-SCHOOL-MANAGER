#!/usr/bin/env bash
# Restore drill: restores a backup into a SCRATCH database, then verifies row counts and every school's
# audit hash chain. Run weekly (cron/CI) and after any backup-config change. Never point at production.
#   RESTORE_ADMIN_URL  superuser/admin connection to the server that will host the scratch DB
#   BACKUP_FILE        path to abo-*.dump or abo-*.dump.enc (needs BACKUP_ENCRYPTION_KEY)
set -euo pipefail
: "${RESTORE_ADMIN_URL:?}"; : "${BACKUP_FILE:?}"
PSQL=${PSQL:-psql}; PGRESTORE=${PG_RESTORE:-pg_restore}
SCRATCH=abo_restore_drill_$(date +%s)
FILE="$BACKUP_FILE"
if [ -f "$FILE.sha256" ]; then (cd "$(dirname "$FILE")" && sha256sum -c "$(basename "$FILE").sha256" >/dev/null) && echo "checksum ok"; fi
if [[ "$FILE" == *.enc ]]; then openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000 -in "$FILE" -out "/tmp/$SCRATCH.dump" -pass env:BACKUP_ENCRYPTION_KEY; FILE="/tmp/$SCRATCH.dump"; fi
"$PSQL" "$RESTORE_ADMIN_URL" -qc "CREATE DATABASE $SCRATCH"
trap '"$PSQL" "$RESTORE_ADMIN_URL" -qc "DROP DATABASE IF EXISTS $SCRATCH WITH (FORCE)" >/dev/null; rm -f /tmp/$SCRATCH.dump' EXIT
DB_URL="${RESTORE_ADMIN_URL%/*}/$SCRATCH"
"$PGRESTORE" --no-owner --no-privileges --exit-on-error --dbname="$DB_URL" "$FILE" 2>&1 | grep -v 'already exists' || true
echo "restored into $SCRATCH"
"$PSQL" "$DB_URL" -At -c "SELECT 'schools=' || count(*) FROM schools" -c "SELECT 'students=' || count(*) FROM students" -c "SELECT 'audit_rows=' || count(*) FROM audit_logs" -c "SELECT 'migrations=' || count(*) FROM schema_migrations"
BAD=$("$PSQL" "$DB_URL" -At -c "SELECT set_config('app.platform','on',false)" -c "SELECT count(*) FROM (SELECT DISTINCT school_id FROM audit_logs) s, LATERAL app.audit_verify(s.school_id) v WHERE NOT v.ok" | tail -1)
if [ "$BAD" != "0" ]; then echo "RESTORE DRILL FAILED: $BAD audit chain(s) broken"; exit 1; fi
echo "restore drill ok: all audit chains verified"
