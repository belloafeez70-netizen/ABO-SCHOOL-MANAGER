#!/usr/bin/env bash
# Logical backup of the A.B.O. database (complements — does not replace — managed PITR/WAL archiving).
#   BACKUP_DATABASE_URL   connection string of a role that can read everything (the owner role or a dedicated backup role)
#   BACKUP_DIR            local staging dir (default ./backups)
#   BACKUP_ENCRYPTION_KEY if set, the dump is encrypted with AES-256 (openssl, PBKDF2) before leaving the host
#   BACKUP_S3_URI         if set (e.g. s3://abo-backups/prod), uploads with the AWS CLI to SEPARATE storage
#   BACKUP_RETENTION_DAYS local retention (default 14). Configure bucket lifecycle rules for off-site retention.
set -euo pipefail
: "${BACKUP_DATABASE_URL:?BACKUP_DATABASE_URL is required}"
DIR=${BACKUP_DIR:-./backups}; KEEP=${BACKUP_RETENTION_DAYS:-14}; PGDUMP=${PG_DUMP:-pg_dump}
mkdir -p "$DIR"; chmod 700 "$DIR"
TS=$(date -u +%Y%m%dT%H%M%SZ); OUT="$DIR/abo-$TS.dump"
"$PGDUMP" --format=custom --compress=9 --no-owner --no-privileges --file="$OUT" "$BACKUP_DATABASE_URL"
sha256sum "$OUT" > "$OUT.sha256"
if [ -n "${BACKUP_ENCRYPTION_KEY:-}" ]; then
  openssl enc -aes-256-cbc -pbkdf2 -iter 200000 -salt -in "$OUT" -out "$OUT.enc" -pass env:BACKUP_ENCRYPTION_KEY
  rm -f "$OUT"; OUT="$OUT.enc"; sha256sum "$OUT" > "$OUT.sha256"
fi
if [ -n "${BACKUP_S3_URI:-}" ]; then
  [ -n "${BACKUP_ENCRYPTION_KEY:-}" ] || { echo "refusing to upload an UNENCRYPTED backup off-site: set BACKUP_ENCRYPTION_KEY"; exit 1; }
  EP=(); [ -n "${AWS_ENDPOINT_URL_S3:-}" ] && EP=(--endpoint-url "$AWS_ENDPOINT_URL_S3")   # Cloudflare R2 / B2 / Wasabi
  aws "${EP[@]}" s3 cp "$OUT" "$BACKUP_S3_URI/" --only-show-errors
  aws "${EP[@]}" s3 cp "$OUT.sha256" "$BACKUP_S3_URI/" --only-show-errors
  rm -f "$OUT" "$OUT.sha256"                          # the container is ephemeral; the copy lives off-site
  echo "backup uploaded: $BACKUP_S3_URI/$(basename "$OUT")"
  # optional heartbeat so a MISSED backup raises an alert (e.g. Better Stack / Healthchecks.io / Cronitor URL)
  [ -n "${BACKUP_HEARTBEAT_URL:-}" ] && curl -fsS -m 10 "$BACKUP_HEARTBEAT_URL" >/dev/null || true
  exit 0
fi
find "$DIR" -name 'abo-*.dump*' -mtime +"$KEEP" -delete
echo "backup ok: $OUT ($(du -h "$OUT" | cut -f1))"
