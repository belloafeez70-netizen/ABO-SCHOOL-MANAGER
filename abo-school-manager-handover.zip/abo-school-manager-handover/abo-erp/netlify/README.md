# Netlify edge function

`edge-functions/api-proxy.js` forwards `https://<site>.netlify.app/api/*` to the backend (`API_ORIGIN`) and adds the
shared secret + the visitor's real IP. It keeps the session cookie first-party (netlify.app is a public suffix), so
sign-in works in every browser without third-party cookies or CORS.

Netlify environment variables (Site configuration → Environment variables, **scope must include Functions**):

| Variable | Example | Notes |
|---|---|---|
| `API_ORIGIN` | `https://abo-api.onrender.com` | https only, no trailing slash |
| `PROXY_SHARED_SECRET` | 64 random characters | identical to the API's value; never put it in code |
| `PREVIEW_API_ENABLED` | `true` | only in deploy-preview/branch contexts whose `API_ORIGIN` is a **staging** API |

Test locally without deploying: `npm run build:web` then `API_ORIGIN=http://127.0.0.1:8080 PROXY_SHARED_SECRET=… npm run netlify:local`.
