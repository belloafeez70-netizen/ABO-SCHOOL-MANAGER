// Netlify Edge Function: same-origin proxy from https://<site>.netlify.app/api/* to the separate backend API.
//
// Why a proxy instead of calling the API host from the browser:
//   • netlify.app is on the Public Suffix List, so a cookie set by another host would be a THIRD-PARTY cookie
//     (blocked by Safari/Firefox/Chrome privacy rules). Through this proxy the session cookie is first-party,
//     HttpOnly, Secure, SameSite=Strict — exactly as in the single-host setup — and there is no CORS preflight.
//   • The backend address and the shared secret live in Netlify ENVIRONMENT VARIABLES (scope: Functions), never in
//     the frontend bundle. Changing to a custom domain later needs no code change.
//
// Environment variables (Netlify → Site configuration → Environment variables, scope must include "Functions"):
//   API_ORIGIN            https://abo-api.onrender.com          (backend origin, https only)
//   PROXY_SHARED_SECRET   same value as on the API                (32+ random bytes; e.g. openssl rand -base64 48)
//   PREVIEW_API_ENABLED   "true" only in deploy-preview/branch contexts that point API_ORIGIN at a STAGING API
const STRIP = new Set(['connection', 'keep-alive', 'proxy-connection', 'transfer-encoding', 'te', 'trailer', 'upgrade', 'host',
  'content-length', 'x-abo-proxy-secret', 'x-abo-client-ip', 'x-forwarded-for', 'x-forwarded-host', 'x-forwarded-proto',
  'x-real-ip', 'forwarded', 'x-nf-client-connection-ip']);
const TIMEOUT_MS = 35000;          // Netlify allows 40 s until response headers

const fail = (status, code, message, requestId) => new Response(JSON.stringify({ error: { code, message, requestId: requestId || null } }),
  { status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' } });
const env = (k) => { try { return globalThis.Netlify ? globalThis.Netlify.env.get(k) : undefined; } catch { return undefined; } };

export default async (request, context) => {
  const rid = context && context.requestId;
  const deployContext = context && context.deploy && context.deploy.context;
  if (deployContext && deployContext !== 'production' && deployContext !== 'dev' && env('PREVIEW_API_ENABLED') !== 'true') {
    return fail(503, 'PREVIEW_NOT_CONNECTED', 'This preview is not connected to a server. Use the live site.', rid);
  }
  const apiOrigin = env('API_ORIGIN'); const secret = env('PROXY_SHARED_SECRET');
  let base = null; try { base = apiOrigin ? new URL(apiOrigin) : null; } catch { base = null; }
  const local = base && /^(localhost|127\.0\.0\.1)$/.test(base.hostname);
  if (!base || !secret || (base.protocol !== 'https:' && !local)) {
    return fail(503, 'PROXY_NOT_CONFIGURED', 'The school portal is being set up. Please try again shortly.', rid);
  }
  const url = new URL(request.url);
  const target = new URL(url.pathname + url.search, base.origin);

  const headers = new Headers();
  for (const [k, v] of request.headers) if (!STRIP.has(k.toLowerCase())) headers.append(k, v);
  headers.set('x-abo-proxy-secret', secret);
  if (context && context.ip) headers.set('x-abo-client-ip', context.ip);
  headers.set('x-forwarded-proto', 'https');
  headers.set('x-forwarded-host', url.host);
  headers.set('accept-encoding', 'identity');          // Netlify compresses for the browser; avoid double-decoding

  const hasBody = !['GET', 'HEAD'].includes(request.method);
  let res;
  try {
    res = await fetch(target, { method: request.method, headers, body: hasBody ? request.body : undefined, redirect: 'manual',
      signal: AbortSignal.timeout(TIMEOUT_MS), ...(hasBody ? { duplex: 'half' } : {}) });
  } catch (e) {
    const timeout = e && (e.name === 'TimeoutError' || e.name === 'AbortError');
    return fail(timeout ? 504 : 502, 'UPSTREAM_UNAVAILABLE', 'The school server is not responding. Please try again in a moment.', rid);
  }
  const out = new Headers();
  for (const [k, v] of res.headers) if (!['connection', 'keep-alive', 'transfer-encoding'].includes(k)) out.append(k, v);
  // fetch() already decoded a compressed body — drop the stale encoding/length headers
  if (out.has('content-encoding')) { out.delete('content-encoding'); out.delete('content-length'); }
  return new Response(res.body, { status: res.status, statusText: res.statusText, headers: out });
};

export const config = { path: '/api/*' };
