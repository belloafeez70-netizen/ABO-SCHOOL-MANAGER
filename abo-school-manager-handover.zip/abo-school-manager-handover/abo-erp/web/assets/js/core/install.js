// "Install app" — puts A.B.O. School Manager on the phone home screen / computer like a normal app (own icon, own
// window, opens straight to the school). Chrome, Edge, Samsung Internet and Opera show their install box when the
// button is pressed. Safari and Firefox do not allow a button to install, so we show their exact steps instead.
import { h } from './dom.js';
import { modal, toast } from './ui.js';

export const installed = () => (window.matchMedia && (matchMedia('(display-mode: standalone)').matches || matchMedia('(display-mode: window-controls-overlay)').matches || matchMedia('(display-mode: minimal-ui)').matches)) || navigator.standalone === true;
export const canPrompt = () => !!window.__aboInstallEvent;
export const onInstallChange = (fn) => window.addEventListener('abo-install-ready', fn);

export function browserName() {
  const ua = navigator.userAgent || ''; const touch = (navigator.maxTouchPoints || 0) > 1;
  const ios = /iPhone|iPad|iPod/.test(ua) || (/Macintosh/.test(ua) && touch);
  if (ios) return /CriOS/.test(ua) ? 'ios-chrome' : /FxiOS/.test(ua) ? 'ios-firefox' : /EdgiOS/.test(ua) ? 'ios-edge' : 'ios-safari';
  if (/SamsungBrowser/.test(ua)) return 'samsung';
  if (/Edg\//.test(ua)) return /Android/.test(ua) ? 'edge-android' : 'edge';
  if (/OPR\//.test(ua)) return 'opera';
  if (/Firefox\//.test(ua)) return /Android/.test(ua) ? 'firefox-android' : 'firefox';
  if (/Chrome\//.test(ua)) return /Android/.test(ua) ? 'chrome-android' : 'chrome';
  if (/Safari\//.test(ua) && /Macintosh/.test(ua)) return 'mac-safari';
  return 'other';
}
// exact steps per browser (checked Oct 2026). iOS: every browser on iPhone/iPad uses Apple's "Add to Home Screen".
export const STEPS = {
  chrome: ['Click the install icon at the right end of the address bar (a small screen with a down arrow).', 'Or open the menu ⋮ › Cast, save and share › Install page as app.', 'Click Install. The app opens in its own window and appears in your Start menu / Applications.'],
  edge: ['Click the “App available” icon in the address bar.', 'Or open the menu ⋯ › Apps › Install this site as an app.', 'Click Install.'],
  opera: ['Open the menu › Install app (or the install icon in the address bar), then confirm.'],
  'chrome-android': ['Tap the menu ⋮ at the top right.', 'Tap “Add to Home screen” and choose Install (or tap “Install app”).', 'The A.B.O. icon appears on your home screen.'],
  'edge-android': ['Tap the menu ⋯ at the bottom.', 'Tap “Add to phone” › Install.'],
  samsung: ['Tap the menu ☰ at the bottom.', 'Tap “Add page to” › Home screen (or the install icon in the address bar).'],
  'firefox-android': ['Tap the menu ⋮.', 'Tap “Add app to Home screen” (older versions: “Install”).', 'Confirm Add.'],
  firefox: ['Firefox on computers cannot install apps yet. Firefox on Windows can “Add to taskbar” if you turn it on: Settings › Firefox Labs › “Add sites to your taskbar”, then click the new icon in the address bar.', 'For a full app window, open this address in Chrome or Microsoft Edge and click Install.', 'Or simply bookmark this page.'],
  'mac-safari': ['Safari 17 or newer: open the File menu (or the Share button).', 'Choose “Add to Dock”, then Add.'],
  'ios-safari': ['Tap the Share button (a square with an arrow pointing up).', 'Scroll down and tap “Add to Home Screen”.', 'Tap Add. Open the app from the new A.B.O. icon.'],
  'ios-chrome': ['Tap the Share button in the address bar.', 'Tap “Add to Home Screen”, then Add.'],
  'ios-edge': ['Tap the menu ⋯ › Share › “Add to Home Screen”.'],
  'ios-firefox': ['Tap the menu ☰ › Share › “Add to Home Screen”.'],
  other: ['Open your browser menu and look for “Install app”, “Add to Home screen” or “Add to Dock”.', 'Chrome and Microsoft Edge give the best app experience.'],
};
const NAMES = { chrome: 'Google Chrome', edge: 'Microsoft Edge', opera: 'Opera', 'chrome-android': 'Chrome on Android', 'edge-android': 'Edge on Android', samsung: 'Samsung Internet', 'firefox-android': 'Firefox on Android', firefox: 'Firefox on a computer', 'mac-safari': 'Safari on Mac', 'ios-safari': 'Safari on iPhone / iPad', 'ios-chrome': 'Chrome on iPhone / iPad', 'ios-edge': 'Edge on iPhone / iPad', 'ios-firefox': 'Firefox on iPhone / iPad', other: 'your browser' };

export async function installApp() {
  if (installed()) { toast('The app is already installed on this device.'); return 'installed'; }
  const ev = window.__aboInstallEvent;
  if (ev) {
    ev.prompt();
    const r = await ev.userChoice.catch(() => ({ outcome: 'dismissed' }));
    window.__aboInstallEvent = null;
    if (r.outcome === 'accepted') toast('Installing… the A.B.O. icon will appear on this device.');
    return r.outcome;
  }
  showSteps(); return 'help';
}
export function showSteps() {
  const b = browserName(); const secure = location.protocol === 'https:' || /^(localhost|127\.0\.0\.1)$/.test(location.hostname);
  const others = ['chrome-android', 'ios-safari', 'chrome', 'edge', 'firefox-android', 'mac-safari'].filter((k) => k !== b);
  const closeBtn = h('button.btn.btn-primary', { type: 'button', text: 'Close' });
  const m = modal({ title: 'Install the app on this device', body: h('div.install-help',
    secure ? null : h('div.alert.alert-warn', h('span', { text: 'Installing needs the secure https:// address of your school portal. Open the app from its https:// link first.' })),
    h('p', { text: 'Installing puts the A.B.O. icon on your home screen or computer. It opens in its own window, straight to your school — no address to type. It uses the same safe sign-in.' }),
    h('h3', { text: `On ${NAMES[b]}` }), h('ol', STEPS[b].map((s) => h('li', { text: s }))),
    h('details', h('summary', { text: 'Other phones and browsers' }), others.map((k) => h('div.install-other', h('strong', { text: NAMES[k] }), h('ol', STEPS[k].map((s) => h('li', { text: s })))))),
  ), actions: [closeBtn] });
  closeBtn.addEventListener('click', m.close);
}
