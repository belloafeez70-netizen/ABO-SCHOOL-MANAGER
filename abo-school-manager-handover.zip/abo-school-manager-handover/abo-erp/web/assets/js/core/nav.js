// Navigation is derived from the permissions the SERVER returned — hiding items is UX only; every
// endpoint independently enforces authorisation.
//
// Model: categories (small caps labels) → sections (icon + label; a single link or an expandable group) → items.
// Only one group is open at a time, so the sidebar stays short. Utility pages live in the sidebar footer.
import { can, portal, session } from './session.js';
import { word } from './words.js';
import { hubTabs } from './hubs.js';

const UUID = '[0-9a-f-]{36}';
// 12 Oct 2026 (owner's request): repeated menu entries merged. Pages that belong together are ONE menu entry and a row
// of tabs at the top of the page (core/hubs.js). A section with `hub` opens the first tab the person may see, and shows
// whenever any of its tabs is allowed — so a teacher's "Cashbook" entry opens Petty Cash, an owner's opens the book.
const STAFF = [
  { label: 'Overview', sections: [
    { key: 'dashboard', label: 'Dashboard', icon: 'dashboard', href: '#/' },
    { key: 'alerts', label: 'Reminders & Alerts', icon: 'bell', href: '#/alerts', perm: ['alerts.view'] }] },
  { label: 'People', sections: [
    { key: 'students', label: 'Students', icon: 'graduation', hub: 'students', match: new RegExp(`^#/(students(/(new|import|profile|${UUID}))?|guardians|promotion|id-cards)(\\?.*)?$`) },
    { key: 'staff', label: 'Staff & Teachers', icon: 'briefcase', hub: 'staff', match: /^#\/(staff|teachers(\/(accounts|assignments|activity))?|academic\/teachers)(\?.*)?$/ },
    { key: 'calendar', label: 'Calendar & Birthdays', icon: 'calendar', hub: 'calendar', match: /^#\/(calendar|birthdays)(\?.*)?$/ }] },
  { label: 'Academics', sections: [
    { key: 'academics', label: 'Classes & Subjects', icon: 'book', hub: 'academics', match: /^#\/academic\/(classes|subjects|allocation|sessions|terms|timetable)(\?.*)?$/ },
    { key: 'lessons', label: 'Lessons & Materials', icon: 'notebook', hub: 'lessons', match: /^#\/(lesson-notes|materials|live-classes)(\/.*)?(\?.*)?$/ },
    { key: 'attendance', label: 'Attendance', icon: 'calendarCheck', hub: 'attendance', match: /^#\/(attendance|clock|monitor|devices)(\?.*)?$/ }] },
  { label: 'Assessment', sections: [
    { key: 'cbt', label: 'CBT Examinations', icon: 'cbt', hub: 'cbt', match: /^#\/cbt(\/(?!result\/).*)?(\?.*)?$/ },
    { key: 'scores', label: 'Scores & Results', icon: 'clipboard', items: [
      { href: '#/scores/ca', label: 'Score Entry', perm: ['results.enter', 'results.enter_any'], match: /^#\/(scores\/(ca|exam)|results\/sheet\/[^?]+\?(.*&)?focus=(ca|exam))/ },
      { href: '#/results', label: 'Score Sheets', perm: ['results.enter', 'results.enter_any', 'results.view'], match: /^#\/results(\/sheet\/[^?]*)?(\?(?!(.*&)?focus=).*)?$/ },
      { href: '#/results/processing', label: 'Result Workflow', perm: ['results.approve', 'results.publish', 'results.enter_any', 'results.review'], match: /^#\/results\/(processing|approval|publishing)(\?.*)?$/ },
      { href: '#/corrections', label: 'Corrections', perm: ['results.update', 'results.approve'] },
      { href: '#/results/comments', label: 'Comment Helper', perm: ['results.enter', 'results.enter_any', 'results.approve'] }] },
    { key: 'reports', label: 'Reports', icon: 'table', items: [
      { href: '#/broadsheet', label: 'Class Broadsheet', perm: ['results.view'], match: /^#\/broadsheet(\/(terminal|subject|ranking|layout))?(\?.*)?$/ },
      { href: '#/broadsheet/cumulative', label: 'Cumulative Results', perm: ['results.view'], match: /^#\/broadsheet\/(cumulative|annual)(\?.*)?$/ },
      { href: '#/reports/student', label: 'Report Cards', perm: ['results.view'], match: new RegExp(`^#/(reports/(student|class|print|pdf)|report/${UUID})`) },
      { href: '#/analytics/classes', label: 'Analytics', perm: ['results.view', 'reports.view'], match: /^#\/analytics\/(classes|subjects|students|charts)(\?.*)?$/ },
      { href: '#/reports/templates', label: 'Report Templates', perm: ['settings.view'] },
      { href: '#/print-centre', label: 'Print Centre', perm: ['results.view', 'fees.view', 'attendance.view', 'attendance.create', 'store.view', 'cashbook.view'], match: /^#\/(print-centre|print\/(register|attendance|stock|ledger))(\?.*)?$/ }] }] },
  { label: 'Finance', sections: [
    { key: 'fees', label: 'Fees & Payments', icon: 'wallet', hub: 'fees', match: /^#\/fees(\/.*)?(\?.*)?$/ },
    { key: 'cashbook', label: 'Cashbook', icon: 'money', hub: 'cashbook', match: /^#\/(cashbook(\/categories)?|petty-cash)(\?.*)?$/ },
    { key: 'store', label: 'School Store', icon: 'layers', hub: 'store', match: /^#\/store(\/.*)?(\?.*)?$/ }] },
  { label: 'Communication', sections: [
    { key: 'comms', label: 'Messages & Notices', icon: 'message', hub: 'comms', badge: 'messages', match: /^#\/(announcements|messages)(\/.*)?(\?.*)?$/ },
    { key: 'documents', label: 'School Documents', icon: 'file', href: '#/documents', perm: ['documents.view'] }] },
  { label: 'Settings', sections: [
    { key: 'school', label: 'School Settings', icon: 'building', hub: 'school', match: /^#\/(school\/(profile|branding|head|web-address)|settings|billing)(\?.*)?$/ },
    { key: 'users', label: 'Users & Roles', icon: 'users', hub: 'users', match: /^#\/(users|roles|act-as)(\?.*)?$/ },
    { key: 'security', label: 'Activity & Security', icon: 'shield', hub: 'security', match: /^#\/(audit|security-events)(\?.*)?$/ },
    { key: 'data', label: 'Backup & Data', icon: 'download', hub: 'data', match: /^#\/(backup|data|migrate)(\?.*)?$/ }] },
];
const STAFF_FOOTER = [
  { key: 'f-start', label: 'Getting Started', icon: 'compass', href: '#/getting-started', perm: ['settings.update'] },
  { key: 'f-help', label: 'Help & Support', icon: 'help', href: '#/help' },
  { key: 'f-system', label: 'System Information', icon: 'info', href: '#/system', perm: ['settings.view'] },
];
const LEARNER = (parent) => [
  { label: 'Overview', sections: [{ key: 'dashboard', label: 'Dashboard', icon: 'dashboard', href: '#/' }] },
  { label: parent ? 'My Children' : 'My School', sections: [
    { key: 'results', label: parent ? 'Results' : 'My Results', icon: 'award', href: '#/my-results' },
    ...(parent ? [] : [{ key: 'mycbt', label: 'CBT Examinations', icon: 'cbt', href: '#/my-cbt', match: /^#\/(my-cbt|cbt\/result\/)/ }]),
    { key: 'myfees', label: parent ? 'Fees & Payments' : 'My Fees', icon: 'wallet', href: '#/my-fees' },
    { key: 'learning', label: 'Learning', icon: 'paperclip', href: '#/materials', perm: ['materials.view_own', 'materials.view_children', 'lesson_notes.view_own', 'lesson_notes.view_children'], match: /^#\/(materials|live-classes|lesson-notes)(\/[0-9a-f-]{36})?(\?.*)?$/ },
    { key: 'timetable', label: 'Timetable & Calendar', icon: 'calendar', href: '#/timetable', match: /^#\/(timetable|calendar)(\?.*)?$/ }] },
  { label: 'Communication', sections: [
    { key: 'notices', label: 'Notices', icon: 'megaphone', href: '#/announcements' },
    { key: 'messages', label: 'Messages', icon: 'message', href: '#/messages', badge: 'messages' }] },
];
const LEARNER_FOOTER = [{ key: 'f-help', label: 'Help & Support', icon: 'help', href: '#/help' }];
const PLATFORM = [
  { label: 'Platform', sections: [
    { key: 'schools', label: 'Schools', icon: 'building', items: [
      { href: '#/', label: 'All Schools', match: /^#\/(\?(?!.*status=pending).*)?$/ },
      { href: '#/?status=pending', label: 'Pending Approvals', match: /^#\/\?.*status=pending/ }] },
    { key: 'psec', label: 'Security Events', icon: 'shield', href: '#/platform/security', perm: ['platform.security.view'] },
    { key: 'phealth', label: 'System Health', icon: 'activity', href: '#/platform/health', perm: ['platform.health.view'] },
    { key: 'pdemo', label: 'Demo Links', icon: 'send', href: '#/platform/demo', perm: ['platform.billing.manage'] },
    { key: 'pbilling', label: 'Payments & Plans', icon: 'wallet', href: '#/platform/billing', perm: ['platform.billing.manage'] }] },
];

// demo sessions: owner-level settings pages are not part of the demo (the server also refuses changing them)
const DEMO_HIDDEN = new Set(['#/settings', '#/system', '#/getting-started']);
const visible = (i) => (!i.perm || can(...i.perm)) && !(session.me && session.me.demo && DEMO_HIDDEN.has(i.href));
function prune(cats) {
  return cats.map((c) => ({ ...c, sections: c.sections.filter(visible).map((s) => (s.items ? { ...s, items: s.items.filter(visible) } : s)).filter((s) => !s.items || s.items.length) }))
    .filter((c) => c.sections.length);
}
// a hub section → a single link to the first tab this person may open (hidden when none is allowed)
function resolveHubs(cats) {
  return cats.map((c) => ({ ...c, sections: c.sections.map((s) => {
    if (!s.hub) return s;
    const tabs = hubTabs(s.hub);
    if (!tabs.length) return null;
    return { ...s, href: tabs[0].href, label: tabs.length === 1 ? tabs[0].label : s.label, tabs };
  }).filter(Boolean) }));
}
export function navCategories() {
  const p = portal();
  const src = resolveHubs(p === 'platform' ? (session.me.support ? [...PLATFORM, ...STAFF.slice(1, 4)] : PLATFORM) : p === 'staff' ? STAFF : LEARNER(p === 'parent'));
  // simple words (default) or full terms; the full name is kept for the menu search
  const w = (x) => ({ ...x, label: word(x.label), full: x.label });
  return prune(src).map((c) => ({ ...w(c), sections: c.sections.map((sec) => ({ ...w(sec), items: sec.items ? sec.items.map(w) : sec.items })) }));
}
export function navFooter() { const p = portal(); return (p === 'staff' ? STAFF_FOOTER : p === 'platform' ? [] : LEARNER_FOOTER).filter(visible).map((f) => ({ ...f, label: word(f.label), full: f.label })); }
// flat section list (bottom bar, tests)
export function navTree() { return navCategories().flatMap((c) => c.sections.map((s) => ({ ...s, category: c.label }))); }
// every link (items + single-link sections + footer)
export const navLinks = () => [...navTree().flatMap((s) => (s.items ? s.items.map((i) => ({ ...i, section: s })) : [{ ...s, section: s }])), ...navFooter().map((f) => ({ ...f, section: f }))];
export function navGroups() { return navTree().map((s) => ({ group: s.label, items: s.items || [s] })); }

// the menu entry that owns a location: explicit `match` wins, then exact path, then the longest prefix
export function activeEntry(hash) {
  const full = hash || '#/'; const path = full.split('?')[0] || '#/';
  const links = navLinks();
  const byMatch = links.find((l) => l.match && l.match.test(full));
  if (byMatch) return byMatch;
  const exact = links.find((l) => l.href === full) || links.find((l) => l.href.split('?')[0] === path && !l.href.includes('?'));
  if (exact) return exact;
  let best = null;
  for (const l of links) { const h = l.href.split('?')[0]; if (h !== '#/' && path.startsWith(h + '/') && (!best || h.length > best.href.length)) best = l; }
  return best;
}
