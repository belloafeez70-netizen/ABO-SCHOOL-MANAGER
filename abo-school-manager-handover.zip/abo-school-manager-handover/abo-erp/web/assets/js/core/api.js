// API client. Session lives in an HttpOnly cookie the JS cannot read; we only keep the CSRF token (in memory).
// Nothing sensitive is written to localStorage/sessionStorage.
import { apiUrl, credentials } from './config.js';

let csrf = null;
const listeners = new Set();
export class ApiError extends Error {
  constructor(status, body) {
    const e = (body && body.error && typeof body.error === 'object') ? body.error : {};
    super(e.message || `Request failed (${status})`); this.status = status; this.code = e.code; this.details = e.details; this.requestId = e.requestId;
  }
}
export const onAuthError = (fn) => listeners.add(fn);
export const setCsrf = (t) => { csrf = t || null; };
async function request(method, url, body, opts = {}) {
  const headers = { accept: 'application/json', ...(opts.headers || {}) };
  if (method !== 'GET' && csrf) headers['x-csrf-token'] = csrf;
  let payload;
  if (body instanceof FormData) payload = body;
  else if (body !== undefined) { headers['content-type'] = 'application/json'; payload = JSON.stringify(body); }
  let res;
  try { res = await fetch(apiUrl(url), { method, headers, body: payload, credentials, cache: 'no-store' }); }
  catch { throw new ApiError(0, { message: 'You appear to be offline. Check your connection and try again.' }); }
  if (opts.raw) { if (!res.ok) throw new ApiError(res.status, await res.json().catch(() => ({}))); return res; }
  const saved = res.headers.get('X-ABO-Offline-Copy');
  if (saved) import('./offline.js').then((m) => m.offlineCopy(saved)).catch(() => {});
  const data = res.status === 204 ? null : await res.json().catch(() => null);
  if (data && data.csrf) csrf = data.csrf;
  // the server is very busy (503 BUSY): wait the time it asks for and try a READ once more, quietly
  if (res.status === 503 && method === 'GET' && !opts.retried && data && data.error && data.error.code === 'BUSY') {
    const wait = Math.min(5, Number(res.headers.get('Retry-After')) || 2) * 1000 * (0.75 + Math.random() * 0.5);
    await new Promise((r) => setTimeout(r, wait));
    return request(method, url, body, { ...opts, retried: true });
  }
  if (!res.ok) {
    const err = new ApiError(res.status, data || {});
    if (res.status === 401 || ['MFA_REQUIRED', 'MFA_ENROLL_REQUIRED', 'PASSWORD_CHANGE_REQUIRED'].includes(err.code)) listeners.forEach((fn) => fn(err));
    throw err;
  }
  return data;
}
export const api = {
  get: (u, o) => request('GET', u, undefined, o), post: (u, b, o) => request('POST', u, b ?? {}, o),
  // idempotent POST: the same key is re-sent on retry, so a double-click / flaky network never duplicates a payment
  postOnce: (u, b, key) => request('POST', u, b ?? {}, { headers: { 'idempotency-key': key || (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random().toString(36).slice(2)) } }), put: (u, b) => request('PUT', u, b),
  patch: (u, b) => request('PATCH', u, b), del: (u, b) => request('DELETE', u, b), raw: (m, u, b) => request(m, u, b, { raw: true }),
};
export const qs = (o) => { const p = new URLSearchParams(); for (const [k, v] of Object.entries(o || {})) if (v !== undefined && v !== null && v !== '') p.set(k, v); const s = p.toString(); return s ? `?${s}` : ''; };
// download an authorised file (export/receipt) through fetch so the cookie + CSRF rules apply
export async function download(url, fallbackName) {
  const res = await api.raw('GET', url);
  const cd = res.headers.get('content-disposition') || ''; const m = /filename="([^"]+)"/.exec(cd);
  const blob = await res.blob(); const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = (m && m[1]) || fallbackName || 'download'; document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
}
