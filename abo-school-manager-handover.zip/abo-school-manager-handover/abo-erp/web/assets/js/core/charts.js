// Tiny inline-SVG charts built with createElementNS (no innerHTML, no external library — works under the strict CSP
// and inside the offline preview). Labels are inserted as text nodes, so user data can never inject markup.
const NS = 'http://www.w3.org/2000/svg';
function el(tag, attrs = {}, text) {
  const n = document.createElementNS(NS, tag);
  for (const [k, v] of Object.entries(attrs)) if (v !== undefined && v !== null) n.setAttribute(k, String(v));
  if (text !== undefined) n.textContent = String(text);
  return n;
}
const clip = (s, n) => (String(s).length > n ? String(s).slice(0, n - 1) + '…' : String(s));

// vertical bar chart: items [{ label, value, tone? }]
export function barChart(items, { max = 100, height = 240, fmt = (v) => v, title = 'Bar chart', threshold } = {}) {
  const n = Math.max(1, items.length); const bw = Math.max(18, Math.min(56, 640 / n - 10)); const gap = 10;
  const W = Math.max(320, n * (bw + gap) + 50); const H = height; const top = 18; const bottom = 54; const left = 36; const ph = H - top - bottom;
  const svg = el('svg', { class: 'chart', viewBox: `0 0 ${W} ${H}`, role: 'img', 'aria-label': title });
  svg.appendChild(el('title', {}, title));
  for (let i = 0; i <= 4; i++) {
    const y = top + ph - (ph * i) / 4; const v = Math.round((max * i) / 4);
    svg.appendChild(el('line', { class: 'grid', x1: left, x2: W - 6, y1: y, y2: y }));
    svg.appendChild(el('text', { x: left - 6, y: y + 4, 'text-anchor': 'end' }, v));
  }
  if (threshold !== undefined) { const y = top + ph - (ph * threshold) / max; svg.appendChild(el('line', { x1: left, x2: W - 6, y1: y, y2: y, stroke: 'currentColor', 'stroke-dasharray': '4 4', opacity: 0.5 })); }
  items.forEach((it, i) => {
    const v = Math.max(0, Math.min(max, Number(it.value) || 0)); const h = (ph * v) / max;
    const x = left + 8 + i * (bw + gap); const y = top + ph - h;
    const r = el('rect', { class: `bar${it.tone ? ' ' + it.tone : ''}`, x, y, width: bw, height: Math.max(0, h), rx: 4 });
    r.appendChild(el('title', {}, `${it.label}: ${fmt(it.value)}`)); svg.appendChild(r);
    svg.appendChild(el('text', { class: 'val', x: x + bw / 2, y: y - 4, 'text-anchor': 'middle' }, fmt(it.value)));
    const t = el('text', { x: x + bw / 2, y: top + ph + 14, 'text-anchor': 'end', transform: `rotate(-35 ${x + bw / 2} ${top + ph + 14})` }, clip(it.label, 14));
    svg.appendChild(t);
  });
  svg.appendChild(el('line', { class: 'axis', x1: left, x2: W - 6, y1: top + ph, y2: top + ph }));
  return svg;
}

// line chart: points [{ label, value }]
export function lineChart(points, { max = 100, height = 220, fmt = (v) => v, title = 'Trend' } = {}) {
  const W = Math.max(320, points.length * 110 + 60); const H = height; const top = 20; const bottom = 40; const left = 36; const right = 20; const ph = H - top - bottom;
  const svg = el('svg', { class: 'chart', viewBox: `0 0 ${W} ${H}`, role: 'img', 'aria-label': title });
  svg.appendChild(el('title', {}, title));
  for (let i = 0; i <= 4; i++) { const y = top + ph - (ph * i) / 4; svg.appendChild(el('line', { class: 'grid', x1: left, x2: W - right, y1: y, y2: y })); svg.appendChild(el('text', { x: left - 6, y: y + 4, 'text-anchor': 'end' }, Math.round((max * i) / 4))); }
  const step = points.length > 1 ? (W - left - right - 30) / (points.length - 1) : 0;
  const xy = points.map((p, i) => [left + 15 + i * step, top + ph - (ph * Math.max(0, Math.min(max, Number(p.value) || 0))) / max]);
  if (xy.length > 1) svg.appendChild(el('polyline', { class: 'line', points: xy.map((p) => p.join(',')).join(' ') }));
  xy.forEach(([x, y], i) => {
    const d = el('circle', { class: 'dot', cx: x, cy: y, r: 4.5 }); d.appendChild(el('title', {}, `${points[i].label}: ${fmt(points[i].value)}`)); svg.appendChild(d);
    svg.appendChild(el('text', { class: 'val', x, y: y - 9, 'text-anchor': 'middle' }, fmt(points[i].value)));
    svg.appendChild(el('text', { x, y: top + ph + 18, 'text-anchor': 'middle' }, clip(points[i].label, 18)));
  });
  return svg;
}

// donut: slices [{ label, value, color }]
export function donut(slices, { size = 180, title = 'Distribution' } = {}) {
  const total = slices.reduce((a, s) => a + (Number(s.value) || 0), 0) || 1;
  const r = size / 2 - 14; const c = size / 2; const circ = 2 * Math.PI * r; let off = 0;
  const svg = el('svg', { class: 'chart donut', viewBox: `0 0 ${size} ${size}`, role: 'img', 'aria-label': title, width: size, height: size });
  svg.appendChild(el('title', {}, title));
  svg.appendChild(el('circle', { class: 'donut-bg', cx: c, cy: c, r, fill: 'none', 'stroke-width': 22 }));
  for (const s of slices) {
    const len = circ * ((Number(s.value) || 0) / total);
    const seg = el('circle', { cx: c, cy: c, r, fill: 'none', stroke: s.color, 'stroke-width': 22, 'stroke-dasharray': `${len} ${circ - len}`, 'stroke-dashoffset': -off, transform: `rotate(-90 ${c} ${c})` });
    seg.appendChild(el('title', {}, `${s.label}: ${s.value}`)); svg.appendChild(seg); off += len;
  }
  svg.appendChild(el('text', { x: c, y: c + 6, 'text-anchor': 'middle', class: 'val', 'font-size': 18 }, total === 1 && !slices.some((s) => s.value) ? 0 : total));
  return svg;
}
export const PALETTE = ['#0a7d61', '#175cd3', '#d99a16', '#6938ef', '#0f766e', '#b42318', '#2d5a86', '#96660a', '#31b896', '#98a2b3'];
