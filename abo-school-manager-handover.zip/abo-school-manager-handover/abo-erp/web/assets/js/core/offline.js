// Offline support (page side). Registers the service worker (web/sw.js), tells it who is signed in (each person's saved
// copy is kept apart), deletes the saved copy on sign-out, and shows a clear bar when the internet is gone or when a page
// is showing the last saved copy. Saving anything still needs the internet.
const sw = () => (navigator.serviceWorker && navigator.serviceWorker.controller) || null;
const send = (msg) => { try { const c = sw(); if (c) c.postMessage(msg); else if (navigator.serviceWorker) navigator.serviceWorker.ready.then((r) => r.active && r.active.postMessage(msg)).catch(() => {}); } catch { /* not supported */ } };
export function registerOffline() {
  if (!('serviceWorker' in navigator)) return;
  if (location.protocol !== 'https:' && !/^(localhost|127\.0\.0\.1)$/.test(location.hostname)) return;   // browsers allow it only on https
  navigator.serviceWorker.register('/sw.js', { scope: '/' }).catch(() => { /* offline support is optional */ });
  addEventListener('online', () => bar(null)); addEventListener('offline', () => bar('You are offline. Pages you opened before still show their last saved copy. Saving needs the internet.'));
  if (!navigator.onLine) bar('You are offline. Pages you opened before still show their last saved copy. Saving needs the internet.');
}
export const offlineUser = (id) => send({ type: 'user', id: id || null });
export const offlineSignedOut = () => send({ type: 'signed-out' });
export function offlineCopy(savedAt) {
  const t = savedAt && !Number.isNaN(Date.parse(savedAt)) ? new Date(savedAt).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : 'earlier';
  bar(`No connection to the school server right now. This page shows the copy saved on ${t}. Saving needs the connection.`);
}
function bar(text) {
  let el = document.getElementById('offlineBar');
  if (!text) { if (el) el.remove(); return; }
  if (!el) { el = document.createElement('div'); el.id = 'offlineBar'; el.className = 'offline-bar'; el.setAttribute('role', 'status'); document.body.appendChild(el); }
  el.textContent = text;
}
