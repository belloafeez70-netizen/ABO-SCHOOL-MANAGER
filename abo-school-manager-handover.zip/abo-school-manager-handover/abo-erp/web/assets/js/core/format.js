export const naira = (kobo) => '₦' + (Number(kobo || 0) / 100).toLocaleString('en-NG', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
export const toKobo = (naira) => Math.round(Number(String(naira).replace(/[^0-9.]/g, '')) * 100);
export const date = (d) => (d ? new Date(d.length === 10 ? d + 'T00:00:00' : d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—');
export const dateTime = (d) => (d ? new Date(d).toLocaleString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—');
export function ago(d) {
  if (!d) return '—'; const s = (Date.now() - new Date(d).getTime()) / 1000;
  if (s < 60) return 'just now'; if (s < 3600) return `${Math.floor(s / 60)}m ago`; if (s < 86400) return `${Math.floor(s / 3600)}h ago`; if (s < 604800) return `${Math.floor(s / 86400)}d ago`; return date(d);
}
export const initials = (n) => String(n || '?').split(/\s+/).filter(Boolean).slice(0, 2).map((x) => x[0].toUpperCase()).join('');
export const ordinal = (n) => { if (!n) return '—'; const s = ['th', 'st', 'nd', 'rd'], v = n % 100; return n + (s[(v - 20) % 10] || s[v] || s[0]); };
export const today = () => new Date().toISOString().slice(0, 10);
export const cap = (s) => String(s || '').replace(/_/g, ' ').replace(/\b\w/g, (m) => m.toUpperCase());

// term names are stored as 1ST / 2ND / 3RD (a database rule); people read them as 1st / 2nd / 3rd
export const tn = (n) => ({ '1ST': '1st', '2ND': '2nd', '3RD': '3rd' }[String(n || '').toUpperCase()] || n);
