// Simple words (the owner's standing rule: "simple terms a 10-year-old can navigate").
// Menu names, page titles and the breadcrumb use everyday words by default. The "Show full terms" switch at the bottom
// of the menu brings back the office terms (for bursars, accountants, inspectors). The menu search finds a page by
// either name. Only labels change — never what users type, and never any data.
const KEY = 'abo.words';
export const SIMPLE = {
  'Dashboard': 'Home', 'Academics': 'Teaching', 'Assessment': 'Tests & Results', 'Finance': 'Money', 'Communication': 'Keep in Touch',
  'Academic Sessions': 'School Years', 'Subject Allocation': 'Who Teaches What', 'Assigned Subjects': 'Who Teaches What', 'Teacher Activity': 'What Teachers Did',
  'Promotion': 'Move to Next Class', 'Student Import': 'Add Many Students at Once', 'Student List': 'All Students',
  'CBT Examinations': 'Computer Tests (CBT)', 'Question Bank': 'Saved Questions', 'Create Examination': 'Make a Computer Test', 'Examinations': 'All Computer Tests',
  'CA Score Entry': 'Type Class Test Scores (CA)', 'Exam Score Entry': 'Type Exam Scores', 'Score Management': 'All Score Sheets',
  'Result Processing': 'Work Out Results', 'Result Approval': 'Check & Approve Results', 'Result Publishing': 'Send Results Out', 'Corrections': 'Fix a Score',
  'Broadsheets & Reports': 'Score Sheets & Report Cards', 'Reports': 'Score Sheets & Report Cards', 'Score Sheets': 'All Score Sheets', 'Class Broadsheet': 'Class Score Sheet', 'Subject Broadsheet': 'Subject Score Sheet',
  'Terminal Broadsheet': 'Term Score Sheet', 'Annual Broadsheet': 'Whole-Year Score Sheet', 'Cumulative Results': 'Results So Far (All Terms)', 'Position & Ranking': 'Class Positions', 'Position / Ranking': 'Class Positions',
  'Analytics': 'Charts', 'Class Performance': 'How Each Class Did', 'Subject Performance': 'How Each Subject Did', 'Student Performance': 'How Each Student Did', 'Performance Charts': 'Result Charts',
  'Invoices': 'Bills', 'Fee Setup': 'Set School Fees', 'Cashbook': 'Money In & Out', 'Income & Expenses': 'Money Book', 'Cashbook Categories': 'Money Headings', 'Categories': 'Money Headings',
  'School Store': 'School Shop', 'Items & Stock': 'Shop Items', 'Sell Items': 'Sell', 'Store Sales': 'Shop Sales',
  'Review Queue': 'Notes to Check', 'Coverage Report': 'Notes Summary', 'Lesson Notes Coverage': 'Notes Summary',
  'Users': 'Logins', 'Roles & Permissions': 'Who Can Do What', 'Audit Logs': 'Who Did What', 'Audit log': 'Who Did What', 'Security Events': 'Safety Alerts',
  'Backup & Restore': 'Save a Copy', 'Import & Export': 'Bring In / Take Out Data', 'Legacy Migration': 'Bring In Old App Data', 'Legacy migration': 'Bring In Old App Data',
  'System Information': 'About This System',
  'Broadsheet': 'Class Score Sheet', 'Academic setup': 'Classes & Subjects Setup', 'CBT Analytics': 'Computer Test Charts', 'CBT Dashboard': 'Computer Tests Summary', 'CBT Settings': 'Computer Test Settings',
  'My CBT Exams': 'My Computer Tests', 'End-of-session promotion': 'Move to Next Class', 'Fee structures & discounts': 'School Fees & Discounts', 'Fees overview': 'School Fees Summary',
  'Result Templates': 'Report Card Designs', 'Result corrections': 'Fix a Score', 'Roles & permissions': 'Who Can Do What', 'Security events': 'Safety Alerts', 'Platform security events': 'Safety Alerts',
  'Score entry & review': 'Type & Check Scores', 'Document archive': 'Saved Documents', 'Import & export': 'Bring In / Take Out Data', 'Users & access': 'Logins', 'Class Monitor': 'Classes Right Now', 'Study Materials': 'Notes & Videos',
  'Score Entry': 'Type Scores', 'Result Workflow': 'Check & Send Out Results', 'Sessions & Terms': 'School Years & Terms', 'Backup & Data': 'Save a Copy & Bring In Data',
  'Results & Analytics': 'Results & Charts', 'Timetable & Calendar': 'Timetable & Calendar', 'Teachers': 'Teachers',
};
export const isSimple = () => { try { return localStorage.getItem(KEY) !== 'full'; } catch { return true; } };
export const word = (s) => (isSimple() && s && Object.prototype.hasOwnProperty.call(SIMPLE, s) ? SIMPLE[s] : s);
export function setSimple(on) { try { localStorage.setItem(KEY, on ? 'simple' : 'full'); } catch { /* private mode: keep default */ } }
