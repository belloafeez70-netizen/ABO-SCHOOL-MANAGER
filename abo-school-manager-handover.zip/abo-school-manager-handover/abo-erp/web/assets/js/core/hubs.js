// Page groups ("hubs"): pages that belong together share ONE menu entry and a row of tabs at the top of the page,
// instead of five look-alike menu items (owner's request, 11 Oct 2026: "merge repeated features for proper navigation").
// The pages themselves are unchanged and keep their addresses (old links and bookmarks still work).
// Tabs only show what the person may open (UX only — the server checks every request).
import { h } from './dom.js';
import { can, portal } from './session.js';
import { word } from './words.js';

const LN_MINE = /^#\/lesson-notes(\?(?!(.*&)?scope=(review|all)).*)?$/;
export const HUBS = [
  // ── people ──
  { key: 'students', portals: ['staff'], tabs: [
    { href: '#/students', label: 'Student List', perm: ['students.view'] },
    { href: '#/guardians', label: 'Parents & Guardians', perm: ['guardians.view'] },
    { href: '#/promotion', label: 'Promotion', perm: ['promotion.run'] },
    { href: '#/students/import', label: 'Import', perm: ['imports.run'] },
    { href: '#/id-cards', label: 'ID Cards', perm: ['students.view', 'staff.view'] }] },
  { key: 'staff', portals: ['staff'], tabs: [
    { href: '#/teachers', label: 'Teachers', perm: ['teachers.view'] },
    { href: '#/staff', label: 'Staff Records', perm: ['staff.view'] },
    { href: '#/teachers/assignments', label: 'Who Teaches What', perm: ['teachers.view'] },
    { href: '#/teachers/activity', label: 'Activity', perm: ['teachers.view'] },
    { href: '#/teachers/accounts', label: 'Sign-in Accounts', perm: ['staff.view'] }] },
  { key: 'calendar', portals: ['staff'], tabs: [
    { href: '#/calendar', label: 'School Calendar', perm: ['calendar.view'] },
    { href: '#/birthdays', label: 'Birthdays', perm: ['birthdays.view'] }] },
  // ── academics ──
  { key: 'academics', tabs: [
    { href: '#/academic/classes', label: 'Classes & Arms', perm: ['academic.view'] },
    { href: '#/academic/subjects', label: 'Subjects', perm: ['academic.view'] },
    { href: '#/academic/allocation', label: 'Subject Allocation', perm: ['academic.view'] },
    { href: '#/academic/sessions', label: 'School Years', perm: ['academic.view'] },
    { href: '#/academic/terms', label: 'Terms', perm: ['academic.view'] },
    { href: '#/academic/timetable', label: 'Timetable', perm: ['academic.view'] }] },
  { key: 'lessons', portals: ['staff'], tabs: [
    { href: '#/lesson-notes', label: 'My Lesson Notes', perm: ['lesson_notes.create'], match: LN_MINE },
    { href: '#/lesson-notes?scope=review', label: 'Review Queue', perm: ['lesson_notes.review'], match: /^#\/lesson-notes\?(.*&)?scope=review/ },
    { href: '#/lesson-notes?scope=all', label: 'All Lesson Notes', perm: ['lesson_notes.view'], match: /^#\/lesson-notes\?(.*&)?scope=all/ },
    { href: '#/lesson-notes/summary', label: 'Coverage', perm: ['lesson_notes.view', 'lesson_notes.review'] },
    { href: '#/materials', label: 'Study Materials', perm: ['materials.view', 'materials.create', 'materials.manage'] },
    { href: '#/live-classes', label: 'Live Classes', perm: ['materials.view', 'materials.create', 'materials.manage'] }] },
  { key: 'attendance', portals: ['staff'], tabs: [
    { href: '#/attendance', label: 'Pupil Attendance', perm: ['attendance.view', 'attendance.create', 'attendance.update'] },
    { href: '#/clock', label: 'Staff Clock-in', perm: ['clock.use', 'clock.view'] },
    { href: '#/monitor', label: 'Classes Right Now', perm: ['clock.view'] },
    { href: '#/devices', label: 'Devices', perm: ['devices.view', 'devices.manage'] }] },
  // ── assessment ──
  { key: 'cbt', portals: ['staff'], tabs: [
    { href: '#/cbt/dashboard', label: 'Overview', perm: ['cbt.view'] },
    { href: '#/cbt', label: 'Examinations', perm: ['cbt.view'] },
    { href: '#/cbt/bank', label: 'Question Bank', perm: ['cbt.view'] },
    { href: '#/cbt/review', label: 'Teachers\u2019 Questions', perm: ['cbt.publish'] },
    { href: '#/cbt/candidates', label: 'Candidates', perm: ['cbt.update'] },
    { href: '#/cbt/results', label: 'Results', perm: ['cbt.results'] },
    { href: '#/cbt/analytics', label: 'Analytics', perm: ['cbt.results'] },
    { href: '#/cbt/settings', label: 'Settings', perm: ['cbt.view'] }] },
  { key: 'broadsheet', tabs: [
    { href: '#/broadsheet', label: 'Totals', perm: ['results.view'] },
    { href: '#/broadsheet/terminal', label: 'CA & Exam', perm: ['results.view'] },
    { href: '#/broadsheet/subject', label: 'One Subject', perm: ['results.view'] },
    { href: '#/broadsheet/ranking', label: 'Positions', perm: ['results.view'] },
    { href: '#/broadsheet/layout', label: 'Sheet Layout', perm: ['settings.view'] }] },
  { key: 'classreports', tabs: [
    { href: '#/reports/student', label: 'One Learner', perm: ['results.view'] },
    { href: '#/reports/class', label: 'Class List', perm: ['results.view'] },
    { href: '#/reports/print', label: 'Print All', perm: ['results.view'] },
    { href: '#/reports/pdf', label: 'Save as PDF', perm: ['results.view'] }] },
  { key: 'scoreentry', tabs: [
    { href: '#/scores/ca', label: 'CA Scores', perm: ['results.enter', 'results.enter_any'] },
    { href: '#/scores/exam', label: 'Exam Scores', perm: ['results.enter', 'results.enter_any'] }] },
  { key: 'workflow', tabs: [
    { href: '#/results/processing', label: '1. Work Out', perm: ['results.approve', 'results.publish', 'results.enter_any'] },
    { href: '#/results/approval', label: '2. Check & Approve', perm: ['results.review', 'results.approve'] },
    { href: '#/results/publishing', label: '3. Publish', perm: ['results.publish'] }] },
  { key: 'analytics', tabs: [
    { href: '#/analytics/classes', label: 'Classes', perm: ['results.view', 'reports.view'] },
    { href: '#/analytics/subjects', label: 'Subjects', perm: ['results.view', 'reports.view'] },
    { href: '#/analytics/students', label: 'Learners', perm: ['results.view'] },
    { href: '#/analytics/charts', label: 'Charts', perm: ['results.view', 'reports.view'] }] },
  { key: 'print', tabs: [
    { href: '#/print-centre', label: 'All Documents', perm: ['results.view', 'fees.view', 'attendance.view', 'attendance.create', 'store.view', 'cashbook.view'] },
    { href: '#/print/register', label: 'Blank Register', perm: ['attendance.view', 'attendance.create', 'students.view'] },
    { href: '#/print/attendance', label: 'Attendance Report', perm: ['attendance.view', 'attendance.create'] },
    { href: '#/print/stock', label: 'Stock Sheet', perm: ['store.view', 'store.manage'] },
    { href: '#/print/ledger', label: 'Cash Ledger', perm: ['cashbook.view'] }] },
  // ── finance ──
  { key: 'fees', portals: ['staff'], tabs: [
    { href: '#/fees', label: 'Overview', perm: ['fees.view'] },
    { href: '#/fees/invoices', label: 'Invoices', perm: ['fees.view'] },
    { href: '#/fees/payments', label: 'Payments & Receipts', perm: ['fees.view'] },
    { href: '#/fees/arrears', label: 'Old Debts', perm: ['fees.view'] },
    { href: '#/fees/setup', label: 'Fee Setup', perm: ['fees.view'] }] },
  { key: 'cashbook', portals: ['staff'], tabs: [
    { href: '#/cashbook', label: 'Income & Expenses', perm: ['cashbook.view'] },
    { href: '#/petty-cash', label: 'Petty Cash', perm: ['pettycash.request', 'pettycash.approve', 'cashbook.record'] },
    { href: '#/cashbook/categories', label: 'Categories', perm: ['cashbook.view'] }] },
  { key: 'store', portals: ['staff'], tabs: [
    { href: '#/store', label: 'Items & Stock', perm: ['store.view', 'store.manage', 'store.sell'] },
    { href: '#/store/sell', label: 'Sell Items', perm: ['store.sell'] },
    { href: '#/store/sales', label: 'Sales & Receipts', perm: ['store.view', 'store.sell'] }] },
  // ── communication & settings ──
  { key: 'comms', portals: ['staff'], tabs: [
    { href: '#/announcements', label: 'Announcements', perm: ['announcements.view', 'announcements.manage'] },
    { href: '#/messages', label: 'Messages', perm: ['messages.use'] }] },
  { key: 'school', tabs: [
    { href: '#/school/profile', label: 'Profile', perm: ['settings.view'] },
    { href: '#/school/branding', label: 'Logo & Colours', perm: ['settings.view'] },
    { href: '#/school/head', label: 'Principal / Head', perm: ['settings.view'] },
    { href: '#/settings', label: 'Grading & Rules', perm: ['settings.view'] },
    { href: '#/school/web-address', label: 'Web Address', perm: ['settings.view'] },
    { href: '#/billing', label: 'Subscription', perm: ['settings.view'] }] },
  { key: 'users', tabs: [
    { href: '#/users', label: 'Users', perm: ['users.view'] },
    { href: '#/roles', label: 'Roles & Permissions', perm: ['roles.view'] },
    { href: '#/act-as', label: 'Sign In As Someone', perm: ['users.impersonate'] }] },
  { key: 'security', tabs: [
    { href: '#/audit', label: 'Audit Logs', perm: ['audit_logs.view'] },
    { href: '#/security-events', label: 'Security Events', perm: ['security.view', 'audit_logs.view'] }] },
  { key: 'data', tabs: [
    { href: '#/backup', label: 'Backup & Restore', perm: ['reports.export', 'imports.run'] },
    { href: '#/data', label: 'Import & Export', perm: ['imports.run', 'reports.export'] },
    { href: '#/migrate', label: 'From the Old App', perm: ['imports.run'] }] },
  // ── portals ──
  { key: 'learning', portals: ['student', 'parent'], tabs: [
    { href: '#/materials', label: 'Notes & Videos', perm: ['materials.view_own', 'materials.view_children'] },
    { href: '#/live-classes', label: 'Live Classes', perm: ['materials.view_own', 'materials.view_children'] },
    { href: '#/lesson-notes', label: 'Lesson Notes', perm: ['lesson_notes.view_own', 'lesson_notes.view_children'] }] },
  { key: 'mycal', portals: ['student', 'parent'], tabs: [
    { href: '#/timetable', label: 'Timetable' },
    { href: '#/calendar', label: 'School Calendar', perm: ['calendar.view'] }] },
];

const path = (href) => href.split('?')[0];
// the platform's read-only support view shows the school's staff menu
const pt = () => (portal() === 'platform' ? 'staff' : portal());
const allowed = (t) => (!t.perm || can(...t.perm)) && (!t.portals || t.portals.includes(pt()));
// the hub a location belongs to (exact page address; sub-pages such as a single sheet or report card have no tabs)
// the tabs of one group this person may open (menu entries use the first one)
export function hubTabs(key) {
  const hub = HUBS.find((x) => x.key === key && (!x.portals || x.portals.includes(pt())));
  return hub ? hub.tabs.filter(allowed).map((t) => ({ ...t, label: word(t.label), full: t.label })) : [];
}
const tabHit = (t, hash) => (t.match ? t.match.test(hash) : path(t.href) === path(hash) && (!t.href.includes('?') || hash === t.href));
// the group a location belongs to (exact page address or the tab's own pattern; sub-pages such as a single sheet or
// report card have no tabs)
export function hubOf(hash) {
  const full = hash || '#/';
  for (const hub of HUBS) {
    if (hub.portals && !hub.portals.includes(pt())) continue;
    const tab = hub.tabs.find((t) => tabHit(t, full));
    if (tab && allowed(tab)) { const tabs = hub.tabs.filter(allowed); if (tabs.length > 1) return { hub, tabs, active: tab }; }
  }
  return null;
}
// tab row; keeps the chosen term / class when moving between tabs (read from the page's own pickers)
export function hubBar(hash) {
  const m = hubOf(hash); if (!m) return null;
  const carry = (href) => {
    const keep = new URLSearchParams(href.split('?')[1] || '');      // the tab's own address details (e.g. scope=review) stay
    for (const n of ['termId', 'classId', 'sessionId', 'subjectId']) { const el = document.querySelector(`#view select[name="${n}"]`); if (el && el.value) keep.set(n, el.value); }
    const q = keep.toString(); return q ? `${path(href)}?${q}` : href;
  };
  return h('nav.hub-tabs.no-print', { 'aria-label': 'Pages in this group' }, m.tabs.map((t) => h(`a.hub-tab${t === m.active ? '.active' : ''}`, {
    href: t.href, 'aria-current': t === m.active ? 'page' : null,
    on: { click: (ev) => { if (t === m.active) { ev.preventDefault(); return; } const to = carry(t.href); if (to !== t.href) { ev.preventDefault(); location.hash = to; } } },
  }, word(t.label))));
}
