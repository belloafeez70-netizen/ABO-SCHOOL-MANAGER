// Where the API lives, as seen from the browser. Contains NO secrets — only a public URL.
// • Default (''): same origin. On Netlify the edge function proxies /api/* to the backend, so the session cookie is
//   first-party on https://<site>.netlify.app.
// • PUBLIC_API_BASE (build-time, optional): e.g. https://api.yourschool.com.ng — only once BOTH the site and the API use
//   subdomains of YOUR OWN domain (same site), which removes the proxy hop at large scale. Never use it with a
//   netlify.app site and a different API domain: the cookie would be third-party and browsers would block sign-in.
/* global __ABO_API_BASE__, __ABO_SITE_URL__ */
export const API_BASE = (typeof __ABO_API_BASE__ !== 'undefined' && __ABO_API_BASE__) ? __ABO_API_BASE__ : '';
export const apiUrl = (path) => `${API_BASE}/api/v1${path}`;
export const fileUrl = (id) => apiUrl(`/files/${encodeURIComponent(id)}`);
export const credentials = API_BASE ? 'include' : 'same-origin';
// Public address of the live portal (build-time PUBLIC_SITE_URL, e.g. https://abo-school-manager.netlify.app). Used only to
// offer a link when the single-file app is opened straight from disk, where sign-in cannot work.
export const SITE_URL = (typeof __ABO_SITE_URL__ !== 'undefined' && __ABO_SITE_URL__) ? __ABO_SITE_URL__ : '';
