import { api, setCsrf } from './api.js';
export const session = { me: null };
export async function loadMe() {
  const me = await api.get('/auth/me');
  setCsrf(me.csrf); session.me = me;
  import('./offline.js').then((m) => m.offlineUser(me.user && me.user.id)).catch(() => {});
  return me;
}
export const can = (...perms) => !!session.me && perms.some((p) => session.me.permissions.includes(p));
export const portal = () => (session.me ? session.me.portal : null);
export function workspace() {
  const me = session.me; if (!me) return 'guest';
  if (me.portal === 'platform') return me.support ? 'support' : 'platform';
  if (me.portal !== 'staff') return me.portal;
  const keys = me.roles.map((r) => r.key);
  if (keys.includes('school_owner')) return 'owner';
  if (keys.some((k) => ['administrator', 'principal', 'vice_principal', 'head_of_school', 'ict_officer'].includes(k))) return 'admin';
  if (keys.some((k) => ['bursar', 'accountant'].includes(k))) return 'finance';
  return 'teacher';
}
