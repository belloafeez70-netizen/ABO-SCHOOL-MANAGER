// Reports uncaught browser errors to the API (POST /api/v1/client-errors) so problems on the Netlify-hosted app reach
// the same logs and alerts as server errors. No personal data: URL query strings are dropped, at most 5 reports per
// page load, duplicates are skipped. Contains no secrets — it only calls the same-origin API.
import { apiUrl, credentials } from './config.js';

const sent = new Set(); let count = 0;
const clean = (s, n) => String(s || '').replace(/\?[^\s)]*/g, '').slice(0, n);
function report(kind, message, source, line, column, stack) {
  try {
    const key = `${kind}|${message}|${source}|${line}`;
    if (count >= 5 || sent.has(key) || !message) return;
    sent.add(key); count++;
    const body = JSON.stringify({ kind, message: clean(message, 500), source: clean(source, 300), line: Number(line) || 0, column: Number(column) || 0,
      stack: clean(stack, 2000), route: (location.hash || '#/').split('?')[0].slice(0, 200), release: document.documentElement.dataset.release || 'dev' });
    fetch(apiUrl('/client-errors'), { method: 'POST', headers: { 'content-type': 'application/json' }, body, keepalive: true, credentials }).catch(() => {});
  } catch { /* never throw from the error reporter */ }
}
export function installTelemetry() {
  if (location.protocol === 'file:') return;          // opened from disk: there is no API to report to
  window.addEventListener('error', (e) => { if (e.error || e.message) report('error', e.message, e.filename, e.lineno, e.colno, e.error && e.error.stack); });
  window.addEventListener('unhandledrejection', (e) => { const r = e.reason || {}; report('unhandledrejection', r.message || String(r), '', 0, 0, r.stack); });
}
