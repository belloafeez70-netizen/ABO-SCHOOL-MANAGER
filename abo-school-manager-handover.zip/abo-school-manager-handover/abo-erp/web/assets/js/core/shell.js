import { h, clear, icon, $ } from './dom.js';
import { api } from './api.js';
import { session, workspace, can } from './session.js';
import { navCategories, navFooter, navTree, activeEntry } from './nav.js';
import { initials, ago, tn } from './format.js';
import { toast, fail } from './ui.js';
import { fileUrl } from './config.js';
import { word, isSimple, setSimple } from './words.js';
import { installApp, installed, onInstallChange } from './install.js';

const WS_LABEL = { owner: 'Owner', admin: 'Administration', finance: 'Finance', teacher: 'Teacher', student: 'Student portal', parent: 'Parent portal', platform: 'Platform console', support: 'Support view (read-only)' };
export function applyTheme(mode) { document.body.dataset.mode = mode; try { localStorage.setItem('aboThemeMode', mode); } catch { /* private mode */ } }
export function initTheme() { let m = 'light'; try { m = localStorage.getItem('aboThemeMode') || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'); } catch { /* */ } applyTheme(m); }

// UI preferences only (never data): which menu section is open, collapsed sidebar
const pref = { get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* */ } } };
const isPhone = () => matchMedia('(max-width: 900px)').matches;

export function schoolLogo(school, cls = 'brand-logo') {
  return school && school.logo_file_id ? h(`img.${cls}`, { src: fileUrl(school.logo_file_id), alt: `${school.name} logo` }) : h(`div.${cls === 'brand-logo' ? 'brand-mark' : cls + '-mark'}`, { text: school ? initials(school.name) : 'ABO', 'aria-hidden': 'true' });
}
// school accent colour (validated #rrggbb on the server) → CSS custom properties via the CSSOM (CSP-safe)
export function applyBrand(color) {
  const root = document.documentElement;
  if (color && /^#[0-9a-fA-F]{6}$/.test(color)) {
    const [r, g, b] = [1, 3, 5].map((i) => parseInt(color.slice(i, i + 2), 16));
    const lum = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
    const mix = (t) => '#' + [r, g, b].map((v) => Math.round(v + (255 - v) * t).toString(16).padStart(2, '0')).join('');
    const ui = lum < 0.35 ? mix(lum < 0.15 ? 0.55 : 0.35) : color;          // stays visible on the dark sidebar
    root.style.setProperty('--school', ui); root.style.setProperty('--school-raw', color); root.style.setProperty('--school-soft', ui + '26');
  } else { root.style.removeProperty('--school'); root.style.removeProperty('--school-raw'); root.style.removeProperty('--school-soft'); }
}

// ONE behaviour for every menu button (owner's request, 12 Oct 2026): the three-line button shows or hides the WHOLE
// menu — on a computer the page then uses the full width (remembered); on a phone it slides the menu in and out.
// There is no icon-only "small menu" any more.
export function toggleNav(force) {
  if (isPhone()) { const open = force === undefined ? !document.body.classList.contains('nav-open') : force; document.body.classList.toggle('nav-open', open); syncNavButtons(); return; }
  const hide = force === undefined ? !document.body.classList.contains('nav-hidden') : !force;
  document.body.classList.toggle('nav-hidden', hide); pref.set('aboNavHidden', hide); syncNavButtons();
}
function syncNavButtons() {
  const closed = isPhone() ? !document.body.classList.contains('nav-open') : document.body.classList.contains('nav-hidden');
  document.querySelectorAll('[data-nav-toggle]').forEach((b) => { b.setAttribute('aria-expanded', String(!closed)); b.setAttribute('aria-label', closed ? 'Show menu' : 'Hide menu'); b.title = b.getAttribute('aria-label'); });
}

function openSection(li, on, { remember = true } = {}) {
  const list = li.closest('.menu');
  if (on && list && !list.classList.contains('searching')) list.querySelectorAll('.menu-sec.open').forEach((x) => { if (x !== li) { x.classList.remove('open'); const hb = x.querySelector('.menu-head'); if (hb) hb.setAttribute('aria-expanded', 'false'); } });
  li.classList.toggle('open', on); const b = li.querySelector('.menu-head'); if (b) b.setAttribute('aria-expanded', String(on));
  if (remember) pref.set('aboNavOpen', on ? li.dataset.key : '');
}

function buildNav(me) {
  const openKey = pref.get('aboNavOpen', '');
  const list = h('ul.menu', { role: 'tree', 'aria-label': 'Main menu' });
  const badgeOf = (i) => (i.badge && me.unread && me.unread[i.badge] ? h('span.nav-badge', { text: me.unread[i.badge] }) : null);
  for (const cat of navCategories()) {
    list.appendChild(h('li.menu-cat', { role: 'presentation' }, h('span', { text: cat.label })));
    for (const s of cat.sections) {
      if (!s.items) {
        list.appendChild(h('li.menu-sec.menu-single', { role: 'none', dataset: { key: s.key } }, h('a.menu-link.nav-item', { href: s.href, role: 'treeitem', title: s.label, dataset: { href: s.href, full: s.full || '' } },
          h('span.menu-ic', icon(s.icon, 18)), h('span.menu-label', { text: s.label }), badgeOf(s))));
        continue;
      }
      const id = `menu-${s.key}`;
      const count = s.items.reduce((n, i) => n + (i.badge && me.unread && me.unread[i.badge] ? Number(me.unread[i.badge]) : 0), 0);
      const head = h('button.menu-head', { type: 'button', title: s.label, 'aria-expanded': s.key === openKey ? 'true' : 'false', 'aria-controls': id, dataset: { key: s.key, full: s.full || '' } },
        h('span.menu-ic', icon(s.icon, 18)), h('span.menu-label', { text: s.label }), count ? h('span.nav-badge', { text: count }) : null, h('span.menu-chev', icon('chevronDown', 14)));
      const sub = h('ul.submenu', { id, role: 'group' }, s.items.map((i) => h('li', { role: 'none' },
        h('a.sub-link.nav-item', { href: i.href, role: 'treeitem', dataset: { href: i.href, full: i.full || '' } }, h('span.menu-label', { text: i.label }), badgeOf(i)))));
      const li = h(`li.menu-sec${s.key === openKey ? '.open' : ''}`, { role: 'none', dataset: { key: s.key } }, head, sub);
      head.addEventListener('click', () => openSection(li, !li.classList.contains('open')));
      list.appendChild(li);
    }
  }
  // search: filter items and sections; matching sections open while searching
  const filter = h('input.nav-filter', { type: 'search', placeholder: 'Search menu', 'aria-label': 'Search menu', autocomplete: 'off' });
  const noMatch = h('li.menu-empty', { hidden: true, role: 'none' }, h('span', { text: 'No menu item matches.' }), h('button.link', { type: 'button', text: 'Clear search', on: { click: () => { filter.value = ''; filter.dispatchEvent(new Event('input')); filter.focus(); } } }));
  list.appendChild(noMatch);
  filter.addEventListener('input', () => {
    const q = filter.value.trim().toLowerCase();
    list.classList.toggle('searching', !!q);
    list.querySelectorAll('.menu-sec').forEach((sec) => {
      if (!q) { sec.hidden = false; sec.querySelectorAll('li').forEach((x) => { x.hidden = false; }); sec.classList.toggle('open', sec.dataset.key === pref.get('aboNavOpen', '') || sec.classList.contains('has-active')); return; }
      const secEl = sec.querySelector('.menu-head, .menu-link');
      const secLabel = ((sec.querySelector('.menu-label') || {}).textContent || '') + ' ' + ((secEl && secEl.dataset.full) || '');
      const secHit = secLabel.toLowerCase().includes(q); let any = false;
      sec.querySelectorAll('.submenu li').forEach((x) => { const a = x.querySelector('a'); const hit = secHit || (x.textContent + ' ' + ((a && a.dataset.full) || '')).toLowerCase().includes(q); x.hidden = !hit; any = any || hit; });
      sec.hidden = !(any || secHit); sec.classList.toggle('open', any);
    });
    list.querySelectorAll('.menu-cat').forEach((c) => { let n = c.nextElementSibling; let show = false; while (n && !n.classList.contains('menu-cat')) { if (n.classList.contains('menu-sec') && !n.hidden) show = true; n = n.nextElementSibling; } c.hidden = !!q && !show; });
    noMatch.hidden = !q || !!list.querySelector('.menu-sec:not([hidden])');
  });
  filter.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { const a = list.querySelector('.menu-sec:not([hidden]) .submenu li:not([hidden]) a, .menu-sec.menu-single:not([hidden]) a'); if (a) { location.hash = a.getAttribute('href'); filter.value = ''; filter.dispatchEvent(new Event('input')); filter.blur(); } }
    if (e.key === 'Escape') { filter.value = ''; filter.dispatchEvent(new Event('input')); }
  });
  return { filter, list };
}

export function buildShell() {
  const me = session.me; const ws = workspace(); const school = me.school;
  applyBrand(school && school.brand_color);
  document.body.classList.remove('nav-mini');
  if (!isPhone() && pref.get('aboNavHidden', false)) document.body.classList.add('nav-hidden');
  const { filter, list } = buildNav(me);
  const brand = h('div.sb-head',
    h('a.sb-brand', { href: can('settings.view') ? '#/school/profile' : '#/', title: school ? school.name : 'A.B.O. School Manager' }, schoolLogo(school),
      h('div.sb-brand-text', h('strong', { text: school ? school.name : 'A.B.O. School Manager' }), h('span', { text: `School Manager · ${me.branch ? me.branch.name : WS_LABEL[ws]}` }))),
    h('button.sb-close.icon-btn', { type: 'button', 'aria-label': 'Close menu', title: 'Close menu', on: { click: () => toggleNav(false) } }, icon('x', 18)));   // phone only
  const search = h('label.nav-search', icon('search', 15), filter);
  const foot = navFooter();
  const sidebar = h('aside.sidebar', { id: 'sidebar' }, brand, search, h('nav.nav', { 'aria-label': 'Main' }, list),
    h('div.sidebar-foot', foot.length ? h('ul.foot-links', foot.map((f) => h('li', h('a.foot-link.nav-item', { href: f.href, title: f.label, dataset: { href: f.href } }, h('span.menu-ic', icon(f.icon, 16)), h('span.menu-label', { text: f.label }))))) : null,
      h('div.foot-term', icon('calendar', 14), h('span.menu-label', { text: school && school.current_term ? `${school.current_term.session} · ${tn(school.current_term.name)} term` : 'No current term' }))));
  // phone: any menu link closes the drawer — including the page you are already on (no hash change → no re-render)
  sidebar.addEventListener('click', (e) => { if (isPhone() && e.target.closest('a.nav-item, a.sb-brand')) toggleNav(false); });
  const bellCount = h('span.bell-count', { text: me.unread.notifications || '', hidden: !me.unread.notifications });
  const panel = h('div.popover', { hidden: true, role: 'dialog', 'aria-label': 'Notifications' });
  const bell = h('button.icon-btn.bell', { 'aria-label': 'Notifications', title: 'Notifications', on: { click: () => toggleNotifications(panel, bellCount) } }, icon('bell'), bellCount);
  const theme = h('button.icon-btn', { 'aria-label': 'Toggle dark mode', title: 'Light / dark', on: { click: () => applyTheme(document.body.dataset.mode === 'dark' ? 'light' : 'dark') } }, icon('moon'));
  const userMenu = h('div.popover.user-pop', { hidden: true },
    h('div.user-pop-head', h('strong', { text: me.user.fullName }), h('span.muted', { text: me.user.loginId }), h('span.muted', { text: me.roles.map((r) => r.name).join(', ') })),
    h('a.pop-item', { href: '#/account' }, icon('user', 16), h('span', { text: 'My account & security' })),
    h('a.pop-item', { href: '#/notifications' }, icon('bell', 16), h('span', { text: 'Notifications' })),
    h('a.pop-item', { href: '#/help' }, icon('help', 16), h('span', { text: 'Help & support' })),
    installItem(), layoutItem(),
    h('label.pop-item.pop-check', { title: 'Simple words are easier to read; full terms are the usual office words.' },
      h('input', { type: 'checkbox', checked: !isSimple(), 'aria-label': 'Show full terms', on: { change: (e) => { setSimple(!e.target.checked); location.reload(); } } }), h('span', { text: 'Show full terms' })),
    ...(me.memberships || []).filter((m) => m.status === 'active' && !m.current).map((m) => h('button.pop-item', { on: { click: async () => { try { await api.post('/auth/switch-school', { schoolId: m.schoolId }); location.hash = '#/'; location.reload(); } catch (e) { fail(e); } } } }, icon('building', 16), h('span', { text: `Switch to ${m.schoolName}` }))),
    h('button.pop-item', { on: { click: logout } }, icon('logout', 16), h('span', { text: 'Sign out' })));
  const chip = h('button.user-chip', { 'aria-haspopup': 'true', on: { click: () => { userMenu.hidden = !userMenu.hidden; panel.hidden = true; } } }, h('span.avatar', { text: initials(me.user.fullName) }), h('span.user-name', { text: me.user.fullName.split(' ').slice(0, 2).join(' ') }), icon('chevronDown', 14));
  const topSearch = can('students.view') ? h('label.top-search', icon('search', 15), h('input', { type: 'search', placeholder: 'Search students', 'aria-label': 'Search students', on: { keydown: (e) => { if (e.key === 'Enter' && e.target.value.trim()) location.hash = `#/students?q=${encodeURIComponent(e.target.value.trim())}`; } } }), h('kbd', { text: 'Ctrl K' })) : h('div.spacer');
  const menuBtn = h('button.icon-btn.menu-btn', { type: 'button', 'aria-controls': 'sidebar', dataset: { navToggle: '' }, on: { click: () => toggleNav() } }, icon('menu'));
  const title = h('div.top-title', { id: 'topTitle' });
  const topbar = h('header.topbar', menuBtn, title, topSearch, h('div.top-actions', bell, theme, h('div.pop-wrap', chip, userMenu), panel));
  // "sign in as": a banner the owner cannot miss, with the time left and the way back
  const acting = me.actingAs ? (() => {
    const left = h('strong');
    const tick = () => { const ms = new Date(me.actingAs.expiresAt).getTime() - Date.now(); if (ms <= 0) { location.reload(); return; } left.textContent = `${Math.floor(ms / 60000)}:${String(Math.floor(ms / 1000) % 60).padStart(2, '0')}`; };
    tick(); const t = setInterval(() => { if (!document.body.contains(left)) clearInterval(t); else tick(); }, 1000);
    return h('div.support-banner.acting-banner', { role: 'status' }, icon('user', 16),
      h('span', `You are using the app as ${me.user.fullName}. Everything you do is recorded under your own name (${me.actingAs.byName}). Time left: `, left),
      h('button.btn.btn-sm', { text: 'Back to my account', on: { click: async () => { try { await api.post('/auth/act-as/stop', {}); } catch { /* the session decides */ } location.hash = '#/'; location.reload(); } } }));
  })() : null;
  // demo: a clear DEMO label and the time left. The SERVER ends the session at expiresAt; this is only the display.
  const demoBar = me.demo ? (() => {
    const offset = Date.now() - new Date(me.demo.serverNow || Date.now()).getTime();
    const end = new Date(me.demo.expiresAt).getTime() + offset;
    const left = h('strong.demo-left'); let warned = false;
    const bar = h('div.support-banner.demo-banner', { role: 'status' }, h('span.demo-pill', { text: 'DEMO' }),
      h('span', `${school ? school.name : 'Demo school'} — sample data for trying the app. Changes are wiped when the demo ends. Time left: `, left),
      h('a.btn.btn-sm', { href: '#/register', text: 'Register your school' }),
      h('button.btn.btn-sm', { type: 'button', text: 'End demo', on: { click: () => endDemo() } }));
    async function endDemo() { try { sessionStorage.setItem('abo.demoEnded', '1'); } catch { /* */ } try { await api.post('/auth/logout'); } catch { /* already over */ } location.hash = '#/login'; location.reload(); }
    const tick = () => {
      const ms = end - Date.now();
      if (ms <= 0) { clearInterval(t); endDemo(); return; }
      left.textContent = `${Math.floor(ms / 60000)}:${String(Math.floor(ms / 1000) % 60).padStart(2, '0')}`;
      if (ms <= 60000 && !warned) { warned = true; bar.classList.add('ending'); toast('Your demo ends in 1 minute. Anything you changed will be wiped.', 'err', 6000); }
    };
    tick(); const t = setInterval(() => { if (!document.body.contains(left)) clearInterval(t); else tick(); }, 1000);
    return bar;
  })() : null;
  const banner = demoBar || acting || (me.support ? h('div.support-banner', icon('shield', 16), h('span', { text: `Read-only support view of ${school ? school.name : 'school'} — every action is audited.` }),
    h('button.btn.btn-sm', { text: 'End support view', on: { click: async () => { await api.del('/platform/support'); location.hash = '#/'; location.reload(); } } })) : null);
  const view = h('main.view', { id: 'view', tabindex: '-1' });
  // phone bottom bar: first link of the first four sections + Menu
  const quick = navTree().slice(0, 4).map((s) => ({ href: s.href || s.items[0].href, label: s.label.replace(/^My\s+/, '').split(/[ &/]/)[0], icon: s.icon }));
  const bottom = h('nav.bottom-nav', { 'aria-label': 'Quick' }, quick.map((i) => h('a.bn-item', { href: i.href, dataset: { href: i.href } }, icon(i.icon, 20), h('span', { text: i.label }))),
    h('button.bn-item', { type: 'button', 'aria-controls': 'sidebar', on: { click: () => toggleNav(true) } }, icon('menu', 20), h('span', { text: 'Menu' })));
  const root = h(`div.app.ws-${ws}`, sidebar, h('div.scrim', { on: { click: () => toggleNav(false) } }), h('div.main', topbar, banner, view), bottom);
  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { const s = $('.top-search input'); if (s) { e.preventDefault(); s.focus(); } }
    if ((e.ctrlKey || e.metaKey) && e.key === '/') { e.preventDefault(); if (isPhone()) toggleNav(true); else if (document.body.classList.contains('nav-hidden')) toggleNav(true); filter.focus(); }
    if (e.key === 'Escape' && document.body.classList.contains('nav-open')) toggleNav(false);
  });
  document.addEventListener('click', (e) => { if (!e.target.closest('.pop-wrap,.popover,.bell')) { userMenu.hidden = true; panel.hidden = true; } });
  matchMedia('(max-width: 900px)').addEventListener('change', () => { document.body.classList.remove('nav-open'); syncNavButtons(); });
  setTimeout(syncNavButtons, 0);
  return { root, view };
}

// "Install app" in the account menu (hidden once the app runs installed)
function installItem() {
  const b = h('button.pop-item.install-item', { type: 'button', on: { click: () => installApp().catch(() => {}) } }, icon('download', 16), h('span', { text: 'Install app on this device' }));
  const sync = () => { b.hidden = installed(); }; sync(); onInstallChange(sync); return b;
}
// screen layout on this device: Automatic / Computer layout / Phone layout (remembered; see assets/js/layout.js)
function layoutItem() {
  const L = window.aboLayout; if (!L) return null;
  const small = (screen.width || 9999) < 1100 || L.isTouch();
  if (!small && L.get() === 'auto') return null;                                     // big screen with a mouse: nothing to choose
  const label = h('span'); const b = h('button.pop-item.layout-item', { type: 'button' }, icon('panel', 16), label);
  const sync = () => { const m = L.get(); label.textContent = m === 'desktop' ? 'Screen: computer layout (tap for phone)' : m === 'phone' ? 'Screen: phone layout (tap for automatic)' : `Screen: automatic${L.effective() === 'desktop' ? ' (computer)' : ''} — tap for computer layout`; };
  b.addEventListener('click', () => { const m = L.get(); L.set(m === 'auto' ? 'desktop' : m === 'desktop' ? 'phone' : 'auto'); sync(); toast(L.get() === 'desktop' ? 'Computer layout on. It stays on for this device until you change it.' : L.get() === 'phone' ? 'Phone layout on for this device.' : 'Automatic layout: phone on phones, computer on computers.'); });
  sync(); return b;
}

export function setActive(hash, label) {
  const entry = activeEntry(hash || '#/');
  document.querySelectorAll('.nav-item').forEach((a) => {
    const on = !!entry && a.dataset.href === entry.href;
    a.classList.toggle('active', on); if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
  });
  document.querySelectorAll('.menu-sec').forEach((sec) => {
    const has = !!sec.querySelector('.nav-item.active'); sec.classList.toggle('has-active', has);
    if (has && !sec.classList.contains('open') && !sec.classList.contains('menu-single')) openSection(sec, true);
  });
  document.querySelectorAll('.bn-item[data-href]').forEach((a) => a.classList.toggle('active', !!entry && entry.section && (entry.section.href || (entry.section.items && entry.section.items[0].href)) === a.dataset.href));
  const t = document.getElementById('topTitle'); label = word(label);
  if (t) {
    clear(t);
    if (entry && entry.section && entry.section.items) t.append(h('span.crumb', { text: entry.section.label }), h('span.crumb-sep', icon('chevron', 14)), h('strong', { text: label || entry.label }));
    else t.appendChild(h('strong', { text: label || '' }));
  }
  const act = document.querySelector('.sidebar .nav-item.active'); const navEl = document.querySelector('.sidebar .nav');
  if (act && navEl) { const a = act.getBoundingClientRect(); const n = navEl.getBoundingClientRect(); if (a.top < n.top || a.bottom > n.bottom) navEl.scrollTop += a.top - n.top - n.height / 3; }
  if (document.body.classList.contains('nav-open')) toggleNav(false);
}
async function toggleNotifications(panel, count) {
  panel.hidden = !panel.hidden; if (panel.hidden) return;
  clear(panel).appendChild(h('div.muted.pad', { text: 'Loading…' }));
  try {
    const d = await api.get('/notifications');
    clear(panel).append(h('div.pop-head', h('strong', { text: 'Notifications' }), h('button.link', { text: 'Mark all read', on: { click: async () => { await api.post('/notifications/read', { all: true }); count.hidden = true; panel.hidden = true; } } })));
    if (!d.items.length) panel.appendChild(h('div.muted.pad', { text: 'You are all caught up.' }));
    for (const n of d.items.slice(0, 20)) panel.appendChild(h(`a.notif${n.read_at ? '' : '.unread'}`, { href: n.link || '#/', on: { click: () => { api.post('/notifications/read', { ids: [n.id] }).catch(() => {}); panel.hidden = true; } } },
      h('strong', { text: n.title }), n.body ? h('span', { text: n.body }) : null, h('small.muted', { text: ago(n.created_at) })));
    panel.appendChild(h('a.pop-item.center', { href: '#/notifications', on: { click: () => { panel.hidden = true; } } }, h('span', { text: 'See all notifications' })));
  } catch (e) { fail(e); panel.hidden = true; }
}
export async function logout() {
  try { await api.post('/auth/logout'); } catch { /* already gone */ }
  try { (await import('./offline.js')).offlineSignedOut(); } catch { /* optional */ }
  toast('Signed out'); location.hash = session.me && session.me.school ? `#/s/${session.me.school.slug}` : '#/login'; location.reload();
}
