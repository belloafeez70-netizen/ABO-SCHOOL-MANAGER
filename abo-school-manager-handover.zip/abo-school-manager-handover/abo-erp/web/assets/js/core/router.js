const routes = [];
export function route(pattern, loader, opts = {}) {
  const keys = []; const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/?]+)'; }) + '/?$');
  routes.push({ pattern, re, keys, loader, ...opts });
}
export function match(hash) {
  const [path, query] = (hash.replace(/^#/, '') || '/').split('?');
  for (const r of routes) { const m = r.re.exec(path); if (m) { const params = {}; r.keys.forEach((k, i) => { params[k] = decodeURIComponent(m[i + 1]); }); return { r, params, query: Object.fromEntries(new URLSearchParams(query || '')) }; } }
  return null;
}
export const go = (h) => { if (location.hash === h) window.dispatchEvent(new HashChangeEvent('hashchange')); else location.hash = h; };
