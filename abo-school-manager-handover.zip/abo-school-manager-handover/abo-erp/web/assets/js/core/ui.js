// UI primitives: toasts, modals, confirm, forms, server-paginated tables, badges, states.
import { h, clear, icon } from './dom.js';
import { word } from './words.js';
import { ApiError } from './api.js';

// ── toasts (aria-live) ──
let toastHost;
export function toast(msg, kind = 'ok', ms = 3800) {
  if (!toastHost) { toastHost = h('div.toasts', { role: 'status', 'aria-live': 'polite' }); document.body.appendChild(toastHost); }
  const t = h(`div.toast.toast-${kind}`, h('span', { text: msg }), h('button.toast-x', { 'aria-label': 'Dismiss', on: { click: () => t.remove() } }, icon('x', 14)));
  toastHost.appendChild(t); setTimeout(() => t.classList.add('out'), ms); setTimeout(() => t.remove(), ms + 400);
}
export const errMsg = (e) => (e instanceof ApiError ? e.message : 'Something went wrong. Please try again.');
export const fail = (e) => toast(errMsg(e), 'err', 6000);

// ── modal with focus trap + Esc ──
export function modal({ title, body, actions = [], wide = false, onClose }) {
  const prev = document.activeElement;
  const close = () => { back.remove(); document.removeEventListener('keydown', key); if (prev && prev.focus) prev.focus(); onClose && onClose(); };
  const key = (e) => {
    if (e.key === 'Escape') close();
    if (e.key === 'Tab') { const f = [...dlg.querySelectorAll('button,input,select,textarea,a[href],[tabindex="0"]')].filter((x) => !x.disabled); if (!f.length) return;
      if (e.shiftKey && document.activeElement === f[0]) { e.preventDefault(); f[f.length - 1].focus(); } else if (!e.shiftKey && document.activeElement === f[f.length - 1]) { e.preventDefault(); f[0].focus(); } }
  };
  const dlg = h(`div.modal${wide ? '.modal-wide' : ''}`, { role: 'dialog', 'aria-modal': 'true', 'aria-label': title },
    h('div.modal-head', h('h2', { text: title }), h('button.icon-btn', { 'aria-label': 'Close', on: { click: close } }, icon('x'))),
    h('div.modal-body', body), actions.length ? h('div.modal-foot', actions) : null);
  const back = h('div.modal-back', { on: { mousedown: (e) => { if (e.target === back) close(); } } }, dlg);
  document.body.appendChild(back); document.addEventListener('keydown', key);
  setTimeout(() => { const f = dlg.querySelector('input,select,textarea,button.btn-primary'); if (f) f.focus(); }, 30);
  return { close, el: dlg };
}
export function confirmDialog({ title = 'Are you sure?', message, confirmLabel = 'Confirm', danger = false, reason = false }) {
  return new Promise((resolve) => {
    const ta = reason ? h('textarea.input', { rows: 3, placeholder: 'Reason (required, kept in the audit log)', 'aria-label': 'Reason' }) : null;
    let done = false;
    const m = modal({ title, body: [h('p.muted', { text: message }), ta], onClose: () => { if (!done) resolve(null); },
      actions: [h('button.btn', { text: 'Cancel', on: { click: () => m.close() } }),
        h(`button.btn.${danger ? 'btn-danger' : 'btn-primary'}`, { text: confirmLabel, on: { click: () => { if (reason && ta.value.trim().length < 3) { ta.classList.add('invalid'); ta.focus(); return; } done = true; m.close(); resolve(reason ? ta.value.trim() : true); } } })] });
  });
}

// ── forms ──
export function field(f, value) {
  const id = 'f_' + f.name + '_' + Math.random().toString(36).slice(2, 7);
  let input;
  const common = { id, name: f.name, required: !!f.required, disabled: !!f.disabled, 'aria-describedby': id + '_err' };
  if (f.type === 'select') {
    input = h('select.input', common, f.placeholder !== false ? h('option', { value: '', text: f.placeholder || 'Select…' }) : null,
      (f.options || []).map((o) => h('option', { value: o.value ?? o, text: o.label ?? o, selected: String(o.value ?? o) === String(value ?? '') })));
  } else if (f.type === 'multiselect') {
    input = h('div.checks', { id }, (f.options || []).map((o) => h('label.check', h('input', { type: 'checkbox', value: o.value, checked: (value || []).includes(o.value) }), h('span', { text: o.label }))));
  } else if (f.type === 'textarea') input = h('textarea.input', { ...common, rows: f.rows || 4, maxlength: f.max || 8000, text: value ?? '' });
  else if (f.type === 'checkbox') input = h('input', { ...common, type: 'checkbox', checked: !!value });
  else if (f.type === 'file') input = h('input.input', { ...common, type: 'file', accept: f.accept || '' });
  else input = h('input.input', { ...common, type: f.type || 'text', value: value ?? '', placeholder: f.placeholder || '', autocomplete: f.autocomplete || 'off', min: f.min, max: f.maxv, step: f.step, maxlength: f.max, pattern: f.pattern, inputmode: f.inputmode });
  const wrap = h(`div.field${f.type === 'checkbox' ? '.field-inline' : ''}${f.full ? '.field-full' : ''}`, { dataset: { name: f.name } },
    h('label', { for: id }, f.label, f.required ? h('span.req', { text: ' *', 'aria-hidden': 'true' }) : null), input,
    f.hint ? h('small.hint', { text: f.hint }) : null, h('small.err', { id: id + '_err', role: 'alert' }));
  wrap._get = () => {
    if (f.type === 'checkbox') return input.checked;
    if (f.type === 'multiselect') return [...input.querySelectorAll('input:checked')].map((x) => x.value);
    if (f.type === 'file') return input.files[0] || null;
    const v = input.value.trim();
    if (f.type === 'number') return v === '' ? null : Number(v);
    return v === '' ? (f.emptyAs !== undefined ? f.emptyAs : null) : v;
  };
  return wrap;
}
export function form(fields, values = {}) {
  const wraps = fields.map((f) => (f.section ? h('h3.form-section', { text: f.section }) : field(f, values[f.name])));
  const el = h('div.form-grid', wraps);
  el._values = () => { const o = {}; for (const w of wraps) if (w._get) { const v = w._get(); const f = fields.find((x) => x.name === w.dataset.name); if (!(f.omitEmpty && (v === null || v === ''))) o[w.dataset.name] = v; } return o; };
  el._error = (e) => {
    el.querySelectorAll('.field').forEach((w) => { w.classList.remove('has-err'); w.querySelector('.err').textContent = ''; });
    const f = e && e.details && e.details.field && el.querySelector(`.field[data-name="${e.details.field.split('.')[0]}"]`);
    if (f) { f.classList.add('has-err'); f.querySelector('.err').textContent = e.message; const i = f.querySelector('input,select,textarea'); if (i) i.focus(); return true; }
    return false;
  };
  return el;
}
export function formDialog({ title, fields, values, submitLabel = 'Save', onSubmit, wide, intro }) {
  return new Promise((resolve) => {
    const f = form(fields, values || {});
    const banner = h('div.form-alert', { role: 'alert', hidden: true });
    const btn = h('button.btn.btn-primary', { text: submitLabel, type: 'submit' });
    let ok = false;
    const submit = async (ev) => {
      if (ev) ev.preventDefault();
      banner.hidden = true; btn.disabled = true; btn.classList.add('loading');
      try { const r = await onSubmit(f._values()); ok = true; m.close(); resolve(r ?? true); }
      catch (e) { if (!f._error(e)) { banner.textContent = errMsg(e); banner.hidden = false; } }
      finally { btn.disabled = false; btn.classList.remove('loading'); }
    };
    const frm = h('form', { on: { submit }, novalidate: true }, intro ? h('p.muted', { text: intro }) : null, banner, f);
    const m = modal({ title, wide, body: frm, onClose: () => { if (!ok) resolve(null); }, actions: [h('button.btn', { text: 'Cancel', type: 'button', on: { click: () => m.close() } }), h('button.btn.btn-primary', { text: submitLabel, on: { click: submit } })] });
    void btn;
  });
}

// ── states & atoms ──
export const spinner = (label = 'Loading…') => h('div.state', { role: 'status' }, h('div.spin'), h('span', { text: label }));
export const empty = (title, hint, action) => h('div.state.state-empty', icon('layers', 28), h('strong', { text: title }), hint ? h('span.muted', { text: hint }) : null, action || null);
export const errorState = (e, retry) => (e && e.status === 403
  ? h('div.state.state-err.state-denied', icon('shield', 28), h('strong', { text: 'You don’t have access to this page' }), h('span.muted', { text: errMsg(e) }), h('a.btn', { href: '#/', text: 'Go to dashboard' }))
  : h('div.state.state-err', icon('shield', 28), h('strong', { text: 'Could not load this page' }), h('span.muted', { text: errMsg(e) }), retry ? h('button.btn', { text: 'Try again', on: { click: retry } }) : null));
const TONE = { active: 'ok', paid: 'ok', published: 'ok', approved: 'ok', graded: 'ok', confirmed: 'ok', present: 'ok', clean: 'ok', done: 'ok', verified: 'ok', Pass: 'ok',
  draft: 'muted', not_started: 'muted', pending: 'warn', submitted: 'info', partial: 'warn', in_progress: 'info', late: 'warn', excused: 'info', queued: 'info', running: 'info', important: 'warn',
  unpaid: 'danger', void: 'muted', reversed: 'danger', failed: 'danger', absent: 'danger', disabled: 'danger', suspended: 'danger', urgent: 'danger', rejected: 'danger', Fail: 'danger', auto_submitted: 'warn', returned: 'warn', closed: 'muted', high: 'danger', critical: 'danger', medium: 'warn', low: 'info', info: 'muted' };
export const badge = (v, tone) => h(`span.badge.badge-${tone || TONE[v] || 'muted'}`, { text: String(v ?? '—').replace(/_/g, ' ') });
export const stat = (label, value, sub, ic, tone = '') => h(`div.stat${tone ? '.stat-' + tone : ''}`, h('div.stat-ic', icon(ic || 'chart', 20)), h('div', h('div.stat-label', { text: label }), h('div.stat-value', { text: value }), sub ? h('div.stat-sub', { text: sub }) : null));
export function pageHead(title, sub, ...actions) { return h('header.page-head', h('div', h('h1', { text: word(title) }), sub ? h('p.muted', { text: sub }) : null), h('div.page-actions', actions)); }
export const btn = (label, onClick, { kind = '', ic, disabled, title } = {}) => h(`button.btn${kind ? '.btn-' + kind : ''}`, { type: 'button', disabled, title, on: { click: onClick } }, ic ? icon(ic, 16) : null, label ? h('span', { text: label }) : null);
export function card(title, body, ...actions) { return h('section.card', title ? h('div.card-head', h('h2', { text: title }), h('div.card-actions', actions)) : null, h('div.card-body', body)); }
export function tabs(items, onChange, active) {
  const bar = h('div.tabs', { role: 'tablist' });
  items.forEach((t) => bar.appendChild(h(`button.tab${t.key === active ? '.active' : ''}`, { role: 'tab', 'aria-selected': t.key === active ? 'true' : 'false', text: t.label, on: { click: () => { bar.querySelectorAll('.tab').forEach((x) => { x.classList.remove('active'); x.setAttribute('aria-selected', 'false'); }); const b = [...bar.children].find((x) => x.textContent === t.label); b.classList.add('active'); b.setAttribute('aria-selected', 'true'); onChange(t.key); } } })));
  return bar;
}
export function bars(items, { max, fmt = (v) => v } = {}) {
  const m = max || Math.max(1, ...items.map((i) => Number(i.value) || 0));
  return h('div.bars', items.map((i) => { const fill = h('div.bar-fill'); fill.style.width = `${Math.round((Number(i.value) || 0) / m * 100)}%`;
    return h('div.bar-row', h('span.bar-label', { text: i.label }), h('div.bar-track', fill), h('span.bar-val', { text: fmt(i.value) })); }));
}

// ── server-paginated data table (search debounce, mobile card layout via CSS) ──
export function dataTable({ columns, load, filters = [], empty: emptyText = 'Nothing here yet', emptyHint, rowClick, pageSize = 25, toolbar = [] }) {
  const state = { page: 1, q: '', f: {} };
  const tbody = h('tbody'); const info = h('span.muted'); const pager = h('div.pager');
  const search = h('input.input.search', { type: 'search', placeholder: 'Search…', 'aria-label': 'Search' });
  let timer;
  search.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(() => { state.q = search.value.trim(); state.page = 1; refresh(); }, 280); });
  const filterEls = filters.map((f) => { const s = field({ ...f, type: 'select' }); s.classList.add('filter'); s.querySelector('select').addEventListener('change', (e) => { state.f[f.name] = e.target.value; state.page = 1; refresh(); }); return s; });
  const table = h('table.table', h('thead', h('tr', columns.map((c) => h('th', { text: c.label, class: c.cls || '', scope: 'col' })))), tbody);
  const wrap = h('div.dt', h('div.dt-bar', search, filterEls, h('div.spacer'), toolbar), h('div.table-wrap', table), h('div.dt-foot', info, pager));
  async function refresh() {
    clear(tbody).appendChild(h('tr', h('td', { colspan: columns.length }, spinner())));
    try {
      const d = await load({ page: state.page, pageSize, q: state.q || undefined, ...state.f });
      clear(tbody);
      const items = d.items || [];
      if (!items.length) tbody.appendChild(h('tr', h('td', { colspan: columns.length }, empty(emptyText, emptyHint))));
      for (const r of items) {
        const tr = h('tr', columns.map((c) => { const v = c.render ? c.render(r) : r[c.key]; return h('td', { class: c.cls || '', dataset: { label: c.label } }, v instanceof Node ? v : String(v ?? '—')); }));
        if (rowClick) { tr.classList.add('clickable'); tr.tabIndex = 0; tr.addEventListener('click', (e) => { if (!e.target.closest('button,a,input')) rowClick(r); }); tr.addEventListener('keydown', (e) => { if (e.key === 'Enter') rowClick(r); }); }
        tbody.appendChild(tr);
      }
      const total = d.total ?? items.length; const pages = d.pages || 1;
      info.textContent = total ? `${(state.page - 1) * pageSize + 1}–${Math.min(total, state.page * pageSize)} of ${total}` : '';
      clear(pager).append(btn('Prev', () => { state.page--; refresh(); }, { disabled: state.page <= 1 }), h('span.muted', { text: `Page ${state.page} / ${pages}` }), btn('Next', () => { state.page++; refresh(); }, { disabled: state.page >= pages }));
    } catch (e) { clear(tbody).appendChild(h('tr', h('td', { colspan: columns.length }, errorState(e, refresh)))); }
  }
  wrap.refresh = refresh; refresh();
  return wrap;
}
// simple (non-paginated) table
export function simpleTable(columns, rows, emptyText = 'Nothing to show') {
  if (!rows.length) return empty(emptyText);
  return h('div.table-wrap', h('table.table', h('thead', h('tr', columns.map((c) => h('th', { text: c.label, class: c.cls || '' })))),
    h('tbody', rows.map((r) => h('tr', columns.map((c) => { const v = c.render ? c.render(r) : r[c.key]; return h('td', { class: c.cls || '', dataset: { label: c.label } }, v instanceof Node ? v : String(v ?? '—')); }))))));
}
