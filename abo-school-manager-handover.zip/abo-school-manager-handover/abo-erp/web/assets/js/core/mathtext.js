// Lightweight, XSS-safe maths/rich-text renderer for CBT questions. Builds DOM nodes only (never innerHTML).
// Supported (LaTeX-like, typed by teachers):
//   x^{2} or x^2 (superscript)   H_{2}O or a_1 (subscript)   \frac{a}{b}   \sqrt{x}   \sqrt[3]{x}
//   \times \div \pm \le \ge \ne \approx \pi \theta \alpha \beta \gamma \Delta \degree \infty \angle \therefore \cdot
//   lines starting with | are table rows:  | x | 1 | 2 |
//   **bold**   blank line = new paragraph
const SYM = { times: '×', div: '÷', pm: '±', mp: '∓', le: '≤', leq: '≤', ge: '≥', geq: '≥', ne: '≠', neq: '≠', approx: '≈', pi: 'π', theta: 'θ', alpha: 'α', beta: 'β',
  gamma: 'γ', delta: 'δ', Delta: 'Δ', lambda: 'λ', mu: 'μ', sigma: 'σ', Sigma: 'Σ', omega: 'ω', Omega: 'Ω', phi: 'φ', degree: '°', deg: '°', infty: '∞', angle: '∠',
  therefore: '∴', because: '∵', cdot: '·', rightarrow: '→', to: '→', leftarrow: '←', Rightarrow: '⇒', in: '∈', notin: '∉', subset: '⊂', cup: '∪', cap: '∩', emptyset: '∅',
  sum: '∑', int: '∫', parallel: '∥', perp: '⊥', triangle: '△', percent: '%', ldots: '…', sqrt: '√' };
const el = (tag, cls) => { const e = document.createElement(tag); if (cls) e.className = cls; return e; };

// parse a {group} starting at s[i] === '{' → [content, nextIndex]
function group(s, i) {
  if (s[i] !== '{') { return s[i] === undefined ? ['', i] : [s[i], i + 1]; }
  let depth = 0;
  for (let j = i; j < s.length; j++) {
    if (s[j] === '{') depth++;
    else if (s[j] === '}') { depth--; if (depth === 0) return [s.slice(i + 1, j), j + 1]; }
  }
  return [s.slice(i + 1), s.length];
}
function inline(s, out) {
  let buf = '';
  const flush = () => { if (buf) { out.appendChild(document.createTextNode(buf)); buf = ''; } };
  for (let i = 0; i < s.length;) {
    const ch = s[i];
    if (ch === '*' && s[i + 1] === '*') { const end = s.indexOf('**', i + 2); if (end > i + 2) { flush(); const b = el('strong'); inline(s.slice(i + 2, end), b); out.appendChild(b); i = end + 2; continue; } }
    if ((ch === '^' || ch === '_') && i + 1 < s.length) {
      flush(); const [g, n] = group(s, i + 1); const t = el(ch === '^' ? 'sup' : 'sub'); inline(g, t); out.appendChild(t); i = n; continue;
    }
    if (ch === '\\') {
      const m = /^\\([A-Za-z]+)/.exec(s.slice(i));
      if (m) {
        const cmd = m[1]; let j = i + m[0].length;
        if (cmd === 'frac') {
          flush(); const [a, n1] = group(s, j); const [b, n2] = group(s, n1);
          const f = el('span', 'mt-frac'); const num = el('span', 'mt-num'); const den = el('span', 'mt-den'); inline(a, num); inline(b, den); f.append(num, den); out.appendChild(f); i = n2; continue;
        }
        if (cmd === 'sqrt') {
          flush(); let idx = '';
          if (s[j] === '[') { const e = s.indexOf(']', j); if (e > j) { idx = s.slice(j + 1, e); j = e + 1; } }
          const [a, n] = group(s, j); const r = el('span', 'mt-root');
          if (idx) { const k = el('sup', 'mt-idx'); k.textContent = idx; r.appendChild(k); }
          const sign = el('span', 'mt-radic'); sign.textContent = '√'; const body = el('span', 'mt-rad'); inline(a, body); r.append(sign, body); out.appendChild(r); i = n; continue;
        }
        if (SYM[cmd]) { buf += SYM[cmd]; i = j; continue; }
      }
      if (s[i + 1] === '\\') { flush(); out.appendChild(el('br')); i += 2; continue; }
    }
    buf += ch; i++;
  }
  flush();
}
export function renderRich(text, { block = true } = {}) {
  const root = el(block ? 'div' : 'span', 'mtx');
  const lines = String(text ?? '').replace(/\r\n?/g, '\n').split('\n');
  let para = null; let table = null;
  const endTable = () => { table = null; };
  for (const line of lines) {
    if (/^\s*\|.*\|\s*$/.test(line)) {
      if (/^\s*\|[\s:|-]+\|\s*$/.test(line)) continue;          // markdown separator row
      para = null;
      if (!table) { table = el('table', 'mt-table'); root.appendChild(table); }
      const tr = el('tr'); table.appendChild(tr);
      for (const cell of line.trim().slice(1, -1).split('|')) { const td = el(table.rows.length === 1 ? 'th' : 'td'); inline(cell.trim(), td); tr.appendChild(td); }
      continue;
    }
    endTable();
    if (!line.trim()) { para = null; continue; }
    if (!block) { if (root.childNodes.length) root.appendChild(document.createTextNode(' ')); inline(line, root); continue; }
    if (!para) { para = el('p'); root.appendChild(para); } else para.appendChild(el('br'));
    inline(line, para);
  }
  return root;
}
// plain-text preview (for tables of questions): strips markup
export const plain = (text, max = 140) => {
  const t = String(text ?? '').replace(/\\frac\{([^}]*)\}\{([^}]*)\}/g, '$1/$2').replace(/\\sqrt\{([^}]*)\}/g, '√$1').replace(/\\([A-Za-z]+)/g, (m, c) => SYM[c] || m)
    .replace(/\^\{([^}]*)\}/g, '^$1').replace(/_\{([^}]*)\}/g, '_$1').replace(/\*\*/g, '').replace(/\s+/g, ' ').trim();
  return t.length > max ? t.slice(0, max - 1) + '…' : t;
};
export const MATH_TOOLS = [['x²', '^{2}'], ['xₙ', '_{n}'], ['a/b', '\\frac{a}{b}'], ['√', '\\sqrt{x}'], ['∛', '\\sqrt[3]{x}'], ['×', '\\times '], ['÷', '\\div '], ['±', '\\pm '],
  ['≤', '\\le '], ['≥', '\\ge '], ['≠', '\\ne '], ['π', '\\pi '], ['θ', '\\theta '], ['°', '\\degree'], ['∠', '\\angle '], ['∴', '\\therefore '], ['Table', '\n| x | 1 | 2 |\n| y | 3 | 5 |\n']];
