// Code 128 (set B) barcode as an SVG, drawn with createElementNS (no innerHTML, CSP-safe). Gate scanners and phone
// scanner apps read it as plain text (the admission or staff number). The checksum follows the Code 128 standard.
export const PATTERNS = ['212222', '222122', '222221', '121223', '121322', '131222', '122213', '122312', '132212', '221213', '221312', '231212', '112232', '122132', '122231', '113222',
  '123122', '123221', '223211', '221132', '221231', '213212', '223112', '312131', '311222', '321122', '321221', '312212', '322112', '322211', '212123', '212321', '232121', '111323',
  '131123', '131321', '112313', '132113', '132311', '211313', '231113', '231311', '112133', '112331', '132131', '113123', '113321', '133121', '313121', '211331', '231131', '213113',
  '213311', '213131', '311123', '311321', '331121', '312113', '312311', '332111', '314111', '221411', '431111', '111224', '111422', '121124', '121421', '141122', '141221', '112214',
  '112412', '122114', '122411', '142112', '142211', '241211', '221114', '413111', '241112', '134111', '111242', '121142', '121241', '114212', '124112', '124211', '411212', '421112',
  '421211', '212141', '214121', '412121', '111143', '111341', '131141', '114113', '114311', '411113', '411311', '113141', '114131', '311141', '411131', '211412', '211214', '211232', '2331112'];
const START_B = 104, STOP = 106;

// text → list of symbol values (start, data, checksum, stop)
export function code128Values(text) {
  const data = [...String(text)].filter((ch) => ch.charCodeAt(0) >= 32 && ch.charCodeAt(0) <= 126).map((ch) => ch.charCodeAt(0) - 32);
  const check = data.reduce((sum, v, i) => sum + v * (i + 1), START_B) % 103;
  return [START_B, ...data, check, STOP];
}
// text → "1101…" module string (1 = bar, 0 = space), without quiet zones
export function code128Modules(text) {
  return code128Values(text).map((v) => [...PATTERNS[v]].map((w, i) => (i % 2 === 0 ? '1' : '0').repeat(Number(w))).join('')).join('');
}
export function code128Svg(text, { height = 34, module = 1.4, label = false } = {}) {
  const NS = 'http://www.w3.org/2000/svg';
  const bits = code128Modules(text); const quiet = 10; const w = (bits.length + quiet * 2) * module; const hh = height + (label ? 12 : 0);
  const svg = document.createElementNS(NS, 'svg');
  svg.setAttribute('viewBox', `0 0 ${w} ${hh}`); svg.setAttribute('width', String(w)); svg.setAttribute('height', String(hh));
  svg.setAttribute('role', 'img'); svg.setAttribute('aria-label', `Barcode ${text}`); svg.classList.add('barcode');
  const bg = document.createElementNS(NS, 'rect'); bg.setAttribute('width', String(w)); bg.setAttribute('height', String(hh)); bg.setAttribute('fill', '#fff'); svg.appendChild(bg);
  let x = quiet;
  for (let i = 0; i < bits.length;) {
    let j = i; while (j < bits.length && bits[j] === bits[i]) j++;
    if (bits[i] === '1') { const r = document.createElementNS(NS, 'rect'); r.setAttribute('x', String(x * module)); r.setAttribute('y', '0'); r.setAttribute('width', String((j - i) * module)); r.setAttribute('height', String(height)); r.setAttribute('fill', '#000'); svg.appendChild(r); }
    x += j - i; i = j;
  }
  if (label) { const t = document.createElementNS(NS, 'text'); t.setAttribute('x', String(w / 2)); t.setAttribute('y', String(hh - 2)); t.setAttribute('text-anchor', 'middle'); t.setAttribute('font-size', '10'); t.setAttribute('font-family', 'monospace'); t.textContent = text; svg.appendChild(t); }
  return svg;
}
