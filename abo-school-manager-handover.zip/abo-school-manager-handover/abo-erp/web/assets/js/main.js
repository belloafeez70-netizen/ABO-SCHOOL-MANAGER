import { h, clear } from './core/dom.js';
import { onAuthError } from './core/api.js';
import { session, loadMe } from './core/session.js';
import { route, match } from './core/router.js';
import { buildShell, setActive, initTheme } from './core/shell.js';
import { spinner, errorState } from './core/ui.js';
import { installTelemetry } from './core/telemetry.js';
import { word } from './core/words.js';
import { hubBar } from './core/hubs.js';
import { SITE_URL, apiUrl, credentials } from './core/config.js';

installTelemetry();
import('./core/offline.js').then((m) => m.registerOffline()).catch(() => {});

const P = (mod, fn) => async () => (await import(`./pages/${mod}.js`))[fn];
// public (pre-auth) routes
route('/login', P('auth', 'login'), { public: true, title: 'Sign in' });
route('/register', P('auth', 'register'), { public: true, title: 'Register your school' });
route('/activate', P('auth', 'activate'), { public: true, title: 'Activate account' });
route('/forgot', P('auth', 'forgot'), { public: true, title: 'Forgot password' });
route('/demo', P('auth', 'demo'), { public: true, title: 'Demo' });
route('/reset', P('auth', 'reset'), { public: true, title: 'Reset password' });
route('/verify', P('auth', 'verify'), { public: true, title: 'Verify email' });
route('/s/:slug', P('auth', 'schoolPortal'), { public: true, title: 'Sign in' });
// app routes
route('/', P('dashboard', 'dashboard'), { title: 'Dashboard' });
route('/getting-started', P('dashboard', 'gettingStarted'), { title: 'Getting started' });
route('/students', P('people', 'students'), { title: 'Student List' });
route('/students/new', P('students', 'addStudent'), { title: 'Add Student' });
route('/students/profile', P('students', 'studentProfile'), { title: 'Student Profile' });
route('/students/import', P('students', 'studentImport'), { title: 'Student Import' });
route('/students/:id', P('people', 'studentDetail'), { title: 'Student' });
route('/guardians', P('people', 'guardians'), { title: 'Parents & guardians' });
route('/staff', P('people', 'staff'), { title: 'Staff' });
route('/users', P('people', 'users'), { title: 'Users & access' });
route('/teachers', P('people', 'teachers'), { title: 'Teacher List' });
route('/teachers/accounts', P('teachers', 'accounts'), { title: 'Teacher Accounts' });
route('/teachers/assignments', P('teachers', 'assignments'), { title: 'Assigned Subjects' });
route('/teachers/activity', P('teachers', 'activity'), { title: 'Teacher Activity' });
route('/roles', P('people', 'roles'), { title: 'Roles & permissions' });
route('/academic', P('academic', 'setup'), { title: 'Academic setup' });
route('/academic/classes', P('academic', 'classesPage'), { title: 'Classes & Arms' });
route('/academic/subjects', P('academic', 'subjectsPage'), { title: 'Subjects' });
route('/academic/teachers', P('academic', 'teachersPage'), { title: 'Teachers' });
route('/academic/sessions', P('academic', 'sessionsPage'), { title: 'Academic Session' });
route('/academic/terms', P('academic', 'termsPage'), { title: 'Terms' });
route('/academic/allocation', P('academic', 'allocationPage'), { title: 'Subject Allocation' });
route('/academic/timetable', P('academic', 'timetablePage'), { title: 'Timetable' });
route('/attendance', P('academic', 'attendance'), { title: 'Attendance' });
route('/promotion', P('academic', 'promotion'), { title: 'Promotion' });
route('/timetable', P('portal', 'timetable'), { title: 'Timetable' });
route('/results', P('results', 'sheets'), { title: 'Score Management' });
route('/scores/ca', P('scores', 'caEntry'), { title: 'CA Score Entry' });
route('/scores/exam', P('scores', 'examEntry'), { title: 'Exam Score Entry' });
route('/results/processing', P('scores', 'processing'), { title: 'Result Processing' });
route('/results/approval', P('scores', 'approval'), { title: 'Result Approval' });
route('/results/publishing', P('scores', 'publishing'), { title: 'Result Publishing' });
route('/results/sheet/:id', P('results', 'sheet'), { title: 'Score sheet' });
route('/broadsheet', P('results', 'broadsheet'), { title: 'Class Broadsheet' });
route('/broadsheet/subject', P('broadsheets', 'subjectBroadsheet'), { title: 'Subject Broadsheet' });
route('/broadsheet/terminal', P('broadsheets', 'terminalBroadsheet'), { title: 'Terminal Broadsheet' });
route('/broadsheet/cumulative', P('broadsheets', 'cumulativeSheet'), { title: 'Cumulative Results' });
route('/broadsheet/annual', P('broadsheets', 'annualAsCumulative'), { title: 'Cumulative Results' });   // merged: annual = cumulative at 3rd term
route('/broadsheet/ranking', P('broadsheets', 'ranking'), { title: 'Position / Ranking' });
route('/reports/student', P('reports', 'studentReport'), { title: 'Student Report' });
route('/reports/class', P('reports', 'classReports'), { title: 'Class Reports' });
route('/reports/print', P('reports', 'printReports'), { title: 'Print Reports' });
route('/reports/pdf', P('reports', 'pdfReports'), { title: 'Download PDF' });
route('/reports/templates', P('reports', 'templates'), { title: 'Result Templates' });
route('/analytics/classes', P('analytics', 'classPerformance'), { title: 'Class Performance' });
route('/analytics/subjects', P('analytics', 'subjectPerformance'), { title: 'Subject Performance' });
route('/analytics/students', P('analytics', 'studentPerformance'), { title: 'Student Performance' });
route('/analytics/charts', P('analytics', 'performanceCharts'), { title: 'Performance Charts' });
route('/report/:id', P('results', 'reportCard'), { title: 'Report card' });
route('/corrections', P('results', 'corrections'), { title: 'Result corrections' });
route('/clock', P('schoollife', 'clock'), { title: 'Staff Clock-in' });
route('/calendar', P('schoollife', 'calendar'), { title: 'School Calendar' });
route('/birthdays', P('schoollife', 'birthdays'), { title: 'Birthdays' });
// 027 (12 Oct 2026): the last offline-edition features, online
route('/fees/arrears', P('tools', 'oldDebts'), { title: 'Old Debts' });
route('/petty-cash', P('tools', 'pettyCash'), { title: 'Petty Cash' });
route('/alerts', P('tools', 'alertsPage'), { title: 'Reminders & Alerts' });
route('/cbt/review', P('tools', 'questionReview'), { title: 'Questions from Teachers' });
route('/devices', P('tools', 'devices'), { title: 'Devices' });
route('/print-centre', P('tools', 'printCentre'), { title: 'Print Centre' });
route('/print/register', P('tools', 'printRegister'), { title: 'Blank Attendance Register' });
route('/print/attendance', P('tools', 'printAttendance'), { title: 'Attendance Report' });
route('/print/stock', P('tools', 'printStock'), { title: 'Store Stock Sheet' });
route('/print/ledger', P('tools', 'printLedger'), { title: 'Cash Ledger' });
route('/broadsheet/layout', P('tools', 'sheetLayout'), { title: 'Score Sheet Layout' });
route('/cashbook', P('cashbook', 'book'), { title: 'Cashbook' });
route('/cashbook/categories', P('cashbook', 'categories'), { title: 'Cashbook Categories' });
route('/store', P('store', 'items'), { title: 'School Store' });
route('/store/sell', P('store', 'sell'), { title: 'Sell Items' });
route('/store/sales', P('store', 'sales'), { title: 'Store Sales' });
route('/store/receipt/:id', P('store', 'receipt'), { title: 'Receipt' });
route('/results/comments', P('comments_idcards', 'commentHelper'), { title: 'Comment Helper' });
route('/id-cards', P('comments_idcards', 'idCards'), { title: 'ID Cards' });
route('/materials', P('materials', 'list'), { title: 'Study Materials' });
route('/live-classes', P('materials', 'live'), { title: 'Live Classes' });
route('/monitor', P('materials', 'monitor'), { title: 'Class Monitor' });
route('/act-as', P('owner_tools', 'actAs'), { title: 'Sign In As Someone' });
route('/school/web-address', P('owner_tools', 'webAddress'), { title: 'School Web Address' });
route('/lesson-notes', P('lessons', 'list'), { title: 'Lesson Notes' });
route('/lesson-notes/new', P('lessons', 'editor'), { title: 'Write Lesson Note' });
route('/lesson-notes/summary', P('lessons', 'summary'), { title: 'Lesson Notes Coverage' });
route('/lesson-notes/:id', P('lessons', 'detail'), { title: 'Lesson Note' });
route('/lesson-notes/:id/edit', P('lessons', 'editor'), { title: 'Edit Lesson Note' });
route('/cbt', P('cbt', 'exams'), { title: 'All Examinations' });
route('/cbt/dashboard', P('cbt', 'dashboard'), { title: 'CBT Dashboard' });
route('/cbt/bank', P('cbt', 'bank'), { title: 'Question Bank' });
route('/cbt/new', P('cbt', 'wizard'), { title: 'Create Examination' });
route('/cbt/scheduled', P('cbt', 'scheduled'), { title: 'Scheduled Examinations' });
route('/cbt/active', P('cbt', 'active'), { title: 'Active Examinations' });
route('/cbt/completed', P('cbt', 'completed'), { title: 'Completed Examinations' });
route('/cbt/drafts', P('cbt', 'drafts'), { title: 'Draft Examinations' });
route('/cbt/candidates', P('cbt', 'candidatesPicker'), { title: 'Candidates' });
route('/cbt/results', P('cbt', 'resultsPicker'), { title: 'CBT Results' });
route('/cbt/analytics', P('cbt', 'analytics'), { title: 'CBT Analytics' });
route('/cbt/settings', P('cbt', 'settings'), { title: 'CBT Settings' });
route('/cbt/exam/:id', P('cbt', 'examDetail'), { title: 'Examination' });
route('/cbt/exam/:id/edit', P('cbt', 'wizard'), { title: 'Edit Examination' });
route('/cbt/print/:id', P('cbt', 'printView'), { title: 'Print Examination' });
route('/cbt/attempt/:id', P('cbt', 'grade'), { title: 'Review Attempt' });
route('/cbt/result/:id', P('cbt_take', 'result'), { title: 'My Result' });
route('/my-cbt', P('cbt_take', 'myCbt'), { title: 'My CBT Exams' });
route('/take/:id', P('cbt_take', 'take'), { title: 'Examination', bare: true });
route('/fees', P('finance', 'overview'), { title: 'Fees overview' });
route('/fees/invoices', P('finance', 'invoices'), { title: 'Invoices' });
route('/fees/invoice/:id', P('finance', 'invoice'), { title: 'Invoice' });
route('/fees/payments', P('finance', 'payments'), { title: 'Payments & receipts' });
route('/fees/receipt/:id', P('finance', 'receipt'), { title: 'Receipt' });
route('/fees/setup', P('finance', 'setup'), { title: 'Fee items & discounts' });
route('/my-fees', P('portal', 'myFees'), { title: 'Fees' });
route('/my-results', P('portal', 'myResults'), { title: 'Results' });
route('/child', P('portal', 'myResults'), { title: 'Results' });
route('/announcements', P('comms', 'announcements'), { title: 'Announcements' });
route('/messages', P('comms', 'messages'), { title: 'Messages' });
route('/messages/:id', P('comms', 'thread'), { title: 'Conversation' });
route('/newsletters', P('comms', 'newsletters'), { title: 'Newsletters' });
route('/documents', P('records', 'documents'), { title: 'Document archive' });
route('/data', P('records', 'data'), { title: 'Import & export' });
route('/downloads/:id', P('records', 'downloadFile'), { title: 'Download' });
route('/migrate', P('records', 'migrate'), { title: 'Legacy migration' });
route('/audit', P('records', 'audit'), { title: 'Audit log' });
route('/security-events', P('records', 'securityEvents'), { title: 'Security events' });
route('/settings', P('settings', 'school'), { title: 'Settings' });
route('/school/profile', P('school', 'profile'), { title: 'School Profile' });
route('/school/branding', P('school', 'branding'), { title: 'Logo & Branding' });
route('/school/head', P('school', 'head'), { title: 'Principal / Head Information' });
route('/backup', P('admin', 'backup'), { title: 'Backup & Restore' });
route('/billing', P('billing', 'mySubscription'), { title: 'Subscription' });
route('/platform/demo', P('demolinks', 'demoLinks'), { title: 'Demo Links' });
route('/platform/billing', P('billing', 'platformBilling'), { title: 'Payments & Plans' });
route('/notifications', P('admin', 'notifications'), { title: 'Notifications' });
route('/help', P('admin', 'help'), { title: 'Help & Support' });
route('/system', P('admin', 'system'), { title: 'System Information' });
route('/account', P('settings', 'account'), { title: 'My account & security' });
route('/platform/security', P('platform', 'security'), { title: 'Security events' });
route('/platform/health', P('platform', 'health'), { title: 'System health' });

const app = document.getElementById('app');
app.classList.remove('boot');
let shell = null;
onAuthError((e) => {
  const m = match(location.hash || '#/');
  if (m && m.r.public) return;                       // pre-auth pages show their own errors (e.g. wrong password)
  if (e.code === 'UNAUTHENTICATED' || e.status === 401) { import('./core/offline.js').then((x) => x.offlineSignedOut()).catch(() => {}); session.me = null; shell = null; location.hash = '#/login'; }
});

async function render() {
  const hash = location.hash || '#/';
  const m = match(hash);
  if (!m) { location.hash = '#/'; return; }
  if (!m.r.public) {
    if (!session.me) { try { await loadMe(); } catch { location.hash = '#/login'; return; } }
    const me = session.me;
    if (me.mfaState === 'pending' || me.mfaState === 'enroll_required' || me.user.mustChangePassword) {
      const gate = (await import('./pages/auth.js')).gate; clear(app); shell = null; gate(app, me); return;
    }
    if (me.portal === 'platform' && !me.support && (hash === '#/' || hash.startsWith('#/?'))) { m.loader = P('platform', 'schools'); m.r = { ...m.r, loader: P('platform', 'schools') }; }
    if (m.r.bare) { clear(app); shell = null; const fn = await m.r.loader(); const v = h('main.view.bare'); app.appendChild(v); return fn(v, m.params, m.query); }
    if (!shell) { const s = buildShell(); clear(app).appendChild(s.root); shell = s; }
    setActive(hash, m.r.title); document.title = `${word(m.r.title)} · ${me.school ? me.school.name : 'A.B.O. School Manager'}`;
    clear(shell.view).appendChild(spinner());
    try {
      const fn = await m.r.loader(); clear(shell.view); await fn(shell.view, m.params, m.query);
      // pages that belong together: one menu entry + a row of tabs under the page title
      const bar = hubBar(hash); if (bar && location.hash === hash) { const head = shell.view.querySelector(':scope > .page-head'); if (head) head.after(bar); else shell.view.prepend(bar); }
      shell.view.focus({ preventScroll: true }); window.scrollTo(0, 0);
    }
    catch (e) { clear(shell.view).appendChild(errorState(e, render)); }
  } else {
    if (session.me && (m.r.pattern === '/login' || m.r.pattern === '/s/:slug')) { location.hash = '#/'; return; }
    if (!(await serverReachable())) { needsServer(); return; }
    shell = null; document.title = `${m.r.title} · A.B.O. School Manager`;
    const fn = await m.r.loader(); clear(app); await fn(app, m.params, m.query);
  }
}
// Opened straight from disk (double-clicked file): sign-in cookies, the database and every security check live on the
// server, so show how to reach the live portal instead of a broken sign-in page.
// Is the school server behind this page? (No: opened from disk, inside a sandboxed preview, a static host without the
// /api proxy, or a Netlify site whose API_ORIGIN is not set yet.) Checked once, only before the sign-in pages.
let serverCheck = null;
function serverReachable() {
  if (location.protocol === 'file:' || window.origin === 'null') return Promise.resolve(false);
  return serverCheck || (serverCheck = fetch(apiUrl('/public/status'), { credentials, cache: 'no-store', headers: { accept: 'application/json' } })
    .then(async (r) => {
      const text = await r.text().catch(() => '');            // always read the body so the request completes
      if (r.status === 429) return true;                       // busy, but it IS the school server
      let b = null; try { b = JSON.parse(text); } catch { /* HTML or nothing: not our API */ }
      return !!(r.ok && b && b.service === 'abo-api');
    }).catch(() => false));
}
function needsServer() {
  const fromDisk = location.protocol === 'file:';
  const steps = [
    'Open your school portal address in the browser (the Netlify address, or your own domain once connected).',
    'Or upload this file as index.html to the Netlify site that is connected to the A.B.O. API.',
    'The offline edition (no server, one device) remains available as school_broadsheet_manager_bopc_erp.html.',
  ];
  clear(app).appendChild(h('div.auth', h('section.auth-brand', h('div.logo-row', h('div.brand-mark', { text: 'ABO' }), h('span', { text: 'A.B.O. SCHOOL MANAGER' })),
    h('div', h('h1', { text: 'This is the online edition.' }), h('p', { text: 'Results, CBT, fees, lesson notes and parent access are protected by the school server, so the app must be opened from its web address.' })),
    h('small', { text: `© ${new Date().getFullYear()} A.B.O. Edu Consultant` })),
  h('section.auth-form', h('div.auth-box', h('h2', { text: 'Open the school portal' }),
    h('p.muted', { text: fromDisk ? 'This file was opened directly from your computer. Signing in needs the secure server, which is not reachable from a local file.'
      : 'The school server cannot be reached from this page (for example a file preview, or a site whose server connection is not set up yet). Signing in needs the secure server.' }),
    SITE_URL ? h('a.btn.btn-primary', { href: SITE_URL, text: `Go to ${SITE_URL.replace(/^https:\/\//, '')}` }) : null,
    h('ol.needs-server', steps.map((t) => h('li', { text: t })))))));
}
initTheme();
if (location.protocol === 'file:' || window.origin === 'null') needsServer();
else { window.addEventListener('hashchange', render); render(); }
