/* A.B.O. School Manager — screen layout lock + early install hook. Loaded as a normal (non-module) script in <head>
   so it runs BEFORE the page is drawn.

   Why: on phones, people tick the browser's "Desktop site", or want the computer layout, and the page kept falling back
   to the phone layout (after a reload, coming back to the tab, turning the phone, or opening the installed app).
   Now the choice is remembered on this device (localStorage "abo.layout") and re-applied every time:
     'auto'    — phone layout on phones, computer layout on computers. If the browser's "Desktop site" is on, the
                 computer layout is used and stays (we detect it: desktop browser name + touch screen + small screen).
     'desktop' — always the computer layout (the page is drawn 1280 px wide; pinch to zoom).
     'phone'   — always the phone layout (tablets).
   Only how the page is laid out changes — never any data. */
(function () {
  'use strict';
  var KEY = 'abo.layout';
  var meta = document.querySelector('meta[name="viewport"]');
  if (!meta) { meta = document.createElement('meta'); meta.name = 'viewport'; document.head.appendChild(meta); }
  var PHONE = 'width=device-width, initial-scale=1, viewport-fit=cover';
  var DESKTOP = 'width=1280, viewport-fit=cover';
  function get() { try { var v = localStorage.getItem(KEY); return v === 'desktop' || v === 'phone' ? v : 'auto'; } catch (e) { return 'auto'; } }
  function touch() { return (window.matchMedia && matchMedia('(pointer: coarse)').matches) || (navigator.maxTouchPoints || 0) > 1; }
  // the browser's own "Desktop site" switch: it sends a computer browser name from a small touch screen
  function browserDesktopSite() {
    var ua = navigator.userAgent || '';
    var small = Math.min(screen.width || 0, screen.height || 0) > 0 && Math.min(screen.width, screen.height) < 820;
    return touch() && small && !/Mobi|Android|iPhone|iPod|Opera Mini|IEMobile/i.test(ua);
  }
  function effective() { var m = get(); return m === 'auto' ? (browserDesktopSite() ? 'desktop' : 'phone-or-computer') : m; }
  function apply() {
    var e = effective(); var want = e === 'desktop' ? DESKTOP : PHONE;
    if (meta.getAttribute('content') !== want) meta.setAttribute('content', want);
    var root = document.documentElement;
    root.classList.toggle('layout-desktop', e === 'desktop');
    root.classList.toggle('layout-phone', e === 'phone');
    root.setAttribute('data-layout', get());
  }
  apply();
  // re-apply whenever the browser could have reset the page: back/forward cache, returning to the tab, rotating,
  // another tab changing the choice
  window.addEventListener('pageshow', apply);
  document.addEventListener('visibilitychange', function () { if (!document.hidden) apply(); });
  window.addEventListener('orientationchange', function () { setTimeout(apply, 150); });
  window.addEventListener('storage', function (ev) { if (ev.key === KEY) apply(); });
  window.aboLayout = {
    get: get, effective: effective, browserDesktopSite: browserDesktopSite, isTouch: touch,
    set: function (m) { try { if (m === 'auto') localStorage.removeItem(KEY); else localStorage.setItem(KEY, m); } catch (e) { /* private mode */ } apply(); try { window.dispatchEvent(new Event('resize')); } catch (e) { /* old browser */ } },
  };
  // "Install app": Chrome / Edge / Samsung Internet / Opera fire this early — keep it for the Install button
  window.addEventListener('beforeinstallprompt', function (ev) { ev.preventDefault(); window.__aboInstallEvent = ev; try { window.dispatchEvent(new Event('abo-install-ready')); } catch (e) { /* */ } });
  window.addEventListener('appinstalled', function () { window.__aboInstallEvent = null; try { localStorage.setItem('abo.installed', '1'); window.dispatchEvent(new Event('abo-install-ready')); } catch (e) { /* */ } });
}());
