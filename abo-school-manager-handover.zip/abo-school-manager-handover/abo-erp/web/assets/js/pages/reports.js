// Report Sheets menu: Student Report, Class Reports, Print Reports, Download PDF, Result Templates.
import { h, clear } from '../core/dom.js';
import { api, qs } from '../core/api.js';
import { can } from '../core/session.js';
import { pageHead, btn, badge, card, toast, fail, simpleTable, empty, spinner, field, form } from '../core/ui.js';
import { ordinal } from '../core/format.js';
import { academic } from './people.js';
import { pickers, mapLimit } from './shared.js';
import { reportDoc, renderReport } from './results.js';

export async function studentReport(view, p, q) {
  const a = await academic();
  view.appendChild(pageHead('Student Report', 'Open one learner’s report sheet for any term — print it or save it as PDF.'));
  const pk = pickers(a, q, { term: true, cls: true });
  const who = h('select.input', { 'aria-label': 'Learner' });
  const box = h('div');
  const loadStudents = async ({ termId, classId }) => {
    clear(who).appendChild(h('option', { text: 'Loading…', value: '' }));
    try {
      const b = await api.get(`/results/broadsheet${qs({ termId, classId })}`);
      clear(who).append(h('option', { value: '', text: `Choose a learner (${b.rows.length})` }), ...[...b.rows].sort((x, y) => x.name.localeCompare(y.name)).map((r) => h('option', { value: r.studentId, text: `${r.name} · ${r.admissionNo}`, selected: r.studentId === q.studentId })));
      if (q.studentId) show();
    } catch (e) { clear(who); fail(e); }
  };
  const show = async () => {
    const { termId } = pk.get(); if (!who.value) return clear(box);
    clear(box).appendChild(spinner('Loading report…'));
    try { clear(box).appendChild(await reportDoc(who.value, termId)); } catch (e) { clear(box); fail(e); }
  };
  who.addEventListener('change', show);
  pk.on(loadStudents);
  view.append(h('div.no-print', card(null, [pk.el, h('div.field', h('label', { text: 'Learner' }), who)])), box);
  loadStudents(pk.get());
}

export async function classReports(view, p, q) {
  const a = await academic();
  view.appendChild(pageHead('Class Reports', 'Every learner in a class with their average, position and report status. Open, print or batch-print the whole class.'));
  const pk = pickers(a, q, { term: true, cls: true });
  const box = h('div');
  const load = async ({ termId, classId }) => {
    clear(box).appendChild(spinner());
    try {
      const b = await api.get(`/results/broadsheet${qs({ termId, classId })}`);
      clear(box).append(h('div.page-actions', h('a.btn.btn-primary', { href: `#/reports/print?termId=${termId}&classId=${classId}`, text: 'Print all report sheets' }), h('a.btn', { href: `#/reports/pdf?termId=${termId}&classId=${classId}`, text: 'Save class as PDF' }), b.provisional ? badge('provisional — not yet published', 'warn') : badge('published', 'ok')),
        card(`${b.class_name} · ${b.rows.length} learners`, simpleTable([{ label: 'Pos', render: (r) => (r.summary && r.summary.position ? ordinal(r.summary.position) : '—') }, { key: 'name', label: 'Name' }, { key: 'admissionNo', label: 'Adm. No', cls: 'mono' },
          { label: 'Subjects', render: (r) => r.scores.filter(Boolean).length }, { label: 'Average', render: (r) => (r.summary ? `${r.summary.average}%` : '—') }, { label: 'Grade', render: (r) => (r.summary ? r.summary.grade || '' : '') },
          { label: 'Status', render: (r) => (r.summary ? badge(r.summary.status) : badge('no scores', 'muted')) }, { label: '', render: (r) => h('a.btn.btn-sm', { href: `#/report/${r.studentId}?termId=${termId}`, text: 'Open report' }) }], b.rows, 'No learners in this class')));
    } catch (e) { clear(box); fail(e); }
  };
  pk.on(load); view.append(card(null, pk.el), box); load(pk.get());
}

// batch renderer shared by Print Reports and Download PDF
function batchPage({ title, sub, pdf }) {
  return async (view, p, q) => {
    const a = await academic();
    view.appendChild(pageHead(title, sub));
    const pk = pickers(a, q, { term: true, cls: true });
    const box = h('div.report-batch');
    const status = h('div.no-print');
    let token = 0;
    const load = async ({ termId, classId }) => {
      const my = ++token;
      clear(box); clear(status).appendChild(spinner('Preparing report sheets…'));
      try {
        const b = await api.get(`/results/broadsheet${qs({ termId, classId })}`);
        const rows = b.rows.filter((r) => r.summary && r.summary.status !== 'Pending');
        if (!rows.length) { clear(status).appendChild(empty('No report sheets to print', 'Learners appear here once they have scores for this term.')); return; }
        let done = 0; const prog = h('span.muted', { text: `0 / ${rows.length}` });
        clear(status).append(card(null, h('div.kpi-row', h('strong', { text: `${b.class_name} — ${rows.length} report sheet(s)` }), prog)));
        const docs = await mapLimit(rows, 4, async (r) => { const d = await api.get(`/results/student/${r.studentId}${qs({ termId })}`); done++; prog.textContent = `${done} / ${rows.length}`; return d; });
        if (my !== token) return;
        docs.forEach((d) => { if (d && d.available) box.appendChild(renderReport(d, { actions: false })); });
        clear(status).append(card(pdf ? 'Save as PDF' : 'Ready to print', [
          pdf ? h('ol', ['Click “Save class as PDF”.', 'In the print window choose “Save as PDF” (or “Microsoft Print to PDF”) as the destination.', 'Keep “Background graphics” ticked so logos and colours are included, then Save.'].map((t) => h('li', { text: t })))
            : h('p.muted', { text: 'Each report sheet starts on a new page. Use A4 portrait.' }),
          h('div.page-actions', btn(pdf ? 'Save class as PDF' : 'Print all', () => window.print(), { kind: 'primary', ic: pdf ? 'download' : 'printer' }), b.provisional ? badge('provisional — not yet published', 'warn') : badge('published', 'ok')),
          pdf ? h('p.muted', { text: 'PDFs are produced by your browser’s built-in PDF printer, so nothing leaves your device and no file is stored on the server.' }) : null]));
      } catch (e) { clear(status); fail(e); }
    };
    pk.on(load); view.append(h('div.no-print', card(null, pk.el)), status, box); load(pk.get());
  };
}
export const printReports = batchPage({ title: 'Print Reports', sub: 'Print every report sheet in a class in one go — one learner per page.' });
export const pdfReports = batchPage({ title: 'Download PDF', sub: 'Save a whole class’s report sheets as one PDF file.', pdf: true });

// ── Result Templates ──
const SAMPLE = () => ({
  available: true, provisional: false,
  student: { first_name: 'Adaeze', last_name: 'Okafor', other_names: 'Chioma', admission_no: 'SAMPLE/001', gender: 'Female' },
  term: { name: '1ST', session: '2026/2027', days_open: 64, next_term_begins: '2027-01-11' },
  summary: { class_name: 'JSS 2A', average: 71.4, class_size: 32, total: 642.6, grade: 'B2', status: 'Pass', section: 'secondary' }, ordinalPosition: '4th',
  attendance: { present: 60, absent: 4 }, reportCard: { teacher_comment: 'A focused and helpful learner. Keep it up!', head_comment: 'Good result. Aim higher next term.' },
  subjects: [['English Language', 15, 16, 44], ['Mathematics', 18, 17, 51], ['Basic Science', 14, 12, 40], ['Civic Education', 17, 18, 47]].map(([subject, ca1, ca2, exam], i) => ({ subject, components: [{ key: 'ca1', label: 'CA1', max: 20 }, { key: 'ca2', label: 'CA2', max: 20 }, { key: 'exam', label: 'Exam', max: 60 }], scores: { ca1, ca2, exam }, total: ca1 + ca2 + exam, grade: ['B3', 'A1', 'C5', 'B2'][i], subject_position: [5, 2, 9, 4][i], class_average: [61.2, 58.4, 55.9, 63.1][i], remark: ['Good', 'Excellent', 'Credit', 'Very good'][i] })),
});
// sample "results so far" block for the template preview (2nd term)
const SAMPLE_CUM = (divisor) => {
  const subj = [['English Language', 70, 75], ['Mathematics', 82, 86], ['Basic Science', 58, 66], ['Civic Education', 72, 82]];
  const subjects = subj.map(([name, a, b], i) => ({ name, termTotals: [a, b], taken: 2, total: a + b, average: (a + b) / 2, grade: ['B2', 'A1', 'C4', 'A1'][i], position: [4, 2, 8, 3][i], classAverage: [62.5, 59.1, 57.3, 64.0][i] }));
  return { terms: [{ name: '1ST', label: '1st term' }, { name: '2ND', label: '2nd term' }], termLabel: '2nd term', isAnnual: false, classSize: 32, passMark: 40, subjects,
    termAverages: [70.5, 77.25], cumulativeAverage: 73.88, grade: 'B2', ordinalCumulativePosition: '3rd', status: 'Pass', change: 6.75, marksObtained: 591, marksObtainable: 800, classAverage: 60.7, provisional: false,
    summary: 'After the second term, Amaka’s cumulative average is 73.88% (B2), which is very good. This term’s average is 6.75 points higher than last term. Amaka is 3rd of 32 in the class so far this session. Best subject so far: Mathematics (84%).',
    method: divisor === 'all' ? 'Cumulative subject average = total marks so far ÷ number of terms the subject was taught (a missed term counts as 0). Overall cumulative average = average of the subject cumulative averages.'
      : 'Cumulative subject average = total marks so far ÷ number of terms the learner was scored in that subject. Overall cumulative average = average of the subject cumulative averages.' };
};
export async function templates(view) {
  const [d] = await Promise.all([api.get('/school')]);
  const edit = can('settings.update');
  const rs = d.settings.report_card || {};
  view.appendChild(pageHead('Result Templates', 'Choose how report sheets look. Changes apply to every report sheet you print or publish from now on.'));
  const f = form([
    { name: 'template', label: 'Layout', type: 'select', placeholder: false, options: [{ value: 'classic', label: 'Classic — traditional, black & white friendly' }, { value: 'modern', label: 'Modern — coloured headings in your school colour' }, { value: 'compact', label: 'Compact — smaller text, fits more subjects on A4' }] },
    { name: 'accent', label: 'Accent colour (modern layout)', type: 'color' },
    { name: 'principalTitle', label: 'Head title on report', placeholder: 'Principal / Head teacher' },
    { name: 'footer', label: 'Footer note', placeholder: 'e.g. School resumes 8:00am. Fees are due before resumption.', full: true },
    { name: 'showPosition', label: 'Show overall class position', type: 'checkbox' }, { name: 'showSubjectPosition', label: 'Show position in each subject', type: 'checkbox' },
    { name: 'showClassAverage', label: 'Show class average per subject', type: 'checkbox' }, { name: 'showAttendance', label: 'Show attendance', type: 'checkbox' },
    { name: 'showGradeKey', label: 'Print the grading key', type: 'checkbox' }, { name: 'showPassport', label: 'Show learner passport photo', type: 'checkbox' },
    { name: 'showSignature', label: 'Print the head’s signature (upload it under School › Principal/Head Information)', type: 'checkbox', full: true },
    { name: 'showCumulative', label: 'Show “results so far” (cumulative) on 2nd and 3rd term report cards', type: 'checkbox', full: true },
    { name: 'cumulativeDivisor', label: 'Cumulative average — when a learner missed a term', type: 'select', placeholder: false, full: true, options: [
      { value: 'taken', label: 'Divide by the terms the learner took (fair to new pupils) — recommended' },
      { value: 'all', label: 'Divide by every term the subject was taught (a missed term counts as 0)' }] },
  ], { template: rs.template || 'classic', accent: rs.accent || d.school.brand_color || '#0a7d61', principalTitle: rs.principalTitle || d.school.head_title || '', footer: rs.footer || '',
    showPosition: rs.showPosition !== false, showSubjectPosition: rs.showSubjectPosition !== false, showClassAverage: rs.showClassAverage !== false, showAttendance: rs.showAttendance !== false,
    showGradeKey: !!rs.showGradeKey, showPassport: rs.showPassport !== false, showSignature: rs.showSignature !== false,
    showCumulative: rs.showCumulative !== false, cumulativeDivisor: rs.cumulativeDivisor === 'all' ? 'all' : 'taken' });
  if (!edit) f.querySelectorAll('input,select,textarea').forEach((x) => { x.disabled = true; });
  const preview = h('div');
  const values = () => { const v = f._values(); return { ...v, accent: /^#[0-9a-fA-F]{6}$/.test(v.accent || '') ? v.accent : undefined, principalTitle: v.principalTitle || '', footer: v.footer || '' }; };
  const draw = () => { const sample = SAMPLE(); sample.school = { ...d.school, school_type: d.school.school_type }; sample.grading = d.settings.grading; sample.reportSettings = values(); sample.cumulative = values().showCumulative ? SAMPLE_CUM(values().cumulativeDivisor) : null; clear(preview).appendChild(renderReport(sample, { actions: false })); };
  f.addEventListener('input', draw); f.addEventListener('change', draw);
  view.appendChild(h('div.grid.g2', card('Template settings', [f, edit ? h('div.page-actions', btn('Save template', async () => {
    const v = values(); const body = { ...v }; if (!body.accent) delete body.accent; if (!body.principalTitle) delete body.principalTitle;
    try { await api.put('/school/settings', { reportCard: body }); toast('Report template saved'); } catch (e) { if (!f._error(e)) fail(e); }
  }, { kind: 'primary', ic: 'check' })) : h('p.muted', { text: 'Only administrators can change the template.' })]),
  card('Live preview (sample learner)', preview)));
  draw();
  void field;
}
