// Broadsheet menu: Subject Broadsheet, Terminal Broadsheet (CA/Exam breakdown), Annual Broadsheet (cumulative),
// Cumulative Results (term-to-date and whole session: class / subject / learner),
// Position / Ranking. Every figure comes from the server; the page only lays it out for screen and print.
import { h, clear, icon, append } from '../core/dom.js';
import { api, qs, download } from '../core/api.js';
import { can, session } from '../core/session.js';
import { pageHead, btn, badge, card, fail, simpleTable, empty, spinner, stat, tabs } from '../core/ui.js';
import { lineChart } from '../core/charts.js';
import { ordinal, initials, tn } from '../core/format.js';
import { academic } from './people.js';
import { pickers, mapLimit, num } from './shared.js';
import { fileUrl } from '../core/config.js';

export function docHead(lines) {
  const s = session.me.school || {};
  return h('div.doc-head', s.logo_file_id ? h('img', { src: fileUrl(s.logo_file_id), alt: '' }) : h('div.brand-mark.doc-mark', { text: initials((s || {}).name || 'School') }),
    h('div', h('h1', { text: s.name || '' }), s.motto ? h('p', { text: `Motto: ${s.motto}` }) : null, h('p', { text: [s.address, s.phone].filter(Boolean).join(' · ') }), ...lines.filter(Boolean).map((l) => h('p', h('strong', { text: l })))));
}
const printBtn = () => btn('Print', () => window.print(), { ic: 'printer' });
const isExam = (c) => c.is_exam === true || c.key === 'exam';

export async function subjectBroadsheet(view, p, q) {
  const a = await academic();
  view.appendChild(pageHead('Subject Broadsheet', 'One subject for one class: every CA and exam score with total, grade, position and class statistics.'));
  const pk = pickers(a, q, { term: true, cls: true, subject: true });
  const box = h('div');
  const load = async ({ termId, classId, subjectId }) => {
    clear(box).appendChild(spinner());
    try {
      const list = await api.get(`/results/sheets${qs({ termId, classId })}`);
      const row = list.items.find((x) => x.subject_id === subjectId);
      if (!row) return clear(box).appendChild(empty('This subject is not offered in this class', 'Choose another subject, or allocate it under Academics › Subject Allocation.'));
      if (!row.sheet_id) return clear(box).appendChild(empty('No scores yet', 'The subject teacher has not started this score sheet.'));
      const d = await api.get(`/results/sheets/${row.sheet_id}`);
      const comps = d.sheet.components; const scored = d.rows.filter((r) => r.result);
      const totals = scored.map((r) => Number(r.result.total));
      const passMark = d.passMark ?? 40; const avg = totals.length ? totals.reduce((x, y) => x + y, 0) / totals.length : 0;
      const rows = [...d.rows].sort((x, y) => ((x.result && x.result.subject_position) || 1e9) - ((y.result && y.result.subject_position) || 1e9));
      clear(box).append(h('div.page-actions.no-print', printBtn(), badge(d.sheet.status, d.sheet.status === 'published' ? 'ok' : 'warn')),
        h('div.stats.no-print', stat('Scored', `${scored.length}/${d.rows.length}`, 'learners', 'users'), stat('Class average', num(avg), '', 'chart'), stat('Highest', totals.length ? num(Math.max(...totals)) : '—', '', 'check'),
          stat('Lowest', totals.length ? num(Math.min(...totals)) : '—', '', 'activity'), stat('Passed', totals.filter((t) => t >= passMark).length, `of ${totals.length} (≥ ${passMark})`, 'shield')),
        h('div.doc', docHead([`${d.sheet.className} · ${d.sheet.subject}`]), h('h2', { text: `Subject broadsheet${d.sheet.status !== 'published' ? ' (provisional)' : ''}` }),
          h('div.table-wrap', h('table', h('thead', h('tr', h('th', { text: 'Pos' }), h('th', { text: 'Name' }), h('th', { text: 'Adm. No' }), comps.map((c) => h('th', { text: `${c.label} (${c.max})` })), h('th', { text: 'Total' }), h('th', { text: 'Grade' }), h('th', { text: 'Remark' }))),
            h('tbody', rows.map((r) => h('tr', h('td.center', { text: r.result ? ordinal(r.result.subject_position) : '—' }), h('td.nowrap', { text: r.name }), h('td.mono', { text: r.admissionNo }),
              comps.map((c) => h('td.center', { text: r.scores[c.key] ?? '' })), h('td.center', h('strong', { text: r.result ? r.result.total : '' })), h('td.center', { text: r.result ? r.result.grade : '' }), h('td', { text: r.result ? r.result.remark || '' : '' }))))))));
    } catch (e) { clear(box); fail(e); }
  };
  pk.on(load); view.append(h('div.no-print', card(null, pk.el)), box); load(pk.get());
}

export async function terminalBroadsheet(view, p, q) {
  const a = await academic();
  view.appendChild(pageHead('Terminal Broadsheet', 'The full end-of-term broadsheet: CA, exam and total for every subject, with overall total, average, grade and position.'));
  const pk = pickers(a, q, { term: true, cls: true });
  const box = h('div');
  const load = async ({ termId, classId }) => {
    clear(box).appendChild(spinner('Building broadsheet…'));
    try {
      const b = await api.get(`/results/broadsheet${qs({ termId, classId })}`);
      if (!b.subjects.length) return clear(box).appendChild(empty('No score sheets yet', 'Scores appear here as teachers enter them.'));
      const sheets = await mapLimit(b.subjects, 4, (s) => api.get(`/results/sheets/${s.sheetId}`).catch(() => null));
      const bySheet = new Map(); sheets.forEach((d, i) => { if (d) bySheet.set(b.subjects[i].sheetId, new Map(d.rows.map((r) => [r.studentId, r]))); });
      const split = (sheetId, studentId) => {
        const d = sheets.find((x) => x && x.sheet.id === sheetId); const r = bySheet.get(sheetId) && bySheet.get(sheetId).get(studentId);
        if (!d || !r || !r.result) return ['', '', ''];
        const ca = d.sheet.components.filter((c) => !isExam(c)).reduce((t, c) => t + Number(r.scores[c.key] || 0), 0);
        const ex = d.sheet.components.filter(isExam).reduce((t, c) => t + Number(r.scores[c.key] || 0), 0);
        return [num(ca), num(ex), r.result.total];
      };
      // the school's own layout (Score Sheet Layout page): which columns print, title and footer
      const L = { showBreakdown: true, showPosition: true, showTotal: true, showAverage: true, showGrade: true, showStatus: true, title: '', footer: '', ...((await api.get('/broadsheet/layout').catch(() => ({}))).layout || {}) };
      const per = L.showBreakdown ? 3 : 1; const rs = L.showBreakdown ? 2 : 1;
      const tail = [['showTotal', 'Total', (r) => r.summary ? r.summary.total : ''], ['showAverage', 'Avg', (r) => r.summary ? r.summary.average : ''],
        ['showGrade', 'Grade', (r) => r.summary ? r.summary.grade || '' : ''], ['showStatus', 'Status', (r) => r.summary ? r.summary.status : '']].filter(([k]) => L[k]);
      const head1 = h('tr', L.showPosition ? h('th', { rowspan: rs, text: 'Pos' }) : null, h('th', { rowspan: rs, text: 'Name' }), b.subjects.map((s) => h('th.center', { colspan: per, text: s.name })), tail.map(([, t]) => h('th', { rowspan: rs, text: t })));
      const head2 = L.showBreakdown ? h('tr', b.subjects.map(() => [h('th.center.sub', { text: 'CA' }), h('th.center.sub', { text: 'EX' }), h('th.center.sub', { text: 'TOT' })])) : null;
      const body = h('tbody', b.rows.map((r) => h('tr', L.showPosition ? h('td.center', { text: r.summary && r.summary.position ? ordinal(r.summary.position) : '—' }) : null, h('td.nowrap', { text: r.name }),
        b.subjects.map((s) => { const v3 = split(s.sheetId, r.studentId); return L.showBreakdown ? v3.map((v, i) => h(`td.center${i === 2 ? '.strong' : ''}`, { text: v })) : h('td.center.strong', { text: v3[2] }); }),
        tail.map(([, , f]) => h('td.center', { text: f(r) })))));
      clear(box).append(h('div.page-actions.no-print', printBtn(), can('reports.export') ? btn('Excel (totals)', () => download(`/exports/broadsheet${qs({ termId, classId, format: 'xlsx' })}`).catch(fail), { ic: 'download' }) : null, b.provisional ? badge('provisional', 'warn') : badge('published', 'ok')),
        h('div.doc.landscape', docHead([`${b.class_name} · ${b.session} · ${tn(b.term)} term`]), h('h2', { text: `${L.title || 'Terminal broadsheet'}${b.provisional ? ' (provisional — not yet published)' : ''}` }), h('div.table-wrap', h('table.terminal', h('thead', head1, head2), body)),
          L.footer ? h('p.sign-line', { text: L.footer }) : null));
    } catch (e) { clear(box); fail(e); }
  };
  pk.on(load); view.append(h('div.no-print', card(null, pk.el)), box); load(pk.get());
}

export async function annualBroadsheet(view, p, q) {
  const a = await academic();
  view.appendChild(pageHead('Annual Broadsheet', 'Cumulative results for the whole session: each subject’s term totals and annual average, overall average, grade and annual position.'));
  const pk = pickers(a, q, { session: true, cls: true });
  const box = h('div');
  const load = async ({ sessionId, classId }) => {
    clear(box).appendChild(spinner('Computing annual results…'));
    try {
      const b = await api.get(`/results/annual${qs({ sessionId, classId })}`);
      if (!b.subjects.length) return clear(box).appendChild(empty('No results for this session yet', 'Scores entered in any term of the session appear here.'));
      const tn = b.terms.map((t) => t.name);
      const head1 = h('tr', h('th', { rowspan: 2, text: 'Pos' }), h('th', { rowspan: 2, text: 'Name' }), b.subjects.map((s) => h('th.center', { colspan: tn.length + 1, text: s.name })), h('th', { rowspan: 2, text: 'Annual avg' }), h('th', { rowspan: 2, text: 'Grade' }), h('th', { rowspan: 2, text: 'Status' }));
      const head2 = h('tr', b.subjects.map(() => [...tn.map((t) => h('th.center.sub', { text: t })), h('th.center.sub', { text: 'AVG' })]));
      const body = h('tbody', b.rows.map((r) => h('tr', h('td.center', { text: r.position ? ordinal(r.position) : '—' }), h('td.nowrap', { text: r.name }),
        r.subjects.map((s) => [...s.termTotals.map((v) => h('td.center', { text: v ?? '' })), h('td.center.strong', { text: s.annual ?? '' })]),
        h('td.center', h('strong', { text: r.annualAverage ?? '—' })), h('td.center', { text: r.grade || '' }), h('td.center', { text: r.status }))));
      clear(box).append(h('div.page-actions.no-print', printBtn(), b.provisional ? badge('includes unpublished results', 'warn') : badge('all terms published', 'ok')),
        h('div.doc.landscape', docHead([`${b.class_name} · ${b.session} session · annual results`]), h('h2', { text: `Annual broadsheet${b.provisional ? ' (provisional)' : ''}` }),
          h('p.muted', { text: `Annual subject average = average of the terms in which the learner was scored. Pass mark ${b.passMark}%. Ranking: 1-2-2-4.` }), h('div.table-wrap', h('table.terminal', h('thead', head1, head2), body))));
    } catch (e) { clear(box); fail(e); }
  };
  pk.on(load); view.append(h('div.no-print', card(null, pk.el)), box); load(pk.get());
}

export async function ranking(view, p, q) {
  const a = await academic();
  view.appendChild(pageHead('Position / Ranking', 'Class positions (1-2-2-4 competition ranking), top performers and subject leaders.'));
  const pk = pickers(a, q, { term: true, cls: true });
  const box = h('div');
  const load = async ({ termId, classId }) => {
    clear(box).appendChild(spinner());
    try {
      const b = await api.get(`/results/broadsheet${qs({ termId, classId })}`);
      const ranked = b.rows.filter((r) => r.summary && r.summary.position);
      if (!ranked.length) return clear(box).appendChild(empty('No positions yet', 'Positions appear once scores are entered (process results under Scores & Results › Result Processing).'));
      const medals = ['1st', '2nd', '3rd'];
      const podium = h('div.podium', ranked.slice(0, 3).map((r, i) => h('div.pd', h('div.medal', { text: medals[i] }), h('strong', { text: r.name }), h('div.muted', { text: `Average ${r.summary.average}% · Grade ${r.summary.grade || '—'}` }))));
      const leaders = b.subjects.map((s, i) => {
        const best = b.rows.filter((r) => r.scores[i] && r.scores[i].position === 1);
        return { subject: s.name, names: best.map((r) => r.name).join(', ') || '—', score: best[0] ? best[0].scores[i].total : '—' };
      });
      clear(box).append(h('div.page-actions.no-print', printBtn(), b.provisional ? badge('provisional', 'warn') : badge('published', 'ok')),
        card(`Top of ${b.class_name}`, podium),
        h('div.grid.g2', card('Class ranking', simpleTable([{ label: 'Pos', render: (r) => h('strong', { text: ordinal(r.summary.position) }) }, { key: 'name', label: 'Name' }, { label: 'Total', render: (r) => r.summary.total }, { label: 'Average', render: (r) => `${r.summary.average}%` }, { label: 'Grade', render: (r) => r.summary.grade || '' }, { label: 'Status', render: (r) => badge(r.summary.status) }], ranked)),
          card('Subject leaders (1st in each subject)', simpleTable([{ key: 'subject', label: 'Subject' }, { key: 'names', label: 'Best learner(s)' }, { key: 'score', label: 'Score' }], leaders))));
    } catch (e) { clear(box); fail(e); }
  };
  pk.on(load); view.append(h('div.no-print', card(null, pk.el)), box); load(pk.get());
}

// ── Cumulative results: every term of the session up to the chosen term, per subject and overall ──
// Whole class (score sheet), one subject, or one learner (a plain-English statement a parent can read).
export async function cumulativeSheet(view, p, q) {
  const a = await academic();
  view.appendChild(pageHead('Cumulative Results', 'Results added up across the terms of the session: each subject’s term scores, total so far, cumulative average, grade and position — and the overall cumulative average and position. Choose 3rd term for the whole-session result.'));
  const pk = pickers(a, q, { term: true, cls: true });
  const state = { mode: ['class', 'subject', 'pupil'].includes(q.view) ? q.view : 'class', cols: 'all', subjectId: q.subjectId || '', studentId: q.studentId || '', data: null };
  const box = h('div');
  const v = (x) => (x === null || x === undefined ? '–' : String(x));
  const signed = (x) => (x === null || x === undefined ? '–' : `${x > 0 ? '+' : ''}${x}`);
  const posTxt = (n) => (n ? ordinal(n) : '–');

  const classView = (b) => {
    const every = state.cols === 'all' && b.terms.length > 1;
    const per = every ? b.terms.length + 1 : 1;
    const head1 = h('tr', h('th', { rowspan: 2, text: 'Pos' }), h('th', { rowspan: 2, text: 'Name' }), b.subjects.map((s) => h('th.center', { colspan: per, text: s.name })),
      b.terms.length > 1 ? h('th.center', { colspan: b.terms.length, text: 'Term averages' }) : null,
      h('th', { rowspan: 2, text: 'Cum. avg' }), h('th', { rowspan: 2, text: 'Grade' }), b.terms.length > 1 ? h('th', { rowspan: 2, text: 'Change' }) : null, h('th', { rowspan: 2, text: 'Result' }));
    const head2 = h('tr', b.subjects.map(() => (every ? [...b.terms.map((t) => h('th.center.sub', { text: t.name })), h('th.center.sub', { text: 'CUM' })] : h('th.center.sub', { text: b.terms.length > 1 ? 'CUM' : 'TOT' }))),
      b.terms.length > 1 ? b.terms.map((t) => h('th.center.sub', { text: t.name })) : null);
    const body = h('tbody', b.rows.map((r) => h('tr', h('td.center', h('strong', { text: posTxt(r.cumulativePosition) })), h('td.nowrap', h('a', { href: `#/broadsheet/cumulative?view=pupil&studentId=${r.studentId}&termId=${b.termId}&classId=${b.classId}`, text: r.name })),
      r.subjects.map((s) => (every ? [...s.termTotals.map((t) => h('td.center', { text: v(t) })), h('td.center.strong', { text: v(s.average) })] : h('td.center.strong', { text: v(s.average) }))),
      b.terms.length > 1 ? r.termAverages.map((t) => h('td.center', { text: v(t) })) : null,
      h('td.center', h('strong', { text: v(r.cumulativeAverage) })), h('td.center', { text: r.grade || '' }),
      b.terms.length > 1 ? h(`td.center${r.change > 0 ? '.up' : r.change < 0 ? '.down' : ''}`, { text: signed(r.change) }) : null, h('td.center', { text: r.status }))));
    const foot = h('tfoot', h('tr', h('th'), h('th', { text: 'Class average' }), b.subjectStats.map((s) => (every ? [...s.termAverages.map((t) => h('th.center', { text: v(t) })), h('th.center', { text: v(s.average) })] : h('th.center', { text: v(s.average) }))),
      b.terms.length > 1 ? b.overall.termAverages.map((t) => h('th.center', { text: v(t) })) : null, h('th.center', { text: v(b.overall.average) }), h('th'), b.terms.length > 1 ? h('th') : null, h('th.center', { text: `${b.overall.passed} passed` })));
    return h('div.table-wrap', h('table.terminal.cum-sheet', h('thead', head1, head2), body, foot));
  };

  const subjectView = (b) => {
    const i = Math.max(0, b.subjects.findIndex((s) => s.id === state.subjectId)); const sb = b.subjects[i]; state.subjectId = sb.id; const st = b.subjectStats[i];
    const rows = b.rows.filter((r) => r.subjects[i].taken > 0).sort((x, y) => (x.subjects[i].position || 1e9) - (y.subjects[i].position || 1e9));
    const sel = h('select.input', { 'aria-label': 'Subject', on: { change: (e) => { state.subjectId = e.target.value; render(); } } }, b.subjects.map((s) => h('option', { value: s.id, text: s.name, selected: s.id === sb.id })));
    return [h('div.cum-tools.no-print', h('label.field', h('span', { text: 'Subject' }), sel)),
      h('div.stats', stat('Class cumulative average', v(st.average), sb.name, 'chart'), stat('Highest', v(st.highest), '', 'check'), stat('Lowest', v(st.lowest), '', 'activity'), stat('Passed', `${st.passed}/${st.count}`, `at ${b.passMark}% or more`, 'shield')),
      h('h3.center', { text: `${sb.name} — cumulative to ${b.termLabel}` }),
      h('div.table-wrap', h('table.terminal', h('thead', h('tr', h('th', { text: 'Pos' }), h('th', { text: 'Name' }), b.terms.map((t) => h('th.center', { text: t.label })), h('th.center', { text: 'Total so far' }), h('th.center', { text: 'Cum. avg' }), h('th.center', { text: 'Grade' }), h('th', { text: 'Remark' }))),
        h('tbody', rows.map((r) => { const s = r.subjects[i]; return h('tr', h('td.center', h('strong', { text: posTxt(s.position) })), h('td.nowrap', { text: r.name }), s.termTotals.map((t) => h('td.center', { text: v(t) })), h('td.center', { text: v(s.total) }), h('td.center', h('strong', { text: v(s.average) })), h('td.center', { text: s.grade || '' }), h('td', { text: s.remark || '' })); })),
        h('tfoot', h('tr', h('th'), h('th', { text: 'Class average' }), st.termAverages.map((t) => h('th.center', { text: v(t) })), h('th'), h('th.center', { text: v(st.average) }), h('th'), h('th'))))),
    ];
  };

  const pupilView = (b) => {
    const r = b.rows.find((x) => x.studentId === state.studentId) || b.rows[0]; state.studentId = r.studentId;
    const sel = h('select.input', { 'aria-label': 'Learner', on: { change: (e) => { state.studentId = e.target.value; render(); } } }, [...b.rows].sort((x, y) => x.name.localeCompare(y.name)).map((x) => h('option', { value: x.studentId, text: x.name, selected: x.studentId === r.studentId })));
    const chart = b.terms.length > 1 ? lineChart(b.terms.map((t, ti) => ({ label: t.label, value: r.termAverages[ti] ?? 0 })), { title: 'Term averages', fmt: (x) => `${x}%` }) : null;
    return [h('div.cum-tools.no-print', h('label.field', h('span', { text: 'Learner' }), sel), btn('Open report card', () => { location.hash = `#/report/${r.studentId}?termId=${b.termId}`; }, { ic: 'file' })),
      h('div.cum-person',
        h('div.cum-facts',
          h('div', h('span', { text: 'Cumulative average' }), h('strong', { text: r.cumulativeAverage === null ? '–' : `${r.cumulativeAverage}% · ${r.grade}` })),
          h('div', h('span', { text: 'Cumulative position' }), h('strong', { text: r.cumulativePosition ? `${ordinal(r.cumulativePosition)} of ${b.classSize}` : '–' })),
          h('div', h('span', { text: `${b.termLabel} position` }), h('strong', { text: r.thisTermPosition ? `${ordinal(r.thisTermPosition)} of ${b.classSize}` : '–' })),
          b.terms.length > 1 ? h('div', h('span', { text: 'Change since last term' }), h('strong', { text: r.change === null ? '–' : `${signed(r.change)} points` })) : null,
          h('div', h('span', { text: 'Result' }), h('strong', { text: r.status }))),
        h('p.cum-summary', { text: r.summary }),
        chart ? h('div.cum-chart', chart) : null),
      h('div.table-wrap', h('table.terminal', h('thead', h('tr', h('th', { text: 'Subject' }), b.terms.map((t) => h('th.center', { text: t.label })), h('th.center', { text: 'Total so far' }), h('th.center', { text: 'Cum. avg' }), h('th.center', { text: 'Grade' }), h('th.center', { text: 'Pos' }), h('th.center', { text: 'Class avg' }), h('th', { text: 'Remark' }))),
        h('tbody', b.subjects.map((sb, i) => { const s = r.subjects[i]; if (!s.taken) return null; return h('tr', h('td', { text: sb.name }), s.termTotals.map((t) => h('td.center', { text: v(t) })), h('td.center', { text: v(s.total) }), h('td.center', h('strong', { text: v(s.average) })), h('td.center', { text: s.grade || '' }), h('td.center', { text: posTxt(s.position) }), h('td.center', { text: v(b.subjectStats[i].average) }), h('td', { text: s.remark || '' })); })),
        h('tfoot', h('tr', h('th', { text: 'Term average' }), r.termAverages.map((t) => h('th.center', { text: t === null ? '–' : `${t}%` })), h('th.center', { text: r.marksObtained === null ? '–' : `${r.marksObtained} / ${r.marksObtainable}` }), h('th.center', { text: v(r.cumulativeAverage) }), h('th.center', { text: r.grade || '' }), h('th.center', { text: posTxt(r.cumulativePosition) }), h('th.center', { text: v(b.overall.average) }), h('th'))))),
    ];
  };

  const render = () => {
    const b = state.data; if (!b) return;
    if (!b.subjects.length || !b.rows.length) return clear(box).appendChild(empty('No results for this class yet', 'Scores entered for this class in any term of the session will be added up here.'));
    const modeTabs = tabs([{ key: 'class', label: 'Whole class' }, { key: 'subject', label: 'One subject' }, { key: 'pupil', label: 'One learner' }], (k) => { state.mode = k; render(); }, state.mode);
    const colTabs = state.mode === 'class' && b.terms.length > 1 ? h('div.seg.no-print', { role: 'group', 'aria-label': 'Columns' },
      h(`button.seg-btn${state.cols === 'all' ? '.on' : ''}`, { type: 'button', text: 'Every term', 'aria-pressed': String(state.cols === 'all'), on: { click: () => { state.cols = 'all'; render(); } } }),
      h(`button.seg-btn${state.cols === 'cum' ? '.on' : ''}`, { type: 'button', text: 'Cumulative only', 'aria-pressed': String(state.cols === 'cum'), on: { click: () => { state.cols = 'cum'; render(); } } })) : null;
    const hint = b.terms.length === 1 ? h('div.alert.alert-info.no-print', icon('help', 16), h('span', { text: 'This is the 1st term, so the cumulative result is the same as this term’s result. Choose 2nd term or 3rd term above to see the terms added up.' })) : null;
    const title = b.isAnnual ? 'Whole-session (annual) cumulative result' : b.terms.length > 1 ? `Cumulative result — 1st term to ${b.termLabel}` : `${b.termLabel} result`;
    append(clear(box), [
      h('div.page-actions.no-print', printBtn(), can('reports.export') ? btn('Excel', () => download(`/exports/cumulative${qs({ termId: b.termId, classId: b.classId, format: 'xlsx' })}`).catch(fail), { ic: 'download' }) : null,
        b.provisional ? badge('includes unpublished results', 'warn') : badge('all published', 'ok')),
      hint,
      h('div.no-print', modeTabs), colTabs,
      state.mode === 'class' ? h('div.stats.no-print', stat('Learners', b.classSize, b.class_name, 'users'), stat('Class cumulative average', v(b.overall.average), '', 'chart'), stat('Highest', v(b.overall.highest), '', 'check'), stat('Lowest', v(b.overall.lowest), '', 'activity'), stat('Passed', `${b.overall.passed}/${b.overall.count}`, `at ${b.passMark}% or more`, 'shield')) : null,
      h('div.doc.landscape', docHead([`${b.class_name} · ${b.session} session · ${b.terms.map((t) => t.label).join(' + ')}`]), h('h2', { text: `${title}${b.provisional ? ' (provisional)' : ''}` }),
        state.mode === 'class' ? classView(b) : state.mode === 'subject' ? subjectView(b) : pupilView(b),
        h('p.muted.cum-note', { text: `${b.method} Positions: two learners on the same average share a place (1-2-2-4). Pass mark ${b.passMark}%.` }))]);
  };
  const load = async ({ termId, classId }) => {
    clear(box).appendChild(spinner('Adding up the terms…'));
    try { state.data = await api.get(`/results/cumulative${qs({ termId, classId })}`); render(); } catch (e) { clear(box); fail(e); }
  };
  pk.on(load); view.append(h('div.no-print', card(null, pk.el)), box); load(pk.get());
}

// Annual Broadsheet was merged into Cumulative Results: the whole-session result IS the cumulative at 3rd term.
// Old links (#/broadsheet/annual?sessionId=…&classId=…) open Cumulative Results on that session's 3rd term.
export async function annualAsCumulative(view, p, q) {
  const a = await academic();
  const se = a.sessions.find((s) => s.id === q.sessionId) || a.sessions.find((s) => s.is_current) || a.sessions[0];
  const t3 = se && (se.terms.find((t) => t.name === '3RD') || se.terms[se.terms.length - 1]);
  history.replaceState(null, '', `#/broadsheet/cumulative?termId=${t3 ? t3.id : ''}${q.classId ? `&classId=${q.classId}` : ''}`);
  return cumulativeSheet(view, p, { ...q, termId: t3 ? t3.id : q.termId });
}
