import { h, icon } from '../core/dom.js';
import { api } from '../core/api.js';
import { session, can, workspace } from '../core/session.js';
import { stat, card, bars, empty, badge, pageHead, btn } from '../core/ui.js';
import { naira, ago, ordinal, initials, tn } from '../core/format.js';
import { fileUrl } from '../core/config.js';

const greet = () => { const hr = new Date().getHours(); return hr < 12 ? 'Good morning' : hr < 17 ? 'Good afternoon' : 'Good evening'; };
const tile = (href, ic, label, sub) => h('a.tile', { href }, h('div.stat-ic', icon(ic, 18)), h('div', h('strong', { text: label }), sub ? h('div.muted', { text: sub }) : null));

export async function dashboard(view) {
  const me = session.me; const d = await api.get('/dashboard');
  const term = d.term ? `${d.term.session} · ${tn(d.term.name)} term` : 'No current term set';
  const sc = me.school;
  const logo = sc && sc.logo_file_id ? h('img.pi-logo', { src: fileUrl(sc.logo_file_id), alt: `${sc.name} logo` }) : sc ? h('div.pi-mark', { text: initials(sc.name) }) : null;
  const first = me.user.fullName.replace(/^(Mr|Mrs|Miss|Ms|Dr|Prof|Chief)\.?\s+/i, '').split(' ')[0];
  view.appendChild(h('section.page-intro', h('div.pi-main', logo, h('div', h('h1', { text: `${greet()}, ${first}` }), h('p', { text: sc ? sc.name : 'A.B.O. School Manager' }))),
    h('div.pi-meta', h('span.meta-pill', icon('calendar', 14), term), h('span.meta-pill', icon('shield', 14), me.roles.map((r) => r.name).join(', ')), me.user.mfaEnabled ? h('span.meta-pill', icon('key', 14), 'Two-step sign-in on') : null)));
  if (me.portal === 'staff' && sc && !sc.logo_file_id && can('settings.branding')) view.appendChild(h('div.support-banner.no-print', icon('upload', 16), h('span', { text: 'Add your school logo so it shows on your sign-in page, report sheets and receipts.' }), h('a.btn.btn-sm', { href: '#/school/branding', text: 'Upload logo' })));
  if (me.portal === 'staff') return staff(view, d);
  return learner(view, d, me.portal === 'parent');
}

async function staff(view, d) {
  const c = d.cards; const cards = [];
  if (c.students) cards.push(stat('Students', c.students.total, `${c.students.male} boys · ${c.students.female} girls`, 'users'));
  if (c.staff) cards.push(stat('Staff', c.staff.total, `${c.staff.teachers} teachers`, 'building', 'blue'));
  if (c.fees) cards.push(stat('Fees collected', naira(c.fees.collected), `of ${naira(c.fees.billed)} billed`, 'money', 'gold'));
  if (c.attendanceToday) cards.push(stat('Present today', c.attendanceToday.present, `${c.attendanceToday.absent} absent`, 'check'));
  if (c.results) cards.push(stat('Sheets awaiting review', c.results.submitted, `${c.results.published} published · ${c.results.draft} draft`, 'book', c.results.submitted ? 'red' : ''));
  if (c.cbt) cards.push(stat('Live CBT exams', c.cbt.live, `${c.cbt.drafts} drafts`, 'cbt', 'blue'));
  if (c.pendingCorrections !== undefined) cards.push(stat('Pending corrections', c.pendingCorrections, 'need review', 'activity', c.pendingCorrections ? 'red' : ''));
  view.appendChild(h('div.stats', cards));
  const quick = [];
  if (can('attendance.create', 'attendance.update')) quick.push(tile('#/attendance', 'check', 'Mark attendance', 'Today’s register'));
  if (can('results.enter', 'results.enter_any')) { quick.push(tile('#/scores/ca', 'book', 'Enter CA scores', 'Continuous assessment')); quick.push(tile('#/scores/exam', 'book', 'Enter exam scores')); }
  if (can('results.approve', 'results.review')) quick.push(tile('#/results/approval', 'check', 'Approve results', c.results && c.results.submitted ? `${c.results.submitted} waiting` : 'Review queue'));
  if (can('students.create')) quick.push(tile('#/students/new', 'users', 'Add a student'));
  if (can('payments.record')) quick.push(tile('#/fees/invoices', 'money', 'Record a payment'));
  if (can('announcements.manage')) quick.push(tile('#/announcements', 'megaphone', 'Post a notice'));
  if (can('cbt.create')) quick.push(tile('#/cbt/new', 'cbt', 'Create a CBT exam'));
  if (can('results.view')) { quick.push(tile('#/broadsheet', 'grid', 'Broadsheet')); quick.push(tile('#/reports/print', 'printer', 'Print report sheets')); }
  if (can('settings.update')) quick.push(tile('#/getting-started', 'check', 'Setup checklist'));
  const left = []; const right = [];
  left.push(card('Quick actions', h('div.tiles', quick)));
  if (d.enrolmentByClass && d.enrolmentByClass.length) left.push(card('Enrolment by class', bars(d.enrolmentByClass)));
  if (d.mySubjects && d.mySubjects.length) left.push(card('My teaching load', h('div.list', d.mySubjects.map((s) => h('div.list-item', h('span', { text: `${s.class_name} · ${s.subject}` }), h('a.btn.btn-sm', { href: `#/results?classId=${s.class_id}&subjectId=${s.subject_id}`, text: 'Scores' }))))));
  if (d.myClasses && d.myClasses.length) right.push(card('My classes', h('div.list', d.myClasses.map((k) => h('div.list-item', h('span', { text: k.display_name }), k.form_teacher ? badge('form teacher', 'info') : null)))));
  right.push(card('Latest notices', d.announcements.length ? h('div.list', d.announcements.map((a) => h('a.list-item', { href: '#/announcements' }, h('span', { text: a.title }), h('small.muted', { text: ago(a.publish_at) })))) : empty('No notices yet'), can('announcements.manage') ? btn('New', () => { location.hash = '#/announcements'; }, { kind: 'ghost', ic: 'plus' }) : null));
  if (can('settings.update')) {
    try { const s = await api.get('/onboarding/status'); if (s.done < s.total) { const pr = h('div.progress', h('div')); pr.firstChild.style.width = `${Math.round(s.done / s.total * 100)}%`; right.unshift(card('Finish setting up', [h('p.muted', { text: `${s.done} of ${s.total} steps done` }), pr, h('p', h('a', { href: '#/getting-started', text: 'Open checklist →' }))])); } } catch { /* optional */ }
  }
  view.appendChild(h('div.grid.g2', h('div', left), h('div', right)));
}

function learner(view, d, parent) {
  const kids = d.children || [];
  if (!kids.length) return view.appendChild(empty(parent ? 'No children linked yet' : 'Your student record is not linked yet', 'Please contact the school office.'));
  const tiles = h('div.tiles', tile('#/my-results', 'book', parent ? 'Results' : 'My results'), parent ? null : tile('#/my-cbt', 'cbt', 'CBT exams', d.cbtOpen ? `${d.cbtOpen} open` : 'None open'),
    tile('#/my-fees', 'money', 'Fees'), tile('#/timetable', 'calendar', 'Timetable'), tile('#/messages', 'mail', 'Message a teacher'));
  view.appendChild(card(null, tiles));
  view.appendChild(h('div.grid.g2', kids.map((k) => card(`${k.first_name} ${k.last_name}`, [
    h('dl.kv', h('dt', { text: 'Class' }), h('dd', { text: k.class_name || '—' }), h('dt', { text: 'Admission no' }), h('dd', { text: k.admission_no }),
      h('dt', { text: 'Term average' }), h('dd', { text: k.result ? `${k.result.average}% (${k.result.grade || '—'})` : 'Not published yet' }),
      h('dt', { text: 'Position' }), h('dd', { text: k.result && k.result.position ? `${ordinal(k.result.position)} of ${k.result.class_size}` : '—' }),
      h('dt', { text: 'Absences this term' }), h('dd', { text: k.absences }),
      h('dt', { text: 'Outstanding fees' }), h('dd', !k.invoices ? badge('No invoices yet', 'muted') : Number(k.balance_kobo) > 0 ? badge(naira(k.balance_kobo), 'danger') : badge('Fully paid', 'ok'))),
    h('div.page-actions', h('a.btn.btn-sm', { href: `#/my-results?student=${k.id}`, text: 'View report card' }), h('a.btn.btn-sm', { href: '#/my-fees', text: 'Fees' }))]))));
  view.appendChild(card('Latest notices', d.announcements.length ? h('div.list', d.announcements.map((a) => h('a.list-item', { href: '#/announcements' }, h('span', { text: a.title }), h('small.muted', { text: ago(a.publish_at) })))) : empty('No notices yet')));
}

export async function gettingStarted(view) {
  const s = await api.get('/onboarding/status');
  view.appendChild(pageHead('Getting started', `${s.done} of ${s.total} steps complete — work through these to launch your school on A.B.O.`));
  const pr = h('div.progress', h('div')); pr.firstChild.style.width = `${Math.round(s.done / s.total * 100)}%`;
  view.appendChild(card(null, [pr, h('div.steps', s.steps.map((st, i) => h(`div.step${st.done ? '.done' : ''}`, h('span.dot', st.done ? icon('check', 14) : h('small', { text: i + 1 })), h('span', { text: st.label }), h('span.spacer'), !st.done && st.link ? h('a.btn.btn-sm', { href: st.link, text: 'Do it' }) : null)))]));
  void workspace;
}
