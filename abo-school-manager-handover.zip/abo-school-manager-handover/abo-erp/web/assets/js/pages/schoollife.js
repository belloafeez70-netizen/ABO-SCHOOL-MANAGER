// Staff clock-in, school calendar and birthdays (Phase 6). The server checks every rule — including the distance to the
// school gate, which it works out itself from the position the phone reports. This page only shows what the API allows.
import { h, clear, icon } from '../core/dom.js';
import { api, qs } from '../core/api.js';
import { can, portal } from '../core/session.js';
import { pageHead, btn, badge, card, toast, fail, confirmDialog, formDialog, simpleTable, stat, spinner, errMsg, tabs, empty } from '../core/ui.js';
import { date, dateTime } from '../core/format.js';

const time = (d) => (d ? new Date(d).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }) : '—');
const metres = (m) => (m === null || m === undefined ? '—' : m >= 1000 ? `${(m / 1000).toFixed(1)} km` : `${m} m`);
function position() {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) { reject(new Error('This device cannot share its location.')); return; }
    navigator.geolocation.getCurrentPosition((p) => resolve({ lat: p.coords.latitude, lng: p.coords.longitude, accuracy: Math.round(p.coords.accuracy) }),
      (e) => reject(new Error(e.code === 1 ? 'Location is blocked. Allow location for this site in the browser settings, then try again.' : 'Could not get your location. Turn on GPS and try again.')),
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 });
  });
}

// fingerprint / face (WebAuthn passkeys): the browser asks the phone; the SERVER checks the answer
const b64uToBuf = (s) => { const b = atob(String(s).replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((String(s).length + 3) % 4)); const u = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u.buffer; };
const bufToB64u = (buf) => { let s = ''; for (const x of new Uint8Array(buf)) s += String.fromCharCode(x); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); };
const passkeysOk = () => !!(window.PublicKeyCredential && navigator.credentials && window.isSecureContext);
async function passkeyCreate() {
  const { challengeId, options: o } = await api.post('/clock/passkeys/register-options', {});
  const cred = await navigator.credentials.create({ publicKey: { ...o, challenge: b64uToBuf(o.challenge), user: { ...o.user, id: b64uToBuf(o.user.id) },
    excludeCredentials: (o.excludeCredentials || []).map((c) => ({ ...c, id: b64uToBuf(c.id) })) } });
  const r = cred.response;
  const response = { id: cred.id, rawId: bufToB64u(cred.rawId), type: cred.type, authenticatorAttachment: cred.authenticatorAttachment || undefined, clientExtensionResults: cred.getClientExtensionResults(),
    response: { clientDataJSON: bufToB64u(r.clientDataJSON), attestationObject: bufToB64u(r.attestationObject), transports: r.getTransports ? r.getTransports() : [] } };
  const label = /Android/.test(navigator.userAgent) ? 'Android phone' : /iPhone|iPad/.test(navigator.userAgent) ? 'iPhone' : 'This device';
  return api.post('/clock/passkeys', { challengeId, response, label });
}
async function passkeyGet() {
  const { challengeId, options: o } = await api.post('/clock/passkeys/clock-options', {});
  const cred = await navigator.credentials.get({ publicKey: { ...o, challenge: b64uToBuf(o.challenge), allowCredentials: (o.allowCredentials || []).map((c) => ({ ...c, id: b64uToBuf(c.id) })) } });
  const r = cred.response;
  return { passkeyChallengeId: challengeId, passkey: { id: cred.id, rawId: bufToB64u(cred.rawId), type: cred.type, authenticatorAttachment: cred.authenticatorAttachment || undefined, clientExtensionResults: cred.getClientExtensionResults(),
    response: { clientDataJSON: bufToB64u(r.clientDataJSON), authenticatorData: bufToB64u(r.authenticatorData), signature: bufToB64u(r.signature), userHandle: r.userHandle ? bufToB64u(r.userHandle) : undefined } } };
}
const passkeyError = (e) => (e && (e.name === 'NotAllowedError' || e.name === 'AbortError') ? new Error('The fingerprint/face check was cancelled or timed out. Try again.') : e);

// ───────────────────────── staff clock-in ─────────────────────────
export async function clock(view) {
  const viewer = can('clock.view'); const manager = can('clock.manage');
  view.appendChild(pageHead('Staff Clock-in', 'Clock in when you arrive and clock out when you leave. The school can require you to be at school.',
    manager ? btn('Clock-in rules', () => rules(() => location.reload()), { ic: 'settings' }) : null));
  const mine = h('div'); view.appendChild(mine);
  if (can('clock.use')) await myCard(mine);
  if (viewer) await register(view);
}
async function myCard(box) {
  clear(box).appendChild(spinner());
  let me; try { me = await api.get('/clock/me'); } catch (e) { clear(box).appendChild(card('My clock-in', h('p.muted', { text: errMsg(e) }))); return; }
  const s = me.settings;
  const rulesTxt = [s.requireLocation ? `You must be within ${s.radiusM} m of the school.` : null, s.requireBiometric ? 'Confirm with your fingerprint or face.' : null, `Late after ${s.lateAfter}.`].filter(Boolean).join(' ');
  if (!me.staff) { clear(box).appendChild(card('My clock-in', h('p.muted', { text: 'Your account is not linked to a staff record, so you cannot clock in. The school office can link it in Staff Records.' }))); return; }
  const msg = h('p.muted', { role: 'status' });
  const act = (kind) => async (ev) => {
    const b = ev && ev.currentTarget; if (b) b.disabled = true;
    try {
      let body = {};
      if (s.requireLocation || s.hasSite) { msg.textContent = 'Getting your location…'; try { body = await position(); } catch (e) { if (s.requireLocation) throw e; } }
      body.device = (navigator.userAgentData && navigator.userAgentData.platform) || navigator.platform || null;
      if (s.requireBiometric || (me.passkeys || []).length) {
        if (!(me.passkeys || []).length) throw new Error('Set up fingerprint/face on this phone first (button below).');
        if (!passkeysOk()) throw new Error('This browser cannot do fingerprint/face checks. Use Chrome or Safari on your phone.');
        msg.textContent = 'Touch the fingerprint sensor or look at the camera…';
        try { Object.assign(body, await passkeyGet()); } catch (e) { throw passkeyError(e); }
      }
      const r = await api.post(`/clock/${kind}`, body);
      toast(kind === 'in' ? `Clocked in at ${time(r.at)}${r.late ? ' (late)' : ''}` : `Clocked out at ${time(r.at)}`);
      await myCard(box);
    } catch (e) { msg.textContent = e.message || errMsg(e); fail(e); if (b) b.disabled = false; }
  };
  const state = me.in ? (me.out ? `In at ${time(me.in.at)} · out at ${time(me.out.at)}` : `In at ${time(me.in.at)}${me.in.late ? ' (late)' : ''}`) : 'Not clocked in yet today';
  clear(box).appendChild(card('My clock-in', [
    h('div.stats', stat('Today', date(me.today), state, 'clock', me.in ? (me.in.late ? 'gold' : '') : 'red')),
    h('p.muted', { text: rulesTxt }), msg,
    h('div.page-actions', !me.in ? btn('Clock in now', act('in'), { kind: 'primary', ic: 'check' }) : null, me.in && !me.out ? btn('Clock out now', act('out'), { kind: 'primary', ic: 'clock' }) : null),
    h('div.passkey-box', h('strong', { text: 'Fingerprint / face' }), ' ',
      h('span.muted', { text: (me.passkeys || []).length ? `set up on ${(me.passkeys || []).length} device(s)` : 'not set up yet' }),
      passkeysOk() ? btn((me.passkeys || []).length ? 'Add this phone too' : 'Set up fingerprint/face on this phone', async (ev) => {
        const btnEl = ev.currentTarget; btnEl.disabled = true; msg.textContent = 'Touch the fingerprint sensor or look at the camera…';
        try { await passkeyCreate(); toast('Fingerprint/face is ready for clock-in'); await myCard(box); } catch (e) { const x = passkeyError(e); msg.textContent = x.message || errMsg(x); fail(x); btnEl.disabled = false; }
      }, { kind: 'ghost' }) : h('small.muted', { text: ' (needs Chrome or Safari on a phone with fingerprint/face unlock, over https)' }),
      (me.passkeys || []).map((k) => h('div.muted', h('span', { text: `${k.device_label || 'Device'} · added ${date(k.created_at)}${k.last_used_at ? ` · last used ${date(k.last_used_at)}` : ''} ` }),
        btn('Remove', async () => { if (!(await confirmDialog({ title: 'Remove this device?', message: 'It will no longer be able to clock in with fingerprint/face.', confirmLabel: 'Remove', danger: true }))) return; try { await api.del(`/clock/passkeys/${k.id}`); toast('Removed'); myCard(box); } catch (e) { fail(e); } }, { kind: 'ghost' })))),
    me.entries.length ? h('details', h('summary', { text: 'My last clock-ins' }), simpleTable([{ label: 'Day', render: (r) => date(r.day) }, { label: 'In / out', render: (r) => (r.kind === 'in' ? 'In' : 'Out') },
      { label: 'Time', render: (r) => time(r.at) }, { label: 'Late', render: (r) => (r.kind === 'in' ? (r.late ? badge('late') : badge('on time', 'ok')) : '') }, { label: 'Distance', render: (r) => metres(r.distance_m) }, { label: 'Fingerprint/face', render: (r) => (r.verified_by ? badge('confirmed', 'ok') : '—') }], me.entries)) : null]));
}
async function register(view) {
  const box = h('div'); const day = h('input.input', { type: 'date', 'aria-label': 'Day' });
  const load = async () => {
    clear(box).appendChild(spinner());
    try {
      const r = await api.get(`/clock/register${qs({ date: day.value || undefined })}`);
      if (!day.value) day.value = r.date;
      clear(box).append(h('div.stats', stat('Staff', r.summary.staff, '', 'users'), stat('On time', r.summary.present, '', 'check'), stat('Late', r.summary.late, '', 'clock', r.summary.late ? 'gold' : ''),
        stat(r.date === r.today ? 'Not in yet' : 'Absent', r.summary.notIn, '', 'x', r.summary.notIn ? 'red' : '')),
      simpleTable([{ key: 'full_name', label: 'Name' }, { label: 'Role', render: (x) => x.designation || (x.is_teacher ? 'Teacher' : 'Staff') },
        { label: 'Status', render: (x) => badge({ present: 'on time', late: 'late', not_in: 'not in yet', absent: 'absent' }[x.status], { present: 'ok', late: 'warn', not_in: 'muted', absent: 'danger' }[x.status]) },
        { label: 'In', render: (x) => time(x.in_at) }, { label: 'Out', render: (x) => time(x.out_at) }, { label: 'Distance (in)', render: (x) => metres(x.in_distance_m) }], r.items, 'No staff records yet'));
    } catch (e) { clear(box).appendChild(h('p.muted', { text: errMsg(e) })); }
  };
  day.addEventListener('change', load);
  view.appendChild(card('Clock-in register', [h('div.range-bar', h('label.muted', { text: 'Day' }), day), box]));
  await load();
}
async function rules(done) {
  const cur = await api.get('/clock/settings');
  const vals = { requireLocation: cur.requireLocation, requireBiometric: cur.requireBiometric, siteLat: cur.siteLat ?? '', siteLng: cur.siteLng ?? '', radiusM: cur.radiusM, lateAfter: cur.lateAfter };
  let dlg = null;
  const here = h('button.btn', { type: 'button', text: '📍 Use my location (stand at the school gate)', on: { click: async () => {
    try { const p = await position(); const f = here.closest('form'); f.querySelector('[name=siteLat]').value = p.lat.toFixed(6); f.querySelector('[name=siteLng]').value = p.lng.toFixed(6); toast(`Location set (accuracy about ${p.accuracy} m)`); } catch (e) { toast(e.message, 'err', 6000); }
  } } });
  dlg = formDialog({ title: 'Clock-in rules', intro: 'The server checks these rules on every clock-in. GPS on a phone can be wrong by 10–50 m, so a distance of 100–200 m works best.',
    fields: [{ name: 'requireLocation', label: 'Staff must be at school to clock in', type: 'checkbox' },
      { name: 'requireBiometric', label: 'Staff must confirm with fingerprint or face (each person sets up their own phone once)', type: 'checkbox' },
      { name: 'siteLat', label: 'School latitude', type: 'number', step: 'any' }, { name: 'siteLng', label: 'School longitude', type: 'number', step: 'any' },
      { name: 'radiusM', label: 'Allowed distance (metres)', type: 'number', min: 20, maxv: 5000 }, { name: 'lateAfter', label: 'Late after', type: 'time' }],
    values: vals, submitLabel: 'Save rules',
    onSubmit: (v) => api.put('/clock/settings', { requireLocation: !!v.requireLocation, requireBiometric: !!v.requireBiometric, siteLat: v.siteLat ?? null, siteLng: v.siteLng ?? null, radiusM: v.radiusM || 150, lateAfter: (v.lateAfter || '08:00').slice(0, 5) }) });
  setTimeout(() => { const f = document.querySelector('.modal form .form-grid'); if (f) f.prepend(here); }, 0);
  if (await dlg) { toast('Clock-in rules saved'); done(); }
}

// ───────────────────────── calendar ─────────────────────────
const KINDS = [{ value: 'holiday', label: 'Holiday' }, { value: 'exam', label: 'Exams / tests' }, { value: 'event', label: 'Event' }, { value: 'meeting', label: 'Meeting' }, { value: 'other', label: 'Other' }];
const kindTone = { holiday: 'ok', exam: 'warn', event: 'info', meeting: 'muted', other: 'muted' };
export async function calendar(view) {
  const learnerView = ['student', 'parent'].includes(portal());
  const box = h('div'); let start = new Date(); start = new Date(start.getFullYear(), start.getMonth(), 1);
  const fmt = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const label = h('strong');
  const evForm = (e) => formDialog({ title: e ? 'Change event' : 'Add to the calendar',
    fields: [{ name: 'title', label: 'Title', required: true, max: 160, full: true }, { name: 'kind', label: 'Type', type: 'select', options: KINDS, placeholder: false },
      { name: 'audience', label: 'Who can see it', type: 'select', placeholder: false, options: [{ value: 'all', label: 'Everyone (staff, pupils, parents)' }, { value: 'staff', label: 'Staff only' }] },
      { name: 'startsOn', label: 'From', type: 'date', required: true }, { name: 'endsOn', label: 'To (leave empty for one day)', type: 'date' },
      { name: 'description', label: 'Details', type: 'textarea', max: 2000, full: true }],
    values: e ? { title: e.title, kind: e.kind, audience: e.audience, startsOn: e.starts_on, endsOn: e.ends_on, description: e.description } : { kind: 'event', audience: 'all', startsOn: fmt(new Date()) },
    onSubmit: (v) => (e ? api.patch(`/calendar/${e.id}`, v) : api.post('/calendar', v)) });
  const load = async () => {
    const end = new Date(start.getFullYear(), start.getMonth() + 3, 0);
    label.textContent = `${start.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' })} – ${end.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' })}`;
    clear(box).appendChild(spinner());
    try {
      const r = await api.get(`/calendar${qs({ from: fmt(start), to: fmt(end) })}`);
      if (!r.items.length) { clear(box).appendChild(empty('Nothing on the calendar for these months', r.canManage ? 'Use “Add event” to add holidays, exams, PTA meetings and more.' : undefined)); return; }
      const months = new Map();
      for (const e of r.items) { const k = e.starts_on.slice(0, 7); if (!months.has(k)) months.set(k, []); months.get(k).push(e); }
      const item = (e) => h('li.cal-item',
        h('div.cal-date', { text: e.starts_on === e.ends_on ? date(e.starts_on) : `${date(e.starts_on)} – ${date(e.ends_on)}` }),
        h('div.cal-body', h('strong', { text: e.title }), ' ', badge((KINDS.find((x) => x.value === e.kind) || {}).label || e.kind, kindTone[e.kind]),
          e.audience === 'staff' ? badge('staff only', 'muted') : null, e.description ? h('div.muted', { text: e.description }) : null),
        r.canManage ? h('div.cal-act',
          btn('Change', async () => { if (await evForm(e)) { toast('Event saved'); load(); } }, { kind: 'ghost' }),
          btn('Remove', async () => {
            if (!(await confirmDialog({ title: 'Remove this event?', message: e.title, confirmLabel: 'Remove', danger: true }))) return;
            try { await api.del(`/calendar/${e.id}`); toast('Event removed'); load(); } catch (x) { fail(x); }
          }, { kind: 'ghost' })) : null);
      const monthName = (k) => new Date(k + '-01T00:00:00').toLocaleDateString('en-GB', { month: 'long', year: 'numeric' });
      clear(box).append(...[...months].map(([k, list]) => card(monthName(k), h('ul.cal-list', list.map(item)))));
    } catch (e) { clear(box).appendChild(h('p.muted', { text: errMsg(e) })); }
  };
  view.appendChild(pageHead('School Calendar', learnerView ? 'Holidays, exams and school events.' : 'Holidays, exams, meetings and events for the whole school.',
    can('calendar.manage') ? btn('Add event', async () => { if (await evForm(null)) { toast('Event added'); load(); } }, { kind: 'primary', ic: 'plus' }) : null));
  view.appendChild(h('div.range-bar', btn('← Earlier', () => { start = new Date(start.getFullYear(), start.getMonth() - 1, 1); load(); }), label,
    btn('Later →', () => { start = new Date(start.getFullYear(), start.getMonth() + 1, 1); load(); })));
  view.appendChild(box);
  await load();
}

// ───────────────────────── birthdays ─────────────────────────
export async function birthdays(view) {
  view.appendChild(pageHead('Birthdays', 'Pupils and staff with birthdays coming up. Add dates of birth in the student and staff records.'));
  const box = h('div'); let days = 7;
  const load = async () => {
    clear(box).appendChild(spinner());
    try {
      const r = await api.get(`/birthdays?days=${days}`);
      const when = (x) => (x.inDays === 0 ? h('strong', { text: '🎂 Today' }) : x.inDays === 1 ? 'Tomorrow' : `${date(x.date)} (in ${x.inDays} days)`);
      clear(box).append(h('div.stats', stat('Today', r.counts.today, '', 'gift', r.counts.today ? 'gold' : ''), stat('Pupils', r.counts.students, `next ${days} days`, 'graduation'), stat('Staff', r.counts.staff, `next ${days} days`, 'briefcase')),
        card(null, simpleTable([{ label: 'When', render: when }, { key: 'name', label: 'Name' }, { label: 'Who', render: (x) => (x.kind === 'student' ? 'Pupil' : 'Staff') },
          { label: 'Class / role', render: (x) => x.detail || '—' }, { label: 'Turns', cls: 'num', render: (x) => String(x.turns) }], r.items, `No birthdays in the next ${days} days`)));
    } catch (e) { clear(box).appendChild(h('p.muted', { text: errMsg(e) })); }
  };
  view.appendChild(tabs([{ key: '0', label: 'Today' }, { key: '7', label: 'Next 7 days' }, { key: '31', label: 'Next 31 days' }], (k) => { days = Number(k); load(); }, '7'));
  view.appendChild(box);
  await load();
}
