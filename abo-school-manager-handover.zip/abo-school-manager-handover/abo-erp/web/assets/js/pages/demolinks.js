// Demo Links (028) — platform owner only. A demo can only be opened with a link made here: open it on your own phone /
// laptop, or send it to a school on WhatsApp. Each link expires and has a number of uses; it can be cancelled.
import { h, clear } from '../core/dom.js';
import { api } from '../core/api.js';
import { pageHead, btn, badge, card, toast, fail, confirmDialog, formDialog, simpleTable, spinner, errMsg, modal } from '../core/ui.js';
import { dateTime } from '../core/format.js';

const TONE = { active: 'ok', 'used up': 'muted', expired: 'muted', cancelled: 'danger' };
const HOURS = [{ value: '1', label: '1 hour' }, { value: '3', label: '3 hours' }, { value: '24', label: '1 day' }, { value: '72', label: '3 days' }, { value: '168', label: '7 days' }];

async function copy(text) {
  try { await navigator.clipboard.writeText(text); toast('Link copied'); }
  catch { const t = h('textarea', { text }); document.body.appendChild(t); t.select(); try { document.execCommand('copy'); toast('Link copied'); } catch { toast('Copy the link by hand', 'err'); } t.remove(); }
}
function showLink(r, schools) {
  const school = r.school_key ? (schools.find((s) => s.key === r.school_key) || {}).name : 'either demo school';
  const msg = `Hello${r.label ? ` ${r.label}` : ''}, here is your 5-minute demo of A.B.O. School Manager (${school}). Tap the link, then choose who you want to be:\n${r.link}\n\nA.B.O. Edu Consultant · 0805 144 6681`;
  const box = h('input.input.demo-link-box', { type: 'text', value: r.link, readonly: true, 'aria-label': 'Demo link', on: { focus: (e) => e.target.select() } });
  const m = modal({ title: 'Demo link ready', wide: true, body: [
    h('p', { text: `For ${r.label || 'anyone'} · ${school} · ${r.max_uses} use${r.max_uses === 1 ? '' : 's'} · ends ${dateTime(r.expires_at)}` }), box,
    h('p.muted.small', { text: 'This is the only time the full link is shown. Keep it private: anyone with it can open the demo until it ends or is used up.' }),
    h('p.muted.small', { text: 'Opening it in this browser signs you out of the console. Open it on your phone, in another browser, or in a private window.' })],
  actions: [h('button.btn', { text: 'Close', on: { click: () => m.close() } }),
    h('a.btn', { href: `https://wa.me/?text=${encodeURIComponent(msg)}`, target: '_blank', rel: 'noopener', text: 'Send by WhatsApp' }),
    h('button.btn.btn-primary', { text: 'Copy link', on: { click: () => copy(r.link) } })] });
}

export async function demoLinks(view, p, q = {}) {
  const box = h('div'); let data = null;
  const makeBtn = btn('Make a demo link', async () => {
      const schools = (data && data.schools) || [];
      const r = await formDialog({ title: 'Make a demo link', submitLabel: 'Make link', fields: [
        { name: 'label', label: 'Who is it for? (optional, e.g. school or person)', max: 120, full: true },
        { name: 'school', label: 'Demo school', type: 'select', placeholder: 'Let them choose', options: schools.map((s) => ({ value: s.key, label: `${s.name} — ${s.kind}` })) },
        { name: 'hours', label: 'Link works for', type: 'select', placeholder: false, options: HOURS },
        { name: 'uses', label: 'How many demos it can open', type: 'number', min: 1, maxv: 50, required: true }],
      values: { hours: '24', uses: 1 },
      onSubmit: (v) => api.post('/platform/demo/links', { label: v.label || null, school: v.school || null, hours: Number(v.hours), uses: Math.round(Number(v.uses)) }) });
      if (r) { showLink(r, schools); load(); }
    }, { kind: 'primary', ic: 'plus' });
  view.appendChild(pageHead('Demo Links', 'Only you can open a demo. Make a link, open it on your phone or laptop, or send it to a school. Each demo lasts 5 minutes and is wiped afterwards.', makeBtn));
  view.appendChild(box);
  async function load() {
    clear(box).appendChild(spinner());
    try {
      data = await api.get('/platform/demo/links');
      const parts = [];
      if (!data.demoEnabled) parts.push(h('div.alert.alert-warn', h('span', { text: 'Demos are switched off. Links still work only after you switch demos on in ' }), h('a', { href: '#/platform/billing', text: 'Payments & Plans › Settings' }), h('span', { text: '.' })));
      parts.push(card('Your demo links', simpleTable([
        { label: 'For', render: (x) => h('div', h('strong', { text: x.label || '—' }), h('div.muted', { text: `made ${dateTime(x.created_at)}` })) },
        { label: 'Demo school', render: (x) => (x.school_key ? (data.schools.find((s) => s.key === x.school_key) || {}).name || x.school_key : 'Their choice') },
        { label: 'Used', cls: 'num', render: (x) => `${x.uses} / ${x.max_uses}` },
        { label: 'Ends', render: (x) => dateTime(x.expires_at) },
        { label: 'Last opened', render: (x) => (x.last_used_at ? dateTime(x.last_used_at) : '—') },
        { label: 'Status', render: (x) => badge(x.status, TONE[x.status]) },
        { label: '', render: (x) => (x.status === 'active' ? btn('Cancel', async () => {
          if (!(await confirmDialog({ title: 'Cancel this demo link?', message: `${x.label || 'This link'} will stop working at once.`, confirmLabel: 'Cancel link', danger: true }))) return;
          try { await api.post(`/platform/demo/links/${x.id}/cancel`); toast('Link cancelled'); load(); } catch (e) { fail(e); }
        }, { kind: 'ghost' }) : null) }], data.items, 'No demo link yet. Press "Make a demo link".')));
      clear(box).append(...parts);
    } catch (e) { clear(box).appendChild(h('p.muted', { text: errMsg(e) })); }
  }
  await load();
  if (q.new) { try { history.replaceState(null, '', '#/platform/demo'); } catch { /* */ } makeBtn.click(); }      // from "Make a demo link" on the home page
}
