import { h, clear } from '../core/dom.js';
import { api, qs, download } from '../core/api.js';
import { can } from '../core/session.js';
import { pageHead, btn, formDialog, badge, card, toast, fail, confirmDialog, simpleTable, dataTable, empty, field, stat } from '../core/ui.js';
import { dateTime, date, cap } from '../core/format.js';
import { academic } from './people.js';

export async function documents(view) {
  const d = await api.get('/documents');
  view.appendChild(pageHead('Document archive', 'Private files — downloads are authorised per request and sensitive downloads are audited.', can('documents.upload') ? btn('Upload document', async () => {
    const st = await api.get('/students?pageSize=100');
    const r = await formDialog({ title: 'Upload document', fields: [{ name: 'title', label: 'Title', required: true }, { name: 'category', label: 'Category', type: 'select', options: ['general', 'policy', 'admission', 'medical', 'certificate', 'lesson_note', 'lesson_plan', 'report'] },
      { name: 'ownerType', label: 'Belongs to', type: 'select', placeholder: false, options: [{ value: 'school', label: 'School' }, { value: 'student', label: 'A student' }] }, { name: 'ownerId', label: 'Student (if applicable)', type: 'select', options: st.items.map((s) => ({ value: s.id, label: `${s.last_name} ${s.first_name}` })) },
      { name: 'visibility', label: 'Visibility', type: 'select', placeholder: false, options: [{ value: 'staff', label: 'Staff only' }, { value: 'owner_and_staff', label: 'Staff + the student/parents' }] }, { name: 'file', label: 'File (PDF, Word, Excel, image · max 5 MB)', type: 'file', required: true, accept: '.pdf,.docx,.xlsx,.pptx,image/png,image/jpeg,image/webp' }],
    values: { ownerType: 'school', visibility: 'staff', category: 'general' },
    onSubmit: (v) => { if (!v.file) throw Object.assign(new Error('Choose a file'), { details: { field: 'file' } }); const fd = new FormData(); for (const k of ['title', 'category', 'ownerType', 'visibility']) fd.append(k, v[k] || ''); if (v.ownerType === 'student' && v.ownerId) fd.append('ownerId', v.ownerId); fd.append('file', v.file); return api.post('/documents', fd); } });
    if (r) { toast('Uploaded'); clear(view); documents(view); }
  }, { kind: 'primary', ic: 'upload' }) : null));
  view.appendChild(card(null, simpleTable([{ key: 'title', label: 'Title' }, { label: 'Category', render: (x) => cap(x.category) }, { label: 'Owner', render: (x) => cap(x.owner_type) }, { key: 'original_name', label: 'File' }, { label: 'Size', render: (x) => `${Math.ceil(x.size_bytes / 1024)} KB` },
    { label: 'Scan', render: (x) => badge(x.scan_status) }, { label: 'Uploaded', render: (x) => date(x.created_at) },
    { label: '', render: (x) => h('div.page-actions', btn('Download', () => download(`/files/${x.file_id}`, x.original_name).catch(fail), { kind: 'ghost', ic: 'download' }), can('documents.delete') ? btn('', async () => { if (await confirmDialog({ title: 'Delete document?', danger: true })) { await api.del(`/documents/${x.id}`); clear(view); documents(view); } }, { kind: 'ghost', ic: 'x', title: 'Delete' }) : null) }], d.items, 'No documents yet')));
}
export async function downloadFile(view, p) { view.appendChild(card('Your file is ready', [h('p.muted', { text: 'Downloads are authorised and logged.' }), btn('Download', () => download(`/files/${p.id}`).catch(fail), { kind: 'primary', ic: 'download' })])); }

const KINDS = [{ key: 'students', label: 'Students', perm: 'students.create' }, { key: 'staff', label: 'Staff', perm: 'staff.create' }, { key: 'guardians', label: 'Parents', perm: 'guardians.manage' }, { key: 'classes', label: 'Classes & arms', perm: 'academic.manage' }, { key: 'subjects', label: 'Subjects', perm: 'academic.manage' }, { key: 'scores', label: 'Scores (draft sheets)', perm: 'results.enter_any' }];
// reusable import card (Import & export page, Student Import page)
export function importCard({ only, title = 'Import', intro } = {}) {
  const kinds = KINDS.filter((k) => can(k.perm) && (!only || only.includes(k.key)));
  const kind = field({ name: 'kind', label: 'What are you importing?', type: 'select', placeholder: false, options: kinds.map((k) => ({ value: k.key, label: k.label })) });
  if (kinds.length === 1) kind.hidden = true;
  const file = field({ name: 'file', label: 'CSV or Excel (.xlsx) file · max 5,000 rows', type: 'file', accept: '.csv,.xlsx' });
  const out = h('div');
  return card(title, [intro ? h('p.muted', { text: intro }) : null, h('div.form-grid', kind, file), h('div.page-actions', btn('Download template', () => download(`/imports/templates/${kind._get()}.csv`).catch(fail), { ic: 'download' }),
    btn('Preview import', async () => {
      const f = file._get(); if (!f) return toast('Choose a file first', 'err');
      const fd = new FormData(); fd.append('file', f);
      try {
        const r = await api.post(`/imports/${kind._get()}/preview`, fd);
        clear(out).append(h('div.stats', stat('Rows', r.totalRows, '', 'file'), stat('Valid', r.validRows, 'will be imported', 'check'), stat('Problems', r.errorCount, 'rows skipped', 'x', r.errorCount ? 'red' : '')),
          r.errors.length ? simpleTable([{ key: 'row', label: 'Row' }, { key: 'field', label: 'Column' }, { key: 'message', label: 'Problem' }], r.errors) : h('p', { text: 'No problems found.' }),
          h('div.page-actions', r.errorCount ? btn('Download error report', () => download(`/imports/${r.importId}/errors.csv`).catch(fail), { ic: 'download' }) : null,
            r.validRows ? btn(`Import ${r.validRows} valid rows`, async () => { try { const c = await api.post(`/imports/${r.importId}/commit`); toast(`Imported ${c.imported} rows`); clear(out); } catch (e) { fail(e); } }, { kind: 'primary' }) : null));
      } catch (e) { fail(e); }
    }, { kind: 'primary', ic: 'upload' })), out]);
}
export async function data(view) {
  const a = await academic();
  view.appendChild(pageHead('Import & export', 'Bulk-load data from CSV/Excel with a validated preview, and export reports. Every export is permission-checked and audited.'));
  if (can('imports.run')) view.appendChild(importCard());
  if (can('reports.export')) {
    const term = field({ name: 'termId', label: 'Term (for broadsheet/invoices/attendance)', type: 'select', options: a.sessions.flatMap((s) => s.terms.map((t) => ({ value: t.id, label: `${s.name} · ${t.name}` }))) });
    const cls = field({ name: 'classId', label: 'Class (optional; required for broadsheet)', type: 'select', options: a.classes.map((c) => ({ value: c.id, label: c.display_name })) });
    const sets = [['students', 'Students', 'students.view'], ['staff', 'Staff', 'staff.view'], ['guardians', 'Parents', 'guardians.view'], ['broadsheet', 'Broadsheet', 'results.view'], ['invoices', 'Invoices', 'fees.view'], ['payments', 'Payments', 'fees.view'], ['attendance', 'Attendance', 'attendance.view'], ['audit', 'Audit log', 'audit_logs.view']].filter((x) => can(x[2]));
    view.appendChild(card('Export', [h('div.form-grid', term, cls), simpleTable([{ label: 'Dataset', render: (x) => x[1] }, { label: '', render: (x) => h('div.page-actions', btn('CSV', () => download(`/exports/${x[0]}${qs({ format: 'csv', termId: term._get(), classId: cls._get() })}`).catch(fail), { kind: 'ghost', ic: 'download' }), btn('Excel', () => download(`/exports/${x[0]}${qs({ format: 'xlsx', termId: term._get(), classId: cls._get() })}`).catch(fail), { kind: 'ghost', ic: 'download' }),
      btn('Large (background)', async () => { try { const r = await api.get(`/exports/${x[0]}${qs({ format: 'xlsx', termId: term._get(), classId: cls._get(), async: true })}`); toast('Export queued — you will get a notification when it is ready.'); void r; } catch (e) { fail(e); } }, { kind: 'ghost' })) }], sets)]));
  }
}
export async function migrate(view) {
  view.appendChild(pageHead('Legacy migration', 'Move data from the old offline app (its “Backup” JSON file) into this secure server — with a preview first.'));
  const file = field({ name: 'file', label: 'Legacy backup (.json)', type: 'file', accept: 'application/json,.json' });
  const out = h('div');
  // 027: when the offline edition runs on the same web address (abosch.netlify.app/offline/), its data is already in
  // this browser — offer it directly, no backup file needed. Nothing leaves the device until "Commit" is pressed.
  let picked = null; let previewBtn = null;
  const found = [];
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (!/^broadsheetData_/.test(k) || k === 'broadsheetData_pricing') continue;
      const raw = localStorage.getItem(k); if (!raw || raw.length < 20) continue;
      let o = null; try { o = JSON.parse(raw); } catch { continue; }
      if (!o || !o.schoolData || !o.schoolData.erp) continue;
      const L = o.schoolData.erp.learners || {};
      const n = Object.values(L).reduce((a, x) => a + (Array.isArray(x) ? x.length : 0), 0);
      found.push({ key: k, raw, name: o.schoolData.name || k.replace(/^broadsheetData_/, ''), learners: n, classes: Object.keys(L).length });
    }
  } catch { /* storage blocked */ }
  if (found.length) {
    view.append(card('Found on this device: data from the offline app', [
      h('p.muted', { text: 'The offline app was used in this browser. Choose a school to preview moving it here — nothing is changed until you press "Commit migration".' }),
      simpleTable([{ label: 'School', render: (x) => h('strong', { text: x.name }) }, { label: 'Classes', cls: 'num', render: (x) => String(x.classes) }, { label: 'Learners', cls: 'num', render: (x) => String(x.learners) },
        { label: '', render: (x) => btn('Preview moving this school', () => { picked = new File([x.raw], 'offline-app-data.json', { type: 'application/json' }); if (previewBtn) previewBtn.click(); }, { kind: 'primary' }) }], found)]));
  }
  view.append(card('How it works', [h('ol', ['In the old app, open Print Centre → “Full backup” (or the Backup button) on each device/class and download the JSON.', 'Upload it here and review the preview (classes, learners, scores, CBT, and old newsletters — they arrive as draft announcements).', 'Commit. Scores go into DRAFT sheets for review — nothing is auto-published.', 'Issue secure access codes to teachers/students from Users & access (old Login IDs had no passwords and are not imported).'].map((t) => h('li', { text: t }))),
    h('p.muted', { text: 'For safety, AI API keys, bank/pricing settings and parent messages in old backups are ignored.' }), file, h('div.page-actions', (previewBtn = btn('Preview migration', async () => {
      const f = picked || file._get(); picked = null; if (!f) return toast('Choose the backup file', 'err');
      const fd = new FormData(); fd.append('file', f);
      try {
        const r = await api.post('/migration/legacy/preview', fd); let layoutBox = null;
        clear(out).append(card('Preview', [h('div.stats', stat('Classes', r.counts.classes, r.classes.map((c) => c.label).join(', '), 'grid'), stat('Learners', r.counts.students, '', 'users'), stat('Score rows', r.counts.scoreRows, '', 'book'), stat('CBT exams', r.counts.cbtExams, '', 'cbt'), stat('Passport photos', r.counts.photos || 0, r.counts.logo ? '+ school logo' : '', 'user')),
          r.warnings.length ? h('ul', r.warnings.map((w) => h('li', { text: w }))) : null,
          (layoutBox = r.layout && !r.layout.same ? h('input', { type: 'checkbox', id: 'adoptLayout', checked: true }) : null) ? h('label.check', [layoutBox, ' Use the offline score layout (' + r.layout.offline.map((x) => `${x.label} ${x.max}`).join(' + ') + ') so every score comes in']) : null,
          btn('Commit migration', async () => {
            if (!(await confirmDialog({ title: 'Import this data?', message: 'This runs in one transaction — all or nothing.' }))) return;
            try {
              const adopt = !!(layoutBox && layoutBox.checked);
              // passport photos / logo: send the same file again so the server can take the pictures from it
              let c;
              if (r.counts.photos || r.counts.logo) { const fd2 = new FormData(); fd2.append('adoptLayout', String(adopt)); fd2.append('file', f); c = await api.post(`/migration/legacy/${r.importId}/commit`, fd2); }
              else c = await api.post(`/migration/legacy/${r.importId}/commit`, { adoptLayout: adopt });
              const rc = c.reconciliation || {};
              toast(`Migrated ${c.students} learners, ${c.scores} subject scores`);
              clear(out).appendChild(card('Done — check the numbers', [h('div.stats', stat('Learners in the file', rc.learnersInFile ?? '—', '', 'users'), stat('Brought in', c.students, '', 'users'), stat('Already here (skipped)', c.skippedExisting || 0, '', 'users'), stat('Same number twice (skipped)', c.skippedDuplicateInFile || 0, '', 'users')),
                h('p', { text: rc.balanced ? '✔ Every learner in the file is accounted for.' : '✖ The numbers do not add up.' }),
                c.scorePartsNotImported ? h('p', { text: `${c.scorePartsNotImported} score part(s) did not match this school's score layout and were not brought in.` }) : null,
                c.photos || c.logo ? h('p', { text: `${c.photos || 0} passport photo(s) brought in${c.logo ? ', and the school logo' : ''}.` }) : null,
                h('details', [h('summary', { text: 'Full details' }), h('pre.code-box', { text: JSON.stringify(c, null, 2) })])]));
            } catch (e) { fail(e); }
          }, { kind: 'primary' })]));
      } catch (e) { fail(e); }
    }, { kind: 'primary' })))]), out);
}
export async function audit(view) {
  view.appendChild(pageHead('Audit log', 'Tamper-evident, append-only record of sensitive actions. Normal administrators cannot edit or delete it.', btn('Verify integrity', async () => { try { const r = await api.get('/audit/verify'); r.ok ? toast(`Hash chain intact — ${r.checked} entries verified`) : toast(`TAMPERING DETECTED at entry #${r.first_bad_seq}`, 'err', 12000); } catch (e) { fail(e); } }, { kind: 'primary', ic: 'shield' }), can('reports.export') ? btn('Export', () => download('/exports/audit?format=xlsx').catch(fail), { ic: 'download' }) : null));
  view.appendChild(dataTable({ columns: [{ key: 'seq', label: '#', cls: 'num' }, { label: 'Time', render: (x) => dateTime(x.created_at) }, { key: 'actor_login', label: 'Actor' }, { label: 'Action', render: (x) => h('span.mono', { text: x.action }) }, { label: 'Resource', render: (x) => (x.resource_type ? `${x.resource_type}` : '—') },
    { label: 'Result', render: (x) => (x.success ? badge('ok', 'ok') : badge('failed', 'danger')) }, { key: 'ip', label: 'IP' }, { label: 'Details', render: (x) => h('small.mono', { text: JSON.stringify(x.metadata).slice(0, 120) }) }],
  filters: [{ name: 'action', label: 'Area', placeholder: 'All actions', options: ['auth', 'users', 'roles', 'students', 'results', 'fees', 'cbt', 'data', 'files', 'school', 'platform'].map((x) => ({ value: x + '.', label: cap(x) })) }], load: (o) => api.get('/audit' + qs(o)), pageSize: 50 }));
}
export async function securityEvents(view) {
  view.appendChild(pageHead('Security events', 'Lockouts, new-device sign-ins, role changes, CSRF blocks and support access for your school.'));
  view.appendChild(card('Security events', dataTable({ columns: [{ label: 'Time', render: (x) => dateTime(x.created_at) }, { label: 'Event', render: (x) => cap(x.kind) }, { label: 'Severity', render: (x) => badge(x.severity) }, { key: 'full_name', label: 'User' }, { key: 'ip', label: 'IP' }, { label: 'Details', render: (x) => h('small.mono', { text: JSON.stringify(x.detail).slice(0, 100) }) }], load: (o) => api.get('/security/events' + qs(o)) })));
  view.appendChild(card('Sign-in activity', dataTable({ columns: [{ label: 'Time', render: (x) => dateTime(x.created_at) }, { key: 'login_attempt', label: 'Login ID' }, { key: 'full_name', label: 'User' }, { label: 'Result', render: (x) => (x.success ? badge('success', 'ok') : badge(x.reason, 'danger')) }, { key: 'ip', label: 'IP' }],
    filters: [{ name: 'failedOnly', label: 'Show', placeholder: 'All sign-ins', options: [{ value: 'true', label: 'Failures only' }] }], load: (o) => api.get('/security/login-events' + qs(o)) })));
}
