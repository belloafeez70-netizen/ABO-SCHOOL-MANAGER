import { h, clear, icon } from '../core/dom.js';
import { api } from '../core/api.js';
import { can, session } from '../core/session.js';
import { pageHead, btn, formDialog, badge, card, toast, fail, confirmDialog, simpleTable, form, field } from '../core/ui.js';
import { dateTime, ago } from '../core/format.js';
import { mfaEnrol } from './auth.js';

export async function school(view) {
  const d = await api.get('/school'); const edit = can('settings.update');
  const s = d.school; const st = d.settings;
  view.appendChild(pageHead('Settings', 'Assessment components, grading scales, results workflow and security policy.'));
  view.appendChild(h('div.tiles.no-print', [['#/school/profile', 'building', 'School profile & branches', s.name], ['#/school/branding', 'upload', 'Logo & branding', 'Logo and school colour'], ['#/school/head', 'users', 'Principal / head', 'Name and signature on report sheets'], ['#/reports/templates', 'file', 'Result templates', 'Report sheet layout']]
    .map(([href, ic, label, sub]) => h('a.tile', { href }, h('div.stat-ic', icon(ic, 18)), h('div', h('strong', { text: label }), h('div.muted', { text: sub }))))));
  // assessment components
  const comps = st.assessment_components;
  const compRows = comps.map((c) => ({ key: h('input.input', { value: c.key, disabled: !edit, 'aria-label': 'key' }), label: h('input.input', { value: c.label, disabled: !edit, 'aria-label': 'label' }), max: h('input.input', { type: 'number', value: c.max, disabled: !edit, 'aria-label': 'maximum' }) }));
  const compTbl = h('tbody', compRows.map((r) => h('tr', h('td', r.key), h('td', r.label), h('td', r.max))));
  view.appendChild(card('Assessment components (must total 100)', [h('div.table-wrap', h('table.table', h('thead', h('tr', h('th', { text: 'Key' }), h('th', { text: 'Label' }), h('th', { text: 'Maximum' }))), compTbl)),
    h('p.muted', { text: 'Changes apply to NEW score sheets; existing sheets keep the components they were created with.' }),
    edit ? h('div.page-actions', btn('Add component', () => { if (compRows.length >= 6) return; const r = { key: h('input.input', { value: `ca${compRows.length}` }), label: h('input.input', { value: 'New CA' }), max: h('input.input', { type: 'number', value: 10 }) }; compRows.push(r); compTbl.appendChild(h('tr', h('td', r.key), h('td', r.label), h('td', r.max))); }),
      btn('Save components', async () => { try { await api.put('/school/settings', { assessmentComponents: compRows.map((r) => ({ key: r.key.value.trim(), label: r.label.value.trim(), max: Number(r.max.value), isExam: r.key.value.trim() === 'exam' })) }); toast('Components saved'); } catch (e) { fail(e); } }, { kind: 'primary' })) : null]));
  // grading scales
  const scales = ['primary', 'secondary'].map((sec) => {
    const rows = (st.grading[sec] || []).map((b) => ({ min: h('input.input', { type: 'number', value: b.min, disabled: !edit }), grade: h('input.input', { value: b.grade, disabled: !edit }), remark: h('input.input', { value: b.remark || '', disabled: !edit }) }));
    return { sec, rows, el: card(`${sec === 'secondary' ? 'Secondary (WAEC)' : 'Primary / nursery'} grading scale`, [h('div.table-wrap', h('table.table', h('thead', h('tr', h('th', { text: 'From %' }), h('th', { text: 'Grade' }), h('th', { text: 'Remark' }))), h('tbody', rows.map((r) => h('tr', h('td', r.min), h('td', r.grade), h('td', r.remark)))))),
      edit ? btn('Save scale', async () => { try { await api.put('/school/settings', { grading: { [sec]: rows.map((r) => ({ min: Number(r.min.value), grade: r.grade.value.trim(), remark: r.remark.value.trim() })) } }); toast('Grading saved'); } catch (e) { fail(e); } }, { kind: 'primary' }) : null]) };
  });
  view.appendChild(h('div.grid.g2', scales.map((x) => x.el)));
  const roles = can('roles.view') ? (await api.get('/roles')).items : [];
  const pol = form([{ name: 'passMark', label: 'Pass mark (%)', type: 'number' }, { name: 'aiEnabled', label: 'Allow online AI remark suggestions (server-side, pseudonymised)', type: 'checkbox' },
    { name: 'resultsRequireReview', label: 'Results need a separate REVIEW step before approval', type: 'checkbox' },     { name: 'mfaRequiredRoles', label: 'Roles that must use two-factor sign-in', type: 'multiselect', full: true, options: roles.filter((r) => r.portal === 'staff').map((r) => ({ value: r.key, label: r.name })) }],
  { passMark: st.pass_mark, aiEnabled: st.ai_enabled, resultsRequireReview: st.results_require_review !== false, mfaRequiredRoles: st.mfa_required_roles });
  view.appendChild(card('Results, AI & security policy', [pol, edit ? h('div.page-actions', btn('Save policy', async () => { const v = pol._values(); try { await api.put('/school/settings', { passMark: v.passMark ?? 40, aiEnabled: v.aiEnabled, resultsRequireReview: v.resultsRequireReview, mfaRequiredRoles: v.mfaRequiredRoles }); toast('Policy saved'); } catch (e) { fail(e); } }, { kind: 'primary' })) : null]));
  void field; void clear; void confirmDialog; void formDialog; void simpleTable;
}

export async function account(view) {
  const me = session.me; const s = await api.get('/auth/sessions');
  view.appendChild(pageHead('My account & security', `${me.user.fullName} · ${me.user.loginId}`));
  const mfa = card('Two-factor authentication', [h('p', me.user.mfaEnabled ? badge('enabled', 'ok') : badge('off', 'muted'), h('span.muted', { text: me.user.mfaEnabled ? '  Your account asks for an authenticator code at sign-in.' : '  Protect your account with an authenticator app (Google/Microsoft Authenticator, Authy).' })),
    me.user.mfaEnabled ? btn('Turn off', async () => { const r = await formDialog({ title: 'Turn off two-factor', fields: [{ name: 'password', label: 'Password', type: 'password', required: true }, { name: 'code', label: 'Current 6-digit code', required: true, inputmode: 'numeric' }], onSubmit: (v) => api.post('/auth/mfa/disable', v) }); if (r) { toast('Two-factor disabled'); location.reload(); } }, { kind: 'danger' })
      : btn('Set up two-factor', () => { clear(view); mfaEnrol(view, false); }, { kind: 'primary', ic: 'key' })]);
  const pw = card('Password', [h('p.muted', { text: 'Changing your password signs you out on every other device.' }), btn('Change password', async () => { const r = await formDialog({ title: 'Change password', fields: [{ name: 'currentPassword', label: 'Current password', type: 'password', required: true, autocomplete: 'current-password' }, { name: 'newPassword', label: 'New password', type: 'password', required: true, autocomplete: 'new-password', hint: '10+ characters for staff; avoid common words and your name' }], onSubmit: (v) => api.post('/auth/password/change', v) }); if (r) toast('Password changed'); })]);
  view.appendChild(h('div.grid.g2', mfa, pw));
  const ms = me.memberships || [];
  if (ms.length) view.appendChild(card('My schools', simpleTable([{ key: 'schoolName', label: 'School' }, { label: 'Status', render: (m) => (m.current ? badge('signed in here', 'ok') : badge(m.status)) },
    { label: '', render: (m) => (m.status === 'invited' ? h('div.page-actions', btn('Accept', async () => { try { await api.post(`/auth/memberships/${m.id}/respond`, { accept: true }); toast('Invitation accepted'); location.reload(); } catch (e) { fail(e); } }, { kind: 'primary' }), btn('Decline', async () => { await api.post(`/auth/memberships/${m.id}/respond`, { accept: false }); location.reload(); })) : m.status === 'active' && !m.current ? btn('Switch', async () => { try { await api.post('/auth/switch-school', { schoolId: m.schoolId }); location.hash = '#/'; location.reload(); } catch (e) { fail(e); } }) : '') }], ms)));
  view.appendChild(card('Signed-in devices', simpleTable([{ key: 'device_label', label: 'Device' }, { key: 'ip', label: 'IP' }, { label: 'Signed in', render: (x) => dateTime(x.created_at) }, { label: 'Last active', render: (x) => ago(x.last_seen_at) }, { label: '', render: (x) => (x.current ? badge('this device', 'ok') : btn('Sign out', async () => { await api.del(`/auth/sessions/${x.id}`); clear(view); account(view); }, { kind: 'ghost' })) }], s.items),
    btn('Sign out everywhere', async () => { if (await confirmDialog({ title: 'Sign out of all devices?', message: 'Including this one.', danger: true })) { await api.post('/auth/logout-all'); location.hash = '#/login'; location.reload(); } }, { kind: 'danger' })));
}
