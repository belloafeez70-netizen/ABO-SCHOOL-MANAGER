import { h, clear, icon } from '../core/dom.js';
import { api, setCsrf } from '../core/api.js';
import { API_BASE } from '../core/config.js';
import { session } from '../core/session.js';
import { form, toast, errMsg, btn } from '../core/ui.js';
import { installApp, installed, onInstallChange } from '../core/install.js';

// remembered school (UI preference only — the slug is public): a device used for one school opens its branded page
const REMEMBER = 'aboSchool';
const remembered = () => { try { return localStorage.getItem(REMEMBER); } catch { return null; } };
const remember = (slug) => { try { if (slug) localStorage.setItem(REMEMBER, slug); else localStorage.removeItem(REMEMBER); } catch { /* private mode */ } };
function applySchoolColor(color) { if (color && /^#[0-9a-fA-F]{6}$/.test(color)) document.documentElement.style.setProperty('--school', color); }
const initialsOf = (n) => String(n || '?').split(/\s+/).filter(Boolean).slice(0, 2).map((x) => x[0].toUpperCase()).join('');

function layout(root, box, school) {
  const brand = school
    ? h('section.auth-brand.school-branded',
      h('div.logo-row', h('span.portal-chip', icon('shield', 14), 'Official school portal')),
      h('div.portal-school', school.logoUrl ? h('img.portal-logo', { src: school.logoUrl, alt: `${school.name} logo` }) : h('div.portal-logo-mark', { text: initialsOf(school.name) }),
        h('h1', { text: school.name }), school.motto ? h('p.motto', { text: `“${school.motto}”` }) : null,
        h('p', { text: 'Staff, students and parents sign in here to see results, CBT exams, fees and school notices.' })),
      h('small', { text: `Powered by A.B.O. School Manager · © ${new Date().getFullYear()}` }))
    : h('section.auth-brand',
      h('div.logo-row', h('div.brand-mark', { text: 'ABO' }), h('span', { text: 'A.B.O. SCHOOL MANAGER' })),
      h('div', h('h1', { text: 'Run your whole school from one secure place.' }),
        h('p', { text: 'Results, CBT, fees, attendance and parent communication — for nursery, primary and secondary schools across Nigeria.' }),
        h('div.auth-points', ['Server-side security & school data isolation', 'Two-factor sign-in for owners & bursars', 'Approved results are locked & audited', 'Works on phones, tablets and laptops'].map((t) => h('div', icon('check'), h('span', { text: t }))))),
      h('small', { text: `© ${new Date().getFullYear()} A.B.O. Edu Consultant · Help: 0805 144 6681` }));
  const inst = h('button.link.auth-install', { type: 'button', on: { click: () => installApp().catch(() => {}) } }, icon('download', 14), h('span', { text: 'Install this app on your phone or computer' }));
  const syncInst = () => { inst.hidden = installed(); }; syncInst(); onInstallChange(syncInst);
  clear(root).appendChild(h('div.auth', brand, h('section.auth-form', h('div.auth-box', box), inst)));
}
function submitter(fields, action, label) {
  const f = form(fields); const alert = h('div.form-alert', { role: 'alert', hidden: true });
  const b = h('button.btn.btn-primary', { type: 'submit', text: label });
  const el = h('form', { novalidate: true, on: { submit: async (e) => { e.preventDefault(); alert.hidden = true; b.disabled = true; b.classList.add('loading');
    try { await action(f._values(), f); } catch (err) { if (!f._error(err)) { alert.textContent = errMsg(err); alert.hidden = false; } } finally { b.disabled = false; b.classList.remove('loading'); } } } }, alert, f, b);
  return el;
}
const afterLogin = async (r) => { setCsrf(r.csrf); session.me = null; location.hash = '#/'; };

// Portal tabs (website parity): Staff · Student · Parent. The tab only changes which identifiers the server tries —
// staff: Login ID / e-mail; students: admission number too; parents: phone number too. Students and parents may type
// the one-time ACCESS CODE in the password box on their first visit; they are then asked to create a password.
const PORTAL_KEY = 'aboPortal';
const PORTAL_DEF = {
  staff: { label: 'Staff', ic: 'briefcase', id: 'Login ID or email', ph: (s) => (s ? `e.g. ${s.slug.split('-')[0]}.firstname` : 'e.g. bopc.teacher1'), pw: 'Password',
    intro: (s) => `Administrators and teachers sign in${s ? ` to ${s.name}` : ''} with the Login ID from the school.` },
  student: { label: 'Student', ic: 'graduation', id: 'Admission number or Login ID', ph: () => 'e.g. BOPC/0001', pw: 'Password or access code',
    intro: () => 'Use your admission number. First time? Type the access code from your slip as the password.' },
  parent: { label: 'Parent', ic: 'users', id: 'Phone number, email or Login ID', ph: () => 'e.g. 0803 000 0000', pw: 'Password or access code',
    intro: () => 'Use the phone number or email the school has for you. First time? Type the access code from the school as the password.' },
};
const savedPortal = () => { try { const v = localStorage.getItem(PORTAL_KEY); return PORTAL_DEF[v] ? v : null; } catch { return null; } };
function loginBox(school, q = {}) {
  let portal = PORTAL_DEF[q.portal] ? q.portal : (savedPortal() || 'staff');
  const box = h('div.login-box');
  const tabsEl = h('div.portal-tabs', { role: 'tablist', 'aria-label': 'Choose your portal' });
  const draw = () => {
    const d = PORTAL_DEF[portal];
    clear(tabsEl);
    for (const [k, t] of Object.entries(PORTAL_DEF)) {
      tabsEl.appendChild(h(`button.portal-tab${k === portal ? '.active' : ''}`, { type: 'button', role: 'tab', 'aria-selected': k === portal ? 'true' : 'false', dataset: { portal: k },
        on: { click: () => { portal = k; try { localStorage.setItem(PORTAL_KEY, k); } catch { /* private mode */ } draw(); const i = box.querySelector('input[name="loginId"]'); if (i) i.focus(); } } }, icon(t.ic, 15), h('span', { text: t.label })));
    }
    const formEl = submitter([{ name: 'loginId', label: d.id, required: true, autocomplete: 'username', placeholder: d.ph(school) },
      { name: 'password', label: d.pw, type: 'password', required: true, autocomplete: 'current-password' }],
    async (v) => {
      const body = { ...v, portal, ...(school ? { schoolId: school.id } : {}) };
      const r = await api.post('/auth/login', body);
      if (school) remember(school.slug);
      if (r.activationRequired) return createPassword(box, school, { loginId: r.loginId, accessCode: v.password, portal }, build);
      afterLogin(r);
    }, 'Sign in');
    const rows = [h('p.muted', { text: d.intro(school) }), formEl,
      h('div.auth-links', portal === 'staff' ? h('a', { href: '#/activate', text: 'First time? Activate with access code' }) : h('span.muted', { text: 'Code expired? Ask the school office.' }), h('a', { href: '#/forgot', text: 'Forgot password?' }))];
    if (!school && portal !== 'staff') rows.push(h('div.auth-note', { text: 'Tip: admission numbers and phone numbers work best from your school’s own sign-in link (ask the school for it). Your Login ID always works here.' }));
    clear(slot).append(...rows);
  };
  const slot = h('div');
  const build = () => { clear(box).append(school ? h('div.school-mini', school.logoUrl ? h('img', { src: school.logoUrl, alt: '' }) : h('div.brand-mark', { text: initialsOf(school.name) }), h('strong', { text: school.name })) : h('span'),
    h('h2', { text: 'Sign in' }), tabsEl, slot,
    school ? h('div.auth-links', h('span.muted', { text: `Not from ${school.name}?` }), h('a', { href: '#/login', text: 'Use the general sign-in', on: { click: () => remember(null) } }))
      : h('div.auth-links', h('span.muted', { text: 'New school?' }), h('a', { href: '#/register', text: 'Register your school' }))); draw(); };
  build();
  return [box];
}
// second step after a valid access code: choose a personal password, then sign straight in
function createPassword(box, school, ctx, back) {
  clear(box).append(h('h2', { text: 'Create your password' }),
    h('p.muted', { text: `Access code accepted for Login ID ${ctx.loginId}. Choose a personal password — you will use it from now on instead of the code.` }),
    submitter([{ name: 'newPassword', label: 'New password', type: 'password', required: true, autocomplete: 'new-password', hint: 'At least 8 characters. Avoid common passwords and your name.' },
      { name: 'confirm', label: 'Confirm password', type: 'password', required: true, autocomplete: 'new-password' }],
    async (v) => {
      if (v.newPassword !== v.confirm) throw Object.assign(new Error('The two passwords do not match.'), { details: { field: 'confirm' } });
      await api.post('/auth/activate', { loginId: ctx.loginId, accessCode: ctx.accessCode, newPassword: v.newPassword });
      const r = await api.post('/auth/login', { loginId: ctx.loginId, password: v.newPassword, portal: ctx.portal, ...(school ? { schoolId: school.id } : {}) });
      toast('Password created. Welcome!');
      afterLogin(r);
    }, 'Save password and sign in'),
    h('div.auth-links', h('a', { href: '#', text: 'Back to sign in', on: { click: (e) => { e.preventDefault(); back(); } } })));
  const i = box.querySelector('input'); if (i) i.focus();
}
async function loadSchool(slug) {
  try { const s = await api.get(`/public/schools/${encodeURIComponent(slug)}`); if (s && s.logoUrl && s.logoUrl.startsWith('/api/')) s.logoUrl = API_BASE + s.logoUrl; return s; } catch { return null; }
}
// the school's own sign-in page: /#/s/<slug> — shows the school's name, motto, colour and logo once it is approved
export async function schoolPortal(root, p, q = {}) {
  const school = await loadSchool(p.slug);
  if (!school) {
    layout(root, [h('h2', { text: 'School page not available' }), h('p.muted', { text: 'This school sign-in page does not exist or the school has not been approved yet. Check the link with your school, or use the general sign-in.' }),
      h('div.auth-links', h('a', { href: '#/login', text: '← General sign-in', on: { click: () => remember(null) } }))]);
    return;
  }
  if (school.slug && school.slug !== p.slug) { location.replace(`#/s/${encodeURIComponent(school.slug)}`); return; }   // an old address: move to the current one
  applySchoolColor(school.brandColor); document.title = `Sign in · ${school.name}`;
  layout(root, loginBox(school, q), school);
}
export async function login(root, p, q = {}) {
  const slug = remembered();
  const school = slug ? await loadSchool(slug) : null;
  if (slug && !school) remember(null);
  if (school) { applySchoolColor(school.brandColor); document.title = `Sign in · ${school.name}`; }
  let ended = false; try { ended = sessionStorage.getItem('abo.demoEnded') === '1'; sessionStorage.removeItem('abo.demoEnded'); } catch { /* */ }
  // 028 (owner's request): no public "Try the demo" button — demos open only from a demo link made by A.B.O.
  let again = null; try { again = sessionStorage.getItem('abo.demoPass'); } catch { /* */ }
  layout(root, [ended ? h('div.alert.alert-info', h('span', { text: 'Your demo time is over and the demo school has been put back as it was.' }),
    again ? h('a', { href: `#/demo?pass=${encodeURIComponent(again)}`, text: ' Open the demo again' }) : null) : null,
  loginBox(school, q)], school);
}

// ── Demo (by invitation): two separate demo schools, 5 minutes, sample data only (the server ends the session) ──
// Since 028 a demo opens only from a demo link made by A.B.O. Edu Consultant (…/#/demo?pass=DEMO-XXXX-XXXX-XXXX).
export async function demo(root, p, q) {
  const pass = (q && q.pass) || '';
  let d; try { d = await api.get(`/public/demo${pass ? `?pass=${encodeURIComponent(pass)}` : ''}`); } catch (e) { d = null; }
  if (!d || !d.enabled || !d.passValid) {
    return layout(root, [h('span.demo-pill', { text: 'DEMO' }), h('h2', { text: 'Demo by invitation' }),
      h('p.muted', { text: pass ? 'This demo link is not valid any more (it was used up, has expired or was cancelled).' : 'A demo of A.B.O. School Manager is given by A.B.O. Edu Consultant.' }),
      h('p', { text: 'To see a demo, contact A.B.O. Edu Consultant on 0805 144 6681.' }),
      h('div.auth-links', h('a', { href: '#/login', text: '← Back to sign in' }), h('a', { href: '#/register', text: 'Register your school' }))]);
  }
  try { sessionStorage.setItem('abo.demoPass', pass); } catch { /* */ }
  let busy = false;
  const start = async (school, as, btnEl) => {
    if (busy) return; busy = true; btnEl.disabled = true;
    try { const r = await api.post('/public/demo/start', { school, as, pass }); if (r.csrf) setCsrf(r.csrf); session.me = null; location.hash = '#/'; }
    catch (e) { toast(errMsg(e), 'err', 6000); btnEl.disabled = false; } finally { busy = false; }
  };
  layout(root, [h('span.demo-pill', { text: 'DEMO' }), h('h2', { text: 'Try A.B.O. School Manager' }),
    h('p.muted', { text: `${d.schools.length > 1 ? 'Pick a demo school and who you want to be' : 'Pick who you want to be'}. You get ${d.minutes} minutes with sample pupils, classes, staff, results and report cards. Real school data is never shown, and anything you change is wiped when the demo ends.` }),
    ...d.schools.map((s) => h('section.demo-school', h('div', h('strong', { text: `${s.name}` }), h('span.demo-pill.sm', { text: 'DEMO' }), h('div.muted.small', { text: `${s.kind} · “${s.motto}”` })),
      h('div.demo-roles', d.as.map((a) => { const b = h('button.btn.btn-sm', { type: 'button', text: a.label }); b.addEventListener('click', () => start(s.key, a.key, b)); return b; })))),
    h('p.muted.small', { text: 'School owner controls (logins, settings, payments) are not part of the demo.' }),
    h('div.auth-links', h('a', { href: '#/login', text: '← Back to sign in' }), h('a', { href: '#/register', text: 'Register your school' }))]);
}
export function activate(root) {
  layout(root, [h('h2', { text: 'Activate your account' }), h('p.muted', { text: 'Enter the Login ID and one-time access code from your school slip, then choose a password.' }),
    submitter([{ name: 'loginId', label: 'Login ID, admission number or phone', required: true, autocomplete: 'username' }, { name: 'accessCode', label: 'Access code', required: true, placeholder: 'ABCDE-FGH23' },
      { name: 'newPassword', label: 'New password', type: 'password', required: true, autocomplete: 'new-password', hint: 'At least 8 characters (10 for staff). Avoid common passwords.' }],
    async (v) => { const r = await api.post('/auth/activate', v); toast(r.message); location.hash = '#/login'; }, 'Activate account'),
    h('div.auth-links', h('a', { href: '#/login', text: '← Back to sign in' }))]);
}
export function forgot(root) {
  layout(root, [h('h2', { text: 'Reset your password' }), h('p.muted', { text: 'Enter your Login ID or email. Students and parents without email should ask the school office for a new access code.' }),
    submitter([{ name: 'identifier', label: 'Login ID or email', required: true }], async (v) => { const r = await api.post('/auth/password/forgot', v); toast(r.message, 'ok', 8000); location.hash = '#/login'; }, 'Send reset link'),
    h('div.auth-links', h('a', { href: '#/login', text: '← Back to sign in' }))]);
}
export function reset(root, p, q) {
  layout(root, [h('h2', { text: 'Choose a new password' }),
    submitter([{ name: 'newPassword', label: 'New password', type: 'password', required: true, autocomplete: 'new-password' }], async (v) => { await api.post('/auth/password/reset', { token: q.token || '', ...v }); toast('Password updated. Please sign in.'); location.hash = '#/login'; }, 'Update password')]);
}
export async function verify(root, p, q) {
  layout(root, [h('h2', { text: 'Verifying your email…' })]);
  try {
    const r = await api.post('/auth/verify-email', { token: q.token || '' });
    if (r.awaitingApproval) layout(root, [h('h2', { text: 'Email verified — awaiting approval' }), h('p.muted', { text: r.message }),
      h('ol', ['The A.B.O. team reviews new schools (usually within one working day).', 'You get an e-mail with your school’s own sign-in link as soon as it is approved.', 'Sign in, upload your logo under School › Logo & Branding, and share the link with your staff and parents.'].map((t) => h('li', { text: t }))),
      h('a.btn', { href: '#/login', text: 'Back to sign-in' })]);
    else layout(root, [h('h2', { text: 'Email verified' }), h('p.muted', { text: r.message }), h('a.btn.btn-primary', { href: '#/login', text: 'Sign in' })]);
  }
  catch (e) { layout(root, [h('h2', { text: 'Link problem' }), h('p.muted', { text: errMsg(e) }), h('a', { href: '#/login', text: 'Back to sign in' })]); }
}
export function register(root) {
  layout(root, [h('h2', { text: 'Register your school' }), h('p.muted', { text: 'Create your school workspace. You will verify your email before it becomes active.' }),
    submitter([
      { section: 'School' },
      { name: 'name', label: 'School name', required: true, full: true }, { name: 'slug', label: 'School web address (slug)', required: true, placeholder: 'e.g. bopc-ibadan', hint: 'lowercase letters, numbers and dashes', pattern: '[a-z0-9-]{3,30}' }, { name: 'registrationNumber', label: 'Registration number (optional)' },
      { name: 'schoolType', label: 'School type', type: 'select', required: true, options: [{ value: 'primary', label: 'Primary (Nursery & Basic)' }, { value: 'secondary', label: 'Secondary (JSS & SSS)' }, { value: 'mixed', label: 'Mixed (Primary + Secondary)' }] },
      { name: 'address', label: 'Address', full: true }, { name: 'phone', label: 'School phone' },
      { section: 'Owner / proprietor account' },
      { name: 'firstName', label: 'First name', required: true }, { name: 'lastName', label: 'Last name', required: true }, { name: 'email', label: 'Your email', type: 'email', required: true },
      { name: 'loginId', label: 'Choose a Login ID', required: true, placeholder: 'e.g. bopc.owner' }, { name: 'password', label: 'Password', type: 'password', required: true, autocomplete: 'new-password', hint: '10+ characters, mix of letters, numbers and symbols' },
    ], async (v) => {
      const r = await api.post('/onboarding/register', { school: { name: v.name, slug: v.slug, registrationNumber: v.registrationNumber, schoolType: v.schoolType, address: v.address, phone: v.phone }, owner: { firstName: v.firstName, lastName: v.lastName, email: v.email, loginId: v.loginId, password: v.password } });
      clear(root); layout(root, [h('h2', { text: 'Check your email' }), h('p.muted', { text: r.message }),
        r.devVerificationToken ? h('p', h('span.badge.badge-warn', { text: 'development only' }), ' ', h('a', { href: `#/verify?token=${r.devVerificationToken}`, text: 'Verify now (no SMTP configured)' })) : null,
        h('a', { href: '#/login', text: '← Back to sign in' })]);
    }, 'Create school'),
    h('div.auth-links', h('a', { href: '#/login', text: '← I already have an account' }))]);
}

// Post-login gates: MFA verification, MFA enrolment, forced password change
export function gate(root, me) {
  const out = h('button.link', { text: 'Sign out', on: { click: async () => { await api.post('/auth/logout').catch(() => {}); import('../core/offline.js').then((m) => m.offlineSignedOut()).catch(() => {}); session.me = null; location.hash = '#/login'; location.reload(); } } });
  if (me.mfaState === 'pending') {
    let useRecovery = false;
    const render = () => layout(root, [h('h2', { text: 'Two-factor verification' }), h('p.muted', { text: useRecovery ? 'Enter one of your saved recovery codes.' : 'Enter the 6-digit code from your authenticator app.' }),
      submitter([useRecovery ? { name: 'recoveryCode', label: 'Recovery code', required: true, placeholder: 'ABCDE-FGH23' } : { name: 'code', label: 'Authentication code', required: true, inputmode: 'numeric', pattern: '[0-9]{6}', autocomplete: 'one-time-code' }],
        async (v) => { await api.post('/auth/mfa/verify', useRecovery ? { recoveryCode: String(v.recoveryCode).toUpperCase() } : v); session.me = null; location.hash = '#/'; location.reload(); }, 'Verify'),
      h('div.auth-links', h('button.link', { text: useRecovery ? 'Use authenticator code' : 'Use a recovery code', on: { click: () => { useRecovery = !useRecovery; render(); } } }), out)]);
    return render();
  }
  if (me.mfaState === 'enroll_required') return mfaEnrol(root, true, out);
  // forced password change
  layout(root, [h('h2', { text: 'Set a new password' }), h('p.muted', { text: 'Your school requires you to change your password before continuing.' }),
    submitter([{ name: 'currentPassword', label: 'Current password', type: 'password', required: true }, { name: 'newPassword', label: 'New password', type: 'password', required: true, autocomplete: 'new-password' }],
      async (v) => { await api.post('/auth/password/change', v); session.me = null; location.hash = '#/'; location.reload(); }, 'Update password'), h('div.auth-links', out)]);
}
export async function mfaEnrol(root, required, out) {
  const s = await api.post('/auth/mfa/setup');
  const content = [h('h2', { text: 'Set up two-factor sign-in' }),
    h('p.muted', { text: required ? 'Your role handles sensitive data, so two-factor authentication is required. Scan the QR code with Google Authenticator, Microsoft Authenticator or Authy.' : 'Scan with your authenticator app.' }),
    h('img.qr', { src: s.qrSvgDataUrl, alt: 'QR code for authenticator app' }), h('p.muted', { text: 'Can’t scan? Enter this key manually:' }), h('div.code-box', { text: s.secret.replace(/(.{4})/g, '$1 ').trim() }),
    submitter([{ name: 'code', label: 'Enter the 6-digit code to confirm', required: true, inputmode: 'numeric', pattern: '[0-9]{6}', autocomplete: 'one-time-code' }], async (v) => {
      const r = await api.post('/auth/mfa/enable', v);
      const box = [h('h2', { text: 'Save your recovery codes' }), h('p.muted', { text: 'Each code works once if you lose your phone. Store them somewhere safe — they will not be shown again.' }),
        h('div.recovery.code-box', r.recoveryCodes.map((c) => h('span', { text: c }))), h('div.page-actions', btn('Print', () => window.print(), { ic: 'printer' }), btn('I have saved them', () => { session.me = null; location.hash = '#/'; location.reload(); }, { kind: 'primary' }))];
      if (root.classList && root.classList.contains('view')) { clear(root).append(...box); } else layout(root, box);
    }, 'Turn on two-factor'), out ? h('div.auth-links', out) : null];
  if (root.classList && root.classList.contains('view')) { clear(root).append(h('section.card', h('div.card-body', content))); } else layout(root, content);
}
