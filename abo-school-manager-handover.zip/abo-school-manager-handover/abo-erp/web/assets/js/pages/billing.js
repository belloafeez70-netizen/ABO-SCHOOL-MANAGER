// Subscriptions & payments.
//  • School (Settings › School Profile › Subscription): plan, status, expiry, pay online (Paystack) or by bank transfer,
//    payment history. Coming back from Paystack, the SERVER checks the payment before anything changes.
//  • Platform owner (Payments & Plans): demo timer, trial length, gateway keys (the secret key is write-only), plans and
//    prices, every school's subscription (manual changes need a reason), every payment.
import { h, clear } from '../core/dom.js';
import { api } from '../core/api.js';
import { session } from '../core/session.js';
import { pageHead, btn, badge, card, toast, fail, simpleTable, empty, formDialog, tabs, spinner } from '../core/ui.js';
import { naira, date, dateTime } from '../core/format.js';

const STATUS_TONE = { active: 'ok', trial: 'info', past_due: 'warn', expired: 'danger', cancelled: 'muted' };
const PERIOD = { month: 'per month', term: 'per term', year: 'per year' };

export async function mySubscription(view, p, q) {
  view.appendChild(pageHead('Subscription', 'Your A.B.O. plan, when it ends, and your payments. Payments are confirmed by the server with the payment company — never by this page.'));
  const box = h('div'); view.appendChild(box);
  if (q.reference) {
    clear(box).appendChild(spinner('Checking your payment with Paystack…'));
    try {
      const r = await api.post('/billing/verify', { reference: q.reference });
      toast(r.ok ? `Payment confirmed. Your subscription now runs until ${date(r.periodEnd)}.` : r.status === 'pending' || r.status === 'ongoing' ? 'Payment not finished yet. If you paid, it will be confirmed automatically in a few minutes.' : 'This payment was not completed. Nothing was charged for it.', r.ok ? 'ok' : 'err', 8000);
    } catch (e) { fail(e); }
    history.replaceState(null, '', '#/billing');
  }
  const draw = async () => {
    const d = await api.get('/billing'); const s = d.subscription || { status: 'trial' };
    const ends = s.status === 'trial' ? s.trial_ends_at : s.current_period_end;
    const daysLeft = ends ? Math.ceil((new Date(ends) - Date.now()) / 86400000) : null;
    clear(box).append(...[         // (native append would print "null" for a missing card)
      card('Your plan', h('div.billing-now', h('div', h('div.muted.small', { text: 'Status' }), badge(s.status, STATUS_TONE[s.status])), h('div', h('div.muted.small', { text: 'Plan' }), h('strong', { text: s.plan || (s.status === 'trial' ? 'Free trial' : '—') })),
        h('div', h('div.muted.small', { text: s.status === 'trial' ? 'Trial ends' : 'Paid until' }), h('strong', { text: ends ? `${date(ends)}${daysLeft !== null ? ` (${daysLeft > 0 ? `${daysLeft} day${daysLeft === 1 ? '' : 's'} left` : 'ended'})` : ''}` : '—' })))),
      card('Choose a plan', d.plans.length ? h('div.plan-grid', d.plans.map((pl) => h('div.plan-card2', h('h3', { text: pl.name }), h('div.plan-price', { text: naira(pl.price_kobo) }), h('div.muted', { text: PERIOD[pl.period] || '' }), pl.description ? h('p.small', { text: pl.description }) : null,
        d.canPay ? btn(d.onlinePayments ? 'Pay with Paystack' : 'How to pay', async () => {
          if (!d.onlinePayments) return toast('Online payment is not switched on yet. Use the bank details below and send your receipt to A.B.O.', 'err', 8000);
          const r = await formDialog({ title: `Pay for ${pl.name}`, intro: `${naira(pl.price_kobo)} ${PERIOD[pl.period] || ''}. You will go to Paystack’s secure page; your plan starts as soon as the server confirms the payment.`,
            fields: [{ name: 'email', label: 'Email for the receipt', type: 'email', required: true }], values: { email: session.me.user.email || '' }, submitLabel: 'Continue to Paystack', onSubmit: (v) => api.post('/billing/checkout', { planId: pl.id, email: v.email }) });
          if (r && /^https:\/\//.test(r.authorizationUrl)) window.location.assign(r.authorizationUrl);
        }, { kind: 'primary' }) : h('p.muted.small', { text: 'Only the school owner or administrator can pay.' })))) : empty('No plans yet')),
      d.bankDetails ? card('Pay by bank transfer', [h('p.prewrap', { text: d.bankDetails }), h('p.muted.small', { text: 'After a transfer, send the receipt to A.B.O. Your subscription is updated once the payment is confirmed.' })]) : null,
      card('Payment history', simpleTable([{ label: 'Date', render: (x) => dateTime(x.created_at) }, { key: 'plan', label: 'Plan' }, { label: 'Amount', cls: 'num', render: (x) => naira(x.amount_kobo) },
        { label: 'Status', render: (x) => badge(x.status === 'success' ? 'paid' : x.status, x.status === 'success' ? 'ok' : x.status === 'pending' ? 'warn' : 'muted') }, { label: 'Paid until', render: (x) => (x.period_end_after ? date(x.period_end_after) : '—') }, { key: 'reference', label: 'Reference' }], d.payments, 'No payments yet'))].filter(Boolean));
  };
  draw().catch(fail);
}

export async function platformBilling(view, p, q) {
  view.appendChild(pageHead('Payments & Plans', 'Only you (the platform owner) see this page. Secret keys are stored encrypted on the server and are never shown again.'));
  const box = h('div'); let tab = q.tab || 'settings';
  view.append(tabs([{ key: 'settings', label: 'Settings' }, { key: 'plans', label: 'Plans & prices' }, { key: 'subs', label: 'Schools' }, { key: 'pays', label: 'Payments' }], (k) => { tab = k; draw(); }, tab), box);
  const draw = async () => {
    clear(box).appendChild(spinner());
    try {
      if (tab === 'settings') {
        const s = await api.get('/platform/billing/settings');
        clear(box).append(card('Demo & trial', simpleTable([{ key: 'k', label: 'Setting' }, { key: 'v', label: 'Value' }], [
          { k: 'Demo for visitors', v: s.demo_enabled ? 'On' : 'Off' }, { k: 'Demo time per visitor', v: `${s.demo_minutes} minute(s) (maximum 5)` }, { k: 'Free trial for new schools', v: `${s.trial_days} day(s)` }, { k: 'Currency', v: s.currency }])),
        card('Payment gateway (Paystack)', simpleTable([{ key: 'k', label: '' }, { key: 'v', label: '' }], [
          { k: 'Public key', v: s.paystack_public_key || 'not set' }, { k: 'Secret key', v: s.secretFromEnvironment ? 'set on the server (environment variable)' : s.secret_set ? `set (${s.paystack_secret_hint})` : 'not set' },
          { k: 'Webhook URL (paste in Paystack › Settings › API Keys & Webhooks)', v: s.webhookUrl }, { k: 'Bank transfer details shown to schools', v: s.bank_details || '—' }])),
        h('div.page-actions', btn('Change settings', async () => {
          const r = await formDialog({ title: 'Payment & demo settings', wide: true, intro: 'Leave the secret key empty to keep the current one. Use both TEST keys or both LIVE keys from Paystack › Settings › API Keys & Webhooks.',
            fields: [{ name: 'demoEnabled', label: 'Demo for visitors on the sign-in page', type: 'checkbox' }, { name: 'demoMinutes', label: 'Demo minutes (1–5)', type: 'number', min: 1, max: 5 },
              { name: 'trialDays', label: 'Free trial days for new schools', type: 'number', min: 0, max: 90 }, { name: 'currency', label: 'Currency', type: 'select', placeholder: false, options: ['NGN', 'GHS', 'KES', 'ZAR', 'USD'] },
              { name: 'paystackPublicKey', label: 'Paystack public key', placeholder: 'pk_… (public key)', full: true }, { name: 'paystackSecretKey', label: 'Paystack secret key (write-only)', type: 'password', placeholder: s.secret_set ? 'leave empty to keep the current key' : 'sk_… (secret key)', full: true, autocomplete: 'off' },
              { name: 'clearSecret', label: 'Remove the stored secret key', type: 'checkbox' }, { name: 'bankDetails', label: 'Bank transfer details for schools', type: 'textarea', full: true, max: 500 }],
            values: { demoEnabled: s.demo_enabled, demoMinutes: s.demo_minutes, trialDays: s.trial_days, currency: s.currency, paystackPublicKey: s.paystack_public_key || '', bankDetails: s.bank_details || '' },
            onSubmit: (v) => { const b = { demoEnabled: !!v.demoEnabled, demoMinutes: Number(v.demoMinutes), trialDays: Number(v.trialDays), currency: v.currency, paystackPublicKey: v.paystackPublicKey || null, bankDetails: v.bankDetails || null, clearSecret: !!v.clearSecret }; if (v.paystackSecretKey) b.paystackSecretKey = v.paystackSecretKey; return api.put('/platform/billing/settings', b); } });
          if (r) { toast('Settings saved'); draw(); }
        }, { kind: 'primary' })));
      } else if (tab === 'plans') {
        const d = await api.get('/platform/billing/plans');
        const edit = async (pl) => {
          const r = await formDialog({ title: pl ? `Edit ${pl.name}` : 'New plan', fields: [pl ? null : { name: 'code', label: 'Code (letters, numbers, - or _)', required: true }, { name: 'name', label: 'Name', required: true }, { name: 'price', label: 'Price (₦)', type: 'number', required: true, min: 0 },
            { name: 'period', label: 'Billing period', type: 'select', placeholder: false, options: [{ value: 'month', label: 'Monthly' }, { value: 'term', label: 'Per term' }, { value: 'year', label: 'Yearly' }] }, { name: 'periodDays', label: 'Days of access per payment', type: 'number', required: true, min: 1, max: 400 },
            { name: 'description', label: 'Description', full: true }, pl ? { name: 'active', label: 'Offered to schools', type: 'checkbox' } : null].filter(Boolean),
          values: pl ? { name: pl.name, price: Number(pl.price_kobo) / 100, period: pl.period, periodDays: pl.period_days, description: pl.description || '', active: pl.active } : { period: 'term', periodDays: 120 },
          onSubmit: (v) => { const b = { name: v.name, price: Number(v.price), period: v.period, periodDays: Number(v.periodDays), description: v.description || null }; if (pl) { b.active = !!v.active; return api.patch(`/platform/billing/plans/${pl.id}`, b); } return api.post('/platform/billing/plans', { ...b, code: v.code }); } });
          if (r) { toast('Plan saved'); draw(); }
        };
        clear(box).append(h('div.page-actions', btn('New plan', () => edit(null), { kind: 'primary', ic: 'plus' })), card(null, simpleTable([{ key: 'name', label: 'Plan' }, { key: 'code', label: 'Code' }, { label: 'Price', cls: 'num', render: (x) => naira(x.price_kobo) }, { label: 'Period', render: (x) => `${PERIOD[x.period]} · ${x.period_days} days` },
          { label: 'Offered', render: (x) => badge(x.active ? 'yes' : 'no', x.active ? 'ok' : 'muted') }, { label: '', render: (x) => btn('Edit', () => edit(x), { kind: 'ghost' }) }], d.items)));
      } else if (tab === 'subs') {
        const d = await api.get('/platform/billing/subscriptions');
        clear(box).appendChild(card(null, simpleTable([{ label: 'School', render: (x) => h('div', h('strong', { text: x.name }), x.is_demo ? h('span.demo-pill.sm', { text: 'DEMO' }) : null) }, { label: 'Status', render: (x) => badge(x.status || 'none', STATUS_TONE[x.status]) },
          { label: 'Plan', render: (x) => x.plan || '—' }, { label: 'Ends', render: (x) => date(x.status === 'trial' ? x.trial_ends_at : x.current_period_end) }, { label: 'Last paid', render: (x) => (x.last_paid_at ? date(x.last_paid_at) : '—') },
          { label: '', render: (x) => (x.is_demo ? null : btn('Change', async () => {
            const r = await formDialog({ title: `Subscription · ${x.name}`, intro: 'For example after a confirmed bank transfer. A reason is required and the change is recorded in the audit log.',
              fields: [{ name: 'status', label: 'Status', type: 'select', placeholder: false, options: ['trial', 'active', 'past_due', 'expired', 'cancelled'] }, { name: 'periodEnd', label: 'Paid until', type: 'date' }, { name: 'trialEnd', label: 'Trial ends', type: 'date' }, { name: 'note', label: 'Reason', required: true, full: true }],
              values: { status: x.status || 'trial', periodEnd: x.current_period_end ? x.current_period_end.slice(0, 10) : '', trialEnd: x.trial_ends_at ? x.trial_ends_at.slice(0, 10) : '' },
              onSubmit: (v) => api.patch(`/platform/billing/subscriptions/${x.school_id}`, { status: v.status, note: v.note, periodEnd: v.periodEnd ? new Date(`${v.periodEnd}T23:59:59`).toISOString() : null, trialEnd: v.trialEnd ? new Date(`${v.trialEnd}T23:59:59`).toISOString() : null }) });
            if (r) { toast('Subscription updated'); draw(); }
          }, { kind: 'ghost' })) }], d.items)));
      } else {
        const d = await api.get('/platform/billing/payments');
        clear(box).appendChild(card(null, simpleTable([{ label: 'Date', render: (x) => dateTime(x.created_at) }, { key: 'school', label: 'School' }, { key: 'plan', label: 'Plan' }, { label: 'Amount', cls: 'num', render: (x) => naira(x.amount_kobo) },
          { label: 'Status', render: (x) => badge(x.status, x.status === 'success' ? 'ok' : x.status === 'pending' ? 'warn' : 'muted') }, { label: 'Checked', render: (x) => (x.verified_at ? dateTime(x.verified_at) : '—') }, { key: 'reference', label: 'Reference' },
          { label: '', render: (x) => (x.status === 'pending' ? btn('Check with Paystack', async () => { try { const r = await api.post(`/platform/billing/payments/${x.id}/verify`); toast(r.ok ? 'Confirmed by Paystack' : `Not paid (${r.status})`, r.ok ? 'ok' : 'err'); draw(); } catch (e) { fail(e); } }, { kind: 'ghost' }) : null) }], d.items, 'No payments yet')));
      }
    } catch (e) { clear(box); fail(e); }
  };
  draw();
}
