import { h, clear, icon } from '../core/dom.js';
import { api, qs } from '../core/api.js';
import { can, session } from '../core/session.js';
import { dataTable, pageHead, btn, formDialog, badge, card, toast, fail, confirmDialog, modal, simpleTable, spinner } from '../core/ui.js';
import { date, ago, cap } from '../core/format.js';
import { fileUrl } from '../core/config.js';

let academicCache = null;
export async function academic(force) { if (!academicCache || force) academicCache = await api.get('/academic'); return academicCache; }
const classOpts = (a) => a.classes.map((c) => ({ value: c.id, label: c.display_name }));

// printable access-code slip (replaces the legacy "Access Code Slips")
export function accessSlip(r) {
  const school = session.me.school;
  modal({ title: 'Access code created', body: h('div', h('p.muted', { text: 'Give this slip to the account holder. The code works once and expires in ' + r.expiresInDays + ' days. It is not stored in readable form, so it cannot be shown again.' }),
    h('div.slip', h('strong', { text: school ? school.name : 'A.B.O. School Manager' }), h('dl.kv', h('dt', { text: 'Name' }), h('dd', { text: r.fullName || (r.user && r.user.full_name) }), h('dt', { text: 'Login ID' }), h('dd.mono', { text: r.loginId || (r.user && r.user.login_id) }),
      h('dt', { text: 'Access code' }), h('dd.mono', { text: r.accessCode }),
      h('dt', { text: 'Sign in at' }), h('dd', { text: school && school.slug ? `${location.origin}/#/s/${school.slug}` : `${location.origin}/#/login` })),
      h('p.muted', { text: 'First sign-in: enter your Login ID (students may use their admission number, parents their phone number) and type the access code as the password. You will then create your own password.' }))),
  actions: [btn('Print slip', () => window.print(), { ic: 'printer' })] });
}

export async function students(view, p, q) {
  const a = await academic();
  const add = can('students.create') ? btn('Admit student', async () => {
    const r = await formDialog({ title: 'Admit a student', fields: [
      { name: 'admissionNo', label: 'Admission number', required: true }, { name: 'classId', label: 'Class', type: 'select', options: classOpts(a) },
      { name: 'lastName', label: 'Surname', required: true }, { name: 'firstName', label: 'First name', required: true }, { name: 'otherNames', label: 'Other names' },
      { name: 'gender', label: 'Gender', type: 'select', required: true, options: ['Male', 'Female'] }, { name: 'dateOfBirth', label: 'Date of birth', type: 'date' },
      { name: 'address', label: 'Home address', full: true }, { name: 'medicalNotes', label: 'Medical notes (restricted)', type: 'textarea', full: true, rows: 2 }],
    onSubmit: (v) => api.post('/students', v) });
    if (r) { toast('Student admitted'); t.refresh(); }
  }, { kind: 'primary', ic: 'plus' }) : null;
  view.appendChild(pageHead('Students', 'All learners across every class and arm.', can('reports.export') ? btn('Export', () => { location.hash = '#/data'; }, { ic: 'download' }) : null, can('imports.run') ? btn('Import CSV', () => { location.hash = '#/data'; }, { ic: 'upload' }) : null, can('students.create') ? h('a.btn', { href: '#/students/new' }, icon('plus', 16), h('span', { text: 'Full admission form' })) : null, add));
  const t = dataTable({
    columns: [{ key: 'admission_no', label: 'Adm. No', cls: 'mono' }, { label: 'Name', render: (r) => `${r.last_name} ${r.first_name}${r.other_names ? ' ' + r.other_names : ''}` },
      { key: 'gender', label: 'Gender' }, { label: 'Class', render: (r) => r.class_name || badge('not enrolled', 'warn') }, { label: 'Portal', render: (r) => (r.has_account ? badge('account', 'ok') : badge('none', 'muted')) }, { label: 'Status', render: (r) => badge(r.status) }],
    filters: [{ name: 'classId', label: 'Class', placeholder: 'All classes', options: classOpts(a) }, { name: 'status', label: 'Status', placeholder: 'Active', options: ['graduated', 'transferred', 'withdrawn'] }],
    load: (o) => api.get('/students' + qs({ ...o, q: o.q || q.q })), rowClick: (r) => { location.hash = `#/students/${r.id}`; },
    empty: 'No students found', emptyHint: can('students.create') ? 'Admit a student or import a CSV to get started.' : undefined,
  });
  view.appendChild(t);
}

export async function studentDetail(view, p) {
  const [d, a] = await Promise.all([api.get(`/students/${p.id}`), academic()]);
  const s = d.student;
  const photo = s.passport_file_id ? h('img.brand-logo', { src: fileUrl(s.passport_file_id), alt: 'Passport' }) : h('div.brand-mark', { text: (s.first_name[0] || '') + (s.last_name[0] || '') });
  const actions = [];
  if (can('results.view')) actions.push(h('a.btn', { href: `#/report/${s.id}`, text: 'Report card' }));
  if (can('students.update')) actions.push(btn('Edit', async () => {
    const r = await formDialog({ title: 'Edit student', values: { admissionNo: s.admission_no, firstName: s.first_name, lastName: s.last_name, otherNames: s.other_names, gender: s.gender, dateOfBirth: s.date_of_birth, address: s.address, medicalNotes: s.medical_notes, classId: s.class_id },
      fields: [{ name: 'admissionNo', label: 'Admission number', required: true }, { name: 'classId', label: 'Class (current session)', type: 'select', options: classOpts(a) }, { name: 'lastName', label: 'Surname', required: true }, { name: 'firstName', label: 'First name', required: true },
        { name: 'otherNames', label: 'Other names' }, { name: 'gender', label: 'Gender', type: 'select', options: ['Male', 'Female'], required: true }, { name: 'dateOfBirth', label: 'Date of birth', type: 'date' }, { name: 'address', label: 'Address', full: true }, { name: 'medicalNotes', label: 'Medical notes', type: 'textarea', full: true }],
      onSubmit: (v) => api.patch(`/students/${s.id}`, v) });
    if (r) { toast('Saved'); clear(view); studentDetail(view, p); }
  }, { ic: 'settings' }));
  if (can('students.update')) actions.push(btn('Passport photo', () => {
    const inp = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp' });
    inp.addEventListener('change', async () => { const fd = new FormData(); fd.append('file', inp.files[0]); try { await api.post(`/students/${s.id}/passport`, fd); toast('Photo uploaded'); clear(view); studentDetail(view, p); } catch (e) { fail(e); } });
    inp.click();
  }, { ic: 'upload' }));
  if (can('users.create') && !s.has_account) actions.push(btn('Create portal login', async () => {
    const r = await formDialog({ title: 'Create student portal login', values: { loginId: `${(session.me.school.slug || 'sch').split('-')[0]}.${s.first_name}${s.last_name}`.toLowerCase().replace(/[^a-z0-9.]/g, '').slice(0, 40), fullName: `${s.first_name} ${s.last_name}` },
      fields: [{ name: 'fullName', label: 'Name', required: true }, { name: 'loginId', label: 'Login ID', required: true }], onSubmit: (v) => api.post('/users', { ...v, roleKeys: ['student'], link: { type: 'student', id: s.id } }) });
    if (r) accessSlip(r);
  }, { ic: 'key' }));
  if (can('students.delete')) actions.push(btn('Archive', async () => { const reason = await confirmDialog({ title: 'Archive student?', message: 'The record is kept for results and fees history, and any portal login is disabled.', danger: true, reason: true, confirmLabel: 'Archive' }); if (reason) { try { await api.del(`/students/${s.id}`, { reason }); toast('Archived'); location.hash = '#/students'; } catch (e) { fail(e); } } }, { kind: 'danger' }));
  view.appendChild(pageHead(`${s.last_name} ${s.first_name}`, `${s.admission_no} · ${s.class_name || 'Not enrolled'} · ${s.status}`, ...actions));
  view.appendChild(h('div.grid.g2',
    card('Profile', h('div', photo, h('dl.kv', h('dt', { text: 'Gender' }), h('dd', { text: s.gender }), h('dt', { text: 'Date of birth' }), h('dd', { text: date(s.date_of_birth) }), h('dt', { text: 'Address' }), h('dd', { text: s.address || '—' }),
      s.medical_notes !== undefined ? [h('dt', { text: 'Medical notes' }), h('dd', { text: s.medical_notes || '—' })] : null, h('dt', { text: 'Admitted' }), h('dd', { text: date(s.created_at) })))),
    h('div', card('Parents & guardians', simpleTable([{ key: 'full_name', label: 'Name' }, { key: 'relationship', label: 'Relationship' }, { key: 'phone', label: 'Phone' }, { key: 'email', label: 'Email' }], d.guardians, 'No guardian linked')),
      card('Class history', simpleTable([{ key: 'session', label: 'Session' }, { key: 'class_name', label: 'Class' }, { label: 'Status', render: (r) => badge(r.status) }], d.history, 'No enrolment history')))));
}

export async function guardians(view) {
  const add = can('guardians.manage') ? btn('Add parent', async () => {
    const r = await formDialog({ title: 'Add parent / guardian', fields: [{ name: 'fullName', label: 'Full name', required: true }, { name: 'relationship', label: 'Relationship', required: true, type: 'select', options: ['Mother', 'Father', 'Guardian', 'Sponsor', 'Other'] },
      { name: 'phone', label: 'Phone' }, { name: 'whatsapp', label: 'WhatsApp' }, { name: 'email', label: 'Email', type: 'email' }, { name: 'occupation', label: 'Occupation' }, { name: 'address', label: 'Address', full: true }],
    onSubmit: (v) => api.post('/guardians', { ...v, studentIds: [] }) });
    if (r) { toast('Parent added — link children from the list'); t.refresh(); }
  }, { kind: 'primary', ic: 'plus' }) : null;
  view.appendChild(pageHead('Parents & guardians', 'Contacts linked to each learner, and parent portal access.', add));
  const t = dataTable({
    columns: [{ key: 'full_name', label: 'Name' }, { key: 'relationship', label: 'Relationship' }, { key: 'phone', label: 'Phone' }, { key: 'email', label: 'Email' },
      { label: 'Children', render: (r) => r.children.map((c) => c.name).join(', ') || '—' }, { label: 'Portal', render: (r) => (r.has_account ? badge('account', 'ok') : badge('none', 'muted')) },
      { label: '', render: (r) => h('div.page-actions',
        can('guardians.manage') ? btn('Link children', async () => {
          const list = await api.get('/students?pageSize=100');
          const ok = await formDialog({ title: `Children of ${r.full_name}`, fields: [{ name: 'studentIds', label: 'Select children', type: 'multiselect', full: true, options: list.items.map((s) => ({ value: s.id, label: `${s.last_name} ${s.first_name} (${s.class_name || '—'})` })) }],
            values: { studentIds: r.children.map((c) => c.id) }, onSubmit: (v) => api.put(`/guardians/${r.id}/students`, v) });
          if (ok) { toast('Links updated'); t.refresh(); }
        }, { kind: 'ghost' }) : null,
        can('users.create') && !r.has_account ? btn('Portal login', async () => {
          const res = await formDialog({ title: 'Create parent portal login', values: { fullName: r.full_name, email: r.email }, fields: [{ name: 'fullName', label: 'Name', required: true }, { name: 'loginId', label: 'Login ID', required: true }, { name: 'email', label: 'Email (for password reset)', type: 'email' }],
            onSubmit: (v) => api.post('/users', { ...v, roleKeys: ['parent'], link: { type: 'guardian', id: r.id } }) });
          if (res) { accessSlip(res); t.refresh(); }
        }, { kind: 'ghost' }) : null) }],
    load: (o) => api.get('/guardians' + qs(o)),
  });
  view.appendChild(t);
}

export async function staff(view) {
  const fields = [{ name: 'fullName', label: 'Full name', required: true }, { name: 'employeeId', label: 'Staff number' }, { name: 'gender', label: 'Gender', type: 'select', options: ['Male', 'Female'] }, { name: 'designation', label: 'Designation' },
    { name: 'phone', label: 'Phone' }, { name: 'email', label: 'Email', type: 'email' }, { name: 'dateJoined', label: 'Date joined', type: 'date' }, { name: 'dateOfBirth', label: 'Date of birth (for birthdays)', type: 'date' }, { name: 'isTeacher', label: 'Teaches classes', type: 'checkbox' }];
  const add = can('staff.create') ? btn('Add staff', async () => { const r = await formDialog({ title: 'Add staff member', fields, values: { isTeacher: true }, onSubmit: (v) => api.post('/staff', v) }); if (r) { toast('Staff added'); t.refresh(); } }, { kind: 'primary', ic: 'plus' }) : null;
  view.appendChild(pageHead('Staff', 'Teaching and non-teaching staff, assignments and logins.', add));
  const t = dataTable({
    columns: [{ key: 'employee_id', label: 'Staff No', cls: 'mono' }, { key: 'full_name', label: 'Name' }, { key: 'designation', label: 'Designation' }, { key: 'phone', label: 'Phone' }, { label: 'Teaches', render: (r) => r.teaches || '—' },
      { label: 'Status', render: (r) => badge(r.employment_status) }, { label: 'Login', render: (r) => (r.has_account ? badge('account', 'ok') : (can('users.create') ? btn('Create login', async () => {
        const roles = (await api.get('/roles')).items.filter((x) => x.portal === 'staff');
        const res = await formDialog({ title: `Login for ${r.full_name}`, values: { fullName: r.full_name, email: r.email }, fields: [{ name: 'fullName', label: 'Name', required: true }, { name: 'loginId', label: 'Login ID', required: true }, { name: 'email', label: 'Email', type: 'email' },
          { name: 'roleKeys', label: 'Roles', type: 'multiselect', full: true, options: roles.map((x) => ({ value: x.key, label: x.name })) }], values2: null,
          onSubmit: (v) => api.post('/users', { ...v, roleKeys: v.roleKeys.length ? v.roleKeys : ['teacher'], link: { type: 'staff', id: r.id } }) });
        if (res) { accessSlip(res); t.refresh(); }
      }, { kind: 'ghost' }) : badge('none', 'muted'))) },
      { label: '', render: (r) => (can('staff.update') ? btn('Edit', async () => { const ok = await formDialog({ title: 'Edit staff', fields: [...fields, { name: 'employmentStatus', label: 'Status', type: 'select', options: ['active', 'on_leave', 'exited'] }], values: { fullName: r.full_name, employeeId: r.employee_id, gender: r.gender, designation: r.designation, phone: r.phone, email: r.email, dateJoined: r.date_joined, dateOfBirth: r.date_of_birth, isTeacher: r.is_teacher, employmentStatus: r.employment_status }, onSubmit: (v) => api.patch(`/staff/${r.id}`, v) }); if (ok) t.refresh(); }, { kind: 'ghost' }) : null) }],
    filters: [{ name: 'teachersOnly', label: 'Type', placeholder: 'All staff', options: [{ value: 'true', label: 'Teachers only' }] }],
    load: (o) => api.get('/staff' + qs(o)),
  });
  view.appendChild(t);
}

export async function users(view) {
  const roles = (await api.get('/roles')).items;
  const add = can('users.create') ? btn('New user', async () => {
    const r = await formDialog({ title: 'Create a user account', intro: 'The user activates the account with a one-time access code and sets their own password. Passwords are never visible to admins.',
      fields: [{ name: 'fullName', label: 'Full name', required: true }, { name: 'loginId', label: 'Login ID', required: true, hint: 'letters, numbers, dot, dash' }, { name: 'email', label: 'Email', type: 'email' }, { name: 'phone', label: 'Phone' },
        { name: 'roleKeys', label: 'Roles', type: 'multiselect', full: true, options: roles.map((x) => ({ value: x.key, label: `${x.name}${x.mfa_required ? ' · 2FA' : ''}` })) }],
      onSubmit: (v) => api.post('/users', v) });
    if (r) { accessSlip(r); t.refresh(); }
  }, { kind: 'primary', ic: 'plus' }) : null;
  const invite = can('users.create') ? btn('Invite existing account', async () => {
    const r = await formDialog({ title: 'Invite an existing A.B.O. account', intro: 'For people who already use A.B.O. at another school (e.g. a proprietor of two schools). They accept from their own account; you never see or change their password.',
      fields: [{ name: 'login', label: 'Their Login ID or email', required: true }, { name: 'roleKeys', label: 'Roles in your school', type: 'multiselect', full: true, options: roles.map((x) => ({ value: x.key, label: x.name })) }], onSubmit: (v) => api.post('/users/invite', v) });
    if (r) { toast('Invitation sent'); t.refresh(); }
  }, { ic: 'mail' }) : null;
  const branches = can('settings.view') ? (await api.get('/school/branches')).items : [];
  view.appendChild(pageHead('Users & access', 'Accounts, roles, branch access, two-factor status and sign-in activity.', invite, add));
  const t = dataTable({
    columns: [{ key: 'full_name', label: 'Name' }, { key: 'login_id', label: 'Login ID', cls: 'mono' }, { label: 'Roles', render: (r) => r.roles.map((x) => x.name).join(', ') || '—' },
      { label: 'Status', render: (r) => (r.locked ? badge('locked', 'danger') : r.awaiting_activation ? badge('awaiting activation', 'warn') : badge(r.status)) }, { label: 'Branch', render: (r) => r.branch || 'All branches' }, { label: '2FA', render: (r) => (r.mfa_enabled ? badge('on', 'ok') : badge('off', 'muted')) },
      { label: 'Last sign-in', render: (r) => ago(r.last_login_at) },
      { label: '', render: (r) => h('div.page-actions',
        can('users.assign_role') ? btn('Roles', async () => { const ok = await formDialog({ title: `Roles for ${r.full_name}`, values: { roleKeys: r.roles.map((x) => x.key) }, fields: [{ name: 'roleKeys', label: 'Roles', type: 'multiselect', full: true, options: roles.map((x) => ({ value: x.key, label: x.name })) }], onSubmit: (v) => api.put(`/users/${r.id}/roles`, v) }); if (ok) { toast('Roles updated'); t.refresh(); } }, { kind: 'ghost' }) : null,
        can('users.update') ? btn('Access code', async () => { if (await confirmDialog({ title: 'Issue a new access code?', message: 'Use this when a user forgot their password or never activated. The old code stops working.' })) { try { accessSlip(await api.post(`/users/${r.id}/access-code`)); } catch (e) { fail(e); } } }, { kind: 'ghost' }) : null,
        can('users.update') && r.mfa_enabled && r.id !== session.me.user.id ? btn('Reset 2FA', async () => { const reason = await confirmDialog({ title: `Reset two-factor for ${r.full_name}?`, message: 'Only after verifying the person’s identity (lost phone). They are signed out and must enrol again.', danger: true, reason: true }); if (reason) { try { await api.post(`/users/${r.id}/mfa-reset`, { reason }); toast('Two-factor reset'); t.refresh(); } catch (e) { fail(e); } } }, { kind: 'ghost' }) : null,
        can('users.update') && branches.length && !session.me.user.branchRestricted ? btn('Branch', async () => { const ok = await formDialog({ title: `Branch access · ${r.full_name}`, values: { branchId: r.branch_id }, fields: [{ name: 'branchId', label: 'Restrict to branch (empty = whole school)', type: 'select', placeholder: 'Whole school', options: branches.map((b) => ({ value: b.id, label: b.name })) }], onSubmit: (v) => api.put(`/users/${r.id}/membership`, { branchId: v.branchId || null }) }); if (ok) { toast('Branch access updated — user signed out of this school'); t.refresh(); } }, { kind: 'ghost' }) : null,
        can('users.update') && r.locked ? btn('Unlock', async () => { await api.post(`/users/${r.id}/unlock`); t.refresh(); }, { kind: 'ghost' }) : null,
        can('users.disable') && r.id !== session.me.user.id ? btn(r.status === 'disabled' ? 'Enable' : 'Disable', async () => { const reason = await confirmDialog({ title: `${r.status === 'disabled' ? 'Enable' : 'Disable'} ${r.full_name}?`, message: 'Disabling signs the user out everywhere immediately.', danger: r.status !== 'disabled', reason: true }); if (reason) { try { await api.post(`/users/${r.id}/status`, { status: r.status === 'disabled' ? 'active' : 'disabled', reason }); t.refresh(); } catch (e) { fail(e); } } }, { kind: 'ghost' }) : null) }],
    filters: [{ name: 'role', label: 'Role', placeholder: 'All roles', options: roles.map((x) => ({ value: x.key, label: x.name })) }, { name: 'status', label: 'Status', placeholder: 'Any status', options: ['active', 'pending', 'disabled'] }],
    load: (o) => api.get('/users' + qs(o)),
  });
  view.appendChild(t);
}

export async function roles(view) {
  const [r, p] = await Promise.all([api.get('/roles'), can('roles.manage') ? api.get('/permissions') : Promise.resolve({ items: [] })]);
  const perms = p.items;
  const editor = async (role) => {
    const res = await formDialog({ title: role ? `Edit ${role.name}` : 'New custom role', wide: true, values: role ? { name: role.name, description: role.description, mfaRequired: role.mfa_required, permissions: role.permissions } : { permissions: [] },
      fields: [...(role ? [] : [{ name: 'key', label: 'Key', required: true, hint: 'e.g. hostel_master' }]), { name: 'name', label: 'Name', required: true }, { name: 'description', label: 'Description', full: true }, { name: 'mfaRequired', label: 'Require two-factor sign-in', type: 'checkbox' },
        { name: 'permissions', label: 'Permissions (you can only grant what you hold)', type: 'multiselect', full: true, options: perms.map((x) => ({ value: x.key, label: `${x.key} — ${x.description}` })) }],
      onSubmit: (v) => (role ? api.patch(`/roles/${role.id}`, v) : api.post('/roles', v)) });
    if (res) { toast('Role saved'); clear(view); roles(view); }
  };
  view.appendChild(pageHead('Roles & permissions', 'Granular, server-enforced permissions. System roles are templates you can tune; the School Owner role is locked.', can('roles.manage') ? btn('New role', () => editor(null), { kind: 'primary', ic: 'plus' }) : null));
  view.appendChild(h('div.grid.g2', r.items.map((x) => card(x.name, [h('p.muted', { text: `${x.users} user(s) · ${x.permissions.length} permissions · ${x.portal} portal` }), x.mfa_required ? badge('2FA required', 'warn') : null, x.is_system ? badge('system', 'muted') : badge('custom', 'info'),
    h('details', h('summary', { text: 'Permissions' }), h('div.checks', x.permissions.map((k) => h('span.badge.badge-muted', { text: k }))))], can('roles.manage') && x.key !== 'school_owner' ? btn('Edit', () => editor(x), { kind: 'ghost' }) : null))));
  void spinner; void cap;
}

export async function teachers(view) {
  const a = await academic();
  view.appendChild(pageHead('Teachers', 'Teaching profiles (TRCN, qualification) and class/subject assignments. Teachers can only open score sheets and registers for what they are assigned.'));
  const t = dataTable({
    columns: [{ key: 'full_name', label: 'Teacher' }, { key: 'employee_id', label: 'Employee ID', cls: 'mono' }, { label: 'TRCN', render: (r) => r.trcn_number || '—' }, { label: 'Qualification', render: (r) => r.qualification || '—' },
      { label: 'Assignments', render: (r) => (r.assignments.length ? h('div.checks', r.assignments.map((x) => badge(`${x.className}${x.subject ? ' · ' + x.subject : ''}${x.role !== 'subject_teacher' ? ' (' + x.role.replace('_', ' ') + ')' : ''}`, x.role === 'form_teacher' ? 'ok' : 'info'))) : badge('none', 'muted')) },
      { label: '', render: (r) => (can('teachers.update') ? h('div.page-actions',
        btn('Profile', async () => { const ok = await formDialog({ title: `Teaching profile · ${r.full_name}`, values: { trcnNumber: r.trcn_number, qualification: r.qualification, specialization: r.specialization }, fields: [{ name: 'trcnNumber', label: 'TRCN number' }, { name: 'qualification', label: 'Qualification' }, { name: 'specialization', label: 'Specialisation', full: true }], onSubmit: (v) => api.patch(`/teachers/${r.id}`, v) }); if (ok) t.refresh(); }, { kind: 'ghost' }),
        btn('Assign', async () => {
          const ok = await formDialog({ title: `Assign ${r.full_name}`, intro: 'Primary subject teachers and form teachers are set under Academic setup; use this for extra/co-teaching assignments.', fields: [
            { name: 'classId', label: 'Class', type: 'select', required: true, options: a.classes.map((c) => ({ value: c.id, label: c.display_name })) }, { name: 'subjectId', label: 'Subject (empty for class-level roles)', type: 'select', options: a.subjects.map((s) => ({ value: s.id, label: s.name })) },
            { name: 'role', label: 'Role', type: 'select', required: true, placeholder: false, options: [{ value: 'subject_teacher', label: 'Subject teacher' }, { value: 'assistant', label: 'Assistant / co-teacher' }, { value: 'form_teacher', label: 'Form teacher' }] }],
          values: { role: 'subject_teacher' }, onSubmit: (v) => api.post(`/teachers/${r.id}/assignments`, v) });
          if (ok) { toast('Assignment added'); t.refresh(); }
        }, { kind: 'ghost' })) : null) }],
    load: (o) => api.get('/teachers' + qs(o)),
  });
  view.appendChild(t);
}
