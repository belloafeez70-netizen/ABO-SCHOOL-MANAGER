// CBT question editor (8 types) with a maths toolbar and live preview. Used by the Question Bank and the exam builder.
import { h, clear, append, icon } from '../core/dom.js';
import { api } from '../core/api.js';
import { modal, btn, errMsg, toast } from '../core/ui.js';
import { renderRich, MATH_TOOLS } from '../core/mathtext.js';
import { fileUrl } from '../core/config.js';

export const TYPE_LABELS = { mcq: 'Multiple choice', multi_select: 'Multiple select', true_false: 'True / False', short_answer: 'Short answer', numeric: 'Numerical answer', fill_blank: 'Fill in the blank', theory: 'Essay', image: 'Image-based' };
const LET = 'ABCDEF';
const sel = (name, opts, value) => h('select.input', { name, 'aria-label': name }, opts.map(([v, l]) => h('option', { value: v, text: l, selected: String(v) === String(value ?? '') })));
const lab = (text, input, hint) => h('div.field', h('label', { text }), input, hint ? h('small.hint', { text: hint }) : null);

// q: existing question (API shape) or defaults; a: /academic payload; topics: string[]
export function questionEditor({ title = 'Question', q = {}, a, topics = [], lockSubject = false, onSave }) {
  return new Promise((resolve) => {
    const isImage = q.type === 'mcq' && q.image_file_id;
    let type = q.type ? (isImage ? 'image' : q.type) : 'mcq';
    let imageId = q.image_file_id || null;
    const k = q.answer_key || {};
    const typeSel = sel('type', Object.entries(TYPE_LABELS), type);
    const subject = sel('subjectId', [['', '— subject —'], ...a.subjects.map((s) => [s.id, s.name])], q.subject_id); if (lockSubject) subject.disabled = true;
    const klass = sel('classId', [['', 'Any class'], ...a.classes.map((c) => [c.id, c.display_name])], q.class_id);
    const dl = h('datalist', { id: 'topic-list' }, topics.map((t) => h('option', { value: t })));
    const topic = h('input.input', { value: q.topic || '', list: 'topic-list', maxlength: 120, placeholder: 'e.g. Algebra' });
    const subtopic = h('input.input', { value: q.subtopic || '', maxlength: 120, placeholder: 'e.g. Linear equations' });
    const diff = sel('difficulty', [['easy', 'Easy'], ['medium', 'Medium'], ['hard', 'Difficult']], q.difficulty || 'medium');
    const marks = h('input.input', { type: 'number', min: 0.5, max: 100, step: 0.5, value: q.marks ?? 1 });
    const text = h('textarea.input.q-editor', { rows: 5, maxlength: 4000, placeholder: 'Type the question. Maths: x^{2}, H_{2}O, \\frac{3}{4}, \\sqrt{16}, \\times, \\pi …', text: q.text || '' });
    const preview = h('div.q-preview');
    const drawPreview = () => clear(preview).appendChild(text.value.trim() ? renderRich(text.value) : h('span.muted', { text: 'Preview appears here' }));
    text.addEventListener('input', drawPreview);
    const insert = (snip) => { const s = text.selectionStart ?? text.value.length; const e = text.selectionEnd ?? s; text.value = text.value.slice(0, s) + snip + text.value.slice(e); text.focus(); text.selectionStart = text.selectionEnd = s + snip.length; drawPreview(); };
    const tools = h('div.math-tools', { role: 'toolbar', 'aria-label': 'Maths symbols' }, MATH_TOOLS.map(([l, snip]) => h('button.btn.btn-sm.btn-ghost', { type: 'button', text: l, title: snip.trim(), on: { click: () => insert(snip) } })));
    // image
    const imgBox = h('div.q-img-box');
    const drawImg = () => append(clear(imgBox), [imageId ? h('img.q-img', { src: fileUrl(imageId), alt: 'Question image' }) : h('span.muted', { text: 'No image' }),
      btn(imageId ? 'Replace image' : 'Add image', () => { const i = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp' }); i.addEventListener('change', async () => { const fd = new FormData(); fd.append('file', i.files[0]); try { imageId = (await api.post('/cbt/images', fd)).fileId; drawImg(); } catch (e) { toast(errMsg(e), 'err'); } }); i.click(); }, { ic: 'upload' }),
      imageId ? btn('Remove', () => { imageId = null; drawImg(); }, { kind: 'ghost' }) : null]);
    drawImg();
    // answers
    let options = (q.options && q.options.length && ['mcq', 'multi_select'].includes(q.type) ? q.options : [{ text: '' }, { text: '' }, { text: '' }, { text: '' }]).map((o) => ({ text: o.text || '', isCorrect: !!o.isCorrect }));
    const optBox = h('div.opt-editor');
    const drawOptions = () => {
      clear(optBox);
      const multi = type === 'multi_select';
      optBox.appendChild(h('small.hint', { text: multi ? 'Tick EVERY correct option (the candidate must choose exactly these).' : 'Choose the ONE correct option.' }));
      options.forEach((o, i) => {
        const mark = h('input', { type: multi ? 'checkbox' : 'radio', name: 'correct-opt', checked: o.isCorrect, 'aria-label': `Option ${LET[i]} is correct`, on: { change: (e) => { if (!multi) options.forEach((x) => { x.isCorrect = false; }); o.isCorrect = e.target.checked; } } });
        const inp = h('input.input', { value: o.text, maxlength: 1000, placeholder: `Option ${LET[i]}`, on: { input: (e) => { o.text = e.target.value; } } });
        optBox.appendChild(h('div.opt-row', h('strong', { text: LET[i] }), inp, h('label.check', mark, h('span', { text: 'correct' })),
          options.length > 2 ? h('button.icon-btn', { type: 'button', 'aria-label': `Remove option ${LET[i]}`, title: 'Remove option', on: { click: () => { options.splice(i, 1); drawOptions(); } } }, icon('x', 16)) : null));
      });
      if (options.length < 6) optBox.appendChild(btn('Add option', () => { options.push({ text: '' }); drawOptions(); }, { kind: 'ghost', ic: 'plus' }));
    };
    const tfTrue = h('input', { type: 'radio', name: 'tf', checked: q.type === 'true_false' && !!(q.options || []).find((o) => o.text === 'True' && o.isCorrect) });
    const tfFalse = h('input', { type: 'radio', name: 'tf', checked: q.type === 'true_false' && !!(q.options || []).find((o) => o.text === 'False' && o.isCorrect) });
    const numVal = h('input.input', { type: 'number', step: 'any', value: k.value ?? '' });
    const numTol = h('input.input', { type: 'number', step: 'any', min: 0, value: k.tolerance ?? 0 });
    const accepted = h('input.input', { value: (k.accepted || []).join(' | '), placeholder: 'three | 3' });
    const caseSens = h('input', { type: 'checkbox', checked: !!k.caseSensitive });
    const guide = h('textarea.input', { rows: 3, maxlength: 2000, text: q.theory_guide || '', placeholder: 'Marking guide for the teacher (never shown to candidates)' });
    const explanation = h('textarea.input', { rows: 2, maxlength: 4000, text: q.explanation || '', placeholder: 'Shown to candidates after submission only if the exam allows it' });
    const answerBox = h('div');
    const drawAnswer = () => {
      clear(answerBox);
      if (['mcq', 'multi_select', 'image'].includes(type)) { drawOptions(); answerBox.appendChild(lab(type === 'multi_select' ? 'Options (select all correct)' : 'Options', optBox)); }
      if (type === 'true_false') answerBox.appendChild(lab('Correct answer', h('div.checks', h('label.check', tfTrue, h('span', { text: 'True' })), h('label.check', tfFalse, h('span', { text: 'False' })))));
      if (type === 'numeric') answerBox.appendChild(h('div.form-grid', lab('Correct value', numVal), lab('Tolerance (±)', numTol, 'e.g. 0.01 accepts 3.49–3.51')));
      if (type === 'fill_blank' || type === 'short_answer') answerBox.appendChild(h('div.form-grid', lab('Accepted answer(s)', accepted, type === 'short_answer' ? 'Separate alternatives with |. Leave empty to mark by hand.' : 'Separate alternatives with |. Spaces and capital letters are ignored.'), lab('Options', h('label.check', caseSens, h('span', { text: 'Case-sensitive' })))));
      if (type === 'theory' || type === 'short_answer') answerBox.appendChild(lab('Marking guide', guide));
    };
    typeSel.addEventListener('change', () => { type = typeSel.value; if (type === 'mcq' && options.filter((o) => o.isCorrect).length > 1) options.forEach((o) => { o.isCorrect = false; }); drawAnswer(); });
    drawAnswer(); drawPreview();
    const alert = h('div.form-alert', { role: 'alert', hidden: true });
    const body = h('div.q-edit', alert, dl,
      h('div.form-grid', lab('Question type', typeSel), lab('Marks', marks), lab('Subject', subject), lab('Class', klass), lab('Topic', topic), lab('Sub-topic', subtopic), lab('Difficulty', diff)),
      lab('Question', h('div', tools, text)), lab('Preview', preview), lab('Image', imgBox, type === 'image' ? 'Image-based questions need an image.' : 'Optional — diagrams, graphs, maps'),
      answerBox, lab('Explanation', explanation));
    const collect = () => {
      const t = type === 'image' ? 'mcq' : type;
      const b = { type: t, text: text.value.trim(), marks: Number(marks.value) || 1, subjectId: subject.value || null, classId: klass.value || null, topic: topic.value.trim() || null, subtopic: subtopic.value.trim() || null,
        difficulty: diff.value, explanation: explanation.value.trim() || null, imageFileId: imageId };
      if (type === 'image' && !imageId) throw new Error('Add the image for this image-based question.');
      if (['mcq', 'multi_select'].includes(t)) b.options = options.filter((o) => o.text.trim()).map((o) => ({ text: o.text.trim(), isCorrect: !!o.isCorrect }));
      if (t === 'true_false') { if (!tfTrue.checked && !tfFalse.checked) throw new Error('Choose True or False as the correct answer.'); b.correct = tfTrue.checked; }
      if (t === 'numeric') { b.numericValue = numVal.value === '' ? undefined : Number(numVal.value); b.tolerance = Number(numTol.value) || 0; }
      if (t === 'fill_blank' || t === 'short_answer') { b.accepted = accepted.value.split('|').map((x) => x.trim()).filter(Boolean); b.caseSensitive = caseSens.checked; }
      if (t === 'theory' || t === 'short_answer') b.theoryGuide = guide.value.trim() || null;
      return b;
    };
    let done = false;
    const save = async () => {
      alert.hidden = true;
      try { const b = collect(); const r = await onSave(b); done = true; m.close(); resolve(r || true); }
      catch (e) { alert.textContent = e.status ? errMsg(e) : e.message; alert.hidden = false; alert.scrollIntoView({ block: 'nearest' }); }
    };
    const m = modal({ title, wide: true, body, onClose: () => { if (!done) resolve(null); }, actions: [h('button.btn', { type: 'button', text: 'Cancel', on: { click: () => m.close() } }), h('button.btn.btn-primary', { type: 'button', text: 'Save question', on: { click: save } })] });
  });
}

// read-only question card (bank preview, exam questions, printing)
export function questionCard(q, { n, showKey = true } = {}) {
  const k = q.answer_key || {};
  const opts = (q.options || []).length && q.type !== 'numeric' ? h('ol.q-opts', { type: 'A' }, q.options.map((o) => h('li', { class: showKey && o.isCorrect ? 'correct' : '' }, renderRich(o.text, { block: false }), showKey && o.isCorrect ? h('span.badge.badge-ok.tick', { text: 'Correct' }) : null))) : null;
  const key = !showKey ? null : q.type === 'numeric' ? `Answer: ${k.value}${k.tolerance ? ` (± ${k.tolerance})` : ''}` : k.accepted ? `Accepted: ${k.accepted.join(' / ')}${k.caseSensitive ? ' (case-sensitive)' : ''}` : q.type === 'theory' || (q.type === 'short_answer' && !k.accepted) ? `Marked by teacher${q.theory_guide ? ` — guide: ${q.theory_guide}` : ''}` : null;
  return h('div.q-card', h('div.q-head', h('strong', { text: n ? `${n}.` : '' }), h('span.badge.badge-info', { text: TYPE_LABELS[q.type === 'mcq' && q.image_file_id ? 'image' : q.type] }), q.topic ? h('span.badge.badge-muted', { text: q.topic }) : null,
    q.difficulty ? h('span.badge.badge-muted', { text: q.difficulty }) : null, h('span.muted', { text: `${Number(q.marks)} mark${Number(q.marks) === 1 ? '' : 's'}` })),
  renderRich(q.text), q.image_file_id ? h('img.q-img', { src: fileUrl(q.image_file_id), alt: 'Question image' }) : null, opts,
  key ? h('p.muted.q-key', { text: key }) : null, showKey && q.explanation ? h('p.q-expl', h('strong', { text: 'Explanation: ' }), renderRich(q.explanation, { block: false })) : null);
}
