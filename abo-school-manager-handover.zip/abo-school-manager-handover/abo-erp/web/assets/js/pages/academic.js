import { h, clear, append } from '../core/dom.js';
import { api, qs } from '../core/api.js';
import { can, session } from '../core/session.js';
import { pageHead, btn, formDialog, badge, card, toast, fail, confirmDialog, simpleTable, tabs, field, empty, stat } from '../core/ui.js';
import { date, today, tn } from '../core/format.js';
import { academic } from './people.js';

const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];

export async function setup(view, p, q) {
  const a = await academic(true); const manage = can('academic.manage');
  view.appendChild(pageHead('Academic setup', 'Sessions & terms, classes & arms, subjects, teacher assignments and timetables.'));
  const body = h('div');
  const show = (k) => { clear(body); ({ sessions, classes, subjects, timetable })[k](body, a, manage); };
  view.append(tabs([{ key: 'sessions', label: 'Sessions & terms' }, { key: 'classes', label: 'Classes & arms' }, { key: 'subjects', label: 'Subjects & teachers' }, { key: 'timetable', label: 'Timetable' }], show, q.tab || 'sessions'), body);
  show(q.tab || 'sessions');
}
function reload(tab) {
  const base = location.hash.split('?')[0];
  location.hash = base.startsWith('#/academic/') ? `${base}?t=${Date.now()}` : `#/academic?tab=${tab}&t=${Date.now()}`;
}
// ── one page per menu entry (Academics › …) ──
const page = (title, sub, fn) => async (view) => { const a = await academic(true); view.appendChild(pageHead(title, sub)); await fn(view, a, can('academic.manage')); };
export const classesPage = page('Classes & Arms', 'Every class and arm (e.g. JSS 1A, JSS 1B) with its section, form teacher and enrolment.', (v, a, m) => classes(v, a, m));
export const subjectsPage = page('Subjects', 'The subjects your school offers. Offer them per class under Subject Allocation.', (v, a, m) => subjectList(v, a, m));
export const allocationPage = page('Subject Allocation', 'Choose which subjects each class offers and who teaches them. Teachers can only enter scores for their allocated subjects.', (v, a, m) => allocation(v, a, m));
export const termsPage = page('Terms', 'First, second and third term dates, days the school opened and when the next term begins (printed on report cards).', (v, a, m) => sessions(v, a, m));
export const timetablePage = page('Timetable', 'Weekly class timetables.', (v, a, m) => timetable(v, a, m));
export const sessionsPage = page('Academic Session', 'Create a new session each year (three terms are added automatically) and choose the current one.', (el, a, manage) => {
  el.appendChild(h('div.page-actions.no-print', manage ? btn('New session', async () => { const r = await formDialog({ title: 'New academic session', fields: [{ name: 'name', label: 'Session', required: true, placeholder: '2026/2027' }, { name: 'startsOn', label: 'Starts', type: 'date' }, { name: 'endsOn', label: 'Ends', type: 'date' }, { name: 'isCurrent', label: 'Make current', type: 'checkbox' }], onSubmit: (v) => api.post('/academic/sessions', v) }); if (r) reload('sessions'); }, { kind: 'primary', ic: 'plus' }) : null));
  if (!a.sessions.length) return el.appendChild(empty('No sessions yet', 'Create your first academic session.'));
  el.appendChild(card(null, simpleTable([{ label: 'Session', render: (s) => h('strong', { text: s.name }) }, { label: 'Starts', render: (s) => date(s.starts_on) }, { label: 'Ends', render: (s) => date(s.ends_on) },
    { label: 'Terms', render: (s) => s.terms.map((t) => `${t.name}${t.is_current ? ' ●' : ''}`).join(' · ') },
    { label: '', render: (s) => (s.is_current ? badge('current session', 'ok') : manage ? btn('Make current', async () => { if (await confirmDialog({ title: `Make ${s.name} the current session?`, message: 'New enrolments, score sheets and attendance will use this session.' })) { try { await api.post(`/academic/sessions/${s.id}/current`); toast('Current session changed'); reload('sessions'); } catch (e) { fail(e); } } }, { kind: 'ghost' }) : null) },
    { label: '', render: () => h('a.btn.btn-sm.btn-ghost', { href: '#/academic/terms', text: 'Edit terms' }) }], a.sessions)));
});
export const teachersPage = async (view, p, q) => (await import('./people.js')).teachers(view, p, q);


function sessions(el, a, manage) {
  el.appendChild(h('div.page-actions.no-print', manage ? btn('New session', async () => { const r = await formDialog({ title: 'New academic session', fields: [{ name: 'name', label: 'Session', required: true, placeholder: '2026/2027' }, { name: 'startsOn', label: 'Starts', type: 'date' }, { name: 'endsOn', label: 'Ends', type: 'date' }, { name: 'isCurrent', label: 'Make current', type: 'checkbox' }], onSubmit: (v) => api.post('/academic/sessions', v) }); if (r) reload('sessions'); }, { kind: 'primary', ic: 'plus' }) : null));
  if (!a.sessions.length) return el.appendChild(empty('No sessions yet', 'Create your first academic session (three terms are added automatically).'));
  for (const s of a.sessions) {
    el.appendChild(card(`${s.name} session`, simpleTable([{ label: 'Term', render: (t) => `${tn(t.name)} term` }, { label: 'Starts', render: (t) => date(t.starts_on) }, { label: 'Ends', render: (t) => date(t.ends_on) }, { key: 'days_open', label: 'Days open' }, { label: 'Next term begins', render: (t) => date(t.next_term_begins) },
      { label: '', render: (t) => (t.is_current ? badge('current', 'ok') : manage ? btn('Make current', async () => { await api.patch(`/academic/terms/${t.id}`, { isCurrent: true }); reload('sessions'); }, { kind: 'ghost' }) : null) },
      { label: '', render: (t) => (manage ? btn('Edit', async () => { const r = await formDialog({ title: `${s.name} · ${tn(t.name)} term`, values: { startsOn: t.starts_on, endsOn: t.ends_on, daysOpen: t.days_open, nextTermBegins: t.next_term_begins }, fields: [{ name: 'startsOn', label: 'Starts', type: 'date' }, { name: 'endsOn', label: 'Ends', type: 'date' }, { name: 'daysOpen', label: 'Days school opened', type: 'number' }, { name: 'nextTermBegins', label: 'Next term begins', type: 'date' }], onSubmit: (v) => api.patch(`/academic/terms/${t.id}`, v) }); if (r) reload('sessions'); }, { kind: 'ghost' }) : null) }], s.terms), s.is_current ? badge('current session', 'ok') : null));
  }
}
async function classes(el, a, manage) {
  const staff = manage ? (await api.get('/staff?teachersOnly=true&pageSize=100')).items : [];
  const SECTIONS = [{ value: 'nursery', label: 'Nursery (Creche, Nursery, KG)' }, { value: 'primary', label: 'Primary' }, { value: 'secondary', label: 'Secondary (WAEC scale)' }];
  const run = async (fn, okMsg) => { try { await fn(); if (okMsg) toast(okMsg); reload('classes'); } catch (e) { fail(e); } };
  el.appendChild(h('div.page-actions.no-print', manage ? [
    btn('Add standard classes', async () => {
      const presets = (await api.get('/academic/class-presets')).items;
      const have = new Set(a.classes.map((c) => c.name.toLowerCase()));
      const r = await formDialog({ title: 'Add standard classes', wide: true, intro: 'Tick the classes your school runs. Classes you already have are skipped. You can rename any class later, or add your own with “Add class”.',
        fields: [...presets.map((p, i) => ({ name: `p${i}`, label: `${p.name}${have.has(p.name.toLowerCase()) ? ' (already added)' : ''}`, type: 'checkbox' })),
          { name: 'arms', label: 'Arms for each class (optional, comma separated)', placeholder: 'A, B', full: true, hint: 'Leave empty for one class each' }],
        onSubmit: (v) => { const names = presets.filter((p, i) => v[`p${i}`]).map((p) => p.name); if (!names.length) throw new Error('Tick at least one class.'); return api.post('/academic/classes/presets', { names, arms: (v.arms || '').split(',').map((x) => x.trim()).filter(Boolean) }); } });
      if (r) { toast(`${r.items.length} class(es) added${r.skipped.length ? ` · ${r.skipped.length} already existed` : ''}`); reload('classes'); }
    }, { ic: 'layers' }),
    btn('Add class', async () => {
      const r = await formDialog({ title: 'Add your own class', intro: 'Any name and level you use (for example “Pre-Nursery”, “Grade 7” or “Year 9”). Arms create separate registers: PRIMARY 1 + arms A, B → PRIMARY 1A, PRIMARY 1B.', fields: [{ name: 'name', label: 'Class name', required: true, placeholder: 'Primary 1 / JSS 2 / Year 9' },
        { name: 'level', label: 'Level (optional)', placeholder: 'Nursery / Primary / Junior Secondary…' },
        { name: 'section', label: 'Grading scale', type: 'select', required: true, options: SECTIONS },
        { name: 'arms', label: 'Arms (comma separated)', placeholder: 'A, B, C', hint: 'Leave empty for a single class' }, { name: 'capacity', label: 'Capacity per arm', type: 'number' }],
      onSubmit: (v) => api.post('/academic/classes', { name: v.name, level: v.level || null, section: v.section, capacity: v.capacity || null, arms: (v.arms || '').split(',').map((x) => x.trim()).filter(Boolean) }) });
      if (r) reload('classes');
    }, { kind: 'primary', ic: 'plus' })] : null));
  const list = a.classes;
  const move = (c, dir) => { const act = list.filter((x) => x.active !== false); const i = act.findIndex((x) => x.id === c.id); const j = i + dir; if (j < 0 || j >= act.length) return; [act[i], act[j]] = [act[j], act[i]]; run(() => api.put('/academic/classes/order', { ids: [...act, ...list.filter((x) => x.active === false)].map((x) => x.id) })); };
  el.appendChild(card(null, simpleTable([
    { label: 'Class', render: (c) => h('div', h('strong', { text: c.display_name }), c.active === false ? h('span.badge.badge-muted', { text: ' switched off' }) : null) },
    { label: 'Level', render: (c) => c.level || '—' }, { label: 'Grading', render: (c) => badge(c.section, 'info') }, { key: 'students', label: 'Pupils', cls: 'num' }, { label: 'Form teacher', render: (c) => c.form_teacher || '—' },
    { label: '', render: (c) => (manage ? h('div.page-actions.class-actions',
      c.active !== false ? [btn('', () => move(c, -1), { kind: 'ghost', ic: 'chevronLeft', title: 'Move up' }), btn('', () => move(c, 1), { kind: 'ghost', ic: 'chevron', title: 'Move down' })] : null,
      btn('Edit', async () => {
        const r = await formDialog({ title: `Edit ${c.display_name}`, intro: 'Renaming updates the class everywhere at once — registers, score sheets, broadsheets, report cards and past results. Nothing is lost.',
          values: { name: c.name, arm: c.arm, level: c.level || '', section: c.section, capacity: c.capacity || '' },
          fields: [{ name: 'name', label: 'Class name', required: true }, { name: 'arm', label: 'Arm', placeholder: 'A' }, { name: 'level', label: 'Level' }, { name: 'section', label: 'Grading scale', type: 'select', placeholder: false, options: SECTIONS }, { name: 'capacity', label: 'Capacity', type: 'number' }],
          onSubmit: (v) => api.patch(`/academic/classes/${c.id}`, { name: v.name, arm: v.arm || '', level: v.level || null, section: v.section, capacity: v.capacity ? Number(v.capacity) : null }) });
        if (r) { toast('Class updated'); reload('classes'); }
      }, { kind: 'ghost' }),
      btn('Form teacher', async () => { const r = await formDialog({ title: `Form teacher · ${c.display_name}`, values: { formTeacherId: c.form_teacher_id }, fields: [{ name: 'formTeacherId', label: 'Teacher', type: 'select', options: staff.map((x) => ({ value: x.id, label: x.full_name })) }], onSubmit: (v) => api.patch(`/academic/classes/${c.id}`, { formTeacherId: v.formTeacherId || null }) }); if (r) reload('classes'); }, { kind: 'ghost' }),
      c.active !== false
        ? btn('Switch off', async () => { if (await confirmDialog({ title: `Switch off ${c.display_name}?`, message: 'The class is hidden from new registrations but ALL its records (pupils’ past results, attendance, report cards) stay. You can switch it on again at any time. Move its pupils first.' })) run(() => api.patch(`/academic/classes/${c.id}`, { active: false }), 'Class switched off'); }, { kind: 'ghost' })
        : btn('Switch on', () => run(() => api.patch(`/academic/classes/${c.id}`, { active: true }), 'Class switched on'), { kind: 'ghost' }),
      btn('Delete', async () => { if (await confirmDialog({ title: `Delete ${c.display_name}?`, message: 'Only a class that never had pupils can be deleted. For any other class use “Switch off”.', danger: true })) { try { await api.del(`/academic/classes/${c.id}`); reload('classes'); } catch (e) { fail(e); } } }, { kind: 'ghost' })) : null) }],
  list, 'No classes yet — use “Add standard classes” to start')));
}
async function subjects(el, a, manage) { await subjectList(el, a, manage); await allocation(el, a, manage); }
async function subjectList(el, a, manage) {
  el.appendChild(h('div.page-actions.no-print', manage ? btn('Add subjects', async () => { const r = await formDialog({ title: 'Add subjects', fields: [{ name: 'names', label: 'Subjects (one per line)', type: 'textarea', full: true, rows: 6, placeholder: 'English Language\nMathematics\nBasic Science' }], onSubmit: (v) => api.post('/academic/subjects', { names: String(v.names || '').split('\n').map((x) => x.trim()).filter(Boolean) }) }); if (r) reload('subjects'); }, { kind: 'primary', ic: 'plus' }) : null));
  if (!a.subjects.length) return el.appendChild(empty('No subjects yet', 'Add the subjects your school offers.'));
  el.appendChild(card(`Subjects (${a.subjects.length})`, simpleTable([{ key: 'name', label: 'Subject' }, { label: 'Code', render: (s) => s.code || '—' },
    { label: '', render: (s) => (manage ? btn('Delete', async () => { if (await confirmDialog({ title: `Delete ${s.name}?`, message: 'Only subjects without score sheets can be deleted.', danger: true })) { try { await api.del(`/academic/subjects/${s.id}`); toast('Subject deleted'); reload('subjects'); } catch (e) { fail(e); } } }, { kind: 'ghost' }) : null) }], a.subjects)));
}
async function allocation(el, a, manage) {
  if (!a.classes.length) return el.appendChild(empty('No classes yet', 'Create classes first under Classes & Arms.'));
  const sel = field({ name: 'cls', label: 'Class', type: 'select', options: a.classes.map((c) => ({ value: c.id, label: c.display_name })), placeholder: 'Choose a class…' });
  const box = h('div');
  el.appendChild(card('Subjects & teachers per class', [sel, box]));
  // only allocators need the staff list (teachers may not have staff.view) — others get a read-only table
  const staff = manage ? (await api.get('/staff?teachersOnly=true&pageSize=100')).items : [];
  sel.querySelector('select').addEventListener('change', async (e) => {
    clear(box); if (!e.target.value) return;
    const cur = (await api.get(`/academic/classes/${e.target.value}/subjects`)).items; const map = new Map(cur.map((x) => [x.subject_id, x.teacher_id]));
    if (!manage) { box.appendChild(simpleTable([{ key: 'subject', label: 'Subject offered' }, { label: 'Subject teacher', render: (x) => x.teacher || '—' }], cur, 'No subjects allocated to this class yet')); return; }
    const rows = a.subjects.map((s) => { const on = h('input', { type: 'checkbox', checked: map.has(s.id), disabled: !manage }); const t = h('select.input', { disabled: !manage }, h('option', { value: '', text: '— teacher —' }), staff.map((x) => h('option', { value: x.id, text: x.full_name, selected: map.get(s.id) === x.id })));
      return { s, on, t, row: h('tr', h('td', h('label.check', on, h('span', { text: s.name }))), h('td', t)) }; });
    append(box, [h('div.table-wrap', h('table.table', h('thead', h('tr', h('th', { text: 'Subject offered' }), h('th', { text: 'Subject teacher' }))), h('tbody', rows.map((r) => r.row)))),
      manage ? h('div.page-actions', btn('Save allocation', async () => { try { await api.put(`/academic/classes/${e.target.value}/subjects`, { items: rows.filter((r) => r.on.checked).map((r) => ({ subjectId: r.s.id, teacherId: r.t.value || null })) }); toast('Allocation saved'); } catch (err) { fail(err); } }, { kind: 'primary' })) : null]);
  });
}
async function timetable(el, a, manage) {
  const sel = field({ name: 'cls', label: 'Class', type: 'select', options: a.classes.map((c) => ({ value: c.id, label: c.display_name })), placeholder: 'Choose a class…' });
  const box = h('div'); el.appendChild(card('Weekly timetable', [sel, box]));
  sel.querySelector('select').addEventListener('change', async (e) => { clear(box); if (e.target.value) box.appendChild(await timetableGrid(e.target.value, a, manage)); });
}
export async function timetableGrid(classId, a, manage) {
  const items = (await api.get(`/academic/classes/${classId}/timetable`)).items;
  const subs = manage ? (await api.get(`/academic/classes/${classId}/subjects`)).items : [];
  const periods = Math.max(8, ...items.map((i) => i.period));
  const cells = [];
  const tbl = h('table.table', h('thead', h('tr', h('th', { text: 'Period' }), DAYS.map((d) => h('th', { text: d })))), h('tbody', Array.from({ length: periods }, (_, pi) => h('tr', h('th', { text: `P${pi + 1}` }), DAYS.map((d, di) => {
    const it = items.find((x) => x.day_of_week === di + 1 && x.period === pi + 1);
    if (!manage) return h('td', { text: it ? (it.subject || it.label || '') : '' });
    const s = h('select.input', h('option', { value: '', text: '—' }), subs.map((x) => h('option', { value: x.subject_id, text: x.subject, selected: it && it.subject_id === x.subject_id })), h('option', { value: 'BREAK', text: 'Break', selected: it && it.label === 'Break' }));
    cells.push({ d: di + 1, p: pi + 1, s }); return h('td', s);
  })))));
  return h('div', h('div.table-wrap', tbl), manage ? h('div.page-actions', btn('Save timetable', async () => { try { await api.put(`/academic/classes/${classId}/timetable`, { items: cells.filter((c) => c.s.value).map((c) => ({ dayOfWeek: c.d, period: c.p, subjectId: c.s.value === 'BREAK' ? null : c.s.value, label: c.s.value === 'BREAK' ? 'Break' : null })) }); toast('Timetable saved'); } catch (e) { fail(e); } }, { kind: 'primary' }), btn('Print', () => window.print(), { ic: 'printer' })) : null);
}

// ── attendance: big touch targets, one tap per learner, works on phones ──
export async function attendance(view, p, q) {
  const a = await academic(); const me = session.me;
  const d = await api.get('/dashboard');
  const mine = (d.myClasses || []).filter((c) => c.form_teacher).map((c) => c.id);
  const allowed = can('attendance.update', 'attendance.view') ? a.classes : a.classes.filter((c) => mine.includes(c.id));
  view.appendChild(pageHead('Attendance', 'Mark the daily register. Parents of absent learners are notified automatically.'));
  if (!allowed.length) return view.appendChild(empty('No classes to mark', 'You can mark attendance for classes where you are the form teacher.'));
  const cls = field({ name: 'cls', label: 'Class', type: 'select', placeholder: false, options: allowed.map((c) => ({ value: c.id, label: c.display_name })) }, q.classId || allowed[0].id);
  const dt = field({ name: 'date', label: 'Date', type: 'date' }, today());
  const box = h('div'); const sum = h('div');
  view.append(card(null, h('div.form-grid', cls, dt)), box, sum);
  const load = async () => {
    clear(box); clear(sum);
    const classId = cls._get(); const date = dt._get() || today();
    const r = await api.get(`/attendance/class/${classId}${qs({ date })}`);
    const canMark = can('attendance.update') || mine.includes(classId);
    const remarks = h('input.input', { value: (r.session && r.session.remarks) || '', placeholder: 'e.g. Heavy rain — late arrivals', maxlength: 500, 'aria-label': 'Register remarks' });
    const state = new Map(r.items.map((x) => [x.student_id, x.status || 'present']));
    const opts = ['present', 'absent', 'late', 'excused'];
    const counts = h('div.chips');
    const recount = () => { clear(counts); const c = {}; for (const v of state.values()) c[v] = (c[v] || 0) + 1; opts.forEach((o) => counts.appendChild(badge(`${o}: ${c[o] || 0}`, { present: 'ok', absent: 'danger', late: 'warn', excused: 'info' }[o]))); };
    const rows = r.items.map((x) => h('div.list-item', h('span', h('strong', { text: `${x.last_name} ${x.first_name}` }), h('small.muted', { text: ` ${x.admission_no}` })),
      h('div.page-actions', opts.map((o) => { const b = h(`button.btn.btn-sm${state.get(x.student_id) === o ? '.btn-primary' : ''}`, { text: o[0].toUpperCase() + o.slice(1), disabled: !canMark, 'aria-pressed': state.get(x.student_id) === o ? 'true' : 'false',
        on: { click: (e) => { state.set(x.student_id, o); e.target.parentElement.querySelectorAll('button').forEach((y) => { y.classList.remove('btn-primary'); y.setAttribute('aria-pressed', 'false'); }); e.target.classList.add('btn-primary'); e.target.setAttribute('aria-pressed', 'true'); recount(); } } }); return b; }))));
    recount();
    box.appendChild(card(`Register · ${r.date}`, r.items.length ? h('div.list', rows) : empty('No learners enrolled in this class'), counts,
      canMark && r.items.length ? btn('Mark all present', () => { for (const k of state.keys()) state.set(k, 'present'); load(); }, { kind: 'ghost' }) : null,
      canMark && r.items.length ? btn('Save register', async () => { try { const res = await api.put(`/attendance/class/${classId}`, { date, remarks: remarks.value.trim() || null, entries: [...state].map(([studentId, status]) => ({ studentId, status })) }); toast(`Saved ${res.saved} records`); } catch (e) { fail(e); } }, { kind: 'primary' }) : null));
    box.firstChild.querySelector('.card-body').prepend(h('div.field', h('label', { text: r.session ? `Register taken by ${r.session.taken_by || '—'}` : 'Register remarks (optional)' }), remarks));
    const s = await api.get(`/attendance/summary${qs({ classId })}`);
    sum.appendChild(card('This term so far', simpleTable([{ label: 'Learner', render: (x) => `${x.last_name} ${x.first_name}` }, { key: 'present', label: 'Present', cls: 'num' }, { key: 'absent', label: 'Absent', cls: 'num' }, { key: 'late', label: 'Late', cls: 'num' }, { key: 'excused', label: 'Excused', cls: 'num' }], s.items)));
  };
  cls.querySelector('select').addEventListener('change', load); dt.querySelector('input').addEventListener('change', load);
  load().catch(fail); void me;
}

export async function promotion(view) {
  const a = await academic(true);
  view.appendChild(pageHead('End-of-session promotion', 'Preview first, then run. Promotion reads a frozen snapshot (no cascades) and the latest run can be undone.'));
  if (a.sessions.length < 2) return view.appendChild(empty('Create next session first', 'Add the next academic session under Academic setup, then come back here.'));
  const from = field({ name: 'from', label: 'From session', type: 'select', placeholder: false, options: a.sessions.map((s) => ({ value: s.id, label: s.name })) }, (a.sessions.find((s) => s.is_current) || a.sessions[1]).id);
  const to = field({ name: 'to', label: 'To session', type: 'select', placeholder: false, options: a.sessions.map((s) => ({ value: s.id, label: s.name })) }, a.sessions[0].id);
  const rows = a.classes.map((c) => ({ c, sel: h('select.input', h('option', { value: '', text: 'Skip' }), h('option', { value: 'GRAD', text: 'Graduate (leaves school)' }), a.classes.map((x) => h('option', { value: x.id, text: `→ ${x.display_name}` }))) }));
  const result = h('div');
  const map = () => rows.filter((r) => r.sel.value).map((r) => (r.sel.value === 'GRAD' ? { fromClassId: r.c.id, graduate: true } : { fromClassId: r.c.id, toClassId: r.sel.value }));
  const run = async (dryRun) => {
    try {
      if (!dryRun && !(await confirmDialog({ title: 'Run promotion?', message: 'Learners will be enrolled in the target session. You can undo the most recent run.', confirmLabel: 'Run promotion' }))) return;
      const r = await api.post('/academic/promotion', { fromSessionId: from._get(), toSessionId: to._get(), map: map(), dryRun });
      clear(result).appendChild(card(dryRun ? 'Preview' : 'Promotion complete', h('div.stats', stat('Promoted', r.summary.promoted, '', 'layers'), stat('Graduated', r.summary.graduated, '', 'check', 'gold'), stat('Repeating', r.summary.repeated, '', 'activity'), stat('Skipped', r.summary.skipped, '', 'x', 'red')),
        !dryRun ? btn('Undo this run', async () => { try { await api.post(`/academic/promotion/${r.runId}/undo`); toast('Promotion undone'); clear(result); } catch (e) { fail(e); } }, { kind: 'danger' }) : null));
    } catch (e) { fail(e); }
  };
  view.append(card('Sessions', h('div.form-grid', from, to)), card('Class mapping', simpleTable([{ label: 'From class', render: (r) => r.c.display_name }, { label: 'Learners', render: (r) => r.c.students }, { label: 'Moves to', render: (r) => r.sel }], rows), btn('Preview', () => run(true)), btn('Run promotion', () => run(false), { kind: 'primary' })), result);
}
