import { h, clear } from '../core/dom.js';
import { api, qs } from '../core/api.js';
import { session } from '../core/session.js';
import { pageHead, btn, card, badge, simpleTable, empty, field, formDialog, fail, toast, spinner } from '../core/ui.js';
import { naira, date, tn } from '../core/format.js';
import { renderReport } from './results.js';
import { timetableGrid } from './academic.js';

const kids = () => (session.me.portal === 'student' ? [{ id: session.me.studentId, first_name: 'Me', last_name: '' }] : session.me.children);
function kidPicker(onChange, initial) {
  const list = kids(); if (list.length <= 1) return null;
  const f = field({ name: 'kid', label: 'Child', type: 'select', placeholder: false, options: list.map((k) => ({ value: k.id, label: `${k.first_name} ${k.last_name} · ${k.class_name || ''}` })) }, initial);
  f.querySelector('select').addEventListener('change', (e) => onChange(e.target.value)); return f;
}
export async function myResults(view, p, q) {
  const list = kids(); if (!list.length || !list[0].id) return view.appendChild(empty('No learner linked to your account', 'Please contact the school office.'));
  const box = h('div'); let current = q.student || list[0].id; let termId = q.termId || '';
  // term picker: only terms with a published report card for this child (2nd/3rd term cards include "results so far")
  const termBox = h('div.portal-term');
  const load = async (id, tid) => {
    current = id; termId = tid || '';
    clear(box).appendChild(spinner());
    try {
      const r = await api.get(`/results/student/${id}${qs({ termId })}`);
      clear(termBox);
      if (r.resultTerms && r.resultTerms.length) {
        const opts = r.resultTerms.map((t) => ({ value: t.id, label: `${t.session} · ${tn(t.name)} term` }));
        if (r.termId && !opts.some((o) => o.value === r.termId)) opts.unshift({ value: r.termId, label: 'Current term (not published yet)' });
        const f = field({ name: 'termId', label: 'Term', type: 'select', placeholder: false, options: opts }, r.termId);
        f.querySelector('select').addEventListener('change', (e) => load(current, e.target.value).catch(fail));
        termBox.appendChild(f);
      }
      clear(box).appendChild(r.available ? renderReport(r, { studentId: id, termId: r.termId }) : empty('Results not available yet', r.resultTerms && r.resultTerms.length ? `${r.message} Choose an earlier term above to see past report cards.` : r.message));
    } catch (e) { clear(box); fail(e); }
  };
  view.append(pageHead(session.me.portal === 'parent' ? 'Children’s results' : 'My results', 'Published report cards only. From 2nd term, the report card also shows the results so far this session (cumulative). Contact the school if something looks wrong.'),
    h('div.form-grid.pickers.no-print', kidPicker((id) => load(id, '').catch(fail), current), termBox), box);
  load(current, termId).catch(fail);
}
export async function myFees(view) {
  const d = await api.get('/fees/my');
  view.appendChild(pageHead('Fees & payments', 'Invoices and receipts. Online payment is confirmed only after the school server verifies it with the payment provider.'));
  if (!d.items.length) return view.appendChild(empty('No invoices yet'));
  view.appendChild(card(null, simpleTable([{ key: 'invoice_no', label: 'Invoice' }, { key: 'student', label: 'Learner' }, { label: 'Term', render: (x) => (x.kind === 'brought_forward' ? `Fees owed from before${x.note ? ` (${x.note})` : ''}` : x.term ? `${x.session} · ${x.term}` : '—') }, { label: 'Total', cls: 'num', render: (x) => naira(x.total_kobo) }, { label: 'Paid', cls: 'num', render: (x) => naira(x.paid_kobo) },
    { label: 'Balance', cls: 'num', render: (x) => h('strong', { text: naira(x.balance_kobo) }) }, { label: 'Status', render: (x) => badge(x.status) }, { label: 'Due', render: (x) => date(x.due_date) },
    { label: '', render: (x) => h('div.page-actions', h('a.btn.btn-sm', { href: `#/fees/invoice/${x.id}`, text: 'View' }), d.onlinePayments && Number(x.balance_kobo) > 0 ? btn('Pay online', async () => {
      const r = await formDialog({ title: `Pay ${naira(x.balance_kobo)} online`, fields: [{ name: 'email', label: 'Email for receipt', type: 'email', required: true }], values: { email: session.me.user.email }, onSubmit: (v) => api.post(`/fees/invoices/${x.id}/pay-online`, v) });
      if (r && r.authorizationUrl && /^https:\/\//.test(r.authorizationUrl)) { toast('Redirecting to secure checkout…'); window.location.assign(r.authorizationUrl); }
    }, { kind: 'primary' }) : null) }], d.items)));
}
export async function timetable(view) {
  const list = kids().filter((k) => k.id);
  view.appendChild(pageHead('Timetable', 'Weekly class timetable.'));
  const me = await api.get('/dashboard'); const children = me.children || [];
  if (!children.length || !children[0].class_id) return view.appendChild(empty('No class timetable yet'));
  for (const c of children) if (c.class_id) view.appendChild(card(`${c.first_name} ${c.last_name} · ${c.class_name}`, await timetableGrid(c.class_id, null, false)));
  void list;
}
