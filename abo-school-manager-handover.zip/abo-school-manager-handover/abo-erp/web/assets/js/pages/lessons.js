// Lesson Notes — teachers write weekly notes for their assigned class/subjects, heads review them, and approved notes
// that are shared with the class become readable by the class's students and parents. The server enforces every rule;
// this page only reflects what the API allows (see `can` on each note).
import { h, clear, icon } from '../core/dom.js';
import { api, qs, download } from '../core/api.js';
import { can, portal, session } from '../core/session.js';
import { pageHead, btn, badge, card, toast, fail, confirmDialog, empty, dataTable, field, simpleTable, stat, spinner, errMsg, tabs } from '../core/ui.js';
import { ago, date, dateTime, tn } from '../core/format.js';
import { docHead } from './broadsheets.js';

const WEEKS = Array.from({ length: 16 }, (_, i) => ({ value: String(i + 1), label: `Week ${i + 1}` }));
const STATUS = [{ value: 'draft', label: 'Draft' }, { value: 'submitted', label: 'Awaiting review' }, { value: 'approved', label: 'Approved' }, { value: 'returned', label: 'Returned for correction' }];
const statusLabel = (s) => (STATUS.find((x) => x.value === s) || { label: s }).label;
const statusBadge = (s) => badge(statusLabel(s), { draft: 'muted', submitted: 'info', approved: 'ok', returned: 'warn' }[s]);
const learner = () => ['student', 'parent'].includes(portal());
const termName = (t) => `${t.session_name} · ${tn(t.name)} term${t.is_current ? ' (current)' : ''}`;
let optsCache = null;
const options = async () => (optsCache = optsCache || await api.get('/lesson-notes/options'));

// ───────────────────────── list ─────────────────────────
export async function list(view, p, q) {
  if (learner()) return learnerList(view, q);
  const mayWrite = can('lesson_notes.create', 'lesson_notes.review'); const reviewer = can('lesson_notes.review'); const viewer = can('lesson_notes.view', 'lesson_notes.review');
  const scopes = [can('lesson_notes.create') ? { key: 'mine', label: 'My notes' } : null, reviewer ? { key: 'review', label: 'Review queue' } : null, viewer ? { key: 'all', label: 'All notes' } : null].filter(Boolean);
  const scope = scopes.some((s) => s.key === q.scope) ? q.scope : (scopes[0] || { key: 'mine' }).key;
  const subs = { mine: 'Write, submit and track your weekly lesson notes.', review: 'Notes submitted by teachers and waiting for your decision (oldest first).', all: 'Every lesson note in the school, with its review status.' };
  view.appendChild(pageHead('Lesson Notes', subs[scope],
    viewer ? h('a.btn', { href: '#/lesson-notes/summary' }, icon('chart', 16), h('span', { text: 'Coverage report' })) : null,
    mayWrite ? h('a.btn.btn-primary', { href: '#/lesson-notes/new' }, icon('plus', 16), h('span', { text: 'Write lesson note' })) : null));
  if (scopes.length > 1) view.appendChild(tabs(scopes, (k) => { location.hash = `#/lesson-notes?scope=${k}`; }, scope));
  let o = { terms: [], pairs: [] };
  try { o = mayWrite ? await options() : { terms: (await api.get('/academic')).sessions.flatMap((s) => s.terms.map((t) => ({ ...t, session_name: s.name }))), pairs: [] }; } catch { /* filters degrade */ }
  const acad = viewer ? await api.get('/academic').catch(() => null) : null;
  const classes = acad ? acad.classes.map((c) => ({ value: c.id, label: c.display_name })) : [...new Map(o.pairs.map((x) => [x.class_id, { value: x.class_id, label: x.class_name }])).values()];
  const subjects = acad ? acad.subjects.map((s) => ({ value: s.id, label: s.name })) : [...new Map(o.pairs.map((x) => [x.subject_id, { value: x.subject_id, label: x.subject }])).values()];
  const filters = [{ name: 'termId', label: 'Term', placeholder: 'All terms', options: o.terms.map((t) => ({ value: t.id, label: termName(t) })) },
    { name: 'classId', label: 'Class', placeholder: 'All classes', options: classes }, { name: 'subjectId', label: 'Subject', placeholder: 'All subjects', options: subjects }];
  if (scope !== 'review') filters.push({ name: 'status', label: 'Status', placeholder: 'Any status', options: STATUS });
  const cols = [{ key: 'week', label: 'Week', cls: 'num', render: (r) => String(r.week) },
    { key: 'topic', label: 'Topic', render: (r) => h('div', h('strong', { text: r.topic }), r.subtopic ? h('div.muted', { text: r.subtopic }) : null) },
    { key: 'class_name', label: 'Class' }, { key: 'subject', label: 'Subject' },
    scope !== 'mine' ? { key: 'author', label: 'Teacher' } : null,
    { key: 'status', label: 'Status', render: (r) => statusBadge(r.status) },
    { key: 'updated_at', label: scope === 'review' ? 'Submitted' : 'Updated', render: (r) => ago(scope === 'review' ? r.submitted_at : r.updated_at) }].filter(Boolean);
  view.appendChild(card(null, dataTable({ columns: cols, filters, rowClick: (r) => { location.hash = `#/lesson-notes/${r.id}`; },
    load: (x) => api.get(`/lesson-notes${qs({ ...x, scope })}`),
    empty: scope === 'review' ? 'Nothing waiting for review' : 'No lesson notes yet',
    emptyHint: scope === 'mine' ? 'Use “Write lesson note” to prepare your first note for the week.' : scope === 'review' ? 'Submitted notes will appear here.' : undefined })));
}

// ───────────────────────── editor ─────────────────────────
export async function editor(view, p) {
  const o = await options();
  let n = null;
  if (p.id) {
    n = await api.get(`/lesson-notes/${p.id}`);
    if (!n.can || !n.can.edit) { location.hash = `#/lesson-notes/${p.id}`; return; }
  }
  view.appendChild(pageHead(n ? 'Edit Lesson Note' : 'Write Lesson Note', n ? `${n.class_name} · ${n.subject} · Week ${n.week}` : 'Prepare the note, save it as a draft, then submit it for review when it is ready.',
    h('a.btn', { href: n ? `#/lesson-notes/${n.id}` : '#/lesson-notes' }, h('span', { text: 'Cancel' }))));
  if (!n && !o.pairs.length) {
    view.appendChild(card(null, empty('No class or subject assigned to you yet', 'Ask the school administrator to assign you a class and subject under Staff & Teachers › Assigned Subjects.')));
    return;
  }
  if (n && n.status === 'returned' && n.review_note) view.appendChild(h('div.alert.alert-warn', icon('flag', 16), h('div', h('strong', { text: 'Returned for correction: ' }), h('span', { text: n.review_note }))));
  const current = o.terms.find((t) => t.is_current) || o.terms[0] || {};
  const classOpts = [...new Map(o.pairs.map((x) => [x.class_id, { value: x.class_id, label: x.class_name }])).values()];
  const f = {
    termId: field({ name: 'termId', label: 'Term', type: 'select', placeholder: false, required: true, disabled: !!n, options: o.terms.map((t) => ({ value: t.id, label: termName(t) })) }, n ? n.term_id : current.id),
    classId: field({ name: 'classId', label: 'Class', type: 'select', required: true, disabled: !!n, options: n ? [{ value: n.class_id, label: n.class_name }] : classOpts }, n ? n.class_id : (classOpts.length === 1 ? classOpts[0].value : '')),
    subjectId: field({ name: 'subjectId', label: 'Subject', type: 'select', required: true, disabled: !!n, options: n ? [{ value: n.subject_id, label: n.subject }] : [] }, n ? n.subject_id : ''),
    week: field({ name: 'week', label: 'Week', type: 'select', placeholder: false, required: true, options: WEEKS }, String(n ? n.week : 1)),
    lessonDate: field({ name: 'lessonDate', label: 'Lesson date', type: 'date' }, n && n.lesson_date ? String(n.lesson_date).slice(0, 10) : ''),
    duration: field({ name: 'duration', label: 'Duration', placeholder: 'e.g. 40 minutes', max: 40 }, n ? n.duration : '40 minutes'),
    topic: field({ name: 'topic', label: 'Topic', required: true, full: true, max: 200 }, n ? n.topic : ''),
    subtopic: field({ name: 'subtopic', label: 'Sub-topic', full: true, max: 200 }, n ? n.subtopic : ''),
    objectives: field({ name: 'objectives', label: 'Behavioural objectives', type: 'textarea', rows: 4, full: true, max: 4000, hint: 'By the end of the lesson, pupils should be able to…' }, n ? n.objectives : ''),
    materials: field({ name: 'materials', label: 'Instructional materials', type: 'textarea', rows: 2, full: true, max: 2000 }, n ? n.materials : ''),
    priorKnowledge: field({ name: 'priorKnowledge', label: 'Previous knowledge', type: 'textarea', rows: 2, full: true, max: 2000 }, n ? n.prior_knowledge : ''),
    content: field({ name: 'content', label: 'Lesson content / presentation', type: 'textarea', rows: 14, required: true, full: true, max: 60000, hint: 'Introduction, step-by-step presentation, examples and class activities.' }, n ? n.content : ''),
    evaluation: field({ name: 'evaluation', label: 'Evaluation', type: 'textarea', rows: 3, full: true, max: 4000 }, n ? n.evaluation : ''),
    assignment: field({ name: 'assignment', label: 'Assignment / homework', type: 'textarea', rows: 3, full: true, max: 4000 }, n ? n.assignment : ''),
    shareWithClass: field({ name: 'shareWithClass', label: 'Share with the class once approved (students and parents can read it)', type: 'checkbox' }, n ? n.share_with_class : true),
    file: field({ name: 'file', label: n && n.file_name ? `Attachment (replaces ${n.file_name})` : 'Attachment (optional)', type: 'file', accept: '.pdf,.docx,.pptx,image/png,image/jpeg,image/webp', hint: 'PDF, Word, PowerPoint or image — up to 5 MB.' }),
  };
  const subjSel = f.subjectId.querySelector('select');
  const fillSubjects = () => {
    if (n) return;
    const cid = f.classId._get(); const keep = subjSel.value;
    clear(subjSel).appendChild(h('option', { value: '', text: cid ? 'Select…' : 'Choose a class first' }));
    for (const x of o.pairs.filter((y) => y.class_id === cid)) subjSel.appendChild(h('option', { value: x.subject_id, text: x.subject, selected: x.subject_id === keep }));
    const opts = o.pairs.filter((y) => y.class_id === cid); if (opts.length === 1) subjSel.value = opts[0].subject_id;
  };
  f.classId.querySelector('select').addEventListener('change', fillSubjects); fillSubjects();
  const alert = h('div.form-alert', { role: 'alert', hidden: true });
  const section = (t) => h('h3.form-section', { text: t });
  const grid = h('div.form-grid', section('Class & period'), f.termId, f.classId, f.subjectId, f.week, f.lessonDate, f.duration,
    section('Lesson plan'), f.topic, f.subtopic, f.objectives, f.materials, f.priorKnowledge, f.content, f.evaluation, f.assignment,
    section('Sharing & attachment'), f.shareWithClass, f.file);
  const values = () => {
    const v = {}; for (const [k, w] of Object.entries(f)) if (k !== 'file') v[k] = w._get();
    v.week = Number(v.week); for (const k of ['subtopic', 'objectives', 'materials', 'priorKnowledge', 'evaluation', 'assignment', 'duration', 'lessonDate']) if (v[k] === null) v[k] = null;
    return v;
  };
  const showErr = (e) => {
    grid.querySelectorAll('.field').forEach((w) => { w.classList.remove('has-err'); w.querySelector('.err').textContent = ''; });
    const name = e && e.details && e.details.field && e.details.field.split('.')[0]; const w = name && f[name];
    if (w) { w.classList.add('has-err'); w.querySelector('.err').textContent = errMsg(e); const i = w.querySelector('input,select,textarea'); if (i) i.focus(); }
    else { alert.textContent = errMsg(e); alert.hidden = false; alert.scrollIntoView({ block: 'center' }); }
  };
  const save = async (submit) => {
    alert.hidden = true;
    const v = values();
    for (const k of ['classId', 'subjectId', 'topic', 'content']) if (!v[k]) { showErr({ message: 'This field is required.', details: { field: k } }); f[k].querySelector('.err').textContent = 'This field is required.'; return; }
    [saveBtn, submitBtn].forEach((b) => { b.disabled = true; }); (submit ? submitBtn : saveBtn).classList.add('loading');
    try {
      let id; let version;
      if (n) { const { termId: _t, classId: _c, subjectId: _s, ...rest } = v; const r = await api.patch(`/lesson-notes/${n.id}`, { ...rest, version: n.version }); id = n.id; version = r.version; }
      else { const r = await api.post('/lesson-notes', v); id = r.id; version = r.version; }
      const file = f.file._get();
      if (file) { const fd = new FormData(); fd.append('file', file); await api.post(`/lesson-notes/${id}/attachment`, fd); }
      if (submit) await api.post(`/lesson-notes/${id}/submit`);
      void version;
      toast(submit ? 'Lesson note submitted for review' : 'Draft saved');
      location.hash = `#/lesson-notes/${id}`;
    } catch (e) { showErr(e); } finally { [saveBtn, submitBtn].forEach((b) => { b.disabled = false; b.classList.remove('loading'); }); }
  };
  const saveBtn = btn('Save draft', () => save(false), { ic: 'check' });
  const submitBtn = btn('Save & submit for review', () => save(true), { kind: 'primary', ic: 'send' });
  view.appendChild(card(null, [alert, grid, h('div.form-actions', saveBtn, submitBtn)]));
}

// ───────────────────────── detail (staff + learners) ─────────────────────────
export async function detail(view, p) {
  const n = await api.get(`/lesson-notes/${p.id}`);
  const c = n.can || {};
  const reload = () => { clear(view); detail(view, p); };
  const act = (fn, okMsg) => async () => { try { await fn(); if (okMsg) toast(okMsg); reload(); } catch (e) { fail(e); } };
  const actions = [h('a.btn', { href: '#/lesson-notes' }, icon('chevronLeft', 16), h('span', { text: 'All notes' })), btn('Print', () => window.print(), { ic: 'printer' })];
  if (c.edit) actions.push(h('a.btn', { href: `#/lesson-notes/${n.id}/edit` }, icon('edit', 16), h('span', { text: 'Edit' })));
  if (c.delete) actions.push(btn('Delete', async () => { if (await confirmDialog({ title: 'Delete this lesson note?', message: 'The draft will be removed. This is recorded in the audit log.', confirmLabel: 'Delete', danger: true })) { try { await api.del(`/lesson-notes/${n.id}`); toast('Lesson note deleted'); location.hash = '#/lesson-notes'; } catch (e) { fail(e); } } }, { kind: 'ghost', ic: 'x' }));
  if (c.submit) actions.push(btn('Submit for review', act(() => api.post(`/lesson-notes/${n.id}/submit`), 'Submitted for review'), { kind: 'primary', ic: 'send' }));
  if (c.review) {
    actions.push(btn('Return for correction', async () => { const note = await confirmDialog({ title: 'Return lesson note', message: 'Tell the teacher what to correct. They will be notified.', confirmLabel: 'Return to teacher', reason: true }); if (note) act(() => api.post(`/lesson-notes/${n.id}/review`, { decision: 'return', note }), 'Returned to the teacher')(); }, { ic: 'flag' }));
    actions.push(btn('Approve', async () => { if (await confirmDialog({ title: 'Approve this lesson note?', message: n.share_with_class ? `It becomes readable by students and parents of ${n.class_name}.` : 'The teacher chose not to share it with the class.', confirmLabel: 'Approve' })) act(() => api.post(`/lesson-notes/${n.id}/review`, { decision: 'approve' }), 'Lesson note approved')(); }, { kind: 'primary', ic: 'check' }));
  }
  if (c.reopen) actions.push(btn('Reopen', async () => { const note = await confirmDialog({ title: 'Reopen approved note', message: 'The note is hidden from the class and returned to the teacher for correction.', confirmLabel: 'Reopen', reason: true }); if (note) act(() => api.post(`/lesson-notes/${n.id}/reopen`, { note }), 'Note reopened')(); }, { kind: 'ghost', ic: 'flag' }));
  view.appendChild(pageHead(`Week ${n.week} · ${n.topic}`, `${n.class_name} · ${n.subject} · ${n.session_name} ${tn(n.term_name)} term`, ...actions));

  if (!learner()) {
    const banner = {
      draft: ['info', 'Draft — only you can see this note. Submit it when it is ready for review.'],
      submitted: ['info', `Submitted ${dateTime(n.submitted_at)} — waiting for review.`],
      approved: ['ok', `Approved by ${n.reviewer || 'the school'} on ${dateTime(n.reviewed_at)}. ${n.share_with_class ? `Visible to students and parents of ${n.class_name}.` : 'Not shared with the class.'}`],
      returned: ['warn', `Returned by ${n.reviewer || 'a reviewer'} on ${dateTime(n.reviewed_at)}: ${n.review_note || ''}`],
    }[n.status];
    if (banner) view.appendChild(h(`div.alert.alert-${banner[0]}.no-print`, statusBadge(n.status), h('span', { text: banner[1] })));
  }
  const sec = (label, text) => (text ? h('section.ln-sec', h('h3', { text: label }), h('p.prewrap', { text })) : null);
  const doc = h('div.doc.lesson-doc', docHead(['LESSON NOTE', `${n.session_name} Session · ${n.term_name} Term`]),
    h('table.ln-meta', h('tbody',
      h('tr', h('th', { text: 'Class' }), h('td', { text: n.class_name }), h('th', { text: 'Subject' }), h('td', { text: n.subject })),
      h('tr', h('th', { text: 'Week' }), h('td', { text: String(n.week) }), h('th', { text: 'Date' }), h('td', { text: n.lesson_date ? date(n.lesson_date) : '—' })),
      h('tr', h('th', { text: 'Duration' }), h('td', { text: n.duration || '—' }), h('th', { text: 'Teacher' }), h('td', { text: n.author || '—' })))),
    sec('Topic', n.topic), sec('Sub-topic', n.subtopic), sec('Behavioural objectives', n.objectives), sec('Instructional materials', n.materials),
    sec('Previous knowledge', n.prior_knowledge), sec('Lesson content / presentation', n.content), sec('Evaluation', n.evaluation), sec('Assignment', n.assignment),
    n.file_id ? h('section.ln-sec.no-print', h('h3', { text: 'Attachment' }), btn(`${n.file_name || 'Download attachment'}`, () => download(`/files/${n.file_id}`, n.file_name).catch(fail), { ic: 'paperclip' })) : null,
    h('div.doc-sign', h('div', { text: `Teacher: ${n.author || ''}` }), h('div', { text: n.status === 'approved' && !learner() ? `Approved: ${n.reviewer || ''} · ${date(n.reviewed_at)}` : 'Head of School' })));
  view.appendChild(doc);
}

// ───────────────────────── coverage report (heads) ─────────────────────────
export async function summary(view, p, q) {
  const acad = await api.get('/academic');
  const terms = acad.sessions.flatMap((s) => s.terms.map((t) => ({ ...t, session_name: s.name })));
  const cur = q.termId || (terms.find((t) => t.is_current) || terms[0] || {}).id;
  const pick = field({ name: 'termId', label: 'Term', type: 'select', placeholder: false, options: terms.map((t) => ({ value: t.id, label: termName(t) })) }, cur);
  pick.querySelector('select').addEventListener('change', (e) => { location.hash = `#/lesson-notes/summary?termId=${e.target.value}`; });
  view.appendChild(pageHead('Lesson Notes Coverage', 'Which teachers have written, submitted and had their notes approved this term — and which assigned subjects have no note yet.',
    h('a.btn', { href: '#/lesson-notes?scope=review' }, h('span', { text: 'Open review queue' })), btn('Print', () => window.print(), { ic: 'printer' })));
  view.appendChild(h('div.form-grid.pickers.ln-pick.no-print', pick));
  if (!cur) { view.appendChild(card(null, empty('No terms set up yet'))); return; }
  const box = h('div', spinner()); view.appendChild(box);
  const d = await api.get(`/lesson-notes/summary?termId=${cur}`);
  clear(box).append(
    h('div.stats.ln-stats', stat('Notes written', String(d.totals.total), null, 'notebook'), stat('Awaiting review', String(d.totals.submitted), null, 'clock', d.totals.submitted ? 'gold' : ''),
      stat('Approved', String(d.totals.approved), null, 'check'), stat('Returned', String(d.totals.returned), null, 'flag'), stat('Not started', String(d.missing.length), 'assigned subjects with no note', 'info', d.missing.length ? 'red' : '')),
    card('By teacher, class and subject', simpleTable([{ key: 'teacher', label: 'Teacher' }, { key: 'class_name', label: 'Class' }, { key: 'subject', label: 'Subject' },
      { key: 'total', label: 'Written', cls: 'num' }, { key: 'draft', label: 'Draft', cls: 'num' }, { key: 'submitted', label: 'Awaiting', cls: 'num' }, { key: 'approved', label: 'Approved', cls: 'num' },
      { key: 'returned', label: 'Returned', cls: 'num' }, { key: 'last_approved_week', label: 'Last approved', cls: 'num', render: (r) => (r.last_approved_week ? `Week ${r.last_approved_week}` : '—') },
      { key: 'last_activity', label: 'Last activity', render: (r) => ago(r.last_activity) }], d.items, 'No lesson notes for this term yet')),
    card('Assigned subjects with no lesson note', simpleTable([{ key: 'teacher', label: 'Teacher' }, { key: 'class_name', label: 'Class' }, { key: 'subject', label: 'Subject' }], d.missing, 'Every assigned subject has at least one note')));
}

// ───────────────────────── learners (students & parents) ─────────────────────────
async function learnerList(view, q) {
  const parent = portal() === 'parent';
  const kids = parent ? (session.me.children || []) : [];
  const childId = parent ? (q.studentId || (kids[0] && kids[0].id)) : null;
  view.appendChild(pageHead('Lesson Notes', parent ? 'Approved lesson notes for your children’s classes — follow what is taught each week.' : 'Approved lesson notes from your teachers, for revision and homework.'));
  const bar = h('div.form-grid.pickers');
  if (parent && kids.length > 1) {
    const ch = field({ name: 'studentId', label: 'Child', type: 'select', placeholder: false, options: kids.map((k) => ({ value: k.id, label: `${k.first_name} ${k.last_name}` })) }, childId);
    ch.querySelector('select').addEventListener('change', (e) => { location.hash = `#/lesson-notes?studentId=${e.target.value}`; });
    bar.appendChild(ch);
  }
  const d = await api.get(`/my/lesson-notes${qs({ studentId: childId, subjectId: q.subjectId })}`);
  const sub = field({ name: 'subjectId', label: 'Subject', type: 'select', placeholder: 'All subjects', options: d.subjects.map((s) => ({ value: s.id, label: s.name })) }, q.subjectId || '');
  sub.querySelector('select').addEventListener('change', (e) => { location.hash = `#/lesson-notes${qs({ studentId: parent ? childId : undefined, subjectId: e.target.value })}`; });
  bar.appendChild(sub); view.appendChild(bar);
  if (!d.items.length) { view.appendChild(card(null, empty('No lesson notes shared yet', 'Approved notes from your teachers will appear here.'))); return; }
  const bySubject = new Map(); for (const x of d.items) { if (!bySubject.has(x.subject)) bySubject.set(x.subject, []); bySubject.get(x.subject).push(x); }
  for (const [subject, rows] of bySubject) {
    view.appendChild(card(subject, h('div.list', rows.map((x) => h('a.list-item', { href: `#/lesson-notes/${x.id}` },
      h('div', h('strong', { text: `Week ${x.week} · ${x.topic}` }), h('div.muted', { text: [x.subtopic, x.class_name, `${tn(x.term_name)} term`, x.author].filter(Boolean).join(' · ') })),
      h('div', x.has_file ? icon('paperclip', 16) : null, h('small.muted', { text: ` ${x.lesson_date ? date(x.lesson_date) : ago(x.reviewed_at)}` })))))));
  }
}
