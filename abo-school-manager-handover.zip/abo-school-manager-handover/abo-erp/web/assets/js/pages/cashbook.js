// Cashbook — other income, expenses and petty cash (Phase 6). Entries are never edited or deleted; a wrong entry is
// voided with a reason and entered again, so the book can always be checked. The server enforces every rule.
import { h, clear } from '../core/dom.js';
import { api, qs } from '../core/api.js';
import { can } from '../core/session.js';
import { pageHead, btn, badge, card, toast, fail, confirmDialog, formDialog, dataTable, simpleTable, stat, spinner, errMsg, tabs } from '../core/ui.js';
import { naira, toKobo, date } from '../core/format.js';

const METHODS = [{ value: 'cash', label: 'Cash' }, { value: 'transfer', label: 'Bank transfer' }, { value: 'pos', label: 'POS' }, { value: 'cheque', label: 'Cheque' }, { value: 'petty_cash', label: 'Petty cash' }];
const methodLabel = (m) => (METHODS.find((x) => x.value === m) || { label: m }).label;
const ymd = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

async function entryForm(kind, cats, preset = {}) {
  const list = cats.filter((c) => c.kind === kind && c.active).map((c) => ({ value: c.id, label: c.name }));
  const petty = preset.method === 'petty_cash';
  const key = 'cb-' + (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2));   // one key per form: a retried Save is never recorded twice
  return formDialog({
    title: preset.title || (kind === 'income' ? 'Record money received' : 'Record money spent'),
    intro: preset.intro,
    fields: [{ name: 'categoryId', label: 'Category', type: 'select', options: list, required: true },
      { name: 'amount', label: 'Amount (₦)', type: 'number', step: '0.01', min: 0.01, required: true },
      { name: 'entryDate', label: 'Date', type: 'date', required: true },
      { name: 'method', label: 'Paid by', type: 'select', options: METHODS, placeholder: false, disabled: petty },
      { name: 'party', label: kind === 'income' ? 'Received from' : 'Paid to', max: 160 },
      { name: 'reference', label: 'Receipt / reference no.', max: 80 },
      { name: 'description', label: 'What for', required: true, max: 300, full: true }],
    values: { entryDate: ymd(new Date()), method: preset.method || 'cash', categoryId: preset.categoryId, description: preset.description },
    submitLabel: 'Save',
    onSubmit: (v) => {
      const amountKobo = toKobo(v.amount ?? '');
      if (!(amountKobo > 0)) { const e = new Error('Type an amount above ₦0.'); e.details = { field: 'amount' }; throw e; }
      return api.postOnce('/cashbook/entries', { kind, categoryId: v.categoryId, amountKobo, entryDate: v.entryDate, method: petty ? 'petty_cash' : (v.method || 'cash'),
        party: v.party || null, reference: v.reference || null, description: v.description }, key);
    },
  });
}

export async function book(view) {
  const rec = can('cashbook.record'); const voider = can('cashbook.void');
  let cats = (await api.get('/cashbook/categories')).items;
  const now = new Date(); let from = ymd(new Date(now.getFullYear(), now.getMonth(), 1)); let to = ymd(now);
  const sumBox = h('div'); let table = null;
  const refresh = () => { loadSummary(); if (table) table.refresh(); };
  const add = (kind, preset) => async () => { if (await entryForm(kind, cats, preset)) { toast('Saved in the cashbook'); refresh(); } };
  view.appendChild(pageHead('Cashbook', 'Money received and spent outside school fees, and the petty-cash box. School-fee payments are added to the totals automatically.',
    rec ? btn('Money received', add('income'), { kind: 'primary', ic: 'plus' }) : null,
    rec ? btn('Money spent', add('expense'), { ic: 'plus' }) : null,
    rec ? btn('Top up petty cash', add('income', { method: 'petty_cash', title: 'Put money into petty cash', categoryId: (cats.find((c) => c.kind === 'income' && c.name === 'Money into petty cash') || {}).id, description: 'Top up petty cash',
      intro: 'Money moved into the petty-cash box. It is not counted as new income.' }), { ic: 'wallet' }) : null,
    rec ? btn('Spend from petty cash', add('expense', { method: 'petty_cash', title: 'Spend from petty cash' }), { ic: 'wallet' }) : null));
  const f = h('input.input', { type: 'date', value: from, 'aria-label': 'From' }); const t = h('input.input', { type: 'date', value: to, 'aria-label': 'To' });
  const range = () => { from = f.value || from; to = t.value || to; refresh(); };
  f.addEventListener('change', range); t.addEventListener('change', range);
  view.appendChild(h('div.range-bar', h('label.muted', { text: 'From' }), f, h('label.muted', { text: 'to' }), t));
  view.appendChild(sumBox);
  async function loadSummary() {
    clear(sumBox).appendChild(spinner());
    try {
      const s = await api.get(`/cashbook/summary${qs({ from, to })}`);
      const rows = s.byCategory;
      clear(sumBox).append(...[h('div.stats', stat('School fees received', naira(s.feesKobo), 'from Fees & Payments', 'wallet'), stat('Other money received', naira(s.otherIncomeKobo), '', 'money'),
        stat('Money spent', naira(s.expenseKobo), '', 'money', 'red'), stat(s.netKobo >= 0 ? 'Left over' : 'Short by', naira(Math.abs(s.netKobo)), `${date(s.from)} – ${date(s.to)}`, 'chart', s.netKobo >= 0 ? '' : 'red'),
        stat('Petty cash in the box', naira(s.pettyCash.balanceKobo), `put in ${naira(s.pettyCash.putInKobo)} · spent ${naira(s.pettyCash.spentKobo)}`, 'wallet', s.pettyCash.balanceKobo > 0 ? 'gold' : '')),
      rows.length ? card('By category', simpleTable([{ label: 'Type', render: (r) => (r.kind === 'income' ? badge('received', 'ok') : badge('spent', 'danger')) }, { key: 'category', label: 'Category' },
        { label: 'Entries', cls: 'num', render: (r) => String(r.entries) }, { label: 'Amount', cls: 'num', render: (r) => naira(r.amount_kobo) }], rows)) : null].filter(Boolean));   // (native append would print "null")
    } catch (e) { clear(sumBox).appendChild(h('p.muted', { text: errMsg(e) })); }
  }
  const catOpts = () => cats.map((c) => ({ value: c.id, label: `${c.kind === 'income' ? '+' : '−'} ${c.name}` }));
  table = dataTable({
    columns: [{ label: 'Date', render: (r) => date(r.entry_date) },
      { label: 'Type', render: (r) => (r.kind === 'income' ? badge(r.method === 'petty_cash' ? 'petty top-up' : 'received', r.method === 'petty_cash' ? 'info' : 'ok') : badge('spent', 'danger')) },
      { key: 'category', label: 'Category' }, { label: 'What for', render: (r) => h('div', h('div', { text: r.description }), r.party ? h('div.muted', { text: r.party }) : null, r.voided_at ? h('div.muted', { text: `VOIDED: ${r.void_reason}` }) : null) },
      { label: 'Paid by', render: (r) => methodLabel(r.method) }, { key: 'reference', label: 'Ref.' },
      { label: 'Amount', cls: 'num', render: (r) => h(r.voided_at ? 's' : 'span', { text: (r.kind === 'income' ? '+' : '−') + naira(r.amount_kobo) }) },
      { key: 'recorded_by', label: 'By' },
      { label: '', render: (r) => (voider && !r.voided_at ? btn('Void', async () => {
        const reason = await confirmDialog({ title: 'Void this entry?', message: `${r.description} · ${naira(r.amount_kobo)}. The entry stays in the book, marked as voided.`, confirmLabel: 'Void entry', danger: true, reason: true });
        if (!reason) return; try { await api.post(`/cashbook/entries/${r.id}/void`, { reason }); toast('Entry voided'); refresh(); } catch (e) { fail(e); }
      }, { kind: 'ghost' }) : null) }],
    filters: [{ name: 'kind', label: 'Type', placeholder: 'Received and spent', options: [{ value: 'income', label: 'Received' }, { value: 'expense', label: 'Spent' }] },
      { name: 'categoryId', label: 'Category', placeholder: 'All categories', options: catOpts() },
      { name: 'method', label: 'Paid by', placeholder: 'Any way', options: METHODS },
      { name: 'includeVoided', label: 'Voided', placeholder: 'Hide voided', options: [{ value: 'true', label: 'Show voided' }] }],
    load: (x) => api.get(`/cashbook/entries${qs({ ...x, from, to, includeVoided: x.includeVoided || undefined })}`),
    empty: 'Nothing in the cashbook for these dates', emptyHint: rec ? 'Use “Money received” or “Money spent” to start.' : undefined,
  });
  view.appendChild(card('Entries', table));
  await loadSummary();
}

export async function categories(view) {
  const rec = can('cashbook.record');
  const box = h('div');
  const load = async () => {
    clear(box).appendChild(spinner());
    try {
      const cats = (await api.get('/cashbook/categories')).items;
      const tableFor = (kind) => simpleTable([{ key: 'name', label: 'Name' }, { label: 'Entries', cls: 'num', render: (c) => String(c.entries) }, { label: 'Status', render: (c) => (c.active ? badge('active') : badge('switched off', 'muted')) },
        { label: '', render: (c) => (rec ? h('span', btn('Rename', async () => { if (await formDialog({ title: 'Rename category', fields: [{ name: 'name', label: 'Name', required: true, max: 80 }], values: { name: c.name }, onSubmit: (v) => api.patch(`/cashbook/categories/${c.id}`, v) })) load(); }, { kind: 'ghost' }),
          btn(c.active ? 'Switch off' : 'Switch on', async () => { try { await api.patch(`/cashbook/categories/${c.id}`, { active: !c.active }); load(); } catch (e) { fail(e); } }, { kind: 'ghost' })) : null) }], cats.filter((c) => c.kind === kind));
      clear(box).append(card('Money received (income)', tableFor('income')), card('Money spent (expenses)', tableFor('expense')));
    } catch (e) { clear(box).appendChild(h('p.muted', { text: errMsg(e) })); }
  };
  view.appendChild(pageHead('Cashbook Categories', 'The headings used in the cashbook. A category in use cannot be deleted, only switched off.',
    rec ? btn('Add category', async () => { if (await formDialog({ title: 'Add category', fields: [{ name: 'kind', label: 'Type', type: 'select', placeholder: false, options: [{ value: 'expense', label: 'Money spent (expense)' }, { value: 'income', label: 'Money received (income)' }] }, { name: 'name', label: 'Name', required: true, max: 80 }], values: { kind: 'expense' }, onSubmit: (v) => api.post('/cashbook/categories', v) })) { toast('Category added'); load(); } }, { kind: 'primary', ic: 'plus' }) : null));
  view.appendChild(box);
  await load();
}
void tabs;
