// School menu: School Profile (incl. the school's own sign-in page link), Logo & Branding, Principal/Head Information.
import { h, clear, icon } from '../core/dom.js';
import { api } from '../core/api.js';
import { can, session } from '../core/session.js';
import { pageHead, btn, formDialog, badge, card, toast, fail, simpleTable, form, confirmDialog } from '../core/ui.js';
import { date, initials } from '../core/format.js';
import { applyBrand } from '../core/shell.js';
import { fileUrl } from '../core/config.js';

const refreshMe = async () => { try { const me = await api.get('/auth/me'); session.me = me; } catch { /* ignore */ } };
function copyRow(value) {
  const inp = h('input.input', { value, readonly: true, 'aria-label': 'School sign-in link' });
  return h('div.copy-row', inp, btn('Copy', async () => { try { await navigator.clipboard.writeText(value); toast('Link copied'); } catch { inp.select(); document.execCommand('copy'); toast('Link copied'); } }, { ic: 'file' }),
    h('a.btn', { href: value.replace(/^https?:\/\/[^/]+\//, '/'), target: '_blank', rel: 'noopener', text: 'Open' }));
}
// mini mock of the school's branded sign-in page
export function portalPreview(school, logoSrc, color) {
  const pv = h('div.portal-preview', { 'aria-label': 'Sign-in page preview' },
    h('div.pv-brand', logoSrc ? h('img', { src: logoSrc, alt: '' }) : h('div.pv-mark', { text: initials(school.name) }), h('strong', { text: school.name }), school.motto ? h('em', { text: school.motto }) : null, h('small', { text: 'Powered by A.B.O. School Manager' })),
    h('div.pv-form', h('strong', { text: `Sign in to ${school.name}` }), h('div.pv-line'), h('div.pv-line'), h('div.pv-btn')));
  if (color) pv.style.setProperty('--pv', color);
  return pv;
}

export async function profile(view) {
  const d = await api.get('/school'); const s = d.school; const edit = can('settings.update');
  view.appendChild(pageHead('School Profile', 'Your school’s official details — printed on report sheets, receipts and the school sign-in page.'));
  const f = form([{ name: 'name', label: 'School name', required: true, full: true }, { name: 'schoolType', label: 'School type', type: 'select', placeholder: false, options: [{ value: 'primary', label: 'Primary' }, { value: 'secondary', label: 'Secondary' }, { value: 'mixed', label: 'Mixed' }] },
    { name: 'motto', label: 'Motto' }, { name: 'registrationNumber', label: 'Registration number' }, { name: 'address', label: 'Address', full: true }, { name: 'phone', label: 'Phone' }, { name: 'email', label: 'Email', type: 'email' }, { name: 'website', label: 'Website' }],
  { name: s.name, schoolType: s.school_type, motto: s.motto, registrationNumber: s.registration_number, address: s.address, phone: s.phone, email: s.email, website: s.website });
  if (!edit) f.querySelectorAll('input,select').forEach((x) => { x.disabled = true; });
  const logoSrc = s.logo_file_id ? fileUrl(s.logo_file_id) : null;
  view.appendChild(h('div.grid.g2',
    card('Details', [f, edit ? h('div.page-actions', btn('Save profile', async () => { try { await api.patch('/school', f._values()); toast('Profile saved'); await refreshMe(); } catch (e) { if (!f._error(e)) fail(e); } }, { kind: 'primary' })) : null]),
    h('div',
      card('Your school sign-in page', [h('p.muted', { text: 'Share this link with staff, students and parents. It shows your school name and logo, so everyone knows they are signing in to the right school.' }),
        copyRow(s.portal_url), h('div.mt', portalPreview(s, logoSrc, s.brand_color)), can('settings.branding') ? h('p', h('a', { href: '#/school/branding', text: 'Change logo & colour →' })) : null]),
      card('Account', h('dl.kv', h('dt', { text: 'Status' }), h('dd', badge(s.status)), h('dt', { text: 'Approved' }), h('dd', { text: s.approved_at ? date(s.approved_at) : '—' }), h('dt', { text: 'Web address' }), h('dd.mono', { text: s.slug }),
        h('dt', { text: 'Plan' }), h('dd', { text: `${s.plan} · up to ${s.max_students} learners` }), h('dt', { text: 'Subscription' }), h('dd', { text: s.subscription_status }), h('dt', { text: 'Registered' }), h('dd', { text: date(s.created_at) }))))));
  view.appendChild(card('Branches / campuses', [simpleTable([{ key: 'name', label: 'Branch' }, { key: 'code', label: 'Code' }, { key: 'address', label: 'Address' }, { label: 'Status', render: (b) => badge(b.status) }], d.branches, 'Single-campus school'),
    edit ? btn('Add branch', async () => { const r = await formDialog({ title: 'Add branch', fields: [{ name: 'name', label: 'Name', required: true }, { name: 'code', label: 'Code', placeholder: 'ANNEX' }, { name: 'address', label: 'Address', full: true }, { name: 'phone', label: 'Phone' }], onSubmit: (v) => api.post('/school/branches', v) }); if (r) { clear(view); profile(view); } }, { ic: 'plus' }) : null]));
}

const SWATCHES = ['#0a7d61', '#10263f', '#175cd3', '#6938ef', '#b42318', '#d99a16', '#0f766e', '#c2185b', '#5d4037', '#2e7d32'];
export async function branding(view) {
  const d = await api.get('/school'); const s = d.school; const edit = can('settings.branding');
  view.appendChild(pageHead('Logo & Branding', 'Your logo and colour appear on the sign-in page, the menu, report sheets, broadsheets and receipts.'));
  let color = s.brand_color || '#0a7d61';
  const logoSrc = s.logo_file_id ? fileUrl(s.logo_file_id) : null;
  const previewBox = h('div'); const drawPreview = () => clear(previewBox).appendChild(portalPreview(s, logoSrc, color));
  const picker = h('input.input', { type: 'color', value: color, disabled: !edit, 'aria-label': 'School colour' });
  const sw = h('div.swatches', SWATCHES.map((c) => { const b = h(`button.swatch${c === color ? '.on' : ''}`, { type: 'button', title: c, 'aria-label': `Use ${c}`, disabled: !edit, on: { click: () => { color = c; picker.value = c; sw.querySelectorAll('.swatch').forEach((x) => x.classList.toggle('on', x === b)); drawPreview(); } } }); b.style.background = c; return b; }));
  picker.addEventListener('input', () => { color = picker.value; sw.querySelectorAll('.swatch').forEach((x) => x.classList.remove('on')); drawPreview(); });
  const upload = () => { const i = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp' }); i.addEventListener('change', async () => { const fd = new FormData(); fd.append('file', i.files[0]); try { await api.post('/school/logo', fd); toast('Logo updated'); location.reload(); } catch (e) { fail(e); } }); i.click(); };
  view.appendChild(h('div.grid.g2',
    h('div',
      card('School logo', [h('div.list-item', logoSrc ? h('img.hero-logo', { src: logoSrc, alt: 'School logo' }) : h('div.hero-logo-mark', { text: initials(s.name) }),
        h('div', h('strong', { text: logoSrc ? 'Current logo' : 'No logo yet' }), h('p.muted', { text: 'PNG, JPG or WEBP up to 1.5 MB. A square image on a white or transparent background looks best. SVG is not accepted (it can carry scripts).' }))),
      edit ? h('div.page-actions', btn(logoSrc ? 'Replace logo' : 'Upload logo', upload, { kind: 'primary', ic: 'upload' }),
        logoSrc ? btn('Remove', async () => { if (await confirmDialog({ title: 'Remove the logo?', message: 'Your initials will be shown instead.', danger: true })) { try { await api.del('/school/logo'); toast('Logo removed'); location.reload(); } catch (e) { fail(e); } } }, { kind: 'ghost' }) : null) : h('p.muted', { text: 'Only users with branding permission can change the logo.' })]),
      card('School colour', [sw, h('div.field', h('label', { text: 'Custom colour' }), picker),
        edit ? h('div.page-actions', btn('Save colour', async () => { try { await api.patch('/school/branding', { brandColor: color }); applyBrand(color); toast('Colour saved'); await refreshMe(); } catch (e) { fail(e); } }, { kind: 'primary' }),
          s.brand_color ? btn('Use default', async () => { try { await api.patch('/school/branding', { brandColor: null }); applyBrand(null); toast('Default colours restored'); location.reload(); } catch (e) { fail(e); } }, { kind: 'ghost' }) : null) : null])),
    card('Preview — your school sign-in page', [previewBox, h('p.muted', { text: 'After A.B.O. approves your school, this is what staff, students and parents see at your sign-in link.' }), h('p', h('a', { href: '#/school/profile', text: 'Get your sign-in link →' }))])));
  drawPreview();
  void icon;
}

export async function head(view) {
  const d = await api.get('/school'); const s = d.school; const edit = can('settings.update');
  view.appendChild(pageHead('Principal / Head Information', 'The head of school’s name, title and signature are printed on report sheets.'));
  const f = form([{ name: 'headName', label: 'Full name', placeholder: 'e.g. Dr (Mrs) Bisi Alade' }, { name: 'headTitle', label: 'Title', placeholder: 'Principal / Head Teacher / Proprietress' },
    { name: 'headPhone', label: 'Phone' }, { name: 'headEmail', label: 'Email', type: 'email' }],
  { headName: s.head_name, headTitle: s.head_title, headPhone: s.head_phone, headEmail: s.head_email });
  if (!edit) f.querySelectorAll('input').forEach((x) => { x.disabled = true; });
  const sig = s.head_signature_file_id ? h('img.sig-img', { src: fileUrl(s.head_signature_file_id), alt: 'Signature' }) : h('p.muted', { text: 'No signature uploaded yet.' });
  const upload = () => { const i = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp' }); i.addEventListener('change', async () => { const fd = new FormData(); fd.append('file', i.files[0]); try { await api.post('/school/head/signature', fd); toast('Signature uploaded'); clear(view); head(view); } catch (e) { fail(e); } }); i.click(); };
  view.appendChild(h('div.grid.g2',
    card('Head of school', [f, edit ? h('div.page-actions', btn('Save', async () => {
      const v = f._values(); const body = {}; for (const k of ['headName', 'headTitle', 'headPhone', 'headEmail']) body[k] = v[k] ?? null;
      try { await api.patch('/school/head', body); toast('Head of school details saved'); } catch (e) { if (!f._error(e)) fail(e); }
    }, { kind: 'primary' })) : null]),
    card('Signature', [sig, h('p.muted', { text: 'Sign on white paper, take a clear photo or scan, crop tightly and upload (PNG/JPG/WEBP, max 512 KB). It is printed on report sheets when “Print the head’s signature” is on in Result Templates.' }),
      edit ? h('div.page-actions', btn(s.head_signature_file_id ? 'Replace signature' : 'Upload signature', upload, { kind: 'primary', ic: 'upload' }),
        s.head_signature_file_id ? btn('Remove', async () => { if (await confirmDialog({ title: 'Remove the signature?', danger: true })) { try { await api.del('/school/head/signature'); toast('Signature removed'); clear(view); head(view); } catch (e) { fail(e); } } }, { kind: 'ghost' }) : null) : null,
      h('p', h('a', { href: '#/reports/templates', text: 'Report sheet layout (Result Templates) →' }))])));
}
