// Shared page helpers: term / session / class / subject pickers that remember the URL query, and a small
// concurrency limiter for pages that load many report cards or sheets.
import { h } from '../core/dom.js';
import { field } from '../core/ui.js';
import { tn } from '../core/format.js';

export const currentTermId = (a) => { for (const s of a.sessions) for (const t of s.terms) if (t.is_current) return t.id; return a.sessions[0] && a.sessions[0].terms[0] && a.sessions[0].terms[0].id; };
export const currentSessionId = (a) => (a.sessions.find((s) => s.is_current) || a.sessions[0] || {}).id;
export const termOpts = (a) => a.sessions.flatMap((s) => s.terms.map((t) => ({ value: t.id, label: `${s.name} · ${tn(t.name)} term${t.is_current ? ' (current)' : ''}` })));
export const sessionOpts = (a) => a.sessions.map((s) => ({ value: s.id, label: `${s.name}${s.is_current ? ' (current)' : ''}` }));
export const classOpts = (a) => a.classes.map((c) => ({ value: c.id, label: c.active === false ? `${c.display_name} (switched off)` : c.display_name }));
export const subjectOpts = (a) => a.subjects.map((s) => ({ value: s.id, label: s.name }));
export const termLabel = (a, id) => { for (const s of a.sessions) for (const t of s.terms) if (t.id === id) return `${s.name} · ${tn(t.name)} term`; return ''; };

// pickers({ term, session, cls, subject }) → { el, get(), on(fn) }; values default from q (URL) then current term/first class
export function pickers(a, q, want = { term: true, cls: true }) {
  const fields = [];
  const f = {};
  if (want.session) f.sessionId = field({ name: 'sessionId', label: 'Session', type: 'select', placeholder: false, options: sessionOpts(a) }, q.sessionId || currentSessionId(a));
  if (want.term) f.termId = field({ name: 'termId', label: 'Term', type: 'select', placeholder: false, options: termOpts(a) }, q.termId || currentTermId(a));
  if (want.cls) f.classId = field({ name: 'classId', label: 'Class', type: 'select', placeholder: want.allClasses ? 'All classes' : false, options: classOpts(a) }, q.classId || (want.allClasses ? '' : a.classes[0] && a.classes[0].id));
  if (want.subject) f.subjectId = field({ name: 'subjectId', label: 'Subject', type: 'select', placeholder: false, options: subjectOpts(a) }, q.subjectId || (a.subjects[0] && a.subjects[0].id));
  for (const k of Object.keys(f)) fields.push(f[k]);
  const listeners = [];
  const get = () => Object.fromEntries(Object.entries(f).map(([k, w]) => [k, w._get()]));
  for (const w of fields) w.querySelector('select').addEventListener('change', () => listeners.forEach((fn) => fn(get())));
  return { el: h('div.form-grid.pickers', fields), get, on: (fn) => listeners.push(fn) };
}

export async function mapLimit(items, limit, fn) {
  const out = new Array(items.length); let i = 0;
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => { while (i < items.length) { const k = i++; out[k] = await fn(items[k], k); } });
  await Promise.all(workers); return out;
}
export const pct = (n) => `${Math.round(Number(n) || 0)}%`;
export const num = (n, d = 1) => (n === null || n === undefined || n === '' ? '—' : Number(n).toFixed(d).replace(/\.0+$/, ''));
