// School store (Phase 6): items & stock, selling with a receipt, and the list of sales. The server sets every price,
// keeps stock from going below zero and records every stock change; this page only shows what the API allows.
import { h, clear } from '../core/dom.js';
import { api, qs } from '../core/api.js';
import { can } from '../core/session.js';
import { pageHead, btn, badge, card, toast, fail, confirmDialog, formDialog, dataTable, simpleTable, stat, spinner, errMsg, modal, empty } from '../core/ui.js';
import { naira, toKobo, date, dateTime } from '../core/format.js';

const toNaira = (k) => (k === null || k === undefined ? '' : String(Number(k) / 100));
const METHODS = [{ value: 'cash', label: 'Cash' }, { value: 'transfer', label: 'Bank transfer' }, { value: 'pos', label: 'POS' }];
const priceErr = () => { const e = new Error('Type a price of ₦0 or more.'); e.details = { field: 'price' }; return e; };

// ───────────────────────── items & stock ─────────────────────────
export async function items(view) {
  const manage = can('store.manage'); const sell = can('store.sell');
  const box = h('div');
  view.appendChild(pageHead('School Store', 'Items for sale (books, uniforms, stationery …), what is in stock and what is running low.',
    sell ? h('a.btn.btn-primary', { href: '#/store/sell', text: 'Sell items' }) : null, h('a.btn', { href: '#/store/sales', text: 'Sales' }),
    manage ? btn('Add item', () => itemForm(null, load), { ic: 'plus' }) : null));
  view.appendChild(box);
  async function load() {
    clear(box).appendChild(spinner());
    try {
      const r = await api.get('/store/items?includeInactive=true');
      clear(box).append(h('div.stats', stat('Items', r.totals.items, '', 'layers'), stat('Running low', r.totals.low, 'at or below the re-order level', 'flag', r.totals.low ? 'gold' : ''),
        manage ? stat('Stock value', naira(r.totals.stockValueKobo), 'at cost price', 'wallet') : null),
      card(null, simpleTable([{ label: 'Item', render: (x) => h('div', h('strong', { text: x.name }), x.sku ? h('div.muted', { text: x.sku }) : null) }, { label: 'Category', render: (x) => x.category || '—' },
        { label: 'Price', cls: 'num', render: (x) => naira(x.unit_price_kobo) }, manage ? { label: 'Cost', cls: 'num', render: (x) => (x.cost_price_kobo == null ? '—' : naira(x.cost_price_kobo)) } : null,
        { label: 'In stock', cls: 'num', render: (x) => h('span', h('strong', { text: String(x.stock_qty) }), ' ', !x.active ? badge('not on sale', 'muted') : x.stock_qty === 0 ? badge('out of stock', 'danger') : x.low ? badge('low', 'warn') : null) },
        { label: '', render: (x) => h('span', manage ? btn('Receive', () => stockForm(x, 'restock', load), { kind: 'ghost' }) : null, manage ? btn('Correct count', () => stockForm(x, 'adjust', load), { kind: 'ghost' }) : null,
          manage ? btn('Edit', () => itemForm(x, load), { kind: 'ghost' }) : null, btn('History', () => history(x), { kind: 'ghost' })) }].filter(Boolean), r.items, 'No items yet. Use “Add item” to start.')));
    } catch (e) { clear(box).appendChild(h('p.muted', { text: errMsg(e) })); }
  }
  await load();
}
async function itemForm(x, done) {
  const ok = await formDialog({ title: x ? 'Edit item' : 'Add item',
    fields: [{ name: 'name', label: 'Item name', required: true, max: 120, full: true }, { name: 'category', label: 'Category (e.g. Books, Uniform)', max: 60 }, { name: 'sku', label: 'Code (optional)', max: 40 },
      { name: 'price', label: 'Selling price (₦)', type: 'number', step: '0.01', min: 0, required: true }, { name: 'cost', label: 'Cost price (₦, optional)', type: 'number', step: '0.01', min: 0 },
      x ? null : { name: 'openingQty', label: 'Quantity in stock now', type: 'number', min: 0, step: 1 }, { name: 'reorderLevel', label: 'Warn me when stock is at or below', type: 'number', min: 0, step: 1 },
      x ? { name: 'active', label: 'On sale', type: 'checkbox' } : null].filter(Boolean),
    values: x ? { name: x.name, category: x.category, sku: x.sku, price: toNaira(x.unit_price_kobo), cost: toNaira(x.cost_price_kobo), reorderLevel: x.reorder_level, active: x.active } : { reorderLevel: 0, openingQty: 0 },
    onSubmit: (v) => {
      if (v.price === null || !(Number(v.price) >= 0)) throw priceErr();
      const body = { name: v.name, category: v.category || null, sku: v.sku || null, unitPriceKobo: toKobo(v.price), costPriceKobo: v.cost === null || v.cost === undefined ? null : toKobo(v.cost), reorderLevel: Number(v.reorderLevel) || 0 };
      if (x) { body.active = !!v.active; return api.patch(`/store/items/${x.id}`, body); }
      return api.post('/store/items', { ...body, openingQty: Number(v.openingQty) || 0 });
    } });
  if (ok) { toast(x ? 'Item saved' : 'Item added'); done(); }
}
async function stockForm(x, kind, done) {
  const ok = await formDialog({ title: kind === 'restock' ? `Receive stock: ${x.name}` : `Correct the count: ${x.name}`,
    intro: kind === 'restock' ? `There are ${x.stock_qty} now. Type how many new ones arrived.` : `There are ${x.stock_qty} on record. Type + to add or − to remove (e.g. -2), and say why.`,
    fields: [{ name: 'qty', label: kind === 'restock' ? 'How many arrived' : 'Change (+ or −)', type: 'number', step: 1, required: true },
      kind === 'restock' ? { name: 'cost', label: 'Cost per item (₦, optional)', type: 'number', step: '0.01', min: 0 } : { name: 'reason', label: 'Why (e.g. 2 damaged by rain)', required: true, max: 300, full: true }],
    onSubmit: (v) => api.post(`/store/items/${x.id}/stock`, { kind, qty: Number(v.qty), unitCostKobo: v.cost === null || v.cost === undefined ? null : toKobo(v.cost), reason: v.reason || null }) });
  if (ok) { toast('Stock updated'); done(); }
}
async function history(x) {
  try {
    const r = await api.get(`/store/items/${x.id}/moves`);
    const words = { opening: 'Opening stock', restock: 'Received', sale: 'Sold', sale_void: 'Sale voided (back in stock)', adjust: 'Count corrected' };
    modal({ title: `Stock history: ${x.name}`, wide: true, body: [h('p.muted', { text: `In stock: ${r.item.stock_qty}. ${r.movesAddUp ? '✔ The history adds up to the stock count.' : '✖ The history does not add up — tell the administrator.'}` }),
      simpleTable([{ label: 'When', render: (m) => dateTime(m.created_at) }, { label: 'What', render: (m) => words[m.kind] || m.kind }, { label: 'Change', cls: 'num', render: (m) => (m.qty > 0 ? '+' : '') + m.qty },
        { label: 'Receipt', render: (m) => m.receipt_no || '—' }, { label: 'Why', render: (m) => m.reason || '—' }, { label: 'By', render: (m) => m.by || '—' }], r.moves, 'No stock changes yet')] });
  } catch (e) { fail(e); }
}

// ───────────────────────── sell ─────────────────────────
export async function sell(view) {
  const all = (await api.get('/store/items')).items.filter((x) => x.active);
  const cart = new Map(); let pupil = null;
  view.appendChild(pageHead('Sell Items', 'Pick the items, check the total, then complete the sale to print a receipt. Prices come from the store list.',
    h('a.btn', { href: '#/store', text: 'Items & stock' }), h('a.btn', { href: '#/store/sales', text: 'Sales' })));
  const search = h('input.input', { type: 'search', placeholder: 'Find an item…', 'aria-label': 'Find an item' });
  const list = h('div'); const cartBox = h('div'); const totalEl = h('strong.sell-total');
  const drawList = () => {
    const q = search.value.trim().toLowerCase();
    const rows = all.filter((x) => !q || x.name.toLowerCase().includes(q) || (x.category || '').toLowerCase().includes(q) || (x.sku || '').toLowerCase().includes(q));
    clear(list).appendChild(rows.length ? h('div.sell-items', rows.map((x) => h('button.sell-item', { type: 'button', disabled: x.stock_qty <= 0, on: { click: () => { const n = (cart.get(x.id) || 0) + 1; if (n > x.stock_qty) { toast(`Only ${x.stock_qty} in stock`, 'err'); return; } cart.set(x.id, n); drawCart(); } } },
      h('strong', { text: x.name }), h('span', { text: naira(x.unit_price_kobo) }), h('small.muted', { text: x.stock_qty > 0 ? `${x.stock_qty} in stock` : 'out of stock' })))) : empty('No item matches'));
  };
  const drawCart = () => {
    const lines = [...cart].map(([id, qty]) => ({ it: all.find((x) => x.id === id), qty }));
    const total = lines.reduce((a, l) => a + Number(l.it.unit_price_kobo) * l.qty, 0);
    totalEl.textContent = naira(total);
    clear(cartBox).appendChild(lines.length ? simpleTable([{ label: 'Item', render: (l) => l.it.name }, { label: 'Price', cls: 'num', render: (l) => naira(l.it.unit_price_kobo) },
      { label: 'Qty', render: (l) => h('input.input.qty', { type: 'number', min: 1, max: l.it.stock_qty, value: l.qty, 'aria-label': `Quantity of ${l.it.name}`, on: { change: (e) => { const n = Math.max(1, Math.min(l.it.stock_qty, Math.round(Number(e.target.value) || 1))); cart.set(l.it.id, n); drawCart(); } } }) },
      { label: 'Amount', cls: 'num', render: (l) => naira(Number(l.it.unit_price_kobo) * l.qty) }, { label: '', render: (l) => btn('Remove', () => { cart.delete(l.it.id); drawCart(); }, { kind: 'ghost' }) }], lines) : h('p.muted', { text: 'Tap items on the left to add them.' }));
  };
  // buyer: a pupil (search) or a name
  const pq = h('input.input', { type: 'search', placeholder: 'Pupil name or admission no. (optional)', 'aria-label': 'Find pupil' });
  const pres = h('div.pupil-results'); const chosen = h('div.muted');
  let t; pq.addEventListener('input', () => { clearTimeout(t); t = setTimeout(async () => {
    const q = pq.value.trim(); if (q.length < 2) { clear(pres); return; }
    try { const r = await api.get(`/students${qs({ q, pageSize: 6 })}`); clear(pres).append(...r.items.map((s) => h('button.btn.btn-ghost', { type: 'button', text: `${s.last_name} ${s.first_name} · ${s.admission_no}`, on: { click: () => { pupil = s; chosen.textContent = `Pupil: ${s.last_name} ${s.first_name} (${s.admission_no})`; clear(pres); pq.value = ''; } } }))); } catch { clear(pres); }
  }, 250); });
  const buyer = h('input.input', { placeholder: 'Or buyer’s name (optional)', maxlength: 160, 'aria-label': 'Buyer name' });
  const method = h('select.input', { 'aria-label': 'Paid by' }, METHODS.map((m) => h('option', { value: m.value, text: m.label })));
  const ref = h('input.input', { placeholder: 'Transfer / POS reference (optional)', maxlength: 80, 'aria-label': 'Reference' });
  let key = crypto.randomUUID ? crypto.randomUUID() : String(Date.now());
  const done = btn('Complete sale', async (ev) => {
    if (!cart.size) { toast('Add at least one item', 'err'); return; }
    const btnEl = ev.currentTarget; btnEl.disabled = true;
    try {
      const s = await api.postOnce('/store/sales', { lines: [...cart].map(([itemId, qty]) => ({ itemId, qty })), studentId: pupil ? pupil.id : null, buyerName: buyer.value.trim() || null, method: method.value, reference: ref.value.trim() || null }, 'sale-' + key);
      key = crypto.randomUUID ? crypto.randomUUID() : String(Date.now());
      toast(`Sold — receipt ${s.receipt_no}`); location.hash = `#/store/receipt/${s.id}`;
    } catch (e) { fail(e); btnEl.disabled = false; }
  }, { kind: 'primary', ic: 'check' });
  search.addEventListener('input', drawList);
  view.appendChild(h('div.sell-grid', card('Items', [search, list]), card('Sale', [cartBox, h('div.sell-sum', h('span', { text: 'Total' }), totalEl),
    h('div.form-grid', h('div.field.field-full', pq, pres, chosen), h('div.field', buyer), h('div.field', method), h('div.field', ref)), h('div.page-actions', done)])));
  drawList(); drawCart();
}

// ───────────────────────── sales + receipt ─────────────────────────
export async function sales(view) {
  const voider = can('store.void');
  view.appendChild(pageHead('Store Sales', 'Every sale with its receipt. A wrong sale is voided (the stock goes back), never deleted.',
    can('store.sell') ? h('a.btn.btn-primary', { href: '#/store/sell', text: 'Sell items' }) : null, h('a.btn', { href: '#/store', text: 'Items & stock' })));
  const tbl = dataTable({
    columns: [{ label: 'Receipt', render: (s) => h('a', { href: `#/store/receipt/${s.id}`, text: s.receipt_no }) }, { label: 'When', render: (s) => dateTime(s.sold_at) }, { label: 'Buyer', render: (s) => s.buyer || '—' },
      { key: 'items', label: 'Items' }, { label: 'Paid by', render: (s) => (METHODS.find((m) => m.value === s.method) || {}).label || s.method },
      { label: 'Amount', cls: 'num', render: (s) => h(s.voided_at ? 's' : 'span', { text: naira(s.total_kobo) }) }, { label: 'Status', render: (s) => (s.voided_at ? badge('void', 'muted') : badge('paid')) },
      { label: '', render: (s) => (voider && !s.voided_at ? btn('Void', async () => {
        const reason = await confirmDialog({ title: `Void ${s.receipt_no}?`, message: 'The items go back into stock and the sale is marked void.', confirmLabel: 'Void sale', danger: true, reason: true });
        if (!reason) return; try { await api.post(`/store/sales/${s.id}/void`, { reason }); toast('Sale voided'); tbl.refresh(); } catch (e) { fail(e); }
      }, { kind: 'ghost' }) : null) }],
    filters: [{ name: 'includeVoided', label: 'Voided', placeholder: 'Hide voided', options: [{ value: 'true', label: 'Show voided' }] }],
    load: (x) => api.get(`/store/sales${qs(x)}`), empty: 'No sales yet',
  });
  view.appendChild(card(null, tbl));
}
export async function receipt(view, p) {
  const s = await api.get(`/store/sales/${p.id}`);
  view.appendChild(pageHead(`Receipt ${s.receipt_no}`, s.voided_at ? `VOIDED: ${s.void_reason}` : 'Print this receipt for the buyer.',
    btn('Print', () => window.print(), { ic: 'printer', kind: 'primary' }), can('store.sell') ? h('a.btn', { href: '#/store/sell', text: 'New sale' }) : null, h('a.btn', { href: '#/store/sales', text: 'All sales' })));
  view.appendChild(h('div.doc.receipt-doc', h('div.receipt-head', h('strong', { text: s.school.name }), s.school.address ? h('div.muted', { text: s.school.address }) : null, s.school.phone ? h('div.muted', { text: s.school.phone }) : null),
    h('h2', { text: s.voided_at ? 'SALES RECEIPT — VOID' : 'SALES RECEIPT' }),
    h('div.receipt-meta', h('div', { text: `Receipt no: ${s.receipt_no}` }), h('div', { text: `Date: ${dateTime(s.sold_at)}` }),
      h('div', { text: `Buyer: ${s.student_name ? `${s.student_name} (${s.admission_no})` : s.buyer_name || '—'}` }), h('div', { text: `Paid by: ${(METHODS.find((m) => m.value === s.method) || {}).label || s.method}${s.reference ? ' · ' + s.reference : ''}` })),
    simpleTable([{ label: 'Item', key: 'item_name' }, { label: 'Qty', cls: 'num', render: (l) => String(l.qty) }, { label: 'Price', cls: 'num', render: (l) => naira(l.unit_price_kobo) }, { label: 'Amount', cls: 'num', render: (l) => naira(l.line_total_kobo) }], s.lines),
    h('div.sell-sum', h('span', { text: 'Total' }), h('strong', { text: naira(s.total_kobo) })), h('div.muted', { text: `Served by ${s.sold_by || '—'}. Thank you.` })));
}
void date;
