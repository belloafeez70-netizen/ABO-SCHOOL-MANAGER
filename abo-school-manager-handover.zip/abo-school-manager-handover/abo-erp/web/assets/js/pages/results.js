import { h, clear, icon } from '../core/dom.js';
import { api, qs, download } from '../core/api.js';
import { can, session } from '../core/session.js';
import { pageHead, btn, formDialog, badge, card, toast, fail, confirmDialog, simpleTable, field, empty, modal, spinner } from '../core/ui.js';
import { ordinal, dateTime, date, initials, tn } from '../core/format.js';
import { academic } from './people.js';
import { fileUrl } from '../core/config.js';

const currentTerm = (a) => { for (const s of a.sessions) for (const t of s.terms) if (t.is_current) return t.id; return a.sessions[0] && a.sessions[0].terms[0] && a.sessions[0].terms[0].id; };
const termOpts = (a) => a.sessions.flatMap((s) => s.terms.map((t) => ({ value: t.id, label: `${s.name} · ${tn(t.name)} term${t.is_current ? ' (current)' : ''}` })));
function pickers(a, q, onChange) {
  const term = field({ name: 'termId', label: 'Term', type: 'select', placeholder: false, options: termOpts(a) }, q.termId || currentTerm(a));
  const cls = field({ name: 'classId', label: 'Class', type: 'select', placeholder: false, options: a.classes.map((c) => ({ value: c.id, label: c.display_name })) }, q.classId || (a.classes[0] && a.classes[0].id));
  [term, cls].forEach((f) => f.querySelector('select').addEventListener('change', () => onChange(term._get(), cls._get())));
  return { el: h('div.form-grid', term, cls), term, cls };
}

export async function sheets(view, p, q) {
  const a = await academic();
  view.appendChild(pageHead('Score entry & review', 'Teachers enter CA and exam scores → submit → reviewers approve → results are published and locked.'));
  if (!a.classes.length) return view.appendChild(empty('No classes yet', 'Set up classes and subjects under Academic setup.'));
  const box = h('div');
  const load = async (termId, classId) => {
    clear(box).appendChild(spinner());
    const r = await api.get(`/results/sheets${qs({ termId, classId })}`);
    const approvedAll = r.items.length && r.items.every((x) => ['approved', 'published'].includes(x.status));
    clear(box).appendChild(card(`Subjects · ${r.classSize} learners`, simpleTable([
      { key: 'subject', label: 'Subject' }, { label: 'Teacher', render: (x) => x.teacher || '—' }, { label: 'Status', render: (x) => badge(x.status) }, { label: 'Scored', render: (x) => `${x.scored || 0}/${r.classSize}` },
      { label: 'Note', render: (x) => x.review_note || '' },
      { label: '', render: (x) => (x.sheet_id ? h('a.btn.btn-sm', { href: `#/results/sheet/${x.sheet_id}`, text: x.can_enter && x.status === 'draft' ? 'Enter scores' : 'Open' })
        : x.can_enter ? btn('Start sheet', async () => { try { const s = await api.post('/results/sheets', { termId, classId, subjectId: x.subject_id }); location.hash = `#/results/sheet/${s.id}`; } catch (e) { fail(e); } }, { kind: 'primary' }) : badge('not started', 'muted')) }], r.items, 'No subjects assigned to this class'),
    can('results.publish') ? btn('Publish class results', async () => {
      if (!approvedAll) return toast('Every subject must be approved before publishing.', 'err');
      if (!(await confirmDialog({ title: 'Publish results?', message: 'Students and parents will see them, positions are computed, and scores become locked (changes need a correction request).', confirmLabel: 'Publish' }))) return;
      try { const res = await api.post('/results/publish', { termId, classId }); toast(`Published for ${res.students} learners (broadsheet v${res.broadsheetVersion})`); load(termId, classId); } catch (e) { fail(e); }
    }, { kind: 'primary', disabled: !approvedAll }) : null,
    can('results.view') ? h('a.btn', { href: `#/broadsheet?termId=${termId}&classId=${classId}`, text: 'Broadsheet' }) : null));
  };
  const pk = pickers(a, q, load);
  view.append(card(null, pk.el), box);
  load(pk.term._get(), pk.cls._get()).catch(fail);
}

const isExamComp = (c) => c.is_exam === true || c.isExam === true || c.key === 'exam';
export async function sheet(view, p, q = {}) {
  const d = await api.get(`/results/sheets/${p.id}`);
  const s = d.sheet; const allComps = s.components;
  // CA Score Entry / Exam Score Entry show only their columns; saving sends only those keys (others stay untouched)
  const focus = q.focus === 'ca' || q.focus === 'exam' ? q.focus : null;
  const comps = focus ? allComps.filter((c) => (focus === 'exam' ? isExamComp(c) : !isExamComp(c))) : allComps;
  const hidden = allComps.filter((c) => !comps.includes(c));
  const inputs = new Map();
  const totalCell = new Map();
  const stored = new Map(d.rows.map((r) => [r.studentId, r.scores]));
  const recompute = (sid) => { const vals = [...comps.map((c) => inputs.get(`${sid}:${c.key}`).value), ...hidden.map((c) => (stored.get(sid)[c.key] ?? ''))].filter((v) => v !== '' && v !== null); totalCell.get(sid).textContent = vals.length ? vals.reduce((x, y) => x + Number(y), 0) : '—'; };
  const rows = d.rows.map((r) => h('tr', h('td.nowrap', h('strong', { text: r.name }), h('div.muted.mono', { text: r.admissionNo })),
    comps.map((c) => { const inp = h('input.input.score-input', { type: 'number', min: 0, max: c.max, step: '0.5', inputmode: 'decimal', value: r.scores[c.key] ?? '', disabled: !d.canEdit, 'aria-label': `${r.name} ${c.label}` });
      inp.addEventListener('input', () => { inp.classList.toggle('invalid', inp.value !== '' && (Number(inp.value) < 0 || Number(inp.value) > c.max)); recompute(r.studentId); });
      inputs.set(`${r.studentId}:${c.key}`, inp); return h('td.center', { dataset: { label: `${c.label} /${c.max}` } }, inp); }),
    (() => { const t = h('td.total.center', { dataset: { label: 'Total' }, text: r.result ? r.result.total : '—' }); totalCell.set(r.studentId, t); return t; })(),
    h('td.center', { dataset: { label: 'Grade' } }, r.result ? badge(r.result.grade, 'info') : '—'), h('td.center', { dataset: { label: 'Pos' }, text: r.result ? ordinal(r.result.subject_position) : '—' })));
  const save = async () => {
    const bad = [...inputs.values()].filter((i) => i.classList.contains('invalid'));
    if (bad.length) { bad[0].focus(); return toast('Fix the highlighted scores first.', 'err'); }
    const entries = d.rows.map((r) => ({ studentId: r.studentId, scores: Object.fromEntries(comps.map((c) => { const v = inputs.get(`${r.studentId}:${c.key}`).value; return [c.key, v === '' ? null : Number(v)]; })) }));
    try { await api.put(`/results/sheets/${s.id}/scores`, { entries, expectedVersion: s.version }); toast(focus ? `${focus === 'ca' ? 'CA' : 'Exam'} scores saved — totals recomputed on the server` : 'Scores saved and computed on the server'); clear(view); sheet(view, p, q); }
    catch (e) { if (e.status === 409) { toast('Someone else saved this sheet a moment ago. Reloading the latest version…', 'err', 6000); clear(view); sheet(view, p, q); } else fail(e); }
  };
  const actions = [];
  if (d.canEdit) actions.push(btn('Save scores', save, { kind: 'primary', ic: 'check' }));
  if (d.canSubmit) actions.push(btn('Submit for review', async () => { if (await confirmDialog({ title: 'Submit for review?', message: 'You will not be able to edit until a reviewer returns it.' })) { try { await api.post(`/results/sheets/${s.id}/submit`); toast('Submitted'); clear(view); sheet(view, p, q); } catch (e) { fail(e); } } }));
  if (d.canReview) actions.push(btn('Mark reviewed', async () => { try { await api.post(`/results/sheets/${s.id}/review`, { action: 'review' }); toast('Reviewed — sent for approval'); clear(view); sheet(view, p, q); } catch (e) { fail(e); } }, { kind: 'primary' }));
  if (d.canApprove) actions.push(btn('Approve & lock', async () => { try { await api.post(`/results/sheets/${s.id}/review`, { action: 'approve' }); toast('Approved & locked'); clear(view); sheet(view, p, q); } catch (e) { fail(e); } }, { kind: 'primary' }));
  if (d.canReview || d.canApprove) actions.push(
    btn('Return', async () => { const note = await confirmDialog({ title: 'Return to teacher', message: 'Explain what needs to change.', reason: true, confirmLabel: 'Return' }); if (note) { try { await api.post(`/results/sheets/${s.id}/review`, { action: 'return', note }); clear(view); sheet(view, p, q); } catch (e) { fail(e); } } }));
  if (['approved', 'published'].includes(s.status) && can('results.update')) actions.push(btn('Request correction', async () => {
    const r = await formDialog({ title: 'Request a correction', intro: 'Locked results change only through an approved correction (a different reviewer must approve).', fields: [
      { name: 'studentId', label: 'Learner', type: 'select', required: true, options: d.rows.map((x) => ({ value: x.studentId, label: x.name })) }, { name: 'componentKey', label: 'Component', type: 'select', required: true, options: comps.map((c) => ({ value: c.key, label: `${c.label} (max ${c.max})` })) },
      { name: 'newScore', label: 'Correct score', type: 'number', required: true }, { name: 'reason', label: 'Reason', type: 'textarea', required: true, full: true }], onSubmit: (v) => api.post('/results/corrections', { ...v, sheetId: s.id }) });
    if (r) toast('Correction requested');
  }));
  if (can('results.approve', 'audit_logs.view')) actions.push(btn('History', async () => { const hst = await api.get(`/results/sheets/${s.id}/history`); modal({ title: 'Score change history', wide: true, body: simpleTable([{ label: 'When', render: (x) => dateTime(x.changed_at) }, { key: 'student', label: 'Learner' }, { key: 'component_key', label: 'Comp.' }, { key: 'old_score', label: 'From' }, { key: 'new_score', label: 'To' }, { key: 'changed_by', label: 'By' }, { label: 'Via', render: (x) => (x.via_correction ? badge('correction', 'warn') : '') }], hst.items, 'No changes yet') }); }, { ic: 'clock' }));
  const modeLinks = h('div.tabs.no-print', { role: 'tablist' }, [['', 'All columns'], ['ca', 'CA only'], ['exam', 'Exam only']].map(([k, label]) => h(`a.tab${(focus || '') === k ? '.active' : ''}`, { href: `#/results/sheet/${s.id}${k ? `?focus=${k}` : ''}`, text: label })));
  view.appendChild(pageHead(`${focus ? (focus === 'ca' ? 'CA scores · ' : 'Exam scores · ') : ''}${s.subject} · ${s.className}`, `Status: ${s.status.toUpperCase()} · version ${s.version}${s.reviewNote ? ` · Note: ${s.reviewNote}` : ''}`, ...actions));
  view.appendChild(modeLinks);
  if (focus && !comps.length) view.appendChild(empty(`This sheet has no ${focus === 'ca' ? 'continuous assessment' : 'exam'} column`, 'Check the assessment components under Administration › Settings.'));
  if (!d.canEdit) view.appendChild(h('div.support-banner', icon('shield', 16), h('span', { text: s.status === 'draft' ? 'Read-only: this subject is not assigned to you.' : s.status === 'submitted' ? 'Submitted — waiting for review.' : s.status === 'reviewed' ? 'Reviewed — waiting for approval.' : 'Locked. Changes require an approved correction request.' })));
  view.appendChild(card(null, h('div.table-wrap', h('table.table.grid-scores', h('thead', h('tr', h('th', { text: 'Learner' }), comps.map((c) => h('th.center', { text: `${c.label} /${c.max}` })), h('th.center', { text: 'Total' }), h('th.center', { text: 'Grade' }), h('th.center', { text: 'Pos' }))), h('tbody', rows)))));
}

export async function broadsheet(view, p, q) {
  const a = await academic();
  view.appendChild(pageHead('Broadsheet', 'Totals, averages, grades and positions — computed on the server from approved scores.'));
  const box = h('div');
  const load = async (termId, classId) => {
    clear(box).appendChild(spinner());
    const b = await api.get(`/results/broadsheet${qs({ termId, classId })}`);
    const school = session.me.school;
    const table = h('table', h('thead', h('tr', h('th', { text: 'Pos' }), h('th', { text: 'Name' }), b.subjects.map((s) => h('th', { text: s.name })), h('th', { text: 'Total' }), h('th', { text: 'Avg' }), h('th', { text: 'Grade' }), h('th', { text: 'Status' }), h('th.no-print', { text: '' }))),
      h('tbody', b.rows.map((r) => h('tr', h('td', { text: r.summary && r.summary.position ? ordinal(r.summary.position) : '—' }), h('td.nowrap', { text: r.name }), r.scores.map((s) => h('td.center', { text: s ? s.total : '' })),
        h('td.center', { text: r.summary ? r.summary.total : '' }), h('td.center', { text: r.summary ? r.summary.average : '' }), h('td.center', { text: r.summary ? r.summary.grade || '' : '' }), h('td.center', { text: r.summary ? r.summary.status : '' }),
        h('td.no-print', h('a.btn.btn-sm', { href: `#/report/${r.studentId}?termId=${termId}`, text: 'Report' }))))));
    clear(box).appendChild(h('div.doc.landscape', h('div.doc-head', school && school.logo_file_id ? h('img', { src: fileUrl(school.logo_file_id), alt: '' }) : h('div.brand-mark.doc-mark', { text: initials((school || {}).name || 'School') }),
      h('div', h('h1', { text: school ? school.name : '' }), h('p', { text: school ? [school.address, school.phone].filter(Boolean).join(' · ') : '' }), h('p', { text: `${b.class_name} · ${b.session} · ${tn(b.term)} term` }))),
    h('h2', { text: `Broadsheet${b.provisional ? ' (provisional — not yet published)' : ''}` }), h('div.table-wrap', table)));
    box.prepend(h('div.page-actions.no-print', btn('Print', () => window.print(), { ic: 'printer' }), can('reports.export') ? btn('Excel', () => download(`/exports/broadsheet${qs({ termId, classId, format: 'xlsx' })}`).catch(fail), { ic: 'download' }) : null, b.provisional ? badge('provisional', 'warn') : badge('published', 'ok')));
  };
  const pk = pickers(a, q, load);
  view.append(h('div.no-print', card(null, pk.el)), box);
  load(pk.term._get(), pk.cls._get()).catch((e) => { clear(box); fail(e); });
}

// report card — shared by staff (#/report/:id) and portals
export async function reportCard(view, p, q) { view.appendChild(await reportDoc(p.id, q.termId)); }
export async function reportDoc(studentId, termId, opts = {}) {
  const r = await api.get(`/results/student/${studentId}${qs({ termId })}`);
  if (!r.available) return empty('Results not available yet', r.message);
  return renderReport(r, { studentId, termId, ...opts });
}
// report template settings (Report Sheets › Result Templates): classic | modern | compact + toggles
export function renderReport(r, { studentId, termId, actions: withActions = true } = {}) {
  const s = r.student; const sc = r.school; const comps = (r.subjects[0] && r.subjects[0].components) || [];
  const rc = r.reportCard || {}; const rs = r.reportSettings || {};
  const on = (k) => rs[k] !== false; const showPos = on('showSubjectPosition'); const showAvg = on('showClassAverage');
  const actions = withActions ? h('div.page-actions.no-print', btn('Print / save PDF', () => window.print(), { kind: 'primary', ic: 'printer' }), r.provisional ? badge('provisional (staff view)', 'warn') : badge('published', 'ok'),
    studentId && can('results.enter', 'results.enter_any', 'results.approve') ? btn('Comments', () => commentDialog(null)) : null,
    studentId && can('ai.use', 'results.enter') && can('ai.use') ? btn('Suggest remark (AI)', async () => {
      try { const x = await api.post('/ai/remark-suggestion', { studentId, termId: termId || r.summary.term_id }); commentDialog(x.suggestion, x.source); } catch (e) { fail(e); }
    }, { ic: 'activity' }) : null) : null;
  async function commentDialog(suggestion, source) {
    const fields = []; if (can('results.enter', 'results.enter_any')) fields.push({ name: 'teacherComment', label: 'Class teacher comment', type: 'textarea', full: true, max: 600 }); if (can('results.approve')) fields.push({ name: 'headComment', label: 'Head / principal comment', type: 'textarea', full: true, max: 600 });
    const ok = await formDialog({ title: 'Report card comments', intro: suggestion ? `Suggestion from ${source === 'online' ? 'AI' : 'the offline remark engine'} inserted — edit it before saving. Nothing is saved automatically.` : undefined,
      fields, values: { teacherComment: suggestion || rc.teacher_comment, headComment: rc.head_comment }, onSubmit: (v) => api.put(`/results/report-cards/${studentId}`, { termId: termId || r.summary.term_id, ...v }) });
    if (ok) toast('Comments saved');
  }
  const section = (r.summary && r.summary.section) || (sc.school_type === 'secondary' ? 'secondary' : 'primary');
  const bands = ((r.grading && r.grading[section]) || []).slice().sort((x, y) => y.min - x.min);
  const headTitle = rs.principalTitle || sc.head_title || 'Head teacher';
  const doc = h(`div.doc.tpl-${['classic', 'modern', 'compact'].includes(rs.template) ? rs.template : 'classic'}`,
    h('div.doc-head', sc.logo_file_id ? h('img', { src: fileUrl(sc.logo_file_id), alt: '' }) : h('div.brand-mark.doc-mark', { text: initials((sc || {}).name || 'School') }),
      h('div', h('h1', { text: sc.name }), sc.motto ? h('p', { text: `Motto: ${sc.motto}` }) : null, h('p', { text: [sc.address, sc.phone, sc.email].filter(Boolean).join(' · ') })),
      on('showPassport') && s.passport_file_id ? h('img', { src: fileUrl(s.passport_file_id), alt: 'Passport' }) : null),
    h('h2', { text: `Report sheet — ${tn(r.term.name)} term, ${r.term.session}` }),
    h('div.grid.g2', h('dl.kv', h('dt', { text: 'Name' }), h('dd', { text: `${s.last_name} ${s.first_name} ${s.other_names || ''}` }), h('dt', { text: 'Admission no' }), h('dd', { text: s.admission_no }), h('dt', { text: 'Class' }), h('dd', { text: r.summary ? r.summary.class_name : '—' }), h('dt', { text: 'Gender' }), h('dd', { text: s.gender })),
      h('dl.kv', h('dt', { text: 'Average' }), h('dd', { text: r.summary ? `${r.summary.average}%` : '—' }), h('dt', { text: 'Position' }), h('dd', { text: r.ordinalPosition && on('showPosition') ? `${r.ordinalPosition} of ${r.summary.class_size}` : '—' }),
        on('showAttendance') ? [h('dt', { text: 'Attendance' }), h('dd', { text: `${rc.days_present ?? r.attendance.present} present · ${rc.days_absent ?? r.attendance.absent} absent${r.term.days_open ? ` (of ${r.term.days_open})` : ''}` })] : null,
        h('dt', { text: 'Next term begins' }), h('dd', { text: date(r.term.next_term_begins) }))),
    h('table', h('thead', h('tr', h('th', { text: 'Subject' }), comps.map((c) => h('th', { text: `${c.label} (${c.max})` })), h('th', { text: 'Total' }), h('th', { text: 'Grade' }), showPos ? h('th', { text: 'Pos' }) : null, showAvg ? h('th', { text: 'Class avg' }) : null, h('th', { text: 'Remark' }))),
      h('tbody', r.subjects.map((x) => h('tr', h('td', { text: x.subject }), comps.map((c) => h('td.center', { text: x.scores[c.key] ?? '' })), h('td.center', { text: x.total }), h('td.center', { text: x.grade }), showPos ? h('td.center', { text: ordinal(x.subject_position) }) : null, showAvg ? h('td.center', { text: x.class_average }) : null, h('td', { text: x.remark })))),
      r.summary ? h('tfoot', h('tr', h('th', { text: 'Overall' }), comps.map(() => h('th')), h('th', { text: r.summary.total }), h('th', { text: r.summary.grade || '' }), showPos ? h('th', { text: on('showPosition') ? r.ordinalPosition || '' : '' }) : null, showAvg ? h('th') : null, h('th', { text: r.summary.status }))) : null),
    rs.showGradeKey && bands.length ? h('div.grade-key', h('strong', { text: 'Grading key:' }), bands.map((b, i) => h('span', { text: `${b.grade} ${b.min}${i === 0 ? '–100' : `–${bands[i - 1].min - 1}`}${b.remark ? ` (${b.remark})` : ''}` }))) : null,
    r.cumulative ? cumulativeBlock(r.cumulative, { showPos: on('showPosition'), showSubjPos: showPos, showAvg }) : null,
    h('p', h('strong', { text: 'Class teacher: ' }), rc.teacher_comment || '—'), h('p', h('strong', { text: `${headTitle}: ` }), rc.head_comment || '—'),
    h('div.doc-sign', h('div', { text: 'Class teacher' }),
      h('div', on('showSignature') && sc.head_signature_file_id ? h('img.sig', { src: fileUrl(sc.head_signature_file_id), alt: 'Signature' }) : null, h('span', { text: sc.head_name ? `${sc.head_name} — ${headTitle}` : `${headTitle}` })),
      h('div', { text: 'Parent / Guardian' })),
    rs.footer ? h('p.muted.center', { text: rs.footer }) : null);
  if (rs.accent && /^#[0-9a-fA-F]{6}$/.test(rs.accent)) doc.style.setProperty('--rc-accent', rs.accent);
  else if (sc.brand_color && /^#[0-9a-fA-F]{6}$/.test(sc.brand_color)) doc.style.setProperty('--rc-accent', sc.brand_color);
  return withActions ? h('div', actions, doc) : doc;
}

// "Results so far this session" on 2nd/3rd term report cards (server-computed; parents see published terms only)
export function cumulativeBlock(c, { showPos = true, showSubjPos = true, showAvg = true } = {}) {
  const v = (x) => (x === null || x === undefined ? '–' : String(x));
  const signed = (x) => (x === null || x === undefined ? '–' : `${x > 0 ? '+' : ''}${x}`);
  const title = c.isAnnual ? 'Whole-session result (cumulative of all three terms)' : `Results so far this session (1st term to ${c.termLabel})`;
  return h('section.cum-block',
    h('h3.cum-title', { text: title }),
    h('table.cum-table', h('thead', h('tr', h('th', { text: 'Subject' }), c.terms.map((t) => h('th.center', { text: t.label })), h('th.center', { text: 'Total so far' }),
      h('th.center', { text: 'Cumulative average' }), h('th.center', { text: 'Grade' }), showSubjPos ? h('th.center', { text: 'Pos' }) : null, showAvg ? h('th.center', { text: 'Class avg' }) : null)),
    h('tbody', c.subjects.map((x) => h('tr', h('td', { text: x.name }), x.termTotals.map((t) => h('td.center', { text: v(t) })), h('td.center', { text: v(x.total) }),
      h('td.center', h('strong', { text: v(x.average) })), h('td.center', { text: x.grade || '' }), showSubjPos ? h('td.center', { text: x.position ? ordinal(x.position) : '–' }) : null, showAvg ? h('td.center', { text: v(x.classAverage) }) : null))),
    h('tfoot', h('tr', h('th', { text: 'Term average' }), c.termAverages.map((t) => h('th.center', { text: t === null ? '–' : `${t}%` })), h('th.center', { text: c.marksObtained === null ? '–' : `${c.marksObtained} / ${c.marksObtainable}` }),
      h('th.center', { text: c.cumulativeAverage === null ? '–' : `${c.cumulativeAverage}%` }), h('th.center', { text: c.grade || '' }), showSubjPos ? h('th.center', { text: showPos && c.ordinalCumulativePosition ? c.ordinalCumulativePosition : '' }) : null, showAvg ? h('th.center', { text: c.classAverage === null ? '–' : `${c.classAverage}%` }) : null))),
    h('div.cum-facts',
      h('div', h('span', { text: 'Cumulative average' }), h('strong', { text: c.cumulativeAverage === null ? '–' : `${c.cumulativeAverage}% · ${c.grade || ''}` })),
      showPos ? h('div', h('span', { text: 'Cumulative position' }), h('strong', { text: c.ordinalCumulativePosition ? `${c.ordinalCumulativePosition} of ${c.classSize}` : '–' })) : null,
      h('div', h('span', { text: 'Change since last term' }), h('strong', { text: c.change === null ? '–' : `${signed(c.change)} points` })),
      h('div', h('span', { text: 'Result' }), h('strong', { text: c.status }))),
    c.summary ? h('p.cum-summary', { text: c.summary }) : null,
    h('p.cum-note', { text: `${c.method} Pass mark ${c.passMark}%.${c.provisional ? ' Includes results that are not yet published.' : ''}` }));
}

export async function corrections(view) {
  const box = h('div');
  view.appendChild(pageHead('Result corrections', 'Every change to a locked result is requested, reviewed by someone else, applied atomically and audited.'));
  const load = async () => {
    const r = await api.get('/results/corrections');
    clear(box).appendChild(card(null, simpleTable([{ label: 'Requested', render: (x) => dateTime(x.requested_at) }, { key: 'student', label: 'Learner' }, { label: 'Subject', render: (x) => `${x.subject} · ${x.class_name}` }, { label: 'Change', render: (x) => `${x.component_key.toUpperCase()}: ${x.old_score ?? '—'} → ${x.new_score}` },
      { key: 'reason', label: 'Reason' }, { key: 'requested_by_name', label: 'By' }, { label: 'Status', render: (x) => badge(x.status) },
      { label: '', render: (x) => (x.status === 'pending' && can('results.approve') && !x.mine ? h('div.page-actions', btn('Approve', async () => { try { await api.post(`/results/corrections/${x.id}/review`, { action: 'approve' }); toast('Correction applied and results recomputed'); load(); } catch (e) { fail(e); } }, { kind: 'primary' }), btn('Reject', async () => { const note = await confirmDialog({ title: 'Reject correction', message: 'Tell the requester why.', reason: true, danger: true }); if (note) { await api.post(`/results/corrections/${x.id}/review`, { action: 'reject', note }); load(); } })) : x.mine && x.status === 'pending' ? badge('awaiting another reviewer', 'muted') : '') }], r.items, 'No correction requests')));
  };
  view.appendChild(box); load().catch(fail);
}
