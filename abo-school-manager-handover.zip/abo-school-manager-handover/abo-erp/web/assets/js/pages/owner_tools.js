// Owner tools (Phase 6, part 4): "Sign in as" another member of the school, and the school's web address.
import { h, clear } from '../core/dom.js';
import { api, qs } from '../core/api.js';
import { can } from '../core/session.js';
import { pageHead, btn, card, toast, fail, formDialog, simpleTable, spinner, errMsg, empty } from '../core/ui.js';
import { dateTime } from '../core/format.js';

// ───────────────────────── sign in as ─────────────────────────
export async function actAs(view) {
  view.appendChild(pageHead('Sign In As Someone', 'See and use the app exactly as a teacher, office staff, pupil or parent of your school sees it — to help them or check their work.'));
  view.appendChild(card('How it works', h('ul', [
    'You give a short reason and choose how long (up to 60 minutes).',
    'A red bar shows the whole time, with a “Back to my account” button.',
    'Everything you do is recorded under YOUR name, and the person is told that you signed in as them.',
    'Passwords, two-step sign-in, private messages and user accounts are closed while you act as someone else.',
  ].map((t) => h('li', { text: t })))));
  const q = h('input.input.search', { type: 'search', placeholder: 'Find a person…', 'aria-label': 'Find a person' });
  const box = h('div');
  let t; q.addEventListener('input', () => { clearTimeout(t); t = setTimeout(load, 250); });
  view.append(h('div.range-bar', q), box);
  async function load() {
    clear(box).appendChild(spinner());
    try {
      const r = await api.get(`/auth/act-as/candidates${qs({ q: q.value.trim() || undefined })}`);
      clear(box).appendChild(r.items.length ? card(null, simpleTable([{ key: 'full_name', label: 'Name' }, { key: 'login_id', label: 'Login ID' }, { label: 'Role', render: (x) => (x.roles || []).join(', ') },
        { label: '', render: (x) => btn('Sign in as', () => start(x), { kind: 'primary' }) }], r.items)) : empty('Nobody found'));
    } catch (e) { clear(box).appendChild(h('p.muted', { text: errMsg(e) })); }
  }
  async function start(x) {
    const ok = await formDialog({ title: `Sign in as ${x.full_name}`, intro: 'Say why — it is saved in the activity record and shown to the person.',
      fields: [{ name: 'reason', label: 'Reason', required: true, max: 300, full: true, placeholder: 'e.g. Help with lesson notes' },
        { name: 'minutes', label: 'For how long', type: 'select', placeholder: false, options: [{ value: '15', label: '15 minutes' }, { value: '30', label: '30 minutes' }, { value: '60', label: '60 minutes' }] }],
      values: { minutes: '30' }, submitLabel: 'Sign in as this person',
      onSubmit: (v) => api.post('/auth/act-as', { userId: x.id, reason: v.reason, minutes: Number(v.minutes) }) });
    if (ok) { location.hash = '#/'; location.reload(); }
  }
  await load();
}

// ───────────────────────── school web address ─────────────────────────
export async function webAddress(view) {
  view.appendChild(pageHead('School Web Address', 'The address of your school’s own sign-in page. Share it with staff, pupils and parents.'));
  const box = h('div'); view.appendChild(box);
  async function load() {
    clear(box).appendChild(spinner());
    try {
      const r = await api.get('/school/web-address');
      const link = h('input.input.mono', { value: r.portalUrl, readonly: true, 'aria-label': 'School web address' });
      const copy = btn('Copy link', async () => { try { await navigator.clipboard.writeText(r.portalUrl); toast('Link copied'); } catch { link.select(); toast('Press Ctrl+C to copy', 'err'); } }, { ic: 'paperclip' });
      const wa = h('a.btn', { href: `https://wa.me/?text=${encodeURIComponent(`Sign in to our school app here: ${r.portalUrl}`)}`, target: '_blank', rel: 'noopener noreferrer', text: 'Share on WhatsApp' });
      const parts = [card('Your address', [h('div.range-bar', link, copy, wa), !r.publicNow ? h('p.form-alert', { text: 'Your school is waiting for approval, so this page opens only after approval.' }) : null,
        h('p.muted', { text: 'People who open it see your school name, logo and colours, then sign in.' })])];
      if (r.canChange) {
        const inp = h('input.input.mono', { value: r.slug, maxlength: 40, 'aria-label': 'New address' }); const msg = h('small.muted', { role: 'status' });
        let tm; inp.addEventListener('input', () => { inp.value = inp.value.toLowerCase().replace(/[^a-z0-9-]/g, ''); clearTimeout(tm); tm = setTimeout(async () => {
          if (!inp.value || inp.value === r.slug) { msg.textContent = ''; return; }
          try { const c = await api.get(`/school/web-address/check${qs({ slug: inp.value })}`); msg.textContent = (c.ok ? '✔ ' : '✖ ') + c.message; } catch (e) { msg.textContent = errMsg(e); }
        }, 300); });
        parts.push(card('Change the address', [h('p.muted', { text: 'Use small letters, numbers and dashes, for example bright-oak-academy. Your old address will keep working and will never be given to another school.' }),
          h('div.range-bar', h('span.muted.mono', { text: r.portalUrl.replace(/#\/s\/.*$/, '#/s/') }), inp, btn('Save new address', async () => {
            try { const s = await api.put('/school/web-address', { slug: inp.value }); toast(s.unchanged ? 'No change' : 'Web address changed'); load(); } catch (e) { fail(e); }
          }, { kind: 'primary' })), msg]));
      }
      if (r.oldAddresses.length) parts.push(card('Old addresses (still working)', simpleTable([{ key: 'slug', label: 'Address' }, { label: 'Changed', render: (x) => dateTime(x.replaced_at) }], r.oldAddresses)));
      clear(box).append(...parts);
    } catch (e) { clear(box).appendChild(h('p.muted', { text: errMsg(e) })); }
  }
  await load();
}
void can;
