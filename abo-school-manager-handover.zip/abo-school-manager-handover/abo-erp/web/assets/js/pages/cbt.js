// CBT / Online Examination — staff side. Everything is computed and authorised on the server; this module lays it out.
import { h, clear, icon, append } from '../core/dom.js';
import { api, qs, download } from '../core/api.js';
import { can, session } from '../core/session.js';
import { pageHead, btn, formDialog, badge, card, toast, fail, confirmDialog, simpleTable, empty, modal, field, form, stat, spinner, dataTable, tabs, errMsg } from '../core/ui.js';
import { dateTime, date, initials, tn } from '../core/format.js';
import { renderRich, plain } from '../core/mathtext.js';
import { barChart, donut, PALETTE } from '../core/charts.js';
import { academic } from './people.js';
import { questionEditor, questionCard, TYPE_LABELS } from './cbt_editor.js';
import { fileUrl } from '../core/config.js';

const LIFE = { draft: ['draft', 'muted'], scheduled: ['scheduled', 'info'], active: ['active', 'ok'], completed: ['completed', 'muted'] };
const life = (x) => badge(...(LIFE[x] || [x]));
const iso = (v) => (v ? new Date(v).toISOString() : null);
const local = (v) => { if (!v) return ''; const d = new Date(v); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 16); };
const mins = (s) => (s === null || s === undefined ? '—' : `${Math.floor(s / 60)}m ${String(Math.round(s % 60)).padStart(2, '0')}s`);
const pctText = (v) => (v === null || v === undefined ? '—' : `${Number(v)}%`);
async function topicsFor(subjectId) { try { return (await api.get(`/cbt/bank/topics${qs({ subjectId })}`)).items.map((t) => t.topic); } catch { return []; } }

// ───────── dashboard ─────────
export async function dashboard(view) {
  const d = await api.get('/cbt/dashboard'); const c = d.cards;
  view.appendChild(pageHead('CBT Dashboard', 'Computer-based tests and examinations. Timing, marking and answer keys stay on the server.',
    can('cbt.create') ? h('a.btn.btn-primary', { href: '#/cbt/new' }, icon('plus', 16), h('span', { text: 'Create examination' })) : null, can('cbt.view') ? h('a.btn', { href: '#/cbt/bank', text: 'Question bank' }) : null));
  view.appendChild(h('div.stats', stat('Total exams', c.total, '', 'cbt'), stat('Draft', c.draft, 'being prepared', 'file'), stat('Scheduled', c.scheduled, 'not yet open', 'calendar', 'blue'), stat('Active', c.active, 'open now', 'activity', c.active ? 'gold' : ''),
    stat('Completed', c.completed, '', 'check'), stat('Question bank', c.questions, 'active questions', 'layers'), stat('Candidates', c.candidates, 'across exams', 'users'),
    stat('Average score', pctText(c.averageScore), `${c.results} result(s)`, 'chart'), stat('Pass rate', pctText(c.passRate), '', 'shield', c.passRate !== null && c.passRate < 50 ? 'red' : '')));
  const row = (x) => h('a.btn.btn-sm', { href: `#/cbt/exam/${x.id}`, text: 'Open' });
  view.appendChild(h('div.grid.g2',
    card('Recent examinations', simpleTable([{ label: 'Examination', render: (x) => h('strong', { text: x.title }) }, { label: 'Subject', render: (x) => x.subject || '—' }, { label: 'Class', render: (x) => x.class_name || 'Any' },
      { label: 'Date', render: (x) => date(x.starts_at || x.created_at) }, { label: 'Duration', render: (x) => `${x.duration_minutes} min` }, { key: 'candidates', label: 'Candidates', cls: 'num' }, { label: 'Status', render: (x) => life(x.lifecycle) }, { label: '', render: row }], d.recent, 'No examinations yet')),
    card('Upcoming examinations', simpleTable([{ label: 'Exam', render: (x) => h('strong', { text: x.title }) }, { label: 'Subject', render: (x) => x.subject || '—' }, { label: 'Class', render: (x) => x.class_name || 'Any' },
      { label: 'Opens', render: (x) => dateTime(x.starts_at) }, { label: 'Closes', render: (x) => dateTime(x.ends_at) }, { label: 'Duration', render: (x) => `${x.duration_minutes} min` }, { label: 'Status', render: (x) => life(x.lifecycle) }], d.upcoming, 'Nothing scheduled'))));
}

// ───────── exam lists ─────────
function listPage(status, title, sub) {
  return async (view) => {
    const a = await academic();
    view.appendChild(pageHead(title, sub, can('cbt.create') ? h('a.btn.btn-primary', { href: '#/cbt/new' }, icon('plus', 16), h('span', { text: 'Create examination' })) : null));
    view.appendChild(dataTable({
      columns: [{ label: 'Examination', render: (x) => h('div', h('strong', { text: x.title }), h('div.muted', { text: `${x.category}${x.score_component ? ` · feeds ${x.score_component.toUpperCase()}` : ''}` })) },
        { label: 'Subject', render: (x) => x.subject || '—' }, { label: 'Class', render: (x) => x.class_name || 'Any' }, { label: 'Window', render: (x) => (x.starts_at || x.ends_at ? `${dateTime(x.starts_at)} → ${dateTime(x.ends_at)}` : 'Always open') },
        { label: 'Qs', cls: 'num', render: (x) => x.questions }, { label: 'Marks', cls: 'num', render: (x) => Number(x.total_marks) }, { label: 'Duration', render: (x) => `${x.duration_minutes} min` },
        { label: 'Candidates', cls: 'num', render: (x) => x.candidates }, { label: 'Sat', cls: 'num', render: (x) => x.attempts }, { label: 'Avg', render: (x) => pctText(x.average) }, { label: 'Status', render: (x) => life(x.lifecycle) },
        { label: '', render: (x) => h('a.btn.btn-sm', { href: `#/cbt/exam/${x.id}`, text: 'Open' }) }],
      filters: [{ name: 'subjectId', label: 'Subject', placeholder: 'All subjects', options: a.subjects.map((s) => ({ value: s.id, label: s.name })) }, { name: 'classId', label: 'Class', placeholder: 'All classes', options: a.classes.map((c) => ({ value: c.id, label: c.display_name })) }],
      load: (o) => api.get('/cbt/exams' + qs({ ...o, status })), rowClick: (x) => { location.hash = `#/cbt/exam/${x.id}`; },
      empty: status === 'all' ? 'No examinations yet' : `No ${status} examinations`, emptyHint: can('cbt.create') ? 'Create an examination to get started.' : undefined,
    }));
  };
}
export const exams = listPage('all', 'All Examinations', 'Every CBT examination you can manage.');
export const scheduled = listPage('scheduled', 'Scheduled Examinations', 'Published examinations that open in the future. Candidates get a reminder 30 minutes before.');
export const active = listPage('active', 'Active Examinations', 'Open right now. Close an exam to auto-submit anyone still writing.');
export const completed = listPage('completed', 'Completed Examinations', 'Closed or past their end time — mark essays, release results and send scores to the result sheet.');
export const drafts = listPage('draft', 'Draft Examinations', 'Being prepared. Publish when every step is complete.');

// exam picker used by Candidates / CBT Results
function pickerPage(title, sub, tab) {
  return async (view) => {
    view.appendChild(pageHead(title, sub));
    view.appendChild(dataTable({ columns: [{ label: 'Examination', render: (x) => h('strong', { text: x.title }) }, { label: 'Subject', render: (x) => x.subject || '—' }, { label: 'Class', render: (x) => x.class_name || 'Any' },
      { key: 'candidates', label: 'Candidates', cls: 'num' }, { key: 'attempts', label: 'Sat', cls: 'num' }, { label: 'Status', render: (x) => life(x.lifecycle) }, { label: '', render: (x) => h('a.btn.btn-sm.btn-primary', { href: `#/cbt/exam/${x.id}?tab=${tab}`, text: 'Open' }) }],
    load: (o) => api.get('/cbt/exams' + qs({ ...o, status: 'all' })), rowClick: (x) => { location.hash = `#/cbt/exam/${x.id}?tab=${tab}`; }, empty: 'No examinations yet' }));
  };
}
export const candidatesPicker = pickerPage('Candidates', 'Choose an examination to manage who may sit it.', 'candidates');
export const resultsPicker = pickerPage('CBT Results', 'Choose an examination to view, release, withhold or export results.', 'results');

// ───────── Create Examination wizard (5 steps) ─────────
const STEPS = ['Basic information', 'Select questions', 'Exam settings', 'Candidates', 'Review & publish'];
export async function wizard(view, p, q) {
  const a = await academic();
  const id = p.id || null; const step = Math.min(5, Math.max(1, Number(q.step) || 1));
  const data = id ? await api.get(`/cbt/exams/${id}`) : null;
  const e = data ? data.exam : null;
  if (e && e.status !== 'draft') { view.appendChild(pageHead(e.title, 'This examination is already published — edit only its schedule from the examination page.')); view.appendChild(h('a.btn', { href: `#/cbt/exam/${id}`, text: 'Open examination' })); return; }
  const settings = (await api.get('/cbt/settings')).settings || {};
  view.appendChild(pageHead(id ? `Edit: ${e.title}` : 'Create Examination', 'Five short steps. Nothing is visible to students until you publish.'));
  view.appendChild(h('ol.stepper', STEPS.map((s, i) => h(`li${i + 1 === step ? '.on' : ''}${i + 1 < step ? '.done' : ''}`, id || i === 0 ? h('a', { href: id ? `#/cbt/exam/${id}/edit?step=${i + 1}` : '#/cbt/new', text: `${i + 1}. ${s}` }) : h('span', { text: `${i + 1}. ${s}` })))));
  const goto = (n, newId) => { location.hash = `#/cbt/exam/${newId || id}/edit?step=${n}`; };
  const box = h('div'); view.appendChild(box);
  if (step === 1) return stepBasic(box, a, e, settings, goto);
  if (step === 2) return stepQuestions(box, a, data, goto);
  if (step === 3) return stepSettings(box, e, goto);
  if (step === 4) return stepCandidates(box, a, e, goto);
  return stepReview(box, data, goto);
}
async function stepBasic(box, a, e, st, goto) {
  const comps = (await api.get('/cbt/settings')).components;
  const sessions = a.sessions.map((s) => ({ value: s.id, label: s.name }));
  const terms = a.sessions.flatMap((s) => s.terms.map((t) => ({ value: t.id, label: `${s.name} · ${tn(t.name)} term${t.is_current ? ' (current)' : ''}` })));
  const cur = (a.sessions.find((s) => s.is_current) || {}); const curTerm = (cur.terms || []).find((t) => t.is_current);
  const f = form([
    { name: 'title', label: 'Examination title', required: true, full: true, placeholder: 'Mathematics First Term Examination' },
    { name: 'subjectId', label: 'Subject', type: 'select', required: true, options: a.subjects.map((s) => ({ value: s.id, label: s.name })) },
    { name: 'classId', label: 'Class & arm', type: 'select', required: true, options: a.classes.map((c) => ({ value: c.id, label: c.display_name })) },
    { name: 'sessionId', label: 'Session', type: 'select', options: sessions }, { name: 'termId', label: 'Term', type: 'select', options: terms },
    { name: 'category', label: 'Examination type', type: 'select', placeholder: false, options: [{ value: 'exam', label: 'Examination' }, { value: 'test', label: 'Test' }, { value: 'ca', label: 'Continuous assessment' }, { value: 'mock', label: 'Mock / practice exam' }, { value: 'practice', label: 'Practice (not graded)' }, { value: 'assignment', label: 'Assignment' }] },
    { name: 'durationMinutes', label: 'Duration (minutes)', type: 'number', required: true, min: 1, maxv: 600 }, { name: 'passMark', label: 'Pass mark (%)', type: 'number', min: 0, maxv: 100 },
    { name: 'scoreComponent', label: 'Send the score to the result sheet as…', type: 'select', placeholder: 'Do not send (stand-alone CBT)', options: comps.map((c) => ({ value: c.key, label: `${c.label} (max ${c.max})` })), hint: 'The CBT percentage is scaled to this column’s maximum, then your normal grading, positions and approval apply.' },
    { name: 'instructions', label: 'Instructions to candidates', type: 'textarea', full: true, rows: 3, placeholder: 'Answer ALL questions. Each question carries equal marks…' },
  ], e ? { title: e.title, subjectId: e.subject_id, classId: e.class_id, sessionId: e.session_id, termId: e.term_id, category: e.category, durationMinutes: e.duration_minutes, passMark: Number(e.pass_mark), scoreComponent: e.score_component, instructions: e.instructions }
    : { category: 'exam', durationMinutes: st.durationMinutes || 30, passMark: st.passMark ?? 50, sessionId: cur.id, termId: curTerm && curTerm.id, scoreComponent: st.scoreComponent || '' });
  const alert = h('div.form-alert', { role: 'alert', hidden: true });
  const next = async () => {
    alert.hidden = true; const v = f._values();
    const body = { title: v.title, subjectId: v.subjectId, classId: v.classId, sessionId: v.sessionId, termId: v.termId, category: v.category, durationMinutes: v.durationMinutes, passMark: v.passMark ?? undefined, scoreComponent: v.scoreComponent || null, instructions: v.instructions };
    if (!v.title || !v.subjectId || !v.classId || !v.durationMinutes) { alert.textContent = 'Title, subject, class and duration are required.'; alert.hidden = false; return; }
    try { if (e) { await api.patch(`/cbt/exams/${e.id}`, body); goto(2); } else { const r = await api.post('/cbt/exams', body); toast('Draft saved'); goto(2, r.id); } }
    catch (err) { if (!f._error(err)) { alert.textContent = errMsg(err); alert.hidden = false; } }
  };
  box.appendChild(card('Step 1 · Basic information', [alert, f, h('div.page-actions', h('a.btn', { href: '#/cbt', text: 'Cancel' }), btn('Save & continue', next, { kind: 'primary' }))]));
}
async function stepQuestions(box, a, data, goto) {
  const e = data.exam; const qsn = data.questions;
  const topics = await topicsFor(e.subject_id);
  const reload = () => { location.hash = `#/cbt/exam/${e.id}/edit?step=2&t=${Date.now()}`; };
  // selected list (drag & drop + up/down ordering)
  const list = h('ol.q-sel');
  let order = qsn.map((x) => x.id);
  const saveOrder = async () => { try { await api.put(`/cbt/exams/${e.id}/order`, { questionIds: order }); } catch (err) { fail(err); } };
  qsn.forEach((qq, i) => {
    const li = h('li.q-sel-item', { draggable: 'true', dataset: { id: qq.id } },
      h('span.drag', { text: '⋮⋮', 'aria-hidden': 'true' }), h('span.q-num', { text: i + 1 }), h('div.grow', h('div', { text: plain(qq.text, 160) }), h('small.muted', { text: `${TYPE_LABELS[qq.type]} · ${qq.topic || 'no topic'} · ${qq.difficulty} · ${Number(qq.marks)} mark(s)` })),
      h('div.page-actions', btn('↑', async () => { const k = order.indexOf(qq.id); if (k > 0) { [order[k - 1], order[k]] = [order[k], order[k - 1]]; await saveOrder(); reload(); } }, { kind: 'ghost', title: 'Move up' }),
        btn('↓', async () => { const k = order.indexOf(qq.id); if (k < order.length - 1) { [order[k + 1], order[k]] = [order[k], order[k + 1]]; await saveOrder(); reload(); } }, { kind: 'ghost', title: 'Move down' }),
        btn('Preview', () => modal({ title: `Question ${i + 1}`, wide: true, body: questionCard(qq, { n: i + 1 }) }), { kind: 'ghost' }),
        btn('Edit', async () => { const r = await questionEditor({ title: 'Edit question', q: qq, a, topics, onSave: (b) => api.patch(`/cbt/questions/${qq.id}`, b) }); if (r) reload(); }, { kind: 'ghost' }),
        btn('Remove', async () => { if (await confirmDialog({ title: 'Remove this question from the exam?', message: 'The original stays in the question bank.', danger: true })) { await api.del(`/cbt/questions/${qq.id}`); reload(); } }, { kind: 'ghost' })));
    li.addEventListener('dragstart', (ev) => { ev.dataTransfer.setData('text/plain', qq.id); li.classList.add('dragging'); });
    li.addEventListener('dragend', () => li.classList.remove('dragging'));
    li.addEventListener('dragover', (ev) => ev.preventDefault());
    li.addEventListener('drop', async (ev) => { ev.preventDefault(); const from = ev.dataTransfer.getData('text/plain'); if (!from || from === qq.id) return; order = order.filter((x) => x !== from); order.splice(order.indexOf(qq.id), 0, from); await saveOrder(); reload(); });
    list.appendChild(li);
  });
  const total = qsn.reduce((t, x) => t + Number(x.marks), 0);
  // option A: pick from bank
  const bankBox = h('div'); const picked = new Set();
  const bankFilters = { subjectId: e.subject_id, q: '', difficulty: '', topic: '', page: 1 };
  const loadBank = async () => {
    clear(bankBox).appendChild(spinner());
    try {
      const r = await api.get('/cbt/bank' + qs({ ...bankFilters, pageSize: 15 }));
      const inExam = new Set(qsn.map((x) => x.source_question_id));
      clear(bankBox).append(simpleTable([{ label: '', render: (x) => (inExam.has(x.id) ? badge('in exam', 'ok') : h('input', { type: 'checkbox', checked: picked.has(x.id), 'aria-label': 'Select question', on: { change: (ev) => { if (ev.target.checked) picked.add(x.id); else picked.delete(x.id); addBtn.textContent = `Add ${picked.size} selected`; } } })) },
        { label: 'Question', render: (x) => h('div', { text: plain(x.text, 120) }) }, { label: 'Type', render: (x) => TYPE_LABELS[x.type] }, { key: 'topic', label: 'Topic' }, { key: 'difficulty', label: 'Difficulty' }, { label: 'Marks', render: (x) => Number(x.marks) },
        { label: '', render: (x) => btn('Preview', () => modal({ title: 'Preview', wide: true, body: questionCard(x) }), { kind: 'ghost' }) }], r.items, 'No questions match. Add some to the bank or change the filters.'),
      h('div.pager', btn('Prev', () => { bankFilters.page--; loadBank(); }, { disabled: r.page <= 1 }), h('span.muted', { text: `Page ${r.page} / ${r.pages} · ${r.total} questions` }), btn('Next', () => { bankFilters.page++; loadBank(); }, { disabled: r.page >= r.pages })));
    } catch (err) { clear(bankBox); fail(err); }
  };
  const addBtn = btn('Add 0 selected', async () => { if (!picked.size) return toast('Tick the questions to add first.', 'err'); try { const r = await api.post(`/cbt/exams/${e.id}/from-bank`, { questionIds: [...picked] }); toast(`${r.added} question(s) added`); reload(); } catch (err) { fail(err); } }, { kind: 'primary' });
  let t; const search = h('input.input', { type: 'search', placeholder: 'Search the bank…', 'aria-label': 'Search the bank', on: { input: (ev) => { clearTimeout(t); t = setTimeout(() => { bankFilters.q = ev.target.value.trim(); bankFilters.page = 1; loadBank(); }, 300); } } });
  const fDiff = h('select.input', { 'aria-label': 'Difficulty', on: { change: (ev) => { bankFilters.difficulty = ev.target.value; bankFilters.page = 1; loadBank(); } } }, [['', 'Any difficulty'], ['easy', 'Easy'], ['medium', 'Medium'], ['hard', 'Difficult']].map(([v, l]) => h('option', { value: v, text: l })));
  const fTopic = h('select.input', { 'aria-label': 'Topic', on: { change: (ev) => { bankFilters.topic = ev.target.value; bankFilters.page = 1; loadBank(); } } }, h('option', { value: '', text: 'Any topic' }), topics.map((x) => h('option', { value: x, text: x })));
  // option B: generate
  const rules = h('div.rules');
  const addRule = (r = {}) => rules.appendChild(h('div.rule-row', h('input.input', { type: 'number', min: 1, max: 200, value: r.count || 10, 'aria-label': 'How many' }),
    h('select.input', { 'aria-label': 'Difficulty' }, [['', 'any difficulty'], ['easy', 'easy'], ['medium', 'medium'], ['hard', 'difficult']].map(([v, l]) => h('option', { value: v, text: l, selected: v === (r.difficulty || '') }))),
    h('select.input', { 'aria-label': 'Topic' }, h('option', { value: '', text: 'any topic' }), topics.map((x) => h('option', { value: x, text: x }))),
    h('button.icon-btn', { type: 'button', 'aria-label': 'Remove rule', title: 'Remove rule', on: { click: (ev) => ev.currentTarget.closest('.rule-row').remove() } }, icon('x', 16))));
  addRule({ count: 10, difficulty: 'easy' }); addRule({ count: 20, difficulty: 'medium' }); addRule({ count: 10, difficulty: 'hard' });
  const generate = btn('Generate questions', async () => {
    const rs = [...rules.querySelectorAll('.rule-row')].map((row) => { const [c, d, tp] = row.querySelectorAll('input,select'); return { count: Number(c.value), ...(d.value ? { difficulty: d.value } : {}), ...(tp.value ? { topic: tp.value } : {}) }; }).filter((r) => r.count > 0);
    if (!rs.length) return toast('Add at least one rule.', 'err');
    try { const r = await api.post(`/cbt/exams/${e.id}/generate`, { rules: rs }); toast(`${r.added} question(s) picked at random`); reload(); } catch (err) { fail(err); }
  }, { kind: 'primary' });
  const tabBody = h('div');
  const showTab = (k) => {
    clear(tabBody);
    if (k === 'bank') { tabBody.append(h('div.dt-bar', search, fDiff, fTopic, h('div.spacer'), addBtn), bankBox); loadBank(); }
    if (k === 'auto') tabBody.append(h('p.muted', { text: 'Pick questions at random from the bank of this subject — e.g. 10 easy + 20 medium + 10 difficult, or 10 per topic. Questions already in the exam are skipped.' }), rules, h('div.page-actions', btn('Add rule', () => addRule(), { ic: 'plus' }), generate));
    if (k === 'new') tabBody.append(h('p.muted', { text: 'Write a question just for this exam (use the Question Bank to reuse questions across exams).' }),
      btn('Write a new question', async () => { const r = await questionEditor({ title: 'New exam question', q: { subject_id: e.subject_id, class_id: e.class_id }, a, topics, onSave: (b) => api.post(`/cbt/exams/${e.id}/questions`, b) }); if (r) reload(); }, { kind: 'primary', ic: 'plus' }));
  };
  box.append(card(`Step 2 · Selected questions (${qsn.length}) · ${total} marks`, qsn.length ? [h('p.muted', { text: 'Drag to reorder (or use ↑ ↓). Order is kept unless “randomise questions” is on.' }), list] : empty('No questions yet', 'Add questions from the bank, generate them automatically, or write new ones below.')),
    card('Add questions', [tabs([{ key: 'bank', label: 'A · Choose from the bank' }, { key: 'auto', label: 'B · Generate automatically' }, { key: 'new', label: 'Write a new question' }], showTab, 'bank'), tabBody]),
    h('div.page-actions', h('a.btn', { href: `#/cbt/exam/${e.id}/edit?step=1`, text: '← Back' }), btn('Continue', () => goto(3), { kind: 'primary', disabled: !qsn.length })));
  showTab('bank');
}
function stepSettings(box, e, goto) {
  const f = form([
    { section: 'Timing' }, { name: 'durationMinutes', label: 'Duration (minutes)', type: 'number', required: true }, { name: 'maxAttempts', label: 'Maximum attempts', type: 'number' },
    { name: 'startsAt', label: 'Start date & time', type: 'datetime-local', hint: 'Empty = opens when you publish' }, { name: 'endsAt', label: 'End date & time', type: 'datetime-local', hint: 'No attempt can run past this time' },
    { section: 'Paper' }, { name: 'shuffleQuestions', label: 'Randomise question order for each candidate', type: 'checkbox' }, { name: 'shuffleOptions', label: 'Randomise answer options', type: 'checkbox' },
    { name: 'allowBackNav', label: 'Allow going back to earlier questions', type: 'checkbox' }, { name: 'allowReview', label: 'Show a review page before final submission', type: 'checkbox' },
    { name: 'autosave', label: 'Autosave answers', type: 'checkbox' }, { name: 'allowResume', label: 'Allow resuming after a refresh / connection loss', type: 'checkbox' },
    { section: 'Results' }, { name: 'passMark', label: 'Pass mark (%)', type: 'number' }, { name: 'showResult', label: 'Show the result immediately after submission', type: 'checkbox' },
    { name: 'showAnswers', label: 'Show correct answers & explanations after the result is released', type: 'checkbox' }, { name: 'scorePolicy', label: 'If several attempts count…', type: 'select', placeholder: false, options: [{ value: 'best', label: 'Use the best attempt' }, { value: 'latest', label: 'Use the latest attempt' }] },
    { section: 'Security' }, { name: 'accessCode', label: e.has_access_code ? 'Access code (set — type a new one to change, “-” to remove)' : 'Access code (optional)', placeholder: 'e.g. JSS1-MATHS', hint: '4–20 letters/numbers. Give it to candidates in the exam hall.' },
    { name: 'fullscreen', label: 'Ask candidates to use full-screen mode (leaving it is recorded)', type: 'checkbox' },
  ], { durationMinutes: e.duration_minutes, maxAttempts: e.max_attempts, startsAt: local(e.starts_at), endsAt: local(e.ends_at), shuffleQuestions: e.shuffle_questions, shuffleOptions: e.shuffle_options, allowBackNav: e.allow_back_nav, allowReview: e.allow_review,
    autosave: e.autosave, allowResume: e.allow_resume, passMark: Number(e.pass_mark), showResult: e.show_result, showAnswers: e.show_answers, scorePolicy: e.score_policy, fullscreen: e.fullscreen });
  const alert = h('div.form-alert', { role: 'alert', hidden: true });
  box.appendChild(card('Step 3 · Exam settings', [alert, f, h('div.page-actions', h('a.btn', { href: `#/cbt/exam/${e.id}/edit?step=2`, text: '← Back' }), btn('Save & continue', async () => {
    alert.hidden = true; const v = f._values();
    const body = { durationMinutes: v.durationMinutes, maxAttempts: v.maxAttempts || 1, startsAt: iso(v.startsAt), endsAt: iso(v.endsAt), shuffleQuestions: v.shuffleQuestions, shuffleOptions: v.shuffleOptions, allowBackNav: v.allowBackNav, allowReview: v.allowReview,
      autosave: v.autosave, allowResume: v.allowResume, passMark: v.passMark ?? 50, showResult: v.showResult, showAnswers: v.showAnswers, scorePolicy: v.scorePolicy, fullscreen: v.fullscreen };
    if (v.accessCode) body.accessCode = v.accessCode === '-' ? null : v.accessCode.toUpperCase();
    try { await api.patch(`/cbt/exams/${e.id}`, body); goto(4); } catch (err) { if (!f._error(err)) { alert.textContent = errMsg(err); alert.hidden = false; } }
  }, { kind: 'primary' }))]));
}
async function candidatesPanel(box, a, e, { editable }) {
  const d = await api.get(`/cbt/exams/${e.id}/candidates`);
  const reload = async () => { clear(box); await candidatesPanel(box, a, e, { editable }); };
  const modeText = d.mode === 'selected' ? 'Only the students listed below may sit this exam.' : d.mode === 'class' ? `Every student in ${e.class_name || 'the exam class'} may sit this exam (the whole class).` : 'No candidates yet.';
  const actions = editable ? [btn('Add whole classes', async () => { const r = await formDialog({ title: 'Add classes', intro: 'Every active student of the chosen classes becomes a candidate.', fields: [{ name: 'classIds', label: 'Classes', type: 'multiselect', full: true, options: a.classes.map((c) => ({ value: c.id, label: c.display_name })) }], onSubmit: (v) => api.post(`/cbt/exams/${e.id}/candidates`, { classIds: v.classIds }) }); if (r) { toast(`${r.added} candidate(s) added`); reload(); } }, { ic: 'plus' }),
    btn('Add specific students', async () => {
      const picked = new Set(); const out = h('div'); let t;
      const find = async (qv) => { const r = await api.get('/students' + qs({ q: qv || undefined, pageSize: 50 })); clear(out).appendChild(h('div.checks.col', r.items.map((s) => h('label.check', h('input', { type: 'checkbox', checked: picked.has(s.id), on: { change: (ev) => { if (ev.target.checked) picked.add(s.id); else picked.delete(s.id); } } }), h('span', { text: `${s.last_name} ${s.first_name} · ${s.admission_no} · ${s.class_name || 'no class'}` }))))); };
      const inp = h('input.input', { type: 'search', placeholder: 'Search name or admission no…', on: { input: (ev) => { clearTimeout(t); t = setTimeout(() => find(ev.target.value.trim()), 300); } } });
      find('');
      const m = modal({ title: 'Add students', wide: true, body: h('div', inp, out), actions: [btn('Cancel', () => m.close()), btn('Add selected', async () => { if (!picked.size) return; try { const r = await api.post(`/cbt/exams/${e.id}/candidates`, { studentIds: [...picked] }); toast(`${r.added} added`); m.close(); reload(); } catch (err) { fail(err); } }, { kind: 'primary' })] });
    }, { ic: 'users' })] : [];
  const rows = d.items;
  const removeSel = new Set();
  box.appendChild(card(`Candidates (${rows.length})`, [h('p.muted', { text: modeText }), h('div.page-actions', ...actions,
    editable && rows.length ? btn('Remove selected', async () => { if (!removeSel.size) return toast('Tick students to remove.', 'err'); if (await confirmDialog({ title: `Remove ${removeSel.size} candidate(s)?`, message: 'They will no longer see this exam. Existing attempts are kept.', danger: true })) { try { await api.del(`/cbt/exams/${e.id}/candidates`, { studentIds: [...removeSel] }); toast('Removed'); reload(); } catch (err) { fail(err); } } }, { kind: 'ghost' }) : null),
  simpleTable([...(editable ? [{ label: '', render: (s) => h('input', { type: 'checkbox', 'aria-label': 'Select', on: { change: (ev) => { if (ev.target.checked) removeSel.add(s.id); else removeSel.delete(s.id); } } }) }] : []),
    { label: 'Student', render: (s) => `${s.last_name} ${s.first_name}` }, { key: 'admission_no', label: 'Admission no', cls: 'mono' }, { label: 'Class', render: (s) => s.class_name || '—' },
    { label: 'Portal login', render: (s) => (s.has_login ? badge('yes', 'ok') : badge('no login', 'warn')) }, { label: 'Attempt status', render: (s) => badge(s.last_status || 'not started') }, { key: 'attempts', label: 'Attempts', cls: 'num' },
    { label: 'Best', render: (s) => pctText(s.best_percentage) }], rows, 'No candidates yet'),
  rows.some((s) => !s.has_login) ? h('p.muted', { text: 'Students without a portal login cannot sit the exam — create logins from the student’s profile (Students › Student Profile).' }) : null]));
}
async function stepCandidates(box, a, e, goto) {
  const panel = h('div'); box.append(panel);
  await candidatesPanel(panel, a, e, { editable: true });
  box.append(h('div.page-actions', h('a.btn', { href: `#/cbt/exam/${e.id}/edit?step=3`, text: '← Back' }), btn('Continue to review', () => goto(5), { kind: 'primary' })));
}
function stepReview(box, data, goto) {
  const e = data.exam; const scheduled = e.starts_at && new Date(e.starts_at) > new Date();
  const kv = (pairs) => h('dl.kv', pairs.flatMap(([k, v]) => [h('dt', { text: k }), h('dd', v instanceof Node ? v : { text: String(v ?? '—') })]));
  const yes = (b) => (b ? 'Yes' : 'No');
  box.append(h('div.grid.g2',
    card('Examination', kv([['Examination', e.title], ['Subject', e.subject || '—'], ['Class', e.class_name || '—'], ['Session', e.session || '—'], ['Term', e.term ? `${tn(e.term)} term` : '—'], ['Type', e.category],
      ['Questions', data.questions.length], ['Total marks', data.totalMarks], ['Duration', `${e.duration_minutes} minutes`], ['Pass mark', `${Number(e.pass_mark)}%`], ['Candidates', data.candidates],
      ['Start', e.starts_at ? dateTime(e.starts_at) : 'When published'], ['End', e.ends_at ? dateTime(e.ends_at) : 'No end time'], ['Result sheet', e.score_component ? `Feeds ${e.score_component.toUpperCase()}` : 'Stand-alone']])),
    card('Security & behaviour', kv([['Access code', yes(e.has_access_code)], ['Randomise questions', yes(e.shuffle_questions)], ['Randomise options', yes(e.shuffle_options)], ['Back navigation', yes(e.allow_back_nav)],
      ['Review page', yes(e.allow_review)], ['Resume after connection loss', yes(e.allow_resume)], ['Full-screen', yes(e.fullscreen)], ['Autosave', yes(e.autosave)], ['Maximum attempts', e.max_attempts],
      ['Result shown immediately', yes(e.show_result)], ['Correct answers shown after release', yes(e.show_answers)]]))),
  data.problems.length ? card('Complete these before publishing', h('ul.problems', data.problems.map((x) => h('li', { text: x })))) : h('div.support-banner.ok', icon('check', 16), h('span', { text: 'Everything is ready.' })),
  h('div.page-actions', h('a.btn', { href: `#/cbt/exam/${e.id}/edit?step=4`, text: '← Back' }), h('a.btn', { href: '#/cbt', text: 'Cancel' }),
    btn('Save draft', () => { toast('Draft saved'); location.hash = `#/cbt/exam/${e.id}`; }),
    can('cbt.publish') ? btn(scheduled ? 'Schedule' : 'Publish now', async () => {
      if (!(await confirmDialog({ title: scheduled ? `Schedule for ${dateTime(e.starts_at)}?` : 'Publish now?', message: 'Questions lock and candidates are notified.', confirmLabel: scheduled ? 'Schedule' : 'Publish' }))) return;
      try { const r = await api.post(`/cbt/exams/${e.id}/publish`); toast(r.lifecycle === 'scheduled' ? 'Scheduled' : 'Published'); location.hash = `#/cbt/exam/${e.id}`; } catch (err) { fail(err); }
    }, { kind: 'primary', disabled: !!data.problems.length }) : h('span.muted', { text: 'An exam officer or administrator publishes the exam.' })));
  void goto;
}

// ───────── examination page (tabs) ─────────
export async function examDetail(view, p, q) {
  const a = await academic();
  const data = await api.get(`/cbt/exams/${p.id}`); const e = data.exam; const draft = e.status === 'draft';
  const actions = [];
  if (draft && can('cbt.update')) actions.push(h('a.btn.btn-primary', { href: `#/cbt/exam/${e.id}/edit?step=${data.questions.length ? 5 : 2}`, text: 'Continue editing' }));
  if (e.status === 'published' && can('cbt.update')) actions.push(btn('Change schedule', async () => { const r = await formDialog({ title: 'Schedule & result visibility', fields: [{ name: 'startsAt', label: 'Start', type: 'datetime-local' }, { name: 'endsAt', label: 'End', type: 'datetime-local' }, { name: 'showResult', label: 'Show result immediately', type: 'checkbox' }, { name: 'showAnswers', label: 'Show answers after release', type: 'checkbox' }], values: { startsAt: local(e.starts_at), endsAt: local(e.ends_at), showResult: e.show_result, showAnswers: e.show_answers }, onSubmit: (v) => api.patch(`/cbt/exams/${e.id}`, { startsAt: iso(v.startsAt), endsAt: iso(v.endsAt), showResult: v.showResult, showAnswers: v.showAnswers }) }); if (r) { clear(view); examDetail(view, p, q); } }));
  if (e.status === 'published' && can('cbt.publish')) actions.push(btn('Close exam', async () => { if (await confirmDialog({ title: 'Close this exam?', message: 'Anyone still writing is submitted automatically with their saved answers.', danger: true, confirmLabel: 'Close exam' })) { try { const r = await api.post(`/cbt/exams/${e.id}/close`); toast(`Closed · ${r.autoSubmitted} auto-submitted`); clear(view); examDetail(view, p, q); } catch (err) { fail(err); } } }, { kind: 'danger' }));
  if (draft && can('cbt.update')) actions.push(btn('Delete draft', async () => { if (await confirmDialog({ title: 'Delete this draft?', danger: true })) { try { await api.del(`/cbt/exams/${e.id}`); toast('Deleted'); location.hash = '#/cbt'; } catch (err) { fail(err); } } }, { kind: 'ghost' }));
  view.appendChild(pageHead(e.title, `${e.subject || 'No subject'} · ${e.class_name || 'Any class'}${e.term ? ` · ${e.session || ''} ${tn(e.term)} term` : ''} · ${data.questions.length} questions · ${data.totalMarks} marks · ${e.duration_minutes} min`, life(e.lifecycle), ...actions));
  const body = h('div');
  const T = [{ key: 'overview', label: 'Overview' }, { key: 'questions', label: `Questions (${data.questions.length})` }, { key: 'candidates', label: `Candidates (${data.candidates})` }];
  if (can('cbt.results')) T.push({ key: 'results', label: 'Results' }, { key: 'analytics', label: 'Analytics' });
  T.push({ key: 'print', label: 'Print' });
  const show = async (k) => { clear(body).appendChild(spinner()); try { const box = h('div'); await ({ overview, questions: qTab, candidates: cTab, results: rTab, analytics: aTab, print: pTab })[k](box); clear(body).appendChild(box); } catch (err) { clear(body); fail(err); } };
  async function overview(box) {
    const counts = can('cbt.results') && !draft ? (await api.get(`/cbt/exams/${e.id}/results`)).items : [];
    const sat = counts.filter((x) => x.attemptStatus !== 'not started'); const res = counts.filter((x) => x.percentage !== null);
    append(box, [h('div.stats', stat('Candidates', data.candidates, '', 'users'), stat('Sat the exam', sat.length, '', 'check'), stat('Results', res.length, `${res.filter((x) => x.released).length} released`, 'book'),
      stat('Average', res.length ? `${Math.round(res.reduce((t, x) => t + x.percentage, 0) / res.length * 10) / 10}%` : '—', '', 'chart')),
    card('Details', h('dl.kv', [['Opens', e.starts_at ? dateTime(e.starts_at) : 'When published'], ['Closes', e.ends_at ? dateTime(e.ends_at) : 'No end time'], ['Attempts allowed', e.max_attempts], ['Pass mark', `${Number(e.pass_mark)}%`],
      ['Access code', e.has_access_code ? 'Required' : 'None'], ['Result sheet', e.score_component ? `Feeds ${e.score_component.toUpperCase()}${e.scores_pushed_at ? ` · sent ${dateTime(e.scores_pushed_at)}` : ''}` : 'Stand-alone'], ['Instructions', e.instructions || '—']]
      .flatMap(([k, v]) => [h('dt', { text: k }), h('dd', { text: String(v) })]))),
    data.problems.length ? card('Not ready to publish', h('ul.problems', data.problems.map((x) => h('li', { text: x })))) : null]);
  }
  async function qTab(box) { box.append(data.questions.length ? h('div', data.questions.map((qq, i) => questionCard(qq, { n: i + 1 }))) : empty('No questions yet', draft ? 'Continue editing to add questions.' : '')); }
  async function cTab(box) { await candidatesPanel(box, a, e, { editable: can('cbt.update') && e.status !== 'closed' }); }
  async function rTab(box) {
    const r = await api.get(`/cbt/exams/${e.id}/results`);
    const top = h('div.page-actions',
      btn('Export CSV', () => download(`/cbt/exams/${e.id}/results?format=csv`).catch(fail), { ic: 'download' }), btn('Export Excel', () => download(`/cbt/exams/${e.id}/results?format=xlsx`).catch(fail), { ic: 'download' }),
      btn('Print', () => window.print(), { ic: 'printer' }),
      can('cbt.publish') ? btn('Release all', async () => { if (await confirmDialog({ title: 'Release all results?', message: 'Candidates see their score now (withheld results stay withheld).' })) { const x = await api.post(`/cbt/exams/${e.id}/release`, { release: true }); toast(`${x.changed} released`); show('results'); } }, { kind: 'primary' }) : null,
      can('cbt.publish') ? btn('Withhold all', async () => { if (await confirmDialog({ title: 'Withhold all results?', danger: true })) { const x = await api.post(`/cbt/exams/${e.id}/release`, { release: false }); toast(`${x.changed} withheld`); show('results'); } }, { kind: 'ghost' }) : null,
      e.score_component && can('cbt.publish') ? btn(`Send to result sheet (${e.score_component.toUpperCase()})`, () => pushScores(e, () => show('results')), { kind: 'primary', ic: 'upload' }) : null);
    box.append(top, h('div.doc-print-only', h('h2', { text: `${e.title} — results` })), card(null, simpleTable([{ key: 'student', label: 'Student' }, { key: 'admissionNo', label: 'Adm. no', cls: 'mono' },
      { label: 'Score', render: (x) => (x.score === null ? '—' : `${x.score}/${x.maxScore}`) }, { label: '%', render: (x) => pctText(x.percentage) }, { label: 'Grade', render: (x) => x.grade || '—' },
      { label: 'Status', render: (x) => (x.passed === null ? badge(x.attemptStatus === 'submitted' || x.attemptStatus === 'auto_submitted' ? 'awaiting marking' : x.attemptStatus, 'muted') : x.passed ? badge('PASS', 'ok') : badge('FAIL', 'danger')) },
      { label: 'Time', render: (x) => mins(x.timeUsedSeconds) }, { label: 'Attempt', render: (x) => (x.attemptNo ? `${x.attemptNo} of ${x.attempts}` : x.attempts || '—') },
      { label: 'Released', render: (x) => (x.resultId ? (x.released ? badge('released', 'ok') : x.withheldReason ? badge('withheld', 'danger') : badge('not yet', 'warn')) : '—') },
      { label: '', render: (x) => h('div.page-actions.no-print', x.lastAttemptId ? h('a.btn.btn-sm', { href: `#/cbt/attempt/${x.attemptId || x.lastAttemptId}`, text: 'Review' }) : null,
        x.resultId && can('cbt.publish') ? (x.released ? btn('Withhold', async () => { const reason = await confirmDialog({ title: `Withhold ${x.student}'s result?`, reason: true, danger: true }); if (reason) { await api.post(`/cbt/results/${x.resultId}/withhold`, { reason }); show('results'); } }, { kind: 'ghost' })
          : btn('Release', async () => { await api.post(`/cbt/results/${x.resultId}/release`); toast('Released'); show('results'); }, { kind: 'ghost' })) : null,
        x.lastAttemptId && can('cbt.publish') ? btn('Reset', async () => { const reason = await confirmDialog({ title: `Reset ${x.student}'s attempt?`, message: 'The attempt is kept for the record but no longer counts, and the student may sit the exam again.', reason: true, danger: true, confirmLabel: 'Reset attempt' }); if (reason) { try { await api.post(`/cbt/attempts/${x.lastAttemptId}/reset`, { reason }); toast('Attempt reset'); show('results'); } catch (err) { fail(err); } } }, { kind: 'ghost' }) : null) }], r.items, 'No candidates yet')));
  }
  async function aTab(box) { await examAnalytics(box, e.id); }
  async function pTab(box) {
    box.append(card('Print', [h('p.muted', { text: 'Printouts use A4. Choose “Save as PDF” in the print window to create a PDF.' }), h('div.tiles',
      h('a.tile', { href: `#/cbt/print/${e.id}?mode=paper` }, h('div.stat-ic', icon('file', 18)), h('div', h('strong', { text: 'Question paper' }), h('div.muted', { text: 'For offline sitting — no answers' }))),
      h('a.tile', { href: `#/cbt/print/${e.id}?mode=sheet` }, h('div.stat-ic', icon('grid', 18)), h('div', h('strong', { text: 'Answer sheet' }), h('div.muted', { text: 'Bubble grid for objective questions' }))),
      can('cbt.update') ? h('a.tile', { href: `#/cbt/print/${e.id}?mode=key` }, h('div.stat-ic', icon('key', 18)), h('div', h('strong', { text: 'Marking scheme' }), h('div.muted', { text: 'Answers & explanations — staff only' }))) : null)]));
  }
  view.append(tabs(T, show, q.tab || 'overview'), body);
  show(q.tab && T.some((t) => t.key === q.tab) ? q.tab : 'overview');
}
async function pushScores(e, after) {
  let d; try { d = await api.post(`/cbt/exams/${e.id}/push-scores`, { dryRun: true }); } catch (err) { return fail(err); }
  const body = h('div', h('p', { text: `CBT percentages are scaled to the ${d.component.label} column (maximum ${d.component.max}) of the ${e.subject} score sheet for ${e.class_name}. Your normal grading, positions and approval workflow then apply.` }),
    d.stillWriting ? h('div.form-alert', { text: `${d.stillWriting} candidate(s) are still writing — close the exam first.` }) : null,
    d.pendingManualMarking.length ? h('div.form-alert', { text: `Essays still to mark for: ${d.pendingManualMarking.join(', ')}. Their scores are not sent until marked.` }) : null,
    simpleTable([{ key: 'name', label: 'Student' }, { label: 'CBT %', render: (x) => `${x.percentage}%` }, { label: `${d.component.label} score`, render: (x) => h('strong', { text: `${x.score} / ${d.component.max}` }) }], d.rows, 'No finalised results yet'),
    d.skipped.length ? h('p.muted', { text: `${d.skipped.length} result(s) skipped (student not on the class register for the term).` }) : null);
  const m = modal({ title: 'Send scores to the result sheet', wide: true, body, actions: [btn('Cancel', () => m.close()), btn(`Send ${d.rows.length} score(s)`, async () => {
    try { const r = await api.post(`/cbt/exams/${e.id}/push-scores`, {}); m.close(); toast(`${r.written} score(s) written to the result sheet`); modal({ title: 'Scores sent', body: h('div', h('p', { text: 'The subject teacher/exam officer can review the sheet and submit it through the normal approval workflow.' }), h('a.btn.btn-primary', { href: `#/results/sheet/${r.sheetId}`, text: 'Open the score sheet' })) }); after && after(); } catch (err) { fail(err); }
  }, { kind: 'primary', disabled: !d.rows.length || !!d.stillWriting })] });
}
async function examAnalytics(box, id) {
  const d = await api.get(`/cbt/exams/${id}/analytics`); const s = d.summary;
  if (!s.candidatesWithResults) { box.appendChild(empty('No results to analyse yet', 'Analytics appear once candidates submit and objective questions are marked.')); return; }
  const qrow = (x) => h('div', h('strong', { text: `Q${x.number}. ` }), plain(x.text, 90));
  box.append(h('div.stats', stat('Attempts', s.attempts, '', 'users'), stat('Average', pctText(s.average), '', 'chart'), stat('Highest', pctText(s.highest), '', 'check'), stat('Lowest', pctText(s.lowest), '', 'activity'),
    stat('Pass rate', pctText(s.passRate), `pass mark ${d.exam.passMark}%`, 'shield'), stat('Average time', s.averageMinutes === null ? '—' : `${s.averageMinutes} min`, '', 'clock')),
  h('div.grid.g2', card('Score distribution', h('div.table-wrap', barChart(d.distribution, { max: Math.max(1, ...d.distribution.map((x) => x.value)), title: 'Score distribution', fmt: (v) => v }))),
    card('Grade distribution', h('div.kpi-row', donut(d.grades.map((g, i) => ({ label: g.grade, value: g.count, color: PALETTE[i % PALETTE.length] })), { title: 'Grades' }), h('div.legend', d.grades.map((g, i) => h('span', (() => { const x = h('i'); x.style.background = PALETTE[i % PALETTE.length]; return x; })(), `${g.grade} (${g.count})`)))))),
  h('div.grid.g2', card('Most-missed questions', simpleTable([{ label: 'Question', render: qrow }, { key: 'topic', label: 'Topic' }, { label: 'Correct', render: (x) => badge(`${x.correct_rate}%`, 'danger') }], d.mostMissed, '—')),
    card('Easiest questions', simpleTable([{ label: 'Question', render: qrow }, { key: 'topic', label: 'Topic' }, { label: 'Correct', render: (x) => badge(`${x.correct_rate}%`, 'ok') }], d.easiest, '—'))),
  card('Topic performance', d.topics.length ? h('div.table-wrap', barChart(d.topics.map((t) => ({ label: t.topic, value: t.rate, tone: t.rate < 50 ? 'bad' : '' })), { title: 'Topic success rate', fmt: (v) => `${v}%`, threshold: 50 })) : empty('No topics tagged')),
  card('Every question', simpleTable([{ key: 'number', label: '#' }, { label: 'Question', render: (x) => plain(x.text, 90) }, { label: 'Type', render: (x) => TYPE_LABELS[x.type] }, { key: 'topic', label: 'Topic' }, { key: 'difficulty', label: 'Difficulty' },
    { label: 'Correct', render: (x) => (x.type === 'theory' ? `avg ${x.avg_marks ?? '—'}/${Number(x.marks)}` : `${x.correct_rate}%`) }, { label: 'Incorrect', render: (x) => (x.type === 'theory' ? '—' : `${x.incorrect_rate}%`) }, { key: 'unanswered', label: 'Unanswered', cls: 'num' },
    { label: 'Avg time', render: (x) => (x.avg_seconds ? `${x.avg_seconds}s` : '—') }], d.questions)));
}

// ───────── print views ─────────
export async function printView(view, p, q) {
  const data = await api.get(`/cbt/exams/${p.id}`); const e = data.exam; const mode = q.mode || 'paper'; const school = session.me.school || {};
  const head = h('div.doc-head', school.logo_file_id ? h('img', { src: fileUrl(school.logo_file_id), alt: '' }) : h('div.brand-mark.doc-mark', { text: initials((school || {}).name || 'School') }),
    h('div', h('h1', { text: school.name || '' }), h('p', { text: `${e.title}` }), h('p', { text: `${e.subject || ''} · ${e.class_name || ''}${e.term ? ` · ${e.session || ''} ${tn(e.term)} term` : ''} · ${e.duration_minutes} minutes · ${data.totalMarks} marks` })));
  const candidate = h('div.grid.g2.cand-lines', h('p', { text: 'Name: ______________________________' }), h('p', { text: 'Admission no: ________________' }));
  let doc;
  if (mode === 'sheet') {
    const obj = data.questions.map((x, i) => ({ n: i + 1, x })).filter((r) => ['mcq', 'true_false', 'multi_select'].includes(r.x.type));
    doc = h('div.doc', head, h('h2', { text: 'Answer sheet' }), candidate, h('p.muted', { text: 'Shade ONE bubble per question (for multiple-select questions shade every correct option).' }),
      h('div.omr', obj.map((r) => h('div.omr-row', h('strong', { text: String(r.n).padStart(2, '0') }), r.x.options.map((o, k) => h('span.bubble', { text: r.x.type === 'true_false' ? o.text[0] : 'ABCDEF'[k] }))))),
      data.questions.length > obj.length ? h('p.muted', { text: `Questions ${data.questions.map((x, i) => (obj.find((r) => r.n === i + 1) ? null : i + 1)).filter(Boolean).join(', ')} are written answers — answer them on ruled paper.` }) : null);
  } else {
    const key = mode === 'key';
    doc = h('div.doc', head, h('h2', { text: key ? 'Marking scheme (confidential)' : 'Question paper' }), key ? null : candidate, e.instructions ? h('p', h('strong', { text: 'Instructions: ' }), e.instructions) : null,
      h('div.print-qs', data.questions.map((qq, i) => questionCard(qq, { n: i + 1, showKey: key }))));
  }
  view.append(h('div.page-actions.no-print', h('a.btn', { href: `#/cbt/exam/${e.id}?tab=print`, text: '← Back' }), btn('Print / save PDF', () => window.print(), { kind: 'primary', ic: 'printer' })), doc);
}

// ───────── question bank ─────────
export async function bank(view) {
  const a = await academic();
  const allTopics = await topicsFor(null);
  const me = session.me.user.id;
  const edit = async (row) => { const qq = row ? await api.get(`/cbt/bank/${row.id}`) : {}; const r = await questionEditor({ title: row ? 'Edit question' : 'Add question', q: qq, a, topics: allTopics, onSave: (b) => (row ? api.patch(`/cbt/bank/${row.id}`, b) : api.post('/cbt/bank', b)) }); if (r) { toast(r.status === 'pending' ? 'Saved — it waits for the exam officer\'s approval' : 'Question saved'); t.refresh(); } };
  let lastFilter = {};
  const toolbar = [can('cbt.create') ? btn('Add question', () => edit(null), { kind: 'primary', ic: 'plus' }) : null, can('cbt.create') ? btn('Import', () => importDialog(() => t.refresh()), { ic: 'upload' }) : null,
    btn('Export', async () => { const r = await formDialog({ title: 'Export question bank', intro: 'Exports the questions matching the current filters, including correct answers. Keep the file safe.', fields: [{ name: 'format', label: 'Format', type: 'select', placeholder: false, options: [{ value: 'csv', label: 'CSV' }, { value: 'xlsx', label: 'Excel (.xlsx)' }] }], values: { format: 'xlsx' }, onSubmit: async (v) => { await download(`/cbt/bank/export${qs({ ...lastFilter, page: undefined, pageSize: undefined, format: v.format })}`); return true; } }); void r; }, { ic: 'download' })];
  view.appendChild(pageHead('Question Bank', 'Reusable questions for every subject and class. Exams take a frozen copy, so editing the bank never changes an exam already published.'));
  const t = dataTable({
    columns: [{ label: 'Question', render: (x) => h('div.bank-q', h('div', { text: plain(x.text, 130) }), x.image_file_id ? badge('image', 'info') : null) }, { label: 'Type', render: (x) => TYPE_LABELS[x.type === 'mcq' && x.image_file_id ? 'image' : x.type] },
      { label: 'Subject', render: (x) => x.subject || '—' }, { label: 'Class', render: (x) => x.class_name || 'Any' }, { label: 'Topic', render: (x) => [x.topic, x.subtopic].filter(Boolean).join(' › ') || '—' },
      { label: 'Difficulty', render: (x) => badge(x.difficulty, x.difficulty === 'hard' ? 'danger' : x.difficulty === 'easy' ? 'ok' : 'warn') }, { label: 'Marks', cls: 'num', render: (x) => Number(x.marks) },
      { label: 'Used in', cls: 'num', render: (x) => x.used_in }, { label: 'By', render: (x) => x.created_by_name || '—' }, { label: 'Status', render: (x) => h('div', badge({ pending: 'waiting for approval', rejected: 'sent back' }[x.status] || x.status, x.status === 'active' ? 'ok' : x.status === 'pending' ? 'warn' : x.status === 'rejected' ? 'danger' : 'muted'), x.status === 'rejected' && x.review_note ? h('div.muted', { text: x.review_note }) : null) },
      { label: '', render: (x) => h('div.page-actions', btn('Preview', () => modal({ title: 'Question preview', wide: true, body: questionCard(x) }), { kind: 'ghost' }),
        can('cbt.update', 'cbt.create') ? btn('Edit', () => edit(x), { kind: 'ghost' }) : null,
        can('cbt.create') ? btn('Duplicate', async () => { try { await api.post(`/cbt/bank/${x.id}/duplicate`); toast('Duplicated'); t.refresh(); } catch (err) { fail(err); } }, { kind: 'ghost' }) : null,
        can('cbt.update', 'cbt.create') ? btn(x.status === 'active' ? 'Archive' : 'Restore', async () => { if (x.status === 'active' && !(await confirmDialog({ title: 'Archive this question?', message: 'It is hidden from the bank and from automatic selection. Exams keep their copies.' }))) return; try { await api.post(`/cbt/bank/${x.id}/archive`, { archived: x.status === 'active' }); t.refresh(); } catch (err) { fail(err); } }, { kind: 'ghost' }) : null,
        can('cbt.update', 'cbt.create') ? btn('Delete', async () => { if (await confirmDialog({ title: 'Delete this question permanently?', message: 'Exams that already used it keep their own copy.', danger: true, confirmLabel: 'Delete' })) { try { await api.del(`/cbt/bank/${x.id}`); toast('Deleted'); t.refresh(); } catch (err) { fail(err); } } }, { kind: 'ghost' }) : null) }],
    filters: [{ name: 'subjectId', label: 'Subject', placeholder: 'All subjects', options: a.subjects.map((s) => ({ value: s.id, label: s.name })) }, { name: 'classId', label: 'Class', placeholder: 'All classes', options: a.classes.map((c) => ({ value: c.id, label: c.display_name })) },
      { name: 'topic', label: 'Topic', placeholder: 'All topics', options: allTopics }, { name: 'difficulty', label: 'Difficulty', placeholder: 'Any difficulty', options: [{ value: 'easy', label: 'Easy' }, { value: 'medium', label: 'Medium' }, { value: 'hard', label: 'Difficult' }] },
      { name: 'type', label: 'Type', placeholder: 'All types', options: Object.entries(TYPE_LABELS).map(([value, label]) => ({ value, label })) }, { name: 'createdBy', label: 'Creator', placeholder: 'Anyone', options: [{ value: me, label: 'Created by me' }] },
      { name: 'status', label: 'Status', placeholder: 'Active', options: [{ value: 'archived', label: 'Archived' }, { value: 'pending', label: 'Waiting for approval' }, { value: 'rejected', label: 'Sent back to fix' }, { value: 'all', label: 'All' }] }],
    toolbar, load: (o) => { lastFilter = o; return api.get('/cbt/bank' + qs(o)); }, empty: 'No questions found', emptyHint: can('cbt.create') ? 'Add a question or import many at once from Excel/CSV.' : undefined,
  });
  view.appendChild(t);
}
function importDialog(done) {
  const file = field({ name: 'file', label: 'CSV or Excel file (max 2,000 questions)', type: 'file', accept: '.csv,.xlsx' });
  const out = h('div');
  const m = modal({ title: 'Import questions', wide: true, body: h('div', h('p.muted', { text: 'Columns: Subject, Class, Topic, Type, Question, Option A–D, Correct Answer, Mark, Difficulty, Explanation. Every row is checked first — nothing is saved until you confirm, and invalid rows are never imported.' }),
    h('div.page-actions', btn('Download template', () => download('/cbt/bank/import/template.csv').catch(fail), { ic: 'download' })), file, out),
  actions: [btn('Close', () => m.close()), btn('Check file', async () => {
    const f = file._get(); if (!f) return toast('Choose a file first', 'err');
    const fd = new FormData(); fd.append('file', f);
    try {
      const r = await api.post('/cbt/bank/import/preview', fd);
      append(clear(out), [h('div.stats', stat('Rows', r.totalRows, '', 'file'), stat('Valid', r.validRows, 'will be imported', 'check'), stat('Invalid', r.errorCount, 'will be skipped', 'x', r.errorCount ? 'red' : '')),
        r.sample.length ? card('Preview (valid rows)', simpleTable([{ key: 'row', label: 'Row' }, { label: 'Type', render: (x) => TYPE_LABELS[x.type] }, { label: 'Question', render: (x) => plain(x.question, 100) }, { key: 'topic', label: 'Topic' }, { key: 'difficulty', label: 'Difficulty' }, { key: 'marks', label: 'Marks' }], r.sample)) : null,
        r.errors.length ? card('Problems (these rows are skipped)', simpleTable([{ key: 'row', label: 'Row' }, { key: 'field', label: 'Column' }, { key: 'message', label: 'Problem' }], r.errors)) : null,
        r.validRows ? h('div.page-actions', btn(`Confirm import of ${r.validRows} question(s)`, async () => { try { const c = await api.post(`/cbt/bank/import/${r.importId}/commit`); toast(`Imported ${c.imported} question(s)`); m.close(); done(); } catch (err) { fail(err); } }, { kind: 'primary' })) : h('p', { text: 'Fix the problems and upload again.' })]);
    } catch (err) { fail(err); }
  }, { kind: 'primary', ic: 'upload' })] });
}

// ───────── CBT analytics (class / subject / term) ─────────
export async function analytics(view, p, q) {
  const a = await academic();
  view.appendChild(pageHead('CBT Analytics', 'Class averages, pass rates, grades and topic performance across CBT examinations.'));
  const exList = (await api.get('/cbt/exams?status=all&pageSize=100')).items;
  const f = form([{ name: 'classId', label: 'Class', type: 'select', placeholder: 'All classes', options: a.classes.map((c) => ({ value: c.id, label: c.display_name })) }, { name: 'subjectId', label: 'Subject', type: 'select', placeholder: 'All subjects', options: a.subjects.map((s) => ({ value: s.id, label: s.name })) },
    { name: 'sessionId', label: 'Session', type: 'select', placeholder: 'All sessions', options: a.sessions.map((s) => ({ value: s.id, label: s.name })) }, { name: 'termId', label: 'Term', type: 'select', placeholder: 'All terms', options: a.sessions.flatMap((s) => s.terms.map((t) => ({ value: t.id, label: `${s.name} · ${t.name}` }))) },
    { name: 'examId', label: 'Examination', type: 'select', placeholder: 'All examinations', options: exList.map((x) => ({ value: x.id, label: x.title })) }], q);
  const box = h('div');
  const load = async () => {
    clear(box).appendChild(spinner());
    try {
      const v = f._values(); const d = await api.get('/cbt/analytics' + qs(v)); const s = d.summary; clear(box);
      if (!s.results) return box.appendChild(empty('No CBT results for these filters yet'));
      box.append(h('div.stats', stat('Examinations', s.exams, '', 'cbt'), stat('Results', s.results, '', 'users'), stat('Average', pctText(s.average), '', 'chart'), stat('Highest', pctText(s.highest), '', 'check'), stat('Lowest', pctText(s.lowest), '', 'activity'), stat('Pass rate', pctText(s.passRate), '', 'shield')),
        h('div.grid.g2', card('Grade distribution', h('div.kpi-row', donut(d.grades.map((g, i) => ({ label: g.grade, value: g.count, color: PALETTE[i % PALETTE.length] })), { title: 'Grades' }), h('div.legend', d.grades.map((g, i) => h('span', (() => { const x = h('i'); x.style.background = PALETTE[i % PALETTE.length]; return x; })(), `${g.grade} (${g.count})`))))),
          card('Topic performance', d.topics.length ? h('div.table-wrap', barChart(d.topics.slice(0, 12).map((t) => ({ label: t.topic, value: t.rate, tone: t.rate < 50 ? 'bad' : '' })), { title: 'Topic success rate', fmt: (x) => `${x}%`, threshold: 50 })) : empty('No topics tagged'))),
        card('Student performance', h('div.table-wrap', barChart(d.students.slice(0, 25).map((x) => ({ label: x.name, value: x.average, tone: x.average < 50 ? 'bad' : '' })), { title: 'Student averages', fmt: (x) => `${x}` }))),
        card('Examinations', simpleTable([{ key: 'title', label: 'Examination' }, { label: 'Subject', render: (x) => x.subject || '—' }, { label: 'Class', render: (x) => x.className || 'Any' }, { key: 'candidates', label: 'Results', cls: 'num' },
          { label: 'Average', render: (x) => pctText(x.average) }, { label: 'High / low', render: (x) => `${pctText(x.highest)} / ${pctText(x.lowest)}` }, { label: 'Pass rate', render: (x) => pctText(x.passRate) }, { label: '', render: (x) => h('a.btn.btn-sm', { href: `#/cbt/exam/${x.id}?tab=analytics`, text: 'Details' }) }], d.exams)),
        card('Students', simpleTable([{ label: '#', render: (x) => d.students.indexOf(x) + 1 }, { key: 'name', label: 'Student' }, { key: 'admissionNo', label: 'Adm. no' }, { key: 'exams', label: 'Exams', cls: 'num' }, { label: 'Average', render: (x) => pctText(x.average) }], d.students)));
    } catch (err) { clear(box); fail(err); }
  };
  f.addEventListener('change', load);
  view.append(card(null, f), box); load();
}

// ───────── CBT settings ─────────
export async function settings(view) {
  const d = await api.get('/cbt/settings'); const s = d.settings; const editable = can('settings.update', 'cbt.publish');
  view.appendChild(pageHead('CBT Settings', 'School-wide defaults for new examinations. Every setting can still be changed per examination.'));
  const f = form([{ section: 'Defaults for new examinations' }, { name: 'durationMinutes', label: 'Duration (minutes)', type: 'number' }, { name: 'passMark', label: 'Pass mark (%)', type: 'number' }, { name: 'maxAttempts', label: 'Maximum attempts', type: 'number' },
    { name: 'scoreComponent', label: 'Send scores to result sheet column', type: 'select', placeholder: 'Do not send by default', options: d.components.map((c) => ({ value: c.key, label: `${c.label} (max ${c.max})` })) },
    { name: 'scorePolicy', label: 'Multiple attempts', type: 'select', placeholder: false, options: [{ value: 'best', label: 'Best attempt counts' }, { value: 'latest', label: 'Latest attempt counts' }] },
    { name: 'shuffleQuestions', label: 'Randomise questions', type: 'checkbox' }, { name: 'shuffleOptions', label: 'Randomise options', type: 'checkbox' }, { name: 'allowBackNav', label: 'Allow back navigation', type: 'checkbox' },
    { name: 'allowReview', label: 'Review page before submission', type: 'checkbox' }, { name: 'autosave', label: 'Autosave', type: 'checkbox' }, { name: 'allowResume', label: 'Allow resume after connection loss', type: 'checkbox' },
    { name: 'fullscreen', label: 'Full-screen mode', type: 'checkbox' }, { name: 'showResult', label: 'Show result immediately', type: 'checkbox' }, { name: 'showAnswers', label: 'Show correct answers after release', type: 'checkbox' }],
  { durationMinutes: s.durationMinutes ?? 30, passMark: s.passMark ?? 50, maxAttempts: s.maxAttempts ?? 1, scoreComponent: s.scoreComponent || '', scorePolicy: s.scorePolicy || 'best', shuffleQuestions: s.shuffleQuestions ?? true, shuffleOptions: s.shuffleOptions ?? true,
    allowBackNav: s.allowBackNav ?? true, allowReview: s.allowReview ?? true, autosave: s.autosave ?? true, allowResume: s.allowResume ?? true, fullscreen: !!s.fullscreen, showResult: !!s.showResult, showAnswers: !!s.showAnswers });
  if (!editable) f.querySelectorAll('input,select').forEach((x) => { x.disabled = true; });
  view.append(h('div.grid.g2', card('Examination defaults', [f, editable ? h('div.page-actions', btn('Save defaults', async () => { const v = f._values(); try { await api.put('/cbt/settings', { ...v, scoreComponent: v.scoreComponent || null, maxAttempts: v.maxAttempts || 1 }); toast('CBT defaults saved'); } catch (err) { if (!f._error(err)) fail(err); } }, { kind: 'primary' })) : null]),
    card('How CBT connects to your results', h('ol', ['Build questions in the Question Bank (or import them from Excel).', 'Create an examination for a subject, class and term and choose which result-sheet column it feeds (e.g. Exam).', 'Candidates sit it on phones, tablets or computers — timing and marking happen on the server.',
      'Mark essays, then release results to students.', 'Click “Send to result sheet”: percentages are scaled to the column’s maximum (e.g. 87.5% → 52.5/60) and your existing grading, positions and approval workflow do the rest — broadsheets and report sheets update automatically.'].map((x) => h('li', { text: x }))))));
}

// ───────── attempt review / manual marking (staff) ─────────
export async function grade(view, p) {
  const d = await api.get(`/cbt/attempts/${p.id}/review`); const a = d.attempt;
  const inputs = [];
  const manual = d.items.filter((i) => i.manual);
  view.appendChild(pageHead(`${a.student} — attempt ${a.attemptNo}`, `${a.admissionNo} · ${a.status.replace('_', ' ')} · objective ${a.objectiveScore ?? 0}/${a.maxScore ?? 0}${a.score !== null && a.score !== undefined ? ` · final ${a.score}/${a.maxScore}` : ''}${a.focusLosses ? ` · left the exam window ${a.focusLosses}×` : ''}`,
    h('a.btn', { href: `#/cbt/exam/${a.examId}?tab=results`, text: '← Results' }), btn('Print', () => window.print(), { ic: 'printer' }),
    can('cbt.grade') && manual.length ? btn('Save marks', async () => { try { const r = await api.post(`/cbt/attempts/${a.id}/grade`, { grades: inputs.filter((x) => x.inp.value !== '').map((x) => ({ questionId: x.id, marks: Number(x.inp.value) })) }); toast(r.complete ? 'Marking complete — result finalised' : 'Marks saved'); clear(view); grade(view, p); } catch (err) { fail(err); } }, { kind: 'primary' }) : null));
  if (manual.length && a.needsManualGrading) view.appendChild(h('div.support-banner', icon('activity', 16), h('span', { text: `${manual.length} written answer(s) to mark. The result is finalised when every one has marks.` })));
  d.items.forEach((qq, i) => {
    let tail;
    if (qq.manual) {
      const inp = h('input.input.score-input', { type: 'number', min: 0, max: qq.marks, step: '0.5', value: qq.marks_awarded ?? '', disabled: !can('cbt.grade'), 'aria-label': `Marks for question ${i + 1}` }); inputs.push({ id: qq.id, inp });
      tail = h('div', h('div.answer-box', h('strong', { text: 'Answer: ' }), qq.text_answer ? renderRich(qq.text_answer) : h('em', { text: '(no answer)' })), qq.theory_guide ? h('p.muted', { text: `Marking guide: ${qq.theory_guide}` }) : null, h('label.inline', 'Marks ', inp, ` / ${Number(qq.marks)}`));
    } else {
      const chosen = qq.chosen || qq.chosen_many || qq.text_answer;
      tail = h('p', chosen ? h('span', 'Answered: ', h('strong', { text: chosen })) : h('em', { text: 'No answer ' }), ' ', qq.is_correct ? badge('correct', 'ok') : badge('wrong', 'danger'),
        h('span.muted', { text: `  Correct: ${qq.correct_option || (qq.answer_key ? (qq.answer_key.accepted || [qq.answer_key.value]).join(' / ') : '—')}` }), qq.flagged ? badge('flagged for review', 'warn') : null, qq.time_spent_seconds ? h('small.muted', { text: `  · ${qq.time_spent_seconds}s` }) : null);
    }
    view.appendChild(h('div.q', h('div.q-head', h('strong', { text: `${i + 1}.` }), h('span.badge.badge-info', { text: TYPE_LABELS[qq.type] }), h('span.muted', { text: `${Number(qq.marks)} mark(s)${qq.topic ? ` · ${qq.topic}` : ''}` })), renderRich(qq.text), tail));
  });
}
