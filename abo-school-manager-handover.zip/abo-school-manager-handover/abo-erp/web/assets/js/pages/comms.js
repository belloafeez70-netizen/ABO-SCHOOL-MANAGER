import { h, clear, icon } from '../core/dom.js';
import { api } from '../core/api.js';
import { can, session } from '../core/session.js';
import { pageHead, btn, formDialog, badge, card, toast, fail, confirmDialog, empty, modal } from '../core/ui.js';
import { ago, dateTime } from '../core/format.js';
import { academic } from './people.js';

// Announcements — the ONE place for school news (Newsletters were merged in on 11 Oct 2026). Managers can keep a draft,
// publish it, and share a notice with parents on WhatsApp (one message to a group, or parent by parent) and by email.
export async function announcements(view) {
  const manage = can('announcements.manage');
  const a = manage ? await academic() : null;
  const AUD = { all: 'Everyone', staff: 'All staff', teachers: 'Teachers', students: 'Students', parents: 'Parents' };
  view.appendChild(pageHead('Announcements', manage ? 'School news and notices — short notices or long letters (this replaces Newsletters). Post to everyone, a group or one class, then share with parents on WhatsApp or email.' : 'News and notices from your school.',
    manage ? btn('New announcement', async () => {
      const r = await formDialog({ title: 'New announcement', wide: true, fields: [{ name: 'title', label: 'Title', required: true, full: true }, { name: 'body', label: 'Message (a short notice or a full letter)', type: 'textarea', required: true, full: true, rows: 8, max: 60000 },
        { name: 'audience', label: 'Who should see it', type: 'select', placeholder: false, options: Object.entries(AUD).map(([value, label]) => ({ value, label })) },
        { name: 'classId', label: 'Only this class (optional)', type: 'select', options: a.classes.map((c) => ({ value: c.id, label: c.display_name })) }, { name: 'priority', label: 'Priority', type: 'select', placeholder: false, options: ['normal', 'important', 'urgent'] },
        { name: 'expiresAt', label: 'Hide after (optional)', type: 'date' }, { name: 'pinned', label: 'Pin to top', type: 'checkbox' }, { name: 'draft', label: 'Save as draft (only managers see it until you publish)', type: 'checkbox' }], values: { audience: 'all', priority: 'normal' },
      onSubmit: (v) => api.post('/announcements', { ...v, expiresAt: v.expiresAt ? new Date(v.expiresAt + 'T23:59:59').toISOString() : null }) });
      if (r) { toast(r && r.id ? 'Announcement saved' : 'Saved'); t.refresh(); if (r && r.id && manage) shareDialog(r.id); }
    }, { kind: 'primary', ic: 'megaphone' }) : null));
  const list = h('div');
  const bodyEl = (x) => {
    const long = x.body.length > 700;
    const p = h('p.prewrap', { text: long ? `${x.body.slice(0, 700).replace(/\s+\S*$/, '')}…` : x.body });
    if (!long) return p;
    const more = h('button.link', { type: 'button', text: 'Read the full notice', on: { click: () => { const open = more.dataset.open === '1'; p.textContent = open ? `${x.body.slice(0, 700).replace(/\s+\S*$/, '')}…` : x.body; more.textContent = open ? 'Read the full notice' : 'Show less'; more.dataset.open = open ? '' : '1'; } } });
    return [p, more];
  };
  const t = { refresh: async () => {
    const d = await api.get('/announcements?pageSize=50');
    clear(list).append(...(d.items.length ? d.items.map((x) => h(`section.card${x.read ? '' : '.unread-card'}${x.draft ? '.draft-card' : ''}`, h('div.card-head', h('div', h('h2', { text: x.title }), h('small.muted', { text: `${x.author || 'School'} · ${ago(x.publish_at)}${x.class_name ? ` · ${x.class_name}` : ''} · ${AUD[x.audience] || x.audience}` })),
      h('div.card-actions', x.draft ? badge('draft', 'warn') : null, x.source === 'newsletter' ? badge('letter', 'muted') : null, x.pinned ? badge('pinned', 'info') : null, x.priority !== 'normal' ? badge(x.priority) : null,
        manage && x.emailed_at ? badge(`emailed to ${x.emailed_count}`, 'ok') : null,
        !x.read && !x.draft ? btn('Mark read', async () => { await api.post(`/announcements/${x.id}/read`); t.refresh(); }, { kind: 'ghost' }) : null,
        manage && x.draft ? btn('Publish', async () => { try { await api.post(`/announcements/${x.id}/publish`); toast('Published'); t.refresh(); } catch (e) { fail(e); } }, { kind: 'primary' }) : null,
        manage && !x.draft ? btn('Share with parents', () => shareDialog(x.id), { ic: 'send' }) : null,
        manage ? btn('', async () => { if (await confirmDialog({ title: 'Delete announcement?', danger: true })) { await api.del(`/announcements/${x.id}`); t.refresh(); } }, { kind: 'ghost', ic: 'x', title: 'Delete' }) : null)),
    h('div.card-body', bodyEl(x)))) : [empty('No announcements yet')]));
  } };
  async function shareDialog(id) {
    let d; try { d = await api.get(`/announcements/${id}/share`); } catch (e) { return fail(e); }
    if (d.draft) return toast('Publish the announcement first, then share it.', 'err');
    const seen = new Set(JSON.parse(sessionStorage.getItem(`abo.wa.${id}`) || '[]'));
    const mark = (gid) => { seen.add(gid); sessionStorage.setItem(`abo.wa.${id}`, JSON.stringify([...seen])); };
    const copyBtn = btn('Copy message', async () => { try { await navigator.clipboard.writeText(d.text); toast('Message copied — paste it in WhatsApp, SMS or anywhere'); } catch { toast('Select the message and copy it', 'err'); } }, { ic: 'clipboard' });
    const whatsappAll = h('a.btn.btn-primary', { href: d.whatsappUrl, target: '_blank', rel: 'noopener noreferrer' }, icon('send', 16), h('span', { text: 'Share on WhatsApp (choose a group or broadcast list)' }));
    const search = h('input.input', { type: 'search', placeholder: 'Find a parent or child', 'aria-label': 'Find a parent or child' });
    const rows = h('tbody');
    const draw = () => {
      const q = search.value.trim().toLowerCase();
      clear(rows).append(...d.recipients.filter((r) => !q || `${r.name} ${r.children} ${r.classes}`.toLowerCase().includes(q)).map((r) => h('tr',
        h('td', h('strong', { text: r.name }), h('div.muted.small', { text: `${r.children || ''}${r.classes ? ` · ${r.classes}` : ''}` })),
        h('td', { text: r.phone || '—' }), h('td', { text: r.email || '—' }),
        h('td', r.whatsappUrl ? h(`a.btn.btn-sm${seen.has(r.id) ? '.done' : ''}`, { href: r.whatsappUrl, target: '_blank', rel: 'noopener noreferrer', on: { click: (ev) => { mark(r.id); ev.currentTarget.classList.add('done'); ev.currentTarget.lastChild.textContent = 'Opened'; } } }, icon('send', 14), h('span', { text: seen.has(r.id) ? 'Opened' : 'WhatsApp' })) : h('span.muted', { text: 'no usable number' })))));
    };
    search.addEventListener('input', draw); draw();
    const again = h('input', { type: 'checkbox', 'aria-label': 'Send again' });
    const emailInfo = h('p.muted', { text: d.emailedAt ? `Already emailed to ${d.emailedCount} parent(s) on ${dateTime(d.emailedAt)}.` : `${d.counts.withEmail} of ${d.counts.parents} parent(s) have an email address.` });
    const emailBtn = btn(`Email ${d.counts.withEmail} parent(s)`, async () => {
      emailBtn.disabled = true;
      try { const r = await api.post(`/announcements/${id}/email`, { again: again.checked }); toast(`Email queued for ${r.queued} parent(s)${r.withoutEmail ? ` · ${r.withoutEmail} have no email` : ''}`); emailInfo.textContent = `Emailed to ${r.queued} parent(s) just now.`; t.refresh(); }
      catch (e) { fail(e); } finally { emailBtn.disabled = false; }
    }, { kind: 'primary', ic: 'mail', disabled: !d.counts.withEmail });
    const body = h('div.share-box',
      !d.forParents ? h('div.alert.alert-warn', h('span', { text: `This notice is for ${AUD[d.audience] || d.audience} only, so it is not sent to parents. You can still copy the message.` })) : null,
      h('h3', { text: '1. WhatsApp — one message to a group' }),
      h('p.muted', { text: 'Opens WhatsApp with the message ready. Pick your parents’ group or broadcast list and press send.' }),
      h('pre.share-preview', { text: d.text }), h('div.page-actions', whatsappAll, copyBtn),
      d.forParents ? [
        h('h3', { text: `2. WhatsApp — parent by parent (${d.counts.withWhatsApp} with a phone number)` }),
        !d.canSeeContacts ? h('p.muted', { text: 'You need permission to see parents’ contacts for this list.' })
          : d.recipients.length ? [h('p.muted', { text: 'Each button opens a chat with that parent and the message ready. Buttons you used turn green.' }), search, h('div.table-wrap.share-list', h('table.table', h('thead', h('tr', h('th', { text: 'Parent / child' }), h('th', { text: 'Phone' }), h('th', { text: 'Email' }), h('th', { text: '' }))), rows))]
            : h('p.muted', { text: d.className ? `No parents are linked to learners in ${d.className} yet.` : 'No parents are linked to learners yet. Add them under Students › Parents & Guardians.' }),
        h('h3', { text: '3. Email every parent' }), emailInfo,
        d.emailedAt ? h('label.check', again, h('span', { text: 'Send again (only if parents need it a second time)' })) : null,
        h('div.page-actions', emailBtn),
        h('p.muted.small', { text: 'Emails are sent by the school’s email service in the background. Each parent gets their own email; addresses are never shown to other parents.' })] : null);
    modal({ title: `Share: ${d.title}`, body, wide: true });
  }
  view.appendChild(list); t.refresh().catch(fail);
}
export async function messages(view) {
  const d = await api.get('/messages/threads');
  view.appendChild(pageHead('Messages', session.me.portal === 'staff' ? 'Private conversations with colleagues, students and parents.' : 'Message your child’s teachers and the school leadership.',
    btn('New message', async () => {
      const c = await api.get('/messages/contacts');
      const r = await formDialog({ title: 'New message', fields: [{ name: 'recipientIds', label: 'To', type: 'multiselect', full: true, options: c.items.map((x) => ({ value: x.id, label: `${x.full_name} (${x.roles})` })) }, { name: 'subject', label: 'Subject', required: true, full: true }, { name: 'body', label: 'Message', type: 'textarea', required: true, full: true }],
        onSubmit: (v) => api.post('/messages/threads', v) });
      if (r) location.hash = `#/messages/${r.id}`;
    }, { kind: 'primary', ic: 'mail' })));
  view.appendChild(card(null, d.items.length ? h('div.list', d.items.map((x) => h('a.list-item', { href: `#/messages/${x.id}` }, h('div', h('strong', { text: x.subject }), h('div.muted', { text: `${x.with_names || ''} — ${x.preview || ''}` })), h('div', x.unread ? badge('new', 'info') : null, h('small.muted', { text: ` ${ago(x.last_message_at)}` }))))) : empty('No conversations yet')));
}
export async function thread(view, p) {
  const d = await api.get(`/messages/threads/${p.id}`);
  const box = h('div.list', d.messages.map((m) => h(`div.list-item${m.mine ? '.mine' : ''}`, h('div', h('strong', { text: m.sender }), h('p.prewrap', { text: m.body })), h('small.muted', { text: dateTime(m.created_at) }))));
  const ta = h('textarea.input', { rows: 3, placeholder: 'Write a reply…', 'aria-label': 'Reply' });
  view.append(pageHead(d.thread.subject, `Started ${dateTime(d.thread.created_at)}`, h('a.btn', { href: '#/messages', text: '← All messages' })), card(null, box),
    card(null, [ta, h('div.page-actions', btn('Send', async () => { if (!ta.value.trim()) return; try { await api.post(`/messages/threads/${p.id}`, { body: ta.value.trim() }); clear(view); thread(view, p); } catch (e) { fail(e); } }, { kind: 'primary' }))]));
}
// Newsletters were merged into Announcements (11 Oct 2026). Old bookmarks land on Announcements.
export async function newsletters() { location.replace('#/announcements'); }
