import { h, clear } from '../core/dom.js';
import { api, qs } from '../core/api.js';
import { pageHead, btn, formDialog, badge, card, toast, fail, confirmDialog, dataTable, stat, simpleTable, modal } from '../core/ui.js';
import { date, dateTime, cap } from '../core/format.js';
import { can } from '../core/session.js';

export async function schools(view, p, q = {}) {
  const pendingView = q.status === 'pending';
  view.appendChild(pageHead(pendingView ? 'Pending approvals' : 'Schools', pendingView ? 'Newly registered schools. Approve a school to grant its users sign-in; the owner receives the school’s own sign-in link (with its name and logo).' : 'Every tenant on the platform. School data stays private — use a time-limited, audited support view when a school asks for help.',
    pendingView ? h('a.btn', { href: '#/', text: 'All schools' }) : h('a.btn', { href: '#/?status=pending', text: 'Pending approvals' })));
  // owner's request (12 Oct 2026): demos live ONLY in the platform owner's interface — offered right on the home page
  if (!pendingView && can('platform.billing.manage')) {
    view.appendChild(h('section.card.demo-panel', h('div.card-body.demo-panel-body',
      h('div', h('span.demo-pill', { text: 'DEMO' }), h('h2', { text: 'Give a demo' }),
        h('p.muted', { text: 'Show a school the app with sample data: make a demo link, open it on your phone or laptop, or send it on WhatsApp. Each demo lasts 5 minutes and is wiped afterwards. Nobody can open a demo without your link.' })),
      h('div.page-actions', h('a.btn.btn-primary', { href: '#/platform/demo?new=1' }, 'Make a demo link'), h('a.btn', { href: '#/platform/demo' }, 'My demo links')))));
  }
  const portalLink = (x) => `${location.origin}/#/s/${x.slug}`;
  const approve = async (x) => {
    const reason = await confirmDialog({ title: `Approve ${x.name}?`, message: `${x.email_verified_at ? 'The owner’s e-mail is verified.' : 'Warning: the owner has NOT verified their e-mail yet.'} Users of this school will be able to sign in, and the owner is e-mailed the school sign-in link.`, confirmLabel: 'Approve school', reason: true });
    if (!reason) return;
    try {
      const r = await api.patch(`/platform/schools/${x.id}`, { status: 'active', reason });
      const link = r.portalUrl || portalLink(x);
      modal({ title: `${x.name} approved`, body: h('div', h('p', { text: 'The school can now sign in. Its own sign-in page shows the school name and logo:' }),
        h('div.copy-row', h('input.input', { value: link, readonly: true, 'aria-label': 'Sign-in link' }), btn('Copy', async () => { try { await navigator.clipboard.writeText(link); toast('Copied'); } catch { /* */ } })),
        h('p.muted', { text: 'The owner has been e-mailed this link and a notification to upload their logo.' })) });
      t.refresh();
    } catch (e) { fail(e); }
  };
  const t = dataTable({ columns: [{ label: 'School', render: (x) => h('div', h('strong', { text: x.name }), h('div.muted.mono', { text: x.slug })) }, { label: 'Owner e-mail', render: (x) => h('div', h('span', { text: x.email || '—' }), h('div', x.email_verified_at ? badge('verified', 'ok') : badge('not verified', 'warn'))) },
    { label: 'Type', render: (x) => cap(x.school_type) }, { label: 'Students', cls: 'num', render: (x) => x.students ?? 0 }, { label: 'Users', cls: 'num', render: (x) => x.users ?? 0 }, { label: 'Online', cls: 'num', render: (x) => x.active_sessions ?? 0 },
    { label: 'Logo', render: (x) => (x.has_logo ? badge('yes', 'ok') : badge('no', 'muted')) }, { label: 'Status', render: (x) => badge(x.status === 'pending' ? 'awaiting approval' : x.status, x.status === 'pending' ? 'warn' : undefined) },
    { label: 'Joined', render: (x) => date(x.created_at) },
    { label: '', render: (x) => h('div.page-actions',
      x.status === 'pending' ? btn('Approve', () => approve(x), { kind: 'primary' }) : null,
      x.status === 'active' ? btn('Sign-in link', () => modal({ title: `${x.name} — sign-in page`, body: h('div.copy-row', h('input.input', { value: portalLink(x), readonly: true, 'aria-label': 'Sign-in link' }), h('a.btn', { href: `/#/s/${x.slug}`, target: '_blank', rel: 'noopener', text: 'Open' })) }), { kind: 'ghost' }) : null,
      x.status !== 'pending' ? btn('Support view', async () => { const r = await formDialog({ title: `Support view · ${x.name}`, intro: 'Read-only, time-limited and written to BOTH the platform and the school audit logs.', fields: [{ name: 'reason', label: 'Ticket / reason', required: true, full: true }, { name: 'minutes', label: 'Minutes', type: 'number' }], values: { minutes: 30 }, onSubmit: (v) => api.post('/platform/support', { schoolId: x.id, reason: v.reason, minutes: v.minutes || 30 }) }); if (r) { location.hash = '#/'; location.reload(); } }, { kind: 'ghost' }) : null,
      x.status !== 'pending' ? btn(x.status === 'suspended' ? 'Activate' : 'Suspend', async () => { const reason = await confirmDialog({ title: `${x.status === 'suspended' ? 'Activate' : 'Suspend'} ${x.name}?`, message: x.status === 'suspended' ? 'Users will be able to sign in again.' : 'All sessions are revoked immediately and the school sign-in page is taken offline.', danger: x.status !== 'suspended', reason: true }); if (reason) { try { await api.patch(`/platform/schools/${x.id}`, { status: x.status === 'suspended' ? 'active' : 'suspended', reason }); t.refresh(); } catch (e) { fail(e); } } }, { kind: 'ghost' }) : null) }],
  filters: pendingView ? [] : [{ name: 'status', label: 'Status', placeholder: 'All', options: [{ value: 'pending', label: 'Awaiting approval' }, { value: 'active', label: 'Active' }, { value: 'suspended', label: 'Suspended' }] }],
  load: (o) => api.get('/platform/schools' + qs(pendingView ? { ...o, status: 'pending' } : o)), empty: pendingView ? 'No schools are waiting for approval' : 'No schools yet' });
  view.appendChild(t);
}
export async function security(view) {
  view.appendChild(pageHead('Platform security events', 'Credential stuffing, lockouts, bad webhook signatures, CSRF blocks and support access across all schools.'));
  view.appendChild(dataTable({ columns: [{ label: 'Time', render: (x) => dateTime(x.created_at) }, { label: 'Event', render: (x) => cap(x.kind) }, { label: 'Severity', render: (x) => badge(x.severity) }, { key: 'school', label: 'School' }, { key: 'ip', label: 'IP' }, { label: 'Details', render: (x) => h('small.mono', { text: JSON.stringify(x.detail).slice(0, 120) }) }],
    filters: [{ name: 'severity', label: 'Severity', placeholder: 'All', options: ['critical', 'high', 'medium', 'low', 'info'] }], load: (o) => api.get('/platform/security-events' + qs(o)), pageSize: 50 }));
}
export async function health(view) {
  const d = await api.get('/platform/health');
  const n = (arr, k, v) => (arr.find((x) => String(x[k]) === String(v)) || { n: 0 }).n;
  view.appendChild(pageHead('System health', 'Last 24 hours.', btn('Refresh', () => { clear(view); health(view); }, { ic: 'activity' })));
  view.appendChild(h('div.stats', stat('Schools', d.totals.schools, `${d.totals.active} active`, 'building'), stat('Uptime', `${Math.floor(d.uptimeSeconds / 3600)}h`, `${d.memoryMb} MB RSS`, 'clock'), stat('DB size', `${Math.round(d.db.bytes / 1048576)} MB`, `${d.db.connections} connections`, 'layers'),
    stat('Sign-ins', n(d.logins, 'success', true), `${n(d.logins, 'success', false)} failed`, 'key', n(d.logins, 'success', false) > 50 ? 'red' : ''), stat('Failed jobs', n(d.jobs, 'status', 'failed'), `${n(d.jobs, 'status', 'done')} done`, 'activity', n(d.jobs, 'status', 'failed') ? 'red' : ''),
    stat('High-severity events', n(d.security, 'severity', 'high') + n(d.security, 'severity', 'critical'), '', 'shield', n(d.security, 'severity', 'high') ? 'red' : '')));
  view.appendChild(h('div.grid.g2', card('Jobs', simpleTable([{ key: 'status', label: 'Status' }, { key: 'n', label: 'Count' }], d.jobs, 'No jobs')), card('Email outbox', simpleTable([{ key: 'status', label: 'Status' }, { key: 'n', label: 'Count' }], d.mail, 'No email'))));
  void toast;
}
