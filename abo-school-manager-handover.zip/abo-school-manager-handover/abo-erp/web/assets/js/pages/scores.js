// Scores & Results menu: CA / Exam score entry, Result Processing, Result Approval, Result Publishing.
import { h, clear, append } from '../core/dom.js';
import { api, qs } from '../core/api.js';
import { can } from '../core/session.js';
import { pageHead, btn, badge, card, toast, fail, confirmDialog, simpleTable, empty, spinner, stat } from '../core/ui.js';
import { dateTime, ago } from '../core/format.js';
import { academic } from './people.js';
import { pickers, termLabel } from './shared.js';

function entryPage(focus) {
  const title = focus === 'ca' ? 'CA Score Entry' : 'Exam Score Entry';
  const what = focus === 'ca' ? 'continuous assessment (CA1, CA2 …)' : 'examination';
  return async (view, p, q) => {
    const a = await academic();
    view.appendChild(pageHead(title, `Enter ${what} scores for the subjects allocated to you. Totals, grades and positions are computed on the server.`));
    if (!a.classes.length) return view.appendChild(empty('No classes yet', 'Set up classes and subject allocation under Academics.'));
    const pk = pickers(a, q, { term: true, cls: true });
    const box = h('div');
    const load = async ({ termId, classId }) => {
      clear(box).appendChild(spinner());
      try {
        const r = await api.get(`/results/sheets${qs({ termId, classId })}`);
        const mine = r.items.filter((x) => x.can_enter);
        clear(box).appendChild(card(`${mine.length} subject(s) you can enter · ${r.classSize} learners`, simpleTable([
          { key: 'subject', label: 'Subject' }, { label: 'Teacher', render: (x) => x.teacher || '—' }, { label: 'Status', render: (x) => badge(x.status) },
          { label: 'Scored', render: (x) => `${x.scored || 0}/${r.classSize}` },
          { label: '', render: (x) => (x.sheet_id
            ? h('a.btn.btn-sm.btn-primary', { href: `#/results/sheet/${x.sheet_id}?focus=${focus}`, text: x.status === 'draft' ? `Enter ${focus === 'ca' ? 'CA' : 'exam'} scores` : 'View' })
            : btn(`Start & enter ${focus === 'ca' ? 'CA' : 'exam'}`, async () => { try { const s = await api.post('/results/sheets', { termId, classId, subjectId: x.subject_id }); location.hash = `#/results/sheet/${s.id}?focus=${focus}`; } catch (e) { fail(e); } }, { kind: 'primary' })) }],
        mine, 'None of this class’s subjects are allocated to you. Ask the exam officer or check Academics › Subject Allocation.')));
      } catch (e) { clear(box); fail(e); }
    };
    pk.on(load);
    view.append(card(null, pk.el), box);
    load(pk.get());
  };
}
export const caEntry = entryPage('ca');
export const examEntry = entryPage('exam');

const bar = (done, total) => { const d = h('div'); d.style.width = `${total ? Math.round(done / total * 100) : 0}%`; return h('div.progress-mini', { title: `${done}/${total}` }, d); };

export async function processing(view, p, q) {
  const a = await academic();
  view.appendChild(pageHead('Result Processing', 'Compute totals, averages, grades and class positions from the scores entered so far. Processing is safe to repeat and never publishes anything.'));
  const pk = pickers(a, q, { term: true });
  const box = h('div');
  const load = async ({ termId }) => {
    clear(box).appendChild(spinner());
    try {
      const r = await api.get(`/results/overview${qs({ termId })}`);
      const tot = r.items.reduce((o, x) => { o.subjects += x.subjects; o.done += x.approved + x.published; o.pending += x.draft + x.submitted + x.reviewed; return o; }, { subjects: 0, done: 0, pending: 0 });
      append(clear(box), [h('div.stats', stat('Classes', r.items.length, termLabel(a, termId), 'grid'), stat('Subject sheets approved', `${tot.done}/${tot.subjects}`, `${tot.pending} still in progress`, 'check'),
        stat('Processed classes', r.items.filter((x) => x.processed_at).length, 'have computed positions', 'activity')),
      card('Classes', simpleTable([{ key: 'display_name', label: 'Class' }, { key: 'students', label: 'Learners', cls: 'num' },
        { label: 'Approved', render: (x) => h('div.kpi-row', bar(x.approved + x.published, x.subjects), h('small.muted', { text: `${x.approved + x.published}/${x.subjects}` })) },
        { label: 'In progress', render: (x) => `${x.draft} draft · ${x.submitted + x.reviewed} awaiting` }, { label: 'Not started', render: (x) => x.not_started || '—' },
        { label: 'Last processed', render: (x) => (x.processed_at ? ago(x.processed_at) : '—') }, { label: 'Status', render: (x) => (x.is_published ? badge('published', 'ok') : x.ready_to_publish ? badge('ready to publish', 'info') : badge('in progress', 'warn')) },
        { label: '', render: (x) => h('div.page-actions', !x.is_published && can('results.approve', 'results.publish', 'results.enter_any') ? btn('Process', async () => { try { const res = await api.post('/results/process', { termId, classId: x.id }); toast(`${x.display_name}: ${res.items[0].withResults ?? 0} learners processed`); load({ termId }); } catch (e) { fail(e); } }, { kind: 'ghost' }) : null,
          h('a.btn.btn-sm.btn-ghost', { href: `#/broadsheet?termId=${termId}&classId=${x.id}`, text: 'Broadsheet' })) }], r.items, 'No classes')),
      can('results.approve', 'results.publish', 'results.enter_any') ? h('div.page-actions', btn('Process all classes', async () => {
        try { const res = await api.post('/results/process', { termId }); toast(`Processed ${res.items.filter((x) => !x.skipped).length} class(es); ${res.items.filter((x) => x.skipped).length} already published`); load({ termId }); } catch (e) { fail(e); }
      }, { kind: 'primary', ic: 'activity' })) : null]);
    } catch (e) { clear(box); fail(e); }
  };
  pk.on(load); view.append(card(null, pk.el), box); load(pk.get());
}

export async function approval(view, p, q) {
  const a = await academic();
  view.appendChild(pageHead('Result Approval', 'Subject sheets submitted by teachers. A different person must review and approve (four-eyes rule); approved sheets are locked.'));
  const pk = pickers(a, q, { term: true });
  let status = q.status || 'awaiting';
  const tabsEl = h('div.tabs', { role: 'tablist' });
  const box = h('div');
  const load = async () => {
    const { termId } = pk.get();
    clear(tabsEl).append(...[['awaiting', 'Awaiting action'], ['draft', 'Still with teachers'], ['approved', 'Approved'], ['published', 'Published']].map(([k, l]) => h(`button.tab${status === k ? '.active' : ''}`, { type: 'button', text: l, on: { click: () => { status = k; load(); } } })));
    clear(box).appendChild(spinner());
    try {
      const r = await api.get(`/results/queue${qs({ termId, status })}`);
      clear(box).appendChild(card(`${r.items.length} sheet(s)${r.requireReview && status === 'awaiting' ? ' · review step required before approval' : ''}`, simpleTable([
        { key: 'class_name', label: 'Class' }, { key: 'subject', label: 'Subject' }, { label: 'Teacher', render: (x) => x.teacher || x.submitted_by_name || '—' },
        { label: 'Submitted', render: (x) => (x.submitted_at ? dateTime(x.submitted_at) : '—') }, { label: 'Scored', render: (x) => x.scored }, { label: 'Status', render: (x) => badge(x.status) },
        { label: '', render: (x) => h('div.page-actions', h('a.btn.btn-sm', { href: `#/results/sheet/${x.id}`, text: 'Open' }),
          x.can_review ? btn('Mark reviewed', async () => { try { await api.post(`/results/sheets/${x.id}/review`, { action: 'review' }); toast('Reviewed'); load(); } catch (e) { fail(e); } }, { kind: 'primary' }) : null,
          x.can_approve ? btn('Approve & lock', async () => { if (await confirmDialog({ title: `Approve ${x.subject} · ${x.class_name}?`, message: 'Scores become locked. Later changes need a correction request.', confirmLabel: 'Approve' })) { try { await api.post(`/results/sheets/${x.id}/review`, { action: 'approve' }); toast('Approved & locked'); load(); } catch (e) { fail(e); } } }, { kind: 'primary' }) : null,
          (x.can_review || x.can_approve) ? btn('Return', async () => { const note = await confirmDialog({ title: 'Return to teacher', message: 'Explain what needs to change.', reason: true, confirmLabel: 'Return' }); if (note) { try { await api.post(`/results/sheets/${x.id}/review`, { action: 'return', note }); toast('Returned to teacher'); load(); } catch (e) { fail(e); } } }, { kind: 'ghost' }) : null,
          x.mine ? badge('you submitted this', 'muted') : null) }], r.items, status === 'awaiting' ? 'Nothing is waiting for your action.' : 'No sheets in this state')));
    } catch (e) { clear(box); fail(e); }
  };
  pk.on(load); view.append(card(null, pk.el), tabsEl, box); load();
}

export async function publishing(view, p, q) {
  const a = await academic();
  view.appendChild(pageHead('Result Publishing', 'Publish a class when every subject is approved. Students and parents are notified, positions are final and a broadsheet version is archived.'));
  const pk = pickers(a, q, { term: true });
  const box = h('div');
  const load = async ({ termId }) => {
    clear(box).appendChild(spinner());
    try {
      const r = await api.get(`/results/overview${qs({ termId })}`);
      const ready = r.items.filter((x) => x.ready_to_publish && !x.is_published);
      clear(box).append(h('div.stats', stat('Ready to publish', ready.length, 'all subjects approved', 'check'), stat('Published', r.items.filter((x) => x.is_published).length, termLabel(a, termId), 'book'), stat('Not ready', r.items.filter((x) => !x.ready_to_publish && !x.is_published).length, 'subjects pending', 'clock')),
        card(null, simpleTable([{ key: 'display_name', label: 'Class' }, { key: 'students', label: 'Learners', cls: 'num' }, { label: 'Subjects approved', render: (x) => `${x.approved + x.published}/${x.subjects}` },
          { label: 'Blocking', render: (x) => (x.is_published ? '—' : [x.not_started ? `${x.not_started} not started` : null, x.draft ? `${x.draft} draft` : null, x.submitted + x.reviewed ? `${x.submitted + x.reviewed} awaiting approval` : null].filter(Boolean).join(' · ') || '—') },
          { label: 'Status', render: (x) => (x.is_published ? badge('published', 'ok') : x.ready_to_publish ? badge('ready', 'info') : badge('not ready', 'warn')) },
          { label: '', render: (x) => h('div.page-actions', h('a.btn.btn-sm.btn-ghost', { href: `#/broadsheet?termId=${termId}&classId=${x.id}`, text: 'Preview' }),
            !x.is_published && can('results.publish') ? btn('Publish', async () => {
              if (!(await confirmDialog({ title: `Publish ${x.display_name}?`, message: 'Students and parents will see results, positions are computed, and scores become locked (changes need a correction request).', confirmLabel: 'Publish' }))) return;
              try { const res = await api.post('/results/publish', { termId, classId: x.id }); toast(`Published for ${res.students} learners (broadsheet v${res.broadsheetVersion})`); load({ termId }); } catch (e) { fail(e); }
            }, { kind: 'primary', disabled: !x.ready_to_publish }) : null) }], r.items, 'No classes')));
    } catch (e) { clear(box); fail(e); }
  };
  pk.on(load); view.append(card(null, pk.el), box); load(pk.get());
}
