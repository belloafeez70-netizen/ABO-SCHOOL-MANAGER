// Study materials, live classes and the class monitor (Phase 6, part 3). The server decides who may share with which
// class and what pupils/parents may see; this page only reflects what the API allows.
import { h, clear, icon } from '../core/dom.js';
import { api, qs } from '../core/api.js';
import { can, portal } from '../core/session.js';
import { pageHead, btn, badge, card, toast, fail, confirmDialog, formDialog, simpleTable, stat, spinner, errMsg, empty, tabs } from '../core/ui.js';
import { date, dateTime } from '../core/format.js';
import { fileUrl } from '../core/config.js';

const learner = () => ['student', 'parent'].includes(portal());
const mayShare = () => can('materials.create', 'materials.manage');
const size = (b) => (b > 1048576 ? `${(b / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1024))} KB`);
let optsCache = null;
const options = async () => (optsCache = optsCache || await api.get('/materials/options'));

// ───────────────────────── study materials ─────────────────────────
export async function list(view) {
  view.appendChild(pageHead('Study Materials', learner() ? 'Notes, worksheets, links and videos your teachers shared with your class.' : 'Share notes, worksheets, links and videos with a class. Pupils and their parents see them on their own page.',
    mayShare() ? btn('Share a link or video', () => linkForm(load), { kind: 'primary', ic: 'plus' }) : null, mayShare() ? btn('Upload a file', () => fileForm(load), { ic: 'upload' }) : null,
    h('a.btn', { href: '#/live-classes', text: 'Live classes' })));
  const box = h('div'); view.appendChild(box);
  async function load() {
    clear(box).appendChild(spinner());
    try {
      const r = await api.get('/materials');
      if (!r.items.length) { clear(box).appendChild(empty(learner() ? 'Nothing shared with your class yet' : 'Nothing shared yet', mayShare() ? 'Use “Share a link or video” or “Upload a file”.' : undefined)); return; }
      const groups = new Map();
      for (const m of r.items) { const k = learner() ? (m.subject || 'General') : m.class_name; if (!groups.has(k)) groups.set(k, []); groups.get(k).push(m); }
      clear(box).append(...[...groups].map(([k, items]) => card(k, h('ul.mat-list', items.map((m) => h('li.mat-item',
        h('span.mat-kind', { 'aria-hidden': 'true' }, icon(m.kind === 'file' ? 'file' : m.kind === 'video' ? 'cbt' : 'paperclip', 18)),
        h('div.mat-body', h('strong', { text: m.title }), ' ', !m.published ? badge('hidden from pupils', 'muted') : null,
          h('div.muted', { text: [learner() ? m.class_name : m.subject, m.kind === 'video' ? `Video on ${m.video}` : m.kind === 'file' ? `${m.file_name} · ${size(m.file_size)}` : new URL(m.url).hostname, `shared by ${m.shared_by || '—'}`, date(m.created_at)].filter(Boolean).join(' · ') }),
          m.description ? h('div', { text: m.description }) : null),
        h('div.mat-act', m.kind === 'file' ? h('a.btn', { href: fileUrl(m.file_id), target: '_blank', rel: 'noopener', text: 'Open' }) : h('a.btn', { href: m.url, target: '_blank', rel: 'noopener noreferrer', text: m.kind === 'video' ? 'Watch' : 'Open link' }),
          m.canDelete ? btn('Remove', async () => { if (!(await confirmDialog({ title: 'Remove this?', message: m.title, confirmLabel: 'Remove', danger: true }))) return; try { await api.del(`/materials/${m.id}`); toast('Removed'); load(); } catch (e) { fail(e); } }, { kind: 'ghost' }) : null)))))));
    } catch (e) { clear(box).appendChild(h('p.muted', { text: errMsg(e) })); }
  }
  await load();
}
const classField = (o) => ({ name: 'classId', label: 'Class', type: 'select', required: true, options: o.classes.map((c) => ({ value: c.id, label: c.display_name })) });
const subjectField = (o) => ({ name: 'subjectId', label: 'Subject (optional)', type: 'select', placeholder: 'Any subject', options: o.subjects.map((s) => ({ value: s.id, label: s.name })) });
async function linkForm(done) {
  const o = await options();
  if (!o.classes.length) { toast('You are not assigned to any class yet.', 'err'); return; }
  const ok = await formDialog({ title: 'Share a link or video', intro: 'Paste a link that starts with https:// (for example a YouTube video or a Google Drive file).',
    fields: [classField(o), subjectField(o), { name: 'title', label: 'Title', required: true, max: 160, full: true }, { name: 'kind', label: 'Type', type: 'select', placeholder: false, options: [{ value: 'video', label: 'Video' }, { value: 'link', label: 'Link' }] },
      { name: 'url', label: 'Link (https://…)', required: true, max: 500, full: true }, { name: 'description', label: 'Note for pupils (optional)', type: 'textarea', max: 2000, full: true },
      { name: 'published', label: 'Pupils can see it now', type: 'checkbox' }],
    values: { kind: 'video', published: true },
    onSubmit: (v) => api.post('/materials', { classId: v.classId, subjectId: v.subjectId || null, title: v.title, kind: v.kind, url: v.url, description: v.description || null, published: !!v.published }) });
  if (ok) { toast('Shared with the class'); done(); }
}
async function fileForm(done) {
  const o = await options();
  if (!o.classes.length) { toast('You are not assigned to any class yet.', 'err'); return; }
  const ok = await formDialog({ title: 'Upload a file', intro: 'PDF, Word, Excel, PowerPoint or a picture. The file is checked before it is saved.',
    fields: [classField(o), subjectField(o), { name: 'title', label: 'Title', required: true, max: 160, full: true }, { name: 'description', label: 'Note for pupils (optional)', type: 'textarea', max: 2000, full: true },
      { name: 'file', label: 'File', type: 'file', accept: '.pdf,.docx,.xlsx,.pptx,image/png,image/jpeg,image/webp', required: true }],
    onSubmit: (v) => {
      if (!v.file) { const e = new Error('Choose a file.'); e.details = { field: 'file' }; throw e; }
      const fd = new FormData(); fd.append('classId', v.classId || ''); fd.append('subjectId', v.subjectId || ''); fd.append('title', v.title || ''); fd.append('description', v.description || ''); fd.append('file', v.file);
      return api.post('/materials/file', fd);
    } });
  if (ok) { toast('File shared with the class'); done(); }
}

// ───────────────────────── live classes ─────────────────────────
export async function live(view) {
  view.appendChild(pageHead('Live Classes', learner() ? 'Online lessons for your class. The Join button opens 15 minutes before the start.' : 'Schedule online lessons (Google Meet, Zoom, Teams …). Pupils and parents see them on their own page.',
    mayShare() ? btn('Schedule a live class', () => liveForm(() => load(false)), { kind: 'primary', ic: 'plus' }) : null, h('a.btn', { href: '#/materials', text: 'Study materials' })));
  const box = h('div');
  view.appendChild(tabs([{ key: 'up', label: 'Coming up' }, { key: 'past', label: 'Past' }], (k) => load(k === 'past'), 'up'));
  view.appendChild(box);
  async function load(past) {
    clear(box).appendChild(spinner());
    try {
      const r = await api.get(`/live-classes${qs({ past: past || undefined })}`);
      clear(box).appendChild(card(null, simpleTable([{ label: 'When', render: (l) => h('div', h('div', { text: dateTime(l.starts_at) }), h('small.muted', { text: `${l.duration_min} minutes` })) },
        { label: 'Lesson', render: (l) => h('div', h('strong', { text: l.title }), h('div.muted', { text: [l.class_name, l.subject, l.teacher].filter(Boolean).join(' · ') }), l.note ? h('div', { text: l.note }) : null) },
        { label: 'Status', render: (l) => (past ? badge('ended', 'muted') : l.live_now ? badge('live now', 'ok') : l.joinable ? badge('starting soon', 'info') : badge('scheduled', 'muted')) },
        { label: '', render: (l) => h('span', !past && l.join_url ? h('a.btn.btn-primary', { href: l.join_url, target: '_blank', rel: 'noopener noreferrer', text: 'Join' }) : !past ? h('small.muted', { text: `Join opens ${r.joinEarlyMinutes} min before` }) : null,
          !past && l.canCancel ? btn('Cancel', async () => { if (!(await confirmDialog({ title: 'Cancel this live class?', message: l.title, confirmLabel: 'Cancel class', danger: true }))) return; try { await api.post(`/live-classes/${l.id}/cancel`); toast('Cancelled'); load(false); } catch (e) { fail(e); } }, { kind: 'ghost' }) : null) }],
      r.items, past ? 'No past live classes' : 'No live classes coming up')));
    } catch (e) { clear(box).appendChild(h('p.muted', { text: errMsg(e) })); }
  }
  await load(false);
}
async function liveForm(done) {
  const o = await options();
  if (!o.classes.length) { toast('You are not assigned to any class yet.', 'err'); return; }
  const d = new Date(Date.now() + 3600e3); d.setMinutes(0, 0, 0);
  const local = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}T${String(d.getHours()).padStart(2, '0')}:00`;
  const ok = await formDialog({ title: 'Schedule a live class', intro: 'Create the meeting in Google Meet, Zoom or Teams first, then paste its link here.',
    fields: [classField(o), subjectField(o), { name: 'title', label: 'Lesson title', required: true, max: 160, full: true }, { name: 'startsAt', label: 'Starts', type: 'datetime-local', required: true },
      { name: 'durationMin', label: 'Minutes', type: 'number', min: 5, maxv: 480, step: 5, required: true }, { name: 'joinUrl', label: 'Meeting link (https://…)', required: true, max: 500, full: true },
      { name: 'note', label: 'Note for pupils (optional)', type: 'textarea', max: 1000, full: true }],
    values: { startsAt: local, durationMin: 40 },
    onSubmit: (v) => api.post('/live-classes', { classId: v.classId, subjectId: v.subjectId || null, title: v.title, startsAt: new Date(v.startsAt).toISOString(), durationMin: Number(v.durationMin), joinUrl: v.joinUrl, note: v.note || null }) });
  if (ok) { toast('Live class scheduled'); done(); }
}

// ───────────────────────── class monitor ─────────────────────────
const STATUS = { in_session: ['in session', 'ok'], teacher_not_in: ['teacher not clocked in', 'danger'], no_teacher: ['no teacher set', 'warn'], free: ['no lesson now', 'muted'], break: ['break', 'muted'],
  no_timetable: ['no timetable', 'muted'], no_times: ['timetable has no times', 'warn'], scheduled: ['lesson planned', 'info'] };
const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
export async function monitor(view) {
  const manage = can('academic.manage');
  view.appendChild(pageHead('Class Monitor', 'Which lesson each class should have right now, and whether its teacher has clocked in. Updates every minute.',
    manage ? btn('Bell times', () => bellForm(() => load()), { ic: 'clock' }) : null));
  const dayEl = h('select.input', { 'aria-label': 'Day' }, h('option', { value: '', text: 'Right now' }), DAYS.map((d, i) => h('option', { value: String(i + 1), text: d })));
  const timeEl = h('input.input', { type: 'time', 'aria-label': 'Time', value: '10:00', disabled: true });
  dayEl.addEventListener('change', () => { timeEl.disabled = !dayEl.value; load(); }); timeEl.addEventListener('change', () => load());
  view.appendChild(h('div.range-bar', h('label.muted', { text: 'Show' }), dayEl, timeEl));
  const box = h('div'); view.appendChild(box);
  async function load() {
    try {
      const at = dayEl.value ? `${dayEl.value}T${timeEl.value || '10:00'}` : undefined;
      const r = await api.get(`/monitor/now${qs({ at })}`);
      clear(box).append(...[!r.hasBellTimes ? h('p.form-alert', { text: manage ? 'Bell times are not set yet. Press “Bell times” to add the start and end of each period, so the monitor knows which lesson is on.' : 'Bell times are not set yet. Ask the school office to set them.' }) : null,
        h('div.stats', stat('Classes', r.summary.classes, `${DAYS[r.dayOfWeek - 1]} ${r.time}${r.preview ? ' (preview)' : ''}`, 'grid'), stat('In session', r.summary.inSession, '', 'check'),
          stat('Teacher not in', r.summary.teacherNotIn, '', 'x', r.summary.teacherNotIn ? 'red' : ''), stat('No lesson now', r.summary.free, '', 'clock')),
        card(null, simpleTable([{ key: 'className', label: 'Class' }, { label: 'Now', render: (x) => (x.subject ? h('div', h('strong', { text: x.subject }), h('div.muted', { text: `${x.from}–${x.to}${x.period ? ` · period ${x.period}` : ''}` })) : '—') },
          { label: 'Teacher', render: (x) => x.teacher || '—' }, { label: 'Status', render: (x) => h('span', badge(...(STATUS[x.status] || [x.status])), x.liveClass ? h('span', ' ', badge(`live online: ${x.liveClass}`, 'info')) : null) },
          { label: 'Next', render: (x) => (x.next ? `${x.next.from} ${x.next.subject || ''}` : '—') }], r.items, 'No classes yet'))].filter(Boolean));
    } catch (e) { clear(box).appendChild(h('p.muted', { text: errMsg(e) })); }
  }
  clear(box).appendChild(spinner());
  await load();
  const timer = setInterval(() => { if (!document.body.contains(box)) { clearInterval(timer); return; } if (!dayEl.value) load(); }, 60000);
}
async function bellForm(done) {
  const cur = (await api.get('/school/periods')).items;
  const rows = cur.length ? cur : Array.from({ length: 8 }, (_, i) => { const s = 8 * 60 + i * 40 + (i >= 4 ? 30 : 0); const f = (m) => `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`; return { period: i + 1, starts_at: f(s), ends_at: f(s + 40) }; });
  const fields = rows.flatMap((r) => [{ name: `s${r.period}`, label: `Period ${r.period} starts`, type: 'time' }, { name: `e${r.period}`, label: `Period ${r.period} ends`, type: 'time' }]);
  const values = Object.fromEntries(rows.flatMap((r) => [[`s${r.period}`, r.starts_at], [`e${r.period}`, r.ends_at]]));
  const ok = await formDialog({ title: 'Bell times', wide: true, intro: cur.length ? 'Change the times, or clear both boxes of a period to remove it.' : 'A starting suggestion: 8 periods of 40 minutes with a 30-minute break. Change them to match your school.',
    fields, values, submitLabel: 'Save bell times',
    onSubmit: (v) => api.put('/school/periods', { items: rows.map((r) => ({ period: r.period, startsAt: v[`s${r.period}`], endsAt: v[`e${r.period}`] })).filter((x) => x.startsAt && x.endsAt) }) });
  if (ok) { toast('Bell times saved'); done(); }
}
