// Teachers menu: Teacher Accounts, Assigned Subjects, Teacher Activity (Teacher List = people.teachers).
import { h, clear } from '../core/dom.js';
import { api, qs } from '../core/api.js';
import { can } from '../core/session.js';
import { pageHead, btn, badge, card, toast, fail, simpleTable, empty, spinner, formDialog, confirmDialog, dataTable, stat } from '../core/ui.js';
import { ago, dateTime } from '../core/format.js';
import { academic, accessSlip } from './people.js';
import { pickers } from './shared.js';

export async function accounts(view) {
  view.appendChild(pageHead('Teacher Accounts', 'Sign-in accounts for teaching staff. Teachers activate with a one-time access code and choose their own password — admins never see passwords.', h('a.btn', { href: '#/staff', text: 'All staff records' })));
  const roles = can('users.create') ? (await api.get('/roles')).items.filter((x) => x.portal === 'staff') : [];
  const t = dataTable({
    columns: [{ key: 'full_name', label: 'Teacher' }, { key: 'employee_id', label: 'Staff No', cls: 'mono' }, { key: 'email', label: 'Email' },
      { label: 'Account', render: (r) => (r.has_account ? badge('has login', 'ok') : badge('no login yet', 'warn')) },
      { label: 'Last sign-in', render: (r) => (r.has_account ? ago(r.last_login_at) : '—') },
      { label: '', render: (r) => h('div.page-actions',
        !r.has_account && can('users.create') ? btn('Create login', async () => {
          const res = await formDialog({ title: `Login for ${r.full_name}`, intro: 'A one-time access code slip is created. Give it to the teacher to activate their account.',
            values: { fullName: r.full_name, email: r.email, roleKeys: ['teacher'] },
            fields: [{ name: 'fullName', label: 'Name', required: true }, { name: 'loginId', label: 'Login ID', required: true, hint: 'e.g. school.firstname' }, { name: 'email', label: 'Email', type: 'email' },
              { name: 'roleKeys', label: 'Roles', type: 'multiselect', full: true, options: roles.map((x) => ({ value: x.key, label: x.name })) }],
            onSubmit: (v) => api.post('/users', { ...v, roleKeys: v.roleKeys.length ? v.roleKeys : ['teacher'], link: { type: 'staff', id: r.id } }) });
          if (res) { accessSlip(res); t.refresh(); }
        }, { kind: 'primary' }) : null,
        r.has_account && can('users.update') ? btn('New access code', async () => {
          if (await confirmDialog({ title: `New access code for ${r.full_name}?`, message: 'Use when the teacher forgot their password. The old code stops working.' })) { try { accessSlip(await api.post(`/users/${r.user_id}/access-code`)); } catch (e) { fail(e); } }
        }, { kind: 'ghost' }) : null) }],
    load: (o) => api.get('/staff' + qs({ ...o, teachersOnly: 'true' })), empty: 'No teaching staff yet', emptyHint: 'Add staff under Administration › Staff Records (tick “Teaches classes”).',
  });
  view.appendChild(t);
}

export async function assignments(view) {
  const a = await academic();
  view.appendChild(pageHead('Assigned Subjects', 'Who teaches what: every teacher’s classes and subjects this session.', can('academic.manage') ? h('a.btn.btn-primary', { href: '#/academic/allocation', text: 'Edit subject allocation' }) : null));
  const d = await api.get('/teachers?pageSize=100');
  if (!d.items.length) return view.appendChild(empty('No teachers yet', 'Teachers are created from staff records that teach classes.'));
  const unassigned = d.items.filter((x) => !x.assignments.some((y) => y.subject));
  view.appendChild(h('div.stats', stat('Teachers', d.items.length, '', 'users'), stat('With subjects', d.items.length - unassigned.length, '', 'check'), stat('Without subjects', unassigned.length, unassigned.length ? 'need allocation' : 'all allocated', 'activity', unassigned.length ? 'red' : ''), stat('Classes', a.classes.length, '', 'grid')));
  view.appendChild(card(null, simpleTable([{ key: 'full_name', label: 'Teacher' },
    { label: 'Subjects taught', render: (r) => { const s = r.assignments.filter((x) => x.subject); return s.length ? h('div.checks', s.map((x) => badge(`${x.className} · ${x.subject}${x.role === 'assistant' ? ' (assistant)' : ''}`, 'info'))) : badge('none', 'muted'); } },
    { label: 'Form teacher of', render: (r) => { const f = r.assignments.filter((x) => x.role === 'form_teacher'); return f.length ? f.map((x) => x.className).join(', ') : '—'; } },
    { label: 'Load', cls: 'num', render: (r) => r.assignments.filter((x) => x.subject).length }], d.items)));
}

export async function activity(view, p, q) {
  const a = await academic();
  view.appendChild(pageHead('Teacher Activity', 'Score entry progress, registers taken and last sign-in for each teacher this term.'));
  const pk = pickers(a, q, { term: true });
  const box = h('div');
  const load = async ({ termId }) => {
    clear(box).appendChild(spinner());
    try {
      const r = await api.get(`/teachers/activity${qs({ termId })}`);
      const behind = r.items.filter((x) => x.subjects_assigned && x.sheets_submitted < x.subjects_assigned);
      clear(box).append(h('div.stats', stat('Teachers', r.items.length, '', 'users'), stat('Scores entered', r.items.reduce((n, x) => n + x.scores_entered, 0), 'this term', 'book'),
        stat('Sheets submitted', r.items.reduce((n, x) => n + x.sheets_submitted, 0), `of ${r.items.reduce((n, x) => n + x.subjects_assigned, 0)} allocated`, 'check'), stat('Behind schedule', behind.length, 'have unsubmitted subjects', 'clock', behind.length ? 'red' : '')),
      card(null, simpleTable([{ key: 'full_name', label: 'Teacher' }, { label: 'Allocated', cls: 'num', render: (x) => x.subjects_assigned }, { label: 'Started', cls: 'num', render: (x) => x.sheets_started },
        { label: 'Submitted', render: (x) => h('div.kpi-row', h('div.progress-mini', (() => { const d = h('div'); d.style.width = `${x.subjects_assigned ? Math.round(x.sheets_submitted / x.subjects_assigned * 100) : 0}%`; return d; })()), h('small', { text: `${x.sheets_submitted}/${x.subjects_assigned}` })) },
        { label: 'Approved', cls: 'num', render: (x) => x.sheets_approved }, { label: 'Scores entered', cls: 'num', render: (x) => x.scores_entered },
        { label: 'Last score entry', render: (x) => (x.last_score_at ? dateTime(x.last_score_at) : '—') }, { label: 'Registers', cls: 'num', render: (x) => x.registers_taken },
        { label: 'Last sign-in', render: (x) => (x.has_account ? ago(x.last_login_at) : badge('no login', 'warn')) }], r.items, 'No teachers yet')));
    } catch (e) { clear(box); fail(e); }
  };
  pk.on(load); view.append(card(null, pk.el), box); load(pk.get());
}
