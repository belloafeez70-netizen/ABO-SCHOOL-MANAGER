import { h, clear } from '../core/dom.js';
import { api, qs, download } from '../core/api.js';
import { can, session } from '../core/session.js';
import { pageHead, btn, formDialog, badge, card, toast, fail, confirmDialog, simpleTable, dataTable, stat, bars, empty, field } from '../core/ui.js';
import { naira, toKobo, date, dateTime, cap, initials, tn } from '../core/format.js';
import { academic } from './people.js';
import { fileUrl } from '../core/config.js';

const termOpts = (a) => a.sessions.flatMap((s) => s.terms.map((t) => ({ value: t.id, label: `${s.name} · ${tn(t.name)} term` })));
const curTerm = (a) => { for (const s of a.sessions) for (const t of s.terms) if (t.is_current) return t.id; return null; };

export async function overview(view) {
  const a = await academic(); const s = await api.get('/fees/summary');
  view.appendChild(pageHead('Fees overview', 'Billing and collections for the current term. All amounts computed on the server.',
    can('fees.create') ? btn('Generate invoices', () => generate(a), { kind: 'primary', ic: 'file' }) : null, can('reports.export') ? btn('Export invoices', () => download(`/exports/invoices${qs({ termId: s.termId, format: 'xlsx' })}`).catch(fail), { ic: 'download' }) : null));
  view.appendChild(h('div.stats', stat('Billed', naira(s.billed), `${s.invoices} invoices`, 'file'), stat('Collected', naira(s.collected), `${s.collectionRate}% collection rate`, 'money', 'gold'), stat('Outstanding', naira(s.outstanding), `${s.owing} owing`, 'activity', 'red'), stat('Fully paid', s.paid, 'invoices', 'check')));
  view.appendChild(h('div.grid.g2', card('Collection by class', s.byClass.length ? bars(s.byClass.map((x) => ({ label: x.class_name, value: Number(x.collected) })), { fmt: naira }) : empty('No invoices yet')),
    card('Payment methods', s.methods.length ? bars(s.methods.map((x) => ({ label: cap(x.method), value: Number(x.amount) })), { fmt: naira }) : empty('No payments yet'))));
}
async function generate(a) {
  const r = await formDialog({ title: 'Generate term invoices', intro: 'Creates one invoice per active learner from mandatory fee items (class-specific items apply automatically) minus approved discounts. Learners who already have an invoice for the term are skipped.',
    fields: [{ name: 'termId', label: 'Term', type: 'select', required: true, options: termOpts(a) }, { name: 'classId', label: 'Class (empty = whole school)', type: 'select', options: a.classes.map((c) => ({ value: c.id, label: c.display_name })) }, { name: 'dueDate', label: 'Due date', type: 'date' }],
    values: { termId: curTerm(a) }, onSubmit: (v) => api.post('/fees/invoices/generate', v) });
  if (r) toast(`${r.created} invoices created · ${r.skipped} skipped`);
}
export async function invoices(view, p, q) {
  const a = await academic();
  view.appendChild(pageHead('Invoices', 'Search a learner or invoice number to record a payment.', can('fees.create') ? btn('Generate invoices', async () => { await generate(a); t.refresh(); }, { kind: 'primary', ic: 'file' }) : null));
  const t = dataTable({
    columns: [{ key: 'invoice_no', label: 'Invoice', cls: 'mono' }, { key: 'student', label: 'Learner' }, { key: 'admission_no', label: 'Adm. No' }, { label: 'Total', cls: 'num', render: (x) => naira(x.total_kobo) }, { label: 'Paid', cls: 'num', render: (x) => naira(x.paid_kobo) },
      { label: 'Balance', cls: 'num', render: (x) => h('strong', { text: naira(x.balance_kobo) }) }, { label: 'Status', render: (x) => badge(x.status) }, { label: 'Due', render: (x) => date(x.due_date) }],
    filters: [{ name: 'termId', label: 'Term', placeholder: 'All terms', options: termOpts(a) }, { name: 'classId', label: 'Class', placeholder: 'All classes', options: a.classes.map((c) => ({ value: c.id, label: c.display_name })) }, { name: 'status', label: 'Status', placeholder: 'Any status', options: ['unpaid', 'partial', 'paid', 'void'] }],
    load: (o) => api.get('/fees/invoices' + qs({ ...o, q: o.q || q.q })), rowClick: (x) => { location.hash = `#/fees/invoice/${x.id}`; },
  });
  view.appendChild(t);
}
export async function invoice(view, p) {
  const d = await api.get(`/fees/invoices/${p.id}`); const inv = d.invoice; const bal = Number(inv.total_kobo) - Number(inv.paid_kobo);
  const actions = [btn('Print', () => window.print(), { ic: 'printer' })];
  const payKey = crypto.randomUUID ? crypto.randomUUID() : String(Date.now());      // one key per dialog → retries/double-clicks cannot duplicate
  if (can('fees.update') && inv.status !== 'void') actions.push(btn('Add charge', async () => { const r = await formDialog({ title: 'Add a student-specific charge', fields: [{ name: 'description', label: 'Description', required: true, full: true, placeholder: 'e.g. Excursion, replacement ID card' }, { name: 'amount', label: 'Amount (₦)', type: 'number', required: true, step: '0.01' }], onSubmit: (v) => api.post(`/fees/invoices/${inv.id}/items`, { description: v.description, amountKobo: toKobo(v.amount) }) }); if (r) { toast('Charge added; totals recomputed'); clear(view); invoice(view, p); } }, { ic: 'plus' }));
  if (can('payments.record') && bal > 0 && inv.status !== 'void') actions.push(btn('Record payment', async () => {
    const r = await formDialog({ title: `Record payment · balance ${naira(bal)}`, fields: [{ name: 'amount', label: 'Amount (₦)', type: 'number', required: true, step: '0.01' }, { name: 'method', label: 'Method', type: 'select', required: true, options: ['cash', 'transfer', 'pos', 'cheque'] },
      { name: 'reference', label: 'Bank / teller reference', hint: 'Must be unique; leave empty for cash' }, { name: 'note', label: 'Note', full: true }],
    onSubmit: (v) => api.postOnce('/fees/payments', { invoiceId: inv.id, amountKobo: toKobo(v.amount), method: v.method, reference: v.reference || undefined, note: v.note || undefined }, payKey) });
    if (r) { toast(`Payment recorded · receipt ${r.receipt_no}`); location.hash = `#/fees/receipt/${r.id}`; }
  }, { kind: 'primary', ic: 'money' }));
  if (can('fees.update') && inv.status !== 'void' && !d.payments.some((x) => x.status === 'confirmed')) actions.push(btn('Void', async () => { const reason = await confirmDialog({ title: 'Void invoice?', message: 'This cannot be undone.', danger: true, reason: true }); if (reason) { try { await api.post(`/fees/invoices/${inv.id}/void`, { reason }); clear(view); invoice(view, p); } catch (e) { fail(e); } } }, { kind: 'danger' }));
  view.appendChild(h('div.page-actions.no-print', actions));
  view.appendChild(docHead(d.school, 'Invoice', [['Invoice no', inv.invoice_no], ['Learner', `${inv.last_name} ${inv.first_name}`], ['Admission no', inv.admission_no], ['Term', inv.kind === 'brought_forward' ? 'Fees owed from before (brought forward)' : inv.term ? `${inv.session} · ${tn(inv.term)} term` : '—'], ['Issued', date(inv.issued_at)], ['Due', date(inv.due_date)], ['Status', inv.status.toUpperCase()]],
    [h('table', h('thead', h('tr', h('th', { text: 'Item' }), h('th.right', { text: 'Amount' }))), h('tbody', d.lines.map((l) => h('tr', h('td', {}, l.description, l.kind === 'student_charge' ? h('small.muted', { text: '  (student charge)' }) : null), h('td.right', { text: naira(l.amount_kobo) })))),
      h('tfoot', h('tr', h('th', { text: 'Subtotal' }), h('th.right', { text: naira(inv.subtotal_kobo) })), Number(inv.discount_kobo) ? h('tr', h('th', { text: 'Discount / scholarship' }), h('th.right', { text: `– ${naira(inv.discount_kobo)}` })) : null,
        h('tr', h('th', { text: 'Total' }), h('th.right', { text: naira(inv.total_kobo) })), h('tr', h('th', { text: 'Paid' }), h('th.right', { text: naira(inv.paid_kobo) })), h('tr', h('th', { text: 'Balance' }), h('th.right', { text: naira(bal) })))),
    h('h2', { text: 'Payments' }), simpleTable([{ key: 'receipt_no', label: 'Receipt' }, { label: 'Date', render: (x) => dateTime(x.paid_at) }, { label: 'Method', render: (x) => cap(x.method) }, { key: 'reference', label: 'Reference' }, { label: 'Amount', cls: 'num', render: (x) => naira(x.amount_kobo) }, { label: 'Status', render: (x) => badge(x.status) },
      { label: '', render: (x) => (x.status === 'confirmed' ? h('span.no-print', h('a.btn.btn-sm', { href: `#/fees/receipt/${x.id}`, text: 'Receipt' }), can('payments.reverse') ? btn('Reverse', async () => { const reason = await confirmDialog({ title: 'Reverse payment?', message: 'Use for bounced transfers or errors. Another officer must do this (four-eyes).', danger: true, reason: true }); if (reason) { try { await api.post(`/fees/payments/${x.id}/reverse`, { reason }); clear(view); invoice(view, p); } catch (e) { fail(e); } } }, { kind: 'ghost' }) : null) : '') }], d.payments, 'No payments yet')]));
}
export function docHead(school, title, kv, body) {
  return h('div.doc', h('div.doc-head', school && school.logo_file_id ? h('img', { src: fileUrl(school.logo_file_id), alt: '' }) : h('div.brand-mark.doc-mark', { text: initials((school || {}).name || 'School') }),
    h('div', h('h1', { text: school ? school.name : '' }), h('p', { text: school ? [school.address, school.phone, school.email].filter(Boolean).join(' · ') : '' }))),
  h('h2', { text: title }), h('dl.kv', kv.map(([k, v]) => [h('dt', { text: k }), h('dd', { text: v ?? '—' })])), body);
}
export async function receipt(view, p) {
  const d = await api.get(`/fees/receipts/${p.id}`); const r = d.receipt;
  view.appendChild(h('div.page-actions.no-print', btn('Print receipt', () => window.print(), { kind: 'primary', ic: 'printer' })));
  view.appendChild(docHead(d.school, r.status === 'reversed' ? 'Payment receipt — REVERSED' : 'Official payment receipt', [['Receipt no', r.receipt_no], ['Date', dateTime(r.paid_at)], ['Received from', `${r.last_name} ${r.first_name} (${r.admission_no})`], ['Invoice', r.invoice_no], ['Method', cap(r.method)], ['Reference', r.reference], ['Amount', naira(r.amount_kobo)], ['Balance after', naira(Number(r.total_kobo) - Number(r.paid_kobo))], ['Received by', r.received_by_name || (r.provider ? `Online (${r.provider})` : '—')]],
    h('div.doc-sign', h('div', { text: 'Bursar / Accountant' }), h('div', { text: 'School stamp' }))));
}
export async function payments(view) {
  view.appendChild(pageHead('Payments & receipts', 'Every confirmed, pending and reversed payment.', can('reports.export') ? btn('Export', () => download('/exports/payments?format=xlsx').catch(fail), { ic: 'download' }) : null));
  const from = field({ name: 'from', label: 'From', type: 'date' }); const to = field({ name: 'to', label: 'To', type: 'date' });
  const t = dataTable({ columns: [{ key: 'receipt_no', label: 'Receipt', cls: 'mono' }, { label: 'Date', render: (x) => dateTime(x.paid_at) }, { key: 'student', label: 'Learner' }, { key: 'invoice_no', label: 'Invoice' }, { label: 'Method', render: (x) => cap(x.method) }, { key: 'reference', label: 'Reference' },
    { label: 'Amount', cls: 'num', render: (x) => naira(x.amount_kobo) }, { label: 'Status', render: (x) => badge(x.status) }, { key: 'received_by', label: 'By' }],
  load: (o) => api.get('/fees/payments' + qs({ ...o, from: from._get(), to: to._get() })), rowClick: (x) => { location.hash = `#/fees/receipt/${x.id}`; },
  filters: [{ name: 'method', label: 'Method', placeholder: 'All methods', options: ['cash', 'transfer', 'pos', 'cheque', 'online'] }] });
  [from, to].forEach((f) => f.querySelector('input').addEventListener('change', () => t.refresh()));
  view.append(card(null, h('div.form-grid', from, to)), t);
}
export async function setup(view) {
  const a = await academic(); const [items, cats, disc] = await Promise.all([api.get('/fees/structures'), api.get('/fees/categories'), api.get('/fees/discounts')]);
  const catOpts = cats.items.filter((c) => c.active).map((c) => ({ value: c.id, label: c.name }));
  const itemFields = [{ name: 'name', label: 'Fee item', required: true }, { name: 'categoryId', label: 'Category', type: 'select', required: true, options: catOpts },
    { name: 'amount', label: 'Amount (₦)', type: 'number', required: true, step: '0.01' }, { name: 'termId', label: 'Term (empty = every term)', type: 'select', options: termOpts(a) }, { name: 'classId', label: 'Class (empty = every class)', type: 'select', options: a.classes.map((c) => ({ value: c.id, label: c.display_name })) }, { name: 'mandatory', label: 'Mandatory (included in invoices)', type: 'checkbox' }];
  const toBody = (v) => ({ name: v.name, categoryId: v.categoryId, amountKobo: toKobo(v.amount), termId: v.termId, classId: v.classId, mandatory: v.mandatory });
  const reload = () => { clear(view); setup(view); };
  view.appendChild(pageHead('Fee structures & discounts', 'What the school charges (by category, term and class), and scholarships/discounts (four-eyes approval).'));
  view.appendChild(card('Fee structures', simpleTable([{ key: 'name', label: 'Item' }, { key: 'category', label: 'Category' }, { label: 'Amount', cls: 'num', render: (x) => naira(x.amount_kobo) }, { label: 'Term', render: (x) => x.term || 'Every term' }, { label: 'Class', render: (x) => x.class_name || 'All' },
    { label: 'Status', render: (x) => (x.active ? badge(x.mandatory ? 'mandatory' : 'optional', x.mandatory ? 'ok' : 'info') : badge('inactive', 'muted')) },
    { label: '', render: (x) => (can('fees.update') ? btn('Edit', async () => { const r = await formDialog({ title: 'Edit fee structure', fields: [...itemFields, { name: 'active', label: 'Active', type: 'checkbox' }], values: { name: x.name, categoryId: x.category_id, amount: Number(x.amount_kobo) / 100, termId: x.term_id, classId: x.class_id, mandatory: x.mandatory, active: x.active }, onSubmit: (v) => api.patch(`/fees/structures/${x.id}`, { ...toBody(v), active: v.active }) }); if (r) reload(); }, { kind: 'ghost' }) : null) }], items.items, 'No fee structures yet'),
  can('fees.create') ? btn('Add fee structure', async () => { const r = await formDialog({ title: 'Add fee structure', fields: itemFields, values: { mandatory: true, categoryId: catOpts[0] && catOpts[0].value }, onSubmit: (v) => api.post('/fees/structures', toBody(v)) }); if (r) reload(); }, { kind: 'primary', ic: 'plus' }) : null));
  view.appendChild(card('Fee categories', h('div.checks', cats.items.map((c) => badge(c.name, c.active ? 'info' : 'muted'))),
    can('fees.create') ? btn('Add category', async () => { const r = await formDialog({ title: 'Add fee category', fields: [{ name: 'name', label: 'Name', required: true }, { name: 'code', label: 'Code', required: true, placeholder: 'e.g. sports' }], onSubmit: (v) => api.post('/fees/categories', v) }); if (r) reload(); }, { ic: 'plus' }) : null));
  view.appendChild(card('Discounts & scholarships', simpleTable([{ key: 'student', label: 'Learner' }, { label: 'Type', render: (x) => cap(x.kind) }, { label: 'Value', render: (x) => (x.percent ? `${x.percent}%` : naira(x.amount_kobo)) }, { key: 'reason', label: 'Reason' }, { label: 'Status', render: (x) => badge(x.status) },
    { label: '', render: (x) => (x.status === 'pending' && can('fees.approve') ? h('div.page-actions', btn('Approve', async () => { try { await api.post(`/fees/discounts/${x.id}/review`, { action: 'approve' }); reload(); } catch (e) { fail(e); } }, { kind: 'primary' }), btn('Reject', async () => { await api.post(`/fees/discounts/${x.id}/review`, { action: 'reject' }); reload(); })) : '') }], disc.items, 'No discounts'),
  can('fees.create') ? btn('Request discount', async () => { const st = await api.get('/students?pageSize=100'); const r = await formDialog({ title: 'Request discount / scholarship', fields: [{ name: 'studentId', label: 'Learner', type: 'select', required: true, options: st.items.map((s) => ({ value: s.id, label: `${s.last_name} ${s.first_name} (${s.admission_no})` })) }, { name: 'kind', label: 'Type', type: 'select', required: true, options: ['discount', 'scholarship', 'sibling', 'staff_child'] },
    { name: 'percent', label: 'Percent (or leave empty)', type: 'number' }, { name: 'amount', label: 'Fixed amount ₦ (or leave empty)', type: 'number' }, { name: 'termId', label: 'Term (empty = every term)', type: 'select', options: termOpts(a) }, { name: 'reason', label: 'Reason', required: true, full: true }],
  onSubmit: (v) => api.post('/fees/discounts', { studentId: v.studentId, kind: v.kind, termId: v.termId, reason: v.reason, percent: v.percent || null, amountKobo: v.amount ? toKobo(v.amount) : null }) }); if (r) { toast('Request sent for approval'); reload(); } }, { ic: 'plus' }) : null));
  void session; void empty;
}
