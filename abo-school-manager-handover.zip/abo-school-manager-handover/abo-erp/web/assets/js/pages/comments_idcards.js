// Comment helper and ID cards (Phase 6).
//   Comment helper: suggestions for every pupil in a class; the teacher/head reads, edits and saves them in one go.
//   ID cards: printable pupil and staff cards with photo and a real Code-128 barcode of the admission / staff number.
import { h, clear } from '../core/dom.js';
import { api, qs } from '../core/api.js';
import { can } from '../core/session.js';
import { pageHead, btn, card, toast, fail, spinner, errMsg, empty, tabs } from '../core/ui.js';
import { initials, tn } from '../core/format.js';
import { fileUrl } from '../core/config.js';
import { code128Svg } from '../core/barcode.js';

async function academicOptions() {
  const a = await api.get('/academic');
  const terms = a.sessions.flatMap((s) => s.terms.map((t) => ({ value: t.id, label: `${s.name} · ${tn(t.name)} term${t.is_current ? ' (current)' : ''}`, current: t.is_current })));
  return { terms, classes: a.classes.map((c) => ({ value: c.id, label: c.display_name })) };
}
const select = (label, options, value) => h('select.input', { 'aria-label': label }, options.map((o) => h('option', { value: o.value, text: o.label, selected: o.value === value })));

// ───────────────────────── comment helper ─────────────────────────
export async function commentHelper(view) {
  view.appendChild(pageHead('Comment Helper', 'Suggested report-card comments for a whole class. Read them, change anything you like, then save. Nothing is saved until you press Save.'));
  const o = await academicOptions();
  const termSel = select('Term', o.terms, (o.terms.find((t) => t.current) || o.terms[0] || {}).value);
  const classSel = select('Class', o.classes, (o.classes[0] || {}).value);
  const box = h('div');
  view.appendChild(h('div.range-bar', h('label.muted', { text: 'Term' }), termSel, h('label.muted', { text: 'Class' }), classSel, btn('Load class', () => load(), { kind: 'primary' })));
  view.appendChild(box);
  async function load() {
    clear(box).appendChild(spinner());
    let r; try { r = await api.get(`/results/comment-helper${qs({ termId: termSel.value, classId: classSel.value })}`); } catch (e) { clear(box).appendChild(h('p.muted', { text: errMsg(e) })); return; }
    if (!r.items.length) { clear(box).appendChild(empty('No pupils in this class for this term')); return; }
    const rows = r.items.map((x) => ({ x, t: r.can.teacher ? h('textarea.input', { rows: 3, maxlength: 600, 'aria-label': `Class teacher's comment for ${x.name}`, text: x.teacherComment || '' }) : null,
      hd: r.can.head ? h('textarea.input', { rows: 2, maxlength: 600, 'aria-label': `Head's comment for ${x.name}`, text: x.headComment || '' }) : null }));
    const use = (ta, text) => h('button.btn.btn-ghost', { type: 'button', text: 'Use suggestion', disabled: !text, on: { click: () => { ta.value = text; } } });
    const fillEmpty = () => { let n = 0; for (const row of rows) { if (row.t && !row.t.value.trim() && row.x.suggestedTeacher) { row.t.value = row.x.suggestedTeacher; n++; } if (row.hd && !row.hd.value.trim() && row.x.suggestedHead) { row.hd.value = row.x.suggestedHead; n++; } } toast(n ? `${n} empty box(es) filled — read them before saving` : 'No empty boxes to fill'); };
    const save = async (ev) => {
      const items = rows.map(({ x, t, hd }) => { const it = { studentId: x.studentId }; if (t && t.value.trim() !== (x.teacherComment || '')) it.teacherComment = t.value.trim() || null; if (hd && hd.value.trim() !== (x.headComment || '')) it.headComment = hd.value.trim() || null; return it; })
        .filter((it) => it.teacherComment !== undefined || it.headComment !== undefined);
      if (!items.length) { toast('Nothing has changed'); return; }
      const btnEl = ev.currentTarget; btnEl.disabled = true;
      try { const s = await api.put('/results/report-cards/bulk', { termId: termSel.value, classId: classSel.value, items }); toast(`Saved comments for ${s.saved} pupil(s)`); await load(); } catch (e) { fail(e); btnEl.disabled = false; }
    };
    clear(box).append(card(`${r.class.name} · ${tn(r.term.name)} term`, [
      h('p.muted', { text: r.can.teacher && r.can.head ? 'You can write both the class teacher’s and the head’s comment.' : r.can.teacher ? 'You are writing the class teacher’s comment.' : 'You are writing the head’s / principal’s comment.' }),
      h('div.page-actions', btn('Fill empty boxes with suggestions', fillEmpty), btn('Save all', save, { kind: 'primary', ic: 'check' })),
      h('div.comment-list', rows.map(({ x, t, hd }) => h('div.comment-row',
        h('div.comment-who', h('strong', { text: x.name }), h('div.muted', { text: `${x.admissionNo}${x.average !== null ? ` · average ${x.average}%` : ''}${x.position ? ` · position ${x.position} of ${x.classSize}` : ''}` }), x.note ? h('div.muted', { text: x.note }) : null),
        h('div.comment-boxes',
          t ? h('div', h('label', { text: 'Class teacher' }), t, x.suggestedTeacher ? h('div.comment-sugg', h('small.muted', { text: `Suggestion: ${x.suggestedTeacher}` }), use(t, x.suggestedTeacher)) : null) : null,
          hd ? h('div', h('label', { text: 'Head / principal' }), hd, x.suggestedHead ? h('div.comment-sugg', h('small.muted', { text: `Suggestion: ${x.suggestedHead}` }), use(hd, x.suggestedHead)) : null) : null)))),
      h('div.page-actions', btn('Save all', save, { kind: 'primary', ic: 'check' }))]));
  }
  if (o.classes.length && o.terms.length) await load();
}

// ───────────────────────── ID cards ─────────────────────────
function idCard(school, p, kind) {
  const photo = p.passport_file_id ? h('img', { src: fileUrl(p.passport_file_id), alt: '' }) : h('span', { text: initials(p.name) });
  const code = kind === 'staff' ? (p.staff_no || '') : p.admission_no;
  const meta = kind === 'staff'
    ? [['Staff no.', p.staff_no || '—'], ['Role', p.designation || 'Staff'], ['Phone', p.phone || '—'], ['Session', school.session || '—']]
    : [['Admission no.', p.admission_no], ['Class', p.className], ['Parent phone', p.guardian_phone || '—'], ['Session', school.session || '—']];
  return h('div.idc',
    h('div.idc-head', school.logo_file_id ? h('div.idc-logo', h('img', { src: fileUrl(school.logo_file_id), alt: '' })) : h('div.idc-logo', { text: initials(school.name) }),
      h('div.idc-school', h('b', { text: school.name }), school.motto ? h('small', { text: school.motto }) : null), h('span.idc-role', { text: kind === 'staff' ? 'STAFF' : 'STUDENT' })),
    h('div.idc-body', h('div.idc-photo', photo), h('div', h('div.idc-name', { text: p.name }), h('div.idc-meta', meta.map(([k, v]) => h('div', h('span', { text: k }), h('b', { text: v })))))),
    h('div.idc-foot', code ? h('div.idc-bar', code128Svg(code, { height: 26, module: 1.1, label: true })) : h('small', { text: 'No staff number yet' }), school.phone ? h('small.idc-tel', { text: school.phone }) : null));
}
export async function idCards(view) {
  const pupils = can('students.view'); const staff = can('staff.view');
  view.appendChild(pageHead('ID Cards', 'Printable ID cards with photo and a barcode that gate scanners and phone scanner apps can read. Cards print 2 per row on A4.',
    btn('Print cards', () => window.print(), { ic: 'printer', kind: 'primary' })));
  const tabsList = [pupils ? { key: 'students', label: 'Pupils' } : null, staff ? { key: 'staff', label: 'Staff' } : null].filter(Boolean);
  const head = h('div'); const box = h('div');
  let o = null;
  const show = async (k) => {
    clear(head); clear(box);
    if (k === 'students') {
      o = o || await academicOptions();
      const cls = select('Class', o.classes, (o.classes[0] || {}).value);
      cls.addEventListener('change', () => draw(cls.value));
      head.appendChild(h('div.range-bar.no-print', h('label.muted', { text: 'Class' }), cls));
      await draw(cls.value);
    } else await drawStaff();
  };
  async function draw(classId) {
    clear(box).appendChild(spinner());
    try {
      const r = await api.get(`/id-cards/students${qs({ classId })}`);
      const noPhoto = r.people.filter((p) => !p.passport_file_id).length;
      clear(box).append(...[noPhoto ? h('p.muted.no-print', { text: `${noPhoto} pupil(s) have no passport photo yet — their cards show initials. Add photos on each pupil’s profile.` }) : null,
        r.people.length ? h('div.idc-grid', r.people.map((p) => idCard(r.school, p, 'student'))) : empty('No pupils in this class')].filter(Boolean));
    } catch (e) { clear(box).appendChild(h('p.muted', { text: errMsg(e) })); }
  }
  async function drawStaff() {
    clear(box).appendChild(spinner());
    try { const r = await api.get('/id-cards/staff'); clear(box).appendChild(r.people.length ? h('div.idc-grid', r.people.map((p) => idCard(r.school, p, 'staff'))) : empty('No staff records')); } catch (e) { clear(box).appendChild(h('p.muted', { text: errMsg(e) })); }
  }
  if (tabsList.length > 1) view.appendChild(h('div.no-print', tabs(tabsList, (k) => show(k), tabsList[0].key)));
  view.append(head, box);
  if (tabsList.length) await show(tabsList[0].key);
}
