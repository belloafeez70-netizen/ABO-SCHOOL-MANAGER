// Administration › Backup & Restore, and More › Notifications / Help & Support / System Information.
import { h, clear, icon } from '../core/dom.js';
import { api, download } from '../core/api.js';
import { can, session } from '../core/session.js';
import { pageHead, btn, badge, card, toast, fail, simpleTable, empty, spinner, stat } from '../core/ui.js';
import { ago, dateTime, date, tn } from '../core/format.js';
import { importCard } from './records.js';

export async function backup(view) {
  view.appendChild(pageHead('Backup & Restore', 'Keep your own copy of your school data and bring records back in when you need to.'));
  view.appendChild(card('How your data is protected', h('ul', [
    'The A.B.O. platform keeps continuous point-in-time recovery of the database and encrypted nightly backups stored separately from the live server.',
    'Every sensitive change is recorded in the tamper-evident audit log (Administration › Audit Logs).',
    'Approved and published results are locked; changes go through correction requests, so history is never lost.',
    'Need data rolled back to an earlier time? Contact A.B.O. support (More › Help & Support) with the date/time — restores are done by the platform team so other schools are never affected.'].map((t) => h('li', { text: t })))));
  if (can('reports.export') && can('settings.view')) {
    const status = h('div');
    view.appendChild(card('Download a full backup of your school data', [
      h('p.muted', { text: 'One Excel workbook with a sheet for each dataset you are allowed to see: students, parents, staff, classes, subjects, results, invoices, payments, attendance and the audit log. It is built in the background — you will get a notification when it is ready.' }),
      h('div.page-actions', btn('Create backup now', async () => {
        try {
          const { jobId } = await api.post('/school/backup');
          clear(status).appendChild(spinner('Building your backup…'));
          for (let i = 0; i < 60; i++) {
            await new Promise((r) => setTimeout(r, 1500));
            const j = await api.get(`/jobs/${jobId}`);
            if (j.status === 'done') {
              clear(status).append(h('div.list-item', icon('check'), h('span', { text: `Backup ready — ${Object.entries(j.result.datasets || {}).map(([k, n]) => `${k}: ${n}`).join(' · ')}` }),
                btn('Download', () => download(`/files/${j.result.fileId}`).catch(fail), { kind: 'primary', ic: 'download' })));
              return;
            }
            if (j.status === 'failed') { clear(status).appendChild(h('p.muted', { text: j.last_error || 'The backup failed. Please try again.' })); return; }
          }
          clear(status).appendChild(h('p.muted', { text: 'Still working — you will get a notification when it is ready.' }));
        } catch (e) { clear(status); fail(e); }
      }, { kind: 'primary', ic: 'download' })), status]));
  }
  if (can('reports.export')) view.appendChild(card('Export single datasets', [h('p.muted', { text: 'CSV or Excel exports of individual lists (students, staff, results, invoices…) are under Administration › Import & Export.' }), h('a.btn', { href: '#/data', text: 'Open Import & Export' })]));
  if (can('imports.run')) {
    view.appendChild(importCard({ title: 'Restore records from a file', intro: 'Bring records back from Excel/CSV (for example from your backup workbook, copied into the matching template). Every file is validated first; duplicates are rejected, nothing is overwritten.' }));
    view.appendChild(card('Moving from the old offline app?', [h('p.muted', { text: 'Import the old app’s “Backup” JSON file — classes, learners, scores and CBT questions are previewed before anything is saved.' }), h('a.btn', { href: '#/migrate', text: 'Legacy migration' })]));
  }
}

export async function notifications(view) {
  view.appendChild(pageHead('Notifications', 'Results, approvals, messages, exports and school updates meant for you.', btn('Mark all as read', async () => { try { await api.post('/notifications/read', { all: true }); toast('All caught up'); clear(view); notifications(view); } catch (e) { fail(e); } }, { ic: 'check' })));
  const d = await api.get('/notifications');
  if (!d.items.length) return view.appendChild(empty('You are all caught up', 'New notifications will appear here.'));
  view.appendChild(card(null, h('div.list', d.items.map((n) => h(`a.list-item.notif-row${n.read_at ? '' : '.unread'}`, { href: n.link || '#/', on: { click: () => { if (!n.read_at) api.post('/notifications/read', { ids: [n.id] }).catch(() => {}); } } },
    h('span', icon(n.read_at ? 'bell' : 'activity', 16)), h('div.grow', h('strong', { text: n.title }), n.body ? h('div.muted', { text: n.body }) : null), h('small.muted', { text: ago(n.created_at) }), n.read_at ? null : badge('new', 'info'))))));
}

const GUIDES = [
  ['Getting your school ready', ['Academics › Academic Session: create the session and make it current.', 'Academics › Classes & Arms, then Subjects and Subject Allocation.', 'Students › Student Import (or Add Student).', 'Teachers › Teacher Accounts: create logins and print the access-code slips.']],
  ['Entering scores (teachers)', ['Scores & Results › CA Score Entry or Exam Score Entry.', 'Pick the term and class, open your subject, type the scores, click Save.', 'When complete, open the sheet and click “Submit for review”.']],
  ['Approving & publishing results', ['Scores & Results › Result Approval: review, approve (or return with a note).', 'Result Processing computes positions at any time (safe to repeat).', 'Result Publishing: publish a class once every subject is approved — parents are notified.']],
  ['Report sheets', ['Report Sheets › Result Templates: choose the layout and what to show.', 'School › Principal/Head Information: add the head’s name and signature.', 'Report Sheets › Print Reports or Download PDF for a whole class.']],
  ['Parents & students', ['Share your school sign-in link (School › School Profile).', 'Create a portal login from the student’s profile; the slip has a one-time access code.', 'Results appear in their portal only after you publish.']],
  ['Security tips', ['Owners, admins and bursars must use two-factor sign-in.', 'Never share passwords — issue a new access code instead (Users).', 'Check Administration › Audit Logs and Security Events regularly.']],
];
export async function help(view) {
  const sup = await api.get('/system/support').catch(() => ({}));
  const me = session.me;
  view.appendChild(pageHead('Help & Support', 'Quick guides, keyboard shortcuts and how to reach the A.B.O. support team.'));
  view.appendChild(h('div.grid.g2',
    card('Contact support', h('dl.kv', h('dt', { text: 'Email' }), h('dd', sup.email ? h('a', { href: `mailto:${sup.email}`, text: sup.email }) : h('span.muted', { text: 'Ask your school administrator' })),
      h('dt', { text: 'Phone / WhatsApp' }), h('dd', sup.phone ? h('a', { href: `tel:${sup.phone.replace(/[^+0-9]/g, '')}`, text: sup.phone }) : h('span.muted', { text: '—' })), h('dt', { text: 'Hours' }), h('dd', { text: sup.hours || '—' }),
      h('dt', { text: 'Your school' }), h('dd', { text: me.school ? me.school.name : '—' }), h('dt', { text: 'Your Login ID' }), h('dd.mono', { text: me.user.loginId }))),
    card('Keyboard shortcuts', h('dl.kv', h('dt', h('span.kbd', { text: 'Ctrl' }), ' + ', h('span.kbd', { text: 'K' })), h('dd', { text: 'Search students' }), h('dt', h('span.kbd', { text: 'Ctrl' }), ' + ', h('span.kbd', { text: '/' })), h('dd', { text: 'Find anything in the menu' }),
      h('dt', h('span.kbd', { text: 'Menu button' })), h('dd', { text: 'Collapse / expand the menu (opens it on phones)' }), h('dt', h('span.kbd', { text: 'Esc' })), h('dd', { text: 'Close a dialog' })))));
  view.appendChild(h('div.help-grid', GUIDES.map(([t, steps]) => card(t, h('ol', steps.map((x) => h('li', { text: x })))))));
  view.appendChild(card('Forgot your password?', h('p.muted', { text: 'Use “Forgot password” on the sign-in page (if your account has an email), or ask your school administrator for a new one-time access code. A.B.O. staff will never ask for your password.' })));
}

export async function system(view) {
  const d = await api.get('/system/info');
  const mb = (b) => `${(Number(b) / 1048576).toFixed(1)} MB`;
  view.appendChild(pageHead('System Information', 'Your school account, usage and the version of A.B.O. School Manager you are using.'));
  view.appendChild(h('div.stats', stat('Active students', d.usage.students, `plan limit ${d.school.max_students}`, 'users', d.usage.students > d.school.max_students * 0.9 ? 'red' : ''), stat('Staff', d.usage.staff, `${d.usage.users} user accounts`, 'building'),
    stat('Two-factor', `${d.usage.users_with_2fa}/${d.usage.users}`, 'accounts protected', 'shield'), stat('File storage', mb(d.usage.storage_bytes), `${d.usage.documents} documents`, 'layers')));
  view.appendChild(h('div.grid.g2',
    card('School account', h('dl.kv', h('dt', { text: 'School' }), h('dd', { text: d.school.name }), h('dt', { text: 'Status' }), h('dd', badge(d.school.status)), h('dt', { text: 'Approved' }), h('dd', { text: d.school.approved_at ? date(d.school.approved_at) : '—' }),
      h('dt', { text: 'Plan' }), h('dd', { text: d.school.plan }), h('dt', { text: 'Subscription' }), h('dd', { text: `${d.school.subscription_status}${d.school.subscription_expires_at ? ` · until ${date(d.school.subscription_expires_at)}` : ''}` }),
      h('dt', { text: 'Current term' }), h('dd', { text: d.currentTerm ? `${d.currentTerm.session} · ${tn(d.currentTerm.name)} term` : 'Not set' }), h('dt', { text: 'Sign-in link' }), h('dd.mono', { text: d.school.portal_url }),
      h('dt', { text: 'Time zone / currency' }), h('dd', { text: `${d.school.timezone || 'Africa/Lagos'} · ${d.school.currency || 'NGN'}` }))),
    card('Application', h('dl.kv', h('dt', { text: 'Product' }), h('dd', { text: d.app.name }), h('dt', { text: 'Version' }), h('dd', { text: d.app.version }), h('dt', { text: 'API' }), h('dd', { text: d.app.api }),
      h('dt', { text: 'Database schema' }), h('dd.mono', { text: d.app.schema || '—' }), h('dt', { text: 'Environment' }), h('dd', { text: d.app.environment }), h('dt', { text: 'Server time' }), h('dd', { text: dateTime(d.app.serverTime) }),
      h('dt', { text: 'Your browser' }), h('dd', { text: navigator.userAgent.replace(/\(.*?\)/g, '').replace(/\s+/g, ' ').slice(0, 80) }), h('dt', { text: 'Backups' }), h('dd', { text: d.backups.description })))));
  view.appendChild(card('Classes & subjects', simpleTable([{ key: 'k', label: 'Item' }, { key: 'v', label: 'Count', cls: 'num' }], [{ k: 'Classes & arms', v: d.usage.classes }, { k: 'Subjects', v: d.usage.subjects }, { k: 'Documents', v: d.usage.documents }])));
}
