// Students menu: Add Student (full page), Student Profile (finder), Student Import.
import { h, clear, icon } from '../core/dom.js';
import { api, qs } from '../core/api.js';
import { can } from '../core/session.js';
import { pageHead, btn, card, toast, form, empty, spinner, badge, fail } from '../core/ui.js';
import { academic } from './people.js';
import { classOpts } from './shared.js';
import { importCard } from './records.js';

export async function addStudent(view) {
  const a = await academic();
  view.appendChild(pageHead('Add Student', 'Admit a new learner. The admission number must be unique in your school.', h('a.btn', { href: '#/students', text: 'Student list' })));
  if (!can('students.create')) return view.appendChild(empty('You cannot admit students', 'Ask an administrator for the students.create permission.'));
  const f = form([
    { section: 'Admission' },
    { name: 'admissionNo', label: 'Admission number', required: true, placeholder: 'e.g. BOPC/2026/014' }, { name: 'classId', label: 'Class (current session)', type: 'select', options: classOpts(a) },
    { name: 'admissionDate', label: 'Admission date', type: 'date' },
    { section: 'Learner' },
    { name: 'lastName', label: 'Surname', required: true }, { name: 'firstName', label: 'First name', required: true }, { name: 'otherNames', label: 'Other names' },
    { name: 'gender', label: 'Gender', type: 'select', required: true, options: ['Male', 'Female'] }, { name: 'dateOfBirth', label: 'Date of birth', type: 'date' },
    { name: 'phone', label: 'Phone (optional)' }, { name: 'email', label: 'Email (optional)', type: 'email' },
    { name: 'address', label: 'Home address', full: true }, { name: 'medicalNotes', label: 'Medical notes (restricted)', type: 'textarea', full: true, rows: 2 },
  ], {});
  const alert = h('div.form-alert', { role: 'alert', hidden: true });
  const save = async (another) => {
    alert.hidden = true;
    try {
      const s = await api.post('/students', f._values());
      toast(`${s.first_name} ${s.last_name} admitted (${s.admission_no})`);
      if (another) { clear(view); addStudent(view); } else location.hash = `#/students/${s.id}`;
    } catch (e) { if (!f._error(e)) { alert.textContent = e.message; alert.hidden = false; } }
  };
  view.appendChild(card(null, [alert, f, h('div.page-actions', btn('Save & add another', () => save(true)), btn('Save student', () => save(false), { kind: 'primary', ic: 'check' }))]));
  view.appendChild(h('p.muted', { text: 'Tip: to admit many learners at once, use Students → Student Import with the Excel/CSV template.' }));
}

export async function studentProfile(view, p, q) {
  const a = await academic();
  view.appendChild(pageHead('Student Profile', 'Find a learner to open their profile, report card, class history and parents.'));
  const input = h('input.input', { type: 'search', placeholder: 'Type a name or admission number…', 'aria-label': 'Search students', value: q.q || '' });
  const cls = h('select.input', { 'aria-label': 'Class' }, h('option', { value: '', text: 'All classes' }), classOpts(a).map((o) => h('option', { value: o.value, text: o.label })));
  const out = h('div');
  let timer;
  const load = async () => {
    clear(out).appendChild(spinner('Searching…'));
    try {
      const r = await api.get('/students' + qs({ q: input.value.trim() || undefined, classId: cls.value || undefined, pageSize: 24 }));
      clear(out);
      if (!r.items.length) return out.appendChild(empty('No learner found', 'Check the spelling or choose another class.'));
      out.appendChild(h('div.profile-grid', r.items.map((s) => h('a.profile-card', { href: `#/students/${s.id}` },
        h('span.avatar.lg', { text: (s.first_name[0] || '') + (s.last_name[0] || '') }),
        h('div', h('strong', { text: `${s.last_name} ${s.first_name}` }), h('div.muted.mono', { text: s.admission_no }), h('div', s.class_name ? badge(s.class_name, 'info') : badge('not enrolled', 'warn'))),
        icon('chevron', 16)))));
      if (r.total > r.items.length) out.appendChild(h('p.muted', { text: `Showing ${r.items.length} of ${r.total}. Refine your search to narrow it down.` }));
    } catch (e) { clear(out); fail(e); }
  };
  input.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(load, 280); });
  cls.addEventListener('change', load);
  view.append(card(null, h('div.form-grid', h('div.field', h('label', { text: 'Search' }), input), h('div.field', h('label', { text: 'Class' }), cls))), out);
  load(); setTimeout(() => input.focus(), 50);
}

export async function studentImport(view) {
  view.appendChild(pageHead('Student Import', 'Admit many learners at once from Excel or CSV. You always see a validated preview before anything is saved.'));
  if (!can('imports.run')) return view.appendChild(empty('Import is not available to you', 'Ask an administrator for the imports.run permission.'));
  view.appendChild(card('How it works', h('ol', ['Download the template and fill one learner per row (admission_no, first_name, last_name, gender are required; class must match an existing class, e.g. “BASIC 1A”).',
    'Optional columns create or link a parent: parent_name, parent_phone, parent_email, relationship.', 'Upload the file and check the preview — rows with problems are listed and skipped.', 'Click “Import valid rows”. Everything runs in one transaction and is written to the audit log.'].map((t) => h('li', { text: t })))));
  view.appendChild(importCard({ only: ['students', 'guardians'], title: 'Upload learners' }));
}
