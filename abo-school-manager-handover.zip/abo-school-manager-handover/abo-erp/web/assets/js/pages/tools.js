// The last offline-edition features, online (12 Oct 2026): Old Debts, Petty Cash requests, Reminders & Alerts,
// Questions from Teachers, Devices, Print Centre (blank register, attendance report, stock sheet, cash ledger) and the
// Score Sheet Layout. Every rule is checked by the server; these pages only show and send.
import { h, clear } from '../core/dom.js';
import { api, qs } from '../core/api.js';
import { can, session } from '../core/session.js';
import { pageHead, btn, badge, card, toast, fail, confirmDialog, formDialog, simpleTable, stat, spinner, errMsg, empty, modal } from '../core/ui.js';
import { naira, toKobo, date, dateTime, tn } from '../core/format.js';
import { docHead } from './broadsheets.js';
import { academic } from './people.js';

const printBtn = () => btn('Print', () => window.print(), { ic: 'printer' });
const ymd = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const errBox = (box, e) => clear(box).appendChild(h('p.muted', { text: errMsg(e) }));
const TONES = { pending: 'warn', approved: 'info', rejected: 'danger', given: 'info', settled: 'ok', cancelled: 'muted', paid: 'ok', partial: 'warn', unpaid: 'danger', void: 'muted', active: 'ok', repair: 'warn', retired: 'muted' };
const LABELS = { given: 'money given', settled: 'settled', rejected: 'refused', repair: 'in repair' };
const tone = (s) => badge(LABELS[s] || s, TONES[s] || 'muted');
const classOptions = async () => (await academic()).classes.map((c) => ({ value: c.id, label: c.display_name || c.name }));

// ───────────────────────── Old Debts ─────────────────────────
// one learner per line: "SA/2024/001, 15000, second term balance" · "Adeyemi Tolu, JSS 2, 15000" · pasted Excel (tabs)
export function parseDebtLines(text) {
  const rows = []; const bad = [];
  String(text || '').split(/\r?\n/).forEach((raw, i) => {
    const line = raw.trim(); if (!line) return;
    const parts = line.split(/\t|,(?=(?:[^"]*"[^"]*")*[^"]*$)/).map((x) => x.replace(/^"|"$/g, '').trim());
    if (i === 0 && /^(name|admission|adm|learner|student|pupil)\b/i.test(parts[0])) return;          // header row
    const at = parts.findIndex((p, j) => j > 0 && /^(₦|N|NGN)?\s*[\d,]+(\.\d{1,2})?$/i.test(p));
    const kobo = at > 0 ? toKobo(parts[at]) : 0;
    if (!(kobo > 0)) { bad.push(i + 1); return; }
    const isClass = (p) => /^(jss|ss|sss|basic|primary|pry|nursery|kg|kindergarten|creche|year)\s*\d*\s*[a-z]?$/i.test(p);
    const ref = parts.slice(0, at).filter((p, j) => j === 0 || !isClass(p)).join(' ').slice(0, 120);
    rows.push({ ref, amountKobo: kobo, note: parts.slice(at + 1).join(', ').slice(0, 300) || null });
  });
  return { rows, bad };
}
const DEBT_LABEL = { ok: 'ready', not_found: 'not found', ambiguous: 'two learners share this name: use the admission number', exists: 'already has an old-debt bill', duplicate: 'listed twice' };
export async function oldDebts(view) {
  const box = h('div');
  view.appendChild(pageHead('Old Debts', 'Fees learners still owe from before (last term, or from your old system). Each learner gets one "brought forward" bill that parents see and can pay.',
    can('fees.create') ? btn('Add old debts', () => addDialog(), { kind: 'primary', ic: 'plus' }) : null));
  view.appendChild(box);
  async function load() {
    clear(box).appendChild(spinner());
    try {
      const d = await api.get('/fees/arrears'); const t = d.totals;
      clear(box).append(h('div.stats', stat('Learners', String(t.learners), 'with old debts', 'users'), stat('Billed', naira(t.billedKobo), '', 'wallet'),
        stat('Paid so far', naira(t.paidKobo), `${t.settled} fully paid`, 'money'), stat('Still owed', naira(t.owedKobo), '', 'money', t.owedKobo > 0 ? 'red' : '')),
      card('Old debts', simpleTable([{ label: 'Bill', render: (r) => h('a', { href: `#/fees/invoice/${r.id}`, text: r.invoice_no }) },
        { label: 'Learner', render: (r) => h('div', h('div', { text: `${r.last_name} ${r.first_name}` }), h('div.muted', { text: [r.admission_no, r.class_name].filter(Boolean).join(' · ') })) },
        { label: 'Note', render: (r) => r.note || '' }, { label: 'Owed', cls: 'num', render: (r) => naira(r.total_kobo) }, { label: 'Paid', cls: 'num', render: (r) => naira(r.paid_kobo) },
        { label: 'Left', cls: 'num', render: (r) => h('strong', { text: naira(r.balance_kobo) }) }, { label: 'Status', render: (r) => tone(r.status) }], d.items, 'No old debts added yet')));
    } catch (e) { errBox(box, e); }
  }
  function addDialog() {
    const ta = h('textarea.input', { rows: 8, 'aria-label': 'Old debts', placeholder: 'SA/2024/001, 15000, second term balance\nAdeyemi Tolu, JSS 2, 25000' });
    const file = h('input.input', { type: 'file', accept: '.csv,.txt', 'aria-label': 'Or choose a CSV file' });
    file.addEventListener('change', async () => { const f = file.files[0]; if (f) { ta.value = await f.text(); check(); } });
    const due = h('input.input', { type: 'date', 'aria-label': 'Pay by (optional)' });
    const out = h('div.debt-preview'); let parsed = null; let preview = null;
    const go = h('button.btn.btn-primary', { text: 'Create bills', disabled: true });
    async function check() {
      preview = null; go.disabled = true;
      parsed = parseDebtLines(ta.value);
      if (!parsed.rows.length) { clear(out).appendChild(h('p.form-alert', { text: 'No line could be read. Each line needs a name or admission number and an amount.' })); return; }
      clear(out).appendChild(spinner('Finding the learners…'));
      try {
        preview = await api.post('/fees/arrears/preview', { rows: parsed.rows }); const s = preview.summary;
        clear(out).append(h('p', h('strong', { text: `${s.ready} ready · ${naira(s.totalKobo)}` }), parsed.bad.length ? h('span.muted', { text: ` · lines that could not be read: ${parsed.bad.join(', ')}` }) : null),
          simpleTable([{ label: 'Line', render: (r) => String(r.line) }, { label: 'Typed', render: (r) => r.ref }, { label: 'Learner found', render: (r) => (r.name ? `${r.name}${r.admissionNo ? ` (${r.admissionNo})` : ''}` : '—') },
            { label: 'Amount', cls: 'num', render: (r) => naira(r.amountKobo) }, { label: '', render: (r) => badge(DEBT_LABEL[r.status], r.status === 'ok' ? 'ok' : 'warn') }], preview.items));
        go.disabled = !s.ready;
      } catch (e) { errBox(out, e); }
    }
    go.addEventListener('click', async () => {
      if (!preview || !preview.summary.ready) return;
      go.disabled = true; go.classList.add('loading');
      try { const r = await api.postOnce('/fees/arrears/import', { rows: parsed.rows, dueDate: due.value || null }); m.close(); toast(`${r.created} old-debt bill${r.created === 1 ? '' : 's'} created`); load(); }
      catch (e) { fail(e); go.disabled = false; } finally { go.classList.remove('loading'); }
    });
    const m = modal({ title: 'Add old debts', wide: true, body: [
      h('p.muted', { text: 'Paste from Excel or type one learner per line: admission number (or full name), amount, and a note if you like. Press "Check" — only lines marked ready are billed.' }),
      ta, h('div.form-grid', h('div.field', h('label', { text: 'Or choose a CSV file' }), file), h('div.field', h('label', { text: 'Pay by (optional)' }), due)), out],
    actions: [h('button.btn', { text: 'Cancel', on: { click: () => m.close() } }), h('button.btn', { text: 'Check', on: { click: check } }), go] });
  }
  load();
}

// ───────────────────────── Petty Cash ─────────────────────────
export async function pettyCash(view) {
  const box = h('div'); let filter = '';
  view.appendChild(pageHead('Petty Cash', 'Ask for small money for school spending. Another person approves it, the cashier hands it out, then you bring the receipts and any change.',
    can('pettycash.request') ? btn('Ask for petty cash', async () => {
      const r = await formDialog({ title: 'Ask for petty cash', submitLabel: 'Send request', fields: [
        { name: 'purpose', label: 'What is it for?', required: true, type: 'textarea', rows: 2, max: 300, full: true },
        { name: 'amount', label: 'Amount (₦)', required: true, type: 'number', min: 1, step: '0.01' }],
      onSubmit: (v) => api.postOnce('/pettycash/requests', { purpose: v.purpose, amountKobo: toKobo(v.amount) }) });
      if (r) { toast(`Request ${r.ref_no} sent`); load(); }
    }, { kind: 'primary', ic: 'plus' }) : null));
  const bar = h('div.range-bar.no-print'); view.append(bar, box);
  const STATES = [['', 'All'], ['pending', 'Waiting for approval'], ['approved', 'Approved — to pay out'], ['given', 'Money given'], ['settled', 'Settled'], ['rejected', 'Refused']];
  const sel = h('select.input', { 'aria-label': 'Show' }, STATES.map(([v, l]) => h('option', { value: v, text: l })));
  sel.addEventListener('change', () => { filter = sel.value; load(); }); bar.append(h('label.muted', { text: 'Show' }), sel);
  let cats = null;
  async function act(r, kind) {
    try {
      if (kind === 'approve' || kind === 'refuse') {
        const note = kind === 'refuse' ? await confirmDialog({ title: `Refuse ${r.ref_no}?`, message: `${r.purpose} · ${naira(r.amount_kobo)}`, confirmLabel: 'Refuse', danger: true, reason: true }) : true;
        if (!note) return;
        await api.post(`/pettycash/requests/${r.id}/decide`, { approve: kind === 'approve', note: kind === 'refuse' ? note : null }); toast(kind === 'approve' ? 'Approved' : 'Refused');
      } else if (kind === 'give') {
        cats = cats || (await api.get('/cashbook/categories')).items.filter((c) => c.kind === 'expense' && c.active);
        const ok = await formDialog({ title: `Hand out ${naira(r.amount_kobo)} (${r.ref_no})`, submitLabel: 'Money handed out', intro: `${r.requested_by_name}: ${r.purpose}. This is recorded in the cashbook as spent from petty cash.`,
          fields: [{ name: 'categoryId', label: 'Kind of spending', type: 'select', required: true, options: cats.map((c) => ({ value: c.id, label: c.name })) }],
          onSubmit: (v) => api.postOnce(`/pettycash/requests/${r.id}/give`, { categoryId: v.categoryId }) });
        if (!ok) return; toast('Recorded in the cashbook');
      } else if (kind === 'settle') {
        const ok = await formDialog({ title: `Settle ${r.ref_no}`, submitLabel: 'Settle', intro: `${naira(r.amount_kobo)} was handed out. Enter what was really spent (from the receipts); the rest is change back in the box.`,
          fields: [{ name: 'spent', label: 'Really spent (₦)', type: 'number', required: true, min: 0, step: '0.01' }, { name: 'note', label: 'Note (optional)', max: 300 }],
          values: { spent: Number(r.amount_kobo) / 100 }, onSubmit: (v) => api.post(`/pettycash/requests/${r.id}/settle`, { spentKobo: toKobo(v.spent), note: v.note }) });
        if (!ok) return; toast(ok.returnedKobo > 0 ? `Settled — ${naira(ok.returnedKobo)} change back in petty cash` : 'Settled');
      } else if (kind === 'cancel') {
        if (!(await confirmDialog({ title: `Cancel ${r.ref_no}?`, message: r.purpose, confirmLabel: 'Cancel request', danger: true }))) return;
        await api.post(`/pettycash/requests/${r.id}/cancel`); toast('Cancelled');
      }
      load();
    } catch (e) { fail(e); }
  }
  async function load() {
    clear(box).appendChild(spinner());
    try {
      const d = await api.get(`/pettycash/requests${qs({ status: filter })}`); const n = (s) => (d.counts[s] || { n: 0, kobo: 0 });
      const me = (session.me && session.me.user) || {};
      clear(box).append(h('div.stats', stat('Waiting for approval', String(n('pending').n), naira(n('pending').kobo), 'clock', n('pending').n ? 'gold' : ''),
        stat('To pay out', String(n('approved').n), naira(n('approved').kobo), 'wallet'), stat('Money given, not settled', String(n('given').n), naira(n('given').kobo), 'money'),
        d.boxKobo !== null ? stat('In the petty-cash box', naira(d.boxKobo), 'top up in the Cashbook', 'wallet', d.boxKobo > 0 ? 'gold' : '') : null),
      card('Requests', simpleTable([{ label: 'Ref.', render: (r) => r.ref_no }, { label: 'Asked by', render: (r) => h('div', h('div', { text: r.requested_by_name }), h('div.muted', { text: date(r.created_at) })) },
        { label: 'For', render: (r) => h('div', h('div', { text: r.purpose }), r.decision_note ? h('div.muted', { text: r.decision_note }) : null, r.status === 'settled' ? h('div.muted', { text: `Spent ${naira(r.spent_kobo)} · change ${naira(r.returned_kobo)}` }) : null) },
        { label: 'Amount', cls: 'num', render: (r) => naira(r.amount_kobo) }, { label: 'Status', render: (r) => tone(r.status) },
        { label: '', render: (r) => h('div.row-actions',
          d.can.approve && r.status === 'pending' && r.requested_by !== me.id ? [btn('Approve', () => act(r, 'approve'), { kind: 'primary' }), btn('Refuse', () => act(r, 'refuse'), { kind: 'ghost' })] : null,
          d.can.pay && r.status === 'approved' ? btn('Hand out', () => act(r, 'give'), { kind: 'primary' }) : null,
          d.can.pay && r.status === 'given' ? btn('Settle', () => act(r, 'settle')) : null,
          ['pending', 'approved'].includes(r.status) && (r.requested_by === me.id || d.can.approve) ? btn('Cancel', () => act(r, 'cancel'), { kind: 'ghost' }) : null) }],
      d.items, 'No petty cash requests yet')));
    } catch (e) { errBox(box, e); }
  }
  load();
}

// ───────────────────────── Reminders & Alerts ─────────────────────────
export async function alertsPage(view) {
  const box = h('div');
  view.appendChild(pageHead('Reminders & Alerts', 'Things that need attention, worked out from your records each time you open this page.'));
  view.appendChild(box);
  async function load() {
    clear(box).appendChild(spinner());
    try {
      const d = await api.get('/alerts'); const R = d.rules; const w = d.waiting;
      const parts = [];
      parts.push(h('div.stats', d.fees ? stat('Fees overdue', String(d.fees.count), naira(d.fees.totalKobo), 'wallet', d.fees.count ? 'red' : '') : null,
        d.attendance ? stat(`Attendance below ${R.attendanceFloor}%`, String(d.attendance.count), d.term ? `${tn(d.term.name)} term` : '', 'users', d.attendance.count ? 'gold' : '') : null,
        d.stock ? stat('Store items running low', String(d.stock.count), '', 'layers', d.stock.count ? 'gold' : '') : null,
        stat('Waiting for you', String(Object.values(w).reduce((a, n) => a + (n || 0), 0)), 'approvals', 'clock')));
      if (d.subscription) parts.push(h('div.form-alert', { role: 'status', text: `Your A.B.O. subscription (${d.subscription.status}) ends in ${d.subscription.daysLeft} day${d.subscription.daysLeft === 1 ? '' : 's'}. Open School › Subscription to renew.` }));
      const waits = [[w.pettyCash, 'petty cash request(s) to approve', '#/petty-cash'], [w.pettyCashToPay, 'petty cash request(s) to pay out or settle', '#/petty-cash'],
        [w.questions, 'question(s) from teachers to check', '#/cbt/review'], [w.discounts, 'fee discount(s) to approve', '#/fees/setup']].filter(([n]) => n);
      if (waits.length) parts.push(card('Waiting for you', h('ul.plain-list', waits.map(([n, t, href]) => h('li', h('a', { href }, h('strong', { text: String(n) }), ` ${t}`))))));
      if (d.fees) {
        parts.push(card(R.feeOverdueDays ? `Fees overdue (more than ${R.feeOverdueDays} day${R.feeOverdueDays === 1 ? '' : 's'} after the due date)` : 'Fees overdue (past the due date)', d.fees.items.length ? simpleTable([
          { label: 'Learner', render: (f) => h('div', h('div', { text: `${f.last_name} ${f.first_name}` }), h('div.muted', { text: f.admission_no || '' })) },
          { label: 'Bill', render: (f) => h('a', { href: `#/fees/invoice/${f.id}`, text: f.invoice_no }) }, { label: 'Due', render: (f) => date(f.due) },
          { label: 'Owed', cls: 'num', render: (f) => naira(f.balance_kobo) }, { label: 'Last reminder', render: (f) => (f.last_reminded ? dateTime(f.last_reminded) : '—') }], d.fees.items) : empty('No overdue fees', 'Everyone is up to date.'),
        d.can.remind && d.fees.items.length ? btn('Remind all these parents', async () => {
          if (!(await confirmDialog({ title: 'Send fee reminders?', message: `Parents of ${d.fees.items.length} learner(s) get a reminder in the app, and by e-mail when the school has their address. Nobody is reminded twice in one day.`, confirmLabel: 'Send reminders' }))) return;
          try { const r = await api.post('/alerts/fee-reminders', { invoiceIds: d.fees.items.map((f) => f.id) }); toast(`${r.sent} reminder(s) sent${r.skippedRecent ? ` · ${r.skippedRecent} already reminded today` : ''}${r.noParentContact ? ` · ${r.noParentContact} with no parent contact` : ''}`); load(); } catch (e) { fail(e); }
        }, { kind: 'primary', ic: 'message' }) : null));
      }
      if (d.attendance) parts.push(card(`Learners below ${R.attendanceFloor}% attendance this term`, simpleTable([{ label: 'Learner', render: (a) => `${a.last_name} ${a.first_name}` }, { key: 'class_name', label: 'Class' },
        { label: 'Days marked', cls: 'num', render: (a) => String(a.days) }, { label: 'Came', cls: 'num', render: (a) => String(a.present) }, { label: 'Rate', cls: 'num', render: (a) => h('strong', { text: `${a.rate}%` }) }], d.attendance.items, 'Nobody is below the floor')));
      if (d.stock && d.stock.items.length) parts.push(card('Store items running low', simpleTable([{ key: 'name', label: 'Item' }, { label: 'In stock', cls: 'num', render: (s) => String(s.stock_qty) }, { label: 'Reorder at', cls: 'num', render: (s) => String(s.reorder_level) }], d.stock.items)));
      if (d.can.manage) parts.push(card('Rules', h('p.muted', { text: `Fees count as overdue ${R.feeOverdueDays} day(s) after the due date (bills with no due date: after the day they were issued). Attendance floor ${R.attendanceFloor}%. Low stock alerts ${R.lowStock ? 'on' : 'off'}.` }),
        btn('Change rules', async () => {
          const r = await formDialog({ title: 'Alert rules', fields: [{ name: 'feeOverdueDays', label: 'Days after the due date before fees count as overdue', type: 'number', min: 0, maxv: 365, required: true },
            { name: 'attendanceFloor', label: 'Attendance floor (%)', type: 'number', min: 0, maxv: 100, required: true }, { name: 'lowStock', label: 'Warn when store items run low', type: 'checkbox' }],
          values: R, onSubmit: (v) => api.put('/alerts/rules', { feeOverdueDays: Math.round(v.feeOverdueDays), attendanceFloor: Math.round(v.attendanceFloor), lowStock: v.lowStock }) });
          if (r) { toast('Rules saved'); load(); }
        })));
      clear(box).append(...parts);
    } catch (e) { errBox(box, e); }
  }
  load();
}

// ───────────────────────── Questions from Teachers ─────────────────────────
export async function questionReview(view) {
  const box = h('div');
  view.appendChild(pageHead('Questions from Teachers', 'When approval is switched on, questions teachers add to the question bank wait here. Approve them into the bank, or send them back with a note.'));
  view.appendChild(box);
  async function setApproval(on) { try { await api.put('/cbt/settings', { bankApproval: on }); toast(on ? 'Approval switched on' : 'Approval switched off'); load(); } catch (e) { fail(e); } }
  async function load() {
    clear(box).appendChild(spinner());
    try {
      const d = await api.get('/cbt/bank/review');
      const head = card('Approval of teachers\' questions', h('p', { text: d.approvalOn ? 'On — questions from teachers wait here before they can be used in a test.' : 'Off — teachers\' questions go straight into the bank.' }),
        can('settings.update') || can('cbt.publish') ? btn(d.approvalOn ? 'Switch off' : 'Switch on', () => setApproval(!d.approvalOn), { kind: d.approvalOn ? 'ghost' : 'primary' }) : null);
      const list = d.items.length ? h('div.q-review', d.items.map((q) => card(null, [
        h('div.muted', { text: [q.subject, q.class_name, q.topic, `by ${q.submitted_by || 'a teacher'}`, date(q.created_at)].filter(Boolean).join(' · ') }),
        h('p', h('strong', { text: q.text })),
        q.options && q.options.length ? h('ol.q-options', { type: 'A' }, q.options.map((o) => h('li', { class: o.isCorrect ? 'correct' : '' }, o.text, o.isCorrect ? h('span.badge.badge-ok', { text: 'answer' }) : null))) : null,
        h('div.row-actions', btn('Approve into the bank', async () => { try { await api.post(`/cbt/bank/${q.id}/review`, { approve: true }); toast('Added to the question bank'); load(); } catch (e) { fail(e); } }, { kind: 'primary' }),
          btn('Send back', async () => { const note = await confirmDialog({ title: 'Send this question back?', message: 'Tell the teacher what to fix.', confirmLabel: 'Send back', reason: true }); if (!note) return; try { await api.post(`/cbt/bank/${q.id}/review`, { approve: false, note }); toast('Sent back to the teacher'); load(); } catch (e) { fail(e); } }, { kind: 'ghost' }))])))
        : empty('No question is waiting', d.approvalOn ? 'New questions from teachers will appear here.' : 'Switch approval on to check teachers\' questions first.');
      clear(box).append(head, h('div.stats', stat('Waiting', String(d.counts.pending), '', 'clock', d.counts.pending ? 'gold' : ''), stat('Sent back', String(d.counts.rejected), 'being fixed by teachers', 'message')), list);
    } catch (e) { errBox(box, e); }
  }
  load();
}

// ───────────────────────── Devices ─────────────────────────
const KINDS = [['fingerprint', 'Fingerprint reader'], ['card', 'Card scanner'], ['tablet', 'Tablet'], ['phone', 'Phone'], ['computer', 'Computer'], ['camera', 'Camera'], ['other', 'Other']];
const kindLabel = (k) => (KINDS.find((x) => x[0] === k) || [k, k])[1];
export async function devices(view) {
  const box = h('div'); const manage = can('devices.manage');
  const fields = [{ name: 'name', label: 'Name', required: true, max: 80 }, { name: 'kind', label: 'Type', type: 'select', required: true, options: KINDS.map(([value, label]) => ({ value, label })) },
    { name: 'serial', label: 'Serial / IMEI', max: 80 }, { name: 'location', label: 'Where it is', max: 120 },
    { name: 'status', label: 'Status', type: 'select', placeholder: false, options: [{ value: 'active', label: 'Working' }, { value: 'repair', label: 'In repair' }, { value: 'retired', label: 'Retired' }] },
    { name: 'notes', label: 'Notes', type: 'textarea', rows: 2, max: 300, full: true }];
  const edit = async (d) => { const r = await formDialog({ title: d ? `Edit ${d.name}` : 'Add a device', fields, values: d || { status: 'active' }, onSubmit: (v) => (d ? api.patch(`/devices/${d.id}`, v) : api.post('/devices', v)) }); if (r) { toast('Saved'); load(); } };
  view.appendChild(pageHead('Devices', 'Fingerprint readers, card scanners, tablets and other equipment the school uses.', manage ? btn('Add a device', () => edit(null), { kind: 'primary', ic: 'plus' }) : null, printBtn()));
  view.appendChild(box);
  async function load() {
    clear(box).appendChild(spinner());
    try {
      const d = await api.get('/devices');
      clear(box).append(h('div.stats.no-print', stat('Devices', String(d.counts.total), '', 'layers'), stat('Working', String(d.counts.active), '', 'check'), stat('In repair', String(d.counts.repair), '', 'settings', d.counts.repair ? 'gold' : '')),
        card('Device list', simpleTable([{ key: 'name', label: 'Name' }, { label: 'Type', render: (r) => kindLabel(r.kind) }, { key: 'serial', label: 'Serial / IMEI' }, { key: 'location', label: 'Where' },
          { label: 'Status', render: (r) => tone(r.status) }, { label: '', render: (r) => (manage ? h('div.row-actions.no-print', btn('Edit', () => edit(r), { kind: 'ghost' }),
            btn('Remove', async () => { if (!(await confirmDialog({ title: `Remove ${r.name}?`, message: 'Use "Retired" instead if you want to keep it on record.', confirmLabel: 'Remove', danger: true }))) return; try { await api.del(`/devices/${r.id}`); toast('Removed'); load(); } catch (e) { fail(e); } }, { kind: 'ghost' })) : null) }],
        d.items, 'No device added yet')));
    } catch (e) { errBox(box, e); }
  }
  load();
}

// ───────────────────────── Print Centre ─────────────────────────
export async function printCentre(view) {
  view.appendChild(pageHead('Print Centre', 'Every printable document in one place. In the print window choose "Save as PDF" to keep a copy, and Landscape for wide sheets.'));
  const docs = [
    ['Class score sheet (broadsheet)', 'Every subject with CA, exam, totals, grades and positions.', '#/broadsheet/terminal', ['results.view']],
    ['Report cards', 'Termly report cards for one learner or a whole class.', '#/reports/class', ['results.view']],
    ['Results so far (cumulative)', 'All terms of the session together.', '#/broadsheet/cumulative', ['results.view']],
    ['ID cards', 'Learner and staff ID cards with photos and barcodes.', '#/id-cards', ['students.view', 'staff.view']],
    ['Blank attendance register', 'Class list with day columns and a signature line.', '#/print/register', ['attendance.view', 'attendance.create', 'students.view']],
    ['Attendance report', 'How often each learner came this term.', '#/print/attendance', ['attendance.view', 'attendance.create']],
    ['Class timetable', 'Monday to Friday periods.', '#/academic/timetable', ['academic.view']],
    ['Bills and receipts', 'Fee bills and payment receipts.', '#/fees/invoices', ['fees.view']],
    ['Old debts', 'Fees owed from before, per learner.', '#/fees/arrears', ['fees.view']],
    ['Store stock sheet', 'Stock levels, values and items to reorder.', '#/print/stock', ['store.view', 'store.manage']],
    ['Cash ledger', 'Money in and out with a running balance.', '#/print/ledger', ['cashbook.view']],
    ['Devices list', 'School equipment and where it is.', '#/devices', ['devices.view']],
    ['Login code slips', 'Sign-in slips for staff, learners and parents.', '#/users', ['users.create']],
    ['Download and backups', 'Excel / CSV exports and a full backup of the school.', '#/backup', ['reports.export', 'imports.run']],
  ].filter((d) => can(...d[3]));
  view.appendChild(h('div.print-grid', docs.map(([t, s, href]) => h('a.card.print-card', { href }, h('h2', { text: t }), h('p.muted', { text: s })))));
}
async function classPicker(onPick, label = 'Class') {
  const opts = await classOptions();
  const sel = h('select.input', { 'aria-label': label }, h('option', { value: '', text: 'Choose a class…' }), opts.map((o) => h('option', { value: o.value, text: o.label })));
  sel.addEventListener('change', () => { if (sel.value) onPick(sel.value); });
  return h('div.range-bar.no-print', h('label.muted', { text: label }), sel);
}
export async function printRegister(view, p, q) {
  const box = h('div'); const days = 10;
  view.appendChild(pageHead('Blank attendance register', 'A class list for marking by hand, with day columns and a signature line.', printBtn()));
  const load = async (classId) => {
    clear(box).appendChild(spinner());
    try {
      const d = await api.get(`/print/register${qs({ classId })}`);
      const head = h('tr', h('th', { text: 'No.' }), h('th', { text: 'Name' }), h('th', { text: 'Adm. No' }), Array.from({ length: days }, () => h('th.reg-day', { text: '' })), h('th', { text: 'Remarks' }));
      const body = h('tbody', d.items.map((s, i) => h('tr', h('td.center', { text: String(i + 1) }), h('td.nowrap', { text: `${s.last_name} ${s.first_name}` }), h('td', { text: s.admission_no || '' }),
        Array.from({ length: days }, () => h('td.reg-day')), h('td'))));
      clear(box).appendChild(h('div.doc.landscape', docHead([`Attendance register · ${d.className}`, d.term ? `${d.term.session} · ${tn(d.term.name)} term` : '', 'Week starting: ______________']),
        h('div.table-wrap', h('table.terminal.register', h('thead', head), body)),
        h('p.sign-line', { text: 'Class teacher: ____________________   Signature: ____________   Date: __________' })));
    } catch (e) { errBox(box, e); }
  };
  view.append(await classPicker(load), box);
  if (q && q.classId) load(q.classId);
}
export async function printAttendance(view, p, q) {
  const box = h('div');
  view.appendChild(pageHead('Attendance report', 'How often each learner came to school this term.', printBtn()));
  const load = async (classId) => {
    clear(box).appendChild(spinner());
    try {
      const [d, a] = await Promise.all([api.get(`/attendance/summary${qs({ classId })}`), academic()]);
      const cls = a.classes.find((c) => c.id === classId) || {};
      const rows = d.items.map((r) => { const marked = r.present + r.absent; return { ...r, marked, rate: marked ? Math.round((r.present / marked) * 1000) / 10 : null }; });
      clear(box).appendChild(h('div.doc', docHead([`Attendance report · ${cls.display_name || cls.name || ''}`]),
        simpleTable([{ label: 'Learner', render: (r) => `${r.last_name} ${r.first_name}` }, { label: 'Adm. No', render: (r) => r.admission_no || '' }, { label: 'Present', cls: 'num', render: (r) => String(r.present) },
          { label: 'Late', cls: 'num', render: (r) => String(r.late) }, { label: 'Absent', cls: 'num', render: (r) => String(r.absent) }, { label: 'Excused', cls: 'num', render: (r) => String(r.excused) },
          { label: 'Rate', cls: 'num', render: (r) => (r.rate === null ? '—' : `${r.rate}%`) }], rows, 'No attendance marked yet')));
    } catch (e) { errBox(box, e); }
  };
  view.append(await classPicker(load), box);
  if (q && q.classId) load(q.classId);
}
export async function printStock(view) {
  const box = h('div');
  view.appendChild(pageHead('Store stock sheet', 'Stock levels, values and items to reorder.', printBtn()));
  view.appendChild(box);
  try {
    const d = await api.get('/print/stock');
    box.appendChild(h('div.doc', docHead([`Stock sheet · ${date(ymd(new Date()))}`]),
      simpleTable([{ key: 'name', label: 'Item' }, { label: 'Category', render: (r) => r.category || '' }, { label: 'In stock', cls: 'num', render: (r) => String(r.stock_qty) },
        { label: 'Price', cls: 'num', render: (r) => naira(r.unit_price_kobo) }, { label: 'Value', cls: 'num', render: (r) => naira(r.value_kobo) },
        { label: 'Reorder', render: (r) => (r.low ? badge('reorder', 'warn') : '') }, { label: 'Counted', render: () => '________' }], d.items, 'No store items'),
      h('p', h('strong', { text: `Total value at selling price: ${naira(d.totalValueKobo)} · ${d.low} item(s) to reorder` }))));
  } catch (e) { errBox(box, e); }
}
export async function printLedger(view) {
  const box = h('div'); const now = new Date();
  let from = ymd(new Date(now.getFullYear(), now.getMonth(), 1)); let to = ymd(now);
  view.appendChild(pageHead('Cash ledger', 'Money in and out of the cashbook, with a running balance.', printBtn()));
  const f = h('input.input', { type: 'date', value: from, 'aria-label': 'From' }); const t = h('input.input', { type: 'date', value: to, 'aria-label': 'To' });
  const load = async () => {
    from = f.value || from; to = t.value || to; clear(box).appendChild(spinner());
    try {
      const d = await api.get(`/print/ledger${qs({ from, to })}`);
      clear(box).appendChild(h('div.doc', docHead([`Cash ledger · ${date(from)} – ${date(to)}`]),
        h('p', { text: `Opening balance: ${naira(d.openingKobo)}` }),
        simpleTable([{ label: 'Date', render: (r) => date(r.date) }, { key: 'category', label: 'Category' }, { label: 'Details', render: (r) => [r.description, r.party, r.reference].filter(Boolean).join(' · ') },
          { label: 'In', cls: 'num', render: (r) => (r.kind === 'income' ? naira(r.amount_kobo) : '') }, { label: 'Out', cls: 'num', render: (r) => (r.kind === 'expense' ? naira(r.amount_kobo) : '') },
          { label: 'Balance', cls: 'num', render: (r) => (r.method === 'petty_cash' ? 'petty cash' : naira(r.balance_kobo)) }], d.items, 'Nothing recorded in these dates'),
        h('p', h('strong', { text: `Closing balance: ${naira(d.closingKobo)}` })), h('p.muted', { text: d.note })));
    } catch (e) { errBox(box, e); }
  };
  f.addEventListener('change', load); t.addEventListener('change', load);
  view.append(h('div.range-bar.no-print', h('label.muted', { text: 'From' }), f, h('label.muted', { text: 'to' }), t), box);
  load();
}

// ───────────────────────── Score Sheet Layout ─────────────────────────
export async function sheetLayout(view) {
  const box = h('div');
  view.appendChild(pageHead('Score Sheet Layout', 'Choose what prints on the class score sheet (CA & Exam). Marks, maximums and grades are set in General Settings.'));
  view.appendChild(box);
  try {
    const { layout } = await api.get('/broadsheet/layout');
    const fields = [{ name: 'title', label: 'Title (leave empty for "Terminal broadsheet")', max: 120, full: true },
      { name: 'showBreakdown', label: 'Show CA and Exam for each subject (not only the total)', type: 'checkbox' }, { name: 'showPosition', label: 'Show position', type: 'checkbox' },
      { name: 'showTotal', label: 'Show overall total', type: 'checkbox' }, { name: 'showAverage', label: 'Show average', type: 'checkbox' }, { name: 'showGrade', label: 'Show grade', type: 'checkbox' },
      { name: 'showStatus', label: 'Show pass / fail', type: 'checkbox' }, { name: 'footer', label: 'Footer (for example: Principal: ________  Date: ______)', type: 'textarea', rows: 2, max: 300, full: true }];
    const editable = can('settings.update');
    box.appendChild(card('Current layout', h('div.form-grid', fields.map((fd) => h('div.field', h('label', { text: fd.label }), h('div', { text: fd.type === 'checkbox' ? (layout[fd.name] ? 'Yes' : 'No') : (layout[fd.name] || '—') })))),
      editable ? btn('Change layout', async () => {
        const r = await formDialog({ title: 'Score sheet layout', wide: true, fields, values: layout, onSubmit: (v) => api.put('/broadsheet/layout', { ...v, title: v.title || '', footer: v.footer || '' }) });
        if (r) { toast('Layout saved'); location.hash = '#/broadsheet/layout?saved=' + Date.now(); }
      }, { kind: 'primary' }) : null, btn('See the score sheet', () => { location.hash = '#/broadsheet/terminal'; }, { kind: 'ghost' })));
  } catch (e) { errBox(box, e); }
}
