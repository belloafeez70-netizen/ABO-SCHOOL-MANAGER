// CBT — candidate side: My CBT list, the exam interface (bare page, mobile-first), and the result page.
// The server is authoritative for time, marking and answers; the browser only keeps a small queue of answers that
// have not reached the server yet (so a brief connection drop never loses work). The queue is cleared on sync/submit.
import { h, clear, icon, append } from '../core/dom.js';
import { api } from '../core/api.js';
import { pageHead, btn, badge, card, toast, confirmDialog, simpleTable, empty, spinner, modal, errMsg } from '../core/ui.js';
import { dateTime } from '../core/format.js';
import { renderRich } from '../core/mathtext.js';
import { fileUrl } from '../core/config.js';

const LET = 'ABCDEF';
const mmss = (ms) => { const s = Math.max(0, Math.floor(ms / 1000)); const hh = Math.floor(s / 3600); const m = Math.floor((s % 3600) / 60); const ss = s % 60; return `${hh ? `${hh}:` : ''}${String(m).padStart(2, '0')}:${String(ss).padStart(2, '0')}`; };

export async function myCbt(view) {
  const [av, mine] = await Promise.all([api.get('/cbt/available'), api.get('/cbt/my-results')]);
  view.appendChild(pageHead('My CBT Exams', 'Examinations assigned to you. The timer is controlled by the school server; answers save automatically.'));
  const now = Date.now();
  view.appendChild(card('Examinations', av.items.length ? h('div.exam-cards', av.items.map((x) => {
    const notYet = x.starts_at && new Date(x.starts_at).getTime() > now;
    const done = x.attempts_used >= x.max_attempts && !x.live_attempt;
    return h('div.exam-card', h('div', h('strong', { text: x.title }), h('div.muted', { text: `${x.subject || 'General'}${x.class_name ? ` · ${x.class_name}` : ''}` }),
      h('div.chips', h('span.chip', icon('clock', 14), `${x.duration_minutes} min`), h('span.chip', icon('book', 14), `${x.questions} questions`), h('span.chip', icon('check', 14), `${x.attempts_used}/${x.max_attempts} attempts`), x.needs_code ? h('span.chip', icon('key', 14), 'access code') : null),
      h('small.muted', { text: notYet ? `Opens ${dateTime(x.starts_at)}` : x.ends_at ? `Closes ${dateTime(x.ends_at)}` : 'Open' })),
    x.live_attempt ? h('a.btn.btn-primary', { href: `#/take/${x.id}`, text: 'Resume' }) : done ? badge('completed', 'ok') : notYet ? badge('scheduled', 'info') : h('a.btn.btn-primary', { href: `#/take/${x.id}`, text: 'Start' }));
  })) : empty('No examinations right now', 'Your teacher will assign CBT examinations to you.')));
  view.appendChild(card('My results', simpleTable([{ key: 'title', label: 'Examination' }, { label: 'Subject', render: (x) => x.subject || '—' }, { label: 'Submitted', render: (x) => dateTime(x.submitted_at) },
    { label: 'Score', render: (x) => (x.released ? `${x.score}/${x.max_score} (${x.percentage}%)` : x.needs_manual_grading ? 'being marked' : 'not released yet') },
    { label: 'Result', render: (x) => (x.released ? (x.passed ? badge('PASS', 'ok') : badge('FAIL', 'danger')) : '—') }, { label: '', render: (x) => (x.released ? h('a.btn.btn-sm', { href: `#/cbt/result/${x.id}`, text: 'View' }) : '') }], mine.items, 'No results yet')));
}

// ── the exam interface ──
export async function take(root, p) {
  root.classList.add('cbt-root');
  // pre-exam screen (no attempt is created until the candidate presses Begin)
  let info;
  try { info = (await api.get('/cbt/available')).items.find((x) => x.id === p.id); } catch (e) { info = null; }
  if (!info) { root.appendChild(h('div.cbt-center', card('Examination not available', [h('p.muted', { text: 'It may have closed, or it is not assigned to you.' }), h('a.btn', { href: '#/my-cbt', text: 'Back to My CBT' })]))); return; }
  const code = h('input.input.code-input', { placeholder: 'Access code', autocomplete: 'off', maxlength: 40, 'aria-label': 'Access code' });
  const alert = h('div.form-alert', { role: 'alert', hidden: true });
  const begin = h('button.btn.btn-primary.btn-lg', { type: 'button', text: info.live_attempt ? 'Resume examination' : 'Begin examination' });
  root.appendChild(h('div.cbt-center', h('section.card.cbt-intro', h('div.card-body',
    h('h1', { text: info.title }), h('p.muted', { text: `${info.subject || 'General'}${info.class_name ? ` · ${info.class_name}` : ''}` }),
    h('div.chips', h('span.chip', icon('clock', 14), `${info.duration_minutes} minutes`), h('span.chip', icon('book', 14), `${info.questions} questions`), h('span.chip', icon('check', 14), `Attempt ${info.attempts_used + (info.live_attempt ? 0 : 1)} of ${info.max_attempts}`)),
    info.instructions ? h('div.cbt-instr', renderRich(info.instructions)) : null,
    h('ul.cbt-rules', ['The timer starts when you press Begin and keeps running even if you close the page.', 'Answers are saved automatically. If your connection drops, keep going — they sync when it returns.', 'Leaving the exam window is recorded.', 'The exam is submitted automatically when time runs out.'].map((t) => h('li', { text: t }))),
    info.needs_code && !info.live_attempt ? h('div.field', h('label', { text: 'Access code from the invigilator' }), code) : null, alert,
    h('div.page-actions', h('a.btn', { href: '#/my-cbt', text: 'Back' }), begin)))));
  begin.addEventListener('click', async () => {
    alert.hidden = true; begin.disabled = true;
    try {
      if (info.fullscreen && document.documentElement.requestFullscreen) await document.documentElement.requestFullscreen().catch(() => {});
      const paper = await api.post(`/cbt/exams/${p.id}/start`, info.needs_code && !info.live_attempt ? { accessCode: code.value.trim() } : {});
      if (paper.resumeBlocked) { clear(root).appendChild(h('div.cbt-center', card('Examination submitted', [h('p', { text: paper.message }), h('a.btn', { href: '#/my-cbt', text: 'Back to My CBT' })]))); return; }
      clear(root); runExam(root, paper);
    } catch (e) { alert.textContent = errMsg(e); alert.hidden = false; begin.disabled = false; }
  });
}

function runExam(root, paper) {
  const S = paper.settings; const Qs = paper.questions; const N = Qs.length;
  const skew = new Date(paper.serverNow).getTime() - Date.now();          // anchor the countdown to the SERVER clock
  let deadline = new Date(paper.deadlineAt).getTime();
  const state = new Map(Qs.map((q) => [q.id, { optionId: q.answer ? q.answer.optionId : null, optionIds: q.answer ? (q.answer.optionIds || []) : [], text: q.answer ? q.answer.text : null, flagged: q.flagged }]));
  const QKEY = `abo.cbt.pending.${paper.attemptId}`;
  const pending = new Map(); let pendingTime = new Map();
  try { for (const [k, v] of Object.entries(JSON.parse(localStorage.getItem(QKEY) || '{}'))) if (state.has(k)) { pending.set(k, v); state.set(k, { ...state.get(k), ...v }); } } catch { /* ignore */ }
  const persist = () => { try { if (pending.size) localStorage.setItem(QKEY, JSON.stringify(Object.fromEntries(pending))); else localStorage.removeItem(QKEY); } catch { /* private mode */ } };
  let cur = Math.min(paper.furthestIndex || 0, N - 1); let furthest = paper.furthestIndex || 0; let done = false; let online = true; let shownAt = Date.now();
  const answered = (s) => !!(s.optionId || (s.optionIds && s.optionIds.length) || (s.text && String(s.text).trim()));
  // ── layout ──
  const timer = h('div.cbt-timer', { role: 'timer', 'aria-live': 'off' });
  const net = h('div.cbt-net', { role: 'status', 'aria-live': 'polite' });
  const offline = h('div.cbt-offline', { role: 'alert', hidden: true, text: 'Connection temporarily unavailable. Your saved answers are being protected. Please reconnect.' });
  const header = h('header.cbt-head',
    h('div.cbt-school', paper.school.logoFileId ? h('img', { src: fileUrl(paper.school.logoFileId), alt: '' }) : null, h('div', h('strong', { text: paper.school.name }), h('small', { text: `${paper.title}` }))),
    h('div.cbt-meta', h('span', { text: [paper.subject, paper.className].filter(Boolean).join(' · ') }), h('span', { text: `${paper.student.name} · ${paper.student.admissionNo}` })),
    h('div.cbt-right', net, timer));
  const qArea = h('section.cbt-q', { 'aria-live': 'polite' });
  const navGrid = h('div.cbt-grid', { role: 'list' });
  const navToggle = h('button.btn.cbt-navtoggle', { type: 'button', 'aria-expanded': 'false', on: { click: () => { const open = !panel.classList.contains('open'); panel.classList.toggle('open', open); navToggle.setAttribute('aria-expanded', String(open)); } } });
  const legend = h('div.cbt-legend', h('span', h('i.st-cur'), 'Current'), h('span', h('i.st-ans'), 'Answered'), h('span', h('i.st-flag'), 'For review'), h('span', h('i.st-un'), 'Unanswered'));
  const submitBtn = h('button.btn.btn-primary.cbt-submit', { type: 'button', text: 'Submit exam', on: { click: () => (S.allowReview ? reviewScreen() : confirmSubmit()) } });
  const panel = h('aside.cbt-panel', h('div.cbt-panel-head', h('strong', { text: 'Questions' })), navGrid, legend, submitBtn);
  const main = h('div.cbt-main', qArea, panel);
  root.append(header, offline, navToggle, main);
  const navBtns = Qs.map((q, i) => { const b = h('button.cbt-nb', { type: 'button', role: 'listitem', text: String(i + 1).padStart(2, '0'), 'aria-label': `Question ${i + 1}`, on: { click: () => go(i) } }); navGrid.appendChild(b); return b; });
  const paintNav = () => {
    let a = 0; let f = 0;
    Qs.forEach((q, i) => { const s = state.get(q.id); const b = navBtns[i]; const isA = answered(s); if (isA) a++; if (s.flagged) f++;
      b.className = `cbt-nb${i === cur ? ' cur' : ''}${isA ? ' ans' : ''}${s.flagged ? ' flag' : ''}`; b.disabled = !S.allowBackNav && i < furthest && i !== cur; b.setAttribute('aria-current', i === cur ? 'true' : 'false'); });
    clear(navToggle).append(icon('grid', 16), h('span', { text: `Questions · ${a}/${N} answered${f ? ` · ${f} marked for review` : ''}` }));
  };
  // ── saving ──
  let flushing = false; let saveTimer = null;
  const setNet = (ok, msg) => { online = ok; net.className = `cbt-net ${ok ? 'ok' : 'bad'}`; net.textContent = msg || (ok ? (pending.size ? 'Saving…' : 'All answers saved') : 'Offline'); offline.hidden = ok; };
  const markDirty = (qid, immediate) => { const s = state.get(qid); pending.set(qid, { optionId: s.optionId, optionIds: s.optionIds, text: s.text, flagged: s.flagged }); persist(); paintNav(); setNet(online, online ? 'Saving…' : 'Offline'); clearTimeout(saveTimer); saveTimer = setTimeout(flush, immediate ? 0 : 1500); };
  const takeTime = () => { const q = Qs[cur]; if (!q) return; const secs = Math.round((Date.now() - shownAt) / 1000); shownAt = Date.now(); if (secs > 0) pendingTime.set(q.id, Math.min(3600, (pendingTime.get(q.id) || 0) + secs)); };
  async function flush() {
    if (flushing || done || (!S.autosave && !flush.force)) return; if (!pending.size && !pendingTime.size) return;
    flushing = true;
    const ids = new Set([...pending.keys(), ...[...pendingTime.keys()].filter((k) => pending.has(k) || answered(state.get(k)) || state.get(k).flagged)]);
    const batch = [...ids].map((id) => { const s = state.get(id); return { questionId: id, optionId: s.optionId || null, optionIds: s.optionIds && s.optionIds.length ? s.optionIds : undefined, text: s.text ?? null, flagged: !!s.flagged, timeSpent: pendingTime.get(id) || 0 }; });
    const sent = new Map(batch.map((b) => [b.questionId, JSON.stringify(pending.get(b.questionId))])); const sentTime = new Map(pendingTime); pendingTime = new Map();
    try {
      const r = await api.put(`/cbt/attempts/${paper.attemptId}/answers`, { answers: batch.slice(0, 200) });
      if (r.timeUp) { flushing = false; return finished(true, r.message); }
      if (r.deadlineAt) deadline = new Date(r.deadlineAt).getTime();
      for (const [id, snap] of sent) if (JSON.stringify(pending.get(id)) === snap) pending.delete(id);      // keep edits made while the request was in flight
      persist(); setNet(true);
    } catch (e) {
      for (const [k, v] of sentTime) pendingTime.set(k, (pendingTime.get(k) || 0) + v);
      if (e.status === 0) setNet(false);
      else if (e.status === 409 && /submitted/i.test(e.message)) { flushing = false; return finished(true, e.message); }
      else if (e.status === 409) { toast(e.message, 'err'); for (const b of batch) pending.delete(b.questionId); persist(); setNet(true); }
      else { setNet(true, 'Save failed — retrying'); }
    }
    flushing = false;
    if (pending.size && online) { clearTimeout(saveTimer); saveTimer = setTimeout(flush, 3000); }
  }
  const retry = setInterval(() => { if (pending.size || pendingTime.size) flush(); }, 5000);
  const onOnline = () => { setNet(true, 'Reconnected — syncing…'); flush(); };
  const onOffline = () => setNet(false);
  window.addEventListener('online', onOnline); window.addEventListener('offline', onOffline);
  // ── one question ──
  function render() {
    const q = Qs[cur]; const s = state.get(q.id);
    const multi = q.type === 'multi_select';
    let answerUI;
    if (['mcq', 'true_false', 'multi_select'].includes(q.type)) {
      answerUI = h('div.cbt-opts', { role: multi ? 'group' : 'radiogroup', 'aria-label': 'Answer options' }, q.options.map((o, i) => {
        const checked = multi ? s.optionIds.includes(o.id) : s.optionId === o.id;
        const inp = h('input', { type: multi ? 'checkbox' : 'radio', name: `q_${q.id}`, value: o.id, checked, on: { change: (ev) => {
          if (multi) { s.optionIds = ev.target.checked ? [...new Set([...s.optionIds, o.id])] : s.optionIds.filter((x) => x !== o.id); } else s.optionId = o.id;
          answerUI.querySelectorAll('.cbt-opt').forEach((l) => l.classList.toggle('on', l.querySelector('input').checked));
          markDirty(q.id, true);
        } } });
        return h(`label.cbt-opt${checked ? '.on' : ''}`, inp, h('span.cbt-letter', { text: q.type === 'true_false' ? '' : LET[i] }), o.imageFileId ? h('img.q-img', { src: fileUrl(o.imageFileId), alt: '' }) : null, renderRich(o.text, { block: false }));
      }));
    } else if (q.type === 'theory') {
      const ta = h('textarea.input.cbt-essay', { rows: 8, maxlength: 10000, 'aria-label': 'Your answer', text: s.text || '' }); ta.addEventListener('input', () => { s.text = ta.value; markDirty(q.id); }); answerUI = ta;
    } else {
      const inp = h('input.input.cbt-text', { value: s.text || '', maxlength: 500, 'aria-label': 'Your answer', inputmode: q.type === 'numeric' ? 'decimal' : 'text', autocomplete: 'off', placeholder: q.type === 'numeric' ? 'Type a number' : 'Type your answer' });
      inp.addEventListener('input', () => { s.text = inp.value; markDirty(q.id); }); answerUI = inp;
    }
    const hint = { multi_select: 'Select ALL correct options.', numeric: 'Numbers only (e.g. 12 or 3.5).', fill_blank: 'Type the missing word(s).', short_answer: 'Type a short answer.', theory: 'Write your answer. It will be marked by your teacher.' }[q.type];
    const flagBtn = h(`button.btn.cbt-flag${s.flagged ? '.on' : ''}`, { type: 'button', 'aria-pressed': String(!!s.flagged), on: { click: () => { s.flagged = !s.flagged; markDirty(q.id, true); render(); } } }, icon('flag', 15), h('span', { text: s.flagged ? 'Marked for review' : 'Mark for review' }));
    clear(qArea).append(...[
      h('div.cbt-qhead', h('strong', { text: `QUESTION ${cur + 1} OF ${N}` }), h('span.muted', { text: `${Number(q.marks)} mark${Number(q.marks) === 1 ? '' : 's'}` })),
      h('div.cbt-qtext', renderRich(q.text)), q.imageFileId ? h('img.q-img.cbt-img', { src: fileUrl(q.imageFileId), alt: 'Question diagram' }) : null,
      hint ? h('small.muted', { text: hint }) : null, answerUI,
      h('div.cbt-actions', S.allowBackNav ? h('button.btn', { type: 'button', text: '← Previous', disabled: cur === 0, on: { click: () => go(cur - 1) } }) : h('span'), flagBtn,
        h('button.btn', { type: 'button', text: 'Save answer', on: { click: async () => { takeTime(); markDirty(q.id); clearTimeout(saveTimer); flush.force = true; await flush(); flush.force = false; toast(pending.has(q.id) ? 'Saved on this device — will sync when you reconnect' : 'Answer saved', pending.has(q.id) ? 'err' : 'ok', 2000); } } }),
        cur < N - 1 ? h('button.btn.btn-primary', { type: 'button', text: 'Next →', on: { click: () => go(cur + 1) } }) : h('button.btn.btn-primary', { type: 'button', text: S.allowReview ? 'Review & submit' : 'Submit', on: { click: () => (S.allowReview ? reviewScreen() : confirmSubmit()) } }))].filter(Boolean));
    paintNav();
    const first = qArea.querySelector('input,textarea'); if (first && window.matchMedia('(min-width: 900px)').matches) first.focus({ preventScroll: true });
  }
  function go(i) {
    if (i < 0 || i >= N || done) return;
    if (!S.allowBackNav && i < cur) return;
    takeTime(); if (!S.autosave) { flush.force = true; flush(); flush.force = false; }
    if (pendingTime.size && !pending.size) flush();
    cur = i; furthest = Math.max(furthest, i); render(); panel.classList.remove('open'); navToggle.setAttribute('aria-expanded', 'false'); window.scrollTo(0, 0);
  }
  // ── review & submit ──
  function summary() { let a = 0; let f = 0; for (const q of Qs) { const s = state.get(q.id); if (answered(s)) a++; if (s.flagged) f++; } return { total: N, answered: a, unanswered: N - a, flagged: f }; }
  function reviewScreen() {
    takeTime(); const sm = summary();
    const m = modal({ title: 'Exam summary', body: h('div.cbt-summary', h('dl.kv', h('dt', { text: 'Total questions' }), h('dd', { text: sm.total }), h('dt', { text: 'Answered' }), h('dd', { text: sm.answered }), h('dt', { text: 'Unanswered' }), h('dd', { text: sm.unanswered }), h('dt', { text: 'Marked for review' }), h('dd', { text: sm.flagged })),
      sm.unanswered || sm.flagged ? h('div.cbt-jump', Qs.map((q, i) => { const s = state.get(q.id); return !answered(s) || s.flagged ? h('button.cbt-nb', { type: 'button', class: `cbt-nb${answered(s) ? ' ans' : ''}${s.flagged ? ' flag' : ''}`, text: String(i + 1).padStart(2, '0'), disabled: !S.allowBackNav && i < furthest, on: { click: () => { m.close(); go(i); } } }) : null; })) : null),
    actions: [btn('Return to questions', () => m.close()), btn('SUBMIT EXAM', () => { m.close(); confirmSubmit(sm); }, { kind: 'primary' })] });
  }
  async function confirmSubmit(sm = summary()) {
    if (sm.unanswered && !(await confirmDialog({ title: `${sm.unanswered} question(s) unanswered`, message: 'Unanswered questions score zero. Submit anyway?', confirmLabel: 'Submit anyway', danger: true }))) return;
    if (!sm.unanswered && !(await confirmDialog({ title: 'Submit your exam?', message: 'You cannot change your answers after submitting.', confirmLabel: 'Submit' }))) return;
    submit(false);
  }
  async function submit(auto) {
    if (done) return;
    takeTime(); flush.force = true; await flush(); flush.force = false;
    if (pending.size && !auto) { toast('Some answers are not saved yet — check your connection and try again.', 'err', 6000); return; }
    done = true; stop();
    clear(root).appendChild(h('div.cbt-center', spinner('Submitting…')));
    try { const r = await api.post(`/cbt/attempts/${paper.attemptId}/submit`, {}); try { localStorage.removeItem(QKEY); } catch { /* */ } showSubmitted(r, auto); }
    catch (e) { if (e.status === 409) { try { localStorage.removeItem(QKEY); } catch { /* */ } showSubmitted({ message: e.message, attemptId: paper.attemptId }, auto); } else { clear(root).appendChild(h('div.cbt-center', card('Could not submit', [h('p', { text: `${errMsg(e)} Your answers are safe on the server; the exam is submitted automatically at the end of the time.` }), btn('Try again', () => { done = false; submit(auto); }, { kind: 'primary' })]))); } }
  }
  function finished(auto, message) { if (done) return; done = true; stop(); try { localStorage.removeItem(QKEY); } catch { /* */ } showSubmitted({ message, attemptId: paper.attemptId }, auto); }
  function showSubmitted(r, auto) {
    if (document.fullscreenElement && document.exitFullscreen) document.exitFullscreen().catch(() => {});
    clear(root).appendChild(h('div.cbt-center', card(auto ? 'Time up — your exam was submitted' : 'Exam submitted', [
      r.resultAvailable ? h('p', { text: 'Your result is ready.' }) : r.score !== undefined && r.score !== null ? h('p', { text: `Score: ${r.score}/${r.maxScore}` }) : r.objectiveScore !== undefined ? h('p', { text: `Objective score ${r.objectiveScore}/${r.maxScore}. Written answers will be marked by your teacher.` }) : h('p', { text: r.message || 'Your school will release the result.' }),
      h('div.page-actions', r.resultAvailable ? h('a.btn.btn-primary', { href: `#/cbt/result/${r.attemptId}`, text: 'View my result' }) : null, h('a.btn', { href: '#/my-cbt', text: 'Back to My CBT' }))])));
  }
  // ── timer (server-anchored) + warnings ──
  const warned = new Set();
  const tick = () => {
    const left = deadline - (Date.now() + skew);
    timer.textContent = mmss(left); timer.classList.toggle('low', left < 5 * 60000); timer.classList.toggle('crit', left < 60000);
    for (const [ms, label] of [[10 * 60000, '10 minutes'], [5 * 60000, '5 minutes'], [60000, '1 minute']]) if (left <= ms && left > ms - 5000 && !warned.has(ms)) { warned.add(ms); toast(`${label} remaining`, 'err', 5000); timer.setAttribute('aria-live', 'assertive'); setTimeout(() => timer.setAttribute('aria-live', 'off'), 2000); }
    if (left <= 0) submit(true);
  };
  const vis = () => { if (document.hidden && !done) api.post(`/cbt/attempts/${paper.attemptId}/focus-loss`).catch(() => {}); };
  const fs = () => { if (S.fullscreen && !document.fullscreenElement && !done) { api.post(`/cbt/attempts/${paper.attemptId}/focus-loss`).catch(() => {}); toast('You left full-screen mode. This is recorded.', 'err'); } };
  const beforeUnload = (ev) => { if (!done && pending.size) { ev.preventDefault(); ev.returnValue = ''; } };
  document.addEventListener('visibilitychange', vis); document.addEventListener('fullscreenchange', fs); window.addEventListener('beforeunload', beforeUnload);
  const t1 = setInterval(tick, 500);
  function stop() { clearInterval(t1); clearInterval(retry); clearTimeout(saveTimer); document.removeEventListener('visibilitychange', vis); document.removeEventListener('fullscreenchange', fs); window.removeEventListener('beforeunload', beforeUnload); window.removeEventListener('online', onOnline); window.removeEventListener('offline', onOffline); }
  window.addEventListener('hashchange', () => { if (!done) { takeTime(); flush(); } stop(); }, { once: true });
  setNet(navigator.onLine !== false); render(); tick();
  if (pending.size) flush();                           // answers restored from a previous page load that never reached the server
}

// ── candidate result page ──
export async function result(view, p) {
  const r = await api.get(`/cbt/attempts/${p.id}/result`);
  if (!r.released) { view.append(pageHead(r.title, 'Result'), card(null, empty('Result not released yet', r.message, h('a.btn', { href: '#/my-cbt', text: 'Back to My CBT' })))); return; }
  const t = r.timeUsedSeconds;
  append(view, [pageHead(r.title, `${r.subject || ''}${r.className ? ` · ${r.className}` : ''}`, btn('Print', () => window.print(), { ic: 'printer' })),
    h('div.doc.cbt-result', h('div.cbt-score', h('div', h('small', { text: 'SCORE' }), h('strong', { text: `${r.score} / ${r.maxScore}` })), h('div', h('small', { text: 'PERCENTAGE' }), h('strong', { text: `${r.percentage}%` })),
      h('div', h('small', { text: 'GRADE' }), h('strong', { text: r.grade })), h('div', h('small', { text: 'STATUS' }), h('strong', { class: r.passed ? 'pass' : 'fail', text: r.passed ? 'PASS' : 'FAIL' }))),
    h('dl.kv', [['Student', `${r.student.name} (${r.student.admissionNo})`], ['Examination', r.title], ['Subject', r.subject || '—'], ['Class', r.className || '—'], ['Time used', t === null ? '—' : `${Math.floor(t / 60)} min ${t % 60} s`],
      ['Questions', r.questions], ['Attempted', r.attempted], ['Correct', r.correct], ['Incorrect', r.incorrect], ['Unanswered', r.unanswered], ['Pass mark', `${r.passMark}%`]].flatMap(([k, v]) => [h('dt', { text: k }), h('dd', { text: String(v) })]))),
    r.review ? card('Answers', h('div', r.review.map((x) => h(`div.q.${x.correct === true ? 'q-right' : x.correct === false ? 'q-wrong' : 'q-manual'}`, h('div.q-head', h('strong', { text: `${x.n}.` }), x.correct === true ? badge('correct', 'ok') : x.correct === false ? badge('wrong', 'danger') : badge(x.marksAwarded !== null ? `${x.marksAwarded}/${x.marks}` : 'marked by teacher', 'info')),
      renderRich(x.text), h('p', h('strong', { text: 'Your answer: ' }), x.yourAnswer || '—'), x.correctAnswer ? h('p', h('strong', { text: 'Correct answer: ' }), x.correctAnswer) : null, x.explanation ? h('p.muted', h('strong', { text: 'Explanation: ' }), renderRich(x.explanation, { block: false })) : null)))) : null]);
}
