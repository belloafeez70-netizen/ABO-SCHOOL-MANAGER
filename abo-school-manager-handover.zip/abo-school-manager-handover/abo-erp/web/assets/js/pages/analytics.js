// Analytics menu: Class / Subject / Student performance and Performance Charts. Figures come from
// /results/analytics (server-side SQL). "Approved only" is the default so draft scores never skew decisions.
import { h, clear } from '../core/dom.js';
import { api, qs } from '../core/api.js';
import { pageHead, card, fail, simpleTable, empty, spinner, stat, badge, bars } from '../core/ui.js';
import { ordinal, tn } from '../core/format.js';
import { barChart, lineChart, donut, PALETTE } from '../core/charts.js';
import { academic } from './people.js';
import { pickers, classOpts, num } from './shared.js';

function scopeToggle(q, onChange) {
  const sel = h('select.input', { 'aria-label': 'Which results' }, h('option', { value: 'approved', text: 'Approved & published results only', selected: q.scope !== 'all' }), h('option', { value: 'all', text: 'Include draft / unapproved scores', selected: q.scope === 'all' }));
  sel.addEventListener('change', () => onChange(sel.value));
  return { el: h('div.field', h('label', { text: 'Results included' }), sel), get: () => sel.value };
}
function analyticsPage(title, sub, render, { cls = false } = {}) {
  return async (view, p, q) => {
    const a = await academic();
    view.appendChild(pageHead(title, sub));
    const pk = pickers(a, q, { term: true, cls, allClasses: true });
    const box = h('div');
    const load = async () => {
      clear(box).appendChild(spinner('Crunching numbers…'));
      try {
        const v = pk.get();
        const d = await api.get(`/results/analytics${qs({ termId: v.termId, classId: v.classId || undefined, scope: sc.get() })}`);
        clear(box);
        if (!d.totals.students) return box.appendChild(empty('No results to analyse yet', sc.get() === 'approved' ? 'Only approved results are counted. Switch “Results included” to see draft scores, or approve sheets first.' : 'Scores appear here once teachers enter them.'));
        render(box, d, a);
      } catch (e) { clear(box); fail(e); }
    };
    const sc = scopeToggle(q, load);
    pk.on(load);
    view.append(card(null, h('div.form-grid', ...pk.el.children, sc.el)), box);
    load();
  };
}
const kpis = (d) => h('div.stats', stat('Learners with results', d.totals.students, `${d.term.session} · ${tn(d.term.name)} term`, 'users'), stat('School average', `${num(d.totals.average)}%`, `highest ${num(d.totals.highest)}% · lowest ${num(d.totals.lowest)}%`, 'chart'),
  stat('Pass rate', `${num(d.totals.pass_rate)}%`, `${d.totals.passed} passed (≥ ${d.passMark}%)`, 'check', d.totals.pass_rate < 50 ? 'red' : ''), stat('Subjects analysed', d.bySubject.length, '', 'book'));

export const classPerformance = analyticsPage('Class Performance', 'Average, spread and pass rate for every class this term.', (box, d) => {
  box.append(kpis(d),
    card('Class averages', h('div.table-wrap', barChart(d.byClass.map((c) => ({ label: c.display_name, value: Number(c.average), tone: Number(c.average) < d.passMark ? 'bad' : '' })), { title: 'Class averages', fmt: (v) => num(v), threshold: d.passMark }))),
    card('Classes ranked by average', simpleTable([{ label: '#', render: (c) => d.byClass.slice().sort((x, y) => y.average - x.average).indexOf(c) + 1 }, { key: 'display_name', label: 'Class' }, { key: 'students', label: 'Learners', cls: 'num' },
      { label: 'Average', render: (c) => `${num(c.average)}%` }, { label: 'Highest', render: (c) => `${num(c.highest)}%` }, { label: 'Lowest', render: (c) => `${num(c.lowest)}%` },
      { label: 'Pass rate', render: (c) => h('div.kpi-row', h('div.progress-mini', (() => { const x = h('div'); x.style.width = `${c.pass_rate}%`; return x; })()), h('small', { text: `${num(c.pass_rate)}%` })) }], d.byClass.slice().sort((x, y) => y.average - x.average))));
});

export const subjectPerformance = analyticsPage('Subject Performance', 'Which subjects are strong or weak — averages, pass rates and grade spread per subject.', (box, d) => {
  const gradeKeys = [...new Set(d.bySubject.flatMap((s) => Object.keys(s.grades)))].sort();
  box.append(kpis(d),
    card('Subject averages', h('div.table-wrap', barChart(d.bySubject.map((s) => ({ label: s.name, value: Number(s.average), tone: Number(s.average) < d.passMark ? 'bad' : '' })), { title: 'Subject averages', fmt: (v) => num(v), threshold: d.passMark }))),
    card('Subjects', simpleTable([{ key: 'name', label: 'Subject' }, { key: 'entries', label: 'Learners', cls: 'num' }, { label: 'Average', render: (s) => `${num(s.average)}%` }, { label: 'Highest', render: (s) => num(s.highest) }, { label: 'Lowest', render: (s) => num(s.lowest) },
      { label: 'Pass rate', render: (s) => badge(`${num(s.pass_rate)}%`, s.pass_rate >= 70 ? 'ok' : s.pass_rate >= 50 ? 'warn' : 'danger') }, ...gradeKeys.map((g) => ({ label: g, cls: 'num', render: (s) => s.grades[g] || '' }))], d.bySubject)));
}, { cls: true });

export const performanceCharts = analyticsPage('Performance Charts', 'The term at a glance: grade distribution, pass vs fail, boys vs girls and top performers.', (box, d) => {
  const grades = d.grades.map((g, i) => ({ label: g.grade, value: g.n, color: PALETTE[i % PALETTE.length] }));
  const pf = [{ label: 'Passed', value: d.totals.passed, color: '#0a7d61' }, { label: 'Below pass mark', value: d.totals.students - d.totals.passed, color: '#d92d20' }];
  const legend = (items) => h('div.legend', items.map((x) => h('span', (() => { const i = h('i'); i.style.background = x.color; return i; })(), `${x.label} (${x.value})`)));
  box.append(kpis(d),
    h('div.grid.g2', card('Grade distribution (all subject results)', h('div.kpi-row', donut(grades, { title: 'Grades' }), legend(grades))), card('Pass vs fail (learner averages)', h('div.kpi-row', donut(pf, { title: 'Pass vs fail' }), legend(pf)))),
    h('div.grid.g2', card('Boys vs girls — average', bars(d.gender.map((g) => ({ label: `${g.gender} (${g.students})`, value: Number(g.average) })), { max: 100, fmt: (v) => `${num(v)}%` })),
      card('Class averages', bars(d.byClass.map((c) => ({ label: c.display_name, value: Number(c.average) })), { max: 100, fmt: (v) => `${num(v)}%` }))),
    h('div.grid.g2', card('Top 10 learners', simpleTable([{ label: '#', render: (s) => d.top.indexOf(s) + 1 }, { label: 'Learner', render: (s) => h('a', { href: `#/analytics/students?studentId=${s.id}`, text: `${s.last_name} ${s.first_name}` }) }, { key: 'class_name', label: 'Class' }, { label: 'Average', render: (s) => `${num(s.average)}%` }], d.top)),
      card('Learners who need support', simpleTable([{ label: 'Learner', render: (s) => h('a', { href: `#/analytics/students?studentId=${s.id}`, text: `${s.last_name} ${s.first_name}` }) }, { key: 'class_name', label: 'Class' }, { label: 'Average', render: (s) => badge(`${num(s.average)}%`, Number(s.average) < d.passMark ? 'danger' : 'warn') }], d.bottom))));
}, { cls: true });

export async function studentPerformance(view, p, q) {
  const a = await academic();
  view.appendChild(pageHead('Student Performance', 'One learner across every term: average and position trend, and how each subject is moving.'));
  const cls = h('select.input', { 'aria-label': 'Class' }, h('option', { value: '', text: 'Choose class…' }), classOpts(a).map((o) => h('option', { value: o.value, text: o.label })));
  const search = h('input.input', { type: 'search', placeholder: 'or search name / admission no…', 'aria-label': 'Search learner' });
  const list = h('select.input', { 'aria-label': 'Learner' }, h('option', { value: '', text: 'Choose learner…' }));
  const box = h('div');
  const fill = async () => {
    try {
      const r = await api.get('/students' + qs({ classId: cls.value || undefined, q: search.value.trim() || undefined, pageSize: 100 }));
      clear(list).append(h('option', { value: '', text: `Choose learner (${r.items.length})` }), ...r.items.map((s) => h('option', { value: s.id, text: `${s.last_name} ${s.first_name} · ${s.admission_no}`, selected: s.id === q.studentId })));
    } catch (e) { fail(e); }
  };
  let t; search.addEventListener('input', () => { clearTimeout(t); t = setTimeout(fill, 300); });
  cls.addEventListener('change', fill);
  const show = async (id) => {
    if (!id) return clear(box);
    clear(box).appendChild(spinner());
    try {
      const d = await api.get(`/results/analytics/student/${id}`);
      const s = d.student; clear(box);
      if (!d.terms.length) return box.appendChild(empty(`${s.last_name} ${s.first_name} has no results yet`));
      const last = d.terms[d.terms.length - 1]; const prev = d.terms[d.terms.length - 2];
      const delta = prev ? Number(last.average) - Number(prev.average) : null;
      box.append(h('div.stats', stat('Latest average', `${num(last.average)}%`, last.label, 'chart'), stat('Change vs previous term', delta === null ? '—' : `${delta >= 0 ? '▲' : '▼'} ${num(Math.abs(delta))}`, prev ? prev.label : 'first term on record', 'activity', delta !== null && delta < 0 ? 'red' : ''),
        stat('Latest position', last.position ? `${ordinal(last.position)} of ${last.classSize}` : '—', last.className, 'check'), stat('Terms on record', d.terms.length, `${last.subjects} subjects last term`, 'book')),
      card('Average per term', h('div.table-wrap', lineChart(d.terms.map((x) => ({ label: x.label, value: Number(x.average) })), { title: 'Average per term', fmt: (v) => num(v) }))),
      card('Subjects by term', simpleTable([{ key: 'name', label: 'Subject' }, ...d.terms.map((tm) => ({ label: tm.label.replace(' · ', ' '), cls: 'num', render: (x) => (x.byTerm[tm.termId] ? `${num(x.byTerm[tm.termId].total)} (${x.byTerm[tm.termId].grade})` : '—') })),
        { label: 'Trend', render: (x) => { const v = d.terms.map((tm) => x.byTerm[tm.termId] && x.byTerm[tm.termId].total).filter((n) => n !== undefined); if (v.length < 2) return '—'; const dd = v[v.length - 1] - v[v.length - 2]; return badge(`${dd >= 0 ? '▲' : '▼'} ${num(Math.abs(dd))}`, dd >= 0 ? 'ok' : 'danger'); } }], d.subjects)),
      h('div.page-actions', h('a.btn', { href: `#/students/${s.id}`, text: 'Open profile' }), h('a.btn', { href: `#/report/${s.id}?termId=${last.termId}`, text: 'Latest report sheet' })));
    } catch (e) { clear(box); fail(e); }
  };
  list.addEventListener('change', () => show(list.value));
  view.append(card(null, h('div.form-grid', h('div.field', h('label', { text: 'Class' }), cls), h('div.field', h('label', { text: 'Search' }), search), h('div.field', h('label', { text: 'Learner' }), list))), box);
  if (q.studentId) { await fill(); show(q.studentId); }
  void pickers;
}
