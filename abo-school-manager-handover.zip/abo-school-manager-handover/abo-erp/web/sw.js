/* A.B.O. School Manager — offline support (service worker).
   What works offline: the app opens, and pages you already opened while online show the LAST SAVED copy of their
   information (a yellow bar says so). Saving anything still needs the internet — the app says clearly when you are
   offline, so nothing is lost silently.
   Privacy: saved information belongs to ONE signed-in person (cache per user id). Signing out deletes it. Only a short
   list of read-only, everyday screens is saved; files, exports, money and security screens never are. */
const VERSION = 'abo-sw-3';   // bump on every release that changes cached screens (old saved copies are deleted)
const SHELL = `${VERSION}-shell`;
const API_PREFIX = `${VERSION}-api-`;
let currentUser = null;                          // set by the page after sign-in
const whoIsSignedIn = () => (currentUser ? Promise.resolve(currentUser)
  : caches.open(SHELL).then((c) => c.match('/__abo_user')).then((r) => (r ? r.text() : null)).then((id) => { currentUser = id || null; return currentUser; }));

// read-only screens that may be shown from the saved copy when offline
const SAVE_API = [/\/api\/v1\/auth\/me$/, /\/api\/v1\/dashboard(\/[a-z-]+)?(\?.*)?$/, /\/api\/v1\/calendar(\?.*)?$/, /\/api\/v1\/materials(\?.*)?$/, /\/api\/v1\/live-classes(\?.*)?$/,
  /\/api\/v1\/academic(\?.*)?$/, /\/api\/v1\/academic\/classes\/[0-9a-f-]{36}\/timetable$/, /\/api\/v1\/announcements(\?.*)?$/, /\/api\/v1\/my\/[a-z-]+(\?.*)?$/,
  /\/api\/v1\/lesson-notes(\?.*)?$/, /\/api\/v1\/birthdays(\?.*)?$/, /\/api\/v1\/clock\/me$/];

self.addEventListener('install', (e) => { e.waitUntil(caches.open(SHELL).then((c) => c.addAll(['/', '/manifest.webmanifest', '/assets/img/icons/icon-192.png']).catch(() => {}))); self.skipWaiting(); });
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => !k.startsWith(VERSION)).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('message', (e) => {
  const m = e.data || {};
  if (m.type === 'user') {
    currentUser = m.id ? String(m.id).replace(/[^0-9a-f-]/gi, '') : null;
    // remembered across service-worker restarts (the browser stops idle workers)
    e.waitUntil(caches.open(SHELL).then((c) => (currentUser ? c.put('/__abo_user', new Response(currentUser)) : c.delete('/__abo_user'))));
  }
  if (m.type === 'signed-out') {
    currentUser = null;
    e.waitUntil(Promise.all([caches.open(SHELL).then((c) => c.delete('/__abo_user')),
      caches.keys().then((keys) => Promise.all(keys.filter((k) => k.startsWith(API_PREFIX)).map((k) => caches.delete(k))))]));
  }
});

function marked(res, savedAt) {                  // the page shows "offline — saved copy from …" when it sees this header
  const h = new Headers(res.headers); h.set('X-ABO-Offline-Copy', savedAt || '1');
  return res.blob().then((b) => new Response(b, { status: res.status, statusText: res.statusText, headers: h }));
}

self.addEventListener('fetch', (e) => {
  const req = e.request; const url = new URL(req.url);
  if (req.method !== 'GET') return;                                         // writes always go to the network
  if (url.pathname.startsWith('/offline/')) return;                         // the offline edition has its own worker
  if (req.mode === 'navigate') {                                            // the app itself: network first, saved copy offline
    e.respondWith(fetch(req).then((res) => { if (res.ok) caches.open(SHELL).then((c) => c.put('/', res.clone())); return res; })
      .catch(() => caches.match('/', { cacheName: SHELL }).then((r) => r || Response.error())));
    return;
  }
  if (url.origin === self.location.origin && /^\/assets\//.test(url.pathname)) {   // code, styles, images: saved copy first, refreshed in the background
    e.respondWith(caches.open(SHELL).then((c) => c.match(req).then((hit) => {
      const net = fetch(req).then((res) => { if (res.ok) c.put(req, res.clone()); return res; }).catch(() => hit);
      return hit || net;
    })));
    return;
  }
  if (/\/api\/v1\//.test(url.pathname) && SAVE_API.some((r) => r.test(url.pathname + url.search))) {
    e.respondWith(whoIsSignedIn().then((user) => {
    const saved = () => (user ? caches.open(API_PREFIX + user).then((c) => c.match(req.url)).then((hit) => (hit ? marked(hit, hit.headers.get('X-ABO-Saved-At')) : null)) : Promise.resolve(null));
    return fetch(req).then((res) => {
      // the website is up but the school server is not (Netlify edge proxy answers 502/504): use the saved copy too
      if ((res.status === 502 || res.status === 504) && user) return saved().then((hit) => hit || res);
      if (res.ok && user) { const copy = res.clone(); const h = new Headers(copy.headers); h.set('X-ABO-Saved-At', new Date().toISOString());
        copy.blob().then((b) => caches.open(API_PREFIX + user).then((c) => c.put(req.url, new Response(b, { status: 200, headers: h })))); }
      return res;
    }).catch(() => saved().then((hit) => hit || Response.error()));
    }));
  }
});
