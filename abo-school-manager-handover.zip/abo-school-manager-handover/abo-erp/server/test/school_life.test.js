'use strict';
// Phase 6 (part 1): staff clock-in, school calendar, birthdays and the cashbook — moved from the offline app into the
// server, with the rules enforced here (permissions, distance check, one clock-in a day, never-edited money, isolation).
const H = require('./helpers');
const test = require('node:test');
const assert = require('node:assert/strict');

const GATE = { lat: 6.5244, lng: 3.3792 };              // school gate (Lagos)
const NEAR = { lat: 6.52461, lng: 3.37932, accuracy: 12 }; // ~28 m away
const FAR = { lat: 6.6018, lng: 3.3515, accuracy: 15 };    // ~9 km away (Ikeja)
let S, owner, teacher, teacher2, exam, bursar, accounts, student, parent, bOwner, bTeacher;
test.before(async () => {
  S = await H.setup();
  [owner, teacher, teacher2, exam, bursar, accounts, student, parent, bOwner, bTeacher] = await Promise.all(
    ['sa.owner', 'sa.teacher1', 'sa.teacher2', 'sa.exams', 'sa.bursar', 'sa.accounts', 'sa.student', 'sa.parent', 'sb.owner', 'sb.teacher1'].map((l) => H.login(S.app, l)));
});
test.after(() => H.teardown());

test('clock-in: distance worked out on the server; far refused, near accepted; one clock-in a day; out needs in', async () => {
  assert.equal((await teacher.put('/api/v1/clock/settings', { requireLocation: true, siteLat: GATE.lat, siteLng: GATE.lng })).status, 403, 'teachers cannot change the rules');
  assert.equal((await owner.put('/api/v1/clock/settings', { requireLocation: true })).status, 400, 'location rule needs a school location first');
  const set = await owner.put('/api/v1/clock/settings', { requireLocation: true, siteLat: GATE.lat, siteLng: GATE.lng, radiusM: 150, lateAfter: '23:59' });
  assert.equal(set.status, 200, JSON.stringify(set.body)); assert.equal(set.body.requireLocation, true);
  const me = await teacher.get('/api/v1/clock/me');
  assert.equal(me.status, 200); assert.equal(me.body.staff, true); assert.equal(me.body.settings.requireLocation, true);
  assert.equal(me.body.settings.siteLat, undefined, 'staff are not sent the exact school coordinates');
  let r = await teacher.post('/api/v1/clock/in', {});
  assert.equal(r.status, 400); assert.match(r.body.error.message, /location is needed/);
  r = await teacher.post('/api/v1/clock/in', FAR);
  assert.equal(r.status, 400); assert.match(r.body.error.message, /km from school/); assert.ok(r.body.error.details.distanceM > 8000);
  r = await teacher.post('/api/v1/clock/out', NEAR);
  assert.equal(r.status, 409, 'cannot clock out before clocking in');
  r = await teacher.post('/api/v1/clock/in', { ...NEAR, accuracy: 5000 });
  assert.equal(r.status, 400); assert.match(r.body.error.message, /not precise enough/);
  r = await teacher.post('/api/v1/clock/in', { ...NEAR, device: 'QA phone' });
  assert.equal(r.status, 200, JSON.stringify(r.body)); assert.ok(r.body.distance_m >= 20 && r.body.distance_m <= 40, String(r.body.distance_m)); assert.equal(r.body.late, false);
  assert.equal((await teacher.post('/api/v1/clock/in', NEAR)).status, 409, 'second clock-in the same day refused');
  // a fake "I am at the gate" body is checked like any other position: the server, not the browser, decides
  r = await teacher2.post('/api/v1/clock/in', { lat: GATE.lat + 0.01, lng: GATE.lng, distance_m: 0 });
  assert.equal(r.status, 400, 'unknown fields are rejected and the distance is not trusted');
  r = await teacher.post('/api/v1/clock/out', NEAR); assert.equal(r.status, 200);
  assert.equal((await teacher.post('/api/v1/clock/out', NEAR)).status, 409);
  // late flag follows the school's late time
  await owner.put('/api/v1/clock/settings', { requireLocation: true, lateAfter: '00:00' });
  r = await exam.post('/api/v1/clock/in', NEAR); assert.equal(r.status, 200); assert.equal(r.body.late, true);
  // someone without a staff record
  r = await owner.post('/api/v1/clock/in', NEAR); assert.equal(r.status, 403); assert.match(r.body.error.message, /staff record/);
  assert.equal((await student.post('/api/v1/clock/in', NEAR)).status, 403, 'pupils cannot clock in');
  // the register
  assert.equal((await teacher.get('/api/v1/clock/register')).status, 403, 'teachers do not see everyone');
  const reg = await owner.get('/api/v1/clock/register');
  assert.equal(reg.status, 200);
  const tb = reg.body.items.find((x) => x.full_name === 'Mr Tunde Bello'); const ge = reg.body.items.find((x) => x.full_name === 'Mrs Grace Eze');
  assert.equal(tb.status, 'present'); assert.ok(tb.out_at); assert.equal(ge.status, 'late');
  assert.equal(reg.body.summary.present, 1); assert.equal(reg.body.summary.late, 1); assert.equal(reg.body.summary.clockedOut, 1);
  // another school sees none of it
  const breg = await bOwner.get('/api/v1/clock/register');
  assert.ok(!breg.body.items.some((x) => x.in_at), 'school B sees no clock-ins from school A');
  const bset = await bOwner.get('/api/v1/clock/settings'); assert.equal(bset.body.requireLocation, false);
  // without the location rule, clock-in works without a position
  assert.equal((await bTeacher.post('/api/v1/clock/in', {})).status, 200);
  // audit trail
  const db = await H.dbAs('owner');
  try { assert.ok((await db.query("SELECT count(*)::int AS n FROM audit_logs WHERE action = 'clock.in_refused'")).rows[0].n >= 1, 'refused clock-ins are logged'); } finally { await db.end(); }
});

test('calendar: managers add events; everyone reads; pupils and parents see only events for everyone', async () => {
  const d = new Date(); const ymd = (x) => x.toISOString().slice(0, 10);
  const in5 = ymd(new Date(d.getTime() + 5 * 864e5)); const in7 = ymd(new Date(d.getTime() + 7 * 864e5));
  assert.equal((await teacher.post('/api/v1/calendar', { title: 'Mid-term break', startsOn: in5 })).status, 403);
  let r = await owner.post('/api/v1/calendar', { title: 'Mid-term break', kind: 'holiday', startsOn: in5, endsOn: in7 });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  const ev = r.body.id;
  r = await owner.post('/api/v1/calendar', { title: 'Staff meeting', kind: 'meeting', audience: 'staff', startsOn: in5 });
  assert.equal(r.status, 200); const staffEv = r.body.id;
  assert.equal((await owner.post('/api/v1/calendar', { title: 'Bad', startsOn: in7, endsOn: in5 })).status, 400, 'end before start refused');
  const from = ymd(d); const to = ymd(new Date(d.getTime() + 30 * 864e5));
  const tl = await teacher.get(`/api/v1/calendar?from=${from}&to=${to}`); assert.equal(tl.status, 200);
  assert.ok(tl.body.items.some((x) => x.id === ev) && tl.body.items.some((x) => x.id === staffEv), 'staff see both');
  for (const who of [student, parent]) {
    const l = await who.get(`/api/v1/calendar?from=${from}&to=${to}`); assert.equal(l.status, 200);
    assert.ok(l.body.items.some((x) => x.id === ev) && !l.body.items.some((x) => x.id === staffEv), 'learners see only events for everyone');
    assert.equal((await who.post('/api/v1/calendar', { title: 'x', startsOn: in5 })).status, 403);
  }
  r = await owner.patch(`/api/v1/calendar/${ev}`, { title: 'Mid-term holiday', endsOn: in5 }); assert.equal(r.status, 200); assert.equal(r.body.ends_on, in5);
  assert.equal((await bOwner.patch(`/api/v1/calendar/${ev}`, { title: 'hijack' })).status, 404, 'other school cannot touch it');
  assert.ok(!(await bOwner.get(`/api/v1/calendar?from=${from}&to=${to}`)).body.items.some((x) => x.id === ev), 'other school cannot see it');
  assert.equal((await owner.del(`/api/v1/calendar/${staffEv}`)).status, 200);
  assert.ok(!(await teacher.get(`/api/v1/calendar?from=${from}&to=${to}`)).body.items.some((x) => x.id === staffEv));
});

test('birthdays: pupils and staff, next 7 days, 29 February handled, other schools not shown; pupils cannot use it', async () => {
  const db = await H.dbAs('owner');
  const now = new Date(); const lagos = new Date(now.getTime() + 3600e3);   // Africa/Lagos = UTC+1
  const md = (days) => { const x = new Date(lagos.getTime() + days * 864e5); return [x.getUTCMonth() + 1, x.getUTCDate()]; };
  try {
    const [m0, d0] = md(0); const [m3, d3] = md(3); const [m20, d20] = md(20);
    const sa = (await db.query("SELECT id FROM schools WHERE slug = 'school-a'")).rows[0].id; const sb = (await db.query("SELECT id FROM schools WHERE slug = 'school-b'")).rows[0].id;
    await db.query('UPDATE students SET date_of_birth = NULL WHERE school_id = $1', [sa]); await db.query('UPDATE staff SET date_of_birth = NULL WHERE school_id = $1', [sa]);
    const st = (await db.query("SELECT id FROM students WHERE school_id = $1 AND deleted_at IS NULL AND status = 'active' ORDER BY admission_no LIMIT 3", [sa])).rows;
    await db.query('UPDATE students SET date_of_birth = make_date(2015, $2, $3) WHERE id = $1', [st[0].id, m0, d0]);
    await db.query('UPDATE students SET date_of_birth = make_date(2014, $2, $3) WHERE id = $1', [st[1].id, m3, d3]);
    await db.query('UPDATE students SET date_of_birth = make_date(2013, $2, $3) WHERE id = $1', [st[2].id, m20, d20]);
    await db.query("UPDATE staff SET date_of_birth = make_date(1985, $2, $3) WHERE school_id = $1 AND full_name = 'Mr Tunde Bello'", [sa, m3, d3]);
    await db.query('UPDATE students SET date_of_birth = make_date(2015, $2, $3) WHERE school_id = $1', [sb, m0, d0]);
  } finally { await db.end(); }
  const r = await teacher.get('/api/v1/birthdays?days=7'); assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.equal(r.body.counts.today, 1); assert.equal(r.body.items[0].inDays, 0); assert.equal(r.body.items[0].turns, lagos.getUTCFullYear() - 2015);
  assert.ok(r.body.items.some((x) => x.kind === 'staff' && x.name === 'Mr Tunde Bello' && x.inDays === 3));
  assert.ok(!r.body.items.some((x) => x.inDays > 7), 'only the next 7 days');
  assert.equal(r.body.items.length, 3, 'two pupils + one staff (the 20-day one is outside the window; school B is not shown)');
  assert.equal((await teacher.get('/api/v1/birthdays?days=30')).body.items.length, 4);
  // 29 February: celebrated on 28 February in years without a 29th
  const db2 = await H.dbAs('owner');
  try { await db2.query("UPDATE staff SET date_of_birth = '2012-02-29' WHERE full_name = 'Mrs Ngozi Okeke'"); } finally { await db2.end(); }
  const leapKid = (await teacher.get('/api/v1/birthdays?days=366')).body.items.find((x) => x.name === 'Mrs Ngozi Okeke');
  const y = Number(leapKid.date.slice(0, 4)); const leap = (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0;
  assert.equal(leapKid.date.slice(5), leap ? '02-29' : '02-28', leapKid.date); assert.equal(leapKid.turns, y - 2012);
  assert.equal((await student.get('/api/v1/birthdays')).status, 403);
  assert.equal((await parent.get('/api/v1/birthdays')).status, 403);
});

test('cashbook: record, totals, petty cash cannot go negative, entries are voided never edited, fees included, roles enforced', async () => {
  const cats = await accounts.get('/api/v1/cashbook/categories'); assert.equal(cats.status, 200);
  const cat = (kind, name) => cats.body.items.find((c) => c.kind === kind && c.name === name).id;
  assert.equal((await teacher.get('/api/v1/cashbook/categories')).status, 403, 'teachers cannot see the cashbook');
  const t = new Date(Date.now() + 3600e3).toISOString().slice(0, 10);
  const tomorrow = new Date(Date.now() + 3600e3 + 864e5).toISOString().slice(0, 10);
  const post = (who, b, key) => who.post('/api/v1/cashbook/entries', { entryDate: t, method: 'cash', ...b }, key ? { headers: { 'idempotency-key': key } } : undefined);
  let r = await post(accounts, { kind: 'income', categoryId: cat('income', 'PTA levy'), amountKobo: 5000000, description: 'PTA levy, JSS 1' }, 'pta-levy-0001');
  assert.equal(r.status, 200, JSON.stringify(r.body));
  r = await post(accounts, { kind: 'income', categoryId: cat('income', 'PTA levy'), amountKobo: 5000000, description: 'PTA levy, JSS 1' }, 'pta-levy-0001');
  assert.equal(r.status, 200); assert.equal(r.headers['idempotent-replayed'], 'true', 'a retried request is not recorded twice');
  assert.equal((await post(accounts, { kind: 'expense', categoryId: cat('income', 'PTA levy'), amountKobo: 100, description: 'wrong kind' })).status, 400, 'category kind must match');
  assert.equal((await post(accounts, { kind: 'income', categoryId: cat('income', 'Donations'), amountKobo: 100, description: 'future', entryDate: tomorrow })).status, 400, 'no future dates');
  assert.equal((await post(accounts, { kind: 'income', categoryId: cat('income', 'Donations'), amountKobo: 0, description: 'zero' })).status, 400, 'amount must be positive');
  assert.equal((await post(accounts, { kind: 'income', categoryId: cat('income', 'Donations'), amountKobo: 10.5, description: 'half kobo' })).status, 400, 'whole kobo only');
  r = await post(accounts, { kind: 'expense', categoryId: cat('expense', 'Electricity & fuel'), amountKobo: 1200000, description: 'Diesel for generator', party: 'Total filling station' });
  assert.equal(r.status, 200); const diesel = r.body.id;
  // petty cash: cannot spend money that is not in the box
  r = await post(accounts, { kind: 'expense', method: 'petty_cash', categoryId: cat('expense', 'Food & refreshments'), amountKobo: 300000, description: 'Visitors refreshments' });
  assert.equal(r.status, 400); assert.match(r.body.error.message, /only ₦0\.00 in petty cash/);
  r = await post(accounts, { kind: 'income', method: 'petty_cash', categoryId: cat('income', 'Money into petty cash'), amountKobo: 500000, description: 'Top up petty cash' });
  assert.equal(r.status, 200); const topup = r.body.id;
  // two spends at the same moment: only what is in the box can go out
  const both = await Promise.all([1, 2].map((i) => post(accounts, { kind: 'expense', method: 'petty_cash', categoryId: cat('expense', 'Food & refreshments'), amountKobo: 300000, description: `Refreshments ${i}` })));
  assert.deepEqual(both.map((x) => x.status).sort(), [200, 400], 'concurrent petty-cash spends cannot overdraw the box');
  // a bursar can void (with a reason); an accountant cannot; amounts can never be edited
  assert.equal((await accounts.post(`/api/v1/cashbook/entries/${diesel}/void`, { reason: 'Typed twice' })).status, 403);
  assert.equal((await bursar.post(`/api/v1/cashbook/entries/${diesel}/void`, { reason: '' })).status, 400, 'reason required');
  assert.equal((await bursar.post(`/api/v1/cashbook/entries/${topup}/void`, { reason: 'mistake' })).status, 409, 'cannot void a top-up that was already spent from');
  assert.equal((await bursar.post(`/api/v1/cashbook/entries/${diesel}/void`, { reason: 'Typed twice' })).status, 200);
  assert.equal((await bursar.post(`/api/v1/cashbook/entries/${diesel}/void`, { reason: 'again' })).status, 409);
  const db = await H.dbAs('owner');
  try {
    await assert.rejects(db.query('UPDATE cash_entries SET amount_kobo = 1 WHERE id = $1', [topup]), /never edited/, 'the database refuses to edit an amount');
    await assert.rejects(db.query("UPDATE cash_entries SET description = 'x' WHERE id = $1", [diesel]), /voided/, 'a voided entry is frozen');
  } finally { await db.end(); }
  // summary: other income + confirmed fee payments − expenses; petty-cash top-ups are not counted as income
  const s = await owner.get(`/api/v1/cashbook/summary?from=${t}&to=${t}`); assert.equal(s.status, 200, JSON.stringify(s.body));
  assert.equal(s.body.otherIncomeKobo, 5000000, 'PTA levy only (top-up excluded, recorded once despite the retry)');
  assert.equal(s.body.expenseKobo, 300000, 'diesel voided; one petty-cash spend');
  assert.equal(s.body.pettyCash.balanceKobo, 200000);
  assert.equal(s.body.netKobo, s.body.feesKobo + s.body.storeSalesKobo + 5000000 - 300000);
  const list = await accounts.get(`/api/v1/cashbook/entries?from=${t}&to=${t}`);
  assert.equal(list.body.totals.incomeKobo, 5500000); assert.equal(list.body.totals.expenseKobo, 300000);
  assert.ok(!list.body.items.some((x) => x.id === diesel), 'voided entries hidden by default');
  assert.ok((await accounts.get(`/api/v1/cashbook/entries?includeVoided=true`)).body.items.some((x) => x.id === diesel && x.void_reason === 'Typed twice'));
  // isolation
  const bl = await bOwner.get('/api/v1/cashbook/entries'); assert.equal(bl.body.total, 0, 'school B sees none of school A’s entries');
  assert.equal((await bOwner.post(`/api/v1/cashbook/entries/${topup}/void`, { reason: 'hijack' })).status, 404);
  assert.equal((await post(bOwner, { kind: 'income', categoryId: cat('income', 'PTA levy'), amountKobo: 100, description: 'other school category' })).status, 400, 'cannot use another school’s category');
});
