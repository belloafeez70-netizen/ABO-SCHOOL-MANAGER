'use strict';
const H = require('./helpers');
const test = require('node:test');
const assert = require('node:assert/strict');
const totp = require('../src/security/totp');

let S;
test.before(async () => { S = await H.setup(); });
test.after(() => H.teardown());

test('login: generic error for unknown user and wrong password (no enumeration)', async () => {
  const c = H.client(S.app);
  const a = await c.post('/api/v1/auth/login', { loginId: 'nobody.here', password: 'whatever12' });
  const b = await c.post('/api/v1/auth/login', { loginId: 'sa.teacher2', password: 'wrong-password' });
  assert.equal(a.status, 401); assert.equal(b.status, 401); assert.equal(a.body.error.message, b.body.error.message);
});
test('session cookie is HttpOnly, SameSite=Strict, path=/ and holds an opaque token', async () => {
  const c = H.client(S.app);
  const r = await c.post('/api/v1/auth/login', { loginId: 'sa.teacher2', password: H.PASSWORD });
  const sc = [].concat(r.headers['set-cookie'])[0];
  assert.match(sc, /HttpOnly/); assert.match(sc, /SameSite=Strict/); assert.match(sc, /Path=\//);
  assert.ok(!/sa\.teacher2|role|school/i.test(sc.split(';')[0]), 'token carries no identity data');
  const db = await H.dbAs('owner');
  const tok = sc.split(';')[0].split('=')[1];
  const raw = await db.query('SELECT count(*)::int AS n FROM sessions WHERE token_hash = $1', [tok]);
  assert.equal(raw.rows[0].n, 0, 'raw token is never stored'); await db.end();
});
test('progressive lockout after repeated failures, security event + audit recorded', async () => {
  const c = H.client(S.app);
  for (let i = 0; i < 5; i++) await c.post('/api/v1/auth/login', { loginId: 'sa.accounts', password: 'bad-password-' + i });
  const locked = await c.post('/api/v1/auth/login', { loginId: 'sa.accounts', password: H.PASSWORD });
  assert.equal(locked.status, 401, 'correct password refused while locked');
  const db = await H.dbAs('owner');
  const u = (await db.query("SELECT failed_attempts, locked_until > now() AS locked, id FROM users WHERE login_id = 'sa.accounts'")).rows[0];
  assert.ok(u.locked); assert.ok(u.failed_attempts >= 5);
  assert.equal((await db.query("SELECT count(*)::int AS n FROM security_events WHERE kind = 'account_locked' AND user_id = $1", [u.id])).rows[0].n >= 1, true);
  assert.ok((await db.query("SELECT count(*)::int AS n FROM login_events WHERE user_id = $1 AND reason = 'locked'", [u.id])).rows[0].n >= 1);
  await db.query("UPDATE users SET locked_until = NULL, failed_attempts = 0 WHERE id = $1", [u.id]); await db.end();
});
test('login endpoint is rate limited per IP', async () => {
  const c = H.client(S.app, { ip: '203.0.113.77' });
  let limited = false;
  for (let i = 0; i < 14; i++) { const r = await c.post('/api/v1/auth/login', { loginId: 'nobody', password: 'x' }); if (r.status === 429) limited = true; }
  assert.ok(limited, 'one account hammered from one IP is throttled');
  // a whole class signing in from the same school IP is NOT throttled (limit is per account per IP + a high per-IP ceiling)
  const hall = H.client(S.app, { ip: '203.0.113.78' });
  for (let i = 0; i < 25; i++) assert.notEqual((await hall.post('/api/v1/auth/login', { loginId: `pupil.${i}`, password: 'x' })).status, 429, `pupil ${i}`);
});
test('CSRF: state-changing requests need the session-bound token and same origin', async () => {
  const c = await H.login(S.app, 'sa.teacher1');
  const noTok = await c.post('/api/v1/announcements/00000000-0000-4000-8000-000000000000/read', {}, { noCsrf: true });
  assert.equal(noTok.status, 403);
  const forged = await c.post('/api/v1/auth/logout-all', {}, { noCsrf: true, headers: { 'x-csrf-token': 'forged' } });
  assert.equal(forged.status, 403);
  const xorigin = await c.post('/api/v1/auth/logout-all', {}, { headers: { origin: 'https://evil.example' } });
  assert.equal(xorigin.status, 403);
  const xsite = await c.post('/api/v1/auth/logout-all', {}, { headers: { 'sec-fetch-site': 'cross-site' } });
  assert.equal(xsite.status, 403);
});
test('logout revokes the session server-side (old cookie is useless)', async () => {
  const c = await H.login(S.app, 'sa.teacher2');
  const cookie = [...c.jar][0];
  assert.equal((await c.post('/api/v1/auth/logout', {})).status, 200);
  const replay = await S.app.inject({ method: 'GET', url: '/api/v1/auth/me', headers: { cookie: `${cookie[0]}=${cookie[1]}` } });
  assert.equal(replay.statusCode, 401);
});
test('session rotation issues a new token; previous token has a short grace window only', async () => {
  const c = await H.login(S.app, 'sa.teacher2');
  const [name, oldTok] = [...c.jar][0];
  const db = await H.dbAs('owner');
  await db.query("UPDATE sessions SET rotated_at = now() - interval '1 hour' WHERE user_id = (SELECT id FROM users WHERE login_id = 'sa.teacher2') AND revoked_at IS NULL");
  const r = await c.get('/api/v1/auth/me'); assert.equal(r.status, 200);
  const newTok = c.jar.get(name); assert.notEqual(newTok, oldTok, 'token rotated');
  const grace = await S.app.inject({ method: 'GET', url: '/api/v1/auth/me', headers: { cookie: `${name}=${oldTok}` } }); assert.equal(grace.statusCode, 200);
  await db.query("UPDATE sessions SET prev_valid_until = now() - interval '1 second' WHERE prev_token_hash IS NOT NULL");
  const after = await S.app.inject({ method: 'GET', url: '/api/v1/auth/me', headers: { cookie: `${name}=${oldTok}` } }); assert.equal(after.statusCode, 401);
  await db.end();
});
test('expired sessions are rejected', async () => {
  const c = await H.login(S.app, 'sa.teacher2');
  const db = await H.dbAs('owner');
  await db.query("UPDATE sessions SET idle_expires_at = now() - interval '1 minute' WHERE user_id = (SELECT id FROM users WHERE login_id='sa.teacher2') AND revoked_at IS NULL");
  await db.end();
  assert.equal((await c.get('/api/v1/auth/me')).status, 401);
});
test('MFA: roles that require it cannot use the app until enrolled; login then needs TOTP; replay + recovery codes', async () => {
  const c = H.client(S.app);
  const r = await c.post('/api/v1/auth/login', { loginId: 'sa.admin', password: H.PASSWORD });
  assert.equal(r.body.mfaEnrollRequired, true);
  const blocked = await c.get('/api/v1/students'); assert.equal(blocked.status, 403); assert.equal(blocked.body.error.code, 'MFA_ENROLL_REQUIRED');
  const setup = await c.post('/api/v1/auth/mfa/setup', {});
  assert.match(setup.body.otpauthUri, /^otpauth:\/\/totp\//); assert.match(setup.body.qrSvgDataUrl, /^data:image\/svg\+xml;base64,/);
  const bad = await c.post('/api/v1/auth/mfa/enable', { code: '000000' }); assert.equal(bad.status, 400);
  const step = totp.stepAt(); const code = totp.hotp(setup.body.secret, step);
  const en = await c.post('/api/v1/auth/mfa/enable', { code }); assert.equal(en.status, 200); assert.equal(en.body.recoveryCodes.length, 10);
  assert.equal((await c.get('/api/v1/students')).status, 200);
  const db = await H.dbAs('owner');
  const u = (await db.query("SELECT mfa_secret_enc FROM users WHERE login_id='sa.admin'")).rows[0];
  assert.match(u.mfa_secret_enc, /^v1:/); assert.ok(!u.mfa_secret_enc.includes(setup.body.secret), 'TOTP secret encrypted at rest');
  await db.end();
  // fresh login now requires the code
  const c2 = H.client(S.app);
  const l2 = await c2.post('/api/v1/auth/login', { loginId: 'sa.admin', password: H.PASSWORD }); assert.equal(l2.body.mfaRequired, true);
  assert.equal((await c2.get('/api/v1/students')).status, 401);
  const replay = await c2.post('/api/v1/auth/mfa/verify', { code }); assert.equal(replay.status, 401, 'same TOTP code cannot be replayed');
  const rec = await c2.post('/api/v1/auth/mfa/verify', { recoveryCode: en.body.recoveryCodes[0] }); assert.equal(rec.status, 200);
  const c3 = H.client(S.app); await c3.post('/api/v1/auth/login', { loginId: 'sa.admin', password: H.PASSWORD });
  assert.equal((await c3.post('/api/v1/auth/mfa/verify', { recoveryCode: en.body.recoveryCodes[0] })).status, 401, 'recovery codes are single-use');
  // MFA cannot be disabled for a role that requires it
  const dis = await c.post('/api/v1/auth/mfa/disable', { password: H.PASSWORD, code: totp.hotp(setup.body.secret, step + 1) });
  assert.equal(dis.status, 403);
});
test('MFA brute force: 5 wrong codes revoke the pending session', async () => {
  await H.login(S.app, 'sa.bursar');                    // enrols
  const c = H.client(S.app);
  await c.post('/api/v1/auth/login', { loginId: 'sa.bursar', password: H.PASSWORD });
  let last;
  for (let i = 0; i < 5; i++) last = await c.post('/api/v1/auth/mfa/verify', { code: String(100000 + i) });
  assert.equal(last.status, 401);
  assert.equal((await c.post('/api/v1/auth/mfa/verify', { code: H.codeFor('sa.bursar') })).status, 401, 'session is gone');
});
test('password change: policy enforced, other sessions revoked, old password stops working', async () => {
  const other = await H.login(S.app, 'sa.teacher2');
  const c = await H.login(S.app, 'sa.teacher2');
  const weak = await c.post('/api/v1/auth/password/change', { currentPassword: H.PASSWORD, newPassword: 'password123' }); assert.equal(weak.status, 400);
  const ok = await c.post('/api/v1/auth/password/change', { currentPassword: H.PASSWORD, newPassword: 'Correct-Horse-9-Battery' }); assert.equal(ok.status, 200);
  assert.equal((await c.get('/api/v1/auth/me')).status, 200, 'current session survives (rotated)');
  assert.equal((await other.get('/api/v1/auth/me')).status, 401, 'other sessions revoked');
  const l = await H.client(S.app).post('/api/v1/auth/login', { loginId: 'sa.teacher2', password: H.PASSWORD }); assert.equal(l.status, 401);
  const db = await H.dbAs('owner');
  const h = (await db.query("SELECT password_hash FROM users WHERE login_id='sa.teacher2'")).rows[0].password_hash;
  assert.match(h, /^\$argon2id\$/); await db.end();
});
test('forgot/reset password: identical response, single-use expiring token, sessions revoked', async () => {
  const c = H.client(S.app);
  const a = await c.post('/api/v1/auth/password/forgot', { identifier: 'parent@school-a.example' });
  const b = await c.post('/api/v1/auth/password/forgot', { identifier: 'nobody@nowhere.example' });
  assert.equal(a.status, 200); assert.deepEqual(a.body, b.body);
  const db = await H.dbAs('owner');
  const mail = (await db.query("SELECT body_text FROM outbox_emails WHERE template = 'password_reset' ORDER BY created_at DESC LIMIT 1")).rows[0];
  const token = /token=([\w-]+)/.exec(mail.body_text)[1];
  const stored = (await db.query("SELECT token_hash FROM user_tokens WHERE kind='password_reset' ORDER BY created_at DESC LIMIT 1")).rows[0].token_hash;
  assert.notEqual(stored, token, 'only the hash is stored');
  const r = await c.post('/api/v1/auth/password/reset', { token, newPassword: 'Brand-New-Pass-42' }); assert.equal(r.status, 200);
  assert.equal((await c.post('/api/v1/auth/password/reset', { token, newPassword: 'Another-Pass-43!' })).status, 400, 'single use');
  assert.equal((await H.client(S.app).post('/api/v1/auth/login', { loginId: 'sa.parent', password: 'Brand-New-Pass-42' })).status, 200);
  await db.end();
});
test('access-code activation (replaces legacy "Login ID only"): code is single-use and hashed', async () => {
  const admin = await H.login(S.app, 'sa.owner');
  const st = await admin.get('/api/v1/students?pageSize=50');
  const target = st.body.items.find((s) => !s.has_account);
  const u = await admin.post('/api/v1/users', { fullName: 'New Pupil', loginId: 'sa.pupil9', roleKeys: ['student'], link: { type: 'student', id: target.id } });
  assert.equal(u.status, 200); assert.match(u.body.accessCode, /^[A-Z2-9]{5}-[A-Z2-9]{5}$/);
  const c = H.client(S.app);
  assert.equal((await c.post('/api/v1/auth/login', { loginId: 'sa.pupil9', password: 'anything' })).status, 401, 'no password until activated');
  assert.equal((await c.post('/api/v1/auth/activate', { loginId: 'sa.pupil9', accessCode: 'WRONG-CODE1', newPassword: 'Pupil-Pass-2026' })).status, 401);
  assert.equal((await c.post('/api/v1/auth/activate', { loginId: 'sa.pupil9', accessCode: u.body.accessCode, newPassword: 'Pupil-Pass-2026' })).status, 200);
  assert.equal((await c.post('/api/v1/auth/activate', { loginId: 'sa.pupil9', accessCode: u.body.accessCode, newPassword: 'Pupil-Pass-2027' })).status, 401, 'single use');
  const l = await c.post('/api/v1/auth/login', { loginId: 'sa.pupil9', password: 'Pupil-Pass-2026' }); assert.equal(l.status, 200);
  const me = await c.get('/api/v1/auth/me'); assert.equal(me.body.portal, 'student'); assert.equal(me.body.studentId, target.id);
});
test('users can list and revoke their own sessions (device management)', async () => {
  const a = await H.login(S.app, 'sa.teacher1'); const b = await H.login(S.app, 'sa.teacher1');
  const list = await a.get('/api/v1/auth/sessions'); assert.ok(list.body.items.length >= 2);
  for (const s of list.body.items.filter((x) => !x.current)) assert.equal((await a.del(`/api/v1/auth/sessions/${s.id}`)).status, 200);
  assert.equal((await a.get('/api/v1/auth/me')).status, 200, 'current device kept');
  assert.equal((await b.get('/api/v1/auth/me')).status, 401, 'revoked device signed out');
  assert.equal((await a.del('/api/v1/auth/sessions/00000000-0000-4000-8000-000000000000')).status, 404);
});
test('disabling a user revokes their sessions immediately', async () => {
  const t = await H.login(S.app, 'sa.teacher1'); const admin = await H.login(S.app, 'sa.owner');
  const u = await admin.get('/api/v1/users?q=sa.teacher1');
  assert.equal((await admin.post(`/api/v1/users/${u.body.items[0].id}/status`, { status: 'disabled', reason: 'test' })).status, 200);
  assert.equal((await t.get('/api/v1/auth/me')).status, 401);
  assert.equal((await admin.post(`/api/v1/users/${u.body.items[0].id}/status`, { status: 'active', reason: 'test' })).status, 200);
});
test('suspended school: sessions revoked and logins refused', async () => {
  const p = await H.login(S.app, 'abo.platform'); const b = await H.login(S.app, 'sb.teacher1');
  const r = await p.patch(`/api/v1/platform/schools/${S.B.schoolId}`, { status: 'suspended', reason: 'non-payment test' }); assert.equal(r.status, 200);
  assert.equal((await b.get('/api/v1/auth/me')).status, 401);
  const l = await H.client(S.app).post('/api/v1/auth/login', { loginId: 'sb.teacher1', password: H.PASSWORD }); assert.equal(l.status, 403);
  await p.patch(`/api/v1/platform/schools/${S.B.schoolId}`, { status: 'active', reason: 'restored' });
});
