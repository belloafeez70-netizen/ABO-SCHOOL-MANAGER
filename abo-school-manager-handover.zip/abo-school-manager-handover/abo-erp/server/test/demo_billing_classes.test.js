'use strict';
// Master prompt (11 Oct 2026): two isolated demo schools with 5-minute server-enforced sessions and automatic restore;
// flexible classes (standard list, custom, rename, reorder, switch off without losing records); owner-only payment
// settings, plans and subscriptions with server-side Paystack verification and a signed webhook.
process.env.PAYSTACK_BASE_URL = 'http://127.0.0.1:18998';
const H = require('./helpers');
const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const crypto = require('node:crypto');
const { withTx } = require('../src/db/pool');
const DEMO = require('../src/services/demo');

const SECRET = 'sk_test_platformMockSecret123456';
let S, owner, admin, platform, teacher, mock, verifyAmount = 0, verifyStatus = 'success';
test.before(async () => {
  S = await H.setup();
  mock = http.createServer((req, res) => {
    let body = ''; req.on('data', (d) => { body += d; }); req.on('end', () => {
      res.setHeader('content-type', 'application/json');
      if (req.headers.authorization !== `Bearer ${SECRET}`) { res.statusCode = 401; return res.end('{"status":false}'); }
      if (req.url === '/transaction/initialize') { const b = JSON.parse(body); return res.end(JSON.stringify({ status: true, data: { authorization_url: `https://checkout.paystack.test/${b.reference}`, reference: b.reference, amount: b.amount } })); }
      const m = /^\/transaction\/verify\/(.+)$/.exec(req.url);
      if (m) return res.end(JSON.stringify({ status: true, data: { status: verifyStatus, reference: decodeURIComponent(m[1]), amount: verifyAmount, currency: 'NGN', id: 4455 } }));
      res.statusCode = 404; res.end('{}');
    });
  }).listen(18998);
  [owner, admin, platform, teacher] = await Promise.all(['sa.owner', 'sa.admin', 'abo.platform', 'sa.teacher1'].map((l) => H.login(S.app, l)));
});
test.after(async () => { mock.close(); await H.teardown(); });

const anon = () => H.client(S.app);
// 028: a demo starts only with a demo link made by the platform owner
let PASS = null;
async function pass() { if (!PASS) { const r = await platform.post('/api/v1/platform/demo/links', { label: 'QA', uses: 50, hours: 2 }); assert.equal(r.status, 200, JSON.stringify(r.body)); PASS = r.body.code; } return PASS; }
async function startDemo(school, as) {
  const c = anon();
  const r = await c.post('/api/v1/public/demo/start', { school, as, pass: await pass() });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  if (r.body.csrf) c.setCsrf(r.body.csrf);
  return { c, r };
}

// ───────────────────────── demo schools ─────────────────────────
test('demo: two demo schools, 5-minute session, DEMO flag, no owner controls, isolated from real schools', async () => {
  const bare = await anon().get('/api/v1/public/demo');
  assert.equal(bare.body.passValid, false); assert.equal(bare.body.schools, undefined, 'without a demo link the page shows nothing to start');
  const info = await anon().get(`/api/v1/public/demo?pass=${encodeURIComponent(await pass())}`);
  assert.equal(info.status, 200); assert.equal(info.body.enabled, true); assert.equal(info.body.passValid, true); assert.equal(info.body.minutes, 5); assert.equal(info.body.schools.length, 2);
  const { c, r } = await startDemo('primary', 'admin');
  const left = new Date(r.body.expiresAt).getTime() - Date.now();
  assert.ok(left > 4 * 60000 && left <= 5 * 60000 + 2000, `expires in ${left} ms`);
  const me = await c.get('/api/v1/auth/me');
  assert.equal(me.status, 200); assert.ok(me.body.demo && me.body.demo.expiresAt); assert.match(me.body.school.name, /Sunrise/);
  for (const p of ['users.create', 'roles.manage', 'settings.update', 'users.impersonate', 'reports.export', 'imports.run']) assert.ok(!me.body.permissions.includes(p), `demo has no ${p}`);
  assert.equal((await c.get('/api/v1/users')).status, 403, 'logins page refused');
  assert.equal((await c.put('/api/v1/school/settings', { passMark: 50 })).status, 403, 'school settings refused');
  assert.equal((await c.get('/api/v1/platform/schools')).status, 403);
  assert.equal((await c.get('/api/v1/billing')).status, 403, 'billing is not part of a demo');
  const st = await c.get('/api/v1/students?pageSize=100');
  assert.equal(st.status, 200); assert.ok(st.body.total >= 20);
  assert.ok(!st.body.items.some((s) => /^SA\//.test(s.admission_no) || /^SB\//.test(s.admission_no)), 'no real-school pupils');
  // the second demo school is a separate tenant
  const d2 = await startDemo('secondary', 'teacher');
  const st2 = await d2.c.get('/api/v1/students?pageSize=100');
  assert.ok(st2.body.items.every((s) => /^DEMO2\//.test(s.admission_no)), 'secondary demo sees only its own pupils');
  assert.ok(st.body.items.every((s) => /^DEMO1\//.test(s.admission_no)));
  // demo accounts cannot sign in with a password; a real owner cannot see demo data
  const login = await anon().post('/api/v1/auth/login', { loginId: 'demo1.admin', password: 'Demo#School2026' });
  assert.equal(login.status, 401);
  const real = await owner.get('/api/v1/students?pageSize=100');
  assert.ok(!real.body.items.some((s) => /^DEMO/.test(s.admission_no)));
});

test('demo: the server ends the session when the time is up (the countdown is only a display)', async () => {
  const { c } = await startDemo('primary', 'teacher');
  assert.equal((await c.get('/api/v1/auth/me')).status, 200);
  const db = await H.dbAs('admin');
  try { await db.query("UPDATE sessions SET expires_at = now() - interval '1 second' WHERE demo AND user_id = (SELECT id FROM users WHERE login_id = 'demo1.teacher1')"); } finally { await db.end(); }
  const after = await c.get('/api/v1/students');
  assert.equal(after.status, 401, 'expired demo session refused by the server');
});

test('demo: changes are thrown away — the demo school is rebuilt after the last visitor leaves; real schools untouched', async () => {
  const realBefore = (await owner.get('/api/v1/students?pageSize=1')).body.total;
  const { c } = await startDemo('primary', 'admin');
  const made = await c.post('/api/v1/announcements', { title: 'Visitor was here', body: 'Testing the demo', audience: 'all' });
  assert.equal(made.status, 200, JSON.stringify(made.body));
  await new Promise((r) => setTimeout(r, 300));
  const db = await H.dbAs('admin');
  try {
    const before = (await db.query("SELECT id, demo_dirty_at FROM schools WHERE slug = 'demo-sunrise'")).rows[0];
    assert.ok(before.demo_dirty_at, 'marked as changed');
    assert.equal(await DEMO.resetIdleDemos(), 0, 'not reset while a visitor is still inside');
    await db.query("UPDATE sessions SET expires_at = now() - interval '1 second' WHERE school_id = $1", [before.id]);
    assert.equal(await DEMO.resetIdleDemos(), 1, 'restored once nobody uses it');
    const after = (await db.query("SELECT id, demo_dirty_at FROM schools WHERE slug = 'demo-sunrise'")).rows[0];
    assert.notEqual(after.id, before.id); assert.equal(after.demo_dirty_at, null);
    assert.equal((await db.query("SELECT count(*)::int AS n FROM announcements WHERE title = 'Visitor was here'")).rows[0].n, 0, 'visitor changes are gone');
    assert.equal((await db.query("SELECT count(*)::int AS n FROM schools WHERE slug = 'school-a'")).rows[0].n, 1);
    // the reset can never touch a real school: the DELETE is guarded by is_demo
    await assert.rejects(DEMO.resetDemoSchool('school-a'), /not a demo school/);
  } finally { await db.end(); }
  assert.equal((await owner.get('/api/v1/students?pageSize=1')).body.total, realBefore);
  const again = await startDemo('primary', 'parent');
  assert.equal((await again.c.get('/api/v1/auth/me')).status, 200, 'a new visitor gets the fresh demo');
});

test('demo: platform owner sets the timer (1–5 minutes) or switches demos off', async () => {
  assert.equal((await platform.put('/api/v1/platform/billing/settings', { demoMinutes: 6 })).status, 400, 'never more than 5 minutes');
  assert.equal((await platform.put('/api/v1/platform/billing/settings', { demoMinutes: 2 })).status, 200);
  const { r } = await startDemo('secondary', 'student');
  const left = new Date(r.body.expiresAt).getTime() - Date.now(); assert.ok(left <= 2 * 60000 + 2000 && left > 60000, String(left));
  assert.equal((await platform.put('/api/v1/platform/billing/settings', { demoEnabled: false })).status, 200);
  const usedBefore = (await platform.get('/api/v1/platform/demo/links')).body.items.find((x) => x.label === 'QA').uses;
  assert.equal((await anon().post('/api/v1/public/demo/start', { school: 'primary', as: 'admin', pass: await pass() })).status, 404);
  assert.equal((await platform.get('/api/v1/platform/demo/links')).body.items.find((x) => x.label === 'QA').uses, usedBefore, 'a demo that did not start gives the use back');
  assert.equal((await owner.put('/api/v1/platform/billing/settings', { demoEnabled: true })).status, 403, 'a school owner cannot change platform settings');
  assert.equal((await platform.put('/api/v1/platform/billing/settings', { demoEnabled: true, demoMinutes: 5 })).status, 200);
});

// ───────────────────────── classes ─────────────────────────
test('classes: standard list (Creche … SS 3), custom classes, rename, reorder, switch off/on without losing records', async () => {
  const presets = (await admin.get('/api/v1/academic/class-presets')).body.items.map((p) => p.name);
  assert.deepEqual(presets.slice(0, 4), ['Creche', 'Nursery 1', 'Nursery 2', 'Kindergarten']); assert.ok(presets.includes('Primary 6') && presets.includes('JSS 3') && presets.includes('SS 3')); assert.equal(presets.length, 16);
  const mk = await admin.post('/api/v1/academic/classes/presets', { names: ['Creche', 'Nursery 1', 'Kindergarten', 'SS 3'] });
  assert.equal(mk.status, 200, JSON.stringify(mk.body)); assert.equal(mk.body.items.length, 4);
  assert.equal((await admin.post('/api/v1/academic/classes/presets', { names: ['Creche'] })).body.skipped.length, 1, 'no duplicates');
  assert.equal((await admin.post('/api/v1/academic/classes/presets', { names: ['Grade 9'] })).status, 400);
  const custom = await admin.post('/api/v1/academic/classes', { name: 'Pre-Nursery', section: 'nursery', level: 'Playgroup' });
  assert.equal(custom.status, 200); const cid = custom.body.items[0].id;
  assert.equal((await admin.patch(`/api/v1/academic/classes/${cid}`, { name: 'Little Stars' })).status, 200, 'rename');
  assert.equal((await admin.patch(`/api/v1/academic/classes/${cid}`, { name: 'Creche' })).status, 409, 'cannot rename onto another class');
  let ac = (await admin.get('/api/v1/academic')).body.classes;
  const renamed = ac.find((c) => c.id === cid); assert.equal(renamed.display_name, 'LITTLE STARS'); assert.equal(renamed.level, 'Playgroup');
  const ids = ac.map((c) => c.id).reverse();
  assert.equal((await admin.put('/api/v1/academic/classes/order', { ids })).status, 200);
  ac = (await admin.get('/api/v1/academic')).body.classes; assert.equal(ac[0].id, ids[0], 'new order kept');
  // a class with pupils cannot be switched off; an empty one can, keeps its records, takes no new pupils, and comes back
  const full = ac.find((c) => c.display_name === 'BASIC 1A');
  const off1 = await admin.patch(`/api/v1/academic/classes/${full.id}`, { active: false }); assert.equal(off1.status, 409); assert.match(off1.body.error.message, /Move them/);
  assert.equal((await admin.patch(`/api/v1/academic/classes/${cid}`, { active: false })).status, 200);
  ac = (await admin.get('/api/v1/academic')).body.classes; assert.equal(ac.find((c) => c.id === cid).active, false);
  const db = await H.dbAs('app');
  try {
    await db.query('BEGIN'); await db.query("SELECT set_config('app.school_id', $1, true)", [S.A.schoolId]);
    const st = (await db.query("SELECT s.id, e.session_id FROM students s JOIN student_enrollments e ON e.student_id = s.id LIMIT 1")).rows[0];
    await assert.rejects(db.query('UPDATE student_enrollments SET class_id = $1 WHERE student_id = $2', [cid, st.id]), /CLASS_INACTIVE/);
    await db.query('ROLLBACK');
  } finally { await db.end(); }
  assert.equal((await admin.patch(`/api/v1/academic/classes/${cid}`, { active: true })).status, 200);
  assert.equal((await teacher.post('/api/v1/academic/classes/presets', { names: ['JSS 1'] })).status, 403, 'teachers cannot change classes');
});

// ───────────────────────── payment settings & subscriptions ─────────────────────────
test('payments: owner-only settings, secret never returned, plans, school checkout with server amount, verified before success, signed webhook', async () => {
  assert.equal((await owner.get('/api/v1/platform/billing/settings')).status, 403, 'school owner cannot open platform payment settings');
  assert.equal((await platform.put('/api/v1/platform/billing/settings', { paystackPublicKey: 'pk_test_abcdef123456', paystackSecretKey: SECRET, bankDetails: 'Bank: Demo Bank · Account: 0123456789 · A.B.O. Edu Consultant' })).status, 200);
  const st = await platform.get('/api/v1/platform/billing/settings');
  assert.equal(st.body.secret_set, true); assert.equal(st.body.paystack_secret_hint, 'sk_test_…3456');
  assert.ok(!JSON.stringify(st.body).includes(SECRET), 'secret never sent back');
  const db = await H.dbAs('admin');
  try {
    const raw = (await db.query('SELECT paystack_secret_enc FROM platform_settings')).rows[0].paystack_secret_enc;
    assert.ok(raw && !raw.includes(SECRET), 'stored encrypted');
    const audits = JSON.stringify((await db.query("SELECT metadata FROM audit_logs WHERE action = 'billing.settings_updated'")).rows);
    assert.ok(!audits.includes(SECRET), 'key not in the audit log');
  } finally { await db.end(); }
  assert.equal((await platform.put('/api/v1/platform/billing/settings', { paystackSecretKey: 'not-a-key' })).status, 400);
  const plan = await platform.post('/api/v1/platform/billing/plans', { code: 'term-plus', name: 'Term Plus', price: 20000, period: 'term', periodDays: 120 });
  assert.equal(plan.status, 200); assert.equal(Number(plan.body.price_kobo), 2000000);
  assert.equal((await owner.post('/api/v1/platform/billing/plans', { code: 'free', name: 'Free', price: 0, period: 'year', periodDays: 365 })).status, 403);
  // the school sees its trial and the plans
  const mine = await owner.get('/api/v1/billing');
  assert.equal(mine.status, 200); assert.equal(mine.body.subscription.status, 'trial'); assert.ok(mine.body.plans.some((p) => p.code === 'term-plus')); assert.equal(mine.body.onlinePayments, true);
  assert.match(mine.body.bankDetails, /Demo Bank/);
  assert.equal((await teacher.post('/api/v1/billing/checkout', { planId: plan.body.id, email: 't@example.com' })).status, 403, 'only school managers pay');
  const co = await owner.post('/api/v1/billing/checkout', { planId: plan.body.id, email: 'owner@school-a.example' });
  assert.equal(co.status, 200, JSON.stringify(co.body)); assert.match(co.body.authorizationUrl, /^https:\/\/checkout\.paystack\.test\/SUB-/);
  // Paystack says success but with a different amount → refused (never marked paid)
  verifyAmount = 100; verifyStatus = 'success';
  let v = await owner.post('/api/v1/billing/verify', { reference: co.body.reference });
  assert.equal(v.body.ok, false); assert.equal(v.body.status, 'amount_mismatch');
  assert.equal((await owner.get('/api/v1/billing')).body.subscription.status, 'trial');
  // a fresh checkout, unpaid → pending, not success
  const co2 = await owner.post('/api/v1/billing/checkout', { planId: plan.body.id, email: 'owner@school-a.example' });
  verifyStatus = 'abandoned'; v = await owner.post('/api/v1/billing/verify', { reference: co2.body.reference }); assert.equal(v.body.ok, false);
  // webhook with a bad signature is refused; with a good signature + genuine verification the subscription becomes active
  verifyStatus = 'success'; verifyAmount = 2000000;
  const co3 = await owner.post('/api/v1/billing/checkout', { planId: plan.body.id, email: 'owner@school-a.example' });
  const evt = JSON.stringify({ event: 'charge.success', data: { reference: co3.body.reference, amount: 2000000 } });
  const bad = await S.app.inject({ method: 'POST', url: '/api/v1/billing/webhook/paystack', payload: evt, headers: { 'content-type': 'application/json', 'x-paystack-signature': 'deadbeef' } });
  assert.equal(bad.statusCode, 401);
  assert.equal((await owner.get('/api/v1/billing')).body.subscription.status, 'trial', 'still not paid');
  const sig = crypto.createHmac('sha512', SECRET).update(evt).digest('hex');
  const good = await S.app.inject({ method: 'POST', url: '/api/v1/billing/webhook/paystack', payload: evt, headers: { 'content-type': 'application/json', 'x-paystack-signature': sig } });
  assert.equal(good.statusCode, 200, good.body);
  const after = (await owner.get('/api/v1/billing')).body;
  assert.equal(after.subscription.status, 'active'); assert.equal(after.subscription.plan, 'Term Plus');
  const days = (new Date(after.subscription.current_period_end) - Date.now()) / 86400000; assert.ok(days > 119 && days <= 120.1, String(days));
  // the same webhook again changes nothing (idempotent)
  await S.app.inject({ method: 'POST', url: '/api/v1/billing/webhook/paystack', payload: evt, headers: { 'content-type': 'application/json', 'x-paystack-signature': sig } });
  assert.equal(new Date((await owner.get('/api/v1/billing')).body.subscription.current_period_end).getTime(), new Date(after.subscription.current_period_end).getTime());
  // platform sees subscriptions and payments; school B sees nothing of school A
  const subs = (await platform.get('/api/v1/platform/billing/subscriptions')).body.items;
  assert.ok(subs.some((s) => s.slug === 'school-a' && s.status === 'active'));
  const pays = (await platform.get('/api/v1/platform/billing/payments')).body.items;
  assert.ok(pays.some((p) => p.status === 'success') && pays.some((p) => p.status === 'failed'));
  const bOwner = await H.login(S.app, 'sb.owner');
  assert.equal((await bOwner.get('/api/v1/billing')).body.payments.length, 0, 'school B cannot see school A payments');
  assert.equal((await bOwner.post('/api/v1/billing/verify', { reference: co3.body.reference })).status, 404);
  // manual change (bank transfer) needs a reason and is audited; expiry is automatic
  assert.equal((await platform.patch(`/api/v1/platform/billing/subscriptions/${S.B.schoolId}`, { status: 'active', periodEnd: new Date(Date.now() - 1000).toISOString() })).status, 400, 'reason required');
  assert.equal((await platform.patch(`/api/v1/platform/billing/subscriptions/${S.B.schoolId}`, { status: 'active', periodEnd: new Date(Date.now() - 1000).toISOString(), note: 'Bank transfer confirmed (test)' })).status, 200);
  await withTx({ platform: true }, (c) => c.query(`UPDATE school_subscriptions ss SET status = 'expired' FROM schools s WHERE s.id = ss.school_id AND NOT s.is_demo AND ss.status = 'active' AND ss.current_period_end < now()`));
  assert.equal((await bOwner.get('/api/v1/billing')).body.subscription.status, 'expired');
});

test('demo links (028): only the platform owner makes them; no link, wrong, used-up, expired-school or cancelled links start nothing; only a hash is stored', async () => {
  assert.equal((await owner.post('/api/v1/platform/demo/links', {})).status, 403, 'a school owner cannot make demo links');
  assert.equal((await teacher.get('/api/v1/platform/demo/links')).status, 403);
  assert.equal((await anon().post('/api/v1/public/demo/start', { school: 'primary', as: 'admin' })).status, 400, 'the link is required');
  let r = await anon().post('/api/v1/public/demo/start', { school: 'primary', as: 'admin', pass: 'DEMO-AAAA-BBBB-CCCC' });
  assert.equal(r.status, 403); assert.match(r.body.error.message, /not valid/);
  // one use, primary school only
  r = await platform.post('/api/v1/platform/demo/links', { label: 'Greenfield Academy — Mrs Ade', school: 'primary', uses: 1, hours: 1 });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  const one = r.body; assert.match(one.code, /^DEMO-[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}$/); assert.match(one.link, /#\/demo\?pass=DEMO-/);
  const info = (await anon().get(`/api/v1/public/demo?pass=${one.code}`)).body;
  assert.deepEqual(info.schools.map((x) => x.key), ['primary'], 'a link for one school shows only that school'); assert.equal(info.usesLeft, 1);
  assert.equal((await anon().get(`/api/v1/public/demo?pass=${one.code.toLowerCase()}`)).body.passValid, true, 'typing it in small letters still works');
  assert.equal((await anon().post('/api/v1/public/demo/start', { school: 'secondary', as: 'admin', pass: one.code })).status, 403, 'not for the other demo school');
  assert.equal((await anon().post('/api/v1/public/demo/start', { school: 'primary', as: 'teacher', pass: one.code })).status, 200);
  assert.equal((await anon().post('/api/v1/public/demo/start', { school: 'primary', as: 'teacher', pass: one.code })).status, 403, 'used up');
  // two people pressing at the same moment on the last use: only one starts
  r = await platform.post('/api/v1/platform/demo/links', { label: 'race', uses: 1 });
  const both = await Promise.all([1, 2].map(() => anon().post('/api/v1/public/demo/start', { school: 'secondary', as: 'student', pass: r.body.code })));
  assert.deepEqual(both.map((x) => x.status).sort(), [200, 403]);
  // cancel
  r = await platform.post('/api/v1/platform/demo/links', { label: 'cancel me', uses: 5 });
  assert.equal((await platform.post(`/api/v1/platform/demo/links/${r.body.id}/cancel`)).status, 200);
  assert.equal((await anon().post('/api/v1/public/demo/start', { school: 'primary', as: 'admin', pass: r.body.code })).status, 403, 'a cancelled link starts nothing');
  // list + storage
  const list = (await platform.get('/api/v1/platform/demo/links')).body;
  const st = Object.fromEntries(list.items.map((x) => [x.label, x.status]));
  assert.equal(st['Greenfield Academy — Mrs Ade'], 'used up'); assert.equal(st['cancel me'], 'cancelled'); assert.equal(st.QA, 'active');
  assert.ok(!JSON.stringify(list).includes(one.code), 'the code is never shown again');
  const db = await H.dbAs('admin');
  try {
    const rows = (await db.query('SELECT code_hash FROM demo_passes')).rows;
    assert.ok(rows.every((x) => /^[0-9a-f]{64}$/.test(x.code_hash)) && !JSON.stringify(rows).includes(one.code), 'only a hash is stored');
    const app = await H.dbAs('app');
    try { assert.equal((await app.query('SELECT count(*)::int AS n FROM demo_passes')).rows[0].n, 0, 'the app role (no platform context) sees no demo links'); } finally { await app.end(); }
  } finally { await db.end(); }
});
