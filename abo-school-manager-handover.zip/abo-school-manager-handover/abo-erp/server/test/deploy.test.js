'use strict';
// Netlify + separate API deployment: edge proxy behaviour, trusted-proxy IP handling, direct-access blocking,
// origin allow-list, production config guards, error alert scrubbing and the web build.
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');
const http = require('node:http');
const { spawnSync, execFileSync } = require('node:child_process');
const { pathToFileURL } = require('node:url');

const ROOT = path.resolve(__dirname, '../..');
const SECRET = 'q'.repeat(20) + 'Zx9Lm2Pv8Rt4Wy6Bn1Ck3Df5Gh7Jk0Ls2Qa4Se6Ud8Vf0Wg';     // 64 chars, strong enough for the check
const PROD_ENV = {
  NODE_ENV: 'production', PUBLIC_ORIGIN: 'https://abo-demo.netlify.app', DB_SSL: 'off', LOG_LEVEL: 'silent',
  DATABASE_URL: 'postgres://abo_app:not-used-in-this-test@127.0.0.1:1/none', CSRF_SECRET: 'A'.repeat(20) + 'kP3mQ8vR2tW6yB1cD4fG7hJ0kL5nZ9xS',
  DATA_ENCRYPTION_KEY: 'B'.repeat(20) + 'kP3mQ8vR2tW6yB1cD4fG7hJ0kL5nZ9xS', FILE_URL_SECRET: 'C'.repeat(20) + 'kP3mQ8vR2tW6yB1cD4fG7hJ0kL5nZ9xS',
  PROXY_SHARED_SECRET: SECRET, REQUIRE_PROXY_SECRET: 'true', SERVE_FRONTEND: 'false', RUN_WORKER_IN_PROCESS: 'false', STORAGE_DRIVER: 'local',
};
// run a snippet against a freshly configured app in a child process (config is read once per process)
function inChild(env, body) {
  const code = `(async () => { const { buildApp } = require('./server/src/app'); const app = buildApp({ logger: false });
    app.get('/__probe', async (req) => ({ ip: req.ip, via: !!req.viaProxy, leaked: req.headers['x-abo-proxy-secret'] || null }));
    await app.ready(); const out = {}; ${body}; console.log(JSON.stringify(out)); await app.close(); process.exit(0); })().catch((e) => { console.log(JSON.stringify({ startupError: e.message })); process.exit(0); });`;
  const r = spawnSync(process.execPath, ['-e', code], { cwd: ROOT, env: { PATH: process.env.PATH, ...env }, encoding: 'utf8', timeout: 30000 });
  const line = (r.stdout || '').trim().split('\n').pop();
  try { return JSON.parse(line); } catch { throw new Error(`child failed: ${r.stdout}\n${r.stderr}`); }
}

test('API behind Netlify: only requests carrying the shared secret are served; the real client IP comes from the proxy', () => {
  const o = inChild(PROD_ENV, `
    const s = '${SECRET}';
    const inj = (h, url = '/__probe') => app.inject({ url, headers: h, remoteAddress: '10.0.0.5' }).then((r) => ({ status: r.statusCode, body: r.json() }));
    out.direct = await inj({});
    out.spoof = await inj({ 'x-abo-proxy-secret': 'wrong', 'x-abo-client-ip': '6.6.6.6' });
    out.proxied = await inj({ 'x-abo-proxy-secret': s, 'x-abo-client-ip': '102.89.1.20' });
    out.badIp = await inj({ 'x-abo-proxy-secret': s, 'x-abo-client-ip': 'not-an-ip' });
    out.health = await inj({}, '/healthz');
    out.webhook = (await app.inject({ method: 'POST', url: '/api/v1/payments/webhook/paystack', payload: '{}', headers: { 'content-type': 'application/json' } })).statusCode;
    out.root = await inj({ 'x-abo-proxy-secret': s }, '/');
    out.ce_evil = (await app.inject({ method: 'POST', url: '/api/v1/client-errors', payload: { message: 'x' }, headers: { 'x-abo-proxy-secret': s, origin: 'https://evil.example' } })).statusCode;
    out.ce_ok = (await app.inject({ method: 'POST', url: '/api/v1/client-errors', payload: { message: 'TypeError: x is undefined', route: '#/reset?token=abc' }, headers: { 'x-abo-proxy-secret': s, origin: 'https://abo-demo.netlify.app' } })).statusCode;
    const pre = await app.inject({ method: 'OPTIONS', url: '/api/v1/auth/login', headers: { 'x-abo-proxy-secret': s, origin: 'https://evil.example', 'access-control-request-method': 'POST' } });
    out.corsEvil = pre.headers['access-control-allow-origin'] || null;
    const pre2 = await app.inject({ method: 'OPTIONS', url: '/api/v1/auth/login', headers: { 'x-abo-proxy-secret': s, origin: 'https://abo-demo.netlify.app', 'access-control-request-method': 'POST' } });
    out.corsOk = pre2.headers['access-control-allow-origin'] || null;`);
  assert.equal(o.startupError, undefined, o.startupError);
  assert.equal(o.direct.status, 403); assert.equal(o.direct.body.error.code, 'DIRECT_ACCESS_BLOCKED');
  assert.equal(o.spoof.status, 403, 'wrong secret is refused and its IP header ignored');
  assert.equal(o.proxied.status, 200); assert.equal(o.proxied.body.ip, '102.89.1.20'); assert.equal(o.proxied.body.via, true);
  assert.equal(o.proxied.body.leaked, null, 'the secret header is removed before handlers/logs');
  assert.equal(o.badIp.body.ip, '10.0.0.5', 'a malformed client IP falls back to the socket address');
  assert.equal(o.health.status, 200, 'health checks stay reachable for the host platform');
  assert.notEqual(o.webhook, 403, 'payment webhooks (own HMAC signature) are not blocked');
  assert.equal(o.root.status, 404, 'API-only mode does not serve the web app');
  assert.equal(o.ce_evil, 403, 'cross-origin POST refused'); assert.equal(o.ce_ok, 202);
  assert.equal(o.corsEvil, null); assert.equal(o.corsOk, 'https://abo-demo.netlify.app');
});

test('custom domain later = configuration only: extra origins and a preview pattern are accepted, others refused', () => {
  const o = inChild({ ...PROD_ENV, PUBLIC_ORIGIN: 'https://portal.myschool.com.ng', ALLOWED_ORIGINS: 'https://abo-demo.netlify.app', ALLOWED_ORIGIN_REGEX: '^https://deploy-preview-[0-9]+--abo-demo\\.netlify\\.app$' }, `
    const c = require('./server/src/config');
    out.list = c.allowedOrigins; out.pub = c.publicOrigin;
    out.a = c.isAllowedOrigin('https://portal.myschool.com.ng'); out.b = c.isAllowedOrigin('https://abo-demo.netlify.app');
    out.c = c.isAllowedOrigin('https://deploy-preview-12--abo-demo.netlify.app'); out.d = c.isAllowedOrigin('https://deploy-preview-12--evil.netlify.app');
    out.e = c.isAllowedOrigin('https://abo-demo.netlify.app.evil.com'); out.f = c.isAllowedOrigin(undefined);`);
  assert.deepEqual(o.list, ['https://portal.myschool.com.ng', 'https://abo-demo.netlify.app']);
  assert.equal(o.pub, 'https://portal.myschool.com.ng');
  assert.deepEqual([o.a, o.b, o.c, o.d, o.e, o.f], [true, true, true, false, false, false]);
});

test('production config guards refuse unsafe deployments at startup', () => {
  const bad = (extra) => inChild({ ...PROD_ENV, ...extra }, 'out.ok = true').startupError || null;
  assert.match(bad({ PUBLIC_ORIGIN: 'https://abo-demo.netlify.app/app' }), /origin only/);
  assert.match(bad({ PUBLIC_ORIGIN: 'http://abo-demo.netlify.app' }), /https/);
  assert.match(bad({ ALLOWED_ORIGINS: 'http://insecure.example' }), /https/);
  assert.match(bad({ ALLOWED_ORIGIN_REGEX: 'https://.*\\.netlify\\.app' }), /anchored/);
  assert.match(bad({ PROXY_SHARED_SECRET: '', REQUIRE_PROXY_SECRET: 'true' }), /PROXY_SHARED_SECRET/);
  assert.match(bad({ PROXY_SHARED_SECRET: 'short' }), /entropy/);
  assert.match(bad({ CSRF_SECRET: 'change_me_change_me_change_me_change_me_change_me' }), /placeholder/);
  assert.match(bad({ ERROR_WEBHOOK_URL: 'http://hooks.example/x' }), /https/);
  assert.equal(bad({}), null, 'the valid production configuration starts');
});

async function loadEdge() {
  const tmp = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'edge-')), 'api-proxy.mjs');
  fs.copyFileSync(path.join(ROOT, 'netlify/edge-functions/api-proxy.js'), tmp);
  return (await import(pathToFileURL(tmp).href)).default;
}
test('Netlify edge proxy: adds secret + real IP, strips spoofed headers, streams bodies, keeps cookies, never follows redirects', async () => {
  const seen = [];
  const up = http.createServer((req, res) => {
    let body = ''; req.on('data', (d) => { body += d; }); req.on('end', () => {
      seen.push({ url: req.url, method: req.method, headers: req.headers, body });
      if (req.url.startsWith('/api/v1/redirect')) { res.writeHead(302, { location: 'https://files.example/x' }); return res.end(); }
      res.writeHead(200, { 'content-type': 'application/json', 'set-cookie': ['a=1; Path=/; HttpOnly', 'b=2; Path=/'] }); res.end('{"ok":true}');
    });
  });
  await new Promise((r) => up.listen(0, '127.0.0.1', r));
  const origin = `http://127.0.0.1:${up.address().port}`;
  const envs = { API_ORIGIN: origin, PROXY_SHARED_SECRET: SECRET };
  globalThis.Netlify = { env: { get: (k) => envs[k] } };
  const edge = await loadEdge();
  const ctx = { ip: '102.89.3.4', requestId: 'r1', deploy: { context: 'production' } };
  try {
    const r = await edge(new Request('https://abo-demo.netlify.app/api/v1/auth/login?x=1', { method: 'POST', body: '{"loginId":"a"}',
      headers: { 'content-type': 'application/json', origin: 'https://abo-demo.netlify.app', cookie: 's=1', 'x-abo-proxy-secret': 'forged', 'x-abo-client-ip': '6.6.6.6', 'x-forwarded-for': '6.6.6.6' } }), ctx);
    assert.equal(r.status, 200);
    assert.deepEqual(r.headers.getSetCookie(), ['a=1; Path=/; HttpOnly', 'b=2; Path=/'], 'both cookies reach the browser');
    const h = seen[0].headers;
    assert.equal(seen[0].url, '/api/v1/auth/login?x=1'); assert.equal(seen[0].body, '{"loginId":"a"}');
    assert.equal(h['x-abo-proxy-secret'], SECRET, 'forged secret replaced by the real one');
    assert.equal(h['x-abo-client-ip'], '102.89.3.4', 'client-supplied IP header replaced by Netlify context.ip');
    assert.equal(h['x-forwarded-for'], undefined); assert.equal(h.origin, 'https://abo-demo.netlify.app'); assert.equal(h.cookie, 's=1');
    const red = await edge(new Request('https://abo-demo.netlify.app/api/v1/redirect'), ctx);
    assert.equal(red.status, 302); assert.equal(red.headers.get('location'), 'https://files.example/x');
    const prev = await edge(new Request('https://x.netlify.app/api/v1/x'), { ...ctx, deploy: { context: 'deploy-preview' } });
    assert.equal(prev.status, 503, 'previews are not connected to the production API unless explicitly enabled');
    envs.API_ORIGIN = 'http://api.example.com';
    assert.equal((await edge(new Request('https://x.netlify.app/api/v1/x'), ctx)).status, 503, 'non-https API origin refused');
    envs.API_ORIGIN = 'http://127.0.0.1:1';
    const down = await edge(new Request('https://x.netlify.app/api/v1/x'), ctx);
    assert.equal(down.status, 502); assert.equal((await down.json()).error.code, 'UPSTREAM_UNAVAILABLE');
    delete envs.PROXY_SHARED_SECRET;
    assert.equal((await edge(new Request('https://x.netlify.app/api/v1/x'), ctx)).status, 503);
  } finally { up.close(); delete globalThis.Netlify; }
});

test('error alerts never contain personal data or secrets', () => {
  const { scrub } = require('../src/lib/alerts');
  const s = scrub('failed for ada@example.com phone 08031234567 +2348031234567 token=abc123 id 3f2a1c9e-1111-4222-8333-444455556666');
  assert.ok(!/ada@|0803|234803|abc123|3f2a1c9e/.test(s), s);
});

test('web build: hashed, minified, code-split, strict headers, and no secrets in the published files', () => {
  const out = fs.mkdtempSync(path.join(os.tmpdir(), 'webbuild-'));
  execFileSync(process.execPath, ['scripts/build-web.js'], { cwd: ROOT, env: { ...process.env, WEB_OUT: out, CSP_IMG_SRC: 'https://cdn.example.com javascript:alert(1)' }, stdio: 'pipe' });
  const html = fs.readFileSync(path.join(out, 'index.html'), 'utf8');
  assert.match(html, /\/assets\/js\/main-[A-Z0-9]+\.js/); assert.match(html, /\/assets\/css\/app-[0-9a-f]{10}\.css/); assert.match(html, /data-release="/);
  assert.ok(!/<script>(?!<)/.test(html) && !/style=/.test(html), 'no inline script/style (CSP)');
  const chunks = fs.readdirSync(path.join(out, 'assets/js/c'));
  assert.ok(chunks.some((f) => /^lessons-/.test(f)) && chunks.some((f) => /^cbt_take-/.test(f)), 'every page is a lazy chunk');
  const hdr = fs.readFileSync(path.join(out, '_headers'), 'utf8');
  assert.match(hdr, /Content-Security-Policy: default-src 'self'; script-src 'self'/);
  assert.match(hdr, /img-src 'self' data: blob: https:\/\/cdn\.example\.com;/, 'only valid https origins are added to the CSP');
  assert.ok(!hdr.includes('javascript:'));
  assert.match(hdr, /\/assets\/js\/\*\n {2}Cache-Control: public, max-age=31536000, immutable/);
  const all = []; const walk = (d) => { for (const f of fs.readdirSync(d)) { const p = path.join(d, f); if (fs.statSync(p).isDirectory()) walk(p); else all.push(fs.readFileSync(p, 'utf8')); } }; walk(out);
  const text = all.join('\n');
  for (const k of ['DATABASE_URL', 'CSRF_SECRET', 'DATA_ENCRYPTION_KEY', 'PROXY_SHARED_SECRET', 'PAYSTACK_SECRET', 'abo_app_dev_password', 'abo_owner_dev_password']) assert.ok(!text.includes(k), `${k} must not appear in the frontend`);
});

test('several API instances share one rate-limit budget through Redis (RATE_LIMIT_REDIS_URL)', { skip: !process.env.TEST_REDIS_URL && 'set TEST_REDIS_URL to run' }, () => {
  const run = (redis) => inChild({ NODE_ENV: 'development', LOG_LEVEL: 'silent', RUN_WORKER_IN_PROCESS: 'false', ...(redis ? { RATE_LIMIT_REDIS_URL: redis } : {}) }, `
    const second = buildApp({ logger: false }); await second.ready();
    const codes = [];
    for (let i = 0; i < 30; i++) {
      const a = i % 2 ? second : app;
      codes.push((await a.inject({ method: 'POST', url: '/api/v1/client-errors', payload: { message: 'redis-test-' + Date.now() + '-' + i }, remoteAddress: '10.9.9.9' })).statusCode);
    }
    out.accepted = codes.filter((c) => c === 202).length; out.limited = codes.filter((c) => c === 429).length; await second.close();`);
  const local = run(null);
  assert.equal(local.limited, 0, 'without Redis each instance keeps its own counter (2 × 20 allowed)');
  const shared = run(process.env.TEST_REDIS_URL);
  assert.equal(shared.startupError, undefined, shared.startupError);
  assert.equal(shared.accepted, 20, 'with Redis the 20/min budget is shared by both instances'); assert.equal(shared.limited, 10);
});

test('own-domain direct API mode (optional, for later): public API URL baked in, CSP widened only for it, platform domains refused', () => {
  const out = fs.mkdtempSync(path.join(os.tmpdir(), 'webdirect-'));
  execFileSync(process.execPath, ['scripts/build-web.js'], { cwd: ROOT, env: { ...process.env, WEB_OUT: out, PUBLIC_API_BASE: 'https://api.myschool.com.ng' }, stdio: 'pipe' });
  const hdr = fs.readFileSync(path.join(out, '_headers'), 'utf8');
  assert.match(hdr, /connect-src 'self' https:\/\/api\.myschool\.com\.ng;/); assert.match(hdr, /img-src 'self' data: blob: https:\/\/api\.myschool\.com\.ng;/);
  const js = []; const walk = (d) => { for (const f of fs.readdirSync(d)) { const p = path.join(d, f); if (fs.statSync(p).isDirectory()) walk(p); else if (p.endsWith('.js')) js.push(fs.readFileSync(p, 'utf8')); } }; walk(out);
  assert.ok(js.some((t) => t.includes('https://api.myschool.com.ng')), 'API base compiled into the bundle');
  const bad = spawnSync(process.execPath, ['scripts/build-web.js'], { cwd: ROOT, env: { ...process.env, WEB_OUT: fs.mkdtempSync(path.join(os.tmpdir(), 'webbad-')), PUBLIC_API_BASE: 'https://abo-api.onrender.com' }, encoding: 'utf8' });
  assert.notEqual(bad.status, 0); assert.match(bad.stderr, /third-party/);
});

test('single-file build: the whole app in one index.html; CSP hashes match the inline code exactly; no secrets', () => {
  const out = fs.mkdtempSync(path.join(os.tmpdir(), 'websingle-'));
  execFileSync(process.execPath, ['scripts/build-single.js'], { cwd: ROOT, env: { ...process.env, WEB_OUT: out, PUBLIC_SITE_URL: 'https://abo-demo.netlify.app' }, stdio: 'pipe' });
  const html = fs.readFileSync(path.join(out, 'index.html'), 'utf8');
  const script = html.match(/<script type="module">([\s\S]*?)<\/script>/)[1];
  const style = html.match(/<style>([\s\S]*?)<\/style>/)[1];
  const h = (t) => require('node:crypto').createHash('sha256').update(t, 'utf8').digest('base64');
  const hdr = fs.readFileSync(path.join(out, '_headers'), 'utf8');
  for (const src of [html, hdr]) { assert.ok(src.includes(`'sha256-${h(script)}'`), 'script hash'); assert.ok(src.includes(`'sha256-${h(style)}'`), 'style hash'); }
  assert.ok(!/unsafe-inline|unsafe-eval/.test(html + hdr));
  assert.ok(!/<script[^>]+src=|rel="stylesheet"|"\/assets\//.test(html), 'no external files');
  assert.ok(!/\bimport\s*\(\s*["'`]\.\.?\//.test(script), 'all pages bundled in');
  assert.ok(script.includes('https://abo-demo.netlify.app'), 'portal link for the opened-from-disk screen');
  for (const k of ['postgres://', 'dev_password', 'PROXY_SHARED_SECRET=', 'sk_live_']) assert.ok(!html.includes(k), k);
});

test('Docker image contains every file the API reads at run time (Supabase CA, ops scripts) and no local secrets', () => {
  const fs = require('node:fs'); const path = require('node:path'); const root = path.join(__dirname, '../..');
  const df = fs.readFileSync(path.join(root, 'Dockerfile'), 'utf8');
  for (const need of ['COPY server ./server', 'COPY deploy/certs ./deploy/certs', 'COPY scripts ./scripts']) assert.ok(df.includes(need), `Dockerfile must have: ${need}`);
  assert.ok(fs.existsSync(path.join(root, 'deploy/certs/supabase-prod-ca-2021.crt')), 'the Supabase CA file exists');
  const ign = fs.readFileSync(path.join(root, '.dockerignore'), 'utf8').split('\n').map((x) => x.trim());
  for (const no of ['node_modules', '.env', 'var']) assert.ok(ign.includes(no), `.dockerignore must exclude ${no}`);
  // every server-side require of a path outside server/ must be inside the image
  const { sslFor, SUPABASE_CA } = require('../src/db/ssl'); void sslFor;
  assert.match(path.relative(root, SUPABASE_CA), /^deploy\/certs\//);
});
