'use strict';
// Paystack is simulated by a local HTTP server that implements the two endpoints we call
// (/transaction/initialize and /transaction/verify/:ref). Signature verification uses the real algorithm.
process.env.PAYSTACK_SECRET_KEY = 'sk_test_local_mock_secret_value_123456';
process.env.PAYSTACK_BASE_URL = 'http://127.0.0.1:18999';
const H = require('./helpers');
const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const crypto = require('node:crypto');

let S, owner, bursar, accountant, parent, student, teacher, mock, verifyAmount = null;
test.before(async () => {
  S = await H.setup();
  mock = http.createServer((req, res) => {
    let body = ''; req.on('data', (d) => { body += d; }); req.on('end', () => {
      res.setHeader('content-type', 'application/json');
      if (req.headers.authorization !== `Bearer ${process.env.PAYSTACK_SECRET_KEY}`) { res.statusCode = 401; return res.end('{"status":false}'); }
      if (req.url === '/transaction/initialize') { const b = JSON.parse(body); return res.end(JSON.stringify({ status: true, data: { authorization_url: `https://checkout.paystack.test/${b.reference}`, reference: b.reference } })); }
      const m = /^\/transaction\/verify\/(.+)$/.exec(req.url);
      if (m) return res.end(JSON.stringify({ status: true, data: { status: 'success', reference: decodeURIComponent(m[1]), amount: verifyAmount, currency: 'NGN', id: 998877 } }));
      res.statusCode = 404; res.end('{}');
    });
  }).listen(18999);
  [owner, bursar, accountant, parent, student, teacher] = await Promise.all(['sa.owner', 'sa.bursar', 'sa.accounts', 'sa.parent', 'sa.student', 'sa.teacher1'].map((l) => H.login(S.app, l)));
});
test.after(async () => { mock.close(); await H.teardown(); });

let invoiceId, invTotal;
test('invoices are generated server-side from fee items + approved discounts (four-eyes)', async () => {
  const me = (await student.get('/api/v1/auth/me')).body.studentId;
  const d = await accountant.post('/api/v1/fees/discounts', { studentId: me, termId: S.A.termId, kind: 'scholarship', percent: 10, reason: 'Merit scholarship' });
  assert.equal(d.status, 200);
  assert.equal((await accountant.post(`/api/v1/fees/discounts/${d.body.id}/review`, { action: 'approve' })).status, 403, 'accountant lacks fees.approve');
  assert.equal((await bursar.post(`/api/v1/fees/discounts/${d.body.id}/review`, { action: 'approve' })).status, 200);
  const g = await bursar.post('/api/v1/fees/invoices/generate', { termId: S.A.termId });
  assert.equal(g.status, 200); assert.ok(g.body.created >= 15);
  assert.equal((await bursar.post('/api/v1/fees/invoices/generate', { termId: S.A.termId })).body.created, 0, 'idempotent per term');
  const mine = await parent.get('/api/v1/fees/my');
  const inv = mine.body.items.find((i) => i.student_id === me);
  // 85,000 + 15,000 + 5,000 = 105,000 naira; 10% scholarship → 94,500
  assert.equal(Number(inv.total_kobo), 9450000); invoiceId = inv.id; invTotal = Number(inv.total_kobo);
});
test('payments: amount validated against the locked balance; receipts numbered; invoice status maintained', async () => {
  assert.equal((await bursar.post('/api/v1/fees/payments', { invoiceId, amountKobo: invTotal + 1, method: 'cash' })).status, 400);
  assert.equal((await teacher.post('/api/v1/fees/payments', { invoiceId, amountKobo: 100, method: 'cash' })).status, 403);
  const p1 = await accountant.post('/api/v1/fees/payments', { invoiceId, amountKobo: 5000000, method: 'transfer', reference: 'GTB-2026-0001' });
  assert.equal(p1.status, 200); assert.match(p1.body.receipt_no, /^RCT-\d{4}-\d{6}$/);
  assert.equal((await accountant.post('/api/v1/fees/payments', { invoiceId, amountKobo: 100, method: 'transfer', reference: 'GTB-2026-0001' })).status, 409, 'duplicate reference');
  const inv = await parent.get(`/api/v1/fees/invoices/${invoiceId}`);
  assert.equal(inv.body.invoice.status, 'partial'); assert.equal(Number(inv.body.invoice.paid_kobo), 5000000);
  const rc = await parent.get(`/api/v1/fees/receipts/${p1.body.id}`); assert.equal(rc.status, 200);
  const n = await parent.get('/api/v1/notifications'); assert.ok(n.body.items.some((x) => x.kind === 'fees'));
  // reversal: recorder cannot reverse own payment; bursar can
  assert.equal((await accountant.post(`/api/v1/fees/payments/${p1.body.id}/reverse`, { reason: 'bounced transfer' })).status, 403);
  assert.equal((await bursar.post(`/api/v1/fees/payments/${p1.body.id}/reverse`, { reason: 'bounced transfer' })).status, 200);
  assert.equal((await parent.get(`/api/v1/fees/invoices/${invoiceId}`)).body.invoice.status, 'unpaid');
  const db = await H.dbAs('app');
  try {
    await db.query('BEGIN'); await db.query("SELECT set_config('app.school_id', $1, true)", [S.A.schoolId]);
    await assert.rejects(db.query('UPDATE invoices SET paid_kobo = total_kobo + 1 WHERE id = $1', [invoiceId]), /check constraint/);
    await db.query('ROLLBACK');
  } finally { await db.end(); }
});
test('parents only see their own children\'s invoices; summary for finance staff', async () => {
  const all = await bursar.get('/api/v1/fees/invoices?pageSize=100');
  const pme = (await parent.get('/api/v1/auth/me')).body.children.map((c) => c.id);
  const foreign = all.body.items.find((i) => !pme.includes(i.student_id));
  assert.equal((await parent.get(`/api/v1/fees/invoices/${foreign.id}`)).status, 404);
  const s = await bursar.get(`/api/v1/fees/summary?termId=${S.A.termId}`); assert.ok(Number(s.body.billed) > 0); assert.ok(Array.isArray(s.body.byClass));
});
test('online payment: server-side init with server-computed amount; webhook needs valid HMAC-SHA512 + provider verification', async () => {
  const init = await parent.post(`/api/v1/fees/invoices/${invoiceId}/pay-online`, { email: 'parent@school-a.example' });
  assert.equal(init.status, 200); assert.match(init.body.authorizationUrl, /checkout\.paystack\.test/);
  const ref = init.body.reference;
  const evt = JSON.stringify({ event: 'charge.success', data: { reference: ref, amount: 1, status: 'success' } });   // client-controlled amount is ignored
  const bad = await S.app.inject({ method: 'POST', url: '/api/v1/payments/webhook/paystack', payload: evt, headers: { 'content-type': 'application/json', 'x-paystack-signature': 'deadbeef' } });
  assert.equal(bad.statusCode, 401);
  const sig = crypto.createHmac('sha512', process.env.PAYSTACK_SECRET_KEY).update(evt).digest('hex');
  verifyAmount = 123;                           // provider says a different amount → must NOT credit
  const mism = await S.app.inject({ method: 'POST', url: '/api/v1/payments/webhook/paystack', payload: evt, headers: { 'content-type': 'application/json', 'x-paystack-signature': sig } });
  assert.equal(mism.statusCode, 200);
  assert.equal((await parent.get(`/api/v1/fees/invoices/${invoiceId}`)).body.invoice.status, 'unpaid');
  // a fresh, honest payment
  const init2 = await parent.post(`/api/v1/fees/invoices/${invoiceId}/pay-online`, { email: 'parent@school-a.example' });
  const evt2 = JSON.stringify({ event: 'charge.success', data: { reference: init2.body.reference } });
  const sig2 = crypto.createHmac('sha512', process.env.PAYSTACK_SECRET_KEY).update(evt2).digest('hex');
  verifyAmount = invTotal;
  const ok = await S.app.inject({ method: 'POST', url: '/api/v1/payments/webhook/paystack', payload: evt2, headers: { 'content-type': 'application/json', 'x-paystack-signature': sig2 } });
  assert.equal(ok.statusCode, 200);
  const inv = await parent.get(`/api/v1/fees/invoices/${invoiceId}`);
  assert.equal(inv.body.invoice.status, 'paid');
  const again = await S.app.inject({ method: 'POST', url: '/api/v1/payments/webhook/paystack', payload: evt2, headers: { 'content-type': 'application/json', 'x-paystack-signature': sig2 } });
  assert.equal(again.statusCode, 200);
  assert.equal((await parent.get(`/api/v1/fees/invoices/${invoiceId}`)).body.payments.filter((p) => p.status === 'confirmed').length, 1, 'webhook replay is idempotent');
  const db = await H.dbAs('owner');
  try { assert.ok((await db.query("SELECT count(*)::int AS n FROM security_events WHERE kind IN ('payment_webhook_bad_signature','payment_amount_mismatch')")).rows[0].n >= 2); } finally { await db.end(); }
});
test('online payment: provider unreachable → 502 UPSTREAM_UNAVAILABLE (not 500) and the attempt is marked failed; not configured → 409', async () => {
  const config = require('../src/config');
  const saved = { ...config.payments };
  try {
    // make sure the invoice has an outstanding balance (earlier tests may have settled it)
    const charge = await bursar.post(`/api/v1/fees/invoices/${invoiceId}/items`, { description: 'Excursion levy', amountKobo: 250000 });
    assert.equal(charge.status, 200, JSON.stringify(charge.body));
    config.payments.paystackBaseUrl = 'http://127.0.0.1:1'; // nothing listens here → fetch throws
    const r = await parent.post(`/api/v1/fees/invoices/${invoiceId}/pay-online`, { email: 'parent@school-a.example' });
    assert.equal(r.status, 502); assert.equal(r.body.error.code, 'UPSTREAM_UNAVAILABLE');
    const db = await H.dbAs('owner');
    try {
      const p = (await db.query(`SELECT status FROM payments WHERE invoice_id = $1 AND provider = 'paystack' ORDER BY created_at DESC LIMIT 1`, [invoiceId])).rows[0];
      assert.equal(p.status, 'failed', 'orphaned pending attempt is closed');
    } finally { await db.end(); }
    config.payments.paystackSecret = '';
    const n = await parent.post(`/api/v1/fees/invoices/${invoiceId}/pay-online`, { email: 'parent@school-a.example' });
    assert.equal(n.status, 409); assert.equal(n.body.error.code, 'NOT_CONFIGURED');
  } finally { Object.assign(config.payments, saved); }
});
