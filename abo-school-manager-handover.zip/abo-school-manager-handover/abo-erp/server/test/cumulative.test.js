'use strict';
// Cumulative results ("results so far this session"): maths, positions, the divisor setting, the report card block,
// published-only for parents/pupils, exports, permissions and tenant isolation.
const H = require('./helpers');
const test = require('node:test');
const assert = require('node:assert/strict');
const { withTx } = require('../src/db/pool');
const R = require('../src/services/results');
const CUM = require('../src/services/cumulative');

let S, owner, exam, student, parent, bOwner, cls, terms, roster, subs, st0;

// score sheets written straight to the database (the workflow itself is covered in results.test.js)
async function sheet(termId, subjectId, totals /* studentId -> exam score or undefined */, status = 'published') {
  return withTx({ schoolId: S.A.schoolId }, async (c) => {
    const st = await R.settings(c);
    const id = (await c.query('INSERT INTO assessments (school_id, term_id, class_id, subject_id, components) VALUES ($1,$2,$3,$4,$5) RETURNING id',
      [S.A.schoolId, termId, cls.id, subjectId, JSON.stringify(st.assessment_components)])).rows[0].id;
    for (const [sid, v] of Object.entries(totals)) {
      if (v === undefined) continue;
      // split into ca1/ca2/exam so the components stay in range (20/20/60)
      const ca1 = Math.min(20, v); const ca2 = Math.min(20, v - ca1); const ex = v - ca1 - ca2;
      for (const [k, s] of [['ca1', ca1], ['ca2', ca2], ['exam', ex]]) await c.query('INSERT INTO assessment_scores (school_id, sheet_id, student_id, component_key, score) VALUES ($1,$2,$3,$4,$5)', [S.A.schoolId, id, sid, k, s]);
    }
    await R.recomputeSheet(c, id);
    if (status !== 'draft') await c.query('UPDATE assessments SET status = $2 WHERE id = $1', [id, status]);
    return id;
  });
}
const publishTerm = (termId) => withTx({ schoolId: S.A.schoolId }, (c) => R.computeClassTerm(c, termId, cls.id, { publish: true }));

test.before(async () => {
  S = await H.setup();
  [owner, exam, student, parent] = await Promise.all(['sa.owner', 'sa.exams', 'sa.student', 'sa.parent'].map((l) => H.login(S.app, l)));
  bOwner = await H.login(S.app, 'sb.owner');
  const db = await H.dbAs('admin');
  st0 = (await db.query("SELECT s.id, e.class_id FROM students s JOIN users u ON u.id = s.user_id JOIN student_enrollments e ON e.student_id = s.id WHERE u.login_id = 'sa.student'")).rows[0];
  cls = S.A.classes.find((c) => c.id === st0.class_id);
  terms = Object.fromEntries((await db.query('SELECT t.name, t.id FROM terms t JOIN student_enrollments e ON e.session_id = t.session_id WHERE e.student_id = $1', [st0.id])).rows.map((r) => [r.name, r.id]));
  roster = (await db.query("SELECT s.id FROM student_enrollments e JOIN students s ON s.id = e.student_id WHERE e.class_id = $1 AND e.status <> 'withdrawn' ORDER BY s.last_name, s.first_name", [cls.id])).rows.map((r) => r.id);
  subs = (await db.query('SELECT cs.subject_id, sb.name FROM class_subjects cs JOIN subjects sb ON sb.id = cs.subject_id WHERE cs.class_id = $1 ORDER BY sb.name', [cls.id])).rows;
  await db.end();
  assert.ok(roster.length >= 5 && subs.length >= 3, 'seed has a class with 5 learners and 3+ subjects');
  // roster order: L0 is st0? not necessarily — build explicit score tables by index
  const [L0, L1, L2, L3, L4] = roster; const [M, E2, X] = subs.map((s) => s.subject_id);
  // 1st term: subject M and E2 (L4 joined in 2nd term → no 1st-term scores)
  await sheet(terms['1ST'], M, { [L0]: 80, [L1]: 60, [L2]: 70, [L3]: 50 });
  await sheet(terms['1ST'], E2, { [L0]: 70, [L1]: 60, [L2]: 50, [L3]: 40 });
  await publishTerm(terms['1ST']);
  // 2nd term
  await sheet(terms['2ND'], M, { [L0]: 90, [L1]: 70, [L2]: 70, [L3]: 30, [L4]: 60 });
  await sheet(terms['2ND'], E2, { [L0]: 80, [L1]: 50, [L2]: 60, [L3]: 40, [L4]: 70 });
  await publishTerm(terms['2ND']);
  // an unpublished (draft) extra subject in 2nd term: staff see it as provisional, parents/pupils must not
  await sheet(terms['2ND'], X, { [L0]: 10, [L1]: 99, [L2]: 99, [L3]: 99, [L4]: 99 }, 'draft');
});
test.after(() => H.teardown());

test('cumulative maths: subject averages, overall average, 1-2-2-4 positions, change since last term', async () => {
  const r = await exam.get(`/api/v1/results/cumulative?termId=${terms['2ND']}&classId=${cls.id}`);
  assert.equal(r.status, 200, JSON.stringify(r.body));
  const b = r.body; const [L0, L1, L2, L3, L4] = roster; const iM = b.subjects.findIndex((s) => s.id === subs[0].subject_id); const iE = b.subjects.findIndex((s) => s.id === subs[1].subject_id);
  assert.deepEqual(b.terms.map((t) => t.name), ['1ST', '2ND']); assert.equal(b.provisional, true, 'draft sheet makes the staff view provisional'); assert.equal(b.divisor, 'taken');
  const row = (id) => b.rows.find((x) => x.studentId === id);
  // L0: M 80,90 → 85; E2 70,80 → 75; (X draft 10 → 10) → overall (85+75+10)/3 = 56.67
  assert.deepEqual(row(L0).subjects[iM].termTotals, [80, 90]); assert.equal(row(L0).subjects[iM].average, 85); assert.equal(row(L0).subjects[iE].average, 75);
  assert.equal(row(L0).subjects[iM].total, 170);
  // L4 joined in 2nd term: divided by the terms taken → M 60, E2 70
  assert.deepEqual(row(L4).subjects[iM].termTotals, [null, 60]); assert.equal(row(L4).subjects[iM].average, 60); assert.equal(row(L4).subjects[iM].taken, 1);
  // L1 and L2 tie in M (65, 70 → 65 / 70,70 → 70?) — compute: L1 M 60,70 → 65; L2 M 70,70 → 70; subject positions L0 1st, L2 2nd
  assert.equal(row(L0).subjects[iM].position, 1); assert.equal(row(L2).subjects[iM].position, 2);
  // term averages and change: L3 1st term (50+40)/2 = 45, 2nd term (30+40+99)/3 = 56.33 (staff view includes draft X)
  assert.equal(row(L3).termAverages[0], 45);
  // positions are competition ranking over the cumulative average
  const sorted = [...b.rows].filter((x) => x.cumulativeAverage !== null).sort((a, c) => c.cumulativeAverage - a.cumulativeAverage);
  assert.equal(sorted[0].cumulativePosition, 1);
  for (let i = 1; i < sorted.length; i++) assert.equal(sorted[i].cumulativePosition, sorted[i].cumulativeAverage === sorted[i - 1].cumulativeAverage ? sorted[i - 1].cumulativePosition : i + 1);
  assert.ok(row(L0).summary.includes('cumulative average'), row(L0).summary);
  assert.ok(b.subjectStats[iM].average > 0 && b.overall.average > 0);
  // 1st-term cumulative is just that term
  const one = await exam.get(`/api/v1/results/cumulative?termId=${terms['1ST']}&classId=${cls.id}`);
  assert.equal(one.status, 200); assert.equal(one.body.terms.length, 1); assert.equal(one.body.rows.find((x) => x.studentId === L0).cumulativeAverage, 75);
});

test('a pure tie shares the position and the next learner skips (1-2-2-4)', () => {
  const rows = [{ id: 'a', value: 80 }, { id: 'b', value: 70 }, { id: 'c', value: 70 }, { id: 'd', value: 60 }];
  const p = require('../src/services/grading').rank(rows);
  assert.deepEqual(['a', 'b', 'c', 'd'].map((k) => p.get(k)), [1, 2, 2, 4]);
});

test('school setting: divide by all terms the subject was taught (missed term counts as 0)', async () => {
  const put = await owner.put('/api/v1/school/settings', { reportCard: { cumulativeDivisor: 'all' } });
  assert.equal(put.status, 200, JSON.stringify(put.body));
  const b = (await exam.get(`/api/v1/results/cumulative?termId=${terms['2ND']}&classId=${cls.id}`)).body;
  const iM = b.subjects.findIndex((s) => s.id === subs[0].subject_id);
  const L4 = b.rows.find((x) => x.studentId === roster[4]);
  assert.equal(b.divisor, 'all'); assert.equal(L4.subjects[iM].average, 30, '60 over 2 terms'); assert.match(b.method, /missed term counts as 0/);
  // the draft subject X was only taught in 2nd term → still divided by 1
  const iX = b.subjects.findIndex((s) => s.id === subs[2].subject_id); assert.equal(L4.subjects[iX].average, 99);
  assert.equal((await owner.put('/api/v1/school/settings', { reportCard: { cumulativeDivisor: 'taken' } })).status, 200);
  assert.equal((await owner.put('/api/v1/school/settings', { reportCard: { cumulativeDivisor: 'half' } })).status, 400, 'only known methods');
});

test('report card: 2nd term shows the cumulative block; parents and pupils see published terms only', async () => {
  const staff = await exam.get(`/api/v1/results/student/${st0.id}?termId=${terms['2ND']}`);
  assert.equal(staff.status, 200); assert.ok(staff.body.cumulative, 'staff see cumulative');
  assert.equal(staff.body.cumulative.terms.length, 2);
  assert.ok(staff.body.cumulative.subjects.some((s) => s.name === subs[2].name), 'staff preview includes the draft subject');
  const mine = await student.get(`/api/v1/results/student/${st0.id}?termId=${terms['2ND']}`);
  assert.equal(mine.status, 200); assert.equal(mine.body.available, true);
  const cum = mine.body.cumulative; assert.ok(cum, 'pupil sees cumulative');
  assert.ok(!cum.subjects.some((s) => s.name === subs[2].name), 'unpublished subject hidden from the pupil');
  assert.equal(cum.provisional, false);
  assert.ok(cum.cumulativePosition >= 1 && cum.ordinalCumulativePosition, 'cumulative position shown');
  assert.equal(typeof cum.summary, 'string'); assert.ok(cum.summary.length > 20);
  const kid = await parent.get(`/api/v1/results/student/${st0.id}?termId=${terms['2ND']}`);
  assert.equal(kid.status, 200); assert.deepEqual(kid.body.cumulative.subjects.map((s) => s.name), cum.subjects.map((s) => s.name));
  // 1st term report card has no cumulative block (it would repeat the term)
  assert.equal((await exam.get(`/api/v1/results/student/${st0.id}?termId=${terms['1ST']}`)).body.cumulative, null);
  // switched off by the school
  assert.equal((await owner.put('/api/v1/school/settings', { reportCard: { showCumulative: false } })).status, 200);
  assert.equal((await exam.get(`/api/v1/results/student/${st0.id}?termId=${terms['2ND']}`)).body.cumulative, null);
  assert.equal((await owner.put('/api/v1/school/settings', { reportCard: { showCumulative: true } })).status, 200);
});

test('permissions and tenant isolation', async () => {
  assert.equal((await student.get(`/api/v1/results/cumulative?termId=${terms['2ND']}&classId=${cls.id}`)).status, 403);
  assert.equal((await parent.get(`/api/v1/results/cumulative?termId=${terms['2ND']}&classId=${cls.id}`)).status, 403);
  assert.equal((await bOwner.get(`/api/v1/results/cumulative?termId=${terms['2ND']}&classId=${cls.id}`)).status, 404, 'another school cannot see the class');
  assert.equal((await exam.get(`/api/v1/results/cumulative?classId=${cls.id}&termId=00000000-0000-4000-8000-000000000000`)).status, 404);
  assert.equal((await exam.get('/api/v1/results/cumulative')).status, 400, 'class is required');
});

test('export: cumulative sheet as Excel and CSV', async () => {
  const csv = await owner.get(`/api/v1/exports/cumulative?termId=${terms['2ND']}&classId=${cls.id}&format=csv`);
  assert.equal(csv.status, 200); const head = csv.raw.payload.split('\n')[0];
  assert.match(head, /Cum\. position/); assert.match(head, /Cumulative average/); assert.match(head, /1st term/); assert.match(head, /2nd term/);
  const x = await owner.get(`/api/v1/exports/cumulative?termId=${terms['2ND']}&classId=${cls.id}&format=xlsx`);
  assert.equal(x.status, 200); assert.match(x.headers['content-type'], /spreadsheetml/);
  assert.equal(x.raw.rawPayload.slice(0, 2).toString(), 'PK');
  assert.equal((await owner.get(`/api/v1/exports/cumulative?format=csv`)).status, 400);
});

test('summary sentence reads naturally and never guesses gender', () => {
  const s = CUM.summarySentence({ name: 'Okafor Ada', firstName: 'Ada', cumulativeAverage: 68.4, grade: 'B', change: 3.1, cumulativePosition: 4, best: { name: 'Mathematics', average: 82 }, weakest: { name: 'Basic Science', average: 48 }, status: 'Pass' },
    { termName: '2ND', classSize: 32, terms: [{}, {}], passMark: 40 });
  assert.equal(s, 'After the second term, Ada’s cumulative average is 68.4% (B), which is good. This term’s average is 3.1 points higher than last term. Ada is 4th of 32 in the class so far this session. Best subject so far: Mathematics (82%). Needs more attention: Basic Science (48%).');
  assert.ok(!/\b(he|she|his|her)\b/i.test(s));
});
