'use strict';
// Phase 6 (part 3): study materials, live classes, bell times and the live class monitor — rules checked on the server.
const H = require('./helpers');
const test = require('node:test');
const assert = require('node:assert/strict');

let S, owner, teacher, teacher2, student, parent, bOwner, accounts;
let myClass, otherClass;
test.before(async () => {
  S = await H.setup();
  [owner, teacher, teacher2, student, parent, bOwner, accounts] = await Promise.all(['sa.owner', 'sa.teacher1', 'sa.teacher2', 'sa.student', 'sa.parent', 'sb.owner', 'sa.accounts'].map((l) => H.login(S.app, l)));
  const db = await H.dbAs('owner');
  try {
    myClass = (await db.query(`SELECT e.class_id FROM student_enrollments e JOIN students s ON s.id = e.student_id JOIN users u ON u.id = s.user_id WHERE u.login_id = 'sa.student' LIMIT 1`)).rows[0].class_id;
  } finally { await db.end(); }
  // a new class nobody teaches yet
  const r = await owner.post('/api/v1/academic/classes', { name: 'JSS 3', arm: 'Z', section: 'secondary' });
  assert.equal(r.status, 200, JSON.stringify(r.body)); otherClass = r.body.items[0].id;
});
test.after(() => H.teardown());

test('study materials: teachers share with their classes; https links only; files checked; pupils/parents see only their class', async () => {
  const opt = (await teacher.get('/api/v1/materials/options')).body;
  assert.ok(opt.classes.some((c) => c.id === myClass) && !opt.classes.some((c) => c.id === otherClass), 'a teacher is offered only the classes they teach');
  assert.equal((await teacher.post('/api/v1/materials', { classId: otherClass, title: 'Not mine', kind: 'link', url: 'https://example.org/x' })).status, 403, 'cannot share with a class you do not teach');
  assert.equal((await teacher.post('/api/v1/materials', { classId: myClass, title: 'Bad', kind: 'link', url: 'http://example.org/x' })).status, 400, 'http (not https) refused');
  assert.equal((await teacher.post('/api/v1/materials', { classId: myClass, title: 'Bad', kind: 'link', url: 'javascript:alert(1)' })).status, 400, 'javascript: refused');
  let r = await teacher.post('/api/v1/materials', { classId: myClass, title: 'Fractions explained', kind: 'video', url: 'https://www.youtube.com/watch?v=abc123' });
  assert.equal(r.status, 200, JSON.stringify(r.body)); const vid = r.body.id;
  r = await teacher.post('/api/v1/materials', { classId: myClass, title: 'Draft worksheet', kind: 'link', url: 'https://example.org/draft', published: false }); const draft = r.body.id;
  r = await owner.post('/api/v1/materials', { classId: otherClass, title: 'JSS 3Z reading list', kind: 'link', url: 'https://example.org/list' });
  assert.equal(r.status, 200, 'heads may share with any class'); const otherMat = r.body.id;
  // file upload (real PNG) and a disguised file (refused)
  const up = await teacher.post('/api/v1/materials/file', undefined, { multipart: H.multipart({ classId: myClass, title: 'Shapes chart' }, { name: 'shapes.png', type: 'image/png', data: H.PNG_1PX }) });
  assert.equal(up.status, 200, JSON.stringify(up.body));
  const fake = await teacher.post('/api/v1/materials/file', undefined, { multipart: H.multipart({ classId: myClass, title: 'Evil' }, { name: 'notes.pdf', type: 'application/pdf', data: '<script>alert(1)</script>' }) });
  assert.equal(fake.status, 400, 'a file that is not what it claims is refused');
  // learner views
  for (const who of [student, parent]) {
    const l = (await who.get('/api/v1/materials')).body.items;
    assert.ok(l.some((x) => x.id === vid) && l.some((x) => x.file_id === up.body.fileId), 'pupil/parent sees the class materials');
    assert.ok(!l.some((x) => x.id === draft), 'unpublished material is hidden'); assert.ok(!l.some((x) => x.id === otherMat), 'other classes hidden');
    assert.equal((await who.get(`/api/v1/files/${up.body.fileId}`)).status, 200, 'the file opens for the class');
    assert.equal((await who.post('/api/v1/materials', { classId: myClass, title: 'x', kind: 'link', url: 'https://a.b' })).status, 403);
  }
  assert.equal((await student.get('/api/v1/materials')).body.items.find((x) => x.id === vid).video, 'YouTube');
  // removal rules
  assert.equal((await teacher2.del(`/api/v1/materials/${vid}`)).status, 403, 'another teacher cannot remove it');
  assert.equal((await teacher.del(`/api/v1/materials/${vid}`)).status, 200);
  assert.ok(!(await student.get('/api/v1/materials')).body.items.some((x) => x.id === vid));
  // isolation + no access for unrelated roles
  assert.equal((await bOwner.get('/api/v1/materials')).body.items.length, 0, 'another school sees nothing');
  assert.equal((await bOwner.get(`/api/v1/files/${up.body.fileId}`)).status, 404);
  assert.equal((await accounts.get('/api/v1/materials')).status, 403, 'the accountant has no access');
});

test('live classes: https link; join link only shown to pupils from 15 minutes before; cancel rules', async () => {
  const soon = new Date(Date.now() + 5 * 60000).toISOString(); const later = new Date(Date.now() + 3 * 3600e3).toISOString();
  assert.equal((await teacher.post('/api/v1/live-classes', { classId: myClass, title: 'Past', startsAt: new Date(Date.now() - 3 * 3600e3).toISOString(), durationMin: 40, joinUrl: 'https://meet.google.com/abc-defg-hij' })).status, 400, 'no live class in the past');
  assert.equal((await teacher.post('/api/v1/live-classes', { classId: otherClass, title: 'Not my class', startsAt: later, durationMin: 40, joinUrl: 'https://meet.google.com/abc' })).status, 403);
  let r = await teacher.post('/api/v1/live-classes', { classId: myClass, title: 'Revision: fractions', startsAt: soon, durationMin: 40, joinUrl: 'https://meet.google.com/abc-defg-hij' });
  assert.equal(r.status, 200, JSON.stringify(r.body)); const now1 = r.body.id;
  r = await teacher.post('/api/v1/live-classes', { classId: myClass, title: 'Spelling bee', startsAt: later, durationMin: 30, joinUrl: 'https://zoom.us/j/123456' }); const late1 = r.body.id;
  const l = (await student.get('/api/v1/live-classes')).body.items;
  assert.equal(l.find((x) => x.id === now1).join_url, 'https://meet.google.com/abc-defg-hij', 'join link shown 5 minutes before');
  assert.equal(l.find((x) => x.id === late1).join_url, null, 'join link not shown 3 hours before');
  assert.ok((await teacher.get('/api/v1/live-classes')).body.items.find((x) => x.id === late1).join_url, 'the teacher always sees the link');
  assert.equal((await teacher2.post(`/api/v1/live-classes/${late1}/cancel`)).status, 403);
  assert.equal((await teacher.post(`/api/v1/live-classes/${late1}/cancel`)).status, 200);
  assert.ok(!(await parent.get('/api/v1/live-classes')).body.items.some((x) => x.id === late1), 'cancelled classes disappear');
  assert.equal((await bOwner.get('/api/v1/live-classes')).body.items.length, 0);
});

test('bell times + monitor: the lesson on now, whether its teacher has clocked in, live classes, preview of another time', async () => {
  // bell times are validated
  assert.equal((await teacher.put('/api/v1/school/periods', { items: [] })).status, 403);
  assert.equal((await owner.put('/api/v1/school/periods', { items: [{ period: 1, startsAt: '09:00', endsAt: '08:00' }] })).status, 400);
  assert.equal((await owner.put('/api/v1/school/periods', { items: [{ period: 1, startsAt: '08:00', endsAt: '08:40' }, { period: 2, startsAt: '08:30', endsAt: '09:10' }] })).status, 400, 'overlapping periods refused');
  // school-local now (Africa/Lagos = UTC+1, no daylight saving)
  const lag = new Date(Date.now() + 3600e3); const dow = ((lag.getUTCDay() + 6) % 7) + 1; const hm = (d) => d.toISOString().slice(11, 16);
  const minutes = lag.getUTCHours() * 60 + lag.getUTCMinutes();
  const safe = minutes > 20 && minutes < 23 * 60;                    // keep the period inside today
  const p1s = hm(new Date(lag.getTime() - 10 * 60000)); const p1e = hm(new Date(lag.getTime() + 30 * 60000));
  assert.equal((await owner.put('/api/v1/school/periods', { items: safe ? [{ period: 1, startsAt: p1s, endsAt: p1e }] : [{ period: 1, startsAt: '08:00', endsAt: '08:40' }] })).status, 200);
  const subs = (await owner.get('/api/v1/academic')).body.subjects;
  const db = await H.dbAs('owner'); let staffT1;
  try { staffT1 = (await db.query("SELECT st.id FROM staff st JOIN users u ON u.id = st.user_id WHERE u.login_id = 'sa.teacher1'")).rows[0].id; } finally { await db.end(); }
  const tt = await owner.put(`/api/v1/academic/classes/${myClass}/timetable`, { items: [{ dayOfWeek: safe ? dow : 1, period: 1, subjectId: subs[0].id, teacherId: staffT1 }] });
  assert.equal(tt.status, 200, JSON.stringify(tt.body));
  assert.equal((await teacher.get('/api/v1/monitor/now')).status, 403, 'teachers do not see the monitor');
  // preview a moment of the week
  const pv = (await owner.get(`/api/v1/monitor/now?at=${safe ? dow : 1}T${safe ? p1s.slice(0, 4) + String(Math.min(9, Number(p1s[4]) + 1)) : '08:10'}`)).body;
  const pmine = pv.items.find((x) => x.classId === myClass);
  assert.equal(pmine.status, 'scheduled', JSON.stringify(pmine)); assert.equal(pmine.subject, subs[0].name);
  assert.equal(pv.items.find((x) => x.classId === otherClass).status, 'no_timetable');
  if (safe) {
    let m = (await owner.get('/api/v1/monitor/now')).body; let mine = m.items.find((x) => x.classId === myClass);
    assert.equal(mine.status, 'teacher_not_in', JSON.stringify(mine)); assert.equal(mine.teacher, 'Mr Tunde Bello');
    assert.equal((await teacher.post('/api/v1/live-classes', { classId: myClass, title: 'Live now', startsAt: new Date(Date.now() - 5 * 60000).toISOString(), durationMin: 40, joinUrl: 'https://meet.google.com/xyz' })).status, 200, 'a class that started 5 minutes ago can still be added');
    assert.equal((await teacher.post('/api/v1/clock/in', {})).status, 200);
    m = (await owner.get('/api/v1/monitor/now')).body; mine = m.items.find((x) => x.classId === myClass);
    assert.equal(mine.status, 'in_session', 'after the teacher clocks in, the class is in session'); assert.ok(mine.liveClass, 'the live class happening now is shown');
    assert.equal(m.summary.inSession, 1);
  } else console.log('  (near midnight: real-time monitor checks skipped, preview checked)');
  assert.ok(!(await bOwner.get('/api/v1/monitor/now')).body.items.some((x) => x.classId === myClass), 'another school does not see the class');
});
