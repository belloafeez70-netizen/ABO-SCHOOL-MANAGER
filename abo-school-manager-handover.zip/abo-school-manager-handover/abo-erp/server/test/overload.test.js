'use strict';
// Phase 7: under overload the API answers "busy, try again" (503 BUSY + Retry-After) instead of failing with 500s.
// A tiny pool (2 connections) and a tiny waiting line (10) make the overload easy to reproduce.
process.env.DB_POOL_MAX = '2';
process.env.DB_QUEUE_MAX = '10';
const H = require('./helpers');
const test = require('node:test');
const assert = require('node:assert/strict');

let S, owner;
test.before(async () => { S = await H.setup(); owner = await H.login(S.app, 'sa.owner'); });
test.after(() => H.teardown());

test('overload: many requests at once → some are served, the rest get 503 BUSY with Retry-After; never a 500', async () => {
  // a first wave fills the waiting line; the second wave arrives while it is still full (as in a real rush)
  const first = Array.from({ length: 100 }, () => owner.get('/api/v1/students?pageSize=25'));
  await new Promise((r) => setTimeout(r, 40));
  const second = Array.from({ length: 60 }, () => owner.get('/api/v1/students?pageSize=25'));
  const res = await Promise.all([...first, ...second]);
  const codes = res.reduce((m, r) => { m[r.status] = (m[r.status] || 0) + 1; return m; }, {});
  assert.ok(codes[200] > 0, `some requests are served: ${JSON.stringify(codes)}`);
  assert.ok(codes[503] > 0, `some are told "busy": ${JSON.stringify(codes)}`);
  assert.equal(codes[500] || 0, 0, 'no 500 errors');
  const busy = res.find((r) => r.status === 503);
  assert.equal(busy.body.error.code, 'BUSY'); assert.match(busy.body.error.message, /very busy/); assert.equal(busy.headers['retry-after'], '3');
  // and once the rush is over everything works again
  assert.equal((await owner.get('/api/v1/students?pageSize=5')).status, 200);
});
