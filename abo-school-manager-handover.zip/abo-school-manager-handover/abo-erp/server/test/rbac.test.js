'use strict';
const H = require('./helpers');
const test = require('node:test');
const assert = require('node:assert/strict');
let S, owner, admin, teacher, teacher2, student, parent, ict, platform, bursar;
test.before(async () => {
  S = await H.setup();
  [owner, admin, teacher, teacher2, student, parent, platform, bursar] = await Promise.all(['sa.owner', 'sa.admin', 'sa.teacher1', 'sa.teacher2', 'sa.student', 'sa.parent', 'abo.platform', 'sa.bursar'].map((l) => H.login(S.app, l)));
  const r = await owner.post('/api/v1/users', { fullName: 'ICT Officer', loginId: 'sa.ict', roleKeys: ['ict_officer'] });
  await H.client(S.app).post('/api/v1/auth/activate', { loginId: 'sa.ict', accessCode: r.body.accessCode, newPassword: 'Ict-Officer-2026!' });
  ict = await H.login(S.app, 'sa.ict', { password: 'Ict-Officer-2026!' });
});
test.after(() => H.teardown());

test('permissions are enforced server-side per endpoint', async () => {
  assert.equal((await teacher.post('/api/v1/users', { fullName: 'X Y', loginId: 'x.y1', roleKeys: ['teacher'] })).status, 403);
  assert.equal((await teacher.get('/api/v1/fees/invoices')).status, 403);
  assert.equal((await teacher.get('/api/v1/audit')).status, 403);
  assert.equal((await student.get('/api/v1/students')).status, 403);
  assert.equal((await parent.get('/api/v1/users')).status, 403);
  assert.equal((await bursar.post('/api/v1/results/publish', { termId: S.A.termId, classId: S.A.classes[0].id })).status, 403);
  assert.equal((await teacher.put('/api/v1/school/settings', { passMark: 10 })).status, 403);
  assert.equal((await student.post('/api/v1/cbt/exams', { title: 'mine', durationMinutes: 5 })).status, 403);
});
test('BOLA: students and parents only see their own / their children\'s records', async () => {
  const me = await student.get('/api/v1/auth/me'); const kidMe = me.body.studentId;
  const list = await owner.get('/api/v1/students?pageSize=50');
  const other = list.body.items.find((s) => s.id !== kidMe && !parent.children?.includes(s.id));
  const pme = await parent.get('/api/v1/auth/me'); const kids = pme.body.children.map((k) => k.id);
  const stranger = list.body.items.find((s) => !kids.includes(s.id) && s.id !== kidMe);
  assert.equal((await student.get(`/api/v1/students/${kidMe}`)).status, 200);
  assert.equal((await student.get(`/api/v1/students/${other.id}`)).status, 404);
  assert.equal((await student.get(`/api/v1/results/student/${other.id}`)).status, 404);
  assert.equal((await student.get(`/api/v1/attendance/student/${other.id}`)).status, 404);
  for (const k of kids) assert.equal((await parent.get(`/api/v1/students/${k}`)).status, 200);
  assert.equal((await parent.get(`/api/v1/students/${stranger.id}`)).status, 404);
  assert.equal((await parent.get(`/api/v1/results/student/${stranger.id}`)).status, 404);
  const sDetail = await student.get(`/api/v1/students/${kidMe}`); assert.equal(sDetail.body.student.medical_notes, undefined, 'sensitive field hidden');
});
test('privilege escalation: cannot grant roles or permissions you do not hold', async () => {
  const users = await admin.get('/api/v1/users?q=sa.teacher2'); const t2 = users.body.items[0].id;
  assert.equal((await admin.put(`/api/v1/users/${t2}/roles`, { roleKeys: ['school_owner'] })).status, 403, 'admin cannot mint an owner');
  assert.equal((await ict.put(`/api/v1/users/${t2}/roles`, { roleKeys: ['bursar'] })).status, 403, 'ICT officer lacks finance perms');
  assert.equal((await ict.post('/api/v1/users', { fullName: 'Sneaky', loginId: 'sa.sneaky', roleKeys: ['principal'] })).status, 403);
  assert.equal((await ict.post('/api/v1/users', { fullName: 'Pupil Two', loginId: 'sa.pupil2', roleKeys: ['student'] })).status, 200, 'self-scoped roles are grantable');
  assert.equal((await admin.post('/api/v1/roles', { key: 'super_bursar', name: 'Super', permissions: ['payments.reverse'] })).status, 403, 'administrator has no roles.manage');
  const own = await owner.post('/api/v1/roles', { key: 'library_plus', name: 'Library Plus', permissions: ['documents.view', 'documents.upload'] }); assert.equal(own.status, 200);
  assert.equal((await owner.post('/api/v1/roles', { key: 'platformy', name: 'P', permissions: ['platform.schools.manage'] })).status, 400);
  const roles = await owner.get('/api/v1/roles'); const ownerRole = roles.body.items.find((r) => r.key === 'school_owner');
  assert.equal((await owner.patch(`/api/v1/roles/${ownerRole.id}`, { permissions: [] })).status, 403, 'owner role locked');
  const me = await owner.get('/api/v1/users?q=sa.owner');
  assert.equal((await owner.put(`/api/v1/users/${me.body.items[0].id}/roles`, { roleKeys: ['teacher'] })).status, 400, 'last owner cannot be removed');
});
test('mass assignment: unknown or privileged fields are rejected', async () => {
  const me = await owner.get('/api/v1/users?q=sa.teacher2');
  const r = await owner.patch(`/api/v1/users/${me.body.items[0].id}`, { fullName: 'OK Name', isPlatformAdmin: true });
  assert.equal(r.status, 400); assert.match(r.body.error.message, /not an allowed field/);
  assert.equal((await owner.patch('/api/v1/school', { status: 'active', plan: 'enterprise' })).status, 400);
  assert.equal((await owner.post('/api/v1/fees/payments', { invoiceId: '00000000-0000-4000-8000-000000000000', amountKobo: 100, method: 'cash', status: 'confirmed' })).status, 400);
});
test('platform console is invisible to school owners; support mode is read-only and audited in both chains', async () => {
  assert.equal((await owner.get('/api/v1/platform/schools')).status, 403);
  assert.equal((await owner.patch(`/api/v1/platform/schools/${S.B.schoolId}`, { status: 'suspended', reason: 'attack' })).status, 403);
  const list = await platform.get('/api/v1/platform/schools'); assert.equal(list.status, 200); assert.ok(list.body.items.length >= 2);
  assert.ok(list.body.items[0].students !== undefined);
  assert.equal((await platform.get('/api/v1/students')).status, 403, 'platform admin has no school data by default');
  assert.equal((await platform.post('/api/v1/platform/support', { schoolId: S.A.schoolId, reason: 'Ticket #123 broadsheet issue' })).status, 200);
  const view = await platform.get('/api/v1/students'); assert.equal(view.status, 200);
  assert.equal((await platform.post('/api/v1/students', { admissionNo: 'Z1', firstName: 'Z', lastName: 'Z', gender: 'Male' })).status, 403, 'read-only');
  const audit = await owner.get('/api/v1/audit?action=platform.support'); assert.ok(audit.body.items.length >= 1, 'school sees who looked');
  await platform.del('/api/v1/platform/support');
  assert.equal((await platform.get('/api/v1/students')).status, 403);
});
test('teacher scope: results only for assigned subjects; attendance only for own form class', async () => {
  const ac = await owner.get('/api/v1/academic');
  const cls = ac.body.classes.find((c) => c.display_name === 'BASIC 1A');
  const subs = await owner.get(`/api/v1/academic/classes/${cls.id}/subjects`);
  const mine = subs.body.items.find((s) => s.teacher === 'Mr Tunde Bello'); const notMine = subs.body.items.find((s) => s.teacher === 'Mrs Ngozi Okeke');
  assert.equal((await teacher.post('/api/v1/results/sheets', { termId: S.A.termId, classId: cls.id, subjectId: mine.subject_id })).status, 200);
  assert.equal((await teacher.post('/api/v1/results/sheets', { termId: S.A.termId, classId: cls.id, subjectId: notMine.subject_id })).status, 403);
  const b1b = ac.body.classes.find((c) => c.display_name === 'BASIC 1B');
  assert.equal((await teacher.get(`/api/v1/attendance/class/${cls.id}`)).status, 200);
  assert.equal((await teacher2.put(`/api/v1/attendance/class/${cls.id}`, { date: new Date().toISOString().slice(0, 10), entries: [{ studentId: '00000000-0000-4000-8000-000000000000', status: 'present' }] })).status, 403);
  assert.equal((await teacher.put(`/api/v1/attendance/class/${b1b.id}`, { date: new Date().toISOString().slice(0, 10), entries: [{ studentId: '00000000-0000-4000-8000-000000000000', status: 'present' }] })).status, 403);
});

test('admin MFA reset: audited high-severity event, sessions revoked, owner protected', async () => {
  const bursar = await H.login(S.app, 'sa.bursar');           // enrols MFA
  const list = await admin.get('/api/v1/users?pageSize=100');
  const b = list.body.items.find((u) => u.login_id === 'sa.bursar'); const o = list.body.items.find((u) => u.login_id === 'sa.owner');
  assert.equal(b.mfa_enabled, true);
  assert.equal((await teacher.post(`/api/v1/users/${b.id}/mfa-reset`, { reason: 'lost phone' })).status, 403);
  assert.equal((await admin.post(`/api/v1/users/${o.id}/mfa-reset`, { reason: 'takeover attempt' })).status, 403, 'administrator cannot reset the owner');
  assert.equal((await admin.post(`/api/v1/users/${b.id}/mfa-reset`, { reason: 'Lost phone, verified in person' })).status, 200);
  assert.equal((await bursar.get('/api/v1/auth/me')).status, 401, 'sessions revoked');
  const c = H.client(S.app); const l = await c.post('/api/v1/auth/login', { loginId: 'sa.bursar', password: H.PASSWORD });
  assert.equal(l.body.mfaEnrollRequired, true, 'role still requires MFA → must re-enrol');
  const ev = await owner.get('/api/v1/security/events'); assert.ok(ev.body.items.some((e) => e.kind === 'mfa_reset_by_admin' && e.severity === 'high'));
});
