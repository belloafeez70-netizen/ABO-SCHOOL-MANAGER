'use strict';
// Test helper: the web app shows simple words by default. Suites written against the office terms switch to
// "full terms" exactly like a user would (the same localStorage preference the menu switch sets).
// words.qa.js checks the simple-words default itself.
module.exports = function fullWords(browser) {
  const add = async (pg) => { try { await pg.evaluateOnNewDocument(() => { try { localStorage.setItem('abo.words', 'full'); } catch (e) { /* ignore */ } }); } catch (e) { /* ignore */ } return pg; };
  const np = browser.newPage.bind(browser); browser.newPage = async (...a) => add(await np(...a));
  const cc = browser.createBrowserContext.bind(browser);
  browser.createBrowserContext = async (...a) => { const ctx = await cc(...a); const cnp = ctx.newPage.bind(ctx); ctx.newPage = async (...x) => add(await cnp(...x)); return ctx; };
  return browser;
};
