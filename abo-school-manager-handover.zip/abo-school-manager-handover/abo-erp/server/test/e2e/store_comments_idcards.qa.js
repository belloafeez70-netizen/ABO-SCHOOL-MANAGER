'use strict';
// Browser QA (Phase 6, part 2): School Store (add item, sell, receipt, void), Comment Helper and ID cards, in real Chrome.
// Needs a running server on a fresh dev-reset database. Usage: BASE_URL=http://127.0.0.1:8080 node server/test/e2e/store_comments_idcards.qa.js
const puppeteer = require('puppeteer');
const path = require('node:path');
const totp = require('../../src/security/totp');
const BASE = process.env.BASE_URL || 'http://127.0.0.1:8080';
const PW = process.env.DEMO_PASSWORD || 'Demo#School2026';
const SHOTS = process.env.SHOTS || path.join(__dirname, '../../../docs/screenshots');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms)); let pass = 0; const problems = [];
const ok = (n, c, x = '') => { if (c) pass++; else problems.push(n + ' ' + x); console.log((c ? '✔ ' : '✖ ') + n + (c ? '' : ' — ' + String(x).slice(0, 400))); };

(async () => {
  const b = await puppeteer.launch({ headless: 'shell', acceptInsecureCerts: !!process.env.QA_IGNORE_TLS, args: ['--no-sandbox', '--disable-dev-shm-usage', ...(process.env.QA_IGNORE_TLS ? ['--ignore-certificate-errors'] : [])] }); require('./fullwords')(b);
  const errs = [];
  const idle = async (p) => { await p.waitForNetworkIdle({ idleTime: 300, timeout: 10000 }).catch(() => {}); await sleep(200); };
  const open = async (loginId) => {
    const ctx = await b.createBrowserContext(); const p = await ctx.newPage(); await p.setViewport({ width: 1366, height: 900 });
    p.on('pageerror', (e) => errs.push(`${loginId}: ${e.message}`)); p.on('console', (m) => { if (m.type() === 'error' && !/status of 4\d\d/.test(m.text())) errs.push(`${loginId}: ${m.text()}`); });
    await p.goto(`${BASE}/#/login`, { waitUntil: 'networkidle0' });
    await p.type('input[name="loginId"]', loginId); await p.type('input[name="password"]', PW); await p.click('button[type="submit"]'); await idle(p);
    if (await p.$('.code-box')) { const s = (await p.$eval('.code-box', (e) => e.textContent)).replace(/\s+/g, ''); await p.type('input[name="code"]', totp.hotp(s, totp.stepAt())); await p.click('button[type="submit"]'); await idle(p); await clickText(p, 'button', 'I have saved them'); await idle(p); }
    return p;
  };
  const go = async (p, hash) => { const same = p.url().endsWith(hash); await p.goto(`${BASE}/${hash}`, { waitUntil: 'domcontentloaded' }); if (same) await p.reload({ waitUntil: 'domcontentloaded' }); await idle(p); };
  const text = (p) => p.evaluate(() => (document.querySelector('main') || document.body).innerText);
  async function clickText(p, sel, t) { for (const el of await p.$$(sel)) { if ((await el.evaluate((e) => e.textContent.trim())).startsWith(t)) { await el.click(); return true; } } return false; }
  const fill = (p, name, v) => p.evaluate((n, v) => { const el = document.querySelector(`.modal [name="${n}"]`); if (!el) return false; if (el.type === 'checkbox') el.checked = !!v; else el.value = v; el.dispatchEvent(new Event('change', { bubbles: true })); return true; }, name, v);
  const save = async (p, label = 'Save') => { await p.evaluate((l) => { const bs = [...document.querySelectorAll('.modal button')].filter((x) => x.textContent.trim() === l); bs[bs.length - 1].click(); }, label); await idle(p); await sleep(400); };
  try {
    // ── bursar sets up an item ──
    const B = await open('bopc.bursar');
    await go(B, '#/store');
    ok('bursar: store page', /School Store/.test(await text(B)) && /No items yet/.test(await text(B)));
    await clickText(B, 'button', 'Add item'); await sleep(400);
    await fill(B, 'name', 'Exercise book (40 leaves)'); await fill(B, 'category', 'Books'); await fill(B, 'price', '300'); await fill(B, 'cost', '200'); await fill(B, 'openingQty', '5'); await fill(B, 'reorderLevel', '2');
    await save(B); await sleep(600);
    ok('bursar: item added with 5 in stock', /Exercise book \(40 leaves\)[\s\S]{0,80}₦300[\s\S]{0,40}₦200[\s\S]{0,20}5/.test(await text(B)), (await text(B)).slice(0, 500));
    await clickText(B, 'button', 'Receive'); await sleep(400); await fill(B, 'qty', '10'); await save(B); await sleep(500);
    ok('bursar: received 10 more (15)', /₦200\s*15/.test(await text(B)), (await text(B)).slice(0, 500));
    // ── accountant sells ──
    const A = await open('bopc.accounts');
    await go(A, '#/store/sell');
    await clickText(A, '.sell-item', 'Exercise book'); await clickText(A, '.sell-item', 'Exercise book'); await sleep(200);
    ok('accountant: cart shows 2 × ₦300 = ₦600', /Total\s*₦600/.test(await text(A)), (await text(A)).slice(0, 600));
    await clickText(A, 'button', 'Complete sale'); await sleep(1500); await idle(A);
    const rc = await text(A);
    ok('accountant: receipt page with number and total', /Receipt SAL-\d{4}-000001/.test(rc) && /SALES RECEIPT/.test(rc) && /Total\s*₦600/.test(rc), rc.slice(0, 500));
    await A.screenshot({ path: path.join(SHOTS, 'phase6-store-receipt.png') });
    await go(A, '#/store/sales');
    ok('accountant: sale in the list, no Void button (no permission)', /SAL-\d{4}-000001/.test(await text(A)) && !(await A.evaluate(() => [...document.querySelectorAll('button')].some((x) => x.textContent.trim() === 'Void'))));
    // ── bursar voids; stock returns ──
    await go(B, '#/store/sales');
    await clickText(B, 'button', 'Void'); await sleep(400);
    await B.evaluate(() => { const ta = document.querySelector('.modal textarea'); ta.value = 'Sold to the wrong class'; });
    await B.evaluate(() => [...document.querySelectorAll('.modal button')].find((x) => x.textContent.trim() === 'Void sale').click()); await idle(B); await sleep(500);
    await go(B, '#/store');
    ok('bursar: after voiding, stock is back to 15', /₦200\s*15/.test(await text(B)), (await text(B)).slice(0, 400));
    await B.screenshot({ path: path.join(SHOTS, 'phase6-store-items.png') });
    // ── ID cards ──
    const O = await open('bopc.owner');
    await go(O, '#/id-cards');
    const cards = await O.$$eval('.idc', (x) => x.length); const bars = await O.$$eval('.idc svg.barcode', (x) => x.length);
    ok('owner: pupil ID cards with a barcode on each', cards > 0 && bars === cards, `${cards} cards, ${bars} barcodes`);
    ok('owner: barcode reads the admission number', await O.evaluate(() => { const c = document.querySelector('.idc'); return c.querySelector('svg.barcode').getAttribute('aria-label').includes(c.querySelector('.idc-meta b').textContent); }));
    await O.screenshot({ path: path.join(SHOTS, 'phase6-idcards.png') });
    await clickText(O, '.tabs button, [role=tab]', 'Staff'); await sleep(800); await idle(O);
    ok('owner: staff cards', /STAFF/.test(await text(O)) && /Mr Tunde Bello/.test(await text(O)), (await text(O)).slice(0, 300));
    // ── comment helper (form teacher of BASIC 1A, whose results are computed) ──
    const T = await open('bopc.teacher1');
    await go(T, '#/results/comments'); await sleep(500);
    const ct = await text(T);
    ok('teacher: class loads with suggestions', /You are writing the class teacher’s comment/.test(ct) && /Suggestion: .+ scored \d+%/.test(ct), ct.slice(0, 600));
    // empty the first two boxes (the demo data already has comments), let the helper fill them, save, and check
    const sugg = await T.$$eval('.comment-row', (rows) => rows.slice(0, 2).map((r) => { const t = r.querySelector('textarea'); t.value = ''; return r.querySelector('.comment-sugg small').textContent.replace(/^Suggestion: /, ''); }));
    await clickText(T, 'button', 'Fill empty boxes'); await sleep(300);
    const nowText = await T.$$eval('.comment-boxes textarea', (x) => x.slice(0, 2).map((t) => t.value));
    ok('teacher: "Fill empty boxes" puts the suggestion into the emptied boxes', nowText[0] === sugg[0] && nowText[1] === sugg[1], JSON.stringify({ nowText, sugg }));
    await T.evaluate(() => { const t = document.querySelectorAll('.comment-boxes textarea')[1]; t.value = t.value + ' Well done.'; });   // the teacher edits one
    await clickText(T, 'button', 'Save all'); await sleep(1500); await idle(T);
    const toastNow = await T.evaluate(() => [...document.querySelectorAll('.toast')].map((e) => e.innerText).join(' | '));
    await go(T, '#/results/comments'); await sleep(800);
    const saved = await T.$$eval('.comment-boxes textarea', (x) => x.slice(0, 2).map((t) => t.value));
    ok('teacher: saved exactly 2 changed comments, kept after reloading the page (incl. the teacher’s edit)', /Saved comments for 2 pupil/.test(toastNow) && saved[0] === sugg[0] && saved[1] === sugg[1] + ' Well done.', JSON.stringify({ toastNow, saved }));
    const filled = 2;
    await T.screenshot({ path: path.join(SHOTS, 'phase6-comment-helper.png') });
    const E = await open('bopc.exams');
    await go(E, '#/results/comments'); await sleep(500);
    ok('exam officer: can write both comments and sees the teacher’s saved words', /both the class teacher’s and the head’s comment/.test(await text(E)) && (await E.$$eval('.comment-boxes textarea', (x) => x.filter((t) => t.value.trim()).length)) >= filled);
    await go(T, '#/store');
    ok('teacher: store is closed to teachers', /don’t have access|do not have permission/i.test(await text(T)), (await text(T)).slice(0, 200));
    ok('no console or page errors', errs.length === 0, errs.join(' | '));
  } finally { await b.close(); }
  console.log(`\n${pass} passed, ${problems.length} failed`); process.exit(problems.length ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
