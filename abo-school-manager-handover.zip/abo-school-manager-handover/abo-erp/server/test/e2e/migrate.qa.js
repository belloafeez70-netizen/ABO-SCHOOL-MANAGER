// Browser QA (Phase 5): Legacy Migration page with a real offline backup + custom score layout. Needs a running dev server.
// Usage: BASE_URL=http://127.0.0.1:8080 node server/test/e2e/migrate.qa.js  (user bopc.admin, fresh dev-reset database)
// browser check of the server web app's Legacy Migration page with the real Phase 5 backup + a custom-layout variant
const puppeteer=require('puppeteer'); const fs=require('fs'); const totp=require('../../src/security/totp');
const BASE=process.env.BASE_URL||'http://127.0.0.1:8080', PW='Demo#School2026'; const sleep=(ms)=>new Promise(r=>setTimeout(r,ms)); let pass=0,fail=0;
const ok=(n,c,x='')=>{ c?pass++:fail++; console.log((c?'✔ ':'✖ ')+n+(c?'':' — '+x)); };
(async()=>{ const b=await puppeteer.launch({headless:'shell',acceptInsecureCerts:!!process.env.QA_IGNORE_TLS,args:['--no-sandbox',...(process.env.QA_IGNORE_TLS?['--ignore-certificate-errors']:[])]}); require('./fullwords')(b); const p=await b.newPage(); await p.setViewport({width:1440,height:1000});
 const errs=[]; p.on('pageerror',e=>errs.push(e.message)); p.on('console',m=>{ if(m.type()==='error') errs.push(m.text()); });
 const idle=async()=>{ await p.waitForNetworkIdle({idleTime:300,timeout:10000}).catch(()=>{}); await sleep(200); };
 await p.goto(BASE+'/#/login',{waitUntil:'networkidle0'}); await p.type('input[name="loginId"]','bopc.admin'); await p.type('input[name="password"]',PW); await p.click('button[type="submit"]'); await idle();
 if(await p.$('.code-box')){ const s=(await p.$eval('.code-box',e=>e.textContent)).replace(/\s+/g,''); await p.type('input[name="code"]',totp.hotp(s,totp.stepAt())); await p.click('button[type="submit"]'); await idle();
   for(const bt of await p.$$('button')){ if((await bt.evaluate(e=>e.textContent)).includes('I have saved them')){ await bt.click(); break; } } await idle(); }
 await p.goto(BASE+'/#/migrate',{waitUntil:'domcontentloaded'}); await idle();
 ok('migration page opens', /Legacy migration/i.test(await p.$eval('h1',e=>e.textContent).catch(()=>'')));
 const d=JSON.parse(fs.readFileSync(require('path').join(__dirname,'../fixtures/offline-backup-phase5.json'),'utf8'));
 d.schoolData.erp.broadsheet.components=[{key:'ca1',name:'CA 1',max:20,weight:15},{key:'ca2',name:'CA 2',max:20,weight:15},{key:'x1',name:'Project',max:10,weight:10},{key:'exam',name:'Exam',max:100,weight:60}];
 const PNG='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=='; d.students[0].passport=PNG; d.schoolData.logo=PNG;
 fs.writeFileSync(require('os').tmpdir()+'/ui-backup.json',JSON.stringify(d));
 const inp=await p.$('input[type="file"]'); await inp.uploadFile(require('os').tmpdir()+'/ui-backup.json');
 for(const bt of await p.$$('button')){ if(/Preview migration/.test(await bt.evaluate(e=>e.textContent))){ await bt.click(); break; } } await idle();
 await sleep(800); const t=await p.evaluate(()=>(document.querySelector('main')||document.body).innerText);  
 ok('preview shows 20 learners in 2 classes', /Learners\s*\n?\s*20/i.test(t) && /BASIC 1/.test(t) && /BASIC 2/.test(t), t.slice(0,400));
 ok('preview warns about the different score layout', /Score layout is different/.test(t));
 ok('tick box "Use the offline score layout" shown and ticked', await p.evaluate(()=>{ const c=document.getElementById('adoptLayout'); return !!c && c.checked; }));
 await p.screenshot({path:require('path').join(__dirname,'../../../docs/screenshots/')+'phase5-migration-preview.png'});
 for(const bt of await p.$$('button')){ if(/Commit migration/.test(await bt.evaluate(e=>e.textContent))){ await bt.click(); break; } } await sleep(500);
 for(const bt of await p.$$('.modal button, dialog button, [role=dialog] button')){ const tx=await bt.evaluate(e=>e.textContent); if(/^(OK|Confirm|Yes|Import|Continue)/i.test(tx.trim())){ await bt.click(); break; } } await idle(); await sleep(800);
 const t2=await p.evaluate(()=>document.body.innerText);
 ok('done screen: every learner accounted for', /Every learner in the file is accounted for/.test(t2), t2.slice(0,500));
 ok('done screen: passport photo and logo brought in', /1 passport photo\(s\) brought in, and the school logo/.test(t2), (t2.match(/passport photo[^\n]*/)||[''])[0]);
 ok('done screen: 20 brought in', /Brought in\s*\n?\s*20/i.test(t2), (t2.match(/Brought in[\s\S]{0,20}/)||[''])[0]);
 await p.screenshot({path:require('path').join(__dirname,'../../../docs/screenshots/')+'phase5-migration-done.png'});
 ok('no console errors', errs.length===0, errs.join(' | ').slice(0,300));
 console.log(`\n${pass} passed, ${fail} failed`); await b.close(); process.exit(fail?1:0); })().catch(e=>{console.error(e);process.exit(1);});
