'use strict';
// Test helper: a phone test must look like a real phone. A real phone browser sends a phone name (Android / iPhone)
// in its user agent; headless Chrome sends a computer name. Since 11 Oct 2026 the app treats "computer name on a
// small touch screen" as the browser's "Desktop site" switch (and shows the computer layout), so phone-sized pages
// in the tests get a real Android Chrome user agent. Computer-sized pages are untouched.
const ANDROID = 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36';
module.exports = function phone(browser) {
  const add = (pg) => {
    const sv = pg.setViewport.bind(pg);
    pg.setViewport = async (vp) => { if (vp && vp.isMobile && !pg.__uaSet) await pg.setUserAgent(ANDROID); return sv(vp); };
    const su = pg.setUserAgent.bind(pg); pg.setUserAgent = async (...a) => { pg.__uaSet = a[0] !== ANDROID; return su(...a); };
    return pg;
  };
  const np = browser.newPage.bind(browser); browser.newPage = async (...a) => add(await np(...a));
  const cc = browser.createBrowserContext.bind(browser);
  browser.createBrowserContext = async (...a) => { const ctx = await cc(...a); const cnp = ctx.newPage.bind(ctx); ctx.newPage = async (...x) => add(await cnp(...x)); return ctx; };
  return browser;
};
