'use strict';
// Phone tap audit — opens every menu page on a 390×844 touch screen and checks what a person on a phone feels:
//  • the page does not slide sideways (no horizontal overflow)
//  • every visible button / drop-down / input can be reached and is not hidden under the top bar, bottom bar or
//    another layer (elementFromPoint at its centre is the control itself)
//  • the "Add / New / Record…" dialogs open fully on the screen with their buttons reachable, and close again
//  • the top-bar pop-ups (account, notifications) fit the screen
// Usage: BASE_URL=http://127.0.0.1:8080 ROLES=bopc.owner,bopc.teacher1 node server/test/e2e/mobile_tap.qa.js
const puppeteer = require('puppeteer');
const totp = require('../../src/security/totp');
const fs = require('node:fs');

const BASE = process.env.BASE_URL || 'http://127.0.0.1:8080';
const PW = process.env.DEMO_PASSWORD || 'Demo#School2026';
const ROLES = (process.env.ROLES || 'bopc.owner,bopc.admin,bopc.bursar,bopc.teacher1,bopc.student,bopc.parent').split(',');
const SHOTS = process.env.SHOTS || '/tmp/mobile-tap-shots'; fs.mkdirSync(SHOTS, { recursive: true });
const WIDTH = Number(process.env.WIDTH || 390);
const results = []; const problems = [];
const ok = (name, cond, extra = '') => { results.push(!!cond); if (!cond) problems.push(`${name} ${extra}`); if (!cond || process.env.VERBOSE) process.stdout.write(`${cond ? '✔' : '✖'} ${name}${extra && !cond ? ' — ' + extra : ''}\n`); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function idle(page) { await page.waitForNetworkIdle({ idleTime: 250, timeout: 15000 }).catch(() => {}); await sleep(150); }

const secrets = {};
async function login(page, loginId) {
  await page.goto(`${BASE}/#/login`, { waitUntil: 'networkidle0' });
  await page.waitForSelector('input[name="loginId"]');
  await page.type('input[name="loginId"]', loginId); await page.type('input[name="password"]', PW);
  await page.tap('button[type="submit"]'); await idle(page);
  if (await page.$('.code-box')) {
    const secret = (await page.$eval('.code-box', (e) => e.textContent)).replace(/\s+/g, ''); secrets[loginId] = secret;
    await page.type('input[name="code"]', totp.hotp(secret, totp.stepAt())); await page.tap('button[type="submit"]'); await idle(page);
    await page.evaluate(() => { const b = [...document.querySelectorAll('button')].find((x) => x.textContent.includes('I have saved them')); if (b) b.click(); }); await idle(page);
  }
  await page.waitForSelector('.sidebar', { timeout: 15000 });
}

// everything a finger could need on the page, checked in the page itself
const auditPage = () => {
  const W = window.innerWidth; const H = window.innerHeight; const out = { overflow: document.documentElement.scrollWidth - W, bad: [], small: 0, total: 0 };
  const scrollsX = (el) => { for (let p = el.parentElement; p && p !== document.body; p = p.parentElement) { const s = getComputedStyle(p); if ((s.overflowX === 'auto' || s.overflowX === 'scroll') && p.scrollWidth > p.clientWidth + 1) return p; } return null; };
  const label = (el) => (el.getAttribute('aria-label') || el.textContent || el.name || el.placeholder || el.tagName).trim().replace(/\s+/g, ' ').slice(0, 40);
  const els = [...document.querySelectorAll('#view button, #view select, #view input:not([type=hidden]), #view textarea, #view a.btn, #view [role=tab], .topbar button')]
    .filter((e) => { const dt = e.closest('details'); if (dt && !dt.open && !e.closest('summary')) return false; const r = e.getBoundingClientRect(); const s = getComputedStyle(e); return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && !e.closest('[hidden]') && !e.disabled; })
    .slice(0, 80);
  for (const el of els) {
    out.total++;
    const box = scrollsX(el);
    if (box) { const br = box.getBoundingClientRect(); const r0 = el.getBoundingClientRect(); box.scrollLeft += (r0.left + r0.width / 2) - (br.left + br.width / 2); }
    el.scrollIntoView({ block: 'center', inline: 'nearest' });
    const r = el.getBoundingClientRect();
    if (r.height < 28 && !/checkbox|radio/.test(el.type || '')) out.small++;
    const cx = Math.min(Math.max(r.left + Math.min(r.width / 2, 20), 1), W - 2); const cy = r.top + r.height / 2;
    if (r.right > W + 1 && !box) { out.bad.push(`${label(el)}: off the right edge`); continue; }
    if (cy < 0 || cy > H) { out.bad.push(`${label(el)}: cannot be scrolled into view`); continue; }
    const t = document.elementFromPoint(cx, cy);
    const isLabelFor = t && t.tagName === 'LABEL' && (t.control === el || t.contains(el));
    if (!t || !(t === el || el.contains(t) || isLabelFor || (el.labels && [...el.labels].some((l) => l.contains(t))))) {
      out.bad.push(`${label(el)}: covered by ${t ? (t.className || t.tagName).toString().slice(0, 40) : 'nothing'}`);
    }
  }
  window.scrollTo(0, 0);
  return out;
};

const modalCheck = () => {
  const m = document.querySelector('.modal'); if (!m) return { open: false };
  const W = window.innerWidth; const H = window.innerHeight; const r = m.getBoundingClientRect(); const issues = [];
  if (r.left < -1 || r.right > W + 1) issues.push('dialog wider than the screen');
  if (r.top < -1 || r.bottom > H + 1) issues.push(`dialog taller than the screen (${Math.round(r.bottom)} > ${H})`);
  for (const b of m.querySelectorAll('.modal-foot button, .modal-head button')) {
    const br = b.getBoundingClientRect(); if (!br.width) continue;
    if (br.right > W + 1 || br.left < -1 || br.bottom > H + 1) { issues.push(`button "${b.textContent.trim() || b.getAttribute('aria-label')}" off screen`); continue; }
    const t = document.elementFromPoint(br.left + br.width / 2, br.top + br.height / 2);
    if (!t || !(t === b || b.contains(t))) issues.push(`button "${b.textContent.trim() || b.getAttribute('aria-label')}" covered`);
  }
  return { open: true, issues, title: (m.querySelector('.modal-head') || m).textContent.trim().slice(0, 50) };
};

async function role(browser, loginId) {
  const ctx = await browser.createBrowserContext(); const page = await ctx.newPage();
  await page.setViewport({ width: WIDTH, height: 844, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));
  page.on('dialog', (d) => d.dismiss());
  await login(page, loginId);
  // top bar pop-ups
  for (const sel of ['.user-chip', '.bell']) {
    const el = await page.$(sel); if (!el) continue;
    await el.tap(); await sleep(500);
    const pop = await page.evaluate(() => { const p = [...document.querySelectorAll('.popover')].find((x) => !x.hidden); if (!p) return null; const r = p.getBoundingClientRect(); return { l: r.left, r: r.right, b: r.bottom, W: innerWidth, H: innerHeight }; });
    ok(`${loginId} phone: ${sel} pop-up opens inside the screen`, pop && pop.l >= 0 && pop.r <= pop.W + 1 && pop.b <= pop.H + 1, JSON.stringify(pop));
    await page.tap('.top-title').catch(() => {}); await sleep(200);
  }
  const hrefs = await page.$$eval('.sidebar a.nav-item', (as) => [...new Set(as.map((a) => a.getAttribute('href')).filter((x) => x && x.startsWith('#/') && !/logout/.test(x)))]);
  // 12 Oct 2026: merged pages are tabs — every tab page is tapped through too
  for (let hi = 0; hi < hrefs.length; hi++) {
    const href = hrefs[hi];
    const before = errors.length;
    await page.evaluate((hh) => { location.hash = hh; }, href); await idle(page);
    for (const t of await page.$$eval('.hub-tab', (as) => as.map((x) => x.getAttribute('href')))) if (t && !hrefs.includes(t)) hrefs.push(t);
    const a = await page.evaluate(auditPage);
    ok(`${loginId} ${href}: no sideways scrolling`, a.overflow <= 1, `page is ${a.overflow}px wider than the phone`);
    ok(`${loginId} ${href}: all ${a.total} controls reachable`, a.bad.length === 0, a.bad.slice(0, 6).join(' | '));
    // open the first "add/new" style dialog on the page, check it, close it
    const opened = await page.evaluate(() => {
      const b = [...document.querySelectorAll('#view .page-actions button, #view .card-actions button, #view .dt-bar button')].find((x) => x.offsetParent && /^(\+\s*)?(add|new|create|record|issue|post|enrol|register)\b/i.test(x.textContent.trim()));
      if (!b) return false; b.scrollIntoView({ block: 'center' }); b.click(); return b.textContent.trim().slice(0, 30);
    });
    if (opened) {
      await sleep(600);
      const m = await page.evaluate(modalCheck);
      if (m.open) {
        ok(`${loginId} ${href}: dialog "${m.title}" fits the phone`, m.issues.length === 0, m.issues.join(' | '));
        if (m.issues.length) await page.screenshot({ path: `${SHOTS}/${loginId}-${href.replace(/[^a-z0-9]+/gi, '_')}-dialog.png` });
        await page.keyboard.press('Escape'); await sleep(250);
        await page.evaluate(() => { const x = document.querySelector('.modal-head button'); if (x) x.click(); }); await sleep(200);
        ok(`${loginId} ${href}: dialog closes`, !(await page.$('.modal')));
      }
    }
    ok(`${loginId} ${href}: no script errors`, errors.length === before, errors.slice(before).join(' | '));
    if (a.bad.length || a.overflow > 1) await page.screenshot({ path: `${SHOTS}/${loginId}-${href.replace(/[^a-z0-9]+/gi, '_')}.png` });
  }
  await ctx.close();
}

(async () => {
  const browser = await puppeteer.launch({ headless: 'shell', args: ['--no-sandbox'], acceptInsecureCerts: !!process.env.QA_IGNORE_TLS }); require(__dirname + '/phone.js')(browser);
  try { for (const r of ROLES) await role(browser, r); } catch (e) { problems.push('crash: ' + e.stack); console.error(e); }
  await browser.close();
  const passed = results.filter(Boolean).length;
  console.log(`\n${passed}/${results.length} passed`);
  if (problems.length) { console.log('\nProblems:'); problems.forEach((p) => console.log(' - ' + p)); }
  process.exit(problems.length ? 1 : 0);
})();
