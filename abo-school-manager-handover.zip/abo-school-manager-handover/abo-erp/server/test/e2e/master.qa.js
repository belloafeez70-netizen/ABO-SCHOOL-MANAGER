'use strict';
// Final acceptance (master prompt, 11 Oct 2026) in a real browser: two DEMO schools with a visible 5-minute countdown
// and no owner controls, ending the demo, editable custom classes, owner-only payment settings (secret never shown),
// school subscription page, phone layout. Usage: BASE_URL=http://127.0.0.1:8080 node server/test/e2e/master.qa.js
const puppeteer = require('puppeteer');
const totp = require('../../src/security/totp');
const fs = require('node:fs');
const BASE = process.env.BASE_URL || 'http://127.0.0.1:8080';
const PW = process.env.DEMO_PASSWORD || 'Demo#School2026';
const SHOTS = process.env.SHOTS || '/tmp/master-shots'; fs.mkdirSync(SHOTS, { recursive: true });
const results = []; const problems = [];
const ok = (n, c, x = '') => { results.push(!!c); if (!c) problems.push(`${n} ${x}`); console.log(`${c ? '✔' : '✖'} ${n}${c ? '' : ' — ' + x}`); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const idle = async (p) => { await p.waitForNetworkIdle({ idleTime: 300, timeout: 15000 }).catch(() => {}); await sleep(250); };
const secrets = {};
async function login(p, id) {
  await p.goto(`${BASE}/#/login`, { waitUntil: 'networkidle0' }); await p.waitForSelector('input[name="loginId"]');
  await p.type('input[name="loginId"]', id); await p.type('input[name="password"]', PW); await p.click('button[type="submit"]'); await idle(p);
  if (await p.$('.code-box')) {
    const secret = (await p.$eval('.code-box', (e) => e.textContent)).replace(/\s+/g, ''); secrets[id] = secret;
    await p.type('input[name="code"]', totp.hotp(secret, totp.stepAt())); await p.click('button[type="submit"]'); await idle(p);
    await p.evaluate(() => { const b = [...document.querySelectorAll('button')].find((x) => x.textContent.includes('I have saved them')); if (b) b.click(); }); await idle(p);
  } else if (await p.$('input[name="code"]') && secrets[id]) { await p.type('input[name="code"]', totp.hotp(secrets[id], totp.stepAt() + 1)); await p.click('button[type="submit"]'); await idle(p); }
  await p.waitForSelector('.sidebar', { timeout: 15000 });
}
const go = async (p, hash) => { await p.evaluate((x) => { location.hash = x; }, hash); await idle(p); };
const clickText = (p, sel, re) => p.evaluate((s, r) => { const b = [...document.querySelectorAll(s)].find((x) => new RegExp(r).test(x.textContent.trim())); if (b) { b.click(); return true; } return false; }, sel, re.source || re);

(async () => {
  const browser = await puppeteer.launch({ headless: 'shell', args: ['--no-sandbox'] }); require('./phone')(browser);
  const errors = [];
  try {
    // ── demo ──
    const c1 = await browser.createBrowserContext(); const d = await c1.newPage(); await d.setViewport({ width: 1366, height: 860 });
    d.on('pageerror', (e) => errors.push(e.message)); d.on('console', (m) => { if (m.type() === 'error' && !/40[134]/.test(m.text())) errors.push(m.text()); });
    await d.evaluateOnNewDocument(() => { try { localStorage.setItem('abo.words', 'full'); } catch { /* */ } });
    // 028 (owner's request): only the A.B.O. platform owner opens demos — with a demo link made in the platform console
    const cp = await browser.createBrowserContext(); const P = await cp.newPage(); await P.setViewport({ width: 1366, height: 860 });
    P.on('pageerror', (e) => errors.push('platform: ' + e.message));
    await login(P, 'abo.platform');
    ok('platform console menu has "Demo Links"', await P.evaluate(() => [...document.querySelectorAll('.sidebar a.nav-item')].some((a) => /Demo Links/.test(a.textContent))));
    await go(P, '#/platform/demo');
    await clickText(P, 'button', /^Make a demo link$/); await sleep(400);
    await P.evaluate(() => { const m = document.querySelector('.modal'); m.querySelector('input[name="label"]').value = 'QA prospect school'; m.querySelector('input[name="uses"]').value = '10'; });
    await clickText(P, '.modal button', /^Make link$/); await idle(P);
    const link = await P.$eval('.demo-link-box', (e) => e.value).catch(() => '');
    ok('the platform owner makes a demo link (shown once, with Copy and WhatsApp)', /#\/demo\?pass=DEMO-[A-Z2-9-]+$/.test(link) && await P.evaluate(() => /Send by WhatsApp/.test(document.querySelector('.modal').innerText) && /Copy link/.test(document.querySelector('.modal').innerText)), link);
    await P.evaluate(() => { [...document.querySelectorAll('.modal button')].find((b) => b.textContent === 'Close').click(); }); await idle(P);
    ok('the link is listed as active, 0 / 10 used', await P.evaluate(() => /QA prospect school/.test(document.body.innerText) && /0 \/ 10/.test(document.body.innerText) && /active/i.test(document.body.innerText)));
    const DEMO = `${BASE}/#/demo?pass=${link.split('pass=')[1]}`;
    await d.goto(`${BASE}/#/login`, { waitUntil: 'networkidle0' });
    ok('the public sign-in page has NO "Try the demo" button', await d.evaluate(() => !/Try the demo/.test(document.body.innerText) && !document.querySelector('a.demo-link')));
    await d.goto(`${BASE}/#/demo`, { waitUntil: 'networkidle0' }); await idle(d);
    ok('the demo address without a link offers nothing to start ("by invitation")', await d.evaluate(() => /Demo by invitation/.test(document.body.innerText) && !document.querySelector('.demo-school')));
    ok('no password or login code is shown on the sign-in page', await d.evaluate(() => !/Demo#School2026|Belloafeez/i.test(document.documentElement.outerHTML)));
    await d.goto(DEMO, { waitUntil: 'networkidle0' }); await idle(d);
    const cards = await d.$$eval('.demo-school', (x) => x.map((e) => e.querySelector('strong').textContent));
    ok('two separate demo schools are offered, each labelled DEMO', cards.length === 2 && await d.evaluate(() => document.querySelectorAll('.demo-school .demo-pill').length === 2), JSON.stringify(cards));
    await d.evaluate(() => { const s = [...document.querySelectorAll('.demo-school')][0]; [...s.querySelectorAll('button')].find((b) => /office/.test(b.textContent)).click(); }); await idle(d); await d.waitForSelector('.demo-banner', { timeout: 10000 });
    const banner = await d.$eval('.demo-banner', (e) => e.textContent);
    const t = (banner.match(/(\d):(\d\d)/) || []).slice(1).map(Number);
    ok('DEMO banner with a visible countdown of at most 5:00', /DEMO/.test(banner) && t.length === 2 && t[0] * 60 + t[1] <= 300 && t[0] * 60 + t[1] > 240, banner);
    await sleep(2200);
    const t2 = ((await d.$eval('.demo-left', (e) => e.textContent)).match(/(\d):(\d\d)/) || []).slice(1).map(Number);
    ok('the countdown is running', t2[0] * 60 + t2[1] < t[0] * 60 + t[1]);
    const menu = await d.$$eval('.sidebar a.nav-item', (as) => as.map((a) => (a.dataset.full || a.textContent).trim()));
    ok('no owner controls in the demo menu (logins, roles, sign-in-as, backup, settings)', !menu.some((m) => /^(Users|Roles & Permissions|Sign In As Someone|Backup & Data|General Settings|Audit Logs|Security Events)$/.test(m)), JSON.stringify(menu));
    await go(d, '#/students'); ok('demo pupils load', await d.evaluate(() => document.querySelectorAll('.table tbody tr').length > 0));
    await go(d, '#/broadsheet/cumulative'); await d.evaluate(() => { const s = document.querySelector('select[name="classId"]'); const o = [...s.options].find((x) => /PRIMARY 1A/i.test(x.textContent)); if (o) { s.value = o.value; s.dispatchEvent(new Event('change', { bubbles: true })); } }); await idle(d);
    ok('demo results load (cumulative, PRIMARY 1A)', await d.evaluate(() => !!document.querySelector('table.cum-sheet')));
    await go(d, '#/users'); ok('owner pages are refused in the demo', await d.evaluate(() => /permission|switched off|not have access|access to this page/i.test(document.body.innerText)));
    await d.screenshot({ path: `${SHOTS}/demo-banner.png` });
    await d.evaluate(() => [...document.querySelectorAll('.demo-banner button')].find((b) => /End demo/.test(b.textContent)).click()); await idle(d); await sleep(800);
    ok('"End demo" signs out and explains the demo was reset', /#\/login/.test(d.url()) && await d.evaluate(() => /demo time is over/.test(document.body.innerText)), d.url());
    // the secondary demo: separate school
    await d.goto(DEMO, { waitUntil: 'networkidle0' }); await d.waitForSelector('.demo-school', { timeout: 10000 });
    await d.evaluate(() => { const s = [...document.querySelectorAll('.demo-school')][1]; [...s.querySelectorAll('button')].find((b) => /Teacher/.test(b.textContent)).click(); }); await idle(d); await d.waitForSelector('.demo-banner');
    ok('second demo school opens as a teacher', /Unity College/.test(await d.$eval('.demo-banner', (e) => e.textContent)));
    await c1.close();

    // ── classes (administrator) ──
    const c2 = await browser.createBrowserContext(); const a = await c2.newPage(); await a.setViewport({ width: 1366, height: 900 });
    a.on('pageerror', (e) => errors.push('admin: ' + e.message));
    await a.evaluateOnNewDocument(() => { try { localStorage.setItem('abo.words', 'full'); } catch { /* */ } });
    await login(a, 'bopc.admin');
    await go(a, '#/academic/classes');
    await clickText(a, '.page-actions button', /^Add standard classes$/); await sleep(500);
    const labels = await a.$$eval('.modal label', (x) => x.map((e) => e.textContent.trim()));
    ok('standard list offers Creche, Nursery 1–2, Kindergarten, Primary 1–6, JSS 1–3, SS 1–3', ['Creche', 'Nursery 1', 'Nursery 2', 'Kindergarten', 'Primary 6', 'JSS 3', 'SS 3'].every((n) => labels.some((l) => l.startsWith(n))), JSON.stringify(labels.slice(0, 18)));
    await a.evaluate(() => { [...document.querySelectorAll('.modal label')].forEach((l) => { if (/^(Creche|Nursery 1|SS 2)$/.test(l.textContent.trim())) { const i = l.querySelector('input') || document.getElementById(l.htmlFor); if (i) i.click(); } }); });
    await clickText(a, '.modal .modal-foot button', /Save|Submit|Add/); await idle(a); await sleep(500);
    const names = await a.$$eval('.card table tbody tr td:first-child strong', (x) => x.map((e) => e.textContent));
    ok('standard classes were added', names.includes('CRECHE') && names.includes('NURSERY 1') && names.includes('SS 2'), JSON.stringify(names));
    // rename CRECHE → LITTLE STARS
    await a.evaluate(() => { const row = [...document.querySelectorAll('.card table tbody tr')].find((r) => r.querySelector('strong').textContent === 'CRECHE'); [...row.querySelectorAll('button')].find((b) => b.textContent.trim() === 'Edit').click(); }); await sleep(400);
    await a.evaluate(() => { const i = document.querySelector('.modal input[name="name"]'); i.value = 'Little Stars'; i.dispatchEvent(new Event('input', { bubbles: true })); });
    await clickText(a, '.modal .modal-foot button', /Save/); await idle(a); await sleep(400);
    ok('a class can be renamed', (await a.$$eval('.card table tbody tr td:first-child strong', (x) => x.map((e) => e.textContent))).includes('LITTLE STARS'));
    await a.evaluate(() => { const row = [...document.querySelectorAll('.card table tbody tr')].find((r) => r.querySelector('strong').textContent === 'LITTLE STARS'); [...row.querySelectorAll('button')].find((b) => b.textContent.trim() === 'Switch off').click(); }); await sleep(300);
    await clickText(a, '.modal .modal-foot button', /Confirm|Yes|Switch/); await idle(a); await sleep(400);
    ok('an empty class can be switched off (kept, labelled)', await a.evaluate(() => [...document.querySelectorAll('.card table tbody tr')].some((r) => /LITTLE STARS/.test(r.textContent) && /switched off/.test(r.textContent))));
    await a.screenshot({ path: `${SHOTS}/classes.png`, fullPage: true });
    await go(a, '#/billing');
    ok('school subscription page shows status and plans', await a.evaluate(() => /Your plan/.test(document.body.innerText) && document.querySelectorAll('.plan-card2').length >= 2));
    await c2.close();

    // ── platform owner: payment settings ──
    const c3 = await browser.createBrowserContext(); const pl = await c3.newPage(); await pl.setViewport({ width: 1366, height: 900 });
    pl.on('pageerror', (e) => errors.push('platform: ' + e.message));
    await login(pl, 'abo.platform');
    ok('platform menu has Payments & Plans', await pl.evaluate(() => [...document.querySelectorAll('.sidebar a.nav-item')].some((x) => /Payments & Plans/.test(x.textContent))));
    await go(pl, '#/platform/billing');
    await clickText(pl, '.page-actions button', /Change settings/); await sleep(400);
    await pl.evaluate(() => { const set = (n, v) => { const i = document.querySelector(`.modal [name="${n}"]`); i.value = v; i.dispatchEvent(new Event('input', { bubbles: true })); }; set('paystackPublicKey', 'pk_test_uiCheck12345678'); set('paystackSecretKey', 'sk_test_uiCheckSecret98765'); set('demoMinutes', '4'); });
    await clickText(pl, '.modal .modal-foot button', /Save/); await idle(pl); await sleep(500);
    const page = await pl.evaluate(() => document.body.innerText);
    ok('secret key saved: shown only as a hint, never in full', /sk_test_…8765/.test(page) && !/sk_test_uiCheckSecret98765/.test(await pl.evaluate(() => document.documentElement.outerHTML)), page.slice(0, 300));
    ok('demo timer saved (4 minutes)', /4 minute/.test(page));
    await clickText(pl, '.tab', /^Plans & prices$/); await idle(pl);
    ok('plans & prices listed', await pl.evaluate(() => /Term plan/.test(document.body.innerText) && /Yearly plan/.test(document.body.innerText)));
    await clickText(pl, '.tab', /^Schools$/); await idle(pl);
    ok('every school with its subscription status (demo schools labelled)', await pl.evaluate(() => /trial/i.test(document.body.innerText) && document.querySelectorAll('.demo-pill').length >= 2));
    await pl.screenshot({ path: `${SHOTS}/platform-billing.png`, fullPage: true });
    // reset the demo timer to 5 for other suites
    await pl.evaluate(async () => { const me = await (await fetch('/api/v1/auth/me')).json(); await fetch('/api/v1/platform/billing/settings', { method: 'PUT', headers: { 'content-type': 'application/json', 'x-csrf-token': me.csrf }, body: JSON.stringify({ demoMinutes: 5 }) }); });
    await c3.close();

    // ── phone ──
    const c4 = await browser.createBrowserContext(); const m = await c4.newPage(); await m.setViewport({ width: 390, height: 844, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
    m.on('pageerror', (e) => errors.push('phone: ' + e.message));
    await m.goto(DEMO, { waitUntil: 'networkidle0' });
    await m.evaluate(() => { const s = [...document.querySelectorAll('.demo-school')][0]; [...s.querySelectorAll('button')].find((b) => /Parent/.test(b.textContent)).click(); }); await idle(m); await m.waitForSelector('.demo-banner');
    ok('phone: demo banner and countdown visible, page does not slide sideways', await m.evaluate(() => { const b = document.querySelector('.demo-banner').getBoundingClientRect(); return b.width <= innerWidth + 1 && document.documentElement.scrollWidth <= innerWidth + 1; }));
    await m.screenshot({ path: `${SHOTS}/phone-demo.png` });
    await c4.close();
  } catch (e) { problems.push('crash ' + e.stack); console.error(e); }
  ok('no script errors', errors.length === 0, errors.join(' | '));
  await browser.close();
  console.log(`\n${results.filter(Boolean).length}/${results.length} passed`);
  process.exit(problems.length ? 1 : 0);
})();
