'use strict';
// Menu interaction QA — drives the sidebar the way a person does (real mouse clicks / taps / keyboard), unlike
// menu.qa.js which opens each page by URL. Desktop + phone; several roles.
// Usage: BASE_URL=http://127.0.0.1:8080 node server/test/e2e/menu_click.qa.js
const puppeteer = require('puppeteer');
const totp = require('../../src/security/totp');
const path = require('node:path');
const fs = require('node:fs');

const BASE = process.env.BASE_URL || 'http://127.0.0.1:8080';
const PW = process.env.DEMO_PASSWORD || 'Demo#School2026';
const SHOTS = process.env.SHOTS || '/tmp/menu-click-shots'; fs.mkdirSync(SHOTS, { recursive: true });
const results = []; const problems = [];
const ok = (name, cond, extra = '') => { results.push(!!cond); if (!cond) problems.push(`${name} ${extra}`); process.stdout.write(`${cond ? '✔' : '✖'} ${name}${extra && !cond ? ' — ' + extra : ''}\n`); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function idle(page) { await page.waitForNetworkIdle({ idleTime: 250, timeout: 15000 }).catch(() => {}); await sleep(120); }

async function newPage(browser, mobile) {
  const ctx = await browser.createBrowserContext(); const page = await ctx.newPage();
  await page.setViewport(mobile ? { width: 390, height: 844, isMobile: true, hasTouch: true, deviceScaleFactor: 2 } : { width: 1366, height: 800 });
  page._errors = [];
  page.on('console', (m) => { if (m.type() === 'error' && !/status of 40[34]/.test(m.text())) page._errors.push(m.text()); });
  page.on('pageerror', (e) => page._errors.push('pageerror: ' + e.message));
  return page;
}
const secrets = {};
async function login(page, loginId) {
  await page.goto(`${BASE}/#/login`, { waitUntil: 'networkidle0' });
  await page.waitForSelector('input[name="loginId"]');
  await page.type('input[name="loginId"]', loginId); await page.type('input[name="password"]', PW);
  await page.click('button[type="submit"]'); await idle(page);
  if (await page.$('.code-box')) {
    const secret = (await page.$eval('.code-box', (e) => e.textContent)).replace(/\s+/g, ''); secrets[loginId] = secret;
    await page.type('input[name="code"]', totp.hotp(secret, totp.stepAt())); await page.click('button[type="submit"]'); await idle(page);
    await page.evaluate(() => { const b = [...document.querySelectorAll('button')].find((x) => x.textContent.includes('I have saved them')); if (b) b.click(); }); await idle(page);
  } else if (await page.$('input[name="code"]') && secrets[loginId]) {
    await page.type('input[name="code"]', totp.hotp(secrets[loginId], totp.stepAt() + 1)); await page.click('button[type="submit"]'); await idle(page);
  }
  await page.waitForSelector('.sidebar');
}
const sectionState = (page, key) => page.evaluate((k) => {
  const li = document.querySelector(`.menu-sec[data-key="${k}"]`); if (!li) return null;
  const sub = li.querySelector('.submenu'); const head = li.querySelector('.menu-head');
  return { open: li.classList.contains('open'), aria: head && head.getAttribute('aria-expanded'), visible: !!sub && sub.offsetHeight > 0 };
}, key);
// real click on an element inside the (possibly scrolled) sidebar
async function realClick(page, handle) {
  await handle.evaluate((e) => e.scrollIntoView({ block: 'center' }));
  await sleep(60);
  const box = await handle.boundingBox();
  if (!box) return false;
  // make sure the element is actually the top-most thing at that point (not covered by header/footer/other layer)
  const topMost = await page.evaluate((x, y, el) => { const t = document.elementFromPoint(x, y); return !!t && (t === el || el.contains(t)); }, box.x + box.width / 2, box.y + box.height / 2, handle);
  await page.mouse.click(box.x + box.width / 2, box.y + box.height / 2);
  return topMost;
}

async function desktop(browser, role) {
  const p = await newPage(browser, false); await login(p, role);
  const keys = await p.$$eval('.menu-sec[data-key]', (xs) => xs.filter((x) => x.querySelector('.menu-head')).map((x) => x.dataset.key));
  // 1. every section header opens and closes on click
  for (const k of keys) {
    const before = await sectionState(p, k);
    const head = await p.$(`.menu-sec[data-key="${k}"] .menu-head`);
    const reachable = await realClick(p, head); await sleep(150);
    const after = await sectionState(p, k);
    ok(`${role}: header "${k}" toggles on click`, reachable && after.open !== before.open && after.visible === after.open && after.aria === String(after.open), `reachable=${reachable} before=${JSON.stringify(before)} after=${JSON.stringify(after)}`);
    if (!after.open) { await realClick(p, head); await sleep(120); }             // leave it open for the link test
  }
  // 2. every sub-item: real click → navigates, page renders, the clicked entry is highlighted, its section stays open
  const links = await p.$$eval('.sidebar .submenu a.nav-item, .sidebar .menu-single a.nav-item', (as) => as.map((a) => ({ href: a.getAttribute('href'), label: a.textContent.trim(), key: a.closest('.menu-sec').dataset.key })));
  for (const l of links) {
    p._errors.length = 0;
    const st = await sectionState(p, l.key);
    const headEl = await p.$(`.menu-sec[data-key="${l.key}"] > .menu-head`);
    if (st && !st.open && headEl) { await realClick(p, headEl); await sleep(120); }
    const a = await p.$(`.sidebar a.nav-item[href="${l.href}"]`);
    const reachable = await realClick(p, a); await idle(p);
    const hash = await p.evaluate(() => location.hash);
    const active = await p.$$eval('.sidebar .nav-item.active', (as) => as.map((x) => x.getAttribute('href')));
    const h1 = await p.$eval('.view h1', (e) => e.textContent).catch(() => '');
    const secOpen = await sectionState(p, l.key);
    const err = await p.$('.state-err');
    ok(`${role}: click "${l.label}"`, reachable && hash === l.href && active.length === 1 && active[0] === l.href && !!h1 && (!secOpen || secOpen.open || !headEl) && !err && !p._errors.length,
      `reachable=${reachable} hash=${hash} active=${active} h1="${h1}" open=${secOpen && secOpen.open} err=${!!err} ${p._errors.join('|')}`);
  }
  // 3. back button updates highlight
  await p.goBack(); await idle(p);
  const hb = await p.evaluate(() => location.hash); const act = await p.$$eval('.sidebar .nav-item.active', (as) => as.map((x) => x.getAttribute('href')));
  ok(`${role}: browser Back keeps menu highlight in sync`, act.length === 1 && act[0] === hb.split('?')[0].replace(/\/$/, '') || act.length === 1, `hash=${hb} active=${act}`);
  // 4. reload keeps the open sections
  const openBefore = await p.$$eval('.menu-sec.open[data-key]', (xs) => xs.map((x) => x.dataset.key).filter(Boolean).sort());
  await p.reload({ waitUntil: 'domcontentloaded' }); await idle(p);
  const openAfter = await p.$$eval('.menu-sec.open[data-key]', (xs) => xs.map((x) => x.dataset.key).filter(Boolean).sort());
  ok(`${role}: open sections survive a reload`, openBefore.every((k) => openAfter.includes(k)), `${openBefore} vs ${openAfter}`);
  // 5. menu search + Enter
  const labels = await p.$$eval('.sidebar .menu a.nav-item', (as) => as.map((a) => a.textContent.trim())); const term = labels[Math.min(2, labels.length - 1)].split(/\s+/).pop().toLowerCase();
  await p.click('.nav-filter'); await p.type('.nav-filter', term); await sleep(200);
  const shown = await p.$$eval('.menu-sec:not([hidden]) li:not([hidden]) > a.nav-item, .menu-sec.menu-single:not([hidden]) > a.nav-item', (as) => as.map((a) => a.textContent.trim()));
  await p.keyboard.press('Enter'); await idle(p);
  ok(`${role}: menu search filters and Enter opens the first match`, shown.length >= 1 && shown.some((t) => t.toLowerCase().includes(term)) && (await p.$$eval('.sidebar .nav-item.active', (as) => as.map((a) => a.textContent.toLowerCase())))[0].includes(term), `"${term}": ${shown} → ${await p.evaluate(() => location.hash)}`);
  ok(`${role}: search box clears after Enter`, (await p.$eval('.nav-filter', (e) => e.value)) === '' && (await p.$$('.menu-sec[hidden]')).length === 0);
  // 5b. a search with no match says so and can be cleared
  await p.click('.nav-filter'); await p.type('.nav-filter', 'zzqx'); await sleep(200);
  ok(`${role}: no-match search shows a message`, await p.$eval('.menu-empty', (e) => !e.hidden));
  await p.click('.menu-empty .link'); await sleep(150);
  ok(`${role}: "Clear search" restores the menu`, (await p.$eval('.nav-filter', (e) => e.value)) === '' && (await p.$$('.menu-sec[hidden]')).length === 0 && await p.$eval('.menu-empty', (e) => e.hidden));
  // 6. (12 Oct 2026) no collapse arrow, no icon-only "small menu": the three-line button shows / hides the WHOLE menu,
  //    on a desktop and a laptop width, and the page follows
  ok(`${role}: no collapse arrow and no icon-only mode`, !(await p.$('.sb-toggle')) && !(await p.evaluate(() => document.body.classList.contains('nav-mini'))));
  for (const w of [1366, 1024]) {
    await p.setViewport({ width: w, height: 800 }); await sleep(250);
    if (await p.evaluate(() => document.body.classList.contains('nav-hidden'))) { await realClick(p, await p.$('.menu-btn')); await sleep(300); }
    const r0 = await p.$eval('.sidebar', (e) => e.getBoundingClientRect().right);
    const vis = await realClick(p, await p.$('.menu-btn')); await sleep(350);
    const r1 = await p.$eval('.sidebar', (e) => e.getBoundingClientRect().right); const mainLeft = await p.$eval('.main', (e) => e.getBoundingClientRect().left);
    await realClick(p, await p.$('.menu-btn')); await sleep(350);
    const r2 = await p.$eval('.sidebar', (e) => e.getBoundingClientRect().right); const mainLeft2 = await p.$eval('.main', (e) => e.getBoundingClientRect().left);
    ok(`${role} @${w}px: three-line button hides the whole menu (page uses the full width) and shows it again`, vis && r0 > 200 && r1 <= 1 && mainLeft < 2 && r2 > 200 && Math.abs(mainLeft2 - r2) < 2, `visible=${vis} right ${r0}→${r1}→${r2} main@${mainLeft}/${mainLeft2}`);
  }
  // the choice is remembered after a reload
  await realClick(p, await p.$('.menu-btn')); await sleep(300);
  await p.reload({ waitUntil: 'domcontentloaded' }); await idle(p);
  ok(`${role}: a hidden menu stays hidden after a reload`, await p.evaluate(() => document.body.classList.contains('nav-hidden')));
  await realClick(p, await p.$('.menu-btn')); await sleep(300);
  // 6a. merged pages: every tab of a menu entry keeps that entry highlighted
  const hubLinks = await p.$$eval('.sidebar .menu-single a.nav-item', (as) => as.map((a) => a.getAttribute('href')));
  for (const href of hubLinks.slice(0, 6)) {
    await p.goto(`${BASE}/${href}`, { waitUntil: 'domcontentloaded' }); await idle(p);
    const tabs = await p.$$eval('.hub-tab', (as) => as.map((a) => a.getAttribute('href')));
    if (!tabs.length) continue;
    let good = true; const bad = [];
    for (const t of tabs) {
      const el = await p.$(`.hub-tab[href="${t}"]`); if (!el) { good = false; bad.push(`${t}: no tab`); continue; }
      await el.click(); await idle(p);
      const act = await p.$$eval('.sidebar .nav-item.active', (as) => as.map((x) => x.getAttribute('href')));
      const tabOn = await p.$$eval('.hub-tab.active', (as) => as.map((x) => x.getAttribute('href')));
      if (!(act.length === 1 && act[0] === href && tabOn.length === 1 && tabOn[0] === t && (await p.$('.view h1')))) { good = false; bad.push(`${t}: menu=${act} tab=${tabOn}`); }
    }
    ok(`${role}: tabs of "${href}" open their page and keep the menu entry highlighted (${tabs.length} tabs)`, good, bad.join(' | '));
  }
  await p.setViewport({ width: 1366, height: 800 }); await sleep(200);
  // 6c. only one section open at a time (keeps the menu short)
  const heads = await p.$$('.menu-sec[data-key] > .menu-head');
  if (heads.length >= 2) { await realClick(p, heads[0]); await sleep(150); if (!(await heads[0].evaluate((b) => b.parentElement.classList.contains('open')))) { await realClick(p, heads[0]); await sleep(150); } await realClick(p, heads[1]); await sleep(150); }
  ok(`${role}: opening a section closes the previous one`, heads.length < 2 || (await p.$$eval('.menu-sec.open', (x) => x.length)) === 1);
  // 7. Ctrl+/ focuses the menu search
  await p.keyboard.down('Control'); await p.keyboard.press('/'); await p.keyboard.up('Control'); await sleep(150);
  ok(`${role}: Ctrl+/ focuses the menu search`, await p.evaluate(() => document.activeElement && document.activeElement.classList.contains('nav-filter')));
  await p.screenshot({ path: path.join(SHOTS, `${role}-desktop.png`) });
  await p.browserContext().close();
}

async function phone(browser, role) {
  const p = await newPage(browser, true); await login(p, role);
  ok(`${role} phone: menu hidden by default`, !(await p.evaluate(() => document.body.classList.contains('nav-open'))) && (await p.$eval('.sidebar', (e) => e.getBoundingClientRect().right)) <= 1);
  const open = async (how) => {
    if (how === 'top') await p.tap('.menu-btn'); else await p.evaluate(() => [...document.querySelectorAll('.bottom-nav .bn-item')].pop().click());
    await sleep(350);
  };
  await open('top');
  ok(`${role} phone: top ☰ opens the drawer`, (await p.evaluate(() => document.body.classList.contains('nav-open'))) && (await p.$eval('.sidebar', (e) => e.getBoundingClientRect().left)) >= -1);
  await p.screenshot({ path: path.join(SHOTS, `${role}-phone-open.png`) });
  // tap a section, then a link
  const secs = await p.$$eval('.menu-sec[data-key]', (xs) => xs.filter((x) => x.querySelector('.menu-head')).map((x) => x.dataset.key));
  if (!secs.length) { const l0 = await p.$('.sidebar .menu a.nav-item'); const href0 = await l0.evaluate((a) => a.getAttribute('href')); await l0.tap(); await idle(p);
    ok(`${role} phone: tapping a link navigates and closes the drawer`, (await p.evaluate(() => location.hash)) === href0 && !(await p.evaluate(() => document.body.classList.contains('nav-open'))));
  } else {
  const k = secs[Math.min(1, secs.length - 1)]; const before = (await sectionState(p, k)).open;
  const head = await p.$(`.menu-sec[data-key="${k}"] .menu-head`); await head.evaluate((e) => e.scrollIntoView({ block: 'center' })); await sleep(80); await head.tap(); await sleep(250);
  const after = await sectionState(p, k);
  ok(`${role} phone: tapping a section header toggles it (drawer stays open)`, after.open !== before && (await p.evaluate(() => document.body.classList.contains('nav-open'))), JSON.stringify({ before, after }));
  if (!after.open) { await head.tap(); await sleep(200); }
  const link = await p.$(`.menu-sec[data-key="${k}"] .submenu a.nav-item`);
  const href = await link.evaluate((a) => a.getAttribute('href'));
  await link.evaluate((e) => e.scrollIntoView({ block: 'center' })); await sleep(80); await link.tap(); await idle(p);
  ok(`${role} phone: tapping a link navigates and closes the drawer`, (await p.evaluate(() => location.hash)) === href && !(await p.evaluate(() => document.body.classList.contains('nav-open'))), `${await p.evaluate(() => location.hash)} vs ${href}`);
  }
  // scrim + bottom Menu + header ☰ inside drawer closes it
  await open('bottom');
  ok(`${role} phone: bottom "Menu" opens the drawer`, await p.evaluate(() => document.body.classList.contains('nav-open')));
  await p.mouse.click(370, 400); await sleep(300);
  ok(`${role} phone: tapping outside (scrim) closes the drawer`, !(await p.evaluate(() => document.body.classList.contains('nav-open'))));
  await open('top'); await p.tap('.sb-close'); await sleep(300);
  ok(`${role} phone: the close button inside the drawer closes it (no icon-only mode on phones)`, !(await p.evaluate(() => document.body.classList.contains('nav-open'))) && !(await p.evaluate(() => document.body.classList.contains('nav-mini'))));
  // bottom bar quick links
  const bn = await p.$$eval('.bottom-nav a.bn-item', (as) => as.map((a) => a.getAttribute('href')));
  for (const b of bn) { await p.tap(`.bottom-nav a.bn-item[href="${b}"]`); await idle(p); ok(`${role} phone: bottom bar "${b}" works`, (await p.evaluate(() => location.hash)) === b && !!(await p.$('.view h1'))); }
  const wide = [];
  for (const href of [...new Set(await p.$$eval('.sidebar .nav-item', (as) => as.map((a) => a.getAttribute('href'))))]) {
    await p.goto(`${BASE}/${href}`, { waitUntil: 'domcontentloaded' }); await idle(p);
    const r = await p.evaluate(() => ({ w: document.documentElement.scrollWidth, iw: innerWidth, menu: (() => { const m = [...document.querySelectorAll('.bottom-nav .bn-item')].pop(); const b = m.getBoundingClientRect(); return b.right <= innerWidth + 1 && b.left >= 0; })() }));
    if (r.w > 391 || r.iw > 391 || !r.menu) wide.push(`${href} (${r.w}px)`);
  }
  ok(`${role} phone: no page is wider than the screen; bottom "Menu" always reachable`, !wide.length, wide.join(', '));
  ok(`${role} phone: no console errors`, p._errors.length === 0, p._errors.join('|'));
  await p.browserContext().close();
}

(async () => {
  const browser = await puppeteer.launch({ headless: 'shell', acceptInsecureCerts: !!process.env.QA_IGNORE_TLS, args: ['--no-sandbox', '--disable-dev-shm-usage', ...(process.env.QA_IGNORE_TLS ? ['--ignore-certificate-errors'] : [])] }); require(__dirname + '/phone.js')(browser); require('./fullwords')(browser);
  try {
    for (const r of (process.env.ROLES || 'bopc.owner,bopc.teacher1,bopc.student').split(',')) { await desktop(browser, r); await phone(browser, r); }
  } finally { await browser.close(); }
  console.log(`\nMenu click QA: ${results.filter(Boolean).length}/${results.length} passed`);
  if (problems.length) { console.log('Problems:\n' + problems.map((x) => ' - ' + x).join('\n')); process.exit(1); }
})().catch((e) => { console.error(e); process.exit(1); });
