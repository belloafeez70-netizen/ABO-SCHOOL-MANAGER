'use strict';
// Single-file build QA: (1) opened from disk it shows how to reach the portal, with the strict meta CSP intact and no
// errors; (2) served as the site's index.html behind the Netlify edge proxy it is the full working app.
// Usage: BASE_URL=https://localhost:8890 QA_IGNORE_TLS=1 SINGLE_FILE=/home/user/abo-school-manager.html node server/test/e2e/single.qa.js
const puppeteer = require('puppeteer');
const path = require('node:path');
const fs = require('node:fs');
const BASE = process.env.BASE_URL || 'https://localhost:8890';
const FILE = process.env.SINGLE_FILE || path.join(__dirname, '../../../dist/single/index.html');
const SHOTS = process.env.SHOTS || path.join(__dirname, '../../../docs/screenshots');
const PW = process.env.DEMO_PASSWORD || 'Demo#School2026';
fs.mkdirSync(SHOTS, { recursive: true });
let pass = 0; const bad = [];
const ok = (n, c, x = '') => { if (c) pass++; else bad.push(`${n} ${x}`); console.log(`${c ? '✔' : '✖'} ${n}${!c && x ? ' — ' + x : ''}`); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  const browser = await puppeteer.launch({ headless: 'shell', acceptInsecureCerts: !!process.env.QA_IGNORE_TLS, args: ['--no-sandbox', '--disable-dev-shm-usage', ...(process.env.QA_IGNORE_TLS ? ['--ignore-certificate-errors'] : [])] }); require(__dirname + '/phone.js')(browser); require('./fullwords')(browser);
  const errors = [];
  const page = async (mobile) => { const c = await browser.createBrowserContext(); const p = await c.newPage(); await p.setViewport(mobile ? { width: 390, height: 844, isMobile: true, hasTouch: true, deviceScaleFactor: 2 } : { width: 1366, height: 900 });
    p.on('console', (m) => { if (m.type() === 'error' && !/status of 40[0-9]/.test(m.text())) errors.push(m.text()); }); p.on('pageerror', (e) => errors.push('pageerror ' + e.message)); return p; };
  try {
    const html = fs.readFileSync(FILE, 'utf8');
    ok('one self-contained file: no external scripts, styles or images', !/<script[^>]+src=|<link[^>]+stylesheet|src="\/assets/.test(html));
    ok('strict CSP meta with SHA-256 hashes, no unsafe-inline', /script-src 'sha256-/.test(html) && !/unsafe-inline|unsafe-eval/.test(html));
    ok('no secrets or database URLs inside the file', !/postgres:\/\/|sk_(live|test)_|PRIVATE KEY|dev_password/.test(html));
    const f = await page(false);
    await f.goto('file://' + FILE, { waitUntil: 'load' }); await sleep(600);
    const t = await f.evaluate(() => document.body.innerText);
    ok('opened from disk: explains that the portal must be opened from its web address', /Open the school portal/.test(t) && /online edition/i.test(t), t.slice(0, 120));
    await f.screenshot({ path: path.join(SHOTS, 'single-file-offline.png') });

    const s = await page(false);
    await s.goto(`${BASE}/#/s/bopc-demo`, { waitUntil: 'networkidle0' }); await s.waitForSelector('.portal-tab');
    ok('served by Netlify: single file renders the portal sign-in', (await s.$$('.portal-tab')).length === 3);
    await s.click('.portal-tab[data-portal="staff"]'); await s.type('input[name="loginId"]', 'bopc.teacher1'); await s.type('input[name="password"]', PW);
    await s.click('button[type="submit"]'); await s.waitForNetworkIdle({ idleTime: 400, timeout: 15000 }).catch(() => {});
    ok('staff sign-in through the proxy works', /Dashboard/.test(await s.evaluate(() => document.body.innerText)));
    const routes = ['#/lesson-notes', '#/lesson-notes/new', '#/cbt/bank', '#/results', '#/broadsheet', '#/attendance', '#/students', '#/announcements'];
    for (const r of routes) {
      await s.goto(`${BASE}/${r}`, { waitUntil: 'networkidle0' }); await sleep(300);
      const txt = await s.evaluate(() => (document.querySelector('main') || document.body).innerText);
      ok(`page ${r} loads inside the single file`, txt.length > 40 && !/Could not load this page|undefined|NaN/.test(txt), txt.slice(0, 80));
    }
    await s.screenshot({ path: path.join(SHOTS, 'single-file-served.png') });
    const m = await page(true);
    await m.goto(`${BASE}/#/s/bopc-demo`, { waitUntil: 'networkidle0' }); await m.waitForSelector('.portal-tab');
    await m.click('.portal-tab[data-portal="student"]'); await m.type('input[name="loginId"]', 'BOPC/0001'); await m.type('input[name="password"]', PW);
    await m.click('button[type="submit"]'); await m.waitForNetworkIdle({ idleTime: 400, timeout: 15000 }).catch(() => {});
    await m.goto(`${BASE}/#/lesson-notes`, { waitUntil: 'networkidle0' }); await sleep(300);
    ok('student (admission number) on a phone reads lesson notes', /Parts of Speech/.test(await m.evaluate(() => document.body.innerText)));
    ok('phone: no horizontal overflow', await m.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1));
    // no server behind the page → a clear explanation instead of a sign-in form that can never work
    const sb = await page(false);
    // like a file-viewer preview: the file's own HTML inside a sandboxed frame (opaque origin, no storage, no cookies)
    await sb.setContent('<iframe id="pv" sandbox="allow-scripts" style="width:1300px;height:860px;border:0"></iframe>');
    await sb.evaluate((doc) => { document.getElementById('pv').srcdoc = doc; }, html); await sleep(2500);
    const fr = sb.frames().find((x) => x !== sb.mainFrame());
    ok('inside a sandboxed preview (storage + cookies blocked): shows "Open the school portal", not a broken sign-in', fr && /Open the school portal/.test(await fr.evaluate(() => document.body.innerText)));
    if (process.env.NOAPI_BASE_URL) {
      const na = await page(false);
      await na.goto(`${process.env.NOAPI_BASE_URL}/#/login`, { waitUntil: 'networkidle0' }); await sleep(500);
      const tt = await na.evaluate(() => document.body.innerText);
      ok('Netlify site whose API is not connected yet: explains instead of failing at sign-in', /Open the school portal/.test(tt) && /cannot be reached/.test(tt), tt.slice(0, 120));
      await na.screenshot({ path: path.join(SHOTS, 'single-file-no-server.png') });
    }
  } catch (e) { bad.push('crash ' + e.stack); console.error(e); }
  await browser.close();
  ok('no console / CSP / page errors', errors.filter((e) => !/Failed to load resource|503/.test(e)).length === 0, errors.slice(0, 4).join(' | '));
  console.log(`\nSingle-file QA: ${pass}/${pass + bad.length} passed`); if (bad.length) { console.log(bad.join('\n')); process.exit(1); }
})();
