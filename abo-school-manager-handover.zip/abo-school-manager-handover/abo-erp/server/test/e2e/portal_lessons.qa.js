'use strict';
// Website-parity browser QA: portal tabs on the sign-in page, admission-number (student) and phone (parent) sign-in
// from the school's own page, first sign-in with an access code typed as the password, and the full Lesson Notes
// cycle through the real UI (teacher writes + submits → head approves → student and parent read it).
// Usage: BASE_URL=http://127.0.0.1:8080 SHOTS=/path node server/test/e2e/portal_lessons.qa.js
const puppeteer = require('puppeteer');
const path = require('node:path');
const fs = require('node:fs');
const crypto = require('node:crypto');
const { Client } = require('pg');

const BASE = process.env.BASE_URL || 'http://127.0.0.1:8080';
const SHOTS = process.env.SHOTS || path.join(__dirname, '../../../docs/screenshots');
const PW = process.env.DEMO_PASSWORD || 'Demo#School2026';
const DB = process.env.QA_DATABASE_URL || 'postgres://postgres@127.0.0.1:5432/abo_erp';
fs.mkdirSync(SHOTS, { recursive: true });
const problems = []; let passed = 0;
const ok = (name, cond, extra = '') => { if (cond) passed++; else problems.push(`${name} ${extra}`); process.stdout.write(`${cond ? '✔' : '✖'} ${name}${extra && !cond ? ' — ' + extra : ''}\n`); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function newPage(browser, errors, mobile = false) {
  const ctx = await browser.createBrowserContext(); const page = await ctx.newPage();
  await page.setViewport(mobile ? { width: 390, height: 844, isMobile: true, hasTouch: true, deviceScaleFactor: 2 } : { width: 1366, height: 900 });
  page.on('console', (m) => { if (m.type() === 'error' && !/status of 40[0-9]/.test(m.text())) errors.push(m.text()); });
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('response', (r) => { if (r.url().includes('/api/v1/') && r.status() >= 500) errors.push(`HTTP ${r.status()} ${r.url()}`); });
  return page;
}
async function idle(page) { await page.waitForNetworkIdle({ idleTime: 300, timeout: 15000 }).catch(() => {}); await sleep(150); }
const text = (page) => page.evaluate(() => document.body.innerText);
const clickText = (page, sel, t) => page.evaluate((s, x) => { const b = [...document.querySelectorAll(s)].reverse().find((e) => e.textContent.trim().includes(x) && !e.disabled); if (b) { b.click(); return true; } return false; }, sel, t);
const api = (page, url) => page.evaluate(async (u) => { const r = await fetch('/api/v1' + u, { credentials: 'same-origin' }); return { status: r.status, body: await r.json().catch(() => null) }; }, url);
const shot = (page, f) => page.screenshot({ path: path.join(SHOTS, f) });
async function signIn(page, url, tab, id, pw = PW) {
  await page.goto(`${BASE}/${url}`, { waitUntil: 'networkidle0' });
  await page.waitForSelector('.portal-tab');
  if (tab) { await page.click(`.portal-tab[data-portal="${tab}"]`); await sleep(100); }
  await page.type('input[name="loginId"]', id); await page.type('input[name="password"]', pw);
  await page.click('button[type="submit"]'); await idle(page);
}
const strayText = (page) => page.evaluate(() => /\b(undefined|null|NaN|\[object Object\])\b/.test(document.querySelector('main') ? document.querySelector('main').innerText : ''));

(async () => {
  const browser = await puppeteer.launch({ headless: 'shell', acceptInsecureCerts: !!process.env.QA_IGNORE_TLS, args: ['--no-sandbox', '--disable-dev-shm-usage', ...(process.env.QA_IGNORE_TLS ? ['--ignore-certificate-errors'] : [])] }); require(__dirname + '/phone.js')(browser); require('./fullwords')(browser);
  const errors = [];
  const db = new Client({ connectionString: DB }); await db.connect();
  try {
    // ── 1. sign-in page: three portal tabs change the labels ──
    const p = await newPage(browser, errors);
    await p.goto(`${BASE}/#/s/bopc-demo`, { waitUntil: 'networkidle0' }); await p.waitForSelector('.portal-tab');
    const tabs = await p.$$eval('.portal-tab', (b) => b.map((x) => x.textContent.trim()));
    ok('sign-in page shows Staff / Student / Parent tabs', JSON.stringify(tabs) === JSON.stringify(['Staff', 'Student', 'Parent']), JSON.stringify(tabs));
    await p.click('.portal-tab[data-portal="student"]'); await sleep(100);
    const lbl = await p.$eval('.field[data-name="loginId"] label', (e) => e.textContent);
    const pwl = await p.$eval('.field[data-name="password"] label', (e) => e.textContent);
    ok('Student tab asks for admission number and "password or access code"', /Admission number/.test(lbl) && /access code/.test(pwl), `${lbl} | ${pwl}`);
    await shot(p, 'portal-login-student.png');
    await p.click('.portal-tab[data-portal="parent"]'); await sleep(100);
    ok('Parent tab asks for phone number', /Phone number/.test(await p.$eval('.field[data-name="loginId"] label', (e) => e.textContent)));
    await p.goto(`${BASE}/#/login?portal=parent`, { waitUntil: 'networkidle0' }); await p.waitForSelector('.portal-tab.active');
    ok('?portal=parent deep link preselects the Parent tab (for links from the school website)', (await p.$eval('.portal-tab.active', (e) => e.dataset.portal)) === 'parent');

    // ── 2. student signs in with ADMISSION NUMBER on the school page ──
    const st = await newPage(browser, errors);
    await signIn(st, '#/s/bopc-demo', 'student', 'BOPC/0001');
    ok('student signs in with admission number BOPC/0001', (await api(st, '/auth/me')).body?.user?.loginId === 'bopc.student');
    await st.goto(`${BASE}/#/lesson-notes`, { waitUntil: 'networkidle0' }); await idle(st);
    // Lesson Notes is a tab of the pupil's "Learning" menu entry (Notes & Videos · Live Classes · Lesson Notes)
    ok('student menu has Lesson Notes (under Learning)', await st.evaluate(() => [...document.querySelectorAll('.sidebar a')].some((a) => /Learning/.test(a.textContent) && a.getAttribute('href') === '#/materials')));
    ok('student sees the approved demo note', (await text(st)).includes('Parts of Speech: Nouns'));
    ok('student does not see drafts / submitted notes', !(await text(st)).includes('Living and Non-living'));
    await clickText(st, 'a.list-item', 'Parts of Speech'); await idle(st);
    ok('student opens the printable note', /lesson note/i.test(await text(st)) && /behavioural objectives/i.test(await text(st)));
    ok('student view hides reviewer workflow', !(await text(st)).includes('Approved by') && !(await st.$('.alert')));
    ok('no stray null/undefined on the note page', !(await strayText(st)));

    // ── 3. parent signs in with PHONE NUMBER (+234 format) ──
    const pa = await newPage(browser, errors, true);
    await signIn(pa, '#/s/bopc-demo', 'parent', '+234 803 000 0001');
    ok('parent signs in with phone number on a phone screen', (await api(pa, '/auth/me')).body?.user?.loginId === 'bopc.parent');
    await pa.goto(`${BASE}/#/lesson-notes`, { waitUntil: 'networkidle0' }); await idle(pa);
    ok('parent sees children’s lesson notes', (await text(pa)).includes('Parts of Speech: Nouns'));
    ok('phone layout has no horizontal overflow', await pa.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1));
    await shot(pa, 'portal-parent-lessons-phone.png');

    // ── 4. first sign-in with the ACCESS CODE typed as the password ──
    const code = 'QATST23456';
    await db.query("UPDATE users SET password_hash = NULL, status = 'pending', access_code_hash = $2, access_code_expires_at = now() + interval '1 day', failed_attempts = 0, locked_until = NULL WHERE login_id = $1",
      ['gfa.student', crypto.createHash('sha256').update(code).digest('hex')]);
    const nw = await newPage(browser, errors);
    await signIn(nw, '#/s/greenfield-demo', 'student', 'GFA/0001', 'QATST-23456');
    ok('access code in the password box opens "Create your password"', (await text(nw)).includes('Create your password'), (await text(nw)).slice(0, 200));
    await shot(nw, 'portal-create-password.png');
    await nw.type('input[name="newPassword"]', PW); await nw.type('input[name="confirm"]', PW + 'x');
    await nw.click('button[type="submit"]'); await idle(nw);
    ok('mismatched confirmation is caught before submitting', (await text(nw)).includes('do not match'));
    await nw.evaluate(() => { document.querySelector('input[name="confirm"]').value = ''; });
    await nw.type('input[name="confirm"]', PW); await nw.click('button[type="submit"]'); await idle(nw);
    ok('password created and signed straight in', (await api(nw, '/auth/me')).body?.user?.loginId === 'gfa.student');

    // ── 5. teacher writes and submits a lesson note through the editor ──
    const t = await newPage(browser, errors);
    await signIn(t, '#/s/bopc-demo', 'staff', 'bopc.teacher1');
    await t.goto(`${BASE}/#/lesson-notes/new`, { waitUntil: 'networkidle0' }); await idle(t);
    const cls = await t.$$eval('.field[data-name="classId"] option', (o) => o.map((x) => [x.value, x.textContent]).filter((x) => x[0]));
    ok('editor offers only the teacher’s assigned classes', cls.length > 0, JSON.stringify(cls));
    await t.select('.field[data-name="classId"] select', cls[0][0]); await sleep(100);
    const subs = await t.$$eval('.field[data-name="subjectId"] option', (o) => o.map((x) => [x.value, x.textContent]).filter((x) => x[0]));
    ok('subjects are filtered to that class', subs.length > 0 && !subs.some((s) => s[1] === 'Mathematics'), JSON.stringify(subs));
    await t.select('.field[data-name="subjectId"] select', subs.find((s) => s[1] === 'English Language')[0]);
    await t.select('.field[data-name="week"] select', '2');
    await t.type('.field[data-name="topic"] input', 'Pronouns');
    await t.type('.field[data-name="objectives"] textarea', 'Pupils should be able to use personal pronouns correctly.');
    await t.type('.field[data-name="content"] textarea', 'A pronoun is a word used instead of a noun. Examples: I, you, he, she, it, we, they.');
    await t.type('.field[data-name="evaluation"] textarea', 'Replace the nouns with pronouns.');
    await shot(t, 'lesson-editor.png');
    await clickText(t, 'button', 'Save & submit for review'); await idle(t);
    ok('teacher submits the note and lands on it', /#\/lesson-notes\/[0-9a-f-]{36}$/.test(t.url()) && (await text(t)).includes('waiting for review'), t.url());
    const noteId = t.url().split('/').pop();

    // ── 6. head approves from the review queue ──
    const hd = await newPage(browser, errors);
    await signIn(hd, '#/s/bopc-demo', 'staff', 'demo.proprietor');
    await hd.goto(`${BASE}/#/lesson-notes?scope=review`, { waitUntil: 'networkidle0' }); await idle(hd);
    ok('review queue lists the submitted note', (await text(hd)).includes('Pronouns'));
    ok('menu highlights Lessons & Materials and the Review Queue tab', await hd.evaluate(() => { const a = document.querySelector('.sidebar a[aria-current="page"], .sidebar a.active'); const t = document.querySelector('.hub-tab.active'); return !!a && /Lesson/.test(a.textContent) && !!t && t.textContent.includes('Review'); }));
    await hd.goto(`${BASE}/#/lesson-notes/${noteId}`, { waitUntil: 'networkidle0' }); await idle(hd);
    await clickText(hd, 'button', 'Approve'); await sleep(250);
    await clickText(hd, '.modal button', 'Approve'); await idle(hd);
    ok('head approves; banner shows it is shared with the class', (await text(hd)).includes('Visible to students and parents'));
    await shot(hd, 'lesson-detail-approved.png');
    await hd.goto(`${BASE}/#/lesson-notes/summary`, { waitUntil: 'networkidle0' }); await idle(hd);
    ok('coverage report renders with totals and gaps', /notes written/i.test(await text(hd)) && /assigned subjects with no lesson note/i.test(await text(hd)));
    ok('no stray null/undefined on the coverage report', !(await strayText(hd)));
    await shot(hd, 'lesson-coverage.png');

    // ── 7. the student now sees the new note ──
    await st.goto(`${BASE}/#/lesson-notes`, { waitUntil: 'networkidle0' }); await idle(st);
    ok('student sees the newly approved note', (await text(st)).includes('Week 2 · Pronouns'));

    // ── 8. wrong credentials on the student tab give a clear message, no crash ──
    const bad = await newPage(browser, errors);
    await signIn(bad, '#/s/bopc-demo', 'student', 'BOPC/9999', 'nope-nope');
    ok('unknown admission number shows the generic error', (await text(bad)).includes('Invalid Login ID or password'));
  } catch (e) { problems.push('crash: ' + e.stack); console.error(e); }
  finally {
    // restore the demo account used for the access-code test
    await db.query("UPDATE users SET access_code_hash = NULL, access_code_expires_at = NULL, status = 'active' WHERE login_id = 'gfa.student'").catch(() => {});
    await db.end(); await browser.close();
  }
  ok('no console / server errors', errors.length === 0, errors.slice(0, 5).join(' | '));
  console.log(`\n${passed}/${passed + problems.length} checks passed`);
  if (problems.length) { console.log(problems.join('\n')); process.exit(1); }
})();
