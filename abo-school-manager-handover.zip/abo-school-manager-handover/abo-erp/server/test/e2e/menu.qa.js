'use strict';
// Menu QA: for each role, open EVERY entry of the new tree menu in headless Chrome and assert that it renders
// without console errors, failed API calls (5xx), error states or "access denied" pages (a visible menu entry the
// server refuses = a permission mismatch), and that the clicked entry is highlighted. Also exercises the school
// approval → branded sign-in page flow (logo upload, colour, /#/s/<slug>).
// Usage: BASE_URL=http://127.0.0.1:8080 SHOTS=/path node server/test/e2e/menu.qa.js
const puppeteer = require('puppeteer');
const path = require('node:path');
const fs = require('node:fs');
const totp = require('../../src/security/totp');

const BASE = process.env.BASE_URL || 'http://127.0.0.1:8080';
const SHOTS = process.env.SHOTS || path.join(__dirname, '../../../docs/screenshots');
const PW = process.env.DEMO_PASSWORD || 'Demo#School2026';
const LOGO = path.join(__dirname, '../../../docs/screenshots/demo-logo.png');
fs.mkdirSync(SHOTS, { recursive: true });
const results = []; const problems = [];
const ok = (name, cond, extra = '') => { results.push({ name, ok: !!cond }); if (!cond) problems.push(`${name} ${extra}`); process.stdout.write(`${cond ? '✔' : '✖'} ${name}${extra && !cond ? ' — ' + extra : ''}\n`); };

async function newPage(browser, { mobile = false } = {}) {
  const ctx = await browser.createBrowserContext();
  const page = await ctx.newPage();
  await page.setViewport(mobile ? { width: 390, height: 844, deviceScaleFactor: 2, isMobile: true, hasTouch: true } : { width: 1440, height: 900 });
  page._errors = [];
  page.on('console', (m) => { if (m.type() === 'error' && !/status of 40[34]/.test(m.text())) page._errors.push(m.text()); });
  page.on('pageerror', (e) => page._errors.push('pageerror: ' + e.message));
  page.on('response', (r) => { if (r.url().includes('/api/v1/') && r.status() >= 500) page._errors.push(`HTTP ${r.status()} ${r.url()}`); });
  return page;
}
async function waitIdle(page) { await page.waitForNetworkIdle({ idleTime: 300, timeout: 15000 }).catch(() => {}); await new Promise((r) => setTimeout(r, 150)); }
const secrets = {};
async function login(page, loginId, start = '#/login') {
  await page.goto(`${BASE}/${start}`, { waitUntil: 'networkidle0' });
  await page.waitForSelector('input[name="loginId"]', { timeout: 10000 });
  await page.type('input[name="loginId"]', loginId); await page.type('input[name="password"]', PW);
  await page.click('button[type="submit"]'); await waitIdle(page);
  if (await page.$('.code-box')) {
    const secret = (await page.$eval('.code-box', (e) => e.textContent)).replace(/\s+/g, ''); secrets[loginId] = secret;
    await page.type('input[name="code"]', totp.hotp(secret, totp.stepAt()));
    await page.click('button[type="submit"]'); await waitIdle(page);
    for (const b of await page.$$('button')) { if ((await b.evaluate((e) => e.textContent)).includes('I have saved them')) { await b.click(); break; } }
    await waitIdle(page);
  } else if (await page.$('input[name="code"]') && secrets[loginId]) {
    await page.type('input[name="code"]', totp.hotp(secrets[loginId], totp.stepAt() + 1));
    await page.click('button[type="submit"]'); await waitIdle(page);
  }
}
const shot = (page, file) => page.screenshot({ path: path.join(SHOTS, file), fullPage: false });

async function crawlMenu(page, role, shots = {}) {
  const links = await page.$$eval('.sidebar .nav-item', (as) => as.map((a) => ({ href: a.getAttribute('href'), label: a.textContent.trim() })));
  ok(`${role}: menu has entries (${links.length})`, links.length > 3);
  const seen = new Set();
  // 12 Oct 2026: merged pages are tabs at the top of a page — visit every tab too (the menu entry stays highlighted)
  const queue = links.map((l) => ({ ...l, owner: l.href }));
  for (let qi = 0; qi < queue.length; qi++) {
    const l = queue[qi];
    if (seen.has(l.href)) continue; seen.add(l.href);
    page._errors.length = 0;
    await page.goto(`${BASE}/${l.href}`, { waitUntil: 'domcontentloaded' }); await waitIdle(page);
    const err = await page.$('.state-err:not(.state-denied)'); const denied = await page.$('.state-denied');
    const active = await page.$$eval('.sidebar .nav-item.active', (as) => as.map((a) => a.getAttribute('href')));
    const h1 = await page.$eval('.view h1', (e) => e.textContent).catch(() => '');
    const junk = await page.$eval('.view', (e) => (e.innerText.match(/\b(null|undefined|NaN)\b/) || [''])[0]).catch(() => '');
    ok(`${role}: ${l.label} (${l.href})`, !err && !denied && page._errors.length === 0 && active.includes(l.owner) && !!h1 && !junk,
      `${page._errors.join(' | ')}${err ? ' error-state' : ''}${denied ? ' ACCESS-DENIED' : ''}${active.includes(l.owner) ? '' : ` active=${active}`}${h1 ? '' : ' no-h1'}${junk ? ` shows "${junk}"` : ''}`);
    for (const t of await page.$$eval('.hub-tab', (as) => as.map((a) => ({ href: a.getAttribute('href'), label: a.textContent.trim() })))) if (!seen.has(t.href)) queue.push({ ...t, label: `tab ${t.label}`, owner: l.owner });
    if (shots[l.href]) await shot(page, shots[l.href]);
  }
}

(async () => {
  const browser = await puppeteer.launch({ headless: 'shell', acceptInsecureCerts: !!process.env.QA_IGNORE_TLS, args: ['--no-sandbox', '--disable-dev-shm-usage', ...(process.env.QA_IGNORE_TLS ? ['--ignore-certificate-errors'] : [])] }); require(__dirname + '/phone.js')(browser); require('./fullwords')(browser);
  try {
    // ── owner: branding first, then the full menu ──
    let p = await newPage(browser);
    await login(p, 'bopc.owner');
    ok('owner: sidebar header shows the school name + School Manager', /Bola Olat/.test(await p.$eval('.sb-brand', (e) => e.textContent)) && /School Manager/.test(await p.$eval('.sb-brand', (e) => e.textContent)));
    ok('owner: no emoji anywhere in the menu', !/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/u.test(await p.$eval('.sidebar', (e) => e.textContent)));
    await p.goto(`${BASE}/#/school/branding`, { waitUntil: 'domcontentloaded' }); await waitIdle(p);
    if (fs.existsSync(LOGO)) {
      const [chooser] = await Promise.all([p.waitForFileChooser(), p.evaluate(() => { const b = [...document.querySelectorAll('button')].find((x) => /Upload logo|Replace logo/.test(x.textContent)); b.click(); })]);
      await chooser.accept([LOGO]); await new Promise((r) => setTimeout(r, 800)); await waitIdle(p);
    }
    await p.evaluate(() => { const b = [...document.querySelectorAll('.swatch')][1]; if (b) b.click(); });
    await p.evaluate(() => { const b = [...document.querySelectorAll('button')].find((x) => x.textContent.includes('Save colour')); if (b) b.click(); }); await waitIdle(p);
    await p.reload({ waitUntil: 'networkidle0' }); await waitIdle(p);
    ok('owner: logo now shows in the sidebar header', !!(await p.$('.sb-brand img.brand-logo')));
    await shot(p, 'menu-branding.png');
    await p.goto(`${BASE}/#/`, { waitUntil: 'domcontentloaded' }); await waitIdle(p);
    ok('owner: dashboard header shows the school logo', !!(await p.$('.page-intro img.pi-logo')));
    await shot(p, 'menu-owner-dashboard.png');
    // menu search
    await p.type('.nav-filter', 'broad'); await new Promise((r) => setTimeout(r, 200));
    const visible = await p.$$eval('.menu-sec:not([hidden]) a.nav-item', (as) => as.filter((a) => !a.closest('li[hidden]')).map((a) => a.textContent.trim()));
    ok('menu search filters entries ("broad")', visible.length >= 1 && visible.length <= 3 && visible.some((t) => /Broadsheet/.test(t)), visible.join(','));
    await p.evaluate(() => { const i = document.querySelector('.nav-filter'); i.value = ''; i.dispatchEvent(new Event('input')); });
    // collapse / expand
    // 12 Oct 2026: the three-line button hides / shows the WHOLE menu; there is no icon-only mode or collapse arrow
    await p.evaluate(() => { const f = document.querySelector('.nav-filter'); f.value = ''; f.dispatchEvent(new Event('input')); });
    ok('no collapse arrow and no icon-only menu', !(await p.$('.sb-toggle')) && !(await p.evaluate(() => document.body.classList.contains('nav-mini'))));
    await p.click('.menu-btn'); await new Promise((r) => setTimeout(r, 400));
    ok('three-line button hides the whole menu; the page uses the full width', await p.evaluate(() => document.body.classList.contains('nav-hidden') && document.querySelector('.sidebar').getBoundingClientRect().right <= 1 && parseFloat(getComputedStyle(document.querySelector('.main')).marginLeft) === 0));
    await shot(p, 'menu-hidden.png');
    await p.click('.menu-btn'); await new Promise((r) => setTimeout(r, 400));
    ok('pressing it again shows the menu', await p.evaluate(() => !document.body.classList.contains('nav-hidden') && document.querySelector('.sidebar').getBoundingClientRect().left >= 0));
    await crawlMenu(p, 'owner', { '#/students/new': 'menu-add-student.png', '#/results/processing': 'menu-result-processing.png', '#/broadsheet/terminal': 'menu-terminal-broadsheet.png', '#/broadsheet/annual': 'menu-annual-broadsheet.png',
      '#/broadsheet/ranking': 'menu-ranking.png', '#/reports/templates': 'menu-result-templates.png', '#/analytics/charts': 'menu-performance-charts.png', '#/analytics/subjects': 'menu-subject-performance.png',
      '#/teachers/activity': 'menu-teacher-activity.png', '#/school/profile': 'menu-school-profile.png', '#/school/head': 'menu-head.png', '#/backup': 'menu-backup.png', '#/system': 'menu-system.png', '#/help': 'menu-help.png' });
    // sheet in CA focus mode + breadcrumb
    await p.goto(`${BASE}/#/scores/ca`, { waitUntil: 'domcontentloaded' }); await waitIdle(p);
    const open = await p.$('a.btn[href*="focus=ca"]');
    if (open) {
      await open.click(); await waitIdle(p);
      const heads = await p.$$eval('table.grid-scores thead th', (t) => t.map((x) => x.textContent));
      ok('CA entry sheet shows only CA columns', heads.some((x) => /CA/.test(x)) && !heads.some((x) => /Exam/i.test(x)), heads.join('|'));
      ok('CA entry highlights "Score Entry" in the menu (CA and Exam are tabs of one entry)', /Score Entry/.test(await p.$eval('.sidebar .nav-item.active', (e) => e.textContent)));
      ok('breadcrumb shows section › page', /Scores & Results/.test(await p.$eval('#topTitle', (e) => e.textContent)));
      await shot(p, 'menu-ca-entry.png');
    } else ok('CA entry: a published demo sheet is listed', false, 'no focus=ca link');
    await p.goto(`${BASE}/#/reports/print`, { waitUntil: 'domcontentloaded' }); await waitIdle(p);
    ok('Print Reports renders a batch of report sheets', (await p.$$('.report-batch .doc')).length >= 3);
    await p.goto(`${BASE}/#/reports/student`, { waitUntil: 'domcontentloaded' }); await waitIdle(p);
    await p.evaluate(() => { const s = [...document.querySelectorAll('select')].find((x) => x.getAttribute('aria-label') === 'Learner'); s.selectedIndex = 1; s.dispatchEvent(new Event('change')); }); await waitIdle(p);
    ok('Student Report shows a report sheet with the school logo', !!(await p.$('.doc .doc-head img')));
    await shot(p, 'menu-student-report.png');
    await p.browserContext().close();

    // ── other roles ──
    for (const role of ['bopc.teacher1', 'bopc.exams', 'bopc.bursar', 'bopc.parent', 'bopc.student']) {
      p = await newPage(browser);
      await login(p, role);
      await crawlMenu(p, role, role === 'bopc.teacher1' ? { '#/': 'menu-teacher-dashboard.png' } : {});
      await p.browserContext().close();
    }

    // ── branded school sign-in page ──
    p = await newPage(browser);
    await p.goto(`${BASE}/#/s/bopc-demo`, { waitUntil: 'networkidle0' }); await waitIdle(p);
    ok('school sign-in page shows the school name', /Bola Olat Private College/.test(await p.$eval('.auth-brand', (e) => e.textContent)));
    ok('school sign-in page shows the school logo', !!(await p.$('.auth-brand img.portal-logo')));
    await shot(p, 'menu-school-signin.png');
    await p.goto(`${BASE}/#/s/no-such-school`, { waitUntil: 'networkidle0' }); await waitIdle(p);
    ok('unknown / unapproved school page is refused politely', /not available/.test(await p.$eval('.auth-box', (e) => e.textContent)));
    await login(p, 'bopc.teacher1', '#/s/bopc-demo');
    ok('signing in from the school page works', !!(await p.$('.sidebar')));
    await p.evaluate(() => { const b = [...document.querySelectorAll('.pop-item')].find((x) => x.textContent.includes('Sign out')); if (b) b.click(); });
    await new Promise((r) => setTimeout(r, 1500)); await waitIdle(p);
    ok('after sign-out the device returns to the school’s branded page', /Bola Olat/.test(await p.$eval('body', (e) => e.textContent)) && !!(await p.$('.school-branded')));
    await p.browserContext().close();

    // ── phone ──
    p = await newPage(browser, { mobile: true });
    await login(p, 'bopc.exams');
    const bn = await p.$$eval('.bottom-nav .bn-item', (x) => x.length);
    ok('phone: bottom bar with Menu button', bn === 5, String(bn));
    await p.evaluate(() => { [...document.querySelectorAll('.bottom-nav .bn-item')].pop().click(); }); await new Promise((r) => setTimeout(r, 400));
    ok('phone: Menu opens the full tree', await p.evaluate(() => document.body.classList.contains('nav-open')));
    await shot(p, 'menu-phone.png');
    await p.browserContext().close();

    // ── platform: pending approvals ──
    p = await newPage(browser);
    await login(p, 'abo.platform');
    await crawlMenu(p, 'platform', { '#/?status=pending': 'menu-platform-pending.png' });
    await p.browserContext().close();
  } finally { await browser.close(); }
  const passed = results.filter((r) => r.ok).length;
  console.log(`\nMenu QA: ${passed}/${results.length} passed`);
  if (problems.length) { console.log('Problems:\n' + problems.map((x) => ' - ' + x).join('\n')); process.exit(1); }
})().catch((e) => { console.error(e); process.exit(1); });
