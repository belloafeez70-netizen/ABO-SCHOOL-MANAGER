'use strict';
// CBT browser end-to-end (spec §35): exam officer builds a 20-question Mathematics exam through the UI (editor +
// Excel/CSV import + auto-generation + wizard), publishes; the student sits it (access code, autosave, flag,
// back/forward, offline blip, page refresh + resume, review summary, submit); officer releases, sends the score to
// the result sheet; broadsheet + report card reflect it; the student sees the result; analytics render.
// Usage: BASE_URL=http://127.0.0.1:8080 SHOTS=/path node server/test/e2e/cbt.qa.js
const puppeteer = require('puppeteer');
const path = require('node:path');
const fs = require('node:fs');
const totp = require('../../src/security/totp');

const BASE = process.env.BASE_URL || 'http://127.0.0.1:8080';
const SHOTS = process.env.SHOTS || path.join(__dirname, '../../../docs/screenshots');
const PW = process.env.DEMO_PASSWORD || 'Demo#School2026';
fs.mkdirSync(SHOTS, { recursive: true });
const results = []; const problems = [];
const ok = (name, cond, extra = '') => { results.push({ name, ok: !!cond }); if (!cond) problems.push(`${name} ${extra}`); process.stdout.write(`${cond ? '✔' : '✖'} ${name}${extra && !cond ? ' — ' + extra : ''}\n`); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function newPage(browser, errors) {
  const ctx = await browser.createBrowserContext(); const page = await ctx.newPage();
  await page.setViewport({ width: 1366, height: 900 });
  page.on('console', (m) => { if (m.type() === 'error' && !/status of 40[0-9]|net::ERR_INTERNET_DISCONNECTED|Failed to fetch/.test(m.text())) errors.push(m.text()); });
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('response', (r) => { if (r.url().includes('/api/v1/') && r.status() >= 500) errors.push(`HTTP ${r.status()} ${r.url()}`); });
  return page;
}
async function idle(page) { await page.waitForNetworkIdle({ idleTime: 300, timeout: 15000 }).catch(() => {}); await sleep(150); }
async function login(page, loginId) {
  await page.goto(`${BASE}/#/login`, { waitUntil: 'networkidle0' });
  await page.waitForSelector('input[name="loginId"]');
  await page.type('input[name="loginId"]', loginId); await page.type('input[name="password"]', PW);
  await page.click('button[type="submit"]'); await idle(page);
  if (await page.$('.code-box')) {
    const secret = (await page.$eval('.code-box', (e) => e.textContent)).replace(/\s+/g, '');
    await page.type('input[name="code"]', totp.hotp(secret, totp.stepAt())); await page.click('button[type="submit"]'); await idle(page);
    await page.evaluate(() => { const b = [...document.querySelectorAll('button')].find((x) => x.textContent.includes('I have saved them')); if (b) b.click(); }); await idle(page);
  }
}
const clickText = (page, sel, text) => page.evaluate((s, t) => { const b = [...document.querySelectorAll(s)].reverse().find((x) => x.textContent.trim().includes(t) && !x.disabled); if (b) { b.click(); return true; } return false; }, sel, text);
const api = (page, url, opts = {}) => page.evaluate(async (u, o) => { const r = await fetch('/api/v1' + u, { credentials: 'same-origin', headers: { accept: 'application/json' }, ...o }); return { status: r.status, body: await r.json().catch(() => null) }; }, url, opts);
const shot = (page, f) => page.screenshot({ path: path.join(SHOTS, f) });

(async () => {
  const browser = await puppeteer.launch({ headless: 'shell', acceptInsecureCerts: !!process.env.QA_IGNORE_TLS, args: ['--no-sandbox', '--disable-dev-shm-usage', ...(process.env.QA_IGNORE_TLS ? ['--ignore-certificate-errors'] : [])] }); require(__dirname + '/phone.js')(browser); require('./fullwords')(browser);
  const errors = [];
  try {
    // who is the demo student and which class?
    const sp = await newPage(browser, errors); await login(sp, 'bopc.student');
    const me = (await api(sp, '/auth/me')).body;
    const off = await newPage(browser, errors); await login(off, 'bopc.exams');
    const st = (await api(off, `/students/${me.studentId}`)).body.student;
    const academic = (await api(off, '/academic')).body;
    const cls = academic.classes.find((c) => c.id === st.class_id);
    const maths = academic.subjects.find((s) => s.name === 'Mathematics');
    ok('demo student is enrolled in a class', !!cls, JSON.stringify(st));

    // ── 1. question bank: import 19 questions + write 1 in the editor ──
    const csv = ['Subject,Class,Topic,Type,Question,Option A,Option B,Option C,Option D,Correct Answer,Mark,Difficulty,Explanation'];
    const topics = ['Algebra', 'Number Bases', 'Geometry', 'Statistics'];
    for (let i = 1; i <= 19; i++) csv.push(`Mathematics,${cls.display_name},${topics[i % 4]},MCQ,"Q${i}: What is ${i} + ${i}?",${2 * i - 1},${2 * i},${2 * i + 1},${2 * i + 2},B,1,${['Easy', 'Medium', 'Hard'][i % 3]},Add the two numbers`);
    csv.push(`Mathematics,${cls.display_name},Algebra,MCQ,Broken row,1,2,,,Z,1,Easy,`);
    const csvPath = path.join(require('node:os').tmpdir(), 'cbt-qa-questions.csv'); fs.writeFileSync(csvPath, csv.join('\n'));
    await off.goto(`${BASE}/#/cbt/bank`, { waitUntil: 'domcontentloaded' }); await idle(off);
    await clickText(off, 'button', 'Import'); await sleep(300);
    const fileInput = await off.$('.modal input[type=file]'); await fileInput.uploadFile(csvPath);
    await clickText(off, '.modal button', 'Check file'); await idle(off);
    const pv = await off.$eval('.modal', (m) => m.textContent);
    ok('import preview: 19 valid, 1 invalid with a clear error', /19/.test(pv) && /does not match a filled option letter/.test(pv), pv.slice(0, 200));
    await shot(off, 'cbt-import-preview.png');
    await clickText(off, '.modal button', 'Confirm import of 19'); await idle(off);
    await clickText(off, 'button', 'Add question'); await sleep(300);
    await off.evaluate((sid, cid) => { const m = document.querySelector('.modal'); const s = m.querySelector('select[name=subjectId]'); s.value = sid; s.dispatchEvent(new Event('change')); const c = m.querySelector('select[name=classId]'); c.value = cid; }, maths.id, cls.id);
    await off.type('.modal .q-editor', 'If 2x + 5 = 15, find x. (Hint: x^{2} is not needed; \\frac{10}{2} is)');
    const optInputs = await off.$$('.modal .opt-row input.input');
    for (const [i, v] of ['3', '5', '7', '10'].entries()) await optInputs[i].type(v);
    await off.evaluate(() => { document.querySelectorAll('.modal .opt-row input[type=radio]')[1].click(); });
    ok('editor renders a live maths preview (fraction + superscript)', !!(await off.$('.modal .q-preview .mt-frac')) && !!(await off.$('.modal .q-preview sup')));
    await shot(off, 'cbt-question-editor.png');
    await clickText(off, '.modal button', 'Save question'); await idle(off);
    const bank = (await api(off, `/cbt/bank?subjectId=${maths.id}&pageSize=50`)).body;
    ok('question bank now holds 20 Mathematics questions', bank.total === 20, String(bank.total));
    await shot(off, 'cbt-question-bank.png');

    // ── 2. wizard ──
    await off.goto(`${BASE}/#/cbt/new`, { waitUntil: 'domcontentloaded' }); await idle(off);
    await off.type('input[name=title]', 'Mathematics First Term Examination (QA)');
    const curSession = academic.sessions.find((x) => x.is_current);
    const term1 = curSession.terms.find((t) => t.is_current); const term2 = curSession.terms.find((t) => t.name === '3RD');   // a term whose sheets are not locked (the demo publishes 1st and 2nd term)
    await off.evaluate((sid, cid, tid) => { const set = (n, v) => { const e = document.querySelector(`select[name=${n}]`); e.value = v; e.dispatchEvent(new Event('change')); }; set('subjectId', sid); set('classId', cid); set('termId', tid); set('scoreComponent', 'exam'); }, maths.id, cls.id, term2.id);
    await off.evaluate(() => { const d = document.querySelector('input[name=durationMinutes]'); d.value = '30'; });
    await clickText(off, 'button', 'Save & continue'); await idle(off);
    const examId = (off.url().match(/exam\/([0-9a-f-]{36})\/edit/) || [])[1];
    ok('step 1 saved a draft and moved to step 2', !!examId && /step=2/.test(off.url()), off.url());
    await clickText(off, 'button.tab', 'Generate automatically'); await sleep(200);
    await off.evaluate(() => { const rows = document.querySelectorAll('.rule-row'); rows[1].querySelector('button').click(); rows[2].querySelector('button').click(); const [c, d] = rows[0].querySelectorAll('input,select'); c.value = '20'; d.value = ''; });
    await clickText(off, 'button', 'Generate questions'); await idle(off);
    ok('step 2: 20 questions picked at random from the bank', (await off.$$('.q-sel-item')).length === 20, String((await off.$$('.q-sel-item')).length));
    await shot(off, 'cbt-wizard-questions.png');
    await clickText(off, 'button', 'Continue'); await idle(off);
    await off.type('input[name=accessCode]', 'JSS-MATHS');
    await clickText(off, 'button', 'Save & continue'); await idle(off);
    ok('step 4: candidates default to the whole class', /whole class/.test(await off.$eval('.view', (e) => e.textContent)));
    await clickText(off, 'button', 'Continue to review'); await idle(off);
    ok('step 5: review shows ready + 20 questions / 20 marks', /Everything is ready/.test(await off.$eval('.view', (e) => e.textContent)));
    await shot(off, 'cbt-wizard-review.png');
    await clickText(off, 'button', 'Publish now'); await sleep(300); await clickText(off, '.modal button', 'Publish'); await idle(off);
    ok('published → examination page shows ACTIVE', /active/i.test(await off.$eval('.page-head', (e) => e.textContent)));

    // ── 3. student sits the exam ──
    await sp.goto(`${BASE}/#/my-cbt`, { waitUntil: 'domcontentloaded' }); await idle(sp);
    ok('student sees the exam in My CBT', /Mathematics First Term Examination \(QA\)/.test(await sp.$eval('.view', (e) => e.textContent)));
    await sp.goto(`${BASE}/#/take/${examId}`, { waitUntil: 'domcontentloaded' }); await idle(sp);
    await sp.type('.code-input', 'wrong'); await clickText(sp, 'button', 'Begin examination'); await idle(sp);
    ok('wrong access code refused', /not correct/.test(await sp.$eval('.form-alert', (e) => e.textContent)));
    await sp.click('.code-input', { clickCount: 3 }); await sp.type('.code-input', 'jss-maths');
    await clickText(sp, 'button', 'Begin examination'); await idle(sp);
    ok('exam interface: header with school, student, timer', !!(await sp.$('.cbt-head')) && /\d\d:\d\d/.test(await sp.$eval('.cbt-timer', (e) => e.textContent)) && /\d/.test(await sp.$eval('.cbt-meta', (e) => e.textContent)));
    ok('no stray null/undefined text in the exam UI', !/\b(null|undefined|NaN)\b/.test(await sp.$eval('.cbt-q', (e) => e.innerText)));
    ok('one question at a time: "QUESTION 1 OF 20"', /QUESTION 1 OF 20/.test(await sp.$eval('.cbt-qhead', (e) => e.textContent)));
    const answerCurrent = async (k = 1) => { await sp.evaluate((n) => { const o = document.querySelectorAll('.cbt-opt input'); if (o[n]) o[n].click(); }, k); await sleep(120); };
    for (let i = 0; i < 20; i++) {
      await answerCurrent(i % 5 === 0 ? 0 : 1);
      if (i === 2) await clickText(sp, 'button.cbt-flag', 'Mark for review');
      if (i === 4) {            // connection drop
        await sp.setOfflineMode(true);
        await answerCurrent(2); await sleep(900);
        ok('offline: banner + status shown, answer kept', await sp.$eval('.cbt-offline', (e) => !e.hidden) && /Offline/.test(await sp.$eval('.cbt-net', (e) => e.textContent)));
        await shot(sp, 'cbt-offline.png');
        await sp.setOfflineMode(false); await sp.evaluate(() => window.dispatchEvent(new Event('online'))); await sleep(2500); await idle(sp);
        ok('reconnected: answers synced', /saved/i.test(await sp.$eval('.cbt-net', (e) => e.textContent)) && await sp.$eval('.cbt-offline', (e) => e.hidden));
      }
      if (i === 6) {            // back navigation keeps answers
        await clickText(sp, '.cbt-actions button', 'Previous'); await sleep(200);
        ok('previous question keeps its saved answer', (await sp.$$('.cbt-opt.on')).length === 1);
        await clickText(sp, '.cbt-actions button', 'Next'); await sleep(200);
      }
      if (i === 9) {            // page refresh → resume
        await sleep(1800); await idle(sp);
        await sp.reload({ waitUntil: 'domcontentloaded' }); await idle(sp);
        await clickText(sp, 'button', 'Resume examination'); await idle(sp);
        ok('refresh → resume with saved answers', (await sp.$$('.cbt-nb.ans')).length >= 10, String((await sp.$$('.cbt-nb.ans')).length));
        await sp.evaluate((n) => { document.querySelectorAll('.cbt-nb')[n].click(); }, 9); await sleep(200);
      }
      if (i === 10) { /* width only: changing isMobile/hasTouch would reload the page */ await sp.setViewport({ width: 390, height: 844, deviceScaleFactor: 2 }); await sleep(300); await shot(sp, 'cbt-exam-phone.png'); await sp.setViewport({ width: 1366, height: 900 }); await sleep(200); }
      if (i === 12) await shot(sp, 'cbt-exam-desktop.png');
      if (i < 19) { await clickText(sp, '.cbt-actions button', 'Next'); await sleep(150); }
    }
    ok('navigator shows answered + flagged states', (await sp.$$('.cbt-nb.ans')).length === 20 && (await sp.$$('.cbt-nb.flag')).length === 1, `${(await sp.$$('.cbt-nb.ans')).length} ans`);
    await sleep(1800); await idle(sp);
    await clickText(sp, 'button', 'Review & submit'); await sleep(400);
    const sum = await sp.$eval('.modal', (e) => e.textContent);
    ok('exam summary: 20 total, 20 answered, 0 unanswered, 1 for review', /Total questions20/.test(sum) && /Answered20/.test(sum) && /Unanswered0/.test(sum) && /Marked for review1/.test(sum), sum.slice(0, 160));
    await shot(sp, 'cbt-summary.png');
    await clickText(sp, '.modal button', 'SUBMIT EXAM'); await sleep(300); await clickText(sp, '.modal button', 'Submit'); await idle(sp);
    ok('submitted: confirmation shown, result not yet released', /Exam submitted/.test(await sp.$eval('body', (e) => e.textContent)));
    const attempt = (await api(sp, '/cbt/my-results')).body.items[0];

    // ── 4. officer: results → release → send to result sheet ──
    await off.goto(`${BASE}/#/cbt/exam/${examId}?tab=results`, { waitUntil: 'domcontentloaded' }); await idle(off);
    const rowText = await off.$eval('.view', (e) => e.textContent);
    ok('results table shows score, grade and PASS/FAIL', /\/20/.test(rowText) && /(PASS|FAIL)/.test(rowText));
    await clickText(off, 'button', 'Release all'); await sleep(300); await clickText(off, '.modal button', 'Confirm'); await idle(off);
    ok('results released', /released/.test(await off.$eval('.view', (e) => e.textContent)));
    await shot(off, 'cbt-results.png');
    const expected = (await api(off, `/cbt/exams/${examId}/results`)).body.items.find((x) => x.studentId === me.studentId);
    const locked = await off.evaluate(async (id, t1, csrf) => { const h = { 'content-type': 'application/json', 'x-csrf-token': csrf };
      return (await fetch(`/api/v1/cbt/exams/${id}/push-scores`, { method: 'POST', headers: h, body: JSON.stringify({ dryRun: true }) })).status; }, examId, term1.id, (await api(off, '/auth/me')).body.csrf);
    ok('push into an unlocked (3rd-term) sheet is allowed', locked === 200, String(locked));
    await clickText(off, 'button', 'Send to result sheet'); await idle(off);
    ok('send-to-sheet preview scales the CBT % to the Exam column', /scaled to the/.test(await off.$eval('.modal', (e) => e.textContent)));
    await shot(off, 'cbt-push-preview.png');
    await clickText(off, '.modal button', 'Send 1 score'); await idle(off);
    ok('scores sent confirmation', /Scores sent/.test(await off.$eval('body', (e) => e.textContent)));
    const termId = term2.id;
    const bs = (await api(off, `/results/broadsheet?termId=${termId}&classId=${cls.id}`)).body;
    const si = bs.subjects.findIndex((s) => s.subjectId === maths.id);
    const bsRow = bs.rows.find((r) => r.studentId === me.studentId);
    const want = Math.round(expected.percentage / 100 * 60 * 10) / 10;
    ok('broadsheet reflects the CBT exam score', bsRow && bsRow.scores[si] && Number(bsRow.scores[si].total) >= want, JSON.stringify(bsRow && bsRow.scores[si]));
    const rc = (await api(off, `/results/student/${me.studentId}?termId=${termId}`)).body;
    ok('report card reflects the CBT exam score', Number((rc.subjects.find((x) => x.subject === 'Mathematics') || { scores: {} }).scores.exam) === want);
    await off.goto(`${BASE}/#/cbt/exam/${examId}?tab=analytics`, { waitUntil: 'domcontentloaded' }); await idle(off);
    ok('exam analytics render (charts + per-question table)', !!(await off.$('svg.chart')) && /Most-missed/.test(await off.$eval('.view', (e) => e.textContent)));
    await shot(off, 'cbt-analytics.png');
    await off.goto(`${BASE}/#/cbt/dashboard`, { waitUntil: 'domcontentloaded' }); await idle(off);
    await shot(off, 'cbt-dashboard.png');
    await off.goto(`${BASE}/#/cbt/print/${examId}?mode=sheet`, { waitUntil: 'domcontentloaded' }); await idle(off);
    ok('printable answer sheet renders 20 bubble rows', (await off.$$('.omr-row')).length === 20);

    // ── 5. student result page ──
    await sp.goto(`${BASE}/#/cbt/result/${attempt.id}`, { waitUntil: 'domcontentloaded' }); await idle(sp);
    const rt = await sp.$eval('.view', (e) => e.textContent);
    ok('student result page: score, %, grade, PASS/FAIL, counts', /SCORE/.test(rt) && /PERCENTAGE/.test(rt) && /GRADE/.test(rt) && /(PASS|FAIL)/.test(rt) && /Correct/.test(rt));
    await shot(sp, 'cbt-student-result.png');
    ok('exam officer cannot read the audit log (least privilege)', (await api(off, '/audit?pageSize=5')).status === 403);
    const own = await newPage(browser, errors); await login(own, 'bopc.owner');
    const audit = (await api(own, '/audit?pageSize=100&action=cbt.')).body;
    const acts = new Set((audit.items || []).map((x) => x.action));
    ok('audit log has the CBT lifecycle', ['cbt.questions_imported', 'cbt.exam_created', 'cbt.exam_published', 'cbt.attempt_started', 'cbt.attempt_submitted', 'cbt.results_released', 'cbt.scores_pushed'].every((a) => acts.has(a)), [...acts].join(','));
    ok('no console errors / 5xx during the whole run', errors.length === 0, errors.slice(0, 5).join(' | '));
  } finally { await browser.close(); }
  const passed = results.filter((r) => r.ok).length;
  console.log(`\nCBT QA: ${passed}/${results.length} passed`);
  if (problems.length) { console.log('Problems:\n' + problems.map((x) => ' - ' + x).join('\n')); process.exit(1); }
})().catch((e) => { console.error(e); process.exit(1); });
