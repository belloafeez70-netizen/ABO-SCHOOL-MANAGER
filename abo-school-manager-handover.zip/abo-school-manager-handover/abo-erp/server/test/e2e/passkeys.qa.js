'use strict';
// Browser QA: fingerprint/face clock-in in real Chrome with a virtual platform authenticator (the same thing a phone's
// fingerprint reader is to the browser). The server checks every answer.
// Needs a fresh dev-reset server whose PUBLIC_ORIGIN is http://localhost:8080 (the default):
//   BASE_URL=http://localhost:8080 node server/test/e2e/passkeys.qa.js
const puppeteer = require('puppeteer');
const path = require('node:path');
const totp = require('../../src/security/totp');
const BASE = process.env.BASE_URL || 'http://localhost:8080';
const PW = process.env.DEMO_PASSWORD || 'Demo#School2026';
const SHOTS = process.env.SHOTS || path.join(__dirname, '../../../docs/screenshots');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms)); let pass = 0; const problems = [];
const ok = (n, c, x = '') => { if (c) pass++; else problems.push(n + ' ' + x); console.log((c ? '✔ ' : '✖ ') + n + (c ? '' : ' — ' + String(x).slice(0, 400))); };

(async () => {
  const b = await puppeteer.launch({ headless: 'shell', args: ['--no-sandbox', '--disable-dev-shm-usage'] }); require('./fullwords')(b);
  const errs = [];
  const idle = async (p) => { await p.waitForNetworkIdle({ idleTime: 300, timeout: 10000 }).catch(() => {}); await sleep(200); };
  async function clickText(p, sel, t) { for (const el of await p.$$(sel)) { if ((await el.evaluate((e) => e.textContent.trim())).startsWith(t)) { await el.click(); return true; } } return false; }
  const open = async (loginId, { authenticator = false, verified = true } = {}) => {
    const ctx = await b.createBrowserContext(); const p = await ctx.newPage(); await p.setViewport({ width: 1366, height: 900 });
    p.on('pageerror', (e) => errs.push(`${loginId}: ${e.message}`)); p.on('console', (m) => { if (m.type() === 'error' && !/status of 4\d\d/.test(m.text())) errs.push(`${loginId}: ${m.text()}`); });
    if (authenticator) {
      const cdp = await p.target().createCDPSession(); await cdp.send('WebAuthn.enable');
      await cdp.send('WebAuthn.addVirtualAuthenticator', { options: { protocol: 'ctap2', transport: 'internal', hasResidentKey: true, hasUserVerification: true, isUserVerified: verified, automaticPresenceSimulation: true } });
    }
    await p.goto(`${BASE}/#/login`, { waitUntil: 'networkidle0' });
    await p.type('input[name="loginId"]', loginId); await p.type('input[name="password"]', PW); await p.click('button[type="submit"]'); await idle(p);
    if (await p.$('.code-box')) { const s = (await p.$eval('.code-box', (e) => e.textContent)).replace(/\s+/g, ''); await p.type('input[name="code"]', totp.hotp(s, totp.stepAt())); await p.click('button[type="submit"]'); await idle(p); await clickText(p, 'button', 'I have saved them'); await idle(p); }
    return p;
  };
  const go = async (p, hash) => { const same = p.url().endsWith(hash); await p.goto(`${BASE}/${hash}`, { waitUntil: 'domcontentloaded' }); if (same) await p.reload({ waitUntil: 'domcontentloaded' }); await idle(p); };
  const text = (p) => p.evaluate(() => (document.querySelector('main') || document.body).innerText);
  try {
    // the owner turns the rule on (through the rules dialog)
    const O = await open('bopc.owner');
    await go(O, '#/clock');
    await clickText(O, 'button', 'Clock-in rules'); await sleep(500);
    await O.evaluate(() => { const c = document.querySelector('.modal [name=requireBiometric]'); c.checked = true; c.dispatchEvent(new Event('change', { bubbles: true })); });
    await O.evaluate(() => [...document.querySelectorAll('.modal button')].filter((x) => x.textContent.trim() === 'Save rules').pop().click()); await idle(O); await sleep(800);
    const st = await O.evaluate(async () => (await (await fetch('/api/v1/clock/settings', { credentials: 'include' })).json()).requireBiometric);
    ok('owner: "fingerprint or face required" saved', st === true, String(st));
    // a teacher sets up the phone and clocks in with the (virtual) fingerprint
    const T = await open('bopc.teacher1', { authenticator: true });
    await go(T, '#/clock');
    ok('teacher: rule is shown', /Confirm with your fingerprint or face/.test(await text(T)), (await text(T)).slice(0, 300));
    await clickText(T, 'button', 'Clock in now'); await sleep(1200);
    ok('teacher: without set-up, clock-in explains what to do', /Set up fingerprint\/face on this phone first/.test(await text(T)), (await text(T)).slice(0, 400));
    await clickText(T, 'button', 'Set up fingerprint/face on this phone'); await sleep(2000); await idle(T);
    ok('teacher: phone set up', /set up on 1 device/.test(await text(T)), (await text(T)).slice(0, 400));
    await clickText(T, 'button', 'Clock in now'); await sleep(2500); await idle(T);
    ok('teacher: clocked in with fingerprint', /In at \d\d:\d\d/.test(await text(T)) && /Clock out now/.test(await text(T)), (await text(T)).slice(0, 400));
    await T.evaluate(() => { const d = document.querySelector('details'); if (d) d.open = true; });
    ok('teacher: history says "confirmed"', /confirmed/i.test(await text(T)));
    await T.screenshot({ path: path.join(SHOTS, 'clockin-fingerprint.png') });
    // a phone whose fingerprint check fails (user not verified) is refused by the server
    const T2 = await open('bopc.teacher2', { authenticator: true, verified: false });
    await go(T2, '#/clock');
    await clickText(T2, 'button', 'Set up fingerprint/face on this phone'); await sleep(2000); await idle(T2);
    ok('a phone without a working fingerprint check cannot be set up', /not set up yet/.test(await text(T2)), (await text(T2)).slice(0, 400));
    // the head sees the clock-in
    await go(O, '#/clock');
    ok('owner: register shows the teacher clocked in', /Mr Tunde Bello[\s\S]{0,80}(on time|late)/i.test(await text(O)), (await text(O)).slice(0, 600));
    ok('no page errors', errs.length === 0, errs.join(' | '));
  } finally { await b.close(); }
  console.log(`\n${pass} passed, ${problems.length} failed`); process.exit(problems.length ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
