'use strict';
// Cumulative results in the browser: staff page (whole class / one subject / one learner, columns switch, Excel),
// 2nd-term report card "results so far" block, parent portal term picker, phone layout. Needs the dev seed
// (BASIC 1A has published 1st- and 2nd-term results). Usage: BASE_URL=http://127.0.0.1:8080 node server/test/e2e/cumulative.qa.js
const puppeteer = require('puppeteer');
const fs = require('node:fs');
const totp = require('../../src/security/totp');
const BASE = process.env.BASE_URL || 'http://127.0.0.1:8080';
const PW = process.env.DEMO_PASSWORD || 'Demo#School2026';
const SHOTS = process.env.SHOTS || '/tmp/cumulative-shots'; fs.mkdirSync(SHOTS, { recursive: true });
const results = []; const problems = [];
const ok = (n, c, x = '') => { results.push(!!c); if (!c) problems.push(`${n} ${x}`); console.log(`${c ? '✔' : '✖'} ${n}${c ? '' : ' — ' + x}`); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const idle = async (p) => { await p.waitForNetworkIdle({ idleTime: 300, timeout: 15000 }).catch(() => {}); await sleep(200); };
async function login(p, id) {
  await p.goto(`${BASE}/#/login`, { waitUntil: 'networkidle0' }); await p.waitForSelector('input[name="loginId"]');
  await p.type('input[name="loginId"]', id); await p.type('input[name="password"]', PW); await p.click('button[type="submit"]'); await idle(p);
  if (await p.$('.code-box')) {   // roles that must set up two-step sign-in (owner/admin)
    const secret = (await p.$eval('.code-box', (e) => e.textContent)).replace(/\s+/g, '');
    await p.type('input[name="code"]', totp.hotp(secret, totp.stepAt())); await p.click('button[type="submit"]'); await idle(p);
    await p.evaluate(() => { const b = [...document.querySelectorAll('button')].find((x) => x.textContent.includes('I have saved them')); if (b) b.click(); }); await idle(p);
  }
  await p.waitForSelector('.sidebar', { timeout: 15000 });
}
const pickTerm = (p, name) => p.evaluate((n) => { const s = document.querySelector('select[name="termId"]'); const o = [...s.options].find((x) => x.textContent.toLowerCase().includes(`${n} term`.toLowerCase())); s.value = o.value; s.dispatchEvent(new Event('change', { bubbles: true })); }, name);

(async () => {
  const browser = await puppeteer.launch({ headless: 'shell', args: ['--no-sandbox'] }); require(__dirname + '/phone.js')(browser);
  const errors = [];
  try {
    const ctx = await browser.createBrowserContext(); const p = await ctx.newPage(); await p.setViewport({ width: 1440, height: 900 });
    p.on('pageerror', (e) => errors.push(e.message)); p.on('console', (m) => { if (m.type() === 'error' && !/40[134]/.test(m.text())) errors.push(m.text()); });
    await p.evaluateOnNewDocument(() => { try { localStorage.setItem('abo.words', 'full'); } catch { /* */ } });
    await login(p, 'bopc.exams');
    const link = await p.$('.sidebar a[href="#/broadsheet/cumulative"]');
    ok('menu has "Cumulative Results" under Broadsheets & Reports', !!link);
    await p.evaluate(() => { location.hash = '#/broadsheet/cumulative'; }); await idle(p);
    ok('1st term shows the hint to choose a later term', await p.evaluate(() => /Choose 2nd term or 3rd term/.test(document.body.innerText)));
    await pickTerm(p, '2ND'); await idle(p);
    const t = await p.evaluate(() => { const tb = document.querySelector('table.cum-sheet'); if (!tb) return null; return { rows: tb.querySelectorAll('tbody tr').length, head: tb.querySelector('thead').innerText, foot: tb.querySelector('tfoot').innerText, title: document.querySelector('.doc h2').textContent, first: tb.querySelector('tbody tr td').textContent }; });
    ok('whole-class cumulative sheet renders with learners', t && t.rows >= 5, JSON.stringify(t));
    ok('headings show 1ST, 2ND and CUM columns and term averages', t && /1ST/.test(t.head) && /2ND/.test(t.head) && /CUM/.test(t.head) && /Term averages/.test(t.head), t && t.head.slice(0, 200));
    ok('title says 1st term to 2nd term', t && /1st term to 2nd term/.test(t.title), t && t.title);
    ok('first row is 1st position', t && t.first.trim() === '1st', t && t.first);
    ok('class average footer present', t && /Class average/.test(t.foot) && /passed/.test(t.foot));
    await p.screenshot({ path: `${SHOTS}/cumulative-class.png`, fullPage: false });
    // cumulative only
    const before = await p.$$eval('table.cum-sheet thead tr:nth-child(2) th', (x) => x.length);
    await p.evaluate(() => [...document.querySelectorAll('.seg-btn')].find((b) => /Cumulative only/.test(b.textContent)).click()); await sleep(300);
    const after = await p.$$eval('table.cum-sheet thead tr:nth-child(2) th', (x) => x.length);
    ok('"Cumulative only" hides the per-term columns', after < before, `${before} → ${after}`);
    // one subject
    await p.evaluate(() => [...document.querySelectorAll('.tab')].find((b) => b.textContent === 'One subject').click()); await sleep(300);
    const sv = await p.evaluate(() => ({ h: (document.querySelector('.doc h3') || {}).textContent, rows: document.querySelectorAll('.doc table.terminal tbody tr').length, sel: !!document.querySelector('select[aria-label="Subject"]') }));
    ok('one-subject view lists learners with subject cumulative', sv.rows >= 5 && sv.sel && /cumulative to 2nd term/.test(sv.h || ''), JSON.stringify(sv));
    await p.select('select[aria-label="Subject"]', await p.$eval('select[aria-label="Subject"] option:nth-child(2)', (o) => o.value)); await sleep(300);
    ok('changing subject redraws', await p.evaluate(() => document.querySelector('.doc h3').textContent.length > 5));
    // one learner
    await p.evaluate(() => [...document.querySelectorAll('.tab')].find((b) => b.textContent === 'One learner').click()); await sleep(400);
    const pv = await p.evaluate(() => ({ sum: (document.querySelector('.cum-summary') || {}).textContent || '', facts: (document.querySelector('.cum-facts') || {}).innerText || '', chart: !!document.querySelector('.cum-chart svg') }));
    ok('one-learner view has a plain-English summary', /After the second term, .+ cumulative average is \d/.test(pv.sum), pv.sum);
    ok('one-learner view shows cumulative position and change', /Cumulative position/i.test(pv.facts) && /Change since last term/i.test(pv.facts), pv.facts);
    ok('one-learner view draws the term-average chart', pv.chart);
    await p.screenshot({ path: `${SHOTS}/cumulative-learner.png` });
    // Excel
    const xl = await p.evaluate(async () => { const tid = document.querySelector('select[name="termId"]').value; const cid = document.querySelector('select[name="classId"]').value; const r = await fetch(`/api/v1/exports/cumulative?termId=${tid}&classId=${cid}&format=xlsx`, { credentials: 'include' }); return { s: r.status, t: r.headers.get('content-type') }; });
    ok('Excel export downloads (.xlsx)', xl.s === 200 && /spreadsheetml/.test(xl.t), JSON.stringify(xl));
    // report card 2nd term
    await p.evaluate(() => [...document.querySelectorAll('button')].find((b) => /Open report card/.test(b.textContent)).click()); await idle(p);
    const rc = await p.evaluate(() => { const b = document.querySelector('.cum-block'); return b ? { title: b.querySelector('.cum-title').textContent, rows: b.querySelectorAll('tbody tr').length, foot: b.querySelector('tfoot').innerText, sum: (b.querySelector('.cum-summary') || {}).textContent } : null; });
    ok('2nd-term report card has the "results so far this session" block', rc && /Results so far this session/.test(rc.title) && rc.rows > 0, JSON.stringify(rc));
    ok('report card block shows term averages and the cumulative average', rc && /Term average/.test(rc.foot) && /%/.test(rc.foot));
    await p.screenshot({ path: `${SHOTS}/report-card-2nd-term.png`, fullPage: true });
    await ctx.close();
    // template setting preview (administrator)
    const ca = await browser.createBrowserContext(); const pa = await ca.newPage(); await pa.setViewport({ width: 1440, height: 900 });
    pa.on('pageerror', (e) => errors.push('admin: ' + e.message));
    await login(pa, 'bopc.admin');
    await pa.evaluate(() => { location.hash = '#/reports/templates'; }); await idle(pa);
    ok('report template page previews the cumulative block', await pa.evaluate(() => !!document.querySelector('.cum-block')));
    ok('template page has the cumulative settings', await pa.evaluate(() => !!document.querySelector('[name="showCumulative"]') && !!document.querySelector('select[name="cumulativeDivisor"]')));
    await pa.evaluate(() => { const c = document.querySelector('[name="showCumulative"]'); c.click(); }); await sleep(300);
    ok('unticking hides the block in the preview', await pa.evaluate(() => !document.querySelector('.cum-block')));
    await ca.close();

    // parent portal: term picker → 2nd term card with cumulative
    const c2 = await browser.createBrowserContext(); const pp = await c2.newPage(); await pp.setViewport({ width: 1280, height: 900 });
    pp.on('pageerror', (e) => errors.push('parent: ' + e.message));
    await login(pp, 'bopc.parent');
    await pp.evaluate(() => { location.hash = '#/my-results'; }); await idle(pp);
    const opts = await pp.$$eval('select[name="termId"] option', (o) => o.map((x) => x.textContent));
    ok('parent sees a term picker with published terms', opts.some((x) => /2nd term/i.test(x)) && opts.some((x) => /1st term/i.test(x)), JSON.stringify(opts));
    await pickTerm(pp, '2ND'); await idle(pp);
    ok('parent 2nd-term report card shows results so far', await pp.evaluate(() => !!document.querySelector('.cum-block .cum-summary')));
    await pp.screenshot({ path: `${SHOTS}/parent-2nd-term.png`, fullPage: true });
    await c2.close();

    // phone
    const c3 = await browser.createBrowserContext(); const m = await c3.newPage(); await m.setViewport({ width: 390, height: 844, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
    m.on('pageerror', (e) => errors.push('phone: ' + e.message));
    await login(m, 'bopc.exams');
    await m.evaluate(() => { location.hash = '#/broadsheet/cumulative'; }); await idle(m); await pickTerm(m, '2ND'); await idle(m);
    ok('phone: page does not slide sideways (table scrolls inside its box)', await m.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1));
    const tabsOk = await m.evaluate(() => { const b = [...document.querySelectorAll('.tab')].find((x) => x.textContent === 'One learner'); b.scrollIntoView({ block: 'center' }); const r = b.getBoundingClientRect(); const t = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2); return t === b; });
    ok('phone: view tabs can be tapped', tabsOk);
    await m.tap('.tabs .tab:nth-child(3)'); await sleep(400);
    ok('phone: one-learner view opens by tap', await m.evaluate(() => !!document.querySelector('.cum-summary')));
    await m.screenshot({ path: `${SHOTS}/phone-learner.png`, fullPage: true });
    await c3.close();
  } catch (e) { problems.push('crash ' + e.stack); console.error(e); }
  ok('no script errors', errors.length === 0, errors.join(' | '));
  await browser.close();
  console.log(`\n${results.filter(Boolean).length}/${results.length} passed`);
  process.exit(problems.length ? 1 : 0);
})();
