'use strict';
// Browser QA against a running server (BASE_URL). Signs in as each role in real headless Chrome, visits every
// major page, fails on console errors / CSP violations / failed API calls, and captures screenshots.
// Usage: BASE_URL=http://127.0.0.1:8080 SHOTS=/path node server/test/e2e/ui.qa.js
const puppeteer = require('puppeteer');
const path = require('node:path');
const fs = require('node:fs');
const totp = require('../../src/security/totp');

const BASE = process.env.BASE_URL || 'http://127.0.0.1:8080';
const SHOTS = process.env.SHOTS || path.join(__dirname, '../../../docs/screenshots');
const PW = process.env.DEMO_PASSWORD || 'Demo#School2026';
fs.mkdirSync(SHOTS, { recursive: true });
const results = []; const problems = [];
const ok = (name, cond, extra = '') => { results.push({ name, ok: !!cond }); if (!cond) problems.push(`${name} ${extra}`); process.stdout.write(`${cond ? '✔' : '✖'} ${name}${extra && !cond ? ' — ' + extra : ''}\n`); };

async function newPage(browser, { mobile = false, dark = false } = {}) {
  const ctx = await browser.createBrowserContext();
  const page = await ctx.newPage();
  await page.setViewport(mobile ? { width: 390, height: 844, deviceScaleFactor: 2, isMobile: true, hasTouch: true } : { width: 1440, height: 900 });
  if (dark) await page.emulateMediaFeatures([{ name: 'prefers-color-scheme', value: 'dark' }]);
  page._errors = [];
  page.on('console', (m) => { if (m.type() === 'error') page._errors.push(m.text()); });
  page.on('pageerror', (e) => page._errors.push('pageerror: ' + e.message));
  page.on('response', (r) => { if (r.url().includes('/api/v1/') && r.status() >= 500) page._errors.push(`HTTP ${r.status()} ${r.url()}`); });
  return page;
}
async function waitIdle(page) { await page.waitForNetworkIdle({ idleTime: 250, timeout: 10000 }).catch(() => {}); await new Promise((r) => setTimeout(r, 150)); }
async function login(page, loginId) {
  await page.goto(`${BASE}/#/login`, { waitUntil: 'networkidle0' });
  await page.type('input[name="loginId"]', loginId); await page.type('input[name="password"]', PW);
  await page.click('button[type="submit"]'); await waitIdle(page);
  // MFA enrolment gate (owner/admin/bursar…)
  if (await page.$('.code-box')) {
    const secret = (await page.$eval('.code-box', (e) => e.textContent)).replace(/\s+/g, '');
    await page.type('input[name="code"]', totp.hotp(secret, totp.stepAt()));
    await page.click('button[type="submit"]'); await waitIdle(page);
    ok(`${loginId}: MFA enrolment shows 10 recovery codes`, (await page.$$eval('.recovery span', (x) => x.length)) === 10);
    const btns = await page.$$('button'); for (const b of btns) { if ((await b.evaluate((e) => e.textContent)).includes('I have saved them')) { await b.click(); break; } }
    await waitIdle(page);
  }
}
async function visit(page, hash, name, check) {
  page._errors.length = 0;
  await page.goto(`${BASE}/${hash}`, { waitUntil: 'domcontentloaded' }); await waitIdle(page);
  const hasErrorState = await page.$('.state-err');
  const h1 = await page.$eval('h1', (e) => e.textContent).catch(() => '');
  const extra = check ? await check(page) : true;
  ok(`${name} renders (${hash})`, !hasErrorState && page._errors.length === 0 && extra !== false, `${page._errors.join(' | ')} ${hasErrorState ? 'error-state' : ''} h1="${h1}"`);
}
const shot = (page, file) => page.screenshot({ path: path.join(SHOTS, file), fullPage: false });

(async () => {
  const browser = await puppeteer.launch({ headless: 'shell', acceptInsecureCerts: !!process.env.QA_IGNORE_TLS, args: ['--no-sandbox', '--disable-dev-shm-usage', ...(process.env.QA_IGNORE_TLS ? ['--ignore-certificate-errors'] : [])] }); require(__dirname + '/phone.js')(browser); require('./fullwords')(browser);
  try {
    // ── login page + CSP ──
    let p = await newPage(browser);
    await p.goto(`${BASE}/#/login`, { waitUntil: 'networkidle0' });
    ok('login page renders with password field', !!(await p.$('input[type="password"]')));
    const csp = (await (await fetch(`${BASE}/`)).headers.get('content-security-policy')) || '';
    // multi-file build: script-src 'self' only · single-file edition: script-src = exact SHA-256 hash(es) only (even stricter)
    ok('strict CSP on the HTML shell', /script-src ('self'|('sha256-[A-Za-z0-9+/=]+' ?)+)(;|$)/.test(csp) && !/unsafe-inline|unsafe-eval/.test(csp), csp);
    await shot(p, 'login.png');
    await p.type('input[name="loginId"]', 'bopc.teacher1'); await p.type('input[name="password"]', 'wrong-password');
    await p.click('button[type="submit"]'); await waitIdle(p);
    ok('wrong password shows a generic error', /Invalid Login ID or password/.test(await p.$eval('.form-alert', (e) => e.textContent)));
    const ls = await p.evaluate(() => JSON.stringify(Object.keys(localStorage)));
    ok('no session/token stored in localStorage', !/sid|token|session|password/i.test(ls), ls);
    await p.browserContext().close();

    // ── owner (MFA enrolment) + staff pages ──
    p = await newPage(browser);
    await login(p, 'bopc.owner');
    await visit(p, '#/', 'owner dashboard', async (pg) => (await pg.$$('.stat')).length >= 3);
    await shot(p, 'owner-dashboard.png');
    const cookies = await p.cookies();
    ok('session cookie is HttpOnly + SameSite=Strict', cookies.some((c) => /abo_sid/.test(c.name) && c.httpOnly && c.sameSite === 'Strict'));
    ok('JS cannot read the session cookie', !(await p.evaluate(() => document.cookie)).includes('abo_sid'));
    for (const [hash, name] of [['#/getting-started', 'onboarding checklist'], ['#/students', 'students list'], ['#/guardians', 'parents'], ['#/staff', 'staff'], ['#/teachers', 'teachers & assignments'], ['#/users', 'users & access'], ['#/roles', 'roles'],
      ['#/academic', 'academic setup'], ['#/academic?tab=classes', 'classes & arms'], ['#/academic?tab=subjects', 'subjects'], ['#/attendance', 'attendance'], ['#/results', 'score sheets'], ['#/broadsheet', 'broadsheet'],
      ['#/corrections', 'corrections'], ['#/promotion', 'promotion'], ['#/cbt', 'cbt exams'], ['#/cbt/bank', 'question bank'], ['#/fees', 'fees overview'], ['#/fees/invoices', 'invoices'], ['#/fees/payments', 'payments'],
      ['#/fees/setup', 'fee setup'], ['#/announcements', 'announcements'], ['#/messages', 'messages'], ['#/newsletters', 'newsletters'], ['#/documents', 'documents'], ['#/data', 'import/export'], ['#/migrate', 'legacy migration'],
      ['#/audit', 'audit log'], ['#/security-events', 'security events'], ['#/settings', 'school settings'], ['#/account', 'my account']]) await visit(p, hash, name);
    await visit(p, '#/students', 'students table has rows', async (pg) => (await pg.$$('.table tbody tr.clickable')).length > 0);
    await shot(p, 'students.png');
    // XSS: post an announcement with a script payload and check it renders as inert text
    await p.evaluate(async () => {
      const me = await (await fetch('/api/v1/auth/me')).json();
      await fetch('/api/v1/announcements', { method: 'POST', headers: { 'content-type': 'application/json', 'x-csrf-token': me.csrf }, body: JSON.stringify({ title: 'XSS probe <img src=x onerror="window.__xss=1">', body: '<script>window.__xss=2</script><b>bold?</b>', audience: 'all' }) });
    });
    await visit(p, '#/announcements', 'announcement with XSS payload');
    ok('XSS payload rendered as text (not executed)', (await p.evaluate(() => window.__xss === undefined)) && (await p.$$eval('.card h2', (els) => els.some((e) => e.textContent.includes('<img src=x')))));
    // open a student + report-card flow
    await p.goto(`${BASE}/#/students`); await waitIdle(p);
    await p.click('.table tbody tr.clickable'); await waitIdle(p);
    ok('student detail opens', /\/students\//.test(p.url()) && !!(await p.$('.kv')));
    await shot(p, 'student-detail.png');
    // score sheet for owner
    await p.goto(`${BASE}/#/results`); await waitIdle(p);
    const startBtn = await p.$$('button.btn-primary'); if (startBtn.length) { await startBtn[0].click(); await waitIdle(p); }
    ok('score sheet grid opens', !!(await p.$('.grid-scores')) || !!(await p.$('table')));
    await shot(p, 'score-sheet.png');
    await p.goto(`${BASE}/#/broadsheet`); await waitIdle(p); await shot(p, 'broadsheet.png');
    await p.goto(`${BASE}/#/settings`); await waitIdle(p); await shot(p, 'settings.png');
    await p.goto(`${BASE}/#/audit`); await waitIdle(p); await shot(p, 'audit.png');
    await p.browserContext().close();

    // ── teacher ──
    p = await newPage(browser);
    await login(p, 'bopc.teacher1');
    await visit(p, '#/', 'teacher dashboard', async (pg) => !!(await pg.$('.ws-teacher')));
    ok('teacher cannot see finance or users in the menu', !(await p.$('a[href="#/fees"]')) && !(await p.$('a[href="#/users"]')));
    await visit(p, '#/attendance', 'teacher attendance register', async (pg) => (await pg.$$('.list-item')).length > 0);
    await shot(p, 'attendance.png');
    // mark all present + save
    const buttons = await p.$$('button'); for (const b of buttons) { if ((await b.evaluate((e) => e.textContent)) === 'Save register') { await b.click(); break; } }
    await waitIdle(p);
    ok('attendance saved (toast)', /Saved \d+ records/.test(await p.$eval('.toasts', (e) => e.textContent).catch(() => '')));
    await p.goto(`${BASE}/#/fees`); await waitIdle(p);
    ok('teacher typing a finance URL is refused by the SERVER (403 → access-denied state)', !!(await p.$('.state-denied')) && /permission/i.test(await p.$eval('.state-denied', (e) => e.textContent)));
    await p.browserContext().close();

    // ── student (mobile) ──
    p = await newPage(browser, { mobile: true });
    await login(p, 'bopc.student');
    await visit(p, '#/', 'student dashboard (mobile)', async (pg) => !!(await pg.$('.ws-student')) && !!(await pg.$('.bottom-nav')));
    await shot(p, 'student-mobile.png');
    await visit(p, '#/my-results', 'student sees PUBLISHED seeded report card', async (pg) => !!(await pg.$('.doc')) && !(await pg.$('.state-empty')));
    await shot(p, 'student-report-card.png');
    for (const [hash, name] of [['#/my-results', 'student results'], ['#/my-cbt', 'student CBT'], ['#/my-fees', 'student fees'], ['#/timetable', 'student timetable'], ['#/announcements', 'student notices'], ['#/messages', 'student messages']]) await visit(p, hash, name);
    const overflow = await p.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
    ok('no horizontal overflow on phone width', overflow <= 1, `overflow=${overflow}px`);
    await p.click('.menu-btn'); await new Promise((r) => setTimeout(r, 300));
    ok('mobile drawer opens from the left', await p.evaluate(() => document.body.classList.contains('nav-open')));
    await shot(p, 'student-mobile-menu.png');
    await p.browserContext().close();

    // ── parent (dark mode) ──
    p = await newPage(browser, { dark: true });
    await login(p, 'bopc.parent');
    await visit(p, '#/', 'parent dashboard (dark)', async (pg) => (await pg.evaluate(() => document.body.dataset.mode)) === 'dark' && !!(await pg.$('.ws-parent')));
    await shot(p, 'parent-dark.png');
    await visit(p, '#/my-fees', 'parent fees');
    await p.browserContext().close();

    // ── bursar ──
    p = await newPage(browser);
    await login(p, 'bopc.bursar');
    await visit(p, '#/fees', 'bursar fees overview', async (pg) => (await pg.$$('.stat')).length === 4);
    await shot(p, 'fees.png');
    await p.browserContext().close();

    // ── multi-school proprietor: switch schools from the user menu ──
    p = await newPage(browser);
    await login(p, 'demo.proprietor');
    await visit(p, '#/', 'proprietor dashboard (school A)');
    const schoolA = await p.$eval('.sb-brand-text strong', (e) => e.textContent);
    await p.click('.user-chip'); await new Promise((r) => setTimeout(r, 200));
    const sw = await p.$$('.user-pop .pop-item'); let clicked = false;
    for (const b of sw) { if (/Switch to/.test(await b.evaluate((e) => e.textContent))) { await b.click(); clicked = true; break; } }
    await p.waitForNavigation({ waitUntil: 'networkidle0', timeout: 10000 }).catch(() => {}); await waitIdle(p);
    const schoolB = await p.$eval('.sb-brand-text strong', (e) => e.textContent).catch(() => '');
    ok('multi-school user switches school from the menu', clicked && schoolB && schoolB !== schoolA, `${schoolA} → ${schoolB}`);
    await shot(p, 'school-switch.png');
    await p.browserContext().close();

    // ── branch-restricted administrator ──
    p = await newPage(browser);
    await login(p, 'bopc.annex');
    await visit(p, '#/students', 'annex admin students (branch-scoped)', async (pg) => {
      const classes = await pg.$$eval('.table tbody td[data-label="Class"]', (els) => [...new Set(els.map((e) => e.textContent))]);
      return classes.length === 1 && classes[0] === 'JSS 1A';
    });
    ok('branch shown in the sidebar', /Annex/.test(await p.$eval('.sb-brand-text span', (e) => e.textContent)));
    await shot(p, 'branch-admin.png');
    await p.browserContext().close();

    // ── platform admin ──
    p = await newPage(browser);
    await login(p, 'abo.platform');
    await visit(p, '#/', 'platform schools console', async (pg) => (await pg.$$('.table tbody tr')).length >= 2);
    await shot(p, 'platform.png');
    await visit(p, '#/platform/health', 'platform health');
    await visit(p, '#/platform/security', 'platform security events');
    await p.browserContext().close();
  } finally { await browser.close(); }
  const pass = results.filter((r) => r.ok).length;
  console.log(`\nUI QA: ${pass}/${results.length} passed`);
  if (problems.length) { console.log('Problems:\n - ' + problems.join('\n - ')); process.exit(1); }
})().catch((e) => { console.error(e); process.exit(1); });
