'use strict';
// Browser QA (Phase 6, part 4): owner "sign in as" (banner, menu, blocked areas, back), the school web address (change +
// old link still works) and offline support (the app opens with the last saved copy when the server cannot be reached;
// signing out deletes the saved copy). Needs a running server on a fresh dev-reset database that this script may stop:
//   BASE_URL=http://127.0.0.1:8080 SERVER_PID=<pid> node server/test/e2e/owner_tools.qa.js
const puppeteer = require('puppeteer');
const path = require('node:path');
const totp = require('../../src/security/totp');
const BASE = process.env.BASE_URL || 'http://127.0.0.1:8080';
const PW = process.env.DEMO_PASSWORD || 'Demo#School2026';
const SHOTS = process.env.SHOTS || path.join(__dirname, '../../../docs/screenshots');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms)); let pass = 0; const problems = [];
const ok = (n, c, x = '') => { if (c) pass++; else problems.push(n + ' ' + x); console.log((c ? '✔ ' : '✖ ') + n + (c ? '' : ' — ' + String(x).slice(0, 400))); };

(async () => {
  const b = await puppeteer.launch({ headless: 'shell', acceptInsecureCerts: !!process.env.QA_IGNORE_TLS, args: ['--no-sandbox', '--disable-dev-shm-usage', ...(process.env.QA_IGNORE_TLS ? ['--ignore-certificate-errors'] : [])] }); require('./fullwords')(b);
  const errs = [];
  const idle = async (p) => { await p.waitForNetworkIdle({ idleTime: 300, timeout: 10000 }).catch(() => {}); await sleep(200); };
  async function clickText(p, sel, t) { for (const el of await p.$$(sel)) { if ((await el.evaluate((e) => e.textContent.trim())).startsWith(t)) { await el.click(); return true; } } return false; }
  const open = async (loginId, { track = true } = {}) => {
    const ctx = await b.createBrowserContext(); const p = await ctx.newPage(); await p.setViewport({ width: 1366, height: 900 });
    if (track) { p.on('pageerror', (e) => errs.push(`${loginId}: ${e.message}`)); p.on('console', (m) => { if (m.type() === 'error' && !/status of 4\d\d|Failed to load resource|ERR_/.test(m.text())) errs.push(`${loginId}: ${m.text()}`); }); }
    await p.goto(`${BASE}/#/login`, { waitUntil: 'networkidle0' });
    await p.type('input[name="loginId"]', loginId); await p.type('input[name="password"]', PW); await p.click('button[type="submit"]'); await idle(p);
    if (await p.$('.code-box')) { const s = (await p.$eval('.code-box', (e) => e.textContent)).replace(/\s+/g, ''); await p.type('input[name="code"]', totp.hotp(s, totp.stepAt())); await p.click('button[type="submit"]'); await idle(p); await clickText(p, 'button', 'I have saved them'); await idle(p); }
    return p;
  };
  const go = async (p, hash) => { const same = p.url().endsWith(hash); await p.goto(`${BASE}/${hash}`, { waitUntil: 'domcontentloaded' }); if (same) await p.reload({ waitUntil: 'domcontentloaded' }); await idle(p); };
  const text = (p) => p.evaluate(() => (document.querySelector('main') || document.body).innerText);
  const menu = (p) => p.evaluate(() => [...document.querySelectorAll('.sidebar .menu-label')].map((x) => x.textContent.trim()));
  try {
    // ── sign in as ──
    const O = await open('bopc.owner');
    ok('owner: "Users & Roles" in the menu, with the "Sign In As Someone" tab', (await menu(O)).includes('Users & Roles') && (await (async () => { await O.evaluate(() => { location.hash = '#/users'; }); await sleep(900); return O.$$eval('.hub-tab', (as) => as.map((a) => a.textContent.trim())); })()).includes('Sign In As Someone'));
    await go(O, '#/act-as');
    await O.type('.range-bar input', 'Tunde'); await sleep(900); await idle(O);
    await clickText(O, 'button', 'Sign in as'); await sleep(500);
    await O.evaluate(() => { const r = document.querySelector('.modal [name=reason]'); r.value = 'Help with lesson notes'; });
    await Promise.all([O.waitForNavigation({ waitUntil: 'domcontentloaded' }).catch(() => {}), O.evaluate(() => [...document.querySelectorAll('.modal button')].filter((x) => x.textContent.trim() === 'Sign in as this person').pop().click())]);
    await idle(O); await sleep(1000);
    const bannerTxt = await O.evaluate(() => (document.querySelector('.acting-banner') || {}).innerText || '');
    ok('acting: red banner names the teacher, the owner and the time left', /using the app as Mr Tunde Bello/.test(bannerTxt) && /Mrs Funke Adewale/.test(bannerTxt) && /Time left: \d+:\d\d/.test(bannerTxt), bannerTxt);
    const m = await menu(O);
    ok('acting: the teacher’s menu (no owner pages)', m.includes('Lessons & Materials') && !m.includes('Users & Roles') && !m.includes('Sign In As Someone') && !m.includes('Fees & Payments'), m.join(' | '));
    await O.screenshot({ path: path.join(SHOTS, 'phase6-act-as.png') });
    const blocked = await O.evaluate(async () => (await fetch('/api/v1/messages/threads', { credentials: 'include' })).status);
    ok('acting: private messages are closed', blocked === 403, String(blocked));
    await clickText(O, '.acting-banner button', 'Back to my account'); await sleep(1500); await idle(O);
    ok('back to the owner account', !(await O.$('.acting-banner')) && (await menu(O)).includes('Users & Roles'));
    const T = await open('bopc.teacher1');
    const nt = await T.evaluate(async () => (await (await fetch('/api/v1/notifications', { credentials: 'include' })).json()).items.map((n) => n.title));
    ok('the teacher is told the owner signed in as them', nt.includes('The school owner signed in as you'), nt.join(' | '));
    // ── web address ──
    await go(O, '#/school/web-address');
    ok('web address page shows the link', /#\/s\/bopc-demo/.test(await O.evaluate(() => document.querySelector('input.mono').value)));
    await O.evaluate(() => { const i = document.querySelectorAll('input.mono')[1]; i.value = 'bright-oak-demo'; i.dispatchEvent(new Event('input')); }); await sleep(900);
    ok('live check says the address is free', /That address is free/.test(await text(O)));
    await clickText(O, 'button', 'Save new address'); await sleep(1200); await idle(O);
    ok('address changed; old address listed', /#\/s\/bright-oak-demo/.test(await O.evaluate(() => document.querySelector('input.mono').value)) && /bopc-demo/.test(await text(O)));
    await O.screenshot({ path: path.join(SHOTS, 'phase6-web-address.png') });
    const ctx = await b.createBrowserContext(); const P = await ctx.newPage();
    await P.goto(`${BASE}/#/s/bopc-demo`, { waitUntil: 'networkidle0' }); await sleep(800);
    ok('an old printed link still opens the school page (moved to the new address)', P.url().endsWith('#/s/bright-oak-demo') && /Bola Olat Private College/.test(await P.evaluate(() => document.body.innerText)), P.url());
    // ── offline ──
    const S = await open('bopc.student');
    await go(S, '#/'); await go(S, '#/announcements'); await go(S, '#/');
    await S.waitForFunction(() => navigator.serviceWorker && navigator.serviceWorker.controller, { timeout: 8000 }).catch(() => {});
    await go(S, '#/announcements'); await go(S, '#/');
    ok('offline support is active (service worker controls the page)', await S.evaluate(() => !!(navigator.serviceWorker && navigator.serviceWorker.controller)));
    if (!process.env.SERVER_PID) throw new Error('set SERVER_PID so the test can stop the server');
    process.kill(Number(process.env.SERVER_PID)); await sleep(1500);
    await S.reload({ waitUntil: 'domcontentloaded' }).catch(() => {}); await sleep(2500);
    const off = await S.evaluate(() => ({ app: !!document.querySelector('.sidebar'), bar: (document.getElementById('offlineBar') || {}).textContent || '', text: (document.querySelector('main') || document.body).innerText.slice(0, 300) }));
    ok('server unreachable: the app still opens with the saved copy and says so', off.app && /offline|No connection to the school server/i.test(off.bar), JSON.stringify(off));
    await S.screenshot({ path: path.join(SHOTS, 'phase6-offline.png') });
    const keys = await S.evaluate(async () => (await caches.keys()).filter((k) => k.includes('-api-')).length);
    await S.evaluate(() => navigator.serviceWorker.controller.postMessage({ type: 'signed-out' })); await sleep(800);
    const after = await S.evaluate(async () => (await caches.keys()).filter((k) => k.includes('-api-')).length);
    ok('signing out deletes the saved copy', keys >= 1 && after === 0, `${keys} → ${after}`);
    ok('no console or page errors (before going offline)', errs.filter((e) => !/bopc.student/.test(e)).length === 0, errs.join(' | '));
  } finally { await b.close(); }
  console.log(`\n${pass} passed, ${problems.length} failed`); process.exit(problems.length ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
