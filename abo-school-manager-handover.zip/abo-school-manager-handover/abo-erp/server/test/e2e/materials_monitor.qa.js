'use strict';
// Browser QA (Phase 6, part 3): study materials (link + file), live classes, class monitor + bell times, and the
// simple-words menu with its "Show full terms" switch. Needs a running server on a fresh dev-reset database.
// Usage: BASE_URL=http://127.0.0.1:8080 node server/test/e2e/materials_monitor.qa.js
const puppeteer = require('puppeteer');
const path = require('node:path'); const fs = require('node:fs'); const os = require('node:os');
const totp = require('../../src/security/totp');
const BASE = process.env.BASE_URL || 'http://127.0.0.1:8080';
const PW = process.env.DEMO_PASSWORD || 'Demo#School2026';
const SHOTS = process.env.SHOTS || path.join(__dirname, '../../../docs/screenshots');
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==', 'base64');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms)); let pass = 0; const problems = [];
const ok = (n, c, x = '') => { if (c) pass++; else problems.push(n + ' ' + x); console.log((c ? '✔ ' : '✖ ') + n + (c ? '' : ' — ' + String(x).slice(0, 400))); };

(async () => {
  const b = await puppeteer.launch({ headless: 'shell', acceptInsecureCerts: !!process.env.QA_IGNORE_TLS, args: ['--no-sandbox', '--disable-dev-shm-usage', ...(process.env.QA_IGNORE_TLS ? ['--ignore-certificate-errors'] : [])] });   // NOTE: no full-terms helper — this suite checks the simple-words default
  const errs = [];
  const idle = async (p) => { await p.waitForNetworkIdle({ idleTime: 300, timeout: 10000 }).catch(() => {}); await sleep(200); };
  async function clickText(p, sel, t) { for (const el of await p.$$(sel)) { if ((await el.evaluate((e) => e.textContent.trim())).startsWith(t)) { await el.click(); return true; } } return false; }
  const open = async (loginId) => {
    const ctx = await b.createBrowserContext(); const p = await ctx.newPage(); await p.setViewport({ width: 1366, height: 900 });
    p.on('pageerror', (e) => errs.push(`${loginId}: ${e.message}`)); p.on('console', (m) => { if (m.type() === 'error' && !/status of 4\d\d/.test(m.text())) errs.push(`${loginId}: ${m.text()}`); });
    await p.goto(`${BASE}/#/login`, { waitUntil: 'networkidle0' });
    await p.type('input[name="loginId"]', loginId); await p.type('input[name="password"]', PW); await p.click('button[type="submit"]'); await idle(p);
    if (await p.$('.code-box')) { const s = (await p.$eval('.code-box', (e) => e.textContent)).replace(/\s+/g, ''); await p.type('input[name="code"]', totp.hotp(s, totp.stepAt())); await p.click('button[type="submit"]'); await idle(p); await clickText(p, 'button', 'I have saved them'); await idle(p); }
    return p;
  };
  const go = async (p, hash) => { const same = p.url().endsWith(hash); await p.goto(`${BASE}/${hash}`, { waitUntil: 'domcontentloaded' }); if (same) await p.reload({ waitUntil: 'domcontentloaded' }); await idle(p); };
  const text = (p) => p.evaluate(() => (document.querySelector('main') || document.body).innerText);
  const menu = (p) => p.evaluate(() => [...document.querySelectorAll('.sidebar .menu-label, .sidebar .menu-cat span')].map((x) => x.textContent.trim()));
  const fill = (p, name, v) => p.evaluate((n, v) => { const el = document.querySelector(`.modal [name="${n}"]`); if (!el) return false; if (el.type === 'checkbox') el.checked = !!v; else if (el.tagName === 'SELECT' && v === '#first') { el.selectedIndex = 1; } else el.value = v; el.dispatchEvent(new Event('change', { bubbles: true })); return true; }, name, v);
  const save = async (p, label) => { await p.evaluate((l) => { const bs = [...document.querySelectorAll('.modal button')].filter((x) => x.textContent.trim() === l); bs[bs.length - 1].click(); }, label); await idle(p); await sleep(500); };
  try {
    // ── simple words by default; the switch brings back the full terms ──
    const O = await open('bopc.owner');
    let m = await menu(O);
    ok('menu uses simple words by default (Home, Money, Class Score Sheet)', m.includes('Home') && m.includes('Money') && m.includes('Class Score Sheet') && !m.includes('Dashboard'), m.slice(0, 20).join(' | '));
    await O.type('.nav-filter', 'broadsheet'); await sleep(300);
    const found = await O.evaluate(() => [...document.querySelectorAll('.sidebar .submenu li:not([hidden]) .menu-label')].map((x) => x.textContent.trim()));
    ok('menu search finds a page by its full name too ("broadsheet" → Class Score Sheet)', found.includes('Class Score Sheet'), found.join(' | '));
    await O.evaluate(() => { const f = document.querySelector('.nav-filter'); f.value = ''; f.dispatchEvent(new Event('input')); });
    await go(O, '#/broadsheet');
    ok('page title and breadcrumb in simple words', (await O.$eval('h1', (e) => e.textContent)) === 'Class Score Sheet' && /Score Sheets & Report Cards/.test(await O.$eval('#topTitle', (e) => e.textContent)), await O.$eval('h1', (e) => e.textContent));
    await O.click('.user-chip'); await sleep(200); await Promise.all([O.waitForNavigation({ waitUntil: 'domcontentloaded' }).catch(() => {}), O.click('.pop-check input')]); await idle(O); await sleep(800);
    m = await menu(O);
    ok('"Show full terms" brings back the office words', m.includes('Dashboard') && m.includes('Finance') && m.includes('Class Broadsheet'), m.slice(0, 20).join(' | '));
    await O.click('.user-chip'); await sleep(200); await Promise.all([O.waitForNavigation({ waitUntil: 'domcontentloaded' }).catch(() => {}), O.click('.pop-check input')]); await idle(O); await sleep(800);
    ok('…and switching it off returns to simple words', (await menu(O)).includes('Home'));

    // ── teacher shares a video link and a file ──
    const T = await open('bopc.teacher1');
    await go(T, '#/materials');
    await clickText(T, 'button', 'Share a link or video'); await sleep(500);
    await fill(T, 'classId', '#first'); await fill(T, 'title', 'Fractions made easy'); await fill(T, 'url', 'https://www.youtube.com/watch?v=abc123'); await save(T, 'Save');
    ok('teacher: video shared', /Fractions made easy/.test(await text(T)) && /Video on YouTube/.test(await text(T)), (await text(T)).slice(0, 400));
    const f = path.join(os.tmpdir(), 'shapes-chart.png'); fs.writeFileSync(f, PNG);
    await clickText(T, 'button', 'Upload a file'); await sleep(500);
    await fill(T, 'classId', '#first'); await fill(T, 'title', 'Shapes chart');
    const inp = await T.$('.modal input[type=file]'); await inp.uploadFile(f); await save(T, 'Save');
    ok('teacher: file shared', /Shapes chart/.test(await text(T)) && /shapes-chart\.png/.test(await text(T)), (await text(T)).slice(0, 500));
    await T.screenshot({ path: path.join(SHOTS, 'phase6-materials-teacher.png') });
    // ── live class starting in 10 minutes ──
    await go(T, '#/live-classes');
    await clickText(T, 'button', 'Schedule a live class'); await sleep(500);
    const soon = new Date(Date.now() + 10 * 60000); const loc = `${soon.getFullYear()}-${String(soon.getMonth() + 1).padStart(2, '0')}-${String(soon.getDate()).padStart(2, '0')}T${String(soon.getHours()).padStart(2, '0')}:${String(soon.getMinutes()).padStart(2, '0')}`;
    await fill(T, 'classId', '#first'); await fill(T, 'title', 'Revision class'); await fill(T, 'startsAt', loc); await fill(T, 'joinUrl', 'https://meet.google.com/abc-defg-hij'); await save(T, 'Save');
    ok('teacher: live class scheduled', /Revision class/.test(await text(T)) && /starting soon/i.test(await text(T)), (await text(T)).slice(0, 500));
    // ── the pupil sees both, opens the file, can join ──
    const S = await open('bopc.student');
    m = await menu(S);
    // one "Learning" menu entry; Notes & Videos and Live Classes are its tabs (menu merge, 11 Oct 2026)
    ok('pupil menu has "Learning" (Notes & Videos, Live Classes)', m.includes('Learning'), m.join(' | '));
    await go(S, '#/materials');
    ok('pupil: Learning tabs show Notes & Videos and Live Classes', await S.evaluate(() => { const t = [...document.querySelectorAll('.hub-tab')].map((a) => a.textContent); return t.includes('Notes & Videos') && t.includes('Live Classes'); }));
    ok('pupil: sees the video and the file', /Fractions made easy/.test(await text(S)) && /Shapes chart/.test(await text(S)));
    const href = await S.evaluate(() => [...document.querySelectorAll('a.btn')].find((a) => a.textContent === 'Open').getAttribute('href'));
    const st = await S.evaluate(async (u) => (await fetch(u, { credentials: 'include' })).status, href);
    ok('pupil: the file opens', st === 200, String(st));
    await S.screenshot({ path: path.join(SHOTS, 'phase6-materials-pupil.png') });
    await go(S, '#/live-classes');
    ok('pupil: live class with a Join button (opens 15 min before)', await S.evaluate(() => [...document.querySelectorAll('a.btn')].some((a) => a.textContent === 'Join' && a.getAttribute('href') === 'https://meet.google.com/abc-defg-hij')));
    // ── class monitor + bell times ──
    await go(O, '#/monitor');
    ok('owner: monitor asks for bell times first', /Bell times are not set yet/.test(await text(O)));
    await clickText(O, 'button', 'Bell times'); await sleep(500); await save(O, 'Save bell times'); await sleep(800);
    const mt = await text(O);
    ok('owner: monitor after saving bell times', !/Bell times are not set yet/.test(mt) && /BASIC 1A/.test(mt) && /(in session|teacher not clocked in|no lesson now|no timetable|break)/i.test(mt), mt.slice(0, 600));
    await O.evaluate(() => { const d = document.querySelector('.range-bar select'); d.value = '1'; d.dispatchEvent(new Event('change')); const t = document.querySelector('.range-bar input[type=time]'); t.value = '08:10'; t.dispatchEvent(new Event('change')); });
    await sleep(1200); await idle(O);
    ok('owner: preview Monday 08:10', /Monday 08:10 \(preview\)/i.test(await text(O)), (await text(O)).slice(0, 300));
    await O.screenshot({ path: path.join(SHOTS, 'phase6-monitor.png') });
    await go(T, '#/monitor');
    ok('teacher: monitor is for heads only', /don’t have access|do not have permission/i.test(await text(T)), (await text(T)).slice(0, 200));
    ok('no console or page errors', errs.length === 0, errs.join(' | '));
  } finally { await b.close(); }
  console.log(`\n${pass} passed, ${problems.length} failed`); process.exit(problems.length ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
