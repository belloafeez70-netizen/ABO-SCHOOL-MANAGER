'use strict';
// "Install as app" + screen-layout lock.
//  • Chrome reports the site installable (manifest, icons, service worker) — Page.getInstallabilityErrors is empty
//  • the Install button calls the browser's own install box (beforeinstallprompt) when the browser offers one,
//    and shows exact steps otherwise (Safari / Firefox)
//  • on a phone, choosing "computer layout" draws the page 1280 px wide with the full sidebar, and it STAYS after a
//    reload, after leaving and returning to the tab, after rotating, and in a new tab
//  • the browser's own "Desktop site" (desktop browser name on a small touch screen) gives the computer layout every time
// Usage: BASE_URL=http://localhost:8080 node server/test/e2e/install_layout.qa.js   (localhost counts as secure)
const puppeteer = require('puppeteer');
const BASE = process.env.BASE_URL || 'http://localhost:8080';
const PW = process.env.DEMO_PASSWORD || 'Demo#School2026';
const results = []; const problems = [];
const ok = (n, c, x = '') => { results.push(!!c); if (!c) problems.push(`${n} ${x}`); console.log(`${c ? '✔' : '✖'} ${n}${c ? '' : ' — ' + x}`); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const idle = async (p) => { await p.waitForNetworkIdle({ idleTime: 300, timeout: 15000 }).catch(() => {}); await sleep(200); };
const PHONE = { width: 390, height: 844, isMobile: true, hasTouch: true, deviceScaleFactor: 2 };
const DESKTOP_UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36';
const ANDROID_UA = 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36';
async function login(p, id) {
  await p.goto(`${BASE}/#/login`, { waitUntil: 'networkidle0' }); await p.waitForSelector('input[name="loginId"]');
  await p.type('input[name="loginId"]', id); await p.type('input[name="password"]', PW); await p.click('button[type="submit"]'); await idle(p);
  await p.waitForSelector('.sidebar', { timeout: 15000 });
}
const layoutState = (p) => p.evaluate(() => ({ w: innerWidth, meta: document.querySelector('meta[name=viewport]').content, mode: document.documentElement.dataset.layout,
  desktopClass: document.documentElement.classList.contains('layout-desktop'), menuBtn: (() => { const sb = document.querySelector('.sidebar'); if (!sb) return 'none'; const r = sb.getBoundingClientRect(); return r.right > 10 ? 'none' : 'drawer'; })(), bottom: getComputedStyle(document.querySelector('.bottom-nav') || document.body).display }));

(async () => {
  const browser = await puppeteer.launch({ headless: 'shell', args: ['--no-sandbox'] });
  const errors = [];
  try {
    // ── installable ──
    const p = await browser.newPage(); await p.setViewport({ width: 1366, height: 800 });
    p.on('pageerror', (e) => errors.push(e.message));
    await p.goto(`${BASE}/#/login`, { waitUntil: 'networkidle0' }); await sleep(1500);
    const cdp = await p.createCDPSession();
    const man = await cdp.send('Page.getAppManifest').catch((e) => ({ errors: [{ message: e.message }] }));
    ok('manifest is found and parses without errors', man.url && /manifest\.webmanifest$/.test(man.url) && (!man.errors || !man.errors.length), JSON.stringify(man.errors || man).slice(0, 300));
    const parsed = JSON.parse(man.data || '{}');
    ok('manifest has name, start_url, standalone display, 192 and 512 icons and a maskable icon',
      parsed.name && parsed.start_url && parsed.display === 'standalone' && parsed.icons.some((i) => i.sizes === '192x192') && parsed.icons.some((i) => i.sizes === '512x512') && parsed.icons.some((i) => i.purpose === 'maskable'));
    for (const i of parsed.icons.filter((x) => x.type === 'image/png')) {
      const r = await p.evaluate(async (src) => { const res = await fetch(src); const b = await createImageBitmap(await res.blob()); return { s: res.status, w: b.width, h: b.height }; }, i.src);
      ok(`icon ${i.src} loads at ${i.sizes}`, r.s === 200 && `${r.w}x${r.h}` === i.sizes, JSON.stringify(r));
    }
    const inst = await cdp.send('Page.getInstallabilityErrors').catch((e) => ({ err: e.message }));
    ok('Chrome reports the app as installable (no installability errors)', inst.installabilityErrors && inst.installabilityErrors.length === 0, JSON.stringify(inst));
    ok('service worker controls the page', await p.evaluate(async () => { const r = await navigator.serviceWorker.getRegistration(); return !!(r && (r.active || r.installing || r.waiting)); }));
    // Install link → steps dialog when the browser gives no install box (Firefox / Safari path)
    await p.evaluate(() => { window.__aboInstallEvent = null; });
    await p.click('.auth-install'); await sleep(400);
    const steps = await p.evaluate(() => { const m = document.querySelector('.modal'); return m ? { t: m.querySelector('h2').textContent, n: m.querySelectorAll('.install-help ol li').length, others: !!m.querySelector('details') } : null; });
    ok('without a browser install box, the Install link shows clear steps', steps && /Install the app/.test(steps.t) && steps.n >= 1 && steps.others, JSON.stringify(steps));
    await p.keyboard.press('Escape'); await sleep(200);
    // with a browser install box: our button calls prompt()
    const prompted = await p.evaluate(async () => {
      let called = false; window.__aboInstallEvent = { prompt() { called = true; }, userChoice: Promise.resolve({ outcome: 'accepted' }) };
      document.querySelector('.auth-install').click(); await new Promise((r) => setTimeout(r, 300)); return called;
    });
    ok('with a browser install box (Chrome / Edge / Samsung), the Install link opens it', prompted);
    await p.close();

    // ── layout lock on a phone ──
    const ctx = await browser.createBrowserContext(); const m = await ctx.newPage(); await m.setUserAgent(ANDROID_UA); await m.setViewport(PHONE);
    m.on('pageerror', (e) => errors.push('phone: ' + e.message));
    await login(m, 'bopc.teacher1');
    let s = await layoutState(m);
    ok('phone starts in the phone layout (menu button + bottom bar)', s.w === 390 && s.menuBtn !== 'none' && s.bottom !== 'none', JSON.stringify(s));
    await m.tap('.user-chip'); await sleep(300);
    const item = await m.$('.layout-item'); ok('account menu offers the screen layout switch on a phone', !!item);
    await item.tap(); await sleep(700);
    s = await layoutState(m);
    ok('"computer layout" draws the page 1280 px wide with the full sidebar', s.w === 1280 && s.desktopClass && s.menuBtn === 'none' && s.bottom === 'none', JSON.stringify(s));
    await m.reload({ waitUntil: 'networkidle0' }); await sleep(800); s = await layoutState(m);
    ok('computer layout stays after a reload', s.w === 1280 && s.mode === 'desktop', JSON.stringify(s));
    await m.evaluate(() => { document.querySelector('meta[name=viewport]').content = 'width=device-width, initial-scale=1'; }); await sleep(200);   // something resets the page
    await m.evaluate(() => { Object.defineProperty(document, 'hidden', { configurable: true, get: () => false }); document.dispatchEvent(new Event('visibilitychange')); }); await sleep(500);
    s = await layoutState(m); ok('coming back to the tab puts the computer layout back', s.w === 1280, JSON.stringify(s));
    await m.evaluate(() => window.dispatchEvent(new Event('orientationchange'))); await sleep(500); s = await layoutState(m);
    ok('turning the phone keeps the computer layout', s.w === 1280, JSON.stringify(s));
    await sleep(3000); s = await layoutState(m); ok('still the computer layout after waiting', s.w === 1280, JSON.stringify(s));
    const m2 = await ctx.newPage(); await m2.setUserAgent(ANDROID_UA); await m2.setViewport(PHONE); await m2.goto(`${BASE}/#/`, { waitUntil: 'networkidle0' }); await sleep(800);
    s = await layoutState(m2); ok('a new tab on the same phone opens in the computer layout too', s.w === 1280, JSON.stringify(s)); await m2.close();
    // back to automatic
    await m.evaluate(() => window.aboLayout.set('auto')); await sleep(600); s = await layoutState(m);
    ok('choosing automatic brings the phone layout back', s.w === 390 && s.menuBtn !== 'none', JSON.stringify(s));
    await ctx.close();

    // ── browser "Desktop site" on a phone (desktop browser name + small touch screen) ──
    const c2 = await browser.createBrowserContext(); const d = await c2.newPage(); await d.setUserAgent(DESKTOP_UA); await d.setViewport(PHONE);
    await login(d, 'bopc.teacher1'); s = await layoutState(d);
    ok('browser "Desktop site" → computer layout', s.w === 1280 && s.menuBtn === 'none', JSON.stringify(s));
    await d.reload({ waitUntil: 'networkidle0' }); await sleep(1000); s = await layoutState(d);
    ok('browser "Desktop site" → computer layout after reload as well', s.w === 1280, JSON.stringify(s));
    await d.evaluate(() => { location.hash = '#/broadsheet/cumulative'; }); await idle(d); await sleep(2500); s = await layoutState(d);
    ok('browser "Desktop site" → still computer layout after moving around', s.w === 1280, JSON.stringify(s));
    await c2.close();

    // ── a real computer is unaffected ──
    const c3 = await browser.createBrowserContext(); const k = await c3.newPage(); await k.setViewport({ width: 1366, height: 800 });
    await (await k.createCDPSession()).send('Emulation.setDeviceMetricsOverride', { width: 1366, height: 800, deviceScaleFactor: 1, mobile: false, screenWidth: 1366, screenHeight: 768 });   // a real laptop screen
    await login(k, 'bopc.teacher1'); s = await layoutState(k);
    ok('computer: normal layout, no layout switch in the menu', s.w === 1366 && s.mode === 'auto' && !(await k.$('.layout-item')), JSON.stringify(s));
    await c3.close();
  } catch (e) { problems.push('crash ' + e.stack); console.error(e); }
  ok('no script errors', errors.length === 0, errors.join(' | '));
  await browser.close();
  console.log(`\n${results.filter(Boolean).length}/${results.length} passed`);
  process.exit(problems.length ? 1 : 0);
})();
