'use strict';
// Simpler navigation (page groups with tabs, Newsletters merged into Announcements, Annual merged into Cumulative)
// and sharing an announcement with parents on WhatsApp / email. Usage: BASE_URL=http://127.0.0.1:8080 node server/test/e2e/nav_share.qa.js
const puppeteer = require('puppeteer');
const totp = require('../../src/security/totp');
const fs = require('node:fs');
const BASE = process.env.BASE_URL || 'http://127.0.0.1:8080';
const PW = process.env.DEMO_PASSWORD || 'Demo#School2026';
const SHOTS = process.env.SHOTS || '/tmp/nav-share-shots'; fs.mkdirSync(SHOTS, { recursive: true });
const results = []; const problems = [];
const ok = (n, c, x = '') => { results.push(!!c); if (!c) problems.push(`${n} ${x}`); console.log(`${c ? '✔' : '✖'} ${n}${c ? '' : ' — ' + x}`); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const idle = async (p) => { await p.waitForNetworkIdle({ idleTime: 300, timeout: 15000 }).catch(() => {}); await sleep(250); };
const secrets = {};
async function login(p, id) {
  await p.goto(`${BASE}/#/login`, { waitUntil: 'networkidle0' }); await p.waitForSelector('input[name="loginId"]');
  await p.type('input[name="loginId"]', id); await p.type('input[name="password"]', PW); await p.click('button[type="submit"]'); await idle(p);
  if (await p.$('.code-box')) {
    const secret = (await p.$eval('.code-box', (e) => e.textContent)).replace(/\s+/g, ''); secrets[id] = secret;
    await p.type('input[name="code"]', totp.hotp(secret, totp.stepAt())); await p.click('button[type="submit"]'); await idle(p);
    await p.evaluate(() => { const b = [...document.querySelectorAll('button')].find((x) => x.textContent.includes('I have saved them')); if (b) b.click(); }); await idle(p);
  } else if (await p.$('input[name="code"]') && secrets[id]) {
    await p.type('input[name="code"]', totp.hotp(secrets[id], totp.stepAt() + 1)); await p.click('button[type="submit"]'); await idle(p);
  }
  await p.waitForSelector('.sidebar', { timeout: 15000 });
}
const go = async (p, hash) => { await p.evaluate((x) => { location.hash = x; }, hash); await idle(p); };
const menuTexts = (p) => p.$$eval('.sidebar a.nav-item', (as) => as.map((a) => (a.dataset.full || a.textContent).trim()));
const tabs = (p) => p.$$eval('.hub-tabs .hub-tab', (as) => as.map((a) => ({ t: a.textContent.trim(), on: a.classList.contains('active') })));

(async () => {
  const browser = await puppeteer.launch({ headless: 'shell', args: ['--no-sandbox'] }); require('./phone')(browser);
  const errors = [];
  try {
    const ctx = await browser.createBrowserContext(); const p = await ctx.newPage(); await p.setViewport({ width: 1440, height: 900 });
    p.on('pageerror', (e) => errors.push(e.message)); p.on('console', (m) => { if (m.type() === 'error' && !/40[134]|410/.test(m.text())) errors.push(m.text()); });
    await p.evaluateOnNewDocument(() => { try { localStorage.setItem('abo.words', 'full'); } catch { /* */ } });
    await login(p, 'bopc.owner');
    const menu = await menuTexts(p);
    for (const gone of ['Newsletters', 'Annual Broadsheet', 'Terminal Broadsheet', 'Subject Broadsheet', 'Position & Ranking', 'Print & PDF', 'Exam Score Entry', 'Result Approval', 'Result Publishing', 'Subject Performance', 'Performance Charts', 'Terms', 'Logo & Branding', 'Import & Export', 'Legacy Migration', 'Teacher Accounts', 'Live Classes', 'Add Student', 'Student Profile', 'Staff Records', 'Write Lesson Note', 'Review Queue', 'Create Examination', 'Question Bank', 'Student Report', 'Class Reports', 'Invoices', 'Petty Cash', 'Sell Items', 'Roles & Permissions', 'Sign In As Someone', 'Audit Logs', 'Security Events', 'School Profile', 'General Settings', 'Staff Clock-in', 'Devices', 'Birthdays', 'Old Debts'])
      ok(`menu no longer repeats "${gone}" (it is a tab of its group now)`, !menu.includes(gone));
    for (const here of ['Messages & Notices', 'Class Broadsheet', 'Cumulative Results', 'Report Cards', 'Score Entry', 'Result Workflow', 'Analytics', 'Staff & Teachers', 'Classes & Subjects', 'School Settings', 'Backup & Data', 'Lessons & Materials', 'Students', 'Attendance', 'CBT Examinations', 'Fees & Payments', 'Cashbook', 'Users & Roles', 'Activity & Security'])
      ok(`menu has "${here}"`, menu.includes(here));
    console.log(`  owner menu links: ${menu.length}`);
    // broadsheet group
    await go(p, '#/broadsheet');
    let t = await tabs(p);
    ok('Class Broadsheet shows its 5 tabs (Totals, CA & Exam, One Subject, Positions, Sheet Layout)', t.map((x) => x.t).join('|') === 'Totals|CA & Exam|One Subject|Positions|Sheet Layout' && t[0].on, JSON.stringify(t));
    const term2 = await p.evaluate(() => { const s = document.querySelector('select[name="termId"]'); const o = [...s.options].find((x) => /2nd/i.test(x.textContent)); s.value = o.value; s.dispatchEvent(new Event('change', { bubbles: true })); return o.value; }); await idle(p);
    await p.click('.hub-tab:nth-child(2)'); await idle(p);
    ok('tab "CA & Exam" opens the CA/Exam broadsheet', /#\/broadsheet\/terminal/.test(p.url()) && /Terminal Broadsheet/.test(await p.$eval('.page-head h1', (e) => e.textContent)), p.url());
    ok('the chosen term is kept when switching tabs', (await p.$eval('select[name="termId"]', (e) => e.value)) === term2);
    ok('the menu keeps "Class Broadsheet" highlighted', (await p.$eval('.sidebar a.nav-item.active', (e) => e.dataset.full || e.textContent)).trim() === 'Class Broadsheet');
    // annual → cumulative 3rd term
    await go(p, '#/broadsheet/annual'); await sleep(500);
    ok('old Annual Broadsheet link opens Cumulative Results on 3rd term', /#\/broadsheet\/cumulative/.test(p.url()) && /3rd/i.test(await p.$eval('select[name="termId"]', (e) => e.selectedOptions[0].textContent)), p.url());
    // other groups
    // 12 Oct 2026: repeated entries merged — one menu entry per group, its pages as tabs
    for (const [hash, want] of [['#/results/processing', 3], ['#/analytics/classes', 4], ['#/teachers', 5], ['#/academic/sessions', 6], ['#/school/profile', 6], ['#/backup', 3], ['#/reports/class', 4], ['#/scores/ca', 2], ['#/materials', 6], ['#/cbt/results', 8],
      ['#/students', 5], ['#/attendance', 4], ['#/fees', 5], ['#/cashbook', 3], ['#/store', 3], ['#/announcements', 2], ['#/users', 3], ['#/audit', 2], ['#/calendar', 2]]) {
      await go(p, hash); t = await tabs(p); ok(`${hash} shows ${want} tabs`, t.length === want && t.some((x) => x.on), JSON.stringify(t));
    }
    // newsletters → announcements
    await go(p, '#/newsletters'); await sleep(400);
    ok('old Newsletters link lands on Announcements', /#\/announcements/.test(p.url()), p.url());
    // new announcement → share dialog
    await p.evaluate(() => [...document.querySelectorAll('.page-actions button')].find((b) => /New announcement/.test(b.textContent)).click()); await sleep(400);
    await p.type('.modal input[name="title"]', 'Inter-house sports');
    await p.type('.modal textarea[name="body"]', 'Inter-house sports holds on Saturday 18 October at 9am. Parents are welcome.');
    await p.select('.modal select[name="audience"]', 'parents');
    await p.evaluate(() => [...document.querySelectorAll('.modal .modal-foot button')].find((b) => /Save/.test(b.textContent)).click()); await idle(p); await sleep(600);
    const sh = await p.evaluate(() => { const m = document.querySelector('.modal'); if (!m) return null; const wa = m.querySelector('a.btn-primary[href^="https://wa.me/?text="]'); return { title: m.querySelector('h2').textContent, wa: !!wa, preview: (m.querySelector('.share-preview') || {}).textContent || '', parents: m.querySelectorAll('.share-list tbody tr').length, perParent: m.querySelectorAll('.share-list a[href^="https://wa.me/234"]').length, email: [...m.querySelectorAll('button')].some((b) => /^Email \d+ parent/.test(b.textContent.trim())) }; });
    ok('after posting, the share box opens', sh && /Share: Inter-house sports/.test(sh.title), JSON.stringify(sh));
    ok('WhatsApp: one-tap share with the message ready (group / broadcast list)', sh && sh.wa && /Inter-house sports holds on Saturday/.test(sh.preview));
    ok('WhatsApp: parent-by-parent buttons with Nigerian numbers in WhatsApp format', sh && sh.parents >= 1 && sh.perParent >= 1, JSON.stringify(sh));
    await p.screenshot({ path: `${SHOTS}/share-dialog.png` });
    ok('email button is offered', sh && sh.email);
    const mailBtn = await p.evaluateHandle(() => [...document.querySelectorAll('.modal button')].find((b) => /^Email \d+ parent/.test(b.textContent.trim())));
    await mailBtn.asElement().click(); await idle(p); await sleep(500);
    ok('email to parents is queued and confirmed', await p.evaluate(() => /Emailed to \d+ parent/.test(document.querySelector('.modal').textContent) || /Email queued/.test(document.body.textContent)));
    await p.keyboard.press('Escape'); await sleep(300); await go(p, '#/'); await go(p, '#/announcements');
    ok('the notice shows it was emailed', await p.evaluate(() => [...document.querySelectorAll('.card')].some((c) => /Inter-house sports/.test(c.textContent) && /emailed to \d+/.test(c.textContent))));
    // draft → publish
    await p.evaluate(() => [...document.querySelectorAll('.page-actions button')].find((b) => /New announcement/.test(b.textContent)).click()); await sleep(400);
    await p.type('.modal input[name="title"]', 'Term letter (draft)'); await p.type('.modal textarea[name="body"]', 'Dear parents, the full term letter.');
    await p.click('.modal input[name="draft"]');
    await p.evaluate(() => [...document.querySelectorAll('.modal .modal-foot button')].find((b) => /Save/.test(b.textContent)).click()); await idle(p); await sleep(500);
    if (await p.$('.modal')) { const txt = await p.$eval('.modal', (e) => e.textContent); if (/Share/.test(txt)) { await p.keyboard.press('Escape'); await sleep(200); } }
    ok('a draft shows a Draft badge and a Publish button', await p.evaluate(() => [...document.querySelectorAll('.card')].some((c) => /Term letter \(draft\)/.test(c.textContent) && /draft/i.test(c.querySelector('.card-actions').textContent) && [...c.querySelectorAll('button')].some((b) => b.textContent.trim() === 'Publish'))));
    await ctx.close();

    // parent portal
    const c2 = await browser.createBrowserContext(); const pp = await c2.newPage(); await pp.setViewport({ width: 1280, height: 900 });
    pp.on('pageerror', (e) => errors.push('parent: ' + e.message));
    await pp.evaluateOnNewDocument(() => { try { localStorage.setItem('abo.words', 'full'); } catch { /* */ } });
    await login(pp, 'bopc.parent');
    const pm = await menuTexts(pp);
    ok('parent menu: no Newsletters; Learning and Timetable & Calendar are single entries', !pm.includes('Newsletters') && pm.includes('Learning') && pm.includes('Timetable & Calendar') && !pm.includes('Live Classes') && !pm.includes('School Calendar'), JSON.stringify(pm));
    await go(pp, '#/materials'); t = await tabs(pp);
    ok('parent "Learning" has tabs Notes & Videos, Live Classes, Lesson Notes', t.map((x) => x.t).join('|') === 'Notes & Videos|Live Classes|Lesson Notes', JSON.stringify(t));
    await go(pp, '#/timetable'); t = await tabs(pp); ok('parent "Timetable & Calendar" has 2 tabs', t.length === 2, JSON.stringify(t));
    await go(pp, '#/announcements');
    const pa = await pp.evaluate(() => ({ sports: /Inter-house sports/.test(document.body.textContent), draft: /Term letter \(draft\)/.test(document.body.textContent), share: [...document.querySelectorAll('button')].some((b) => /Share with parents/.test(b.textContent)) }));
    ok('parent sees the published notice, not the draft, and no share buttons', pa.sports && !pa.draft && !pa.share, JSON.stringify(pa));
    await c2.close();

    // phone
    const c3 = await browser.createBrowserContext(); const m = await c3.newPage(); await m.setViewport({ width: 390, height: 844, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
    m.on('pageerror', (e) => errors.push('phone: ' + e.message));
    await login(m, 'bopc.owner');
    await go(m, '#/teachers');
    ok('phone: tabs row scrolls inside itself (page does not slide sideways)', await m.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1));
    await m.tap('.hub-tab:nth-child(2)'); await idle(m);
    ok('phone: tapping a tab opens that page', /#\/staff$/.test(m.url()), m.url());
    await go(m, '#/announcements');
    await m.evaluate(() => [...document.querySelectorAll('button')].find((b) => /Share with parents/.test(b.textContent)).click()); await idle(m); await sleep(400);
    const fit = await m.evaluate(() => { const r = document.querySelector('.modal').getBoundingClientRect(); return { l: r.left, r: r.right, b: r.bottom, W: innerWidth, H: innerHeight }; });
    ok('phone: share box fits the screen', fit.l >= 0 && fit.r <= fit.W + 1 && fit.b <= fit.H + 1, JSON.stringify(fit));
    await m.screenshot({ path: `${SHOTS}/phone-share.png` });
    await c3.close();
  } catch (e) { problems.push('crash ' + e.stack); console.error(e); }
  ok('no script errors', errors.length === 0, errors.join(' | '));
  await browser.close();
  console.log(`\n${results.filter(Boolean).length}/${results.length} passed`);
  process.exit(problems.length ? 1 : 0);
})();
