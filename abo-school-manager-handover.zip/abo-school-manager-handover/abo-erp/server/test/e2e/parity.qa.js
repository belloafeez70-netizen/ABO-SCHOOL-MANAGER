'use strict';
// The last offline-edition features, online (027, 12 Oct 2026) in a real browser: Old Debts (paste → check → bills),
// Petty Cash (teacher asks → owner approves → bursar hands out → settles), Questions from Teachers, Reminders & Alerts,
// Devices, Print Centre (register, attendance, stock, ledger), Score Sheet Layout applied to the score sheet, the menu for
// each role, the offline app's data found on the same device, and a phone check. Usage: BASE_URL=… node parity.qa.js
const puppeteer = require('puppeteer');
const totp = require('../../src/security/totp');
const BASE = process.env.BASE_URL || 'http://127.0.0.1:8080';
const PW = process.env.DEMO_PASSWORD || 'Demo#School2026';
const results = []; const problems = [];
const ok = (n, c, x = '') => { results.push(!!c); if (!c) problems.push(`${n} ${x}`); console.log(`${c ? '✔' : '✖'} ${n}${c ? '' : ' — ' + x}`); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const idle = async (p) => { await p.waitForNetworkIdle({ idleTime: 300, timeout: 15000 }).catch(() => {}); await sleep(250); };
const secrets = {};
const SHOT = async (p, name) => { if (process.env.SHOTS) { require('node:fs').mkdirSync(process.env.SHOTS, { recursive: true }); await p.screenshot({ path: `${process.env.SHOTS}/${name}.png` }); } };
async function login(p, id) {
  await p.goto(`${BASE}/#/login`, { waitUntil: 'networkidle0' }); await p.waitForSelector('input[name="loginId"]');
  await p.type('input[name="loginId"]', id); await p.type('input[name="password"]', PW); await p.click('button[type="submit"]'); await idle(p);
  if (await p.$('.code-box')) {
    const secret = (await p.$eval('.code-box', (e) => e.textContent)).replace(/\s+/g, ''); secrets[id] = secret;
    await p.type('input[name="code"]', totp.hotp(secret, totp.stepAt())); await p.click('button[type="submit"]'); await idle(p);
    await p.evaluate(() => { const b = [...document.querySelectorAll('button')].find((x) => x.textContent.includes('I have saved them')); if (b) b.click(); }); await idle(p);
  } else if (await p.$('input[name="code"]') && secrets[id]) { await p.type('input[name="code"]', totp.hotp(secrets[id], totp.stepAt() + 1)); await p.click('button[type="submit"]'); await idle(p); }
  await p.waitForSelector('.sidebar', { timeout: 15000 });
}
// same address again ⇒ add a throw-away parameter so the page really reloads (the app ignores unknown parameters)
const go = async (p, hash) => { await p.evaluate((x) => { location.hash = location.hash === x ? `${x}${x.includes('?') ? '&' : '?'}r=${Date.now()}` : x; }, hash); await idle(p); };
const text = (p) => p.evaluate(() => (document.querySelector('#view') || document.body).innerText);
const clickBtn = (p, re, scope = 'body') => p.evaluate((r, s) => { const b = [...document.querySelectorAll(`${s} button`)].find((x) => new RegExp(r).test(x.textContent.trim()) && !x.disabled); if (b) { b.click(); return true; } return false; }, re.source || re, scope);
// call the API from inside the page, exactly like the app does (cookie + CSRF header)
const call = (p, method, path, body) => p.evaluate(async (m, u, b) => {
  const me = await (await fetch('/api/v1/auth/me', { credentials: 'include' })).json();
  const r = await fetch('/api/v1' + u, { method: m, credentials: 'include', headers: { 'content-type': 'application/json', 'x-csrf-token': me.csrf || '' }, body: b ? JSON.stringify(b) : undefined });
  return { status: r.status, body: await r.json().catch(() => null) };
}, method, path, body);
const menuOf = (p) => p.$$eval('.sidebar a.nav-item', (as) => as.map((a) => (a.dataset.full || a.textContent).trim()));

(async () => {
  const browser = await puppeteer.launch({ headless: 'shell', args: ['--no-sandbox'] }); require('./phone')(browser);
  const errors = [];
  const page = async (label, mobile) => {
    const ctx = await browser.createBrowserContext(); const p = await ctx.newPage();
    await p.setViewport(mobile ? { width: 390, height: 844, isMobile: true, hasTouch: true, deviceScaleFactor: 2 } : { width: 1366, height: 860 });
    p.on('pageerror', (e) => errors.push(`${label}: ${e.message}`)); p.on('console', (m) => { if (m.type() === 'error' && !/40[0-9]|Failed to load resource/.test(m.text())) errors.push(`${label}: ${m.text()}`); });
    p.on('dialog', (d) => d.accept());
    await p.evaluateOnNewDocument(() => { try { localStorage.setItem('abo.words', 'full'); } catch { /* */ } });
    return p;
  };
  try {
    // ── owner ──
    const O = await page('owner'); await login(O, 'bopc.owner');
    const om = await menuOf(O);
    ok('owner menu has Reminders & Alerts and Print Centre', ['Reminders & Alerts', 'Print Centre'].every((x) => om.includes(x)), JSON.stringify(om.filter((m) => /Alert|Print/.test(m))));
    // the other new pages are tabs of their group (repeated menu entries merged, 12 Oct 2026)
    const tabsAt = async (hash) => { await go(O, hash); return O.$$eval('.hub-tab', (as) => as.map((a) => a.textContent.trim())); };
    ok('Old Debts is a tab of Fees & Payments', (await tabsAt('#/fees')).includes('Old Debts'));
    ok('Petty Cash is a tab of the Cashbook', (await tabsAt('#/cashbook')).includes('Petty Cash'));
    ok('Devices is a tab of Attendance', (await tabsAt('#/attendance')).includes('Devices'));

    // Old Debts: paste two lines + one unknown → check → create
    const kids = (await call(O, 'GET', '/students?pageSize=3')).body.items;
    await go(O, '#/fees/arrears');
    ok('Old Debts page opens', /Old Debts/.test(await text(O)));
    await clickBtn(O, /^Add old debts$/); await sleep(400);
    await O.evaluate((lines) => { const ta = document.querySelector('.modal textarea'); ta.value = lines; }, `Admission No, Amount, Note\n${kids[0].admission_no}, 15000, second term balance\n${kids[1].first_name} ${kids[1].last_name}, JSS 1, 2500\nNobody Known, 100`);
    await clickBtn(O, /^Check$/, '.modal'); await idle(O);
    const pv = await O.evaluate(() => document.querySelector('.modal').innerText);
    ok('the check finds the two learners and flags the unknown name', /2 ready/.test(pv) && /not found/i.test(pv) && /₦17,500/.test(pv), pv.slice(0, 300));
    await clickBtn(O, /^Create bills$/, '.modal'); await idle(O);
    const od = await text(O);
    await SHOT(O, 'old-debts');
    ok('two old-debt bills are created and listed', /BFW-\d{4}-0000\d\d/.test(od) && /second term balance/.test(od) && /₦17,500/.test(od), od.slice(0, 400));

    // Devices
    await go(O, '#/devices'); await clickBtn(O, /^Add a device$/); await sleep(300);
    await O.evaluate(() => { const m = document.querySelector('.modal'); m.querySelector('input[name="name"]').value = 'Gate fingerprint reader'; m.querySelector('select[name="kind"]').value = 'fingerprint'; m.querySelector('input[name="serial"]').value = 'ZK-QA-01'; });
    await clickBtn(O, /^Save$/, '.modal'); await idle(O);
    ok('a device is added and listed', /Gate fingerprint reader/.test(await text(O)) && /Fingerprint reader/.test(await text(O)));

    // Print Centre + documents
    await go(O, '#/print-centre');
    await SHOT(O, 'print-centre');
    const pc = await O.$$eval('.print-card h2', (x) => x.map((e) => e.textContent));
    ok('Print Centre lists the documents (score sheet, register, stock, ledger…)', pc.length >= 10 && pc.includes('Blank attendance register') && pc.includes('Cash ledger'), JSON.stringify(pc));
    await go(O, '#/print/register');
    await O.evaluate(() => { const s = document.querySelector('#view select'); s.value = s.options[1].value; s.dispatchEvent(new Event('change')); }); await idle(O);
    ok('blank register prints the class list with day columns', await O.evaluate(() => document.querySelectorAll('table.register tbody tr').length > 0 && document.querySelectorAll('table.register thead th.reg-day').length === 10));
    ok('the print centre pages share one tab row', await O.evaluate(() => [...document.querySelectorAll('.hub-tab')].map((a) => a.textContent).join('|')) === 'All Documents|Blank Register|Attendance Report|Stock Sheet|Cash Ledger');
    await go(O, '#/print/attendance');
    await O.evaluate(() => { const s = document.querySelector('#view select'); s.value = s.options[1].value; s.dispatchEvent(new Event('change')); }); await idle(O);
    ok('attendance report prints', await O.evaluate(() => /Attendance report/.test(document.querySelector('.doc').innerText) && document.querySelectorAll('.doc tbody tr').length > 0));
    await go(O, '#/print/stock'); ok('stock sheet prints', await O.evaluate(() => !!document.querySelector('.doc') && /Total value/.test(document.querySelector('.doc').innerText)));
    await go(O, '#/print/ledger'); ok('cash ledger prints with opening and closing balance', await O.evaluate(() => /Opening balance/.test(document.body.innerText) && /Closing balance/.test(document.body.innerText)));

    // Score sheet layout → the score sheet follows it
    await go(O, '#/broadsheet/layout'); await clickBtn(O, /^Change layout$/); await sleep(300);
    await O.evaluate(() => { const m = document.querySelector('.modal'); m.querySelector('input[name="title"]').value = 'End of Term Score Sheet QA'; m.querySelector('input[name="showStatus"]').checked = false;
      m.querySelector('input[name="showBreakdown"]').checked = false; m.querySelector('textarea[name="footer"]').value = 'Principal: __________'; });
    await clickBtn(O, /^Save$/, '.modal'); await idle(O);
    await go(O, '#/broadsheet/terminal'); await idle(O); await sleep(800);
    const sheet = await O.evaluate(() => { const d = document.querySelector('.doc'); if (!d) return null; return { t: d.querySelector('h2').textContent, heads: [...d.querySelectorAll('thead th')].map((x) => x.textContent), foot: d.innerText }; });
    ok('the score sheet uses the chosen title, no Status column, no CA/EX split, and the footer', sheet && /End of Term Score Sheet QA/.test(sheet.t) && !sheet.heads.includes('Status') && !sheet.heads.includes('CA') && /Principal: _+/.test(sheet.foot), JSON.stringify(sheet && { t: sheet.t, heads: sheet.heads.slice(0, 8) }));
    ok('the Sheet Layout tab sits with the other score sheet tabs', await O.evaluate(() => [...document.querySelectorAll('.hub-tab')].some((a) => a.textContent === 'Sheet Layout')));
    await call(O, 'PUT', '/broadsheet/layout', { showStatus: true, showBreakdown: true, title: '', footer: '' });

    // ── teacher asks for petty cash; adds a bank question while approval is on ──
    const T = await page('teacher'); await login(T, 'bopc.teacher1');
    const tm = await menuOf(T);
    ok('teacher sees Petty Cash but not Old Debts, Devices or Reminders', tm.includes('Petty Cash') && !tm.includes('Old Debts') && !tm.includes('Devices') && !tm.includes('Reminders & Alerts'), JSON.stringify(tm.filter((m) => /Debt|Petty|Alert|Device/.test(m))));
    await go(T, '#/petty-cash'); await clickBtn(T, /^Ask for petty cash$/); await sleep(300);
    await T.evaluate(() => { const m = document.querySelector('.modal'); m.querySelector('textarea[name="purpose"]').value = 'Chalk and markers for Basic 1'; m.querySelector('input[name="amount"]').value = '4500'; });
    await clickBtn(T, /^Send request$/, '.modal'); await idle(T);
    ok('teacher\'s request is listed as waiting for approval', /PCR-\d{4}-\d{6}/.test(await text(T)) && /pending/i.test(await text(T)));
    ok('the teacher has no approve button on their own request', !(await T.evaluate(() => [...document.querySelectorAll('#view button')].some((b) => b.textContent.trim() === 'Approve'))));

    // owner approves in the page
    await go(O, '#/petty-cash');
    ok('owner sees the request with Approve / Refuse', await O.evaluate(() => /Chalk and markers/.test(document.body.innerText) && [...document.querySelectorAll('#view button')].some((b) => b.textContent.trim() === 'Approve')));
    await clickBtn(O, /^Approve$/, '#view'); await idle(O);
    ok('approved → "Hand out" is offered to the cashier', await O.evaluate(() => [...document.querySelectorAll('#view button')].some((b) => b.textContent.trim() === 'Hand out')));
    // top up the box, hand out, settle with change
    const cats = (await call(O, 'GET', '/cashbook/categories')).body.items;
    const today = await O.evaluate(() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; });
    await call(O, 'POST', '/cashbook/entries', { kind: 'income', categoryId: cats.find((c) => c.name === 'Money into petty cash').id, amountKobo: 1000000, entryDate: today, method: 'petty_cash', description: 'Top up petty cash' });
    await go(O, '#/petty-cash'); await clickBtn(O, /^Hand out$/, '#view'); await sleep(400);
    await O.evaluate(() => { const s = document.querySelector('.modal select[name="categoryId"]'); s.value = [...s.options].find((o) => /Stationery/.test(o.textContent)).value; });
    await clickBtn(O, /^Money handed out$/, '.modal'); await idle(O);
    await clickBtn(O, /^Settle$/, '#view'); await sleep(400);
    await O.evaluate(() => { document.querySelector('.modal input[name="spent"]').value = '3000'; });
    await clickBtn(O, /^Settle$/, '.modal'); await idle(O);
    await SHOT(O, 'petty-cash');
    const pcText = await text(O);
    ok('settled: ₦3,000 spent, ₦1,500 change back; box ₦10,000 − ₦3,000 = ₦7,000', /Spent ₦3,000/.test(pcText) && /change ₦1,500/.test(pcText) && /₦7,000/.test(pcText), pcText.slice(0, 500));

    // ── questions from teachers ──
    const X = await page('exams'); await login(X, 'bopc.exams');
    await go(X, '#/cbt/review');
    if (/Switch on/.test(await text(X))) { await clickBtn(X, /^Switch on$/); await idle(X); }
    ok('exam officer switches approval on', /On — questions from teachers wait here/.test(await text(X)));
    const qr = await call(T, 'POST', '/cbt/bank', { type: 'mcq', text: 'QA: Which city is the capital of Nigeria?', options: [{ text: 'Abuja', isCorrect: true }, { text: 'Lagos' }, { text: 'Kano' }] });
    ok('teacher\'s new question waits for approval', qr.status === 200 && qr.body.status === 'pending', JSON.stringify(qr));
    await go(T, '#/cbt/bank?status=pending'); await idle(T);
    await go(X, '#/cbt/review');
    await SHOT(X, 'question-review');
    ok('the waiting question shows with its answer', /capital of Nigeria/.test(await text(X)) && await X.evaluate(() => !!document.querySelector('.q-options li.correct')));
    await clickBtn(X, /^Approve into the bank$/); await idle(X);
    ok('approved → no question waiting', /No question is waiting/.test(await text(X)));
    const inBank = (await call(T, 'GET', '/cbt/bank?q=capital%20of%20Nigeria')).body.items;
    ok('the approved question is in the shared bank', inBank.some((q) => /QA: Which city/.test(q.text) && q.status === 'active'));
    await clickBtn(X, /^Switch off$/); await idle(X);

    // ── reminders & alerts ──
    await call(O, 'PUT', '/alerts/rules', { feeOverdueDays: 0 });
    await go(O, '#/alerts');
    await SHOT(O, 'alerts');
    const al = await text(O);
    ok('Reminders & Alerts shows overdue fees (the old debts), with a reminder button and the rules', /Fees overdue/.test(al) && /BFW-/.test(al) && /Remind all these parents/.test(al) && /Change rules/.test(al), al.slice(0, 400));
    await clickBtn(O, /^Remind all these parents$/); await sleep(400);
    ok('it asks before sending', /Send fee reminders\?/.test(await O.evaluate(() => (document.querySelector('.modal') || {}).innerText || '')));
    await clickBtn(O, /^Send reminders$/, '.modal'); await sleep(900);
    const toastText = await O.evaluate(() => [...document.querySelectorAll('.toast')].map((t) => t.textContent).join(' | '));
    ok('reminders: the result is reported (sent / already reminded / no parent contact)', /\d+ reminder\(s\) sent/.test(toastText), toastText);
    await idle(O);
    const sentNow = await call(O, 'POST', '/alerts/fee-reminders', {});
    ok('pressing it again the same day reminds nobody twice', sentNow.status === 200 && sentNow.body.sent === 0, JSON.stringify(sentNow.body));

    // ── the offline app's data on the same device → Move it in ──
    await O.evaluate(() => localStorage.setItem('broadsheetData_QA_Offline_School', JSON.stringify({ schoolData: { name: 'QA Offline School', erp: { learners: { 'BASIC 1A': [{ name: 'Ada Obi', admissionNo: 'QA/001', gender: 'F' }, { name: 'Tunde Bello', admissionNo: 'QA/002', gender: 'M' }] } } } })));
    await go(O, '#/migrate');
    ok('the import page finds the offline app\'s data on this device', /Found on this device/.test(await text(O)) && /QA Offline School/.test(await text(O)));
    await clickBtn(O, /^Preview moving this school$/); await idle(O);
    ok('one click previews moving it (2 learners, 1 class) — nothing committed yet', await O.evaluate(() => [...document.querySelectorAll('.card')].some((c) => /^Preview/i.test((c.querySelector('h2') || {}).textContent || '') && /learners\s*2/i.test(c.innerText) && /Commit migration/.test(c.innerText))), (await text(O)).slice(-600));
    await O.evaluate(() => localStorage.removeItem('broadsheetData_QA_Offline_School'));

    // ── phone ──
    const M = await page('phone', true); await login(M, 'bopc.owner');
    for (const h of ['#/petty-cash', '#/alerts', '#/fees/arrears', '#/print-centre']) {
      await go(M, h);
      ok(`phone: ${h} fits the screen (no sideways scrolling)`, await M.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1), String(await M.evaluate(() => document.documentElement.scrollWidth)));
    }
  } catch (e) { problems.push('crash ' + e.stack); console.error(e); }
  ok('no script errors', errors.length === 0, errors.join(' | '));
  await browser.close();
  console.log(`\n${results.filter(Boolean).length}/${results.length} passed`);
  process.exit(problems.length ? 1 : 0);
})();
