'use strict';
// Browser QA (Phase 6): Staff clock-in with a real (emulated) phone position, School Calendar, Birthdays and Cashbook,
// signed in as the owner, teachers, the accountant and a pupil. Needs a running server on a fresh dev-reset database.
// Usage: BASE_URL=http://127.0.0.1:8080 node server/test/e2e/school_life.qa.js
const puppeteer = require('puppeteer');
const path = require('node:path');
const totp = require('../../src/security/totp');
const BASE = process.env.BASE_URL || 'http://127.0.0.1:8080';
const PW = process.env.DEMO_PASSWORD || 'Demo#School2026';
const SHOTS = process.env.SHOTS || path.join(__dirname, '../../../docs/screenshots');
const GATE = { latitude: 6.5244, longitude: 3.3792 }, NEAR = { latitude: 6.52461, longitude: 3.37932 }, FAR = { latitude: 6.6018, longitude: 3.3515 };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms)); let pass = 0; const problems = [];
const ok = (n, c, x = '') => { if (c) pass++; else problems.push(n + ' ' + x); console.log((c ? '✔ ' : '✖ ') + n + (c ? '' : ' — ' + String(x).slice(0, 300))); };

(async () => {
  const b = await puppeteer.launch({ headless: 'shell', acceptInsecureCerts: !!process.env.QA_IGNORE_TLS, args: ['--no-sandbox', '--disable-dev-shm-usage', ...(process.env.QA_IGNORE_TLS ? ['--ignore-certificate-errors'] : [])] }); require('./fullwords')(b);
  const errs = [];
  const open = async (loginId, geo) => {
    const ctx = await b.createBrowserContext(); await ctx.overridePermissions(BASE, ['geolocation']);
    const p = await ctx.newPage(); await p.setViewport({ width: 1366, height: 900 });
    if (geo) await p.setGeolocation({ ...geo, accuracy: 12 });
    p.on('pageerror', (e) => errs.push(`${loginId}: ${e.message}`)); p.on('console', (m) => { if (m.type() === 'error' && !/status of 4\d\d/.test(m.text())) errs.push(`${loginId}: ${m.text()}`); });
    await p.goto(`${BASE}/#/login`, { waitUntil: 'networkidle0' });
    await p.type('input[name="loginId"]', loginId); await p.type('input[name="password"]', PW); await p.click('button[type="submit"]'); await idle(p);
    if (await p.$('.code-box')) {
      const s = (await p.$eval('.code-box', (e) => e.textContent)).replace(/\s+/g, ''); await p.type('input[name="code"]', totp.hotp(s, totp.stepAt())); await p.click('button[type="submit"]'); await idle(p);
      await clickText(p, 'button', 'I have saved them'); await idle(p);
    }
    return p;
  };
  const idle = async (p) => { await p.waitForNetworkIdle({ idleTime: 300, timeout: 10000 }).catch(() => {}); await sleep(200); };
  const go = async (p, hash) => { const same = p.url().endsWith(hash); await p.goto(`${BASE}/${hash}`, { waitUntil: 'domcontentloaded' }); if (same) await p.reload({ waitUntil: 'domcontentloaded' }); await idle(p); };
  const text = (p) => p.evaluate(() => (document.querySelector('main') || document.body).innerText);
  async function clickText(p, sel, t) { for (const el of await p.$$(sel)) { if ((await el.evaluate((e) => e.textContent)).includes(t)) { await el.click(); return true; } } return false; }
  const toastText = (p) => p.evaluate(() => [...document.querySelectorAll('.toast')].map((e) => e.innerText).join(' | '));
  const fill = async (p, name, v) => p.evaluate((n, v) => { const el = document.querySelector(`.modal [name="${n}"]`); if (!el) return false; if (el.type === 'checkbox') el.checked = !!v; else el.value = v; el.dispatchEvent(new Event('change', { bubbles: true })); return true; }, name, v);
  const save = async (p, label = 'Save') => { await p.evaluate((l) => { const bs = [...document.querySelectorAll('.modal button')].filter((x) => x.textContent.trim() === l); bs[bs.length - 1].click(); }, label); await idle(p); await sleep(300); };

  try {
    // ── owner sets the clock-in rules from the school gate ──
    const O = await open('bopc.owner', GATE);
    await go(O, '#/clock');
    ok('owner: clock-in page with the register', /Clock-in register/.test(await text(O)) && /Not in yet/i.test(await text(O)));
    await clickText(O, 'button', 'Clock-in rules'); await sleep(500);
    await clickText(O, '.modal button', 'Use my location'); await sleep(1200);
    ok('owner: "Use my location" fills in the school position', await O.evaluate(() => Math.abs(Number(document.querySelector('.modal [name=siteLat]').value) - 6.5244) < 1e-4));
    await fill(O, 'requireLocation', true); await fill(O, 'radiusM', '150'); await fill(O, 'lateAfter', '23:59');
    await save(O, 'Save rules'); await sleep(1500);
    ok('owner: rules saved', /must be within 150 m|Clock-in register/.test(await text(O)), await toastText(O));
    await O.screenshot({ path: path.join(SHOTS, 'phase6-clock-owner.png') });

    // ── a teacher at school clocks in; a teacher 9 km away is refused ──
    const T = await open('bopc.teacher1', NEAR);
    await go(T, '#/clock');
    ok('teacher: sees the rule', /within 150 m of the school/.test(await text(T)), (await text(T)).slice(0, 300));
    await clickText(T, 'button', 'Clock in now'); await sleep(2500); await idle(T);
    ok('teacher at school: clocked in', /In at \d\d:\d\d/.test(await text(T)) && /Clock out now/.test(await text(T)), await toastText(T));
    await T.screenshot({ path: path.join(SHOTS, 'phase6-clock-teacher.png') });
    const T2 = await open('bopc.teacher2', FAR);
    await go(T2, '#/clock'); await clickText(T2, 'button', 'Clock in now'); await sleep(2500); await idle(T2);
    ok('teacher 9 km away: refused with the distance', /km from school/.test(await text(T2) + await toastText(T2)) && /Not clocked in yet/.test(await text(T2)), (await text(T2)).slice(0, 400));
    await go(O, '#/clock');
    const reg = await text(O);
    ok('owner: register shows the teacher on time and the other not in', /Mr Tunde Bello[\s\S]{0,80}on time/i.test(reg) && /Mrs Ngozi Okeke[\s\S]{0,80}not in yet/i.test(reg), reg.slice(reg.indexOf('Clock-in register'), reg.indexOf('Clock-in register') + 900));

    // ── calendar ──
    await go(O, '#/calendar');
    await clickText(O, 'button', 'Add event'); await sleep(500);
    const d = new Date(Date.now() + 3 * 864e5).toISOString().slice(0, 10);
    await fill(O, 'title', 'Inter-house sports'); await fill(O, 'kind', 'event'); await fill(O, 'startsOn', d); await save(O); await sleep(800);
    await clickText(O, 'button', 'Add event'); await sleep(500);
    await fill(O, 'title', 'Staff appraisal meeting'); await fill(O, 'kind', 'meeting'); await fill(O, 'audience', 'staff'); await fill(O, 'startsOn', d); await save(O); await sleep(800);
    ok('owner: two events on the calendar', /Inter-house sports/.test(await text(O)) && /Staff appraisal meeting/.test(await text(O)), (await text(O)).slice(0, 400));
    await O.screenshot({ path: path.join(SHOTS, 'phase6-calendar.png') });
    await go(T, '#/calendar');
    ok('teacher: sees both events, cannot add', /Staff appraisal meeting/.test(await text(T)) && !(await text(T)).includes('Add event'));
    const S = await open('bopc.student');
    await go(S, '#/calendar');
    ok('pupil: sees the sports day but not the staff meeting', /Inter-house sports/.test(await text(S)) && !/Staff appraisal meeting/.test(await text(S)), (await text(S)).slice(0, 300));
    ok('pupil: calendar is in the menu', await S.evaluate(() => [...document.querySelectorAll('a')].some((a) => a.getAttribute('href') === '#/calendar')));

    // ── birthdays ──
    await go(T, '#/birthdays');
    ok('teacher: birthdays page with tabs', /Birthdays/.test(await text(T)) && /Next 7 days/.test(await text(T)));

    // ── cashbook (accountant) ──
    const A = await open('bopc.accounts');
    await go(A, '#/cashbook');
    ok('accountant: cashbook page', /School fees received/i.test(await text(A)) && /Petty cash in the box/i.test(await text(A)), (await text(A)).slice(0, 300));
    await clickText(A, 'button', 'Money received'); await sleep(500);
    const pta = await A.evaluate(() => [...document.querySelectorAll('.modal [name=categoryId] option')].find((o) => o.textContent === 'PTA levy').value);
    await fill(A, 'categoryId', pta); await fill(A, 'amount', '25000'); await fill(A, 'description', 'PTA levy, JSS 1'); await fill(A, 'party', 'PTA treasurer'); await save(A); await sleep(1200);
    ok('accountant: money received shows in the totals', /₦25,000/.test(await text(A)) && /PTA levy, JSS 1/.test(await text(A)), (await text(A)).slice(0, 500));
    await clickText(A, 'button', 'Spend from petty cash'); await sleep(500);
    const food = await A.evaluate(() => [...document.querySelectorAll('.modal [name=categoryId] option')].find((o) => o.textContent === 'Food & refreshments').value);
    await fill(A, 'categoryId', food); await fill(A, 'amount', '2000'); await fill(A, 'description', 'Visitors'); await save(A); await sleep(1000);
    ok('accountant: cannot spend petty cash that is not there', await A.evaluate(() => /only ₦0\.00 in petty cash/.test((document.querySelector('.modal .form-alert, .modal .err') || {}).textContent || '') || /only ₦0\.00/.test(document.querySelector('.modal') ? document.querySelector('.modal').innerText : '')));
    await A.keyboard.press('Escape'); await sleep(300); await A.evaluate(() => { const c = [...document.querySelectorAll('.modal button')].find((x) => x.textContent.trim() === 'Cancel'); if (c) c.click(); }); await sleep(300);
    await clickText(A, 'button', 'Top up petty cash'); await sleep(500);
    await fill(A, 'amount', '10000'); await save(A); await sleep(1200);
    ok('accountant: petty cash topped up to ₦10,000', /Petty cash in the box\s*₦10,000/i.test(await text(A)), (await text(A)).slice(0, 600));
    await A.screenshot({ path: path.join(SHOTS, 'phase6-cashbook.png') });
    await go(A, '#/cashbook/categories');
    ok('accountant: categories page', /Money spent \(expenses\)/.test(await text(A)) && /Electricity & fuel/.test(await text(A)));
    await go(T, '#/cashbook');
    ok('teacher: cashbook is closed to teachers', /don’t have access|do not have permission/i.test(await text(T)), (await text(T)).slice(0, 200));
    ok('no console or page errors', errs.length === 0, errs.join(' | '));
  } finally { await b.close(); }
  console.log(`\n${pass} passed, ${problems.length} failed`); process.exit(problems.length ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
