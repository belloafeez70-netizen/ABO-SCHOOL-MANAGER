'use strict';
// Test helper: a software "phone" that creates a real WebAuthn passkey (P-256) and signs challenges exactly as a phone's
// fingerprint/face authenticator does (attestation "none", user present + user verified). Used to test the server's
// checks end to end without a browser. Not used by the app.
const crypto = require('node:crypto');
const b64u = (b) => Buffer.from(b).toString('base64url');
// minimal CBOR encoder: unsigned/negative ints, byte strings, text strings, maps
function head(major, n) {
  if (n < 24) return Buffer.from([(major << 5) | n]);
  if (n < 256) return Buffer.from([(major << 5) | 24, n]);
  if (n < 65536) { const b = Buffer.alloc(3); b[0] = (major << 5) | 25; b.writeUInt16BE(n, 1); return b; }
  const b = Buffer.alloc(5); b[0] = (major << 5) | 26; b.writeUInt32BE(n, 1); return b;
}
function cbor(v) {
  if (typeof v === 'number') return v >= 0 ? head(0, v) : head(1, -1 - v);
  if (Buffer.isBuffer(v) || v instanceof Uint8Array) return Buffer.concat([head(2, v.length), Buffer.from(v)]);
  if (typeof v === 'string') { const s = Buffer.from(v, 'utf8'); return Buffer.concat([head(3, s.length), s]); }
  if (v instanceof Map) return Buffer.concat([head(5, v.size), ...[...v].flatMap(([k, x]) => [cbor(k), cbor(x)])]);
  throw new Error('cbor: unsupported value');
}
function softPhone({ origin = 'http://localhost:8080', rpId = 'localhost' } = {}) {
  const { privateKey, publicKey } = crypto.generateKeyPairSync('ec', { namedCurve: 'P-256' });
  const jwk = publicKey.export({ format: 'jwk' });
  const credId = crypto.randomBytes(32); let counter = 0;
  const rpHash = crypto.createHash('sha256').update(rpId).digest();
  const cose = cbor(new Map([[1, 2], [3, -7], [-1, 1], [-2, Buffer.from(jwk.x, 'base64url')], [-3, Buffer.from(jwk.y, 'base64url')]]));
  return {
    credentialId: b64u(credId),
    register(options, { challenge = options.challenge, flags = 0x45, origin: o = origin } = {}) {
      const clientData = Buffer.from(JSON.stringify({ type: 'webauthn.create', challenge, origin: o, crossOrigin: false }));
      const len = Buffer.alloc(2); len.writeUInt16BE(credId.length);
      const authData = Buffer.concat([rpHash, Buffer.from([flags]), Buffer.alloc(4), Buffer.alloc(16), len, credId, cose]);
      const att = cbor(new Map([['fmt', 'none'], ['attStmt', new Map()], ['authData', authData]]));
      return { id: b64u(credId), rawId: b64u(credId), type: 'public-key', authenticatorAttachment: 'platform', clientExtensionResults: {},
        response: { clientDataJSON: b64u(clientData), attestationObject: b64u(att), transports: ['internal'] } };
    },
    sign(options, { challenge = options.challenge, flags = 0x05, origin: o = origin, key = privateKey } = {}) {
      counter += 1;
      const clientData = Buffer.from(JSON.stringify({ type: 'webauthn.get', challenge, origin: o, crossOrigin: false }));
      const cnt = Buffer.alloc(4); cnt.writeUInt32BE(counter);
      const authData = Buffer.concat([rpHash, Buffer.from([flags]), cnt]);
      const sig = crypto.sign('sha256', Buffer.concat([authData, crypto.createHash('sha256').update(clientData).digest()]), key);
      return { id: b64u(credId), rawId: b64u(credId), type: 'public-key', authenticatorAttachment: 'platform', clientExtensionResults: {},
        response: { clientDataJSON: b64u(clientData), authenticatorData: b64u(authData), signature: b64u(sig) } };
    },
    otherKey: () => crypto.generateKeyPairSync('ec', { namedCurve: 'P-256' }).privateKey,
  };
}
module.exports = { softPhone };
