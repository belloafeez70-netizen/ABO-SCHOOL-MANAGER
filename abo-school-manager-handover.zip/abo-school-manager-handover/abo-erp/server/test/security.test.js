'use strict';
const H = require('./helpers');
const test = require('node:test');
const assert = require('node:assert/strict');
let S, owner, bOwner, routes = [];
test.before(async () => {
  S = await H.setup();
  owner = await H.login(S.app, 'sa.owner'); bOwner = await H.login(S.app, 'sb.owner');
  routes = S.app.printRoutes({ commonPrefix: false }).split('\n');
});
test.after(() => H.teardown());

test('security headers on every response (CSP, frame, nosniff, referrer, permissions, COOP/CORP, no-store for API)', async () => {
  const r = await S.app.inject({ method: 'GET', url: '/api/v1/auth/me' });
  const h = r.headers;
  assert.match(h['content-security-policy'], /default-src 'self'/); assert.match(h['content-security-policy'], /script-src 'self'(;|$)/);
  assert.match(h['content-security-policy'], /frame-ancestors 'none'/); assert.match(h['content-security-policy'], /object-src 'none'/);
  assert.equal(h['x-frame-options'], 'DENY'); assert.equal(h['x-content-type-options'], 'nosniff');
  assert.equal(h['referrer-policy'], 'strict-origin-when-cross-origin'); assert.match(h['permissions-policy'], /camera=\(\)/);
  assert.equal(h['cross-origin-opener-policy'], 'same-origin'); assert.equal(h['cache-control'], 'no-store'); assert.equal(h['x-powered-by'], undefined);
});
test('errors never leak stack traces, SQL or internals', async () => {
  const r = await owner.get('/api/v1/students/not-a-uuid');
  assert.equal(r.status, 400); assert.ok(!/stack|pg|SELECT|node_modules/i.test(JSON.stringify(r.body))); assert.ok(r.body.error.requestId); assert.equal(typeof r.body.error.code, 'string');
  const nf = await owner.get('/api/v1/nope'); assert.equal(nf.status, 404);
  const bad = await S.app.inject({ method: 'POST', url: '/api/v1/auth/login', payload: '{"loginId":', headers: { 'content-type': 'application/json' } });
  assert.equal(bad.statusCode, 400); assert.ok(!/Unexpected|position|stack/i.test(bad.body));
});
test('SQL injection attempts are inert (parameterised queries + whitelisted sort)', async () => {
  for (const q of ["' OR 1=1 --", "x'); DROP TABLE students; --", '%', '\\', "admin'/*"]) {
    const r = await owner.get(`/api/v1/students?q=${encodeURIComponent(q)}`); assert.equal(r.status, 200); assert.equal(r.body.total, 0, q);
  }
  assert.equal((await owner.get(`/api/v1/students?sort=${encodeURIComponent('name; DROP TABLE students')}`)).status, 400);
  assert.equal((await owner.get('/api/v1/students?pageSize=100000')).status, 400, 'page size bounded');
  const login = await H.client(S.app).post('/api/v1/auth/login', { loginId: "' OR '1'='1", password: "' OR '1'='1" }); assert.ok([400, 401].includes(login.status));
  assert.equal((await owner.get('/api/v1/students?pageSize=1')).status, 200, 'students table still there');
});
test('request size limits and strict content types', async () => {
  const big = 'x'.repeat(1024 * 1024 + 10);
  const r = await owner.post('/api/v1/announcements', { title: 'big', body: big }); assert.equal(r.status, 413);
  const huge = await owner.post('/api/v1/documents', undefined, { multipart: H.multipart({ title: 'big' }, { name: 'a.pdf', data: Buffer.concat([Buffer.from('%PDF-1.4'), Buffer.alloc(6 * 1024 * 1024)]) }) });
  assert.ok([400, 413].includes(huge.status));
  const xml = await S.app.inject({ method: 'POST', url: '/api/v1/auth/login', payload: '<x/>', headers: { 'content-type': 'application/xml' } }); assert.equal(xml.statusCode, 415);
});
test('file uploads: magic-byte validation, disguised HTML/SVG rejected, downloads authorised', async () => {
  const html = await owner.post('/api/v1/documents', undefined, { multipart: H.multipart({ title: 'x' }, { name: 'report.pdf', data: '<html><script>alert(1)</script></html>' }) });
  assert.equal(html.status, 400);
  const exe = await owner.post('/api/v1/documents', undefined, { multipart: H.multipart({ title: 'x' }, { name: 'a.pdf', data: Buffer.from('4d5a900003000000', 'hex') }) });
  assert.equal(exe.status, 400);
  const ok = await owner.post('/api/v1/documents', undefined, { multipart: H.multipart({ title: 'Policy', ownerType: 'school' }, { name: '../../etc/passwd.pdf', data: '%PDF-1.4 hello' }) });
  assert.equal(ok.status, 200);
  const dl = await owner.get(`/api/v1/files/${ok.body.fileId}`);
  assert.match(dl.headers['content-disposition'], /^attachment; filename="\.\._\.\._etc_passwd\.pdf"|^attachment; filename="[^/]*"$/); assert.ok(!/\//.test(dl.headers['content-disposition'].split('filename=')[1]));
  const student = await H.login(S.app, 'sa.student');
  assert.equal((await student.get(`/api/v1/files/${ok.body.fileId}`)).status, 404, 'staff-only document hidden from students');
  const audit = await owner.get('/api/v1/audit?action=files.downloaded'); assert.ok(audit.body.items.length >= 1, 'sensitive downloads are audited');
});
test('audit log: runtime role cannot modify it; even the owner is blocked; tampering is detected by hash chain', async () => {
  const v1 = await owner.get('/api/v1/audit/verify'); assert.equal(v1.body.ok, true); assert.ok(Number(v1.body.checked) > 3);
  const app = await H.dbAs('app');
  try {
    await app.query('BEGIN'); await app.query("SELECT set_config('app.school_id', $1, true)", [S.A.schoolId]);
    await assert.rejects(app.query("UPDATE audit_logs SET action = 'x.y' WHERE school_id = $1", [S.A.schoolId]), /permission denied/);
    await app.query('ROLLBACK'); await app.query('BEGIN'); await app.query("SELECT set_config('app.school_id', $1, true)", [S.A.schoolId]);
    await assert.rejects(app.query("DELETE FROM audit_logs WHERE school_id = $1", [S.A.schoolId]), /permission denied/);
    await app.query('ROLLBACK'); await app.query('BEGIN'); await app.query("SELECT set_config('app.school_id', $1, true)", [S.A.schoolId]);
    await assert.rejects(app.query("SELECT app.audit_append($1, NULL, 'x', NULL, 'forged.entry', NULL, NULL, true, NULL, NULL, '{}')", [S.B.schoolId]), /AUDIT_TENANT_MISMATCH/, 'cannot write into another school chain');
    await app.query('ROLLBACK');
  } finally { await app.end(); }
  const own = await H.dbAs('owner');
  try { await assert.rejects(own.query("UPDATE audit_logs SET action = 'x.y' WHERE school_id = $1", [S.A.schoolId]), /APPEND_ONLY/); } finally { await own.end(); }
  // simulate a superuser/DBA-level tamper that bypasses triggers → verification must flag it
  const su = await H.dbAs('super');
  try {
    await su.query('ALTER TABLE audit_logs DISABLE TRIGGER audit_logs_no_update');
    await su.query("UPDATE audit_logs SET metadata = '{\"forged\":true}' WHERE school_id = $1 AND seq = 2", [S.A.schoolId]);
    await su.query('ALTER TABLE audit_logs ENABLE TRIGGER audit_logs_no_update');
  } finally { await su.end(); }
  const v2 = await owner.get('/api/v1/audit/verify'); assert.equal(v2.body.ok, false); assert.equal(Number(v2.body.first_bad_seq), 2);
});
test('audit trail covers key actions with actor, IP and outcome', async () => {
  const items = (await owner.get('/api/v1/audit?pageSize=100')).body.items;
  const actions = new Set(items.map((i) => i.action));
  for (const a of ['auth.login', 'auth.mfa_enabled', 'documents.uploaded', 'files.downloaded']) assert.ok(actions.has(a), a);
  const l = items.find((i) => i.action === 'auth.login'); assert.ok(l.actor_login && l.ip);
  const t = await H.login(S.app, 'sa.teacher1');
  assert.equal((await t.get('/api/v1/audit')).status, 403, 'teachers cannot read the audit log');
});
test('BOLA sweep: every :id route rejects School B identifiers for a School A owner (and never 500s)', async () => {
  const db = await H.dbAs('owner'); const ids = [];
  try {
    for (const t of ['students', 'staff', 'guardians', 'classes', 'subjects', 'terms', 'academic_sessions', 'invoices', 'payments', 'cbt_exams', 'cbt_questions', 'cbt_attempts', 'assessments', 'announcements', 'conversations', 'documents', 'uploads', 'roles', 'users', 'fee_items', 'fee_discounts', 'result_corrections', 'imports', 'promotion_runs', 'jobs']) {
      const r = await db.query(`SELECT id FROM ${t} WHERE school_id = $1 LIMIT 1`, [S.B.schoolId]); if (r.rows[0]) ids.push(r.rows[0].id);
    }
  } finally { await db.end(); }
  // enumerate all concrete routes containing ':id'
  const all = [];
  for (const r of S.app.routeList) for (const m of [].concat(r.method)) if (r.url.includes(':id')) all.push([m, r.url]);
  assert.ok(all.length >= 40, `found ${all.length} :id routes`);
  const body = { reason: 'bola sweep test', action: 'approve', status: 'disabled', roleKeys: [], studentIds: [], items: [], entries: [{ studentId: ids[0], scores: {} }], termId: ids[0], grades: [{ questionId: ids[0], marks: 1 }], answers: [{ questionId: ids[0] }], body: 'x', questionIds: [ids[0]], name: 'x', permissions: [], fullName: 'Name X' };
  let checked = 0; const violations = new Set();
  for (const [method, path] of all) {
    if (method === 'HEAD') continue;
    for (const id of ids) {
      const url = path.replace(':id', id);
      const r = await owner.req(method, url, method === 'GET' || method === 'DELETE' ? (method === 'DELETE' ? { reason: 'bola sweep test' } : undefined) : body);
      if (r.status >= 500 || r.status < 400) violations.add(`${method} ${path} → ${r.status}`);
      checked++;
    }
  }
  assert.deepEqual([...violations], [], 'every foreign id must be refused');
  assert.ok(checked > 500, `checked ${checked} combinations`);
});
test('metrics endpoint is hidden without the bearer token; health endpoints are public and minimal', async () => {
  assert.equal((await S.app.inject({ method: 'GET', url: '/metrics' })).statusCode, 404);
  const m = await S.app.inject({ method: 'GET', url: '/metrics', headers: { authorization: 'Bearer test-metrics-token-1234567890' } });
  assert.equal(m.statusCode, 200); assert.match(m.body, /http_requests_total/); assert.match(m.body, /auth_login_failures_total|db_pool_total/);
  const h = await S.app.inject({ method: 'GET', url: '/readyz' }); assert.deepEqual(h.json(), { ok: true, db: 'up' });
});
test('no secrets in the frontend bundle', async () => {
  const fs = require('node:fs'); const path = require('node:path');
  const dir = path.join(__dirname, '../../web');
  const files = []; (function walk(d) { for (const f of fs.readdirSync(d)) { const p = path.join(d, f); if (fs.statSync(p).isDirectory()) walk(p); else files.push(p); } })(dir);
  for (const f of files) {
    const t = fs.readFileSync(f, 'utf8');
    assert.ok(!/sk_(live|test)_|AKIA[0-9A-Z]{16}|BEGIN (RSA )?PRIVATE KEY|postgres:\/\/|abo_app_dev_password|apiKey\s*[:=]\s*['"][^'"]{8,}/.test(t), `secret-like string in ${f}`);
    assert.ok(!/localStorage\.setItem\([^)]*(password|token|session|student|result|score)/i.test(t), `sensitive localStorage use in ${f}`);
  }
});
test('route inventory: no endpoint is accidentally public or permission-less', () => {
  const PUBLIC = new Set(['GET /api/v1/openapi.json', 'POST /api/v1/auth/login', 'POST /api/v1/auth/password/forgot', 'POST /api/v1/auth/password/reset', 'POST /api/v1/auth/activate', 'POST /api/v1/auth/verify-email',
    'POST /api/v1/onboarding/register', 'POST /api/v1/payments/webhook/paystack', 'GET /api/v1/public/schools/:slug', 'GET /api/v1/public/schools/:slug/logo', 'POST /api/v1/client-errors', 'GET /api/v1/public/status',
    // demo start (5-minute demo-school sessions, rate-limited; since 028 only with a demo link from the platform owner) and the signed (HMAC) subscription webhook
    'GET /api/v1/public/demo', 'POST /api/v1/public/demo/start', 'POST /api/v1/billing/webhook/paystack']);
  // signed-in-only endpoints that are scoped to the caller's OWN data inside the handler
  const SELF = new Set(['GET /api/v1/auth/me', 'POST /api/v1/auth/mfa/verify', 'POST /api/v1/auth/mfa/setup', 'POST /api/v1/auth/mfa/enable', 'POST /api/v1/auth/mfa/disable', 'POST /api/v1/auth/password/change',
    'POST /api/v1/auth/logout', 'POST /api/v1/auth/logout-all', 'GET /api/v1/auth/sessions', 'DELETE /api/v1/auth/sessions/:id', 'GET /api/v1/notifications', 'POST /api/v1/notifications/read',
    'GET /api/v1/jobs/:id', 'GET /api/v1/files/:id', 'GET /api/v1/dashboard', 'GET /api/v1/auth/memberships', 'POST /api/v1/auth/memberships/:id/respond', 'POST /api/v1/auth/switch-school', 'GET /api/v1/system/support',
    'POST /api/v1/auth/act-as/stop']);   // stop only ever clears the caller's OWN session (and must work while acting, without the owner's permissions)
  const bad = [];
  for (const r of S.app.routeList) {
    if (!r.url.startsWith('/api/') || r.method === 'HEAD') continue;
    const k = `${[].concat(r.method)[0]} ${r.url}`;
    if (!r.auth) { if (!PUBLIC.has(k)) bad.push(`${k} is public`); continue; }
    if (!r.perms.length && !r.platform && !SELF.has(k)) bad.push(`${k} has no permission guard`);
  }
  assert.deepEqual(bad, []);
});
test('private app: every response asks search engines not to index it (X-Robots-Tag)', async () => {
  const r = await S.app.inject({ method: 'GET', url: '/api/v1/public/status' });
  assert.match(String(r.headers['x-robots-tag'] || ''), /noindex/);
  const fs = require('node:fs'); const path = require('node:path');
  const web = fs.readFileSync(path.join(__dirname, '../../scripts/build-web.js'), 'utf8'); assert.match(web, /X-Robots-Tag: noindex/);
});
