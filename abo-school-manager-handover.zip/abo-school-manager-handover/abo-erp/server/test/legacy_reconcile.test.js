'use strict';
// PHASE 5 — data integrity: a REAL backup made by the offline app ("💾 Backup", produced in a real browser by
// .qa/make_backup.js) is migrated into the server, then every learner and every score is reconciled against the file.
// The expected numbers are computed here, independently of the importer, straight from the raw file.
const H = require('./helpers');
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const FILE = path.join(__dirname, 'fixtures', 'offline-backup-phase5.json');
const RAW = fs.readFileSync(FILE, 'utf8');
const data = JSON.parse(RAW);

// ── independent expectation from the raw file ──
function expected(d) {
  const regs = {}; const L = (d.schoolData && d.schoolData.erp && d.schoolData.erp.learners) || {};
  for (const [k, v] of Object.entries(L)) if (Array.isArray(v)) regs[k] = v;
  if (Array.isArray(d.students) && d.students.length) regs[(d.globalSettings || {}).className || 'BASIC 1'] = d.students;
  const comps = ((d.schoolData.erp || {}).broadsheet || {}).components || [{ key: 'ca1', max: 20, weight: 20 }, { key: 'ca2', max: 20, weight: 20 }, { key: 'exam', max: 60, weight: 60 }];
  const get = (sub, key) => Number(['ca1', 'ca2', 'exam'].includes(key) ? sub[key] : (sub.extra || {})[key]) || 0;
  const out = { learners: 0, perClass: {}, scored: 0, totals: [] };
  for (const [cls, list] of Object.entries(regs)) {
    const named = list.filter((s) => s && String(s.name || '').trim());
    out.perClass[cls] = named.length; out.learners += named.length;
    named.forEach((s) => (s.subjects || []).forEach((sub, j) => {
      if (!sub || !d.subjects[j]) return;
      if (!comps.some((c) => get(sub, c.key) > 0)) return;          // nothing entered for this subject
      const total = comps.reduce((a, c) => a + (Math.min(get(sub, c.key), c.max) / c.max) * c.weight, 0);
      out.scored++; out.totals.push({ cls, name: String(s.name).trim(), subject: d.subjects[j], total: Math.round(total * 100) / 100 });
    }));
  }
  return out;
}

async function reconcile(slug, d, exclude) {
  const exp = expected(d);
  const db = await H.dbAs('admin');
  try {
    const sch = (await db.query('SELECT id FROM schools WHERE slug = $1', [slug])).rows[0].id;
    for (const [cls, n] of Object.entries(exp.perClass)) {
      const got = (await db.query(`SELECT count(*)::int AS n FROM student_enrollments e JOIN classes c ON c.id = e.class_id
        WHERE e.school_id = $1 AND upper(replace(c.name || c.arm, ' ', '')) = upper(replace($2, ' ', ''))`, [sch, cls])).rows[0].n;
      assert.equal(got, n - (exclude[cls] || 0), `class ${cls}: ${got} enrolled vs ${n} in the file`);
    }
    const rows = (await db.query(`SELECT c.name || c.arm AS cls, s.last_name, s.first_name, s.other_names, sub.name AS subject, er.total
      FROM examination_results er JOIN assessments a ON a.id = er.sheet_id JOIN classes c ON c.id = a.class_id JOIN subjects sub ON sub.id = a.subject_id
      JOIN students s ON s.id = er.student_id WHERE er.school_id = $1 AND upper(replace(c.name || c.arm, ' ', '')) = ANY($2::text[])`, [sch, Object.keys(exp.perClass).map((k) => k.toUpperCase().replace(/\s+/g, ''))])).rows;
    const key = (cls, name, subject) => `${cls.toUpperCase().replace(/\s+/g, '')}|${name.toLowerCase()}|${subject.toLowerCase()}`;
    const got = new Map(rows.map((r) => [key(r.cls, [r.last_name, r.first_name, r.other_names].filter(Boolean).join(' '), r.subject), Number(r.total)]));
    let bad = 0; const eg = [];
    const want = exp.totals.filter((t) => !(exclude.names || []).includes(t.name));
    for (const t of want) { const g = got.get(key(t.cls, t.name, t.subject)); if (g === undefined || Math.abs(g - t.total) > 0.05) { bad++; if (eg.length < 3) eg.push({ ...t, got: g }); } }
    assert.equal(rows.length, want.length, `score rows: ${rows.length} in the database vs ${want.length} in the file`);
    assert.equal(bad, 0, `${bad} subject totals differ, e.g. ${JSON.stringify(eg)}`);
    return { learners: exp.learners, scored: want.length };
  } finally { await db.end(); }
}

let S, owner;
test.before(async () => { S = await H.setup(); owner = await H.login(S.app, 'sb.owner'); });
test.after(() => H.teardown());

test('real offline backup: every learner, class and score arrives; totals match the file', async () => {
  const exp = expected(data);
  assert.ok(exp.learners >= 20 && Object.keys(exp.perClass).length >= 2, 'fixture has 2+ classes');
  const pv = await owner.post('/api/v1/migration/legacy/preview', undefined, { multipart: H.multipart({}, { name: 'backup.json', type: 'application/json', data: RAW }) });
  assert.equal(pv.status, 200, JSON.stringify(pv.body));
  assert.equal(pv.body.counts.students, exp.learners, 'preview counts every learner');
  const cm = await owner.post(`/api/v1/migration/legacy/${pv.body.importId}/commit`, {});
  assert.equal(cm.status, 200, JSON.stringify(cm.body));
  assert.equal(cm.body.skipped, 0, 'no learner skipped: ' + JSON.stringify(cm.body));
  assert.equal(cm.body.students, exp.learners, 'every learner imported');
  await reconcile('school-b', data, {});
  // importing the same file again must not create duplicates of anything
  const pv2 = await owner.post('/api/v1/migration/legacy/preview', undefined, { multipart: H.multipart({}, { name: 'backup.json', type: 'application/json', data: RAW }) });
  const cm2 = await owner.post(`/api/v1/migration/legacy/${pv2.body.importId}/commit`, {});
  assert.equal(cm2.status, 200, JSON.stringify(cm2.body));
  assert.equal(cm2.body.students, 0, 'second import adds no learners');
  assert.equal(cm2.body.cbtExams || 0, 0, 'second import adds no CBT exams'); assert.equal(cm2.body.newsletters || 0, 0, 'no newsletters'); assert.equal(cm2.body.teachers || 0, 0, 'no teachers');
});

test('custom score layout (weights ≠ maxima, extra "Project" part), real zeros, over-maximum and duplicate admission numbers', async () => {
  const d = JSON.parse(RAW);
  const L = d.schoolData.erp.learners; const b1 = L['BASIC 1'], b2 = L['BASIC 2'];
  d.schoolData.erp.learners = { 'YEAR 7X': b1, 'YEAR 7Y': b2 }; d.globalSettings.className = 'YEAR 7X'; d.students = b1;
  d.schoolData.erp.broadsheet.components = [{ key: 'ca1', name: 'CA 1', max: 20, weight: 15 }, { key: 'ca2', name: 'CA 2', max: 20, weight: 15 },
    { key: 'x1', name: 'Project', max: 10, weight: 10 }, { key: 'exam', name: 'Exam', max: 100, weight: 60 }];
  b1.forEach((s, i) => { if (!s.name) return; s.name = 'Jay ' + s.name; s.subjects.forEach((sub, j) => { sub.extra = { x1: (i + j) % 11 }; sub.exam = 30 + ((i * 7 + j) % 70); }); });
  b2.forEach((s, i) => { if (!s.name) return; s.name = 'Kay ' + s.name; s.subjects.forEach((sub) => { sub.exam = 0; sub.ca1 = 0; sub.ca2 = 0; }); });
  b2[0].subjects[0] = { ca1: 0, ca2: 0, exam: 55, extra: { x1: 0 } };         // a real zero in the CA parts
  b2[1].subjects[0] = { ca1: 25, ca2: 5, exam: 40, extra: { x1: 4 } };        // above the CA maximum → counted at 20, like the offline app
  b1[3].admissionNo = 'JSS/2026/001'; b2[4].admissionNo = 'JSS/2026/001';    // the same admission number twice
  const file = JSON.stringify(d);
  const a = S.aOwner || (S.aOwner = await H.login(S.app, 'sa.owner'));
  const pv = await a.post('/api/v1/migration/legacy/preview', undefined, { multipart: H.multipart({}, { name: 'b.json', data: file }) });
  assert.equal(pv.status, 200, JSON.stringify(pv.body));
  assert.equal(pv.body.layout.same, false, 'preview notices the different score layout');
  assert.ok(pv.body.warnings.some((w) => /Score layout is different/.test(w)) && pv.body.warnings.some((w) => /appears more than once/.test(w)) && pv.body.warnings.some((w) => /higher than the maximum/.test(w)), JSON.stringify(pv.body.warnings));
  const cm = await a.post(`/api/v1/migration/legacy/${pv.body.importId}/commit`, { adoptLayout: true });
  assert.equal(cm.status, 200, JSON.stringify(cm.body));
  assert.equal(cm.body.layoutAdopted, true); assert.equal(cm.body.scorePartsNotImported, 0);
  assert.equal(cm.body.skippedDuplicateInFile, 1); assert.equal(cm.body.reconciliation.balanced, true);
  const r = await reconcile('school-a', d, { 'YEAR 7Y': 1, names: [b2[4].name] });   // the duplicate is not imported
  assert.ok(r.scored > 100, 'many weighted totals were compared: ' + r.scored);
  const st = (await a.get('/api/v1/school')).body.settings;
  const comps = (st.assessment_components || st.assessmentComponents || []).map((x) => `${x.key}:${Number(x.max)}`).sort().join(',');
  assert.equal(comps, 'ca1:15,ca2:15,exam:60,x1:10', 'school now uses the offline layout (maximum = weight)');
});

test('a backup with no learners or the wrong kind of file is refused', async () => {
  const a = S.aOwner || (S.aOwner = await H.login(S.app, 'sa.owner'));
  const bad = await a.post('/api/v1/migration/legacy/preview', undefined, { multipart: H.multipart({}, { name: 'x.json', data: '{"hello":1}' }) });
  assert.equal(bad.status, 400);
  const notJson = await a.post('/api/v1/migration/legacy/preview', undefined, { multipart: H.multipart({}, { name: 'x.json', data: 'not json' }) });
  assert.equal(notJson.status, 400);
});

test('passport photos and the school logo come across when the same file is sent again at commit', async () => {
  const png = 'data:image/png;base64,' + H.PNG_1PX.toString('base64');
  const kid = (name, i, passport) => ({ name, gender: i % 2 ? 'Female' : 'Male', attendanceNo: i + 1, passport, subjects: [] });
  const d = { subjects: ['Mathematics'], globalSettings: { session: '2025/2026', term: '1ST', className: 'YEAR 9P' },
    students: [kid('Photo Ada', 0, png), kid('Photo Bayo', 1, png), kid('Photo Chi', 2, 'data:text/html;base64,PHNjcmlwdD4='), kid('Photo Dele', 3, null)],
    schoolData: { name: 'Photo School', logo: png, erp: {} } };
  const file = JSON.stringify(d);
  const a = S.aOwner || (S.aOwner = await H.login(S.app, 'sa.owner'));
  const pv = await a.post('/api/v1/migration/legacy/preview', undefined, { multipart: H.multipart({}, { name: 'b.json', data: file }) });
  assert.equal(pv.status, 200, JSON.stringify(pv.body));
  assert.equal(pv.body.counts.photos, 2, 'two usable photos'); assert.equal(pv.body.counts.logo, true);
  assert.ok(pv.body.warnings.some((w) => /Photo Chi.*not a usable picture/.test(w)), 'a fake "photo" is reported, not imported');
  // a different file at commit time is refused
  const other = JSON.stringify({ ...d, students: d.students.slice(0, 1) });
  const bad = await a.post(`/api/v1/migration/legacy/${pv.body.importId}/commit`, undefined, { multipart: H.multipart({}, { name: 'b.json', data: other }) });
  assert.equal(bad.status, 400); assert.match(bad.body.error.message, /not the same file/);
  const cm = await a.post(`/api/v1/migration/legacy/${pv.body.importId}/commit`, undefined, { multipart: H.multipart({ importAudit: 'false' }, { name: 'b.json', data: file }) });
  assert.equal(cm.status, 200, JSON.stringify(cm.body));
  assert.equal(cm.body.students, 4); assert.equal(cm.body.photos, 2); assert.equal(cm.body.logo, true);
  const db = await H.dbAs('owner');
  try {
    const rows = (await db.query("SELECT first_name, last_name, passport_file_id FROM students WHERE admission_no LIKE 'YEAR9P-%' ORDER BY admission_no")).rows;
    assert.equal(rows.filter((r) => r.passport_file_id).length, 2);
    const fid = rows.find((r) => r.passport_file_id).passport_file_id;
    const f = await a.get(`/api/v1/files/${fid}`); assert.equal(f.status, 200); assert.match(f.headers['content-type'], /image\/png/);
    const logo = (await db.query("SELECT logo_file_id FROM schools WHERE slug = 'school-a'")).rows[0].logo_file_id; assert.ok(logo, 'logo set (the school had none)');
  } finally { await db.end(); }
});
