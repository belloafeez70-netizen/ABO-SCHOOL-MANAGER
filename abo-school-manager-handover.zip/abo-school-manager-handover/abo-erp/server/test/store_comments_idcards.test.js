'use strict';
// Phase 6 (part 2): school store & sales, the class comment helper and ID cards — with the rules checked on the server.
const H = require('./helpers');
const test = require('node:test');
const assert = require('node:assert/strict');

let S, owner, bursar, accounts, teacher, teacher2, exam, student, bOwner;
test.before(async () => {
  S = await H.setup();
  [owner, bursar, accounts, teacher, teacher2, exam, student, bOwner] = await Promise.all(
    ['sa.owner', 'sa.bursar', 'sa.accounts', 'sa.teacher1', 'sa.teacher2', 'sa.exams', 'sa.student', 'sb.owner'].map((l) => H.login(S.app, l)));
});
test.after(() => H.teardown());

test('store: items and stock; the server sets prices; stock never goes below zero; sales voided not edited; moves always add up', async () => {
  assert.equal((await accounts.post('/api/v1/store/items', { name: 'Exercise book (40 leaves)', unitPriceKobo: 30000 })).status, 403, 'accountant sells but does not set prices');
  let r = await bursar.post('/api/v1/store/items', { name: 'Exercise book (40 leaves)', category: 'Books', unitPriceKobo: 30000, costPriceKobo: 20000, openingQty: 5, reorderLevel: 2 });
  assert.equal(r.status, 200, JSON.stringify(r.body)); const book = r.body;
  assert.equal(book.stock_qty, 5);
  r = await bursar.post('/api/v1/store/items', { name: 'School tie', category: 'Uniform', unitPriceKobo: 150000, openingQty: 3 }); const tie = r.body;
  assert.equal((await bursar.post('/api/v1/store/items', { name: 'school TIE', unitPriceKobo: 1 })).status, 409, 'no duplicate names');
  assert.equal((await bursar.patch(`/api/v1/store/items/${book.id}`, { stock_qty: 999 })).status, 400, 'stock cannot be typed in directly');
  // sale: the browser cannot set the price
  assert.equal((await accounts.post('/api/v1/store/sales', { method: 'cash', lines: [{ itemId: book.id, qty: 2, unitPriceKobo: 1 }] })).status, 400, 'price fields are refused');
  const st = (await owner.get('/api/v1/students?pageSize=1')).body.items[0];
  r = await accounts.post('/api/v1/store/sales', { method: 'cash', studentId: st.id, lines: [{ itemId: book.id, qty: 2 }, { itemId: tie.id, qty: 1 }, { itemId: book.id, qty: 1 }] }, { headers: { 'idempotency-key': 'sale-qa-000001' } });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.equal(r.body.total_kobo, 3 * 30000 + 150000, 'total worked out on the server'); assert.match(r.body.receipt_no, /^SAL-\d{4}-000001$/);
  assert.equal(r.body.lines.length, 2, 'the same item twice becomes one line');
  const sale = r.body;
  r = await accounts.post('/api/v1/store/sales', { method: 'cash', studentId: st.id, lines: [{ itemId: book.id, qty: 2 }, { itemId: tie.id, qty: 1 }, { itemId: book.id, qty: 1 }] }, { headers: { 'idempotency-key': 'sale-qa-000001' } });
  assert.equal(r.headers['idempotent-replayed'], 'true'); assert.equal(r.body.receipt_no, sale.receipt_no, 'a retried sale is not sold twice');
  let items = (await accounts.get('/api/v1/store/items')).body;
  assert.equal(items.items.find((x) => x.id === book.id).stock_qty, 2); assert.equal(items.items.find((x) => x.id === book.id).low, true, 'low-stock flag');
  assert.equal(items.items[0].cost_price_kobo, undefined, 'sellers do not see cost prices');
  // not enough stock
  r = await accounts.post('/api/v1/store/sales', { method: 'pos', lines: [{ itemId: book.id, qty: 3 }] });
  assert.equal(r.status, 409); assert.match(r.body.error.message, /Only 2/);
  // two tills selling the last 2 books at the same moment: one wins
  const both = await Promise.all([accounts, bursar].map((who) => who.post('/api/v1/store/sales', { method: 'cash', buyerName: 'Walk-in parent', lines: [{ itemId: book.id, qty: 2 }] })));
  assert.deepEqual(both.map((x) => x.status).sort(), [200, 409], 'stock can never be oversold');
  items = (await bursar.get('/api/v1/store/items')).body; assert.equal(items.items.find((x) => x.id === book.id).stock_qty, 0);
  // restock and correct
  assert.equal((await bursar.post(`/api/v1/store/items/${book.id}/stock`, { kind: 'restock', qty: -1 })).status, 400);
  assert.equal((await bursar.post(`/api/v1/store/items/${book.id}/stock`, { kind: 'restock', qty: 10, unitCostKobo: 21000 })).status, 200);
  assert.equal((await bursar.post(`/api/v1/store/items/${book.id}/stock`, { kind: 'adjust', qty: -1 })).status, 400, 'a correction needs a reason');
  assert.equal((await bursar.post(`/api/v1/store/items/${book.id}/stock`, { kind: 'adjust', qty: -11, reason: 'count' })).status, 400, 'cannot remove more than is there');
  assert.equal((await bursar.post(`/api/v1/store/items/${book.id}/stock`, { kind: 'adjust', qty: -1, reason: '1 damaged by rain' })).status, 200);
  // void: stock goes back; only store.void
  assert.equal((await accounts.post(`/api/v1/store/sales/${sale.id}/void`, { reason: 'Wrong pupil' })).status, 403);
  assert.equal((await bursar.post(`/api/v1/store/sales/${sale.id}/void`, { reason: 'Wrong pupil' })).status, 200);
  assert.equal((await bursar.post(`/api/v1/store/sales/${sale.id}/void`, { reason: 'again' })).status, 409);
  const mv = (await bursar.get(`/api/v1/store/items/${book.id}/moves`)).body;
  assert.equal(mv.item.stock_qty, 0 + 10 - 1 + 3, 'restock 10, damaged 1, void returns 3');
  assert.equal(mv.movesAddUp, true, 'stock always equals the sum of its moves');
  const db = await H.dbAs('owner');
  try {
    await assert.rejects(db.query('UPDATE store_sales SET total_kobo = 1 WHERE id = $1', [both.find((x) => x.status === 200).body.id]), /never edited/);
    await assert.rejects(db.query('DELETE FROM store_moves WHERE item_id = $1', [book.id]), /permanent record/);
    await assert.rejects(db.query('UPDATE store_items SET stock_qty = -1 WHERE id = $1', [book.id]), /check/i, 'database refuses negative stock');
  } finally { await db.end(); }
  // sales list + cashbook summary includes store sales
  const sl = (await owner.get('/api/v1/store/sales')).body; assert.equal(sl.total, 1); assert.equal(sl.totalKobo, 60000);
  const t = new Date(Date.now() + 3600e3).toISOString().slice(0, 10);
  const sum = (await owner.get(`/api/v1/cashbook/summary?from=${t}&to=${t}`)).body; assert.equal(sum.storeSalesKobo, 60000, 'store money shows in the cashbook totals');
  // isolation
  assert.equal((await bOwner.get('/api/v1/store/items')).body.items.length, 0);
  assert.equal((await bOwner.post('/api/v1/store/sales', { method: 'cash', lines: [{ itemId: tie.id, qty: 1 }] })).status, 400, 'another school cannot sell A’s item');
  assert.equal((await bOwner.get(`/api/v1/store/sales/${sale.id}`)).status, 404);
  assert.equal((await teacher.get('/api/v1/store/items')).status, 403, 'teachers have no store access');
});

test('comment helper: suggestions for a class; form teacher writes teacher comments, reviewers write head comments; saved in one go', async () => {
  const db = await H.dbAs('owner');
  let classId, termId, pupils;
  try {
    const sa = (await db.query("SELECT id FROM schools WHERE slug = 'school-a'")).rows[0].id;
    const cl = (await db.query("SELECT c.id FROM classes c WHERE c.school_id = $1 AND c.form_teacher_id IS NOT NULL LIMIT 1", [sa])).rows[0]; classId = cl.id;
    termId = (await db.query('SELECT id FROM terms WHERE school_id = $1 AND is_current', [sa])).rows[0].id;
    pupils = (await db.query(`SELECT s.id, s.first_name FROM student_enrollments e JOIN students s ON s.id = e.student_id WHERE e.class_id = $1 ORDER BY s.last_name LIMIT 3`, [classId])).rows;
    for (const [i, p] of pupils.entries()) {
      await db.query(`INSERT INTO result_summaries (school_id, term_id, class_id, student_id, subjects_count, total, average, highest, lowest, grade, position, class_size, status, published)
        VALUES ($1,$2,$3,$4,5,$5,$6,90,30,$7,$8,3,$9,false) ON CONFLICT DO NOTHING`, [sa, termId, classId, p.id, [455, 310, 180][i], [91, 62, 36][i], ['A1', 'C4', 'F9'][i], i + 1, i === 2 ? 'Fail' : 'Pass']);
    }
  } finally { await db.end(); }
  assert.equal((await teacher2.get(`/api/v1/results/comment-helper?termId=${termId}&classId=${classId}`)).status, 403, 'a teacher who is not the form teacher is refused');
  const r = await teacher.get(`/api/v1/results/comment-helper?termId=${termId}&classId=${classId}`);
  assert.equal(r.status, 200, JSON.stringify(r.body)); assert.deepEqual(r.body.can, { teacher: true, head: false });
  const top = r.body.items.find((x) => x.studentId === pupils[0].id); const low = r.body.items.find((x) => x.studentId === pupils[2].id);
  assert.match(top.suggestedTeacher, new RegExp(`^${pupils[0].first_name} scored 91%`)); assert.equal(top.suggestedHead, null, 'form teacher gets no head suggestion');
  assert.match(low.suggestedTeacher, /36%/);
  assert.ok(r.body.items.some((x) => x.note && /compute/.test(x.note)), 'pupils without results are flagged, not given made-up comments');
  // save: teacher comments OK, head comments refused for the form teacher
  assert.equal((await teacher.put('/api/v1/results/report-cards/bulk', { termId, classId, items: [{ studentId: pupils[0].id, headComment: 'x' }] })).status, 403);
  let s = await teacher.put('/api/v1/results/report-cards/bulk', { termId, classId, items: [{ studentId: pupils[0].id, teacherComment: top.suggestedTeacher }, { studentId: pupils[2].id, teacherComment: '  Needs extra lessons in maths.  ' }] });
  assert.equal(s.status, 200, JSON.stringify(s.body)); assert.equal(s.body.saved, 2);
  // a pupil from another class cannot be slipped in
  const other = (await owner.get('/api/v1/students?pageSize=100')).body.items.find((x) => !r.body.items.some((y) => y.studentId === x.id));
  assert.equal((await teacher.put('/api/v1/results/report-cards/bulk', { termId, classId, items: [{ studentId: other.id, teacherComment: 'x' }] })).status, 400);
  // reviewer (exam officer) sees head suggestions and saves them without touching the teacher's words
  const ex = await exam.get(`/api/v1/results/comment-helper?termId=${termId}&classId=${classId}`);
  assert.equal(ex.body.can.head, true); assert.match(ex.body.items.find((x) => x.studentId === pupils[0].id).suggestedHead, /commends/);
  s = await exam.put('/api/v1/results/report-cards/bulk', { termId, classId, items: [{ studentId: pupils[0].id, headComment: ex.body.items.find((x) => x.studentId === pupils[0].id).suggestedHead }] });
  assert.equal(s.status, 200);
  const rc = (await owner.get(`/api/v1/results/student/${pupils[0].id}?termId=${termId}`)).body.reportCard;
  assert.equal(rc.teacher_comment, top.suggestedTeacher, 'teacher comment kept'); assert.match(rc.head_comment, /commends/);
  const rc2 = (await owner.get(`/api/v1/results/student/${pupils[2].id}?termId=${termId}`)).body.reportCard;
  assert.equal(rc2.teacher_comment, 'Needs extra lessons in maths.', 'spaces trimmed');
  assert.equal((await student.get(`/api/v1/results/comment-helper?termId=${termId}&classId=${classId}`)).status, 403);
  assert.equal((await bOwner.get(`/api/v1/results/comment-helper?termId=${termId}&classId=${classId}`)).status, 404, 'another school cannot see the class');
});

test('ID cards: pupils of a class with guardian phone and photo id; staff cards; permissions; audited', async () => {
  const cls = (await owner.get('/api/v1/academic')).body.classes[0];
  const r = await owner.get(`/api/v1/id-cards/students?classId=${cls.id}`);
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.ok(r.body.people.length >= 1); assert.ok(r.body.school.name);
  assert.ok(r.body.people.every((p) => p.admission_no && p.name && p.className === cls.display_name));
  assert.ok('passport_file_id' in r.body.people[0] && 'guardian_phone' in r.body.people[0]);
  const sf = await owner.get('/api/v1/id-cards/staff'); assert.equal(sf.status, 200); assert.ok(sf.body.people.some((p) => p.name === 'Mr Tunde Bello'));
  assert.equal((await student.get(`/api/v1/id-cards/students?classId=${cls.id}`)).status, 403);
  assert.equal((await teacher.get('/api/v1/id-cards/staff')).status, 403, 'teachers cannot print staff cards');
  assert.equal((await bOwner.get(`/api/v1/id-cards/students?classId=${cls.id}`)).status, 404, 'another school cannot print A’s pupils');
  const db = await H.dbAs('owner');
  try { assert.ok((await db.query("SELECT count(*)::int AS n FROM audit_logs WHERE action = 'idcards.students_prepared'")).rows[0].n >= 1); } finally { await db.end(); }
});
