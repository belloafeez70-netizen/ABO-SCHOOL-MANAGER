'use strict';
// CBT / Online Examination v2 — end-to-end: question bank → exam wizard → candidates → publish → student attempt
// (autosave, flags, resume, access code) → automatic + manual marking → release → push into the EXISTING result
// sheet → broadsheet + report card → analytics → audit. Plus timer expiry, no-back-nav, no-resume, reset,
// duplicate submission, cross-tenant and in-school scope checks.
const H = require('./helpers');
const test = require('node:test');
const assert = require('node:assert/strict');

let S, owner, exams, t1, t2, student, bOwner, bStudent, cls, maths, db;
const ids = {};
test.before(async () => {
  S = await H.setup();
  [owner, exams, t1, t2, student, bOwner, bStudent] = await Promise.all(['sa.owner', 'sa.exams', 'sa.teacher1', 'sa.teacher2', 'sa.student', 'sb.owner', 'sb.student'].map((l) => H.login(S.app, l)));
  db = await H.dbAs('owner');
  const me = await student.get('/api/v1/auth/me');
  ids.studentId = me.body.studentId;
  const cl = (await db.query(`SELECT c.id, c.display_name, c.section FROM student_enrollments e JOIN classes c ON c.id = e.class_id WHERE e.student_id = $1`, [ids.studentId])).rows[0];
  cls = cl;
  maths = (await db.query("SELECT id FROM subjects WHERE school_id = $1 AND name = 'Mathematics'", [S.A.schoolId])).rows[0].id;
});
test.after(async () => { await db.end(); await H.teardown(); });

const mcq = (text, correct, topic, difficulty = 'medium') => ({ type: 'mcq', text, subjectId: maths, classId: cls.id, topic, difficulty, marks: 1,
  options: ['A', 'B', 'C', 'D'].map((l, i) => ({ text: `${text.slice(0, 10)} opt ${l}`, isCorrect: i === correct })), explanation: `Answer is option ${'ABCD'[correct]}` });

test('question bank: 8 question types validated; search, filters, pagination, duplicate, archive, delete', async () => {
  // validation
  assert.equal((await exams.post('/api/v1/cbt/bank', { type: 'mcq', text: 'x', options: [{ text: 'a', isCorrect: true }, { text: 'b', isCorrect: true }] })).status, 400);
  assert.equal((await exams.post('/api/v1/cbt/bank', { type: 'multi_select', text: 'x', options: [{ text: 'a' }, { text: 'b' }] })).status, 400);
  assert.equal((await exams.post('/api/v1/cbt/bank', { type: 'numeric', text: 'x' })).status, 400);
  assert.equal((await exams.post('/api/v1/cbt/bank', { type: 'fill_blank', text: 'x ____' })).status, 400);
  assert.equal((await exams.post('/api/v1/cbt/bank', { type: 'essay', text: 'x' })).status, 400);
  assert.equal((await bOwner.post('/api/v1/cbt/bank', { type: 'theory', text: 'x', subjectId: maths })).status, 404, 'foreign subject');
  // 12 MCQ across topics & difficulty (Mathematics) — "If 2x + 5 = 15, find x" style
  const topics = ['Algebra', 'Number Bases', 'Geometry', 'Statistics'];
  ids.bank = [];
  for (let i = 0; i < 12; i++) {
    const r = await exams.post('/api/v1/cbt/bank', mcq(`Maths question ${i + 1}: if 2x + ${i} = ${2 * (i + 3) + i}, find x`, i % 4, topics[i % 4], ['easy', 'medium', 'hard'][i % 3]));
    assert.equal(r.status, 200, JSON.stringify(r.body)); ids.bank.push(r.body.id);
  }
  const extra = [
    { type: 'multi_select', text: 'Which are prime numbers?', topic: 'Number Bases', difficulty: 'medium', marks: 2, options: [{ text: '2', isCorrect: true }, { text: '4' }, { text: '5', isCorrect: true }, { text: '9' }] },
    { type: 'multi_select', text: 'Which are even?', topic: 'Number Bases', difficulty: 'easy', options: [{ text: '6', isCorrect: true }, { text: '7' }, { text: '8', isCorrect: true }] },
    { type: 'true_false', text: '\\frac{1}{2} is greater than \\frac{1}{3}', topic: 'Fractions', difficulty: 'easy', correct: true },
    { type: 'true_false', text: 'x^{2} = 2x for every x', topic: 'Indices', difficulty: 'medium', correct: false },
    { type: 'numeric', text: 'Evaluate \\sqrt{144}', topic: 'Indices', difficulty: 'easy', numericValue: 12, tolerance: 0 },
    { type: 'fill_blank', text: 'A triangle has ____ sides.', topic: 'Geometry', difficulty: 'easy', accepted: ['three', '3'] },
    { type: 'short_answer', text: 'Name the longest side of a right-angled triangle.', topic: 'Geometry', difficulty: 'medium', accepted: ['hypotenuse'] },
    { type: 'theory', text: 'Solve 3x - 7 = 11 showing all steps.', topic: 'Algebra', difficulty: 'hard', marks: 4, theoryGuide: 'x = 6; 1 mark per step' },
  ];
  for (const q of extra) { const r = await exams.post('/api/v1/cbt/bank', { ...q, subjectId: maths, classId: cls.id }); assert.equal(r.status, 200, `${q.type}: ${JSON.stringify(r.body)}`); ids.bank.push(r.body.id); }
  const all = await exams.get(`/api/v1/cbt/bank?subjectId=${maths}&pageSize=10`);
  assert.equal(all.body.total, 20); assert.equal(all.body.items.length, 10); assert.equal(all.body.pages, 2);
  assert.equal((await exams.get(`/api/v1/cbt/bank?subjectId=${maths}&difficulty=hard`)).body.total, 5);
  assert.equal((await exams.get(`/api/v1/cbt/bank?topic=geometry&pageSize=50`)).body.total, 5);
  assert.equal((await exams.get('/api/v1/cbt/bank?type=multi_select')).body.total, 2);
  assert.equal((await exams.get('/api/v1/cbt/bank?q=prime')).body.total, 1);
  assert.ok((await exams.get('/api/v1/cbt/bank/topics')).body.items.find((t) => t.topic === 'Algebra'));
  assert.equal((await bOwner.get('/api/v1/cbt/bank?pageSize=100')).body.total, 0, 'School B sees none of School A questions');
  assert.equal((await bOwner.get(`/api/v1/cbt/bank/${ids.bank[0]}`)).status, 404);
  // duplicate / archive / delete (teacher can't edit someone else's question)
  const dup = await exams.post(`/api/v1/cbt/bank/${ids.bank[0]}/duplicate`); assert.equal(dup.status, 200);
  assert.equal((await t2.post(`/api/v1/cbt/bank/${dup.body.id}/archive`, { archived: true })).status, 403);
  assert.equal((await exams.post(`/api/v1/cbt/bank/${dup.body.id}/archive`, { archived: true })).status, 200);
  assert.equal((await exams.get(`/api/v1/cbt/bank?subjectId=${maths}`)).body.total, 20, 'archived hidden by default');
  assert.equal((await exams.get(`/api/v1/cbt/bank?status=archived`)).body.total, 1);
  assert.equal((await exams.del(`/api/v1/cbt/bank/${dup.body.id}`)).status, 200);
  // edit
  const q0 = (await exams.get(`/api/v1/cbt/bank/${ids.bank[0]}`)).body;
  assert.equal((await exams.patch(`/api/v1/cbt/bank/${q0.id}`, { type: 'mcq', text: q0.text, subjectId: maths, classId: cls.id, topic: 'Algebra', difficulty: 'easy', options: q0.options.map((o) => ({ text: o.text, isCorrect: o.isCorrect })) })).status, 200);
});

test('bulk import: invalid rows are reported and never inserted; commit once, only by the uploader; export includes keys', async () => {
  const csv = ['Subject,Class,Topic,Type,Question,Option A,Option B,Option C,Option D,Correct Answer,Mark,Difficulty,Explanation',
    `Mathematics,${cls.display_name},Statistics,MCQ,What is the mean of 2 4 6?,2,4,6,8,B,1,Easy,Sum/3`,
    `Mathematics,${cls.display_name},Statistics,MCQ,Mode of 1 1 2?,1,2,3,,Z,1,Easy,`,
    'Chemistry,,Atoms,MCQ,Unknown subject row,a,b,,,A,1,Easy,',
    `Mathematics,${cls.display_name},Indices,Numeric,Evaluate 2^{3},,,,,8,1,Medium,`,
    `Mathematics,${cls.display_name},Statistics,MCQ,What is the mean of 2 4 6?,2,4,6,8,B,1,Easy,dup`,
    `Mathematics,${cls.display_name},Geometry,True/False,A square has four equal sides,,,,,True,1,Hard,`].join('\n');
  const up = await exams.post('/api/v1/cbt/bank/import/preview', undefined, { multipart: H.multipart({}, { name: 'q.csv', type: 'text/csv', data: csv }) });
  assert.equal(up.status, 200, JSON.stringify(up.body));
  assert.equal(up.body.totalRows, 6); assert.equal(up.body.validRows, 3); assert.equal(up.body.errorCount, 3);
  assert.ok(up.body.errors.some((e) => e.field === 'answer' && e.row === 3)); assert.ok(up.body.errors.some((e) => e.field === 'subject')); assert.ok(up.body.errors.some((e) => /duplicated/.test(e.message)));
  assert.equal((await t2.post(`/api/v1/cbt/bank/import/${up.body.importId}/commit`)).status, 404, 'only the uploader commits');
  const cm = await exams.post(`/api/v1/cbt/bank/import/${up.body.importId}/commit`); assert.equal(cm.body.imported, 3);
  assert.equal((await exams.post(`/api/v1/cbt/bank/import/${up.body.importId}/commit`)).status, 409);
  const ex = await exams.get('/api/v1/cbt/bank/export?format=csv&topic=Statistics');
  assert.equal(ex.status, 200); assert.match(ex.raw.body, /Correct Answer/); assert.match(ex.raw.body, /mean of 2 4 6/);
  assert.equal((await student.get('/api/v1/cbt/bank/export')).status, 403);
  const bad = await exams.post('/api/v1/cbt/bank/import/preview', undefined, { multipart: H.multipart({}, { name: 'q.csv', type: 'text/csv', data: 'Foo,Bar\n1,2' }) });
  assert.equal(bad.status, 400); assert.match(bad.body.error.message, /Missing required column/);
});

test('exam wizard: create with defaults, generate by difficulty (shortfall refused), from bank, reorder, readiness blocks publish', async () => {
  assert.equal((await owner.put('/api/v1/cbt/settings', { passMark: 45, allowBackNav: true, scoreComponent: 'nope' })).status, 400);
  assert.equal((await owner.put('/api/v1/cbt/settings', { passMark: 45, durationMinutes: 30, showAnswers: true })).status, 200);
  assert.equal((await student.put('/api/v1/cbt/settings', { passMark: 1 })).status, 403);
  const e = await exams.post('/api/v1/cbt/exams', { title: 'Mathematics First Term Examination', category: 'exam', subjectId: maths, classId: cls.id, termId: S.A.termId,
    showResult: false, accessCode: 'MATHS-2026', scoreComponent: 'exam', instructions: 'Answer all questions.' });
  assert.equal(e.status, 200); ids.exam = e.body.id;
  let d = (await exams.get(`/api/v1/cbt/exams/${ids.exam}`)).body;
  assert.equal(Number(d.exam.pass_mark), 45, 'school default applied'); assert.equal(d.exam.show_answers, true); assert.equal(d.exam.has_access_code, true); assert.ok(!('access_code_hash' in d.exam));
  assert.ok(d.problems.some((p) => /question/.test(p)));
  assert.equal((await exams.post(`/api/v1/cbt/exams/${ids.exam}/publish`)).status, 400, 'incomplete exam cannot be published');
  const short = await exams.post(`/api/v1/cbt/exams/${ids.exam}/generate`, { rules: [{ count: 50, difficulty: 'hard' }] });
  assert.equal(short.status, 400); assert.match(short.body.error.message, /Not enough questions/);
  const g = await exams.post(`/api/v1/cbt/exams/${ids.exam}/generate`, { rules: [{ count: 5, difficulty: 'easy' }, { count: 4, difficulty: 'medium', type: 'mcq' }] });
  assert.equal(g.status, 200); assert.equal(g.body.added, 9);
  const fb = await exams.post(`/api/v1/cbt/exams/${ids.exam}/from-bank`, { questionIds: ids.bank });
  assert.equal(fb.body.added, 20 - 9 + (await db.query('SELECT count(*)::int AS n FROM cbt_questions WHERE exam_id = $1 AND source_question_id <> ALL($2::uuid[])', [ids.exam, ids.bank])).rows[0].n, 'duplicates skipped');
  d = (await exams.get(`/api/v1/cbt/exams/${ids.exam}`)).body;
  assert.ok(d.questions.length >= 20);
  // trim to exactly the 20 bank questions (exam of 20 questions)
  for (const q of d.questions.filter((x) => !ids.bank.includes(x.source_question_id))) assert.equal((await exams.del(`/api/v1/cbt/questions/${q.id}`)).status, 200);
  d = (await exams.get(`/api/v1/cbt/exams/${ids.exam}`)).body;
  assert.equal(d.questions.length, 20); assert.equal(d.totalMarks, 12 + 2 + 1 + 2 + 1 + 1 + 1 + 4);
  const rev = [...d.questions].reverse().map((q) => q.id);
  assert.equal((await exams.put(`/api/v1/cbt/exams/${ids.exam}/order`, { questionIds: rev.slice(1) })).status, 400);
  assert.equal((await exams.put(`/api/v1/cbt/exams/${ids.exam}/order`, { questionIds: rev })).status, 200);
  assert.equal((await exams.patch(`/api/v1/cbt/exams/${ids.exam}`, { durationMinutes: 30, allowBackNav: true })).status, 200);
  assert.equal((await exams.patch(`/api/v1/cbt/exams/${ids.exam}`, { startsAt: '2030-01-02T10:00:00Z', endsAt: '2030-01-02T09:00:00Z' })).status, 400);
});

test('candidates + scope: specific students only; teachers see only exams in their classes/subjects; other schools see nothing', async () => {
  const cands = await exams.get(`/api/v1/cbt/exams/${ids.exam}/candidates`);
  assert.equal(cands.body.mode, 'class'); assert.ok(cands.body.items.length >= 3);
  // a second student with a login who will NOT be a candidate
  const other = cands.body.items.find((s) => s.id !== ids.studentId);
  const acct = await owner.post('/api/v1/users', { fullName: `${other.first_name} ${other.last_name}`, loginId: 'sa.cbt.other', roleKeys: ['student'], link: { type: 'student', id: other.id } });
  assert.equal(acct.status, 200, JSON.stringify(acct.body));
  await H.client(S.app).post('/api/v1/auth/activate', { loginId: 'sa.cbt.other', accessCode: acct.body.accessCode, newPassword: 'Other-Student-2026' });
  ids.otherStudent = await H.login(S.app, 'sa.cbt.other', { password: 'Other-Student-2026' });
  // switch to explicit list, then remove everyone except our student + one more
  const keep = cands.body.items.filter((s) => s.id !== other.id).slice(0, 2).map((s) => s.id);
  if (!keep.includes(ids.studentId)) keep[0] = ids.studentId;
  const rm = await exams.del(`/api/v1/cbt/exams/${ids.exam}/candidates`, { studentIds: cands.body.items.map((s) => s.id).filter((x) => !keep.includes(x)) });
  assert.equal(rm.status, 200); assert.equal(rm.body.total, keep.length);
  assert.equal((await exams.get(`/api/v1/cbt/exams/${ids.exam}/candidates`)).body.mode, 'selected');
  assert.equal((await exams.post(`/api/v1/cbt/exams/${ids.exam}/candidates`, { studentIds: ['00000000-0000-4000-8000-000000000000'] })).status, 404);
  // scope inside the school: teacher2 teaches Mathematics → sees it; a teacher with no link to the class/subject does not
  assert.equal((await t2.get(`/api/v1/cbt/exams/${ids.exam}`)).status, 200);
  const t1staff = (await t1.get('/api/v1/auth/me')).body.staffId;
  const t1links = (await db.query('SELECT 1 FROM teacher_class_access WHERE staff_id = $1 AND class_id = $2 AND (subject_id IS NULL OR subject_id = $3)', [t1staff, cls.id, maths])).rowCount;
  assert.equal((await t1.get(`/api/v1/cbt/exams/${ids.exam}`)).status, t1links ? 200 : 404);
  if (!t1links) assert.ok(!(await t1.get('/api/v1/cbt/exams')).body.items.some((x) => x.id === ids.exam));
  // cross-tenant
  for (const u of [`/api/v1/cbt/exams/${ids.exam}`, `/api/v1/cbt/exams/${ids.exam}/candidates`, `/api/v1/cbt/exams/${ids.exam}/results`, `/api/v1/cbt/exams/${ids.exam}/analytics`]) assert.equal((await bOwner.get(u)).status, 404, u);
  assert.equal((await bOwner.post(`/api/v1/cbt/exams/${ids.exam}/publish`)).status, 404);
  assert.equal((await student.get(`/api/v1/cbt/exams/${ids.exam}`)).status, 403, 'students cannot use admin CBT functions');
});

let paper;
test('publish → notified; student needs the access code; paper has no keys; autosave, flags, resume, idempotent resync', async () => {
  assert.equal((await t2.post(`/api/v1/cbt/exams/${ids.exam}/publish`)).status, 403, 'teacher cannot publish');
  const pub = await owner.post(`/api/v1/cbt/exams/${ids.exam}/publish`); assert.equal(pub.status, 200, JSON.stringify(pub.body)); assert.equal(pub.body.lifecycle, 'active');
  const notes = (await student.get('/api/v1/notifications')).body.items; assert.ok(notes.some((n) => /Mathematics First Term/.test(n.title)));
  assert.equal((await exams.patch(`/api/v1/cbt/exams/${ids.exam}`, { durationMinutes: 5 })).status, 423, 'locked after publish');
  const av = (await student.get('/api/v1/cbt/available')).body.items.find((x) => x.id === ids.exam);
  assert.ok(av && av.needs_code); assert.equal(av.questions, 20);
  assert.ok(!(await ids.otherStudent.get('/api/v1/cbt/available')).body.items.some((x) => x.id === ids.exam), 'non-candidate does not see it');
  assert.equal((await ids.otherStudent.post(`/api/v1/cbt/exams/${ids.exam}/start`, { accessCode: 'MATHS-2026' })).status, 404);
  assert.equal((await bStudent.post(`/api/v1/cbt/exams/${ids.exam}/start`, { accessCode: 'MATHS-2026' })).status, 404, 'other school');
  assert.equal((await student.post(`/api/v1/cbt/exams/${ids.exam}/start`, { accessCode: 'WRONG' })).status, 403);
  const st = await student.post(`/api/v1/cbt/exams/${ids.exam}/start`, { accessCode: 'maths-2026' });
  assert.equal(st.status, 200, JSON.stringify(st.body)); paper = st.body;
  assert.ok(!/isCorrect|is_correct|answer_key|accepted|numericValue|"value"|explanation|theory_guide/.test(JSON.stringify(paper)), 'no answer key leaked');
  assert.equal(paper.questions.length, 20); assert.equal(paper.student.admissionNo.length > 0, true); assert.ok(paper.school.name);
  const mins = (new Date(paper.deadlineAt) - new Date(paper.serverNow)) / 60000; assert.ok(mins > 29 && mins <= 30.1, `deadline ${mins}`);
  // answer: all MCQ correct except two, multi-select exact, numeric, blank, short, TF, essay; flag two
  const key = new Map((await db.query('SELECT q.id, q.type, q.answer_key, array_agg(o.id) FILTER (WHERE o.is_correct) AS correct, array_agg(o.id) FILTER (WHERE NOT o.is_correct) AS wrong FROM cbt_questions q LEFT JOIN cbt_options o ON o.question_id = q.id WHERE q.exam_id = $1 GROUP BY q.id', [ids.exam])).rows.map((r) => [r.id, r]));
  let wrongMcq = 0; const batch = [];
  for (const q of paper.questions) {
    const k = key.get(q.id);
    if (q.type === 'mcq') { const miss = wrongMcq < 2; if (miss) wrongMcq++; batch.push({ questionId: q.id, optionId: miss ? k.wrong[0] : k.correct[0], flagged: miss, timeSpent: 30 }); }
    else if (q.type === 'multi_select') batch.push({ questionId: q.id, optionIds: k.correct, timeSpent: 40 });
    else if (q.type === 'true_false') batch.push({ questionId: q.id, optionId: k.correct[0] });
    else if (q.type === 'numeric') batch.push({ questionId: q.id, text: '12' });
    else if (q.type === 'fill_blank') batch.push({ questionId: q.id, text: '  Three ' });
    else if (q.type === 'short_answer') batch.push({ questionId: q.id, text: 'Hypotenuse' });
    else if (q.type === 'theory') batch.push({ questionId: q.id, text: '3x = 18, so x = 6' });
  }
  const ms = paper.questions.find((q) => q.type === 'mcq');
  assert.equal((await student.put(`/api/v1/cbt/attempts/${paper.attemptId}/answers`, { answers: [{ questionId: ms.id, optionIds: key.get(ms.id).correct.concat(key.get(ms.id).wrong.slice(0, 1)) }] })).status, 400, 'only one option for MCQ');
  assert.equal((await student.put(`/api/v1/cbt/attempts/${paper.attemptId}/answers`, { answers: batch })).status, 200);
  assert.equal((await student.put(`/api/v1/cbt/attempts/${paper.attemptId}/answers`, { answers: batch })).status, 200, 'resync after reconnect');
  const rows = (await db.query('SELECT count(*)::int AS n, sum(time_spent_seconds)::int AS t FROM cbt_answers WHERE attempt_id = $1', [paper.attemptId])).rows[0];
  assert.equal(rows.n, 20, 'no duplicate answers'); assert.ok(rows.t > 0);
  assert.equal((await ids.otherStudent.put(`/api/v1/cbt/attempts/${paper.attemptId}/answers`, { answers: batch.slice(0, 1) })).status, 404, 'IDOR blocked');
  // refresh → resume with saved answers + flags, same attempt, no code needed again
  const again = await student.post(`/api/v1/cbt/exams/${ids.exam}/start`, {});
  assert.equal(again.body.attemptId, paper.attemptId); assert.equal(again.body.questions.filter((q) => q.flagged).length, 2); assert.equal(again.body.questions.filter((q) => q.answer).length, 20);
});

test('submit: objective marked automatically, essay waits; duplicate submit refused; result hidden until released', async () => {
  const sub = await student.post(`/api/v1/cbt/attempts/${paper.attemptId}/submit`, {});
  assert.equal(sub.status, 200); assert.equal(sub.body.resultAvailable, false); assert.equal(sub.body.score, undefined);
  assert.equal((await student.post(`/api/v1/cbt/attempts/${paper.attemptId}/submit`, {})).status, 409);
  assert.equal((await student.put(`/api/v1/cbt/attempts/${paper.attemptId}/answers`, { answers: [{ questionId: paper.questions[0].id, text: 'late' }] })).status, 409);
  const at = (await db.query('SELECT * FROM cbt_attempts WHERE id = $1', [paper.attemptId])).rows[0];
  assert.equal(Number(at.objective_score), 24 - 4 - 2, 'all objective correct except 2 MCQ (24 marks, 4 are essay)'); assert.equal(at.needs_manual_grading, true);
  assert.equal((await student.get(`/api/v1/cbt/attempts/${paper.attemptId}/result`)).body.released, false);
  assert.equal((await student.post(`/api/v1/cbt/exams/${ids.exam}/start`, { accessCode: 'MATHS-2026' })).status, 403, 'no second attempt');
  // manual marking of the essay
  const rv = (await t2.get(`/api/v1/cbt/attempts/${paper.attemptId}/review`)).body;
  const essay = rv.items.find((i) => i.manual);
  assert.equal((await t2.post(`/api/v1/cbt/attempts/${paper.attemptId}/grade`, { grades: [{ questionId: essay.id, marks: 9 }] })).status, 400, 'above max');
  const objectiveQ = rv.items.find((i) => !i.manual);
  assert.equal((await t2.post(`/api/v1/cbt/attempts/${paper.attemptId}/grade`, { grades: [{ questionId: objectiveQ.id, marks: 1 }] })).status, 400, 'objective marks cannot be overridden');
  const gr = await t2.post(`/api/v1/cbt/attempts/${paper.attemptId}/grade`, { grades: [{ questionId: essay.id, marks: 3 }] });
  assert.equal(gr.body.complete, true);
  const res = (await exams.get(`/api/v1/cbt/exams/${ids.exam}/results`)).body.items.find((x) => x.studentId === ids.studentId);
  assert.equal(res.score, 21); assert.equal(res.maxScore, 24); assert.equal(res.percentage, 87.5); assert.ok(res.grade); assert.equal(res.passed, true); assert.equal(res.released, false);
  ids.result = res.resultId;
});

test('release / withhold; student result page (grade, counts, answers only if allowed); export CSV/XLSX', async () => {
  assert.equal((await t2.post(`/api/v1/cbt/results/${ids.result}/release`)).status, 403);
  assert.equal((await owner.post(`/api/v1/cbt/results/${ids.result}/release`)).status, 200);
  const r = (await student.get(`/api/v1/cbt/attempts/${paper.attemptId}/result`)).body;
  assert.equal(r.released, true); assert.equal(r.score, 21); assert.equal(r.percentage, 87.5); assert.ok(r.grade); assert.equal(r.passed, true);
  assert.equal(r.questions, 20); assert.equal(r.attempted, 20); assert.equal(r.correct, 17); assert.equal(r.incorrect, 2); assert.equal(r.unanswered, 0);
  assert.ok(Array.isArray(r.review) && r.review[0].correctAnswer !== undefined && r.review.some((x) => x.explanation), 'answers shown (show_answers on)');
  assert.ok((await student.get('/api/v1/notifications')).body.items.some((n) => /result .* released/i.test(n.title)));
  assert.equal((await ids.otherStudent.get(`/api/v1/cbt/attempts/${paper.attemptId}/result`)).status, 404);
  assert.equal((await owner.post(`/api/v1/cbt/results/${ids.result}/withhold`, { reason: 'Exam malpractice review' })).status, 200);
  assert.equal((await student.get(`/api/v1/cbt/attempts/${paper.attemptId}/result`)).body.released, false);
  assert.equal((await student.get('/api/v1/cbt/my-results')).body.items[0].score, null);
  assert.equal((await owner.post(`/api/v1/cbt/exams/${ids.exam}/release`, { release: true })).status, 200);
  assert.equal((await student.get(`/api/v1/cbt/attempts/${paper.attemptId}/result`)).body.released, false, 'bulk release skips withheld results');
  assert.equal((await owner.post(`/api/v1/cbt/results/${ids.result}/release`)).status, 200);
  const csv = await exams.get(`/api/v1/cbt/exams/${ids.exam}/results?format=csv`); assert.equal(csv.status, 200); assert.match(csv.raw.body, /PASS/);
  const xl = await exams.get(`/api/v1/cbt/exams/${ids.exam}/results?format=xlsx`); assert.equal(xl.status, 200); assert.match(xl.headers['content-type'], /spreadsheet/);
});

test('analytics: exam summary, per-question success, most-missed, topics, grades; class analytics; dashboard', async () => {
  const a = (await exams.get(`/api/v1/cbt/exams/${ids.exam}/analytics`)).body;
  assert.equal(a.summary.candidatesWithResults, 1); assert.equal(a.summary.average, 87.5); assert.equal(a.summary.passRate, 100);
  assert.equal(a.questions.length, 20); assert.ok(a.mostMissed[0].correct_rate === 0); assert.ok(a.topics.length >= 3); assert.equal(a.grades.reduce((t, g) => t + g.count, 0), 1);
  const ca = (await exams.get(`/api/v1/cbt/analytics?classId=${cls.id}&subjectId=${maths}`)).body;
  assert.equal(ca.summary.results, 1); assert.equal(ca.students[0].average, 87.5); assert.ok(ca.topics.length);
  const dash = (await exams.get('/api/v1/cbt/dashboard')).body;
  assert.ok(dash.cards.total >= 1 && dash.cards.active >= 1 && dash.cards.questions >= 23); assert.equal(dash.cards.averageScore, 87.5); assert.equal(dash.cards.passRate, 100);
  assert.equal((await student.get('/api/v1/cbt/dashboard')).status, 403);
});

test('CBT score → existing result sheet (scaled to the component) → broadsheet → report card; locked sheets refused; reset blocked after push', async () => {
  const dry = await exams.post(`/api/v1/cbt/exams/${ids.exam}/push-scores`, { dryRun: true });
  assert.equal(dry.status, 200, JSON.stringify(dry.body)); assert.equal(dry.body.rows.length, 1);
  assert.equal(dry.body.rows[0].score, Math.round(0.875 * Number(dry.body.component.max) * 10) / 10);
  assert.equal((await db.query('SELECT count(*)::int AS n FROM assessment_scores WHERE sheet_id = $1', [dry.body.sheetId])).rows[0].n, 0, 'dry run writes nothing');
  assert.equal((await t1.post(`/api/v1/cbt/exams/${ids.exam}/push-scores`, {})).status, 403);
  const push = await exams.post(`/api/v1/cbt/exams/${ids.exam}/push-scores`, {});
  assert.equal(push.status, 200, JSON.stringify(push.body)); assert.equal(push.body.written, 1);
  const expected = dry.body.rows[0].score;
  const sheet = (await exams.get(`/api/v1/results/sheets/${push.body.sheetId}`)).body;
  const row = sheet.rows.find((x) => x.studentId === ids.studentId);
  assert.equal(Number(row.scores.exam), expected); assert.ok(row.result && Number(row.result.total) === expected, 'server recomputed the total with the school grading');
  const bs = (await exams.get(`/api/v1/results/broadsheet?termId=${S.A.termId}&classId=${cls.id}`)).body;
  const si = bs.subjects.findIndex((s) => s.subjectId === maths);
  assert.equal(Number(bs.rows.find((x) => x.studentId === ids.studentId).scores[si].total), expected, 'broadsheet reflects the CBT score');
  const rc = (await exams.get(`/api/v1/results/student/${ids.studentId}?termId=${S.A.termId}`)).body;
  assert.equal(Number(rc.subjects.find((x) => x.subject === 'Mathematics').scores.exam), expected, 'report card reflects the CBT score');
  const at = (await db.query("SELECT id FROM cbt_attempts WHERE exam_id = $1 AND status <> 'void' LIMIT 1", [ids.exam])).rows[0];
  assert.equal((await owner.post(`/api/v1/cbt/attempts/${at.id}/reset`, { reason: 'test' })).status, 409);
  // once the subject sheet is submitted (existing workflow) CBT can no longer overwrite it
  await db.query("UPDATE assessments SET status = 'submitted' WHERE id = $1", [push.body.sheetId]);
  assert.equal((await exams.post(`/api/v1/cbt/exams/${ids.exam}/push-scores`, {})).status, 423);
  await db.query("UPDATE assessments SET status = 'draft' WHERE id = $1", [push.body.sheetId]);
});

test('timer expiry, no back navigation, no resume, reset attempt, close auto-submits', async () => {
  const mk = async (extra) => {
    const e = (await exams.post('/api/v1/cbt/exams', { title: `Quiz ${Math.random().toString(36).slice(2, 6)}`, subjectId: maths, classId: cls.id, durationMinutes: 10, showResult: true, maxAttempts: 1, shuffleQuestions: false, ...extra })).body.id;
    await exams.post(`/api/v1/cbt/exams/${e}/from-bank`, { questionIds: ids.bank.slice(0, 3) });
    assert.equal((await owner.post(`/api/v1/cbt/exams/${e}/publish`)).status, 200);
    return e;
  };
  // timer expiry: server clock decides; late save → auto-submitted
  const e1 = await mk({});
  const p1 = (await student.post(`/api/v1/cbt/exams/${e1}/start`, {})).body;
  await db.query("UPDATE cbt_attempts SET deadline_at = now() - interval '2 minutes' WHERE id = $1", [p1.attemptId]);
  const late = await student.put(`/api/v1/cbt/attempts/${p1.attemptId}/answers`, { answers: [{ questionId: p1.questions[0].id, optionId: p1.questions[0].options[0].id }] });
  assert.equal(late.body.timeUp, true);
  assert.equal((await db.query('SELECT status FROM cbt_attempts WHERE id = $1', [p1.attemptId])).rows[0].status, 'auto_submitted');
  assert.equal((await student.post(`/api/v1/cbt/attempts/${p1.attemptId}/submit`, {})).status, 409);
  // reset → can sit again (attempt kept as void for the record)
  const at1 = (await exams.get(`/api/v1/cbt/exams/${e1}/results`)).body.items.find((x) => x.studentId === ids.studentId);
  assert.equal((await t2.post(`/api/v1/cbt/attempts/${at1.lastAttemptId}/reset`, { reason: 'power failure' })).status, 403);
  assert.equal((await owner.post(`/api/v1/cbt/attempts/${at1.lastAttemptId}/reset`, { reason: 'Power failure in the CBT hall' })).status, 200);
  const p1b = await student.post(`/api/v1/cbt/exams/${e1}/start`, {}); assert.equal(p1b.status, 200); assert.notEqual(p1b.body.attemptId, p1.attemptId);
  // close auto-submits the live attempt
  const cl = await owner.post(`/api/v1/cbt/exams/${e1}/close`); assert.equal(cl.body.autoSubmitted, 1);
  // no back navigation (server-enforced)
  const e2 = await mk({ allowBackNav: false });
  const p2 = (await student.post(`/api/v1/cbt/exams/${e2}/start`, {})).body;
  assert.equal(p2.settings.allowBackNav, false);
  assert.equal((await student.put(`/api/v1/cbt/attempts/${p2.attemptId}/answers`, { answers: [{ questionId: p2.questions[2].id, optionId: p2.questions[2].options[0].id }] })).status, 200);
  assert.equal((await student.put(`/api/v1/cbt/attempts/${p2.attemptId}/answers`, { answers: [{ questionId: p2.questions[0].id, optionId: p2.questions[0].options[0].id }] })).status, 409);
  await student.post(`/api/v1/cbt/attempts/${p2.attemptId}/submit`, {});
  // no resume: re-opening submits what was saved
  const e3 = await mk({ allowResume: false });
  const p3 = (await student.post(`/api/v1/cbt/exams/${e3}/start`, {})).body;
  await student.put(`/api/v1/cbt/attempts/${p3.attemptId}/answers`, { answers: [{ questionId: p3.questions[0].id, optionId: p3.questions[0].options[0].id }] });
  const re = await student.post(`/api/v1/cbt/exams/${e3}/start`, {});
  assert.equal(re.body.resumeBlocked, true);
  assert.equal((await db.query('SELECT status FROM cbt_attempts WHERE id = $1', [p3.attemptId])).rows[0].status, 'auto_submitted');
  // scheduled exam: not startable before its window
  const e4 = (await exams.post('/api/v1/cbt/exams', { title: 'Future CBT', subjectId: maths, classId: cls.id, durationMinutes: 10, startsAt: new Date(Date.now() + 3 * 3600e3).toISOString() })).body.id;
  await exams.post(`/api/v1/cbt/exams/${e4}/from-bank`, { questionIds: ids.bank.slice(0, 2) });
  const pub4 = await owner.post(`/api/v1/cbt/exams/${e4}/publish`); assert.equal(pub4.body.lifecycle, 'scheduled');
  assert.equal((await student.post(`/api/v1/cbt/exams/${e4}/start`, {})).status, 403);
  assert.ok((await exams.get('/api/v1/cbt/exams?status=scheduled')).body.items.some((x) => x.id === e4));
  assert.ok((await db.query("SELECT 1 FROM jobs WHERE kind = 'cbt.reminder' AND payload->>'examId' = $1", [e4])).rowCount === 1, 'reminder queued');
});

test('audit log records the major CBT events', async () => {
  const acts = new Set((await db.query("SELECT action FROM audit_logs WHERE school_id = $1 AND action LIKE 'cbt.%'", [S.A.schoolId])).rows.map((r) => r.action));
  for (const a of ['cbt.bank_question_added', 'cbt.question_edited', 'cbt.question_deleted', 'cbt.questions_imported', 'cbt.exam_created', 'cbt.exam_updated', 'cbt.questions_generated', 'cbt.candidates_removed',
    'cbt.exam_published', 'cbt.attempt_started', 'cbt.attempt_submitted', 'cbt.attempt_graded', 'cbt.result_released', 'cbt.result_withheld', 'cbt.attempt_reset', 'cbt.scores_pushed', 'cbt.exam_closed']) assert.ok(acts.has(a), `missing ${a}`);
});
