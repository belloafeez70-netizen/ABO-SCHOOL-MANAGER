'use strict';
// Test harness: fresh PostgreSQL database per test file (real Postgres, real RLS, real migrations),
// two seeded schools, and an HTTP client that behaves like a browser (cookies, CSRF header, MFA).
process.env.NODE_ENV = 'test';
process.env.DATABASE_URL = process.env.TEST_DATABASE_URL || 'postgres://abo_app:abo_app_dev_password@127.0.0.1:5432/abo_erp_test';
process.env.MIGRATION_DATABASE_URL = process.env.TEST_MIGRATION_DATABASE_URL || 'postgres://abo_owner:abo_owner_dev_password@127.0.0.1:5432/abo_erp_test';
process.env.ARGON2_MEMORY_KIB = process.env.ARGON2_MEMORY_KIB || '8192';
process.env.ARGON2_TIME = process.env.ARGON2_TIME || '1';
process.env.RATE_LIMIT_GLOBAL_PER_MIN = '100000';
process.env.STORAGE_DIR = process.env.STORAGE_DIR || require('node:path').join(require('node:os').tmpdir(), 'abo-test-storage');
process.env.METRICS_TOKEN = 'test-metrics-token-1234567890';

const { Client } = require('pg');
const ADMIN_URL = process.env.TEST_ADMIN_URL || 'postgres://postgres@127.0.0.1:5432/postgres';
const totp = require('../src/security/totp');

async function resetDb() {
  const a = new Client({ connectionString: ADMIN_URL }); await a.connect();
  await a.query('DROP DATABASE IF EXISTS abo_erp_test WITH (FORCE)');
  await a.query("CREATE DATABASE abo_erp_test OWNER abo_owner ENCODING 'UTF8'");
  await a.query('REVOKE ALL ON DATABASE abo_erp_test FROM PUBLIC');
  await a.query('GRANT CONNECT ON DATABASE abo_erp_test TO abo_app');
  await a.end();
  const d = new Client({ connectionString: ADMIN_URL.replace(/\/postgres$/, '/abo_erp_test') }); await d.connect();
  await d.query('CREATE EXTENSION IF NOT EXISTS pg_trgm'); await d.query('ALTER SCHEMA public OWNER TO abo_owner'); await d.query('REVOKE CREATE ON SCHEMA public FROM PUBLIC');
  await d.end();
  await require('../src/db/migrate').migrate({ url: process.env.MIGRATION_DATABASE_URL, log: () => {} });
}

// direct DB clients for low-level assertions
async function dbAs(role) {
  const url = role === 'app' ? process.env.DATABASE_URL : role === 'owner' ? process.env.MIGRATION_DATABASE_URL : ADMIN_URL.replace(/\/postgres$/, '/abo_erp_test');
  const c = new Client({ connectionString: url }); await c.connect(); return c;
}

let ipCounter = 10;
const mfaSecrets = new Map(); const lastStep = new Map();
function codeFor(loginId) {
  const secret = mfaSecrets.get(loginId);
  const step = Math.max(totp.stepAt(), (lastStep.get(loginId) ?? -1) + 1);
  lastStep.set(loginId, step);
  return totp.hotp(secret, step);
}

function client(app, { ip } = {}) {
  const jar = new Map(); let csrf = null;
  const remoteAddress = ip || `10.1.${Math.floor(ipCounter / 250)}.${(ipCounter++ % 250) + 1}`;
  async function req(method, url, body, opts = {}) {
    const headers = { ...(opts.headers || {}) };
    if (jar.size) headers.cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    if (csrf && !opts.noCsrf && method !== 'GET') headers['x-csrf-token'] = csrf;
    let payload;
    if (opts.multipart) { payload = opts.multipart.body; headers['content-type'] = opts.multipart.contentType; }
    else if (body !== undefined) { payload = typeof body === 'string' ? body : JSON.stringify(body); headers['content-type'] = headers['content-type'] || 'application/json'; }
    const res = await app.inject({ method, url, payload, headers, remoteAddress });
    for (const sc of [].concat(res.headers['set-cookie'] || [])) {
      const [kv] = sc.split(';'); const i = kv.indexOf('='); const k = kv.slice(0, i); const v = kv.slice(i + 1);
      if (/Max-Age=0|Expires=Thu, 01 Jan 1970/i.test(sc) || v === '') jar.delete(k); else jar.set(k, v);
    }
    let json = null; try { json = res.json(); } catch { /* not json */ }
    if (json && json.csrf) csrf = json.csrf;
    return { status: res.statusCode, body: json, raw: res, headers: res.headers };
  }
  return {
    ip: remoteAddress, jar,
    get: (u, o) => req('GET', u, undefined, o), post: (u, b, o) => req('POST', u, b, o), put: (u, b, o) => req('PUT', u, b, o),
    patch: (u, b, o) => req('PATCH', u, b, o), del: (u, b, o) => req('DELETE', u, b, o), req,
    setCsrf: (v) => { csrf = v; }, getCsrf: () => csrf,
  };
}

const PASSWORD = 'Demo#School2026';
// Full browser-like sign-in incl. MFA enrolment/verification where the role requires it.
async function login(app, loginId, { password = PASSWORD, ip } = {}) {
  const c = client(app, { ip });
  const r = await c.post('/api/v1/auth/login', { loginId, password });
  if (r.status !== 200) throw new Error(`login ${loginId} failed: ${r.status} ${JSON.stringify(r.body)}`);
  if (r.body.mfaEnrollRequired) {
    const s = await c.post('/api/v1/auth/mfa/setup', {});
    mfaSecrets.set(loginId, s.body.secret);
    const e = await c.post('/api/v1/auth/mfa/enable', { code: codeFor(loginId) });
    if (e.status !== 200) throw new Error(`mfa enable failed ${JSON.stringify(e.body)}`);
    c.recoveryCodes = e.body.recoveryCodes;
  } else if (r.body.mfaRequired) {
    const v = await c.post('/api/v1/auth/mfa/verify', { code: codeFor(loginId) });
    if (v.status !== 200) throw new Error(`mfa verify failed ${JSON.stringify(v.body)}`);
  }
  await c.get('/api/v1/auth/me');       // refresh csrf
  return c;
}

let shared = null;
async function setup() {
  if (shared) return shared;
  await resetDb();
  const { seedSchool, seedPlatformAdmin } = require('../src/db/seed-dev');
  await seedPlatformAdmin();
  const A = await seedSchool({ code: 'school-a', name: 'School A', type: 'mixed', prefix: 'sa', studentsPerClass: 5 });
  const B = await seedSchool({ code: 'school-b', name: 'School B', type: 'secondary', prefix: 'sb', studentsPerClass: 3 });
  const { buildApp } = require('../src/app');
  const app = buildApp({ logger: process.env.DBG ? { level: 'error' } : false });
  await app.ready();
  shared = { app, A, B };
  return shared;
}
async function teardown() {
  if (!shared) return;
  await shared.app.close();
  await require('../src/db/pool').pool.end();
  shared = null;
}
// minimal multipart builder
function multipart(fields, file) {
  const boundary = '----abo' + Math.random().toString(16).slice(2);
  const parts = [];
  for (const [k, v] of Object.entries(fields || {})) parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`));
  if (file) {
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${file.name}"\r\nContent-Type: ${file.type || 'application/octet-stream'}\r\n\r\n`));
    parts.push(Buffer.isBuffer(file.data) ? file.data : Buffer.from(file.data)); parts.push(Buffer.from('\r\n'));
  }
  parts.push(Buffer.from(`--${boundary}--\r\n`));
  return { body: Buffer.concat(parts), contentType: `multipart/form-data; boundary=${boundary}` };
}
const PNG_1PX = Buffer.from('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d49444154789c6300010000000500010d0a2db40000000049454e44ae426082', 'hex');

module.exports = { setup, teardown, login, client, dbAs, multipart, PNG_1PX, PASSWORD, codeFor, mfaSecrets };
