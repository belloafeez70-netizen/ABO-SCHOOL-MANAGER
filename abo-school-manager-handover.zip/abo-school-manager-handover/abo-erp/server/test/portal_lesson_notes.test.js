'use strict';
// Website parity: admission-number / phone sign-in, access code in the password box, and the Lesson Notes module.
const H = require('./helpers');
const test = require('node:test');
const assert = require('node:assert/strict');

let S, owner, head, teacher, teacher2, student, parent, ownerB, studentB, acad, cls, cls2, termId;
const subj = (name) => acad.subjects.find((s) => s.name === name).id;
const L = '/api/v1/auth/login';

test.before(async () => {
  S = await H.setup();
  [owner, teacher, teacher2, student, parent, ownerB, studentB] = await Promise.all(['sa.owner', 'sa.teacher1', 'sa.teacher2', 'sa.student', 'sa.parent', 'sb.owner', 'sb.student'].map((l) => H.login(S.app, l)));
  head = owner;                                                    // school owner holds lesson_notes.review
  acad = (await owner.get('/api/v1/academic')).body;
  cls = S.A.classes.find((c) => c.display_name === 'BASIC 1A'); cls2 = S.A.classes.find((c) => c.display_name === 'BASIC 1B');
  termId = S.A.termId;
});
test.after(() => H.teardown());

// ───────── sign-in identifiers ─────────
test('student signs in with ADMISSION NUMBER (school page or unique match); staff tab and other schools do not resolve it', async () => {
  const c = H.client(S.app);
  let r = await c.post(L, { loginId: 'sa/0001', password: H.PASSWORD, schoolId: S.A.schoolId, portal: 'student' });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.equal((await c.get('/api/v1/auth/me')).body.user.loginId, 'sa.student');
  r = await H.client(S.app).post(L, { loginId: 'SA/0001', password: H.PASSWORD, portal: 'student' });
  assert.equal(r.status, 200, 'unique across the platform → general sign-in also works');
  assert.equal((await H.client(S.app).post(L, { loginId: 'SA/0001', password: H.PASSWORD, schoolId: S.A.schoolId, portal: 'staff' })).status, 401, 'staff tab never resolves admission numbers');
  assert.equal((await H.client(S.app).post(L, { loginId: 'SB/0001', password: H.PASSWORD, schoolId: S.A.schoolId, portal: 'student' })).status, 401, "another school's admission number is not found on this school's page");
  assert.equal((await H.client(S.app).post(L, { loginId: 'SA/0001', password: 'wrong-password', schoolId: S.A.schoolId, portal: 'student' })).status, 401);
});

test('parent signs in with PHONE NUMBER in any Nigerian format; a number shared across schools is refused on the general page', async () => {
  // the seed gives both schools' parents the same number 08030000001
  for (const phone of ['08030000001', '+234 803 000 0001', '2348030000001', '0803-000-0001']) {
    const c = H.client(S.app);
    const r = await c.post(L, { loginId: phone, password: H.PASSWORD, schoolId: S.A.schoolId, portal: 'parent' });
    assert.equal(r.status, 200, `${phone}: ${JSON.stringify(r.body)}`);
    assert.equal((await c.get('/api/v1/auth/me')).body.user.loginId, 'sa.parent');
  }
  const b = H.client(S.app);
  assert.equal((await b.post(L, { loginId: '08030000001', password: H.PASSWORD, schoolId: S.B.schoolId, portal: 'parent' })).status, 200);
  assert.equal((await b.get('/api/v1/auth/me')).body.user.loginId, 'sb.parent', 'school B page resolves school B parent');
  const amb = await H.client(S.app).post(L, { loginId: '08030000001', password: H.PASSWORD, portal: 'parent' });
  assert.equal(amb.status, 401, 'ambiguous (two accounts) → never guess');
  assert.equal(amb.body.error.code, 'INVALID_CREDENTIALS');
});

test('first sign-in with the ACCESS CODE in the password box → create password → sign in (code single-use)', async () => {
  const st = (await owner.get('/api/v1/students?pageSize=50')).body.items.find((s) => !s.has_account);
  const u = await owner.post('/api/v1/users', { fullName: 'Code Pupil', loginId: 'sa.codepupil', roleKeys: ['student'], link: { type: 'student', id: st.id } });
  assert.equal(u.status, 200);
  const c = H.client(S.app);
  const r = await c.post(L, { loginId: st.admission_no, password: u.body.accessCode.toLowerCase(), schoolId: S.A.schoolId, portal: 'student' });
  assert.equal(r.status, 200); assert.equal(r.body.activationRequired, true); assert.equal(r.body.loginId, 'sa.codepupil');
  assert.equal(c.jar.size, 0, 'no session is created by an access code');
  assert.equal((await c.get('/api/v1/auth/me')).status, 401);
  const a = await c.post('/api/v1/auth/activate', { loginId: st.admission_no, accessCode: u.body.accessCode, newPassword: 'Pupil-Pass-2026', schoolId: S.A.schoolId, portal: 'student' });
  assert.equal(a.status, 200, JSON.stringify(a.body));
  assert.equal((await c.post(L, { loginId: st.admission_no, password: u.body.accessCode, schoolId: S.A.schoolId, portal: 'student' })).status, 401, 'code is spent');
  const ok = await c.post(L, { loginId: st.admission_no, password: 'Pupil-Pass-2026', schoolId: S.A.schoolId, portal: 'student' });
  assert.equal(ok.status, 200); assert.ok(!ok.body.activationRequired);
  assert.equal((await c.get('/api/v1/auth/me')).body.studentId, st.id);
});

test('a disabled account cannot be re-activated with an old access code', async () => {
  const st = (await owner.get('/api/v1/students?pageSize=50')).body.items.find((s) => !s.has_account);
  const u = await owner.post('/api/v1/users', { fullName: 'Blocked Pupil', loginId: 'sa.blocked', roleKeys: ['student'], link: { type: 'student', id: st.id } });
  assert.equal((await owner.post(`/api/v1/users/${u.body.user.id}/status`, { status: 'disabled', reason: 'Left the school' })).status, 200);
  const c = H.client(S.app);
  assert.equal((await c.post(L, { loginId: 'sa.blocked', password: u.body.accessCode })).status, 401);
  assert.equal((await c.post('/api/v1/auth/activate', { loginId: 'sa.blocked', accessCode: u.body.accessCode, newPassword: 'Blocked-Pass-2026' })).status, 401);
});

// ───────── lesson notes ─────────
const base = () => ({ termId, classId: cls.id, week: 3, topic: 'Verbs and tenses', content: 'Introduction… Step 1… Step 2…', objectives: 'Identify verbs', evaluation: 'Underline the verbs.' });

test('lesson notes: teachers write only for their assigned class/subject; others cannot see drafts', async () => {
  const opts = await teacher.get('/api/v1/lesson-notes/options');
  assert.equal(opts.status, 200); assert.equal(opts.body.allClasses, false);
  assert.ok(opts.body.pairs.every((p) => p.subject), 'every option is a class/subject pair');
  assert.equal((await teacher.post('/api/v1/lesson-notes', { ...base(), subjectId: subj('Mathematics') })).status, 403, 'Mathematics is taught by teacher2');
  const r = await teacher.post('/api/v1/lesson-notes', { ...base(), subjectId: subj('English Language') });
  assert.equal(r.status, 200, JSON.stringify(r.body)); assert.equal(r.body.status, 'draft');
  assert.equal((await teacher2.get(`/api/v1/lesson-notes/${r.body.id}`)).status, 404, 'another teacher cannot open it');
  assert.ok(!(await teacher2.get('/api/v1/lesson-notes')).body.items.some((x) => x.id === r.body.id), 'teacher list is own notes only');
  assert.equal((await student.get(`/api/v1/lesson-notes/${r.body.id}`)).status, 404, 'students never see drafts');
  assert.equal((await student.get('/api/v1/lesson-notes')).status, 403, 'staff list is staff-only');
  assert.equal((await ownerB.get(`/api/v1/lesson-notes/${r.body.id}`)).status, 404, 'tenant isolation');
  assert.equal((await teacher.post('/api/v1/lesson-notes', { ...base(), subjectId: subj('English Language'), week: 40 })).status, 400, 'validated');
});

test('lesson notes workflow: edit (versioned) → submit → return (comment required) → fix → approve → class can read it', async () => {
  const c = await teacher.post('/api/v1/lesson-notes', { ...base(), week: 4, topic: 'Adjectives', subjectId: subj('English Language') });
  const id = c.body.id;
  assert.equal((await teacher.patch(`/api/v1/lesson-notes/${id}`, { version: 99, topic: 'x y' })).status, 409, 'stale version');
  const e = await teacher.patch(`/api/v1/lesson-notes/${id}`, { version: c.body.version, subtopic: 'Comparison of adjectives' });
  assert.equal(e.status, 200); assert.equal(e.body.version, c.body.version + 1);
  // attachment (image) while editable
  const up = await teacher.post(`/api/v1/lesson-notes/${id}/attachment`, null, { multipart: H.multipart({}, { name: 'chart.png', type: 'image/png', data: H.PNG_1PX }) });
  assert.equal(up.status, 200, JSON.stringify(up.body));
  assert.equal((await teacher.post(`/api/v1/lesson-notes/${id}/attachment`, null, { multipart: H.multipart({}, { name: 'x.html', type: 'text/html', data: '<script>alert(1)</script>' }) })).status, 400, 'unsafe type refused');
  assert.equal((await teacher.post(`/api/v1/lesson-notes/${id}/submit`, {})).status, 200);
  assert.equal((await teacher.patch(`/api/v1/lesson-notes/${id}`, { version: e.body.version + 2, topic: 'Changed' })).status, 409, 'locked while under review');
  assert.equal((await teacher.post(`/api/v1/lesson-notes/${id}/review`, { decision: 'approve' })).status, 403, 'teachers cannot review');
  const notes = (await head.get('/api/v1/notifications')).body.items; assert.ok(notes.some((n) => n.kind === 'lesson_note'), 'reviewers notified');
  const queue = await head.get('/api/v1/lesson-notes?scope=review'); assert.ok(queue.body.items.some((x) => x.id === id));
  assert.equal((await head.post(`/api/v1/lesson-notes/${id}/review`, { decision: 'return' })).status, 400, 'return needs a comment');
  assert.equal((await head.post(`/api/v1/lesson-notes/${id}/review`, { decision: 'return', note: 'Add two more examples.' })).status, 200);
  const back = await teacher.get(`/api/v1/lesson-notes/${id}`);
  assert.equal(back.body.status, 'returned'); assert.equal(back.body.review_note, 'Add two more examples.'); assert.equal(back.body.can.edit, true);
  assert.equal((await teacher.patch(`/api/v1/lesson-notes/${id}`, { version: back.body.version, content: 'Now with examples.' })).status, 200);
  assert.equal((await teacher.post(`/api/v1/lesson-notes/${id}/submit`, {})).status, 200);
  assert.equal((await student.get(`/api/v1/lesson-notes/${id}`)).status, 404, 'still hidden before approval');
  assert.equal((await head.post(`/api/v1/lesson-notes/${id}/review`, { decision: 'approve' })).status, 200);
  // learners of BASIC 1A (and their parents) can now read it; review fields are not exposed to them
  const mine = await student.get('/api/v1/my/lesson-notes'); assert.ok(mine.body.items.some((x) => x.id === id));
  const one = await student.get(`/api/v1/lesson-notes/${id}`); assert.equal(one.status, 200); assert.equal(one.body.review_note, undefined); assert.equal(one.body.topic, 'Adjectives');
  assert.equal((await student.get(`/api/v1/files/${up.body.fileId}`)).status, 200, 'student can open the attachment of an approved note');
  assert.ok((await parent.get('/api/v1/my/lesson-notes')).body.items.some((x) => x.id === id));
  assert.equal((await studentB.get(`/api/v1/lesson-notes/${id}`)).status, 404, 'other school');
  assert.equal((await studentB.get(`/api/v1/files/${up.body.fileId}`)).status, 404);
  assert.equal((await teacher.patch(`/api/v1/lesson-notes/${id}`, { version: 50, topic: 'Changed' })).status, 409, 'approved notes are locked');
  assert.equal((await teacher.del(`/api/v1/lesson-notes/${id}`)).status, 409, 'approved notes cannot be deleted');
  // reopen → hidden again
  assert.equal((await head.post(`/api/v1/lesson-notes/${id}/reopen`, { note: 'Spelling error in step 2' })).status, 200);
  assert.ok(!(await student.get('/api/v1/my/lesson-notes')).body.items.some((x) => x.id === id));
  const audit = await owner.get('/api/v1/audit?pageSize=100');
  const acts = audit.body.items.map((a) => a.action);
  for (const a of ['lesson_notes.created', 'lesson_notes.submitted', 'lesson_notes.returned', 'lesson_notes.approved', 'lesson_notes.reopened']) assert.ok(acts.includes(a), a);
});

test('lesson notes: authors cannot approve their own note; notes for another class stay invisible to this class', async () => {
  const own = await head.post('/api/v1/lesson-notes', { ...base(), week: 5, topic: 'Head note', subjectId: subj('Mathematics') });
  assert.equal(own.status, 200, 'heads may write for any class');
  await head.post(`/api/v1/lesson-notes/${own.body.id}/submit`, {});
  assert.equal((await head.post(`/api/v1/lesson-notes/${own.body.id}/review`, { decision: 'approve' })).status, 403, 'no self-approval');
  const other = await teacher.post('/api/v1/lesson-notes', { ...base(), classId: cls2.id, week: 6, topic: 'BASIC 1B only', subjectId: subj('English Language') });
  await teacher.post(`/api/v1/lesson-notes/${other.body.id}/submit`, {});
  assert.equal((await head.post(`/api/v1/lesson-notes/${other.body.id}/review`, { decision: 'approve' })).status, 200);
  assert.equal((await student.get(`/api/v1/lesson-notes/${other.body.id}`)).status, 404, 'BASIC 1A pupil cannot read a BASIC 1B note');
  const sum = await head.get(`/api/v1/lesson-notes/summary?termId=${termId}`);
  assert.equal(sum.status, 200); assert.ok(sum.body.totals.approved >= 2); assert.ok(Array.isArray(sum.body.missing));
  assert.equal((await teacher.get(`/api/v1/lesson-notes/summary?termId=${termId}`)).status, 403, 'compliance report is for heads');
  const perms = (await teacher.get('/api/v1/auth/me')).body.permissions;
  assert.ok(perms.includes('lesson_notes.create') && !perms.includes('lesson_notes.review'));
});
