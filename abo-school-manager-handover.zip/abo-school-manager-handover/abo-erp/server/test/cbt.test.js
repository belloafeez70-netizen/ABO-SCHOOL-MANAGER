'use strict';
const H = require('./helpers');
const test = require('node:test');
const assert = require('node:assert/strict');
let S, teacher, owner, student, examId, cls;
test.before(async () => {
  S = await H.setup();
  [teacher, owner, student] = await Promise.all(['sa.teacher1', 'sa.owner', 'sa.student'].map((l) => H.login(S.app, l)));
  cls = S.A.classes.find((c) => c.display_name === 'BASIC 1A');
});
test.after(() => H.teardown());

test('build exam: MCQ needs exactly one correct option; publish needs questions; teacher cannot publish', async () => {
  const e = await teacher.post('/api/v1/cbt/exams', { title: 'Maths Test 1', durationMinutes: 20, classId: cls.id, maxAttempts: 1, showResult: true });
  examId = e.body.id;
  assert.equal((await teacher.post(`/api/v1/cbt/exams/${examId}/questions`, { type: 'mcq', text: '2+2?', options: [{ text: '3' }, { text: '4' }] })).status, 400);
  assert.equal((await teacher.post(`/api/v1/cbt/exams/${examId}/questions`, { type: 'mcq', text: '2+2?', marks: 2, options: [{ text: '3' }, { text: '4', isCorrect: true }, { text: '5' }] })).status, 200);
  assert.equal((await teacher.post(`/api/v1/cbt/exams/${examId}/questions`, { type: 'true_false', text: 'Lagos is in Nigeria', correct: true })).status, 200);
  assert.equal((await teacher.post(`/api/v1/cbt/exams/${examId}/questions`, { type: 'theory', text: 'Explain photosynthesis', marks: 5 })).status, 200);
  assert.equal((await teacher.post(`/api/v1/cbt/exams/${examId}/publish`, {})).status, 403);
  assert.equal((await owner.post(`/api/v1/cbt/exams/${examId}/publish`, {})).status, 200);
  assert.equal((await teacher.post(`/api/v1/cbt/exams/${examId}/questions`, { type: 'theory', text: 'late add' })).status, 423, 'locked after publish');
});
let paper;
test('student paper never contains correct answers; deadline is server-side', async () => {
  const av = await student.get('/api/v1/cbt/available'); assert.ok(av.body.items.some((x) => x.id === examId));
  const st = await student.post(`/api/v1/cbt/exams/${examId}/start`, {}); assert.equal(st.status, 200);
  paper = st.body;
  const txt = JSON.stringify(paper);
  assert.ok(!/isCorrect|is_correct|correct/.test(txt), 'no answer key leaked');
  assert.ok(new Date(paper.deadlineAt) > new Date()); assert.equal(paper.questions.length, 3);
  const again = await student.post(`/api/v1/cbt/exams/${examId}/start`, {}); assert.equal(again.body.attemptId, paper.attemptId, 'resume, not a new attempt');
});
test('answers: options must belong to the question; other users cannot touch the attempt', async () => {
  const mcq = paper.questions.find((q) => q.type === 'mcq'); const tf = paper.questions.find((q) => q.type === 'true_false');
  const wrongOpt = await student.put(`/api/v1/cbt/attempts/${paper.attemptId}/answers`, { answers: [{ questionId: mcq.id, optionId: tf.options[0].id }] });
  assert.equal(wrongOpt.status, 400);
  const four = mcq.options.find((o) => o.text === '4'); const tru = tf.options.find((o) => o.text === 'True');
  const theory = paper.questions.find((q) => q.type === 'theory');
  assert.equal((await student.put(`/api/v1/cbt/attempts/${paper.attemptId}/answers`, { answers: [{ questionId: mcq.id, optionId: four.id }, { questionId: tf.id, optionId: tru.id }, { questionId: theory.id, text: 'Plants make food using light.' }] })).status, 200);
  const other = await H.login(S.app, 'sa.teacher2');
  assert.equal((await other.put(`/api/v1/cbt/attempts/${paper.attemptId}/answers`, { answers: [{ questionId: mcq.id, optionId: four.id }] })).status, 403);
});
test('server grades objective questions; theory pending manual grading; attempts limited', async () => {
  const forged = await student.post(`/api/v1/cbt/attempts/${paper.attemptId}/submit`, { score: 8, maxScore: 8 });
  assert.equal(forged.status, 400, 'client-supplied scores are rejected outright');
  const sub = await student.post(`/api/v1/cbt/attempts/${paper.attemptId}/submit`, {});
  assert.equal(sub.status, 200); assert.equal(sub.body.objectiveScore, 3); assert.equal(sub.body.maxScore, 8); assert.equal(sub.body.pendingTheory, true);
  assert.equal((await student.post(`/api/v1/cbt/attempts/${paper.attemptId}/submit`, {})).status, 409);
  assert.equal((await student.post(`/api/v1/cbt/exams/${examId}/start`, {})).status, 403, 'max attempts');
  const rev = await teacher.get(`/api/v1/cbt/attempts/${paper.attemptId}/review`);
  const theory = rev.body.items.find((i) => i.type === 'theory');
  assert.equal((await teacher.post(`/api/v1/cbt/attempts/${paper.attemptId}/grade`, { grades: [{ questionId: theory.id, marks: 6 }] })).status, 400, 'cannot exceed marks');
  const mcq = rev.body.items.find((i) => i.type === 'mcq');
  assert.equal((await teacher.post(`/api/v1/cbt/attempts/${paper.attemptId}/grade`, { grades: [{ questionId: mcq.id, marks: 2 }] })).status, 400, 'objective answers are machine-graded only');
  const g = await teacher.post(`/api/v1/cbt/attempts/${paper.attemptId}/grade`, { grades: [{ questionId: theory.id, marks: 4 }] });
  assert.equal(g.body.complete, true);
  const mine = await student.get('/api/v1/cbt/my-results'); assert.equal(Number(mine.body.items[0].score), 7);
});
test('late answers are refused and the attempt is auto-submitted (server clock)', async () => {
  const e = await teacher.post('/api/v1/cbt/exams', { title: 'Quick quiz', durationMinutes: 1, classId: cls.id });
  await teacher.post(`/api/v1/cbt/exams/${e.body.id}/questions`, { type: 'true_false', text: 'Sky is blue', correct: true });
  await owner.post(`/api/v1/cbt/exams/${e.body.id}/publish`, {});
  const p = await student.post(`/api/v1/cbt/exams/${e.body.id}/start`, {});
  const db = await H.dbAs('owner');
  try {
    await db.query("UPDATE cbt_attempts SET deadline_at = now() - interval '2 minutes' WHERE id = $1", [p.body.attemptId]);
    const late = await student.put(`/api/v1/cbt/attempts/${p.body.attemptId}/answers`, { answers: [{ questionId: p.body.questions[0].id, optionId: p.body.questions[0].options[0].id }] });
    assert.equal(late.status, 200); assert.equal(late.body.timeUp, true);
    assert.equal((await db.query('SELECT count(*)::int AS n FROM cbt_answers WHERE attempt_id = $1', [p.body.attemptId])).rows[0].n, 0, 'late answer not stored');
    assert.equal((await db.query('SELECT status FROM cbt_attempts WHERE id = $1', [p.body.attemptId])).rows[0].status, 'auto_submitted');
  } finally { await db.end(); }
});
test('worker sweep auto-submits abandoned attempts past their deadline', async () => {
  const e = await teacher.post('/api/v1/cbt/exams', { title: 'Abandoned', durationMinutes: 1, classId: cls.id });
  await teacher.post(`/api/v1/cbt/exams/${e.body.id}/questions`, { type: 'true_false', text: 'x', correct: false });
  await owner.post(`/api/v1/cbt/exams/${e.body.id}/publish`, {});
  const p = await student.post(`/api/v1/cbt/exams/${e.body.id}/start`, {});
  const db = await H.dbAs('owner');
  try {
    await db.query("UPDATE cbt_attempts SET deadline_at = now() - interval '5 minutes' WHERE id = $1", [p.body.attemptId]);
    await require('../src/jobs/worker').sweep();
    assert.equal((await db.query('SELECT status FROM cbt_attempts WHERE id = $1', [p.body.attemptId])).rows[0].status, 'auto_submitted');
  } finally { await db.end(); }
});
