'use strict';
// Cross-school isolation: every attempt by School A users to reach School B data must fail —
// through the API (IDOR/BOLA) AND at the database layer (RLS + composite foreign keys).
const H = require('./helpers');
const test = require('node:test');
const assert = require('node:assert/strict');

let S, A, B, aOwner, aTeacher, aBursar, aStudent, aParent, aExam, bOwner, bIds = {};
test.before(async () => {
  S = await H.setup(); A = S.A; B = S.B;
  aOwner = await H.login(S.app, 'sa.owner'); aTeacher = await H.login(S.app, 'sa.teacher1'); aBursar = await H.login(S.app, 'sa.bursar');
  aStudent = await H.login(S.app, 'sa.student'); aParent = await H.login(S.app, 'sa.parent'); aExam = await H.login(S.app, 'sa.exams');
  bOwner = await H.login(S.app, 'sb.owner');
  // create School B resources through B's own API
  const st = await bOwner.get('/api/v1/students?pageSize=1'); bIds.student = st.body.items[0].id;
  const ac = await bOwner.get('/api/v1/academic'); bIds.class = ac.body.classes[0].id; bIds.subject = ac.body.subjects[0].id;
  bIds.term = ac.body.sessions[0].terms.find((t) => t.is_current).id;
  const sh = await bOwner.post('/api/v1/results/sheets', { termId: bIds.term, classId: bIds.class, subjectId: bIds.subject }); bIds.sheet = sh.body.id;
  const ex = await bOwner.post('/api/v1/cbt/exams', { title: 'B secret exam', durationMinutes: 10 }); bIds.exam = ex.body.id;
  await bOwner.post(`/api/v1/cbt/exams/${bIds.exam}/questions`, { type: 'true_false', text: 'B question', correct: true });
  await bOwner.post('/api/v1/fees/invoices/generate', { termId: bIds.term });
  const inv = await bOwner.get('/api/v1/fees/invoices?pageSize=1'); bIds.invoice = inv.body.items[0].id;
  const users = await bOwner.get('/api/v1/users?pageSize=100'); bIds.user = users.body.items.find((u) => u.login_id === 'sb.teacher1').id;
  const an = await bOwner.post('/api/v1/announcements', { title: 'B only notice', body: 'secret B', audience: 'all' }); bIds.announcement = an.body.id;
  const logo = await bOwner.post('/api/v1/school/logo', undefined, { multipart: H.multipart({}, { name: 'logo.png', type: 'image/png', data: H.PNG_1PX }) }); bIds.file = logo.body.fileId;
  const doc = await bOwner.post('/api/v1/documents', undefined, { multipart: H.multipart({ title: 'B contract' }, { name: 'c.pdf', data: '%PDF-1.4 secret' }) }); bIds.doc = doc.body.id; bIds.docFile = doc.body.fileId;
  const role = await bOwner.get('/api/v1/roles'); bIds.role = role.body.items.find((r) => r.key === 'teacher').id;
});
test.after(() => H.teardown());

const DENIED = [403, 404];
test('School A owner cannot read, edit or delete School B students', async () => {
  assert.ok(DENIED.includes((await aOwner.get(`/api/v1/students/${bIds.student}`)).status));
  assert.ok(DENIED.includes((await aOwner.patch(`/api/v1/students/${bIds.student}`, { firstName: 'Hacked' })).status));
  assert.ok(DENIED.includes((await aOwner.del(`/api/v1/students/${bIds.student}`, { reason: 'attack' })).status));
  const list = await aOwner.get('/api/v1/students?pageSize=100');
  assert.ok(list.body.items.every((s) => s.id !== bIds.student)); assert.ok(list.body.items.every((s) => s.admission_no.startsWith('SA/')));
  const still = await bOwner.get(`/api/v1/students/${bIds.student}`); assert.notEqual(still.body.student.first_name, 'Hacked');
});
test('School A admin/exam officer cannot reach School B results or broadsheet', async () => {
  for (const c of [aOwner, aExam]) {
    assert.ok(DENIED.includes((await c.get(`/api/v1/results/sheets/${bIds.sheet}`)).status));
    assert.ok(DENIED.includes((await c.put(`/api/v1/results/sheets/${bIds.sheet}/scores`, { entries: [{ studentId: bIds.student, scores: { exam: 60 } }] })).status));
    assert.ok(DENIED.includes((await c.post(`/api/v1/results/sheets/${bIds.sheet}/submit`, {})).status));
    const bs = await c.get(`/api/v1/results/broadsheet?termId=${bIds.term}&classId=${bIds.class}`);
    assert.ok(DENIED.includes(bs.status), `broadsheet ${bs.status}`);
    assert.ok(DENIED.includes((await c.get(`/api/v1/results/student/${bIds.student}?termId=${bIds.term}`)).status));
    assert.ok(DENIED.includes((await c.post('/api/v1/results/sheets', { termId: bIds.term, classId: bIds.class, subjectId: bIds.subject })).status));
  }
});
test('School A teacher cannot reach School B CBT', async () => {
  assert.ok(DENIED.includes((await aTeacher.get(`/api/v1/cbt/exams/${bIds.exam}`)).status));
  assert.ok(DENIED.includes((await aTeacher.post(`/api/v1/cbt/exams/${bIds.exam}/questions`, { type: 'theory', text: 'x' })).status));
  assert.ok(DENIED.includes((await aOwner.post(`/api/v1/cbt/exams/${bIds.exam}/publish`, {})).status));
  assert.ok(DENIED.includes((await aStudent.post(`/api/v1/cbt/exams/${bIds.exam}/start`, {})).status));
  const list = await aTeacher.get('/api/v1/cbt/exams'); assert.ok(list.body.items.every((e) => e.title !== 'B secret exam'));
});
test('School A bursar cannot reach School B fees', async () => {
  assert.ok(DENIED.includes((await aBursar.get(`/api/v1/fees/invoices/${bIds.invoice}`)).status));
  assert.ok(DENIED.includes((await aBursar.post('/api/v1/fees/payments', { invoiceId: bIds.invoice, amountKobo: 100, method: 'cash' })).status));
  assert.ok(DENIED.includes((await aBursar.post(`/api/v1/fees/invoices/${bIds.invoice}/void`, { reason: 'attack' })).status));
  const inv = await aBursar.get('/api/v1/fees/invoices?pageSize=100'); assert.ok(inv.body.items.every((i) => i.id !== bIds.invoice));
  assert.ok(DENIED.includes((await aParent.get(`/api/v1/fees/invoices/${bIds.invoice}`)).status));
});
test('School A cannot touch School B users, roles, files, documents, announcements, attendance', async () => {
  assert.ok(DENIED.includes((await aOwner.patch(`/api/v1/users/${bIds.user}`, { fullName: 'Hacked Name' })).status));
  assert.ok(DENIED.includes((await aOwner.post(`/api/v1/users/${bIds.user}/status`, { status: 'disabled', reason: 'attack' })).status));
  assert.ok(DENIED.includes((await aOwner.post(`/api/v1/users/${bIds.user}/access-code`, {})).status));
  assert.ok(DENIED.includes((await aOwner.put(`/api/v1/users/${bIds.user}/roles`, { roleKeys: ['teacher'] })).status));
  assert.ok(DENIED.includes((await aOwner.patch(`/api/v1/roles/${bIds.role}`, { name: 'pwned' })).status));
  assert.ok(DENIED.includes((await aOwner.get(`/api/v1/files/${bIds.file}`)).status));
  assert.ok(DENIED.includes((await aOwner.get(`/api/v1/files/${bIds.docFile}`)).status));
  assert.ok(DENIED.includes((await aOwner.del(`/api/v1/documents/${bIds.doc}`)).status));
  assert.ok(DENIED.includes((await aOwner.del(`/api/v1/announcements/${bIds.announcement}`)).status));
  assert.ok(DENIED.includes((await aOwner.put(`/api/v1/attendance/class/${bIds.class}`, { date: '2026-01-05', entries: [{ studentId: bIds.student, status: 'absent' }] })).status));
  const ann = await aStudent.get('/api/v1/announcements'); assert.ok(ann.body.items.every((a) => a.title !== 'B only notice'));
  const bu = await bOwner.get(`/api/v1/users?q=sb.teacher1`); assert.equal(bu.body.items[0].full_name, 'Mr Tunde Bello');
});
test('School A cannot message School B users or link B records', async () => {
  const r = await aOwner.post('/api/v1/messages/threads', { subject: 'hi', body: 'x', recipientIds: [bIds.user] });
  assert.equal(r.status, 400);
  const g = await aOwner.post('/api/v1/guardians', { fullName: 'Evil Parent', relationship: 'Parent', studentIds: [bIds.student] });
  assert.ok([400, 403, 404].includes(g.status), `guardian link ${g.status}`);
  const u = await aOwner.post('/api/v1/users', { fullName: 'Link Attack', loginId: 'link.attack', roleKeys: ['student'], link: { type: 'student', id: bIds.student } });
  assert.ok([400, 404].includes(u.status));
});
test('client-supplied school identifiers are rejected (mass assignment) and ignored', async () => {
  const r = await aOwner.post('/api/v1/students', { admissionNo: 'X1', firstName: 'A', lastName: 'B', gender: 'Male', schoolId: B.schoolId });
  assert.equal(r.status, 400); assert.match(r.body.error.message, /schoolId is not an allowed field/);
  const r2 = await aOwner.get(`/api/v1/students?schoolId=${B.schoolId}`); assert.equal(r2.status, 400);
});
test('database layer: RLS hides other tenants even if the application forgets a WHERE clause', async () => {
  const c = await H.dbAs('app');
  try {
    await c.query('BEGIN');
    assert.equal((await c.query('SELECT count(*)::int AS n FROM students')).rows[0].n, 0, 'no tenant context ⇒ no rows');
    await c.query("SELECT set_config('app.school_id', $1, true)", [A.schoolId]);
    const rows = (await c.query('SELECT DISTINCT school_id FROM students')).rows;
    assert.deepEqual(rows.map((r) => r.school_id), [A.schoolId]);
    assert.equal((await c.query('SELECT count(*)::int AS n FROM students WHERE id = $1', [bIds.student])).rows[0].n, 0);
    assert.equal((await c.query('UPDATE students SET first_name = $2 WHERE id = $1', [bIds.student, 'x'])).rowCount, 0);
    await assert.rejects(c.query("INSERT INTO subjects (school_id, name) VALUES ($1, 'Injected')", [B.schoolId]), /row-level security/);
    await c.query('ROLLBACK');
  } finally { await c.end(); }
});
test('database layer: composite FKs forbid cross-tenant links even for the schema owner', async () => {
  const c = await H.dbAs('owner');
  try {
    const aStudentRow = (await c.query('SELECT id FROM students WHERE school_id = $1 LIMIT 1', [A.schoolId])).rows[0];
    const bSess = (await c.query('SELECT id FROM academic_sessions WHERE school_id = $1 LIMIT 1', [B.schoolId])).rows[0];
    await assert.rejects(c.query('INSERT INTO student_enrollments (school_id, student_id, class_id, session_id) VALUES ($1,$2,$3,$4)', [A.schoolId, aStudentRow.id, bIds.class, bSess.id]), /foreign key/);
  } finally { await c.end(); }
});
test('the runtime DB role cannot bypass RLS or read the permission table for writing', async () => {
  const c = await H.dbAs('app');
  try {
    const r = (await c.query("SELECT rolbypassrls, rolsuper FROM pg_roles WHERE rolname = 'abo_app'")).rows[0];
    assert.equal(r.rolbypassrls, false); assert.equal(r.rolsuper, false);
    await assert.rejects(c.query("INSERT INTO permissions (key, module, description) VALUES ('x.y','x','x')"), /permission denied/);
    await assert.rejects(c.query('SET row_security = off; SELECT * FROM students'), /row-level security|query would be affected/);
  } finally { await c.end(); }
});
