'use strict';
// Fingerprint / face confirmation for clock-in (WebAuthn passkeys), checked on the server with a real P-256 passkey.
const H = require('./helpers');
const test = require('node:test');
const assert = require('node:assert/strict');
const { softPhone } = require('./softauthn');

let S, owner, teacher, teacher2, bOwner;
test.before(async () => {
  S = await H.setup();
  [owner, teacher, teacher2, bOwner] = await Promise.all(['sa.owner', 'sa.teacher1', 'sa.teacher2', 'sb.owner'].map((l) => H.login(S.app, l)));
});
test.after(() => H.teardown());

test('set up a phone: only a real passkey with fingerprint/face (user verified) from this site is accepted', async () => {
  const phone = softPhone();
  let o = (await teacher.post('/api/v1/clock/passkeys/register-options', {})).body;
  assert.ok(o.challengeId && o.options.challenge); assert.equal(o.options.rp.id, 'localhost'); assert.equal(o.options.authenticatorSelection.userVerification, 'required');
  // wrong site (phishing page) → refused
  let r = await teacher.post('/api/v1/clock/passkeys', { challengeId: o.challengeId, response: phone.register(o.options, { origin: 'https://evil.example' }) });
  assert.equal(r.status, 400, 'a passkey made on another website is refused');
  // the challenge was used up by that attempt
  r = await teacher.post('/api/v1/clock/passkeys', { challengeId: o.challengeId, response: phone.register(o.options) });
  assert.equal(r.status, 400, 'a challenge works once only'); assert.match(r.body.error.message, /expired/);
  // no fingerprint/face (user not verified) → refused
  o = (await teacher.post('/api/v1/clock/passkeys/register-options', {})).body;
  r = await teacher.post('/api/v1/clock/passkeys', { challengeId: o.challengeId, response: phone.register(o.options, { flags: 0x41 }) });
  assert.equal(r.status, 400, 'without fingerprint/face the phone is not set up');
  // proper set-up
  o = (await teacher.post('/api/v1/clock/passkeys/register-options', {})).body;
  r = await teacher.post('/api/v1/clock/passkeys', { challengeId: o.challengeId, response: phone.register(o.options), label: 'Tecno Spark' });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  const me = (await teacher.get('/api/v1/clock/me')).body;
  assert.equal(me.passkeys.length, 1); assert.equal(me.passkeys[0].device_label, 'Tecno Spark');
  // another person's challenge cannot be used
  const o2 = (await teacher2.post('/api/v1/clock/passkeys/register-options', {})).body;
  assert.equal((await teacher.post('/api/v1/clock/passkeys', { challengeId: o2.challengeId, response: phone.register(o2.options) })).status, 400);
  assert.equal((await owner.post('/api/v1/clock/passkeys/register-options', {})).status, 403, 'no staff record → cannot set up');
  S.phone = phone;
});

test('clock-in with fingerprint/face required: needs a fresh, correctly signed answer from the person’s own phone', async () => {
  const phone = S.phone;
  assert.equal((await owner.put('/api/v1/clock/settings', { requireLocation: false, requireBiometric: true, lateAfter: '23:59' })).status, 200);
  assert.equal((await teacher.get('/api/v1/clock/me')).body.settings.requireBiometric, true);
  let r = await teacher.post('/api/v1/clock/in', {});
  assert.equal(r.status, 400); assert.match(r.body.error.message, /fingerprint or face/);
  // a signature from another key (stolen credential id) → refused
  let o = (await teacher.post('/api/v1/clock/passkeys/clock-options', {})).body;
  r = await teacher.post('/api/v1/clock/in', { passkeyChallengeId: o.challengeId, passkey: phone.sign(o.options, { key: phone.otherKey() }) });
  assert.equal(r.status, 400, 'a forged signature is refused');
  // signed for a different challenge → refused
  o = (await teacher.post('/api/v1/clock/passkeys/clock-options', {})).body;
  r = await teacher.post('/api/v1/clock/in', { passkeyChallengeId: o.challengeId, passkey: phone.sign(o.options, { challenge: 'b3RoZXItY2hhbGxlbmdl' }) });
  assert.equal(r.status, 400, 'an old/other challenge is refused');
  // no fingerprint/face at signing time (UP only) → refused
  o = (await teacher.post('/api/v1/clock/passkeys/clock-options', {})).body;
  r = await teacher.post('/api/v1/clock/in', { passkeyChallengeId: o.challengeId, passkey: phone.sign(o.options, { flags: 0x01 }) });
  assert.equal(r.status, 400, 'user must be verified (fingerprint/face), not just present');
  // someone else's phone answer → refused
  const o2 = await teacher2.post('/api/v1/clock/passkeys/clock-options', {});
  assert.equal(o2.status, 400, 'teacher2 has no phone set up'); assert.match(o2.body.error.message, /no phone/);
  // correct
  o = (await teacher.post('/api/v1/clock/passkeys/clock-options', {})).body;
  const ans = phone.sign(o.options);
  r = await teacher.post('/api/v1/clock/in', { passkeyChallengeId: o.challengeId, passkey: ans });
  assert.equal(r.status, 200, JSON.stringify(r.body)); assert.equal(r.body.verified_by, 'passkey');
  // replaying the same answer for clock-out → refused (challenge used)
  r = await teacher.post('/api/v1/clock/out', { passkeyChallengeId: o.challengeId, passkey: ans });
  assert.equal(r.status, 400, 'a replayed answer is refused');
  o = (await teacher.post('/api/v1/clock/passkeys/clock-options', {})).body;
  r = await teacher.post('/api/v1/clock/out', { passkeyChallengeId: o.challengeId, passkey: phone.sign(o.options) });
  assert.equal(r.status, 200); assert.equal(r.body.verified_by, 'passkey');
  // the head sees it in the register; another school sees nothing
  const reg = (await owner.get('/api/v1/clock/register')).body.items.find((x) => x.full_name === 'Mr Tunde Bello');
  assert.ok(reg.in_at && reg.out_at);
  const bo = await bOwner.post('/api/v1/clock/passkeys/clock-options', {});
  assert.equal(bo.status, 400, 'another school has no access to these phones'); assert.match(bo.body.error.message, /no phone/);
});

test('a lost phone can be removed (by the person or the head); then it no longer works', async () => {
  const phone = S.phone;
  const me = (await teacher.get('/api/v1/clock/me')).body;
  assert.equal((await teacher2.del(`/api/v1/clock/passkeys/${me.passkeys[0].id}`)).status, 404, 'another teacher cannot remove it');
  assert.equal((await owner.del(`/api/v1/clock/passkeys/${me.passkeys[0].id}`)).status, 200, 'the head can');
  const o = await teacher.post('/api/v1/clock/passkeys/clock-options', {});
  assert.equal(o.status, 400, 'no phone left');
  void phone;
  await owner.put('/api/v1/clock/settings', { requireLocation: false, requireBiometric: false });
});
