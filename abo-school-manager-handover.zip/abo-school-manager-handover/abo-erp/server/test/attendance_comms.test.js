'use strict';
const H = require('./helpers');
const test = require('node:test');
const assert = require('node:assert/strict');
let S, owner, teacher, teacher2, student, parent, cls, cls2;
test.before(async () => {
  S = await H.setup();
  [owner, teacher, teacher2, student, parent] = await Promise.all(['sa.owner', 'sa.teacher1', 'sa.teacher2', 'sa.student', 'sa.parent'].map((l) => H.login(S.app, l)));
  cls = S.A.classes.find((c) => c.display_name === 'BASIC 1A'); cls2 = S.A.classes.find((c) => c.display_name === 'BASIC 1B');
});
test.after(() => H.teardown());
const today = () => new Date().toISOString().slice(0, 10);

test('attendance: form teacher marks own class; validation; parents notified of absence', async () => {
  const roster = await teacher.get(`/api/v1/attendance/class/${cls.id}`);
  const me = (await student.get('/api/v1/auth/me')).body.studentId;
  const entries = roster.body.items.map((r) => ({ studentId: r.student_id, status: r.student_id === me ? 'absent' : 'present' }));
  const tomorrow = new Date(Date.now() + 86400000).toISOString().slice(0, 10);
  assert.equal((await teacher.put(`/api/v1/attendance/class/${cls.id}`, { date: tomorrow, entries })).status, 400);
  const other = (await owner.get(`/api/v1/students?classId=${cls2.id}&pageSize=1`)).body.items[0].id;
  assert.equal((await teacher.put(`/api/v1/attendance/class/${cls.id}`, { date: today(), entries: [...entries, { studentId: other, status: 'present' }] })).status, 400);
  const ok = await teacher.put(`/api/v1/attendance/class/${cls.id}`, { date: today(), entries });
  assert.equal(ok.status, 200); assert.equal(ok.body.counts.absent, 1);
  const n = await parent.get('/api/v1/notifications'); assert.ok(n.body.items.some((x) => x.kind === 'attendance'));
  const sum = await owner.get(`/api/v1/attendance/summary?classId=${cls.id}`); assert.equal(sum.body.items.find((r) => r.student_id === me).absent, 1);
  assert.equal((await student.get(`/api/v1/attendance/student/${me}`)).body.items[0].status, 'absent');
});
test('announcements: audience + class targeting enforced server-side; XSS payload stored as inert text', async () => {
  await owner.post('/api/v1/announcements', { title: 'Staff meeting', body: 'Friday 2pm', audience: 'staff' });
  await owner.post('/api/v1/announcements', { title: 'BASIC 1B excursion', body: 'Zoo trip', audience: 'all', classId: cls2.id });
  await owner.post('/api/v1/announcements', { title: 'BASIC 1A test', body: '<img src=x onerror=alert(1)>', audience: 'students', classId: cls.id });
  const s = (await student.get('/api/v1/announcements')).body.items.map((a) => a.title);
  assert.ok(s.includes('BASIC 1A test')); assert.ok(!s.includes('Staff meeting')); assert.ok(!s.includes('BASIC 1B excursion'));
  const t = (await teacher.get('/api/v1/announcements')).body.items.map((a) => a.title); assert.ok(t.includes('Staff meeting'));
  const x = (await student.get('/api/v1/announcements')).body.items.find((a) => a.title === 'BASIC 1A test');
  assert.equal(x.body, '<img src=x onerror=alert(1)>', 'API returns data; the frontend renders it with textContent');
  assert.equal((await student.post(`/api/v1/announcements/${x.id}/read`, {})).status, 200);
  assert.equal((await student.get('/api/v1/announcements')).body.items.find((a) => a.id === x.id).read, true);
  assert.equal((await student.post('/api/v1/announcements', { title: 'hack', body: 'x' })).status, 403);
});
test('messaging: students/parents may only contact their teachers + leadership; only participants can read', async () => {
  const contacts = (await student.get('/api/v1/messages/contacts')).body.items;
  assert.ok(contacts.some((c) => c.full_name === 'Mr Tunde Bello'));
  const all = (await owner.get('/api/v1/users?pageSize=100')).body.items;
  const bursar = all.find((u) => u.login_id === 'sa.bursar');
  assert.equal((await student.post('/api/v1/messages/threads', { subject: 'fees?', body: 'hello', recipientIds: [bursar.id] })).status, 403);
  const t1 = contacts.find((c) => c.full_name === 'Mr Tunde Bello');
  const th = await parent.post('/api/v1/messages/threads', { subject: 'About homework', body: 'Good morning sir', recipientIds: [t1.id] });
  assert.equal(th.status, 200);
  assert.equal((await teacher2.get(`/api/v1/messages/threads/${th.body.id}`)).status, 404, 'non-participant cannot read');
  const read = await teacher.get(`/api/v1/messages/threads/${th.body.id}`); assert.equal(read.body.messages[0].body, 'Good morning sir');
  assert.equal((await teacher.post(`/api/v1/messages/threads/${th.body.id}`, { body: 'Noted, thanks.' })).status, 200);
  assert.equal((await teacher2.post(`/api/v1/messages/threads/${th.body.id}`, { body: 'intrude' })).status, 404);
});
test('announcements replace newsletters: drafts hidden from parents until published; long letters allowed; old endpoint says where it went', async () => {
  const long = 'Dear parents, '.repeat(900);                                                        // ~12,600 characters (old limit 8,000)
  const d = await owner.post('/api/v1/announcements', { title: 'Draft letter', body: long, audience: 'parents', draft: true });
  assert.equal(d.status, 200, JSON.stringify(d.body));
  const pub = await owner.post('/api/v1/announcements', { title: 'Term letter', body: 'Congratulations to our debate team!', audience: 'parents' });
  let seen = (await parent.get('/api/v1/announcements?pageSize=100')).body.items.map((n) => n.title);
  assert.ok(seen.includes('Term letter')); assert.ok(!seen.includes('Draft letter'), 'draft hidden from parents');
  assert.equal((await parent.post(`/api/v1/announcements/${d.body.id}/publish`)).status, 403);
  assert.equal((await owner.post(`/api/v1/announcements/${d.body.id}/publish`)).status, 200);
  assert.equal((await owner.post(`/api/v1/announcements/${d.body.id}/publish`)).status, 409, 'already published');
  seen = (await parent.get('/api/v1/announcements?pageSize=100')).body.items;
  assert.equal(seen.find((n) => n.title === 'Draft letter').body.length, long.length);
  assert.ok(!('emailed_count' in seen[0]), 'parents do not see sharing details');
  const gone = await owner.get('/api/v1/newsletters'); assert.equal(gone.status, 410); assert.match(gone.body.error.message, /Announcements/);
  void pub;
});
test('share an announcement with parents: WhatsApp text and links, email to each parent once, audience respected', async () => {
  const db = await H.dbAs('owner');
  try {
    // give the seeded parent a WhatsApp-able phone and an email
    await db.query("UPDATE guardians SET phone = '0803 000 0001', email = 'mum@example.com' WHERE school_id = $1", [S.A.schoolId]);
    const a = await owner.post('/api/v1/announcements', { title: 'PTA meeting', body: 'PTA meeting on Friday at 10am in the school hall.', audience: 'parents' });
    const sh = await owner.get(`/api/v1/announcements/${a.body.id}/share`);
    assert.equal(sh.status, 200, JSON.stringify(sh.body));
    assert.match(sh.body.text, /PTA meeting on Friday/); assert.match(sh.body.text, /School portal: /);
    assert.match(sh.body.whatsappUrl, /^https:\/\/wa\.me\/\?text=/);
    assert.ok(sh.body.recipients.length >= 1);
    const r = sh.body.recipients[0]; assert.equal(r.whatsapp, '2348030000001'); assert.match(r.whatsappUrl, /^https:\/\/wa\.me\/2348030000001\?text=PTA|^https:\/\/wa\.me\/2348030000001\?text=/);
    assert.equal((await parent.get(`/api/v1/announcements/${a.body.id}/share`)).status, 403, 'parents cannot list other parents');
    const em = await owner.post(`/api/v1/announcements/${a.body.id}/email`, {});
    assert.equal(em.status, 200, JSON.stringify(em.body)); assert.ok(em.body.queued >= 1);
    const out = (await db.query("SELECT to_address, subject, body_text FROM outbox_emails WHERE template = 'announcement' AND school_id = $1", [S.A.schoolId])).rows;
    assert.equal(new Set(out.map((o) => o.to_address)).size, out.length, 'one email per address'); assert.match(out[0].subject, /PTA meeting/); assert.match(out[0].body_text, /PTA meeting on Friday/);
    const twice = await owner.post(`/api/v1/announcements/${a.body.id}/email`, {}); assert.equal(twice.status, 409, 'not sent twice by mistake');
    assert.equal((await owner.post(`/api/v1/announcements/${a.body.id}/email`, { again: true })).status, 200, 'sent again on purpose');
    const audit = (await db.query("SELECT count(*)::int AS n FROM audit_logs WHERE action = 'announcements.emailed' AND school_id = $1", [S.A.schoolId])).rows[0].n; assert.equal(audit, 2);
    // staff-only notices are not sent to parents; drafts cannot be sent
    const st = await owner.post('/api/v1/announcements', { title: 'Staff briefing', body: 'Staff meeting 7:30am.', audience: 'staff' });
    assert.equal((await owner.get(`/api/v1/announcements/${st.body.id}/share`)).body.recipients.length, 0);
    assert.equal((await owner.post(`/api/v1/announcements/${st.body.id}/email`, {})).status, 400);
    const dr = await owner.post('/api/v1/announcements', { title: 'Draft notice', body: 'Not yet.', audience: 'parents', draft: true });
    assert.equal((await owner.post(`/api/v1/announcements/${dr.body.id}/email`, {})).status, 409);
  } finally { await db.end(); }
});
test('migration 025 copies old newsletters into announcements (published stay published, drafts stay drafts) and can be rolled back', async () => {
  const mig = require('../src/db/migrate');
  const db = await H.dbAs('admin');
  try {
    // roll back every migration from 025 upwards (026, 027, … newer ones come off first) → back to 024
    const top = async () => Number((await db.query('SELECT max(version) AS v FROM schema_migrations')).rows[0].v);
    for (let guard = 0; guard < 20 && (await top()) >= 25; guard++) await mig.down({ url: process.env.MIGRATION_DATABASE_URL, log: () => {} });
    assert.equal(await top(), 24, 'back to 024');
    await db.query("INSERT INTO newsletters (school_id, title, body, audience, status, published_at) VALUES ($1, 'Old published letter', 'Hello parents', 'parents', 'published', now() - interval '3 days'), ($1, 'Old draft letter', 'Not ready', 'parents', 'draft', NULL)", [S.A.schoolId]);
    await mig.migrate({ url: process.env.MIGRATION_DATABASE_URL, log: () => {} });                       // 025 again
    const rows = (await db.query("SELECT title, draft, source FROM announcements WHERE source = 'newsletter' AND school_id = $1 ORDER BY title", [S.A.schoolId])).rows;
    assert.deepEqual(rows.map((r) => [r.title, r.draft]), [['Old draft letter', true], ['Old published letter', false]]);
    const p = (await parent.get('/api/v1/announcements?pageSize=100')).body.items.map((n) => n.title);
    assert.ok(p.includes('Old published letter')); assert.ok(!p.includes('Old draft letter'));
    const app = await H.dbAs('app');
    try { await assert.rejects(app.query("INSERT INTO newsletters (school_id, title, body) VALUES ($1, 'x x', 'y')", [S.A.schoolId]), /permission denied/); } finally { await app.end(); }
  } finally { await db.end(); }
});
test('timetable: students see only their own class timetable', async () => {
  const subj = (await owner.get(`/api/v1/academic/classes/${cls.id}/subjects`)).body.items[0];
  assert.equal((await owner.put(`/api/v1/academic/classes/${cls.id}/timetable`, { items: [{ dayOfWeek: 1, period: 1, startsAt: '08:00', endsAt: '08:40', subjectId: subj.subject_id }] })).status, 200);
  assert.equal((await student.get(`/api/v1/academic/classes/${cls.id}/timetable`)).body.items.length, 1);
  assert.equal((await student.get(`/api/v1/academic/classes/${cls2.id}/timetable`)).status, 404);
});
test('promotion: dry-run preview, run without cascades, one-step undo', async () => {
  const s2 = await owner.post('/api/v1/academic/sessions', { name: '2026/2027' });
  const ac = (await owner.get('/api/v1/academic')).body; const from = ac.sessions.find((s) => s.name === '2025/2026').id;
  const jss = ac.classes.find((c) => c.display_name === 'JSS 1A');
  const map = [{ fromClassId: cls.id, toClassId: cls2.id }, { fromClassId: cls2.id, toClassId: jss.id }, { fromClassId: jss.id, graduate: true }];
  const dry = await owner.post('/api/v1/academic/promotion', { fromSessionId: from, toSessionId: s2.body.id, map, dryRun: true });
  assert.equal(dry.body.dryRun, true); assert.equal(dry.body.summary.promoted, 10); assert.equal(dry.body.summary.graduated, 5);
  const run = await owner.post('/api/v1/academic/promotion', { fromSessionId: from, toSessionId: s2.body.id, map, dryRun: false });
  assert.equal(run.status, 200);
  const db = await H.dbAs('owner');
  try {
    const n = (await db.query('SELECT count(*)::int AS n FROM student_enrollments WHERE session_id = $1 AND class_id = $2', [s2.body.id, jss.id])).rows[0].n;
    assert.equal(n, 5, 'BASIC 1B moved to JSS 1A exactly once (no cascade from BASIC 1A)');
    assert.equal((await owner.post(`/api/v1/academic/promotion/${run.body.runId}/undo`, {})).status, 200);
    assert.equal((await db.query('SELECT count(*)::int AS n FROM student_enrollments WHERE session_id = $1', [s2.body.id])).rows[0].n, 0);
    assert.equal((await db.query("SELECT count(*)::int AS n FROM students WHERE school_id = $1 AND status = 'graduated'", [S.A.schoolId])).rows[0].n, 0);
  } finally { await db.end(); }
});
