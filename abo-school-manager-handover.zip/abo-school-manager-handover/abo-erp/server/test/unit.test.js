'use strict';
process.env.NODE_ENV = 'test';
const test = require('node:test');
const assert = require('node:assert/strict');
const G = require('../src/services/grading');
const totp = require('../src/security/totp');
const cr = require('../src/security/crypto');
const { parseCsv, toCsv, safeCell } = require('../src/lib/csv');
const { sniff, presign } = require('../src/storage');
const pw = require('../src/security/passwords');

test('grading: WAEC + primary scales identical to legacy computeGrade()', () => {
  const sec = G.DEFAULT_GRADING.secondary, pri = G.DEFAULT_GRADING.primary;
  const cases = [[85, 'A+'], [84.4, 'A1'], [75, 'A1'], [70, 'B2'], [65, 'B3'], [60, 'C4'], [55, 'C5'], [50, 'C6'], [45, 'D7'], [40, 'E8'], [39.4, 'F9'], [0, 'F9']];
  for (const [s, g] of cases) assert.equal(G.gradeFor(s, sec).grade, g, `secondary ${s}`);
  for (const [s, g] of [[90, 'A+'], [80, 'A'], [70, 'B+'], [60, 'B'], [50, 'C'], [40, 'D'], [39, 'F'], [120, 'A+'], [-5, 'F']]) assert.equal(G.gradeFor(s, pri).grade, g, `primary ${s}`);
});
test('ranking: competition ranking 1-2-2-4 as legacy recalculateAll()', () => {
  const r = G.rank([{ id: 'a', value: 80 }, { id: 'b', value: 70 }, { id: 'c', value: 70 }, { id: 'd', value: 60 }]);
  assert.deepEqual([r.get('a'), r.get('b'), r.get('c'), r.get('d')], [1, 2, 2, 4]);
});
test('computeSheet rejects out-of-range scores and ignores students with no scores', () => {
  const comps = G.DEFAULT_COMPONENTS;
  const ok = G.computeSheet(comps, new Map([['s1', new Map([['ca1', 18], ['ca2', 17], ['exam', 50]])], ['s2', new Map()]]), G.DEFAULT_GRADING.primary);
  assert.equal(ok.length, 1); assert.equal(ok[0].total, 85); assert.equal(ok[0].grade, 'A');
  assert.throws(() => G.computeSheet(comps, new Map([['s1', new Map([['exam', 61]])]]), G.DEFAULT_GRADING.primary), /out of range/);
});
test('computeTerm: average, pass mark, positions', () => {
  const rows = G.computeTerm(new Map([['a', [80, 90]], ['b', [30, 40]], ['c', []]]), G.DEFAULT_GRADING.secondary, 40);
  const a = rows.find((r) => r.studentId === 'a'); const b = rows.find((r) => r.studentId === 'b'); const c = rows.find((r) => r.studentId === 'c');
  assert.equal(a.average, 85); assert.equal(a.grade, 'A+'); assert.equal(a.position, 1); assert.equal(a.status, 'Pass');
  assert.equal(b.average, 35); assert.equal(b.status, 'Fail'); assert.equal(b.position, 2); assert.equal(c.status, 'Pending'); assert.equal(c.position, null);
});
test('assessment components must total 100', () => {
  assert.equal(G.validateComponents(G.DEFAULT_COMPONENTS), null);
  assert.match(G.validateComponents([{ key: 'ca1', label: 'x', max: 30 }, { key: 'exam', label: 'y', max: 60 }]), /add up to 100/);
  assert.match(G.validateComponents([{ key: 'ca1', label: 'x', max: 50 }, { key: 'ca1', label: 'y', max: 50 }]), /Duplicate/);
});
test('TOTP: RFC 6238 SHA-1 vectors + replay protection', () => {
  const s = totp.b32encode(Buffer.from('12345678901234567890'));
  assert.equal(totp.hotp(s, Math.floor(59 / 30), 8), '94287082');
  assert.equal(totp.hotp(s, Math.floor(1111111109 / 30), 8), '07081804');
  assert.equal(totp.hotp(s, Math.floor(2000000000 / 30), 8), '69279037');
  const now = 1700000000000; const code = totp.hotp(s, totp.stepAt(now));
  const step = totp.verify(s, code, { now }); assert.equal(step, totp.stepAt(now));
  assert.equal(totp.verify(s, code, { now, lastStep: step }), null, 'same code cannot be replayed');
  assert.equal(totp.verify(s, '000000', { now }), null);
});
test('AES-256-GCM: round trip + tamper detection', () => {
  const e = cr.encrypt('JBSWY3DPEHPK3PXP'); assert.equal(cr.decrypt(e), 'JBSWY3DPEHPK3PXP');
  const bad = e.slice(0, -2) + (e.endsWith('A') ? 'BB' : 'AA');
  assert.throws(() => cr.decrypt(bad));
});
test('password policy (NIST-style) + Argon2id hashing', async () => {
  assert.ok(pw.checkPolicy('password123', { staff: true }).length > 0);
  assert.ok(pw.checkPolicy('short', { staff: false }).length > 0);
  assert.ok(pw.checkPolicy('bopc.admin-Secret9', { loginId: 'bopc.admin', staff: true }).some((e) => /Login ID/.test(e)));
  assert.deepEqual(pw.checkPolicy('Tr0ub4dour&Horse', { staff: true }), []);
  const h = await pw.hash('Tr0ub4dour&Horse');
  assert.match(h, /^\$argon2id\$v=19\$/); assert.ok(await pw.verify(h, 'Tr0ub4dour&Horse')); assert.equal(await pw.verify(h, 'wrong'), false);
});
test('CSV: RFC 4180 parse + formula-injection neutralisation on export', () => {
  assert.deepEqual(parseCsv('a,b\n"x, y","he said ""hi"""\n'), [['a', 'b'], ['x, y', 'he said "hi"']]);
  for (const v of ['=HYPERLINK("http://evil")', '+1+1', '-2', '@SUM(A1)', '\tcmd']) assert.ok(safeCell(v).startsWith("'"), v);
  const out = toCsv([{ key: 'n', label: 'Name' }], [{ n: '=cmd|"/c calc"!A0' }]);
  assert.ok(out.includes(`"'=cmd|""/c calc""!A0"`));
});
test('upload sniffing trusts magic bytes, not names', () => {
  assert.equal(sniff(Buffer.from('89504e470d0a1a0a0000', 'hex'), 'x.png').mime, 'image/png');
  assert.equal(sniff(Buffer.from('<svg onload=alert(1)>'), 'logo.png'), null);
  assert.equal(sniff(Buffer.from('<html><script>alert(1)</script>'), 'data.csv'), null);
  assert.equal(sniff(Buffer.from('name,age\nAda,9\n'), 'data.csv').mime, 'text/csv');
  assert.equal(sniff(Buffer.from('%PDF-1.7 ...'), 'x.exe').mime, 'application/pdf');
});
test('S3 SigV4 presign matches the AWS documentation example', () => {
  const url = presign({ region: 'us-east-1', bucket: 'examplebucket', accessKeyId: 'AKIAIOSFODNN7EXAMPLE', secretAccessKey: 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY', forcePathStyle: false, endpoint: 'https://s3.amazonaws.com' },
    'GET', 'test.txt', 86400, new Date('2013-05-24T00:00:00Z'));
  assert.ok(url.endsWith('X-Amz-Signature=aeeed9bbccd4d02ee5c0109b86d86835f995330da4c265957d157751f604d404'));
});
test('AI prompt contains no personal data', () => {
  const { buildPrompt } = require('../src/routes/ai');
  const txt = JSON.stringify(buildPrompt({ average: 71.5, grade: 'B2', status: 'Pass' }, [{ subject: 'Mathematics', total: 80, grade: 'A1' }]));
  assert.ok(!/Okafor|Ada|BOPC\/|@|080/.test(txt)); assert.match(txt, /the pupil/);
});
test('legacy backup analyser maps registers/arms/scores and discards API keys', () => {
  const { analyse } = require('../src/routes/migration');
  const plan = analyse({
    subjects: ['English Language', 'Mathematics'], globalSettings: { session: '2024/2025', term: '2ND', className: 'BASIC 1A', educationLevel: 'primary' },
    students: [{ name: 'Okafor Ada Chioma', gender: 'Female', attendanceNo: 1, subjects: [{ ca1: 18, ca2: 17, exam: 50 }, { ca1: 0, ca2: 0, exam: 0 }], teacherComment: 'Good' }],
    schoolData: { name: 'Old School', erp: { learners: { 'BASIC 1B': [{ name: 'Bello Tunde', gender: 'Male', attendanceNo: 2, subjects: [] }] } } },
    aiSettings: { apiKey: 'sk-secret' }, userAccounts: { teachers: [{ name: 'Mr T' }], students: [], admins: [] },
  });
  assert.equal(plan.counts.classes, 2); assert.equal(plan.counts.students, 2); assert.equal(plan.term, '2ND');
  const a = plan.classes.find((k) => k.arm === 'A'); assert.equal(a.name, 'BASIC 1'); assert.equal(a.students[0].last, 'Okafor');
  assert.deepEqual(a.students[0].scores['English Language'], { ca1: 18, ca2: 17, exam: 50 }); assert.equal(a.students[0].scores.Mathematics, undefined);
  assert.ok(plan.warnings.some((w) => /API key .* DISCARDED/.test(w))); assert.ok(!JSON.stringify(plan).includes('sk-secret'));
});
test('production/staging refuse to start with missing or placeholder secrets and insecure cookies', () => {
  const { spawnSync } = require('node:child_process');
  const run = (env) => spawnSync(process.execPath, ['-e', "require('./server/src/config')"], { cwd: require('node:path').join(__dirname, '../..'), env: { PATH: process.env.PATH, ...env }, encoding: 'utf8' });
  const base = { NODE_ENV: 'production', PUBLIC_ORIGIN: 'https://app.example', DATABASE_URL: 'postgres://abo_app:Str0ngRandomPw@db:5432/abo', DB_SSL: 'require' };
  const good = { CSRF_SECRET: 'k6yJ3Lq2ZV9xT1rW8nP4sQ7aB0cD5eF6gH2iJ3kL4mN=', DATA_ENCRYPTION_KEY: 'u8Qw2Er5Ty7Ui9Op1As3Df5Gh7Jk9Lz1Xc3Vb5Nm7Qw9=', FILE_URL_SECRET: 'p0Oi9Uy8Tr7Ew6Qa5Sd4Fg3Hj2Kl1Zx0Cv9Bn8Mq7Wr6=' };
  assert.match(run(base).stderr, /Missing required secret CSRF_SECRET/);
  assert.match(run({ ...base, ...good, CSRF_SECRET: 'change-me-change-me-change-me-change-me-change' }).stderr, /placeholder|entropy/);
  assert.match(run({ ...base, ...good, COOKIE_SECURE: 'false' }).stderr, /COOKIE_SECURE must be true/);
  assert.match(run({ ...base, ...good, PUBLIC_ORIGIN: 'http://app.example' }).stderr, /must be https/);
  assert.equal(run({ ...base, ...good }).status, 0, run({ ...base, ...good }).stderr);
});

test('CBT marking engine: every objective type, tolerance, normalisation; essays / unkeyed short answers go to a human', () => {
  const { markAnswer, isManual } = require('../src/services/cbt');
  const C = new Set(['a']);
  assert.equal(markAnswer({ type: 'mcq' }, { option_id: 'a' }, C), true);
  assert.equal(markAnswer({ type: 'mcq' }, { option_id: 'b' }, C), false);
  assert.equal(markAnswer({ type: 'mcq' }, undefined, C), false);
  assert.equal(markAnswer({ type: 'multi_select' }, { option_ids: ['a', 'c'] }, new Set(['c', 'a'])), true);
  assert.equal(markAnswer({ type: 'multi_select' }, { option_ids: ['a'] }, new Set(['c', 'a'])), false, 'partial = wrong');
  assert.equal(markAnswer({ type: 'multi_select' }, { option_ids: ['a', 'b', 'c'] }, new Set(['c', 'a'])), false, 'extra option = wrong');
  const num = { type: 'numeric', answer_key: { value: 3.5, tolerance: 0.05 } };
  assert.equal(markAnswer(num, { text_answer: ' 3.54 ' }, C), true); assert.equal(markAnswer(num, { text_answer: '3.6' }, C), false);
  assert.equal(markAnswer(num, { text_answer: '' }, C), false); assert.equal(markAnswer(num, { text_answer: 'abc' }, C), false);
  assert.equal(markAnswer({ type: 'numeric', answer_key: { value: 1000 } }, { text_answer: '1,000' }, C), true);
  const fb = { type: 'fill_blank', answer_key: { accepted: ['Abuja'], caseSensitive: false } };
  assert.equal(markAnswer(fb, { text_answer: '  abuja ' }, C), true); assert.equal(markAnswer(fb, { text_answer: 'Lagos' }, C), false); assert.equal(markAnswer(fb, { text_answer: '   ' }, C), false);
  assert.equal(markAnswer({ type: 'short_answer', answer_key: { accepted: ['H2O'], caseSensitive: true } }, { text_answer: 'h2o' }, C), false);
  assert.equal(isManual({ type: 'theory' }), true); assert.equal(isManual({ type: 'short_answer', answer_key: null }), true);
  assert.equal(markAnswer({ type: 'short_answer', answer_key: null }, { text_answer: 'x' }, C), null);
});

test('rate-limit keys: sessions behind ONE school IP get separate budgets; the per-IP ceiling stops cookie spraying', () => {
  const { sessionKey, ipCeiling } = require('../src/lib/ratekey');
  const { COOKIE } = require('../src/auth/sessions');
  const a = sessionKey({ ip: '10.0.0.1', cookies: { [COOKIE]: 'tokA' } }); const b = sessionKey({ ip: '10.0.0.1', cookies: { [COOKIE]: 'tokB' } });
  assert.notEqual(a, b); assert.ok(a.startsWith('s:')); assert.ok(!a.includes('tokA'), 'raw token never used as a key');
  assert.equal(sessionKey({ ip: '10.0.0.9', cookies: {} }), 'ip:10.0.0.9');
  const hook = ipCeiling({ perMinute: 3 }); let blocked = 0; let passed = 0;
  const reply = { code() { return this; }, header() { return this; }, send() { blocked++; } };
  for (let i = 0; i < 5; i++) hook({ ip: '10.0.0.1', id: 'r' }, reply, () => { passed++; });
  assert.equal(passed, 3); assert.equal(blocked, 2);
  hook({ ip: '10.0.0.2', id: 'r' }, reply, () => { passed++; }); assert.equal(passed, 4, 'other networks unaffected');
});
