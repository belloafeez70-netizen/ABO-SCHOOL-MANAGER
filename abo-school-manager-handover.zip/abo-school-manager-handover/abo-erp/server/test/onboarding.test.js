'use strict';
const H = require('./helpers');
const test = require('node:test');
const assert = require('node:assert/strict');
let S;
test.before(async () => { S = await H.setup(); });
test.after(() => H.teardown());

test('self-registration → pending → email verification → active → owner must enrol MFA → checklist', async () => {
  const c = H.client(S.app);
  const weak = await c.post('/api/v1/onboarding/register', { school: { name: 'Sunrise Nursery & Primary', slug: 'sunrise-np', schoolType: 'primary' }, owner: { fullName: 'Mrs Sade Ade', loginId: 'sunrise.owner', email: 'sade@sunrise.example', password: 'password1' } });
  assert.equal(weak.status, 400);
  const r = await c.post('/api/v1/onboarding/register', { school: { name: 'Sunrise Nursery & Primary', slug: 'sunrise-np', schoolType: 'primary', address: '4 Ring Road, Ibadan', phone: '08030000000' }, owner: { fullName: 'Mrs Sade Ade', loginId: 'sunrise.owner', email: 'sade@sunrise.example', password: 'Sunrise-School-2026' } });
  assert.equal(r.status, 200); assert.ok(r.body.devVerificationToken, 'dev-only token (never returned in production)');
  assert.equal((await c.post('/api/v1/onboarding/register', { school: { name: 'Dup', slug: 'sunrise-np', schoolType: 'primary' }, owner: { fullName: 'X Y', loginId: 'other.owner', email: 'x@y.ng', password: 'Sunrise-School-2026' } })).status, 409);
  const pend = await c.post('/api/v1/auth/login', { loginId: 'sunrise.owner', password: 'Sunrise-School-2026' });
  assert.equal(pend.status, 403); assert.equal(pend.body.error.code, 'SCHOOL_INACTIVE');
  assert.equal((await c.post('/api/v1/auth/verify-email', { token: r.body.devVerificationToken })).status, 200);
  // manual approval (default): the platform approves the verified school before anyone can sign in
  const waiting = await c.post('/api/v1/auth/login', { loginId: 'sunrise.owner', password: 'Sunrise-School-2026' });
  assert.equal(waiting.status, 403); assert.match(waiting.body.error.message, /approval/);
  const plat = await H.login(S.app, 'abo.platform');
  const pend2 = (await plat.get('/api/v1/platform/schools?status=pending')).body.items.find((x) => x.slug === 'sunrise-np');
  assert.equal((await plat.patch(`/api/v1/platform/schools/${pend2.id}`, { status: 'active', reason: 'Verified registration' })).status, 200);
  const owner = await H.login(S.app, 'sunrise.owner', { password: 'Sunrise-School-2026' });   // helper enrols MFA (school_owner requires it)
  const st = await owner.get('/api/v1/onboarding/status');
  assert.equal(st.status, 200); assert.ok(st.body.steps.find((s) => s.key === 'verify').done); assert.ok(!st.body.steps.find((s) => s.key === 'classes').done);
  await owner.post('/api/v1/academic/sessions', { name: '2025/2026', isCurrent: true });
  const cl = await owner.post('/api/v1/academic/classes', { name: 'Basic 1', arms: ['A', 'B', 'C'], section: 'primary' });
  assert.deepEqual(cl.body.items.map((x) => x.display_name), ['BASIC 1A', 'BASIC 1B', 'BASIC 1C']);
  const st2 = await owner.get('/api/v1/onboarding/status'); assert.ok(st2.body.steps.find((s) => s.key === 'classes').done);
  const roles = await owner.get('/api/v1/roles'); assert.ok(roles.body.items.length >= 14, 'role templates provisioned');
  // new tenant is isolated from the demo schools
  assert.equal((await owner.get('/api/v1/students')).body.total, 0);
});
test('school profile, grading & components are validated; logo upload rejects SVG/HTML', async () => {
  const owner = await H.login(S.app, 'sa.owner');
  assert.equal((await owner.patch('/api/v1/school', { schoolType: 'secondary', phone: '+234 805 144 6681' })).status, 200);
  assert.equal((await owner.put('/api/v1/school/settings', { assessmentComponents: [{ key: 'ca1', label: 'CA', max: 30 }, { key: 'exam', label: 'Exam', max: 60 }] })).status, 400);
  assert.equal((await owner.put('/api/v1/school/settings', { assessmentComponents: [{ key: 'ca1', label: 'CA 1', max: 10 }, { key: 'ca2', label: 'CA 2', max: 10 }, { key: 'ca3', label: 'CA 3', max: 20 }, { key: 'exam', label: 'Exam', max: 60 }] })).status, 200);
  const svg = await owner.post('/api/v1/school/logo', undefined, { multipart: H.multipart({}, { name: 'logo.svg', type: 'image/svg+xml', data: '<svg xmlns="http://www.w3.org/2000/svg" onload="alert(1)"/>' }) });
  assert.equal(svg.status, 400);
  const fake = await owner.post('/api/v1/school/logo', undefined, { multipart: H.multipart({}, { name: 'logo.png', type: 'image/png', data: '<html><script>alert(1)</script></html>' }) });
  assert.equal(fake.status, 400);
  const ok = await owner.post('/api/v1/school/logo', undefined, { multipart: H.multipart({}, { name: 'logo.png', type: 'image/png', data: H.PNG_1PX }) });
  assert.equal(ok.status, 200);
  const dl = await owner.get(`/api/v1/files/${ok.body.fileId}`);
  assert.equal(dl.status, 200); assert.equal(dl.headers['content-type'], 'image/png'); assert.match(dl.headers['content-security-policy'], /sandbox/);
  assert.equal(dl.headers['x-content-type-options'], 'nosniff');
  const anon = await S.app.inject({ method: 'GET', url: `/api/v1/files/${ok.body.fileId}` }); assert.equal(anon.statusCode, 401);
});
