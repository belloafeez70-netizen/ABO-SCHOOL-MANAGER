'use strict';
// Phase 6 (part 4): the owner's "sign in as" and the school web address — rules checked on the server.
const H = require('./helpers');
const test = require('node:test');
const assert = require('node:assert/strict');

let S, owner, admin, teacher, bOwner;
const db = async (q, p) => { const c = await H.dbAs('owner'); try { return (await c.query(q, p)).rows; } finally { await c.end(); } };
test.before(async () => {
  S = await H.setup();
  [owner, admin, teacher, bOwner] = await Promise.all(['sa.owner', 'sa.admin', 'sa.teacher1', 'sb.owner'].map((l) => H.login(S.app, l)));
});
test.after(() => H.teardown());

test('sign in as: owner only, reason + time limit, sees exactly what the person sees, blocked areas, audited, notified, stops cleanly', async () => {
  const uid = async (login) => (await db('SELECT id FROM users WHERE login_id = $1', [login]))[0].id;
  const tId = await uid('sa.teacher1'); const aId = await uid('sa.admin'); const bTeacher = await uid('sb.teacher1'); const oId = await uid('sa.owner');
  assert.equal((await admin.post('/api/v1/auth/act-as', { userId: tId, reason: 'checking notes' })).status, 403, 'an administrator cannot sign in as others');
  assert.equal((await owner.post('/api/v1/auth/act-as', { userId: tId, reason: 'x' })).status, 400, 'a reason is required');
  assert.equal((await owner.post('/api/v1/auth/act-as', { userId: tId, reason: 'Check lesson notes', minutes: 240 })).status, 400, 'at most 60 minutes');
  assert.equal((await owner.post('/api/v1/auth/act-as', { userId: oId, reason: 'Myself please' })).status, 400, 'not as yourself');
  assert.equal((await owner.post('/api/v1/auth/act-as', { userId: bTeacher, reason: 'Other school teacher' })).status, 404, 'not someone from another school');
  const cands = (await owner.get('/api/v1/auth/act-as/candidates')).body.items;
  assert.ok(cands.some((x) => x.id === tId) && cands.some((x) => x.id === aId) && !cands.some((x) => x.id === oId), 'candidates: members of this school, not the owner');
  const before = (await owner.get('/api/v1/auth/me')).body;
  const r = await owner.post('/api/v1/auth/act-as', { userId: tId, reason: 'Help Mr Bello with his lesson notes', minutes: 15 });
  assert.equal(r.status, 200, JSON.stringify(r.body)); assert.equal(r.body.as.loginId, 'sa.teacher1');
  const me = (await owner.get('/api/v1/auth/me')).body;
  assert.equal(me.user.loginId, 'sa.teacher1', 'the app now works as the teacher');
  assert.deepEqual(me.roles.map((x) => x.key).sort(), ['form_teacher', 'teacher'], 'with the teacher’s roles only');
  assert.ok(!me.permissions.includes('users.impersonate') && !me.permissions.includes('settings.update'), 'no owner powers while acting');
  assert.equal(me.actingAs.byLoginId, 'sa.owner'); assert.match(me.actingAs.reason, /lesson notes/);
  // works as the teacher: a lesson note is written under the teacher's name
  const o = (await owner.get('/api/v1/lesson-notes/options')).body;
  const pair = o.pairs[0]; const term = o.terms.find((t) => t.is_current) || o.terms[0];
  const ln = await owner.post('/api/v1/lesson-notes', { termId: term.id, classId: pair.class_id, subjectId: pair.subject_id, week: 2, topic: 'Shapes around us', content: 'Squares, circles and triangles.' });
  assert.equal(ln.status, 200, JSON.stringify(ln.body));
  assert.equal((await db('SELECT author_id FROM lesson_notes WHERE id = $1', [ln.body.id]))[0].author_id, tId, 'the note belongs to the teacher');
  // blocked while acting
  for (const [m, u, b] of [['post', '/api/v1/auth/password/change', { currentPassword: 'x', newPassword: 'Blue-Mango-2026-x' }], ['post', '/api/v1/auth/mfa/setup', {}], ['get', '/api/v1/messages/threads'],
    ['get', '/api/v1/auth/sessions'], ['post', '/api/v1/auth/act-as', { userId: aId, reason: 'nested acting' }], ['get', '/api/v1/users']]) {
    const x = await owner[m](u, b);
    assert.equal(x.status, 403, `${u} must be blocked while acting (got ${x.status})`); assert.match(x.body.error.message, /signed in as someone else/);
  }
  // audit: the owner is named; the person was notified; a security event exists
  const au = await db("SELECT actor_user_id, actor_login FROM audit_logs WHERE action = 'lesson_notes.created' ORDER BY seq DESC LIMIT 1");
  assert.equal(au[0].actor_user_id, oId, 'audit log names the owner'); assert.equal(au[0].actor_login, 'sa.owner (as sa.teacher1)');
  assert.ok((await db("SELECT 1 FROM audit_logs WHERE action = 'auth.act_as_started'")).length === 1);
  assert.ok((await db("SELECT 1 FROM notifications WHERE user_id = $1 AND title = 'The school owner signed in as you'", [tId])).length === 1, 'the teacher is told');
  assert.ok((await db("SELECT 1 FROM security_events WHERE kind = 'impersonation_started'")).length >= 1);
  // the teacher's own session is untouched
  assert.equal((await teacher.get('/api/v1/auth/me')).body.user.loginId, 'sa.teacher1');
  // stop
  const st = await owner.post('/api/v1/auth/act-as/stop', {}); assert.equal(st.status, 200); assert.equal(st.body.wasActing, true);
  const back = (await owner.get('/api/v1/auth/me')).body;
  assert.equal(back.user.loginId, 'sa.owner'); assert.equal(back.actingAs, null); assert.ok(back.permissions.includes('users.impersonate'));
  assert.ok((await db("SELECT 1 FROM audit_logs WHERE action = 'auth.act_as_stopped' AND actor_login = 'sa.owner'")).length === 1);
});

test('sign in as: ends by itself when the time is up or when the person is turned off; never as another owner', async () => {
  const tId = (await db("SELECT id FROM users WHERE login_id = 'sa.teacher2'"))[0].id;
  assert.equal((await owner.post('/api/v1/auth/act-as', { userId: tId, reason: 'Check attendance marks', minutes: 5 })).status, 200);
  assert.equal((await owner.get('/api/v1/auth/me')).body.user.loginId, 'sa.teacher2');
  await db("UPDATE sessions SET acting_expires_at = now() - interval '1 second' WHERE acting_user_id = $1", [tId]);
  assert.equal((await owner.get('/api/v1/auth/me')).body.user.loginId, 'sa.owner', 'time up → back to the owner automatically');
  await owner.post('/api/v1/auth/act-as/stop', {});
  assert.equal((await owner.post('/api/v1/auth/act-as', { userId: tId, reason: 'Check attendance marks', minutes: 5 })).status, 200);
  await db("UPDATE users SET status = 'disabled' WHERE id = $1", [tId]);
  assert.equal((await owner.get('/api/v1/auth/me')).body.user.loginId, 'sa.owner', 'person turned off → acting stops');
  await db("UPDATE users SET status = 'active' WHERE id = $1", [tId]);
  await owner.post('/api/v1/auth/act-as/stop', {});
  // another owner of the same school cannot be a target
  const r = await owner.post('/api/v1/users', { fullName: 'Second Owner', loginId: 'sa.owner2', roleKeys: ['school_owner'] });
  assert.ok(r.status === 200 || r.status === 201, JSON.stringify(r.body));
  const id2 = (await db("SELECT id FROM users WHERE login_id = 'sa.owner2'"))[0].id;
  await db("UPDATE users SET status = 'active' WHERE id = $1", [id2]);
  const x = await owner.post('/api/v1/auth/act-as', { userId: id2, reason: 'Another owner test' });
  assert.equal(x.status, 403, 'never as another owner'); assert.match(x.body.error.message, /another owner/);
  assert.ok(!(await owner.get('/api/v1/auth/act-as/candidates')).body.items.some((c) => c.id === id2), 'other owners are not offered');
});

test('web address: valid, unique, old address keeps working, reserved words refused', async () => {
  const cur = (await owner.get('/api/v1/school/web-address')).body; assert.equal(cur.slug, 'school-a'); assert.match(cur.portalUrl, /#\/s\/school-a$/);
  for (const [bad, why] of [['ab', 'too short'], ['Bad Name', 'spaces/capitals'], ['-start', 'leading dash'], ['a--b', 'double dash'], ['admin', 'reserved']]) {
    const r = await owner.put('/api/v1/school/web-address', { slug: bad }); assert.equal(r.status, bad === 'Bad Name' ? 400 : 400, `${bad}: ${why}`);
  }
  assert.equal((await owner.put('/api/v1/school/web-address', { slug: 'school-b' })).status, 409, 'another school’s address refused');
  assert.equal((await teacher.put('/api/v1/school/web-address', { slug: 'bright-oak' })).status, 403);
  assert.equal((await owner.get('/api/v1/school/web-address/check?slug=bright-oak')).body.ok, true);
  const ch = await owner.put('/api/v1/school/web-address', { slug: 'bright-oak' }); assert.equal(ch.status, 200, JSON.stringify(ch.body)); assert.equal(ch.body.previous, 'school-a');
  const c = H.client(S.app);
  assert.equal((await c.get('/api/v1/public/schools/bright-oak')).body.slug, 'bright-oak');
  const old = await c.get('/api/v1/public/schools/school-a');
  assert.equal(old.status, 200, 'the old address still finds the school'); assert.equal(old.body.slug, 'bright-oak', '…and tells the page the new address');
  assert.equal((await bOwner.put('/api/v1/school/web-address', { slug: 'school-a' })).status, 409, 'an old address is never given to another school');
  assert.equal((await bOwner.get('/api/v1/school/web-address/check?slug=school-a')).body.ok, false);
  assert.equal((await owner.put('/api/v1/school/web-address', { slug: 'school-a' })).status, 200, 'a school may go back to its own old address');
  assert.equal((await c.get('/api/v1/public/schools/bright-oak')).body.slug, 'school-a', 'and the newer one now points back');
  assert.ok((await db("SELECT 1 FROM audit_logs WHERE action = 'school.web_address_changed'")).length === 2);
});
