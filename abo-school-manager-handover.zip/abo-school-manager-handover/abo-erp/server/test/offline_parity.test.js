'use strict';
// 027 (12 Oct 2026): the last offline-edition features on the server — old debts, petty cash requests, questions from
// teachers (bank approval), automatic reminders, devices, print centre data and the score sheet layout. Every rule is
// checked on the server, every table is fenced to its school.
const H = require('./helpers');
const test = require('node:test');
const assert = require('node:assert/strict');

let S, owner, bursar, accounts, teacher, teacher2, exams, student, parent, ict, bOwner;
test.before(async () => {
  S = await H.setup();
  [owner, bursar, accounts, teacher, teacher2, exams, student, parent, ict, bOwner] = await Promise.all(
    ['sa.owner', 'sa.bursar', 'sa.accounts', 'sa.teacher1', 'sa.teacher2', 'sa.exams', 'sa.student', 'sa.parent', 'sa.admin', 'sb.owner'].map((l) => H.login(S.app, l)));
});
test.after(() => H.teardown());

test('old debts: paste → preview finds learners → one brought-forward invoice each, never twice; parents see and pay it; school B sees nothing', async () => {
  const kids = (await owner.get('/api/v1/students?pageSize=5')).body.items;
  const [k1, k2, k3] = kids;
  const rows = [
    { ref: k1.admission_no, amountKobo: 1500000, note: 'Second term balance' },
    { ref: `${k2.first_name} ${k2.last_name}`, amountKobo: 250000 },
    { ref: 'Nobody Called This', amountKobo: 100 },
    { ref: k1.admission_no, amountKobo: 999 },
  ];
  assert.equal((await teacher.post('/api/v1/fees/arrears/preview', { rows })).status, 403, 'teachers cannot bill');
  let r = await bursar.post('/api/v1/fees/arrears/preview', { rows });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.deepEqual(r.body.items.map((i) => i.status), ['ok', 'ok', 'not_found', 'duplicate']);
  assert.equal(r.body.summary.ready, 2); assert.equal(r.body.summary.totalKobo, 1750000);
  assert.equal((await bursar.post('/api/v1/fees/arrears/preview', { rows: [{ ref: k1.admission_no, amountKobo: -5 }] })).status, 400, 'no negative debts');
  r = await bursar.post('/api/v1/fees/arrears/import', { rows, dueDate: '2026-11-30' }, { headers: { 'idempotency-key': 'arrears-qa-0001' } });
  assert.equal(r.status, 200, JSON.stringify(r.body)); assert.equal(r.body.created, 2);
  assert.match(r.body.items[0].invoiceNo, /^BFW-\d{4}-000001$/);
  const again = await bursar.post('/api/v1/fees/arrears/import', { rows, dueDate: '2026-11-30' }, { headers: { 'idempotency-key': 'arrears-qa-0001' } });
  assert.equal(again.headers['idempotent-replayed'], 'true', 'a retried import is not billed twice');
  r = await bursar.post('/api/v1/fees/arrears/import', { rows: rows.slice(0, 1) });
  assert.equal(r.body.created, 0); assert.equal(r.body.items[0].status, 'exists', 'the same old debt is never billed twice');
  const list = (await accounts.get('/api/v1/fees/arrears')).body;
  assert.equal(list.totals.learners, 2); assert.equal(list.totals.owedKobo, 1750000);   // (checked before the parent's child is added below)
  const inv = list.items.find((i) => i.student_id === k1.id);
  assert.equal(inv.note, 'Second term balance');
  // a normal payment works on it
  r = await bursar.post('/api/v1/fees/payments', { invoiceId: inv.id, amountKobo: 500000, method: 'cash' });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.equal((await accounts.get('/api/v1/fees/arrears')).body.totals.owedKobo, 1250000);
  // the parent sees the old debt in their own fees page, labelled as owed from before
  const child = (await parent.get('/api/v1/auth/me')).body.children[0];
  if (![k1.id, k2.id].includes(child.id)) assert.equal((await bursar.post('/api/v1/fees/arrears/import', { rows: [{ ref: child.admission_no, amountKobo: 80000, note: 'Bus fare arrears' }] })).body.created, 1);
  const my = (await parent.get('/api/v1/fees/my')).body.items.find((i) => i.kind === 'brought_forward');
  assert.ok(my && my.student_id === child.id && Number(my.balance_kobo) > 0, 'the parent sees their child\'s old debt');
  void k3;
  // isolation
  assert.equal((await bOwner.get('/api/v1/fees/arrears')).body.items.length, 0, 'school B sees none of school A\'s old debts');
  assert.equal((await parent.get('/api/v1/fees/arrears')).status, 403);
});

test('petty cash: ask → someone else approves → handed out from the box → settled; books show only what was spent', async () => {
  const cats = (await bursar.get('/api/v1/cashbook/categories')).body.items;
  const topUp = cats.find((c) => c.name === 'Money into petty cash'); const stat = cats.find((c) => c.name === 'Stationery & printing');
  const ymd = new Date().toISOString().slice(0, 10);
  let r = await teacher.post('/api/v1/pettycash/requests', { purpose: 'Chalk and markers for JSS 1', amountKobo: 500000 });
  assert.equal(r.status, 200, JSON.stringify(r.body)); assert.match(r.body.ref_no, /^PCR-\d{4}-000001$/); const req1 = r.body;
  assert.equal((await student.post('/api/v1/pettycash/requests', { purpose: 'Sweets', amountKobo: 100 })).status, 403, 'pupils cannot ask');
  // staff see only their own; approvers see all
  assert.equal((await teacher2.get('/api/v1/pettycash/requests')).body.items.length, 0);
  assert.equal((await bursar.get('/api/v1/pettycash/requests')).body.items.length, 1);
  assert.equal((await teacher.post(`/api/v1/pettycash/requests/${req1.id}/decide`, { approve: true })).status, 403, 'teachers cannot approve');
  assert.equal((await bursar.post(`/api/v1/pettycash/requests/${req1.id}/give`, { categoryId: stat.id })).status, 409, 'not before approval');
  // the bursar's own request needs another approver
  r = await bursar.post('/api/v1/pettycash/requests', { purpose: 'Fuel for the generator', amountKobo: 200000 }); const own = r.body;
  r = await bursar.post(`/api/v1/pettycash/requests/${own.id}/decide`, { approve: true });
  assert.equal(r.status, 403); assert.match(r.body.error.message, /Another person/);
  assert.equal((await bursar.post(`/api/v1/pettycash/requests/${req1.id}/decide`, { approve: false })).status, 400, 'a refusal needs a reason');
  assert.equal((await bursar.post(`/api/v1/pettycash/requests/${req1.id}/decide`, { approve: true })).status, 200);
  // empty box → cannot hand out
  r = await bursar.post(`/api/v1/pettycash/requests/${req1.id}/give`, { categoryId: stat.id });
  assert.equal(r.status, 400); assert.match(r.body.error.message, /only ₦0\.00 in petty cash/);
  assert.equal((await bursar.post('/api/v1/cashbook/entries', { kind: 'income', categoryId: topUp.id, amountKobo: 1000000, entryDate: ymd, method: 'petty_cash', description: 'Top up petty cash' })).status, 200);
  assert.equal((await bursar.post(`/api/v1/pettycash/requests/${req1.id}/give`, { categoryId: topUp.id })).status, 400, 'must be an expense category');
  r = await bursar.post(`/api/v1/pettycash/requests/${req1.id}/give`, { categoryId: stat.id });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  let sum = (await bursar.get(`/api/v1/cashbook/summary?from=${ymd}&to=${ymd}`)).body;
  assert.equal(sum.pettyCash.balanceKobo, 500000, 'the box paid out ₦5,000');
  assert.equal((await bursar.post(`/api/v1/pettycash/requests/${req1.id}/settle`, { spentKobo: 600000 })).status, 400, 'cannot spend more than was given');
  r = await bursar.post(`/api/v1/pettycash/requests/${req1.id}/settle`, { spentKobo: 350000, note: 'Receipts attached' });
  assert.equal(r.status, 200, JSON.stringify(r.body)); assert.equal(r.body.returnedKobo, 150000); assert.equal(r.body.boxKobo, 650000, 'change is back in the box');
  sum = (await bursar.get(`/api/v1/cashbook/summary?from=${ymd}&to=${ymd}`)).body;
  assert.equal(sum.pettyCash.balanceKobo, 650000);
  const spentLines = (await bursar.get(`/api/v1/cashbook/entries?from=${ymd}&to=${ymd}&method=petty_cash&kind=expense`)).body.items;
  assert.equal(spentLines.length, 1); assert.equal(Number(spentLines[0].amount_kobo), 350000, 'only the real spending stays in the books');
  const voided = (await bursar.get(`/api/v1/cashbook/entries?from=${ymd}&to=${ymd}&method=petty_cash&kind=expense&includeVoided=true`)).body.items.filter((e) => e.voided_at);
  assert.equal(voided.length, 1); assert.match(voided[0].void_reason, /change returned/, 'the hand-out entry stays in the book, voided with the reason');
  // owner approves the bursar's own request; teacher can cancel only their own pending request
  assert.equal((await owner.post(`/api/v1/pettycash/requests/${own.id}/decide`, { approve: false, note: 'Use the diesel budget' })).status, 200);
  r = await teacher.post('/api/v1/pettycash/requests', { purpose: 'Printing past questions', amountKobo: 30000 });
  assert.equal((await teacher2.post(`/api/v1/pettycash/requests/${r.body.id}/cancel`)).status, 404);
  assert.equal((await teacher.post(`/api/v1/pettycash/requests/${r.body.id}/cancel`)).status, 200);
  assert.equal((await bOwner.get('/api/v1/pettycash/requests')).body.items.length, 0, 'school B sees nothing');
});

test('questions from teachers: with approval on, teachers\' bank questions wait; the exam officer approves or sends back; waiting questions never reach an exam', async () => {
  const Q = (t) => ({ type: 'mcq', text: t, options: [{ text: 'Abuja', isCorrect: true }, { text: 'Lagos' }] });
  let r = await teacher.post('/api/v1/cbt/bank', Q('Capital of Nigeria (no approval yet)'));
  assert.equal(r.status, 200); assert.equal(r.body.status, 'active', 'approval is off by default — nothing changes for schools that do not want it');
  assert.equal((await teacher.put('/api/v1/cbt/settings', { bankApproval: true })).status, 403);
  assert.equal((await owner.put('/api/v1/cbt/settings', { bankApproval: true })).status, 200);
  r = await teacher.post('/api/v1/cbt/bank', Q('Capital of Nigeria?')); const q1 = r.body;
  assert.equal(q1.status, 'pending');
  r = await exams.post('/api/v1/cbt/bank', Q('Exam officer question')); assert.equal(r.body.status, 'active', 'the exam officer\'s own questions go straight in');
  // only active questions are in the bank list; teachers see their own waiting questions
  const active = (await teacher2.get('/api/v1/cbt/bank?pageSize=100')).body.items.map((x) => x.id);
  assert.ok(!active.includes(q1.id), 'a waiting question is not in the bank');
  assert.ok((await teacher.get('/api/v1/cbt/bank?status=pending')).body.items.some((x) => x.id === q1.id));
  assert.equal((await teacher2.get('/api/v1/cbt/bank?status=pending')).body.items.length, 0, 'teachers do not see other teachers\' waiting questions');
  // restoring from the archive never skips the check
  assert.equal((await teacher.post(`/api/v1/cbt/bank/${q1.id}/archive`, { archived: false })).status, 200);
  assert.equal((await teacher.get('/api/v1/cbt/bank?status=pending')).body.items.filter((x) => x.id === q1.id).length, 1);
  // review
  assert.equal((await teacher.get('/api/v1/cbt/bank/review')).status, 403);
  r = await exams.get('/api/v1/cbt/bank/review');
  assert.equal(r.status, 200); assert.equal(r.body.approvalOn, true); assert.ok(r.body.items.some((x) => x.id === q1.id && x.submitted_by));
  assert.equal((await exams.post(`/api/v1/cbt/bank/${q1.id}/review`, { approve: false })).status, 400, 'sending back needs a note');
  assert.equal((await exams.post(`/api/v1/cbt/bank/${q1.id}/review`, { approve: false, note: 'Add two more options' })).status, 200);
  let mine = (await teacher.get('/api/v1/cbt/bank?status=rejected')).body.items.find((x) => x.id === q1.id);
  assert.equal(mine.review_note, 'Add two more options');
  // the teacher fixes it → waiting again → approved → in the bank
  assert.equal((await teacher.patch(`/api/v1/cbt/bank/${q1.id}`, { ...Q('Capital of Nigeria?'), options: [{ text: 'Abuja', isCorrect: true }, { text: 'Lagos' }, { text: 'Kano' }, { text: 'Ibadan' }] })).status, 200);
  assert.ok((await teacher.get('/api/v1/cbt/bank?status=pending')).body.items.some((x) => x.id === q1.id));
  assert.equal((await exams.post(`/api/v1/cbt/bank/${q1.id}/review`, { approve: true })).status, 200);
  assert.equal((await exams.post(`/api/v1/cbt/bank/${q1.id}/review`, { approve: true })).status, 409, 'decided once');
  assert.ok((await teacher2.get('/api/v1/cbt/bank?pageSize=100')).body.items.some((x) => x.id === q1.id), 'approved → in the shared bank');
  const notes = (await teacher.get('/api/v1/notifications')).body;
  assert.ok(JSON.stringify(notes).includes('added to the question bank'), 'the teacher is told');
  await owner.put('/api/v1/cbt/settings', { bankApproval: false });
});

test('automatic reminders: rules, overdue fees with parent reminders (not twice a day), low stock, waiting approvals', async () => {
  assert.equal((await teacher.get('/api/v1/alerts')).status, 403);
  assert.equal((await accounts.put('/api/v1/alerts/rules', { feeOverdueDays: 0 })).status, 403, 'the accountant sees alerts but does not set rules');
  let r = await bursar.put('/api/v1/alerts/rules', { feeOverdueDays: 0, attendanceFloor: 80 });
  assert.equal(r.status, 200); assert.equal(r.body.rules.attendanceFloor, 80);
  // a brought-forward invoice with no due date is overdue from today when the rule is 0 days (the earlier ones are due in November)
  const k = (await owner.get('/api/v1/students?pageSize=5')).body.items[2];
  assert.equal((await bursar.post('/api/v1/fees/arrears/import', { rows: [{ ref: k.admission_no, amountKobo: 70000 }] })).body.created, 1);
  r = await accounts.get('/api/v1/alerts');
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.ok(r.body.fees.items.some((f) => f.student_id === k.id), 'an old debt with no due date shows as overdue');
  assert.ok(!r.body.fees.items.some((f) => f.due === '2026-11-30'), 'a debt due in the future is not overdue'); assert.equal(r.body.can.remind, false);
  r = await bursar.get('/api/v1/alerts');
  assert.ok(r.body.waiting.pettyCash !== null);
  const ids = r.body.fees.items.map((f) => f.id);
  r = await bursar.post('/api/v1/alerts/fee-reminders', { invoiceIds: ids });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.equal(r.body.checked, ids.length); assert.ok(r.body.sent + r.body.noParentContact === ids.length);
  const again = (await bursar.post('/api/v1/alerts/fee-reminders', { invoiceIds: ids })).body;
  assert.equal(again.sent, 0, 'never twice in one day'); assert.equal(again.skippedRecent, r.body.sent);
  // low stock
  await bursar.post('/api/v1/store/items', { name: 'Biro (blue)', unitPriceKobo: 10000, openingQty: 2, reorderLevel: 5 });
  r = await owner.get('/api/v1/alerts');
  assert.ok(r.body.stock.items.some((s) => s.name === 'Biro (blue)'));
  assert.equal((await bOwner.get('/api/v1/alerts')).body.fees.count, 0, 'school B: none of school A\'s invoices');
});

test('devices, print centre data and the score sheet layout', async () => {
  assert.equal((await teacher.post('/api/v1/devices', { name: 'Gate reader', kind: 'fingerprint' })).status, 403);
  let r = await ict.post('/api/v1/devices', { name: 'Gate fingerprint reader', kind: 'fingerprint', serial: 'ZK-001', location: 'Main gate' });
  assert.equal(r.status, 200, JSON.stringify(r.body)); const d = r.body;
  assert.equal((await ict.post('/api/v1/devices', { name: 'Second', kind: 'card', serial: 'zk-001' })).status, 409, 'serial numbers are unique');
  assert.equal((await ict.post('/api/v1/devices', { name: 'Toaster', kind: 'toaster' })).status, 400);
  assert.equal((await ict.patch(`/api/v1/devices/${d.id}`, { status: 'repair' })).body.status, 'repair');
  assert.equal((await owner.get('/api/v1/devices')).body.counts.repair, 1);
  assert.equal((await bOwner.get('/api/v1/devices')).body.items.length, 0);
  assert.equal((await bOwner.patch(`/api/v1/devices/${d.id}`, { status: 'retired' })).status, 404, 'school B cannot touch school A\'s device');
  // print centre
  const cls = (await owner.get('/api/v1/academic')).body.classes[0];
  r = await teacher.get(`/api/v1/print/register?classId=${cls.id}`);
  assert.equal(r.status, 200, JSON.stringify(r.body)); assert.ok(r.body.items.length >= 1); assert.ok(r.body.className);
  const ymd = new Date().toISOString().slice(0, 10);
  r = await bursar.get(`/api/v1/print/ledger?from=2020-01-01&to=${ymd}`);
  assert.equal(r.status, 200); assert.ok(r.body.items.length >= 1); assert.equal(typeof r.body.closingKobo, 'number');
  assert.equal((await teacher.get(`/api/v1/print/ledger?from=2020-01-01&to=${ymd}`)).status, 403);
  r = await accounts.get('/api/v1/print/stock'); assert.equal(r.status, 200); assert.equal(r.body.items[0].cost_price_kobo, null, 'sellers do not see cost prices');
  // layout
  assert.equal((await teacher.put('/api/v1/broadsheet/layout', { showGrade: false })).status, 403);
  r = await owner.put('/api/v1/broadsheet/layout', { showBreakdown: false, showStatus: false, title: 'End of term score sheet', footer: 'Principal: ____________' });
  assert.equal(r.status, 200); assert.equal(r.body.layout.showGrade, true, 'untouched columns keep their default');
  assert.equal((await teacher.get('/api/v1/broadsheet/layout')).body.layout.title, 'End of term score sheet');
  assert.equal((await bOwner.get('/api/v1/broadsheet/layout')).body.layout.title, '', 'each school has its own layout');
});
