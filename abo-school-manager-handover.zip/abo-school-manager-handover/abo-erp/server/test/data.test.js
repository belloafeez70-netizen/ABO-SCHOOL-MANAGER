'use strict';
const H = require('./helpers');
const test = require('node:test');
const assert = require('node:assert/strict');
let S, owner, teacher, exam;
test.before(async () => { S = await H.setup(); [owner, teacher, exam] = await Promise.all(['sa.owner', 'sa.teacher1', 'sa.exams'].map((l) => H.login(S.app, l))); });
test.after(() => H.teardown());

const csv = (s) => ({ name: 'students.csv', type: 'text/csv', data: s });
test('student CSV import: preview reports row errors; commit is atomic and imports only valid rows', async () => {
  const file = 'admission_no,first_name,last_name,gender,date_of_birth,class,parent_name,parent_phone\n' +
    'IMP/001,Ada,Obi,F,09/03/2015,BASIC 1A,Mrs Obi,08031112222\n' +
    'IMP/002,Tunde,Bello,Male,2015-01-02,BASIC 1B,,\n' +
    'IMP/003,Bad,Gender,X,2015-01-02,BASIC 1A,,\n' +
    'IMP/001,Dup,Row,M,,BASIC 1A,,\n' +
    'IMP/005,No,Class,M,,BASIC 9Z,,\n' +
    'SA/0001,Exists,Already,M,,,,\n';
  const pv = await owner.post('/api/v1/imports/students/preview', undefined, { multipart: H.multipart({}, csv(file)) });
  assert.equal(pv.status, 200, JSON.stringify(pv.body)); assert.equal(pv.body.totalRows, 6); assert.equal(pv.body.validRows, 2);
  const fields = pv.body.errors.map((e) => `${e.row}:${e.field}`);
  for (const f of ['4:gender', '5:admission_no', '6:class', '7:admission_no']) assert.ok(fields.includes(f), f);
  assert.equal((await teacher.post(`/api/v1/imports/${pv.body.importId}/commit`, {})).status, 403);
  const cm = await owner.post(`/api/v1/imports/${pv.body.importId}/commit`, {}); assert.equal(cm.status, 200); assert.equal(cm.body.imported, 2);
  assert.equal((await owner.post(`/api/v1/imports/${pv.body.importId}/commit`, {})).status, 409, 'cannot commit twice');
  const found = await owner.get('/api/v1/students?q=IMP/'); assert.equal(found.body.total, 2);
  assert.equal(found.body.items.find((s) => s.admission_no === 'IMP/001').class_name, 'BASIC 1A');
  const err = await owner.get(`/api/v1/imports/${pv.body.importId}/errors.csv`); assert.match(err.raw.body, /Row,Field,Problem/);
});
test('import rejects non-CSV/XLSX content and missing columns; teachers cannot import', async () => {
  const bad = await owner.post('/api/v1/imports/students/preview', undefined, { multipart: H.multipart({}, { name: 's.csv', data: '<script>alert(1)</script>' }) });
  assert.equal(bad.status, 400);
  const cols = await owner.post('/api/v1/imports/students/preview', undefined, { multipart: H.multipart({}, csv('name,age\nA,1\n')) });
  assert.equal(cols.status, 400); assert.match(cols.body.error.message, /Missing required column/);
  assert.equal((await teacher.post('/api/v1/imports/students/preview', undefined, { multipart: H.multipart({}, csv('a\n1\n')) })).status, 403);
});
test('exports: permission-checked, audited, formula-injection safe, XLSX valid', async () => {
  await owner.post('/api/v1/students', { admissionNo: 'INJ/1', firstName: '=HYPERLINK("http://evil","x")', lastName: 'Test', gender: 'Male' });
  const r = await owner.get('/api/v1/exports/students?format=csv');
  assert.equal(r.status, 200); assert.match(r.headers['content-type'], /text\/csv/);
  assert.ok(r.raw.body.includes(`"'=HYPERLINK(""http://evil"",""x"")"`), 'formula neutralised');
  const x = await owner.get('/api/v1/exports/invoices?format=xlsx');
  assert.equal(x.status, 200); assert.equal(x.raw.rawPayload.subarray(0, 2).toString(), 'PK');
  assert.equal((await teacher.get('/api/v1/exports/students')).status, 403, 'teachers lack reports.export');
  assert.equal((await exam.get('/api/v1/exports/invoices')).status, 403, 'exam officer lacks fees.view');
  const a = await owner.get('/api/v1/audit?action=data.exported'); assert.ok(a.body.items.length >= 2);
});
test('async export job builds a file only the requester can download', async () => {
  const j = await owner.get('/api/v1/exports/staff?format=csv&async=true'); assert.ok(j.body.jobId);
  const w = require('../src/jobs/worker'); while (await w.runOne());
  const st = await owner.get(`/api/v1/jobs/${j.body.jobId}`); assert.equal(st.body.status, 'done'); assert.ok(st.body.result.fileId);
  assert.equal((await owner.get(`/api/v1/files/${st.body.result.fileId}`)).status, 200);
  const other = await H.login(S.app, 'sa.admin');
  assert.equal((await other.get(`/api/v1/files/${st.body.result.fileId}`)).status, 404);
  assert.equal((await other.get(`/api/v1/jobs/${j.body.jobId}`)).status, 404);
});
test('score import goes into draft sheets only and respects locks', async () => {
  const f = 'admission_no,class,subject,ca1,ca2,exam\nSA/0001,BASIC 1A,Mathematics,18,17,52\nSA/0002,BASIC 1A,Mathematics,25,10,40\n';
  const pv = await exam.post('/api/v1/imports/scores/preview', undefined, { multipart: H.multipart({}, { name: 'scores.csv', data: f }) });
  assert.equal(pv.status, 200); assert.equal(pv.body.validRows, 1); assert.equal(pv.body.errors[0].field, 'ca1');
  assert.equal((await exam.post(`/api/v1/imports/${pv.body.importId}/commit`, {})).status, 200);
});
test('legacy offline backup migrates into the server (preview → commit), keys discarded, no accounts created', async () => {
  const legacy = {
    exportType: 'school-specific', subjects: ['English Language', 'Mathematics', 'Literature'],
    globalSettings: { session: '2025/2026', term: '1ST', className: 'PRIMARY 4A', educationLevel: 'primary' },
    students: [{ name: 'Adeyemi Kola', gender: 'Male', attendanceNo: 'LEG/1', dob: '2016-02-02', subjects: [{ ca1: 15, ca2: 16, exam: 50 }, { ca1: 12, ca2: 14, exam: 40 }, {}], teacherComment: 'Hardworking', present: 58, absent: 2, parentPhone: '08011112222' }],
    schoolData: { name: 'Legacy School', erp: { learners: { 'PRIMARY 4B': [{ name: 'Musa Aisha', gender: 'Female', attendanceNo: 'LEG/2', subjects: [] }] } } },
    cbtExams: [{ title: 'Old CBT', durationMinutes: 15, questions: [{ type: 'objective', text: '1+1', options: [{ text: '2', correct: true }, { text: '3' }] }] }],
    newsletters: [{ title: 'Old news', html: '<p>Hello <b>parents</b><script>alert(1)</script></p>' }],
    userAccounts: { teachers: [{ name: 'Mr Legacy', loginId: 'legacyT' }], students: [{ loginId: 'kola' }], admins: [] }, aiSettings: { apiKey: 'sk-should-never-import' },
  };
  const pv = await owner.post('/api/v1/migration/legacy/preview', undefined, { multipart: H.multipart({}, { name: 'backup.json', type: 'application/json', data: JSON.stringify(legacy) }) });
  assert.equal(pv.status, 200, JSON.stringify(pv.body)); assert.equal(pv.body.counts.students, 2); assert.equal(pv.body.counts.classes, 2);
  assert.ok(pv.body.warnings.some((w) => /DISCARDED/.test(w)));
  const cm = await owner.post(`/api/v1/migration/legacy/${pv.body.importId}/commit`, {}); assert.equal(cm.status, 200, JSON.stringify(cm.body));
  assert.equal(cm.body.students, 2); assert.equal(cm.body.cbtExams, 1); assert.equal(cm.body.teachers, 1);
  const s = await owner.get('/api/v1/students?q=LEG/'); assert.equal(s.body.total, 2);
  // old-app newsletters arrive as DRAFT announcements (Newsletters merged into Announcements, migration 025)
  const nl = (await owner.get('/api/v1/announcements?pageSize=100')).body.items.find((n) => n.title === 'Old news'); assert.ok(nl && nl.draft && nl.source === 'newsletter'); assert.ok(!/<script|<b>/.test(nl.body));
  const db = await H.dbAs('owner');
  try {
    assert.equal((await db.query("SELECT count(*)::int AS n FROM users WHERE lower(login_id) IN ('kola','legacyt')")).rows[0].n, 0, 'no accounts from legacy');
    const dump = JSON.stringify((await db.query('SELECT rows FROM imports WHERE id = $1', [pv.body.importId])).rows);
    assert.ok(!dump.includes('sk-should-never-import'));
  } finally { await db.end(); }
});
