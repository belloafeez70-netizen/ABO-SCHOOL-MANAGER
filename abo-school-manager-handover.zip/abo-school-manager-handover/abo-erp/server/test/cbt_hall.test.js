'use strict';
// "Exam hall" test: a whole class sits the same CBT at the same time from ONE public IP (typical school network),
// with the PRODUCTION default rate limit (600 req/min). Before per-session keying this tripped HTTP 429 mid-exam.
const H = require('./helpers');
process.env.RATE_LIMIT_GLOBAL_PER_MIN = '600';            // production default (helpers raise it for other suites)
const test = require('node:test');
const assert = require('node:assert/strict');

let S, owner, exams;
const HALL_IP = '197.210.55.10';
test.before(async () => { S = await H.setup(); [owner, exams] = await Promise.all(['sa.owner', 'sa.exams'].map((l) => H.login(S.app, l))); });
test.after(() => H.teardown());

test('30 candidates behind one IP sit the exam together: no 429s, no 5xx, every answer saved exactly once, all marked', { timeout: 600000 }, async () => {
  const db = await H.dbAs('owner');
  try {
    for (let i = 0; i < 20; i++) assert.equal((await owner.post('/api/v1/students', { admissionNo: `HALL/${i}`, firstName: `Cand${i}`, lastName: 'Hall', gender: i % 2 ? 'Male' : 'Female', classId: S.A.classes[0].id })).status, 200);
    const kids = (await db.query(`SELECT s.id, s.first_name, s.last_name FROM students s WHERE s.school_id = $1 AND s.user_id IS NULL AND s.deleted_at IS NULL ORDER BY s.admission_no LIMIT 30`, [S.A.schoolId])).rows;
    assert.ok(kids.length >= 30, `need students, got ${kids.length}`);
    const maths = (await db.query("SELECT id FROM subjects WHERE school_id = $1 AND name = 'Mathematics'", [S.A.schoolId])).rows[0].id;
    // accounts (created by the office, activated by each candidate)
    const logins = [];
    for (const [i, k] of kids.entries()) {
      const r = await owner.post('/api/v1/users', { fullName: `${k.first_name} ${k.last_name}`, loginId: `hall.${i}`, roleKeys: ['student'], link: { type: 'student', id: k.id } });
      assert.equal(r.status, 200, JSON.stringify(r.body));
      await H.client(S.app, { ip: HALL_IP }).post('/api/v1/auth/activate', { loginId: `hall.${i}`, accessCode: r.body.accessCode, newPassword: `Hall-Candidate-${i}-2026` });
      logins.push([`hall.${i}`, `Hall-Candidate-${i}-2026`]);
    }
    // a 25-question exam for exactly these candidates
    const e = (await exams.post('/api/v1/cbt/exams', { title: 'Hall test', subjectId: maths, durationMinutes: 30, showResult: true, shuffleQuestions: true })).body.id;
    for (let i = 0; i < 25; i++) await exams.post(`/api/v1/cbt/exams/${e}/questions`, { type: 'mcq', text: `Q${i}: ${i} + 1 = ?`, options: [{ text: String(i), isCorrect: false }, { text: String(i + 1), isCorrect: true }, { text: String(i + 2) }] });
    assert.equal((await exams.post(`/api/v1/cbt/exams/${e}/candidates`, { studentIds: kids.map((k) => k.id) })).status, 200);
    assert.equal((await owner.post(`/api/v1/cbt/exams/${e}/publish`)).status, 200);
    // everyone signs in from the same IP and starts at once
    const students = await Promise.all(logins.map(([l, p]) => H.login(S.app, l, { password: p, ip: HALL_IP })));
    const statuses = []; const t0 = Date.now();
    await Promise.all(students.map(async (st) => {
      const paper = await st.post(`/api/v1/cbt/exams/${e}/start`, {}); statuses.push(paper.status);
      for (const q of paper.body.questions) {                                // one autosave per answer (+ one resend, like a flaky network)
        const opt = q.options.find((o) => /^\d+$/.test(o.text) && Number(o.text) === Number(q.text.match(/Q(\d+)/)[1]) + 1);
        const r = await st.put(`/api/v1/cbt/attempts/${paper.body.attemptId}/answers`, { answers: [{ questionId: q.id, optionId: opt.id, timeSpent: 5 }] }); statuses.push(r.status);
        if (q.n % 5 === 0) statuses.push((await st.put(`/api/v1/cbt/attempts/${paper.body.attemptId}/answers`, { answers: [{ questionId: q.id, optionId: opt.id }] })).status);
      }
      statuses.push((await st.post(`/api/v1/cbt/attempts/${paper.body.attemptId}/submit`, {})).status);
    }));
    const secs = (Date.now() - t0) / 1000;
    const count = (s) => statuses.filter((x) => x === s).length;
    assert.equal(count(429), 0, 'no candidate was rate-limited');
    assert.equal(statuses.filter((x) => x >= 500).length, 0, 'no server errors');
    assert.ok(statuses.length > 600, `more than the per-IP budget was served (${statuses.length} requests)`);
    const ans = (await db.query('SELECT count(*)::int AS n FROM cbt_answers an JOIN cbt_attempts a ON a.id = an.attempt_id WHERE a.exam_id = $1', [e])).rows[0].n;
    assert.equal(ans, kids.length * 25, 'every answer stored exactly once');
    const res = (await db.query('SELECT count(*)::int AS n, min(score)::int AS lo FROM cbt_results WHERE exam_id = $1', [e])).rows[0];
    assert.equal(res.n, kids.length); assert.equal(res.lo, 25, 'all marked correctly by the server');
    console.log(`exam hall: ${kids.length} candidates, ${statuses.length} requests in ${secs.toFixed(1)} s from one IP (${Math.round(statuses.length / secs)} req/s), 0 × 429, 0 × 5xx`);
  } finally { await db.end(); }
});
