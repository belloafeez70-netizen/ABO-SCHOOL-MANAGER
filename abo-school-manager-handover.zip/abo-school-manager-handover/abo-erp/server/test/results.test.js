'use strict';
const H = require('./helpers');
const test = require('node:test');
const assert = require('node:assert/strict');
let S, owner, exam, teacher, teacher2, student, parent, cls, subs, roster, sheetMine;
test.before(async () => {
  S = await H.setup();
  [owner, exam, teacher, teacher2, student, parent] = await Promise.all(['sa.owner', 'sa.exams', 'sa.teacher1', 'sa.teacher2', 'sa.student', 'sa.parent'].map((l) => H.login(S.app, l)));
  cls = S.A.classes.find((c) => c.display_name === 'BASIC 1A');
  subs = (await owner.get(`/api/v1/academic/classes/${cls.id}/subjects`)).body.items;
});
test.after(() => H.teardown());

async function fillSheet(c, subjectId, scoreFn) {
  const sh = await c.post('/api/v1/results/sheets', { termId: S.A.termId, classId: cls.id, subjectId });
  const d = await c.get(`/api/v1/results/sheets/${sh.body.id}`);
  roster = d.body.rows;
  const entries = d.body.rows.map((r, i) => ({ studentId: r.studentId, scores: scoreFn(i) }));
  const put = await c.put(`/api/v1/results/sheets/${sh.body.id}/scores`, { entries });
  return { id: sh.body.id, put };
}
test('teacher enters scores; server validates ranges and computes totals/grades/positions', async () => {
  const mine = subs.find((s) => s.teacher === 'Mr Tunde Bello');
  const over = await teacher.post('/api/v1/results/sheets', { termId: S.A.termId, classId: cls.id, subjectId: mine.subject_id });
  const d = await teacher.get(`/api/v1/results/sheets/${over.body.id}`);
  const bad = await teacher.put(`/api/v1/results/sheets/${over.body.id}/scores`, { entries: [{ studentId: d.body.rows[0].studentId, scores: { exam: 61 } }] });
  assert.equal(bad.status, 400); assert.match(bad.body.error.message, /between 0 and 60/);
  const unk = await teacher.put(`/api/v1/results/sheets/${over.body.id}/scores`, { entries: [{ studentId: d.body.rows[0].studentId, scores: { ca9: 5 } }] });
  assert.equal(unk.status, 400);
  const f = await fillSheet(teacher, mine.subject_id, (i) => ({ ca1: 20 - i, ca2: 18, exam: 55 - i * 5 }));
  assert.equal(f.put.status, 200); sheetMine = f.id;
  const top = f.put.body.computed.find((r) => r.position === 1);
  assert.equal(top.total, 93); assert.equal(top.grade, 'A+');    // BASIC 1A is a primary class → primary scale
});
test('client cannot send totals/grades — only raw component scores are accepted', async () => {
  const r = await teacher.put(`/api/v1/results/sheets/${sheetMine}/scores`, { entries: [{ studentId: roster[0].studentId, scores: { ca1: 10 }, total: 100, grade: 'A+' }] });
  assert.equal(r.status, 400);
});
test('workflow: DRAFT → SUBMITTED → REVIEWED → APPROVED, four-eyes, locked (API + DB trigger)', async () => {
  assert.equal((await teacher.post(`/api/v1/results/sheets/${sheetMine}/submit`, {})).status, 200);
  assert.equal((await teacher.put(`/api/v1/results/sheets/${sheetMine}/scores`, { entries: [{ studentId: roster[0].studentId, scores: { ca1: 1 } }] })).status, 423, 'read-only while in review');
  assert.equal((await teacher.post(`/api/v1/results/sheets/${sheetMine}/review`, { action: 'approve' })).status, 403, 'teacher lacks results.approve');
  const ret = await exam.post(`/api/v1/results/sheets/${sheetMine}/review`, { action: 'return' }); assert.equal(ret.status, 400, 'return needs a note');
  const early = await exam.post(`/api/v1/results/sheets/${sheetMine}/review`, { action: 'approve' });
  assert.equal(early.status, 409, 'cannot approve before review'); assert.match(early.body.error.message, /reviewed before/);
  assert.equal((await exam.post(`/api/v1/results/sheets/${sheetMine}/review`, { action: 'review', note: 'Totals checked' })).status, 200);
  assert.equal((await exam.get(`/api/v1/results/sheets/${sheetMine}`)).body.sheet.status, 'reviewed');
  assert.equal((await teacher.put(`/api/v1/results/sheets/${sheetMine}/scores`, { entries: [{ studentId: roster[0].studentId, scores: { ca1: 1 } }] })).status, 423, 'reviewed sheets are locked');
  assert.equal((await exam.post(`/api/v1/results/sheets/${sheetMine}/review`, { action: 'approve', note: 'Checked' })).status, 200);
  const edit = await teacher.put(`/api/v1/results/sheets/${sheetMine}/scores`, { entries: [{ studentId: roster[0].studentId, scores: { ca1: 1 } }] });
  assert.equal(edit.status, 423);
  // even a direct SQL write through the runtime role is refused by the trigger
  const db = await H.dbAs('app');
  await db.query('BEGIN'); await db.query("SELECT set_config('app.school_id', $1, true)", [S.A.schoolId]);
  await assert.rejects(db.query("UPDATE assessment_scores SET score = 20 WHERE sheet_id = $1", [sheetMine]), /RESULT_LOCKED/);
  await db.query('ROLLBACK'); await db.end();
});
test('exam officer cannot approve a sheet they submitted themselves', async () => {
  const s = subs.find((x) => x.teacher === 'Mrs Ngozi Okeke');
  const f = await fillSheet(exam, s.subject_id, (i) => ({ ca1: 15, ca2: 15, exam: 40 + i }));
  assert.equal((await exam.post(`/api/v1/results/sheets/${f.id}/submit`, {})).status, 200);
  assert.equal((await exam.post(`/api/v1/results/sheets/${f.id}/review`, { action: 'review' })).status, 403, 'submitter cannot review');
  assert.equal((await owner.post(`/api/v1/results/sheets/${f.id}/review`, { action: 'review' })).status, 200);
  assert.equal((await exam.post(`/api/v1/results/sheets/${f.id}/review`, { action: 'approve' })).status, 403, 'submitter cannot approve');
  assert.equal((await owner.post(`/api/v1/results/sheets/${f.id}/review`, { action: 'approve' })).status, 200);
  const ev = await owner.get('/api/v1/security/events'); assert.ok(ev.body.items.some((e) => e.kind === 'self_approval_attempt'));
});
test('publish requires every subject approved; then computes broadsheet + notifies; students see results', async () => {
  const before = await student.get(`/api/v1/results/student/${roster[0].studentId}?termId=${S.A.termId}`);
  const me = (await student.get('/api/v1/auth/me')).body.studentId;
  const pre = await student.get(`/api/v1/results/student/${me}?termId=${S.A.termId}`); assert.equal(pre.body.available, false, 'unpublished results hidden from students');
  void before;
  // remaining subjects: create empty sheets → publish must refuse
  const s3 = subs.find((x) => x.teacher === 'Mr Tunde Bello' && x.subject_id !== subs.find((s) => s.teacher === 'Mr Tunde Bello').subject_id);
  await fillSheet(teacher, s3.subject_id, () => ({ ca1: 10, ca2: 10, exam: 30 }));
  const refused = await owner.post('/api/v1/results/publish', { termId: S.A.termId, classId: cls.id });
  assert.equal(refused.status, 409);
  const sheets = await owner.get(`/api/v1/results/sheets?termId=${S.A.termId}&classId=${cls.id}`);
  for (const s of sheets.body.items.filter((x) => x.status === 'draft')) {
    await teacher.post(`/api/v1/results/sheets/${s.sheet_id}/submit`, {});
    assert.equal((await exam.post(`/api/v1/results/sheets/${s.sheet_id}/review`, { action: 'review' })).status, 200);
    assert.equal((await exam.post(`/api/v1/results/sheets/${s.sheet_id}/review`, { action: 'approve' })).status, 200);
  }
  const pub = await owner.post('/api/v1/results/publish', { termId: S.A.termId, classId: cls.id });
  assert.equal(pub.status, 200, JSON.stringify(pub.body)); assert.equal(pub.body.broadsheetVersion, 1);
  const bs = await owner.get(`/api/v1/results/broadsheet?termId=${S.A.termId}&classId=${cls.id}`);
  assert.equal(bs.body.provisional, false); assert.equal(bs.body.rows[0].summary.position, 1);
  const avgs = bs.body.rows.map((r) => Number(r.summary.average)); assert.deepEqual(avgs, [...avgs].sort((a, b) => b - a), 'sorted by position');
  const rc = await student.get(`/api/v1/results/student/${me}?termId=${S.A.termId}`);
  assert.equal(rc.body.available, true); assert.ok(rc.body.subjects.length >= 3); assert.ok(rc.body.ordinalPosition);
  const pr = await parent.get(`/api/v1/results/student/${me}?termId=${S.A.termId}`); assert.equal(pr.body.available, true);
  const n = await student.get('/api/v1/notifications'); assert.ok(n.body.items.some((x) => x.kind === 'results'));
});
test('corrections: only path to change published results; four-eyes; recompute + new broadsheet version + history + audit', async () => {
  const target = roster[1].studentId;
  const vBefore = (await owner.get(`/api/v1/results/sheets/${sheetMine}`)).body.sheet.version;
  const direct = await teacher.put(`/api/v1/results/sheets/${sheetMine}/scores`, { entries: [{ studentId: target, scores: { exam: 60 } }] });
  assert.equal(direct.status, 423);
  const req = await teacher.post('/api/v1/results/corrections', { sheetId: sheetMine, studentId: target, componentKey: 'exam', newScore: 60, reason: 'Marking error on page 3' });
  assert.equal(req.status, 200);
  assert.equal((await teacher.post(`/api/v1/results/corrections/${req.body.id}/review`, { action: 'approve' })).status, 403);
  const exReq = await exam.post('/api/v1/results/corrections', { sheetId: sheetMine, studentId: target, componentKey: 'ca1', newScore: 20, reason: 'Transcription error' });
  assert.equal((await exam.post(`/api/v1/results/corrections/${exReq.body.id}/review`, { action: 'approve' })).status, 403, 'cannot approve own correction');
  const ok = await exam.post(`/api/v1/results/corrections/${req.body.id}/review`, { action: 'approve', note: 'Verified script' });
  assert.equal(ok.status, 200); assert.equal(ok.body.recomputed, true);
  const d = await owner.get(`/api/v1/results/sheets/${sheetMine}`);
  assert.equal(d.body.rows.find((r) => r.studentId === target).scores.exam, 60); assert.equal(d.body.sheet.version, vBefore + 1, 'correction bumps the version');
  const arch = await owner.get(`/api/v1/results/broadsheets/archive?classId=${cls.id}`); assert.ok(arch.body.items.some((x) => x.version === 2));
  const hist = await exam.get(`/api/v1/results/sheets/${sheetMine}/history`); assert.ok(hist.body.items.some((h) => h.via_correction && Number(h.new_score) === 60));
  const audit = await owner.get('/api/v1/audit?action=results.correction'); assert.ok(audit.body.items.some((a) => a.action === 'results.correction_applied'));
});
test('report card comments: form teacher writes class comment; only reviewers write head comment', async () => {
  const me = (await student.get('/api/v1/auth/me')).body.studentId;
  assert.equal((await teacher.put(`/api/v1/results/report-cards/${me}`, { termId: S.A.termId, teacherComment: 'A diligent pupil.', domains: { neatness: 5 } })).status, 200);
  assert.equal((await teacher.put(`/api/v1/results/report-cards/${me}`, { termId: S.A.termId, headComment: 'Promoted' })).status, 403);
  assert.equal((await teacher2.put(`/api/v1/results/report-cards/${me}`, { termId: S.A.termId, teacherComment: 'not my class' })).status, 403);
  assert.equal((await exam.put(`/api/v1/results/report-cards/${me}`, { termId: S.A.termId, headComment: 'Excellent result.' })).status, 200);
  const rc = await parent.get(`/api/v1/results/student/${me}?termId=${S.A.termId}`);
  assert.equal(rc.body.reportCard.teacher_comment, 'A diligent pupil.'); assert.equal(rc.body.reportCard.head_comment, 'Excellent result.');
});
test('AI remark suggestion is offline-by-default, PII-free and never auto-saved', async () => {
  const me = (await student.get('/api/v1/auth/me')).body.studentId;
  const before = await parent.get(`/api/v1/results/student/${me}?termId=${S.A.termId}`);
  const r = await teacher.post('/api/v1/ai/remark-suggestion', { studentId: me, termId: S.A.termId });
  assert.equal(r.status, 200); assert.equal(r.body.source, 'offline'); assert.ok(r.body.suggestion.length > 20);
  const after = await parent.get(`/api/v1/results/student/${me}?termId=${S.A.termId}`);
  assert.equal(after.body.reportCard.teacher_comment, before.body.reportCard.teacher_comment, 'suggestion not applied automatically');
  assert.equal((await student.post('/api/v1/ai/remark-suggestion', { studentId: me, termId: S.A.termId })).status, 403);
});
