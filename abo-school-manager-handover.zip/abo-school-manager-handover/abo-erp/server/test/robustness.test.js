'use strict';
// Robustness crawl: every operation in the live OpenAPI document is exercised as several roles (plus anonymous and a
// foreign-school owner) with real IDs, random IDs, malformed IDs, hostile query strings and malformed bodies.
// The server must NEVER answer 5xx and must never leak internals (stack traces / SQL) in an error envelope.
const H = require('./helpers');
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');

let S; const clients = {};
const ROLES = ['sa.owner', 'sa.teacher1', 'sa.student', 'sa.parent', 'sa.annex', 'sa.bursar', 'sb.owner', 'abo.platform'];
test.before(async () => {
  S = await H.setup();
  for (const r of ROLES) clients[r] = await H.login(S.app, r);
});
test.after(() => H.teardown());

const failures = []; let calls = 0;
const LEAK = /(at \w+ \(|node_modules|\/src\/|syntax error at|relation "|column "|violates|duplicate key|SELECT |INSERT |UPDATE )/i;
async function hit(who, method, url, body, opts) {
  let c = clients[who] || who;
  let r = await c.req(method, url, body, opts);
  calls++;
  if (r.status === 401 && typeof who === 'string' && clients[who]) { // e.g. a crawl step revoked our own sessions
    clients[who] = await H.login(S.app, who); c = clients[who];
    r = await c.req(method, url, body, opts); calls++;
  }
  const label = `${typeof who === 'string' ? who : 'anon'} ${method} ${url}`;
  if (r.status >= 500) failures.push(`${label} → ${r.status} ${JSON.stringify(r.body).slice(0, 300)}`);
  else if (r.status >= 400 && r.body && r.body.error) {
    const e = r.body.error;
    if (!e.code || !e.message || !e.requestId) failures.push(`${label} → ${r.status} malformed error envelope ${JSON.stringify(r.body).slice(0, 200)}`);
    if (LEAK.test(e.message) || LEAK.test(JSON.stringify(e.details || ''))) failures.push(`${label} → ${r.status} leaks internals: ${JSON.stringify(e).slice(0, 300)}`);
  }
  return r;
}

// collect IDs from list responses so path params can use REAL ids of the right kind
function idsFrom(body) {
  const out = new Set();
  const items = Array.isArray(body) ? body : body && (body.items || body.rows || body.data);
  if (Array.isArray(items)) for (const it of items) if (it && typeof it.id === 'string') out.add(it.id);
  return [...out].slice(0, 2);
}
const BAD_IDS = () => [crypto.randomUUID(), 'not-a-uuid', "1' OR '1'='1", '00000000-0000-0000-0000-000000000000', '%00', 'a'.repeat(300)];
const HOSTILE_QUERY = '?page=-1&pageSize=999999&q=%27%3B%20DROP%20TABLE%20students%3B--&sort=%22id%22%3Bselect&from=not-a-date&to=2026-13-45&classId=bad&termId=%27&status=%3Cscript%3E&limit=abc';
const BODIES = [{}, [], 'x', { id: "' OR 1=1 --", name: 'a'.repeat(10000), amount: -1e308, schoolId: crypto.randomUUID(), __proto__: { admin: true } }];

let spec;
test('crawl: every documented operation, every role, hostile inputs → never 5xx, never leaks internals', { timeout: 900000 }, async () => {
  const doc = await clients['sa.owner'].get('/api/v1/openapi.json');
  assert.equal(doc.status, 200); spec = doc.body;
  const base = '/api/v1';
  const ops = [];
  for (const [p, o] of Object.entries(spec.paths)) for (const m of Object.keys(o)) ops.push([m.toUpperCase(), p]);
  assert.ok(ops.length > 100, `expected >100 operations, got ${ops.length}`);

  // 1) GET list endpoints (no params) as each role, normal + hostile query → harvest ids
  const realIds = new Map(); // path prefix → ids
  for (const [m, p] of ops.filter(([m, p]) => m === 'GET' && !p.includes('{'))) {
    for (const who of ROLES) {
      const r = await hit(who, 'GET', base + p);
      if (who === 'sa.owner' && r.status === 200) realIds.set(p, idsFrom(r.body));
      await hit(who, 'GET', base + p + HOSTILE_QUERY);
    }
    await hit(H.client(S.app), 'GET', base + p);
  }
  const idsFor = (p) => { // /students/{id}/status → ids from /students
    const prefix = p.slice(0, p.indexOf('/{'));
    return realIds.get(prefix) || realIds.get(prefix.replace(/\/[^/]+$/, '')) || [];
  };

  // 2) parameterised operations: real ids (read-only methods + safe mutations), bad ids for all methods
  const skipMutation = (p) => /^\/auth\/(logout|sessions|password|mfa)/.test(p);
  for (const [m, p] of ops.filter(([, p]) => p.includes('{'))) {
    const fill = (v) => p.replace(/\{[^}]+\}/g, encodeURIComponent(v));
    const kindish = p.includes('{kind}') || p.includes('{dataset}');
    const values = kindish ? ['students', 'nonsense', '../../etc/passwd'] : [...BAD_IDS(), ...(m === 'GET' ? idsFor(p) : [])];
    for (const v of values) {
      for (const who of ['sa.owner', 'sa.teacher1', 'sa.student', 'sb.owner']) {
        if (m === 'GET') { await hit(who, 'GET', base + fill(v)); continue; }
        if (skipMutation(p)) continue;
        await hit(who, m, base + fill(v), m === 'DELETE' ? undefined : {});
      }
      await hit(H.client(S.app), m, base + fill(v), m === 'GET' || m === 'DELETE' ? undefined : {});
    }
    // real ids with malformed bodies (validation must answer 4xx, never 5xx); never DELETE real rows here
    if (m !== 'GET' && m !== 'DELETE' && !skipMutation(p)) {
      for (const v of idsFor(p)) for (const b of BODIES) await hit('sa.owner', m, base + fill(v), b);
    }
  }

  // 3) parameterless mutations with malformed bodies, as owner + student + anonymous
  for (const [m, p] of ops.filter(([m, p]) => m !== 'GET' && !p.includes('{') && !skipMutation(p) && !/^\/auth\/(login|switch-school)$/.test(p))) {
    for (const b of BODIES) {
      await hit('sa.owner', m, base + p, b);
      await hit('sa.student', m, base + p, b);
    }
    await hit(H.client(S.app), m, base + p, {});
  }
  // 4) raw protocol abuse
  const anon = H.client(S.app);
  await hit(anon, 'POST', base + '/auth/login', '{"loginId":', { headers: { 'content-type': 'application/json' } });
  await hit(anon, 'POST', base + '/auth/login', 'loginId=x', { headers: { 'content-type': 'application/x-www-form-urlencoded' } });
  await hit(anon, 'POST', base + '/auth/login', { loginId: ['a'], password: { $ne: 1 } });
  await hit(anon, 'GET', base + '/%E0%A4%A');
  await hit(anon, 'GET', base + '/students/' + '..%2f..%2fetc%2fpasswd');

  console.log(`robustness crawl: ${ops.length} operations, ${calls} requests, ${failures.length} failures`);
  assert.deepEqual(failures, [], `server errors / leaks:\n${failures.join('\n')}`);
});

// ── schema-driven phase: VALID-shaped bodies (minimal + boundary-max + cross-tenant ids) for every mutation ──
function makeGen(pools) {
  const all = [...new Set([].concat(...Object.values(pools)))];
  const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
  const idFor = (name) => {
    const stem = String(name || '').replace(/Ids?$/, '').toLowerCase();
    if (stem) for (const [p, ids] of Object.entries(pools)) { const seg = p.split('/').pop().toLowerCase(); if (ids.length && (seg === stem + 's' || seg === stem + 'es' || seg === stem || seg.replace(/-/g, '') === stem + 's')) return pick(ids); }
    return all.length ? pick(all) : crypto.randomUUID();
  };
  const CANDIDATES = ['ABC123', 'abc.def', 'Test-01', '2026/2027', '08:00', '#1a2b3c', '+234 800 000 0000', 'a1', 'X', 'JSS1', 'ref-12345', 'abc', 'first', 'A'];
  function gen(schema, mode, name) {
    if (!schema) return null;
    if (schema.enum) return mode === 'max' ? schema.enum[schema.enum.length - 1] : schema.enum[0];
    if (schema.const !== undefined) return schema.const;
    const types = [].concat(schema.type || (schema.properties ? 'object' : 'string')).filter((t) => t !== 'null');
    const t = types[0];
    if (schema.oneOf || schema.anyOf) return gen((schema.oneOf || schema.anyOf)[0], mode, name);
    switch (t) {
      case 'object': {
        const o = {}; const req = new Set(schema.required || []);
        for (const [k, s] of Object.entries(schema.properties || {})) if (mode !== 'min' || req.has(k)) o[k] = gen(s, mode, k);
        return o;
      }
      case 'array': {
        const n = mode === 'max' ? Math.min(schema.maxItems || 3, 3) : Math.max(schema.minItems || 1, 1);
        return Array.from({ length: n }, () => gen(schema.items, mode, name));
      }
      case 'integer': case 'number': {
        if (mode === 'max' && schema.maximum !== undefined) return schema.maximum;
        return schema.minimum !== undefined ? Math.max(schema.minimum, 1 <= (schema.maximum ?? Infinity) ? Math.max(schema.minimum, 1) : schema.minimum) : 1;
      }
      case 'boolean': return mode === 'max';
      default: {
        if (schema.format === 'uuid') return idFor(name);
        if (schema.format === 'date') return mode === 'max' ? '2099-12-31' : '2026-01-15';
        if (schema.format === 'date-time') return mode === 'max' ? '2099-12-31T23:59:59Z' : '2026-01-15T08:00:00Z';
        if (schema.format === 'email') return `fuzz${Math.floor(Math.random() * 1e6)}@example.com`;
        if (schema.format === 'uri') return 'https://example.com/x';
        if (schema.pattern) { const re = new RegExp(schema.pattern); const c = CANDIDATES.find((x) => re.test(x) && x.length <= (schema.maxLength || 999) && x.length >= (schema.minLength || 0)); if (c) return c; }
        const len = mode === 'max' ? (schema.maxLength || 64) : Math.max(schema.minLength || 1, 3);
        return ('Fuzz ' + (name || 'value') + ' ' + 'x'.repeat(len)).slice(0, len).padEnd(schema.minLength || 0, 'y');
      }
    }
  }
  return { gen, idFor };
}

test('schema-driven: valid-shaped bodies (min / boundary-max / foreign-school ids) and real deletes → never 5xx', { timeout: 900000 }, async () => {
  const base = '/api/v1'; const ops = [];
  for (const [p, o] of Object.entries(spec.paths)) for (const m of Object.keys(o)) ops.push([m.toUpperCase(), p, o[m]]);
  const harvest = async (who) => {
    const pools = {};
    for (const [m, p] of ops) if (m === 'GET' && !p.includes('{')) { const r = await hit(who, 'GET', base + p + '?pageSize=100'); if (r.status === 200) pools[p] = idsFrom(r.body); }
    return pools;
  };
  const poolsA = await harvest('sa.owner'); const poolsB = await harvest('sb.owner');
  const A = makeGen(poolsA); const B = makeGen(poolsB);
  const skip = (p) => /^\/auth\//.test(p) || /webhook/.test(p);
  const bodyOf = (op) => op.requestBody && op.requestBody.content && op.requestBody.content['application/json'] && op.requestBody.content['application/json'].schema;
  const fill = (p, G) => p.replace(/\{([^}]+)\}/g, (_, n) => (n === 'kind' ? 'students' : n === 'dataset' ? 'students' : G.idFor(p.split('/')[p.split('/').indexOf('{' + n + '}') - 1].replace(/s$/, '') + 'Id')));
  const mutations = ops.filter(([m, p]) => m !== 'GET' && m !== 'DELETE' && !skip(p));
  for (let round = 0; round < 2; round++) {
    for (const [m, p, op] of mutations) {
      const schema = bodyOf(op);
      for (const mode of ['min', 'max']) {
        await hit(p.startsWith('/platform') ? 'abo.platform' : 'sa.owner', m, base + fill(p, A), schema ? A.gen(schema, mode) : undefined);
      }
      if (schema) await hit('sa.owner', m, base + fill(p, A), B.gen(schema, 'max')); // foreign-school ids in the body
      await hit('sa.owner', m, base + fill(p, B), schema ? A.gen(schema, 'min') : undefined); // foreign-school id in the path
    }
  }
  // finally: DELETE real rows (FK-referenced rows must answer 409/400, never 500)
  const refreshed = makeGen(await harvest('sa.owner'));
  for (const [m, p] of ops.filter(([m, p]) => m === 'DELETE' && !skip(p))) {
    await hit(p.startsWith('/platform') ? 'abo.platform' : 'sa.owner', 'DELETE', base + fill(p, refreshed));
    await hit('sa.teacher1', 'DELETE', base + fill(p, refreshed));
  }
  console.log(`schema-driven phase: ${calls} requests total, ${failures.length} failures`);
  assert.deepEqual(failures, [], `server errors / leaks:\n${failures.join('\n')}`);
});

test('router-level errors use the standard envelope and never echo the attacker-supplied URL', async () => {
  const anon = H.client(S.app);
  // GET falls through to the SPA wildcard → standard 404 envelope; non-GET hits the router limit → 414
  const longGet = await anon.get('/api/v1/students/' + 'x'.repeat(200) + 'REFLECTMARK');
  assert.equal(longGet.status, 404); assert.ok(longGet.body.error.requestId); assert.ok(!longGet.raw.body.includes('REFLECTMARK'));
  const long = await anon.post('/api/v1/users/' + 'x'.repeat(200) + 'REFLECTMARK' + '/unlock', {});
  assert.equal(long.status, 414); assert.equal(long.body.error.code, 'URI_TOO_LONG'); assert.ok(long.body.error.requestId);
  assert.ok(!long.raw.body.includes('REFLECTMARK'), 'URL not reflected');
  const bad = await anon.get('/api/v1/%E0%A4%AREFLECTMARK');
  assert.equal(bad.status, 400); assert.equal(bad.body.error.code, 'BAD_REQUEST'); assert.ok(!bad.raw.body.includes('REFLECTMARK'));
});
