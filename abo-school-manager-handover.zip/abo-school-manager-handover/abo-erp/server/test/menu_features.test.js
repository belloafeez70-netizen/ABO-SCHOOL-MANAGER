'use strict';
// Features behind the new navigation menu: school approval + branded public portal, branding & head of school,
// result processing / approval queue / annual broadsheet, analytics, teacher activity, system info, data backup.
const H = require('./helpers');
const test = require('node:test');
const assert = require('node:assert/strict');

let S, aOwner, bOwner, aExam, aTeacher, aStudent, aParent, platform;
test.before(async () => {
  S = await H.setup();
  [aOwner, bOwner, aExam, aTeacher, aStudent, aParent, platform] = await Promise.all(['sa.owner', 'sb.owner', 'sa.exams', 'sa.teacher1', 'sa.student', 'sa.parent', 'abo.platform'].map((l) => H.login(S.app, l)));
});
test.after(() => H.teardown());

test('approval: verified school waits for the platform; approval e-mails the branded portal link; only ACTIVE schools are public', async () => {
  const c = H.client(S.app);
  const reg = await c.post('/api/v1/onboarding/register', { school: { name: 'Royal Gems Academy', slug: 'royal-gems', schoolType: 'secondary', motto: 'Light and Truth' }, owner: { fullName: 'Mr Tayo Bello', loginId: 'royal.owner', email: 'owner@royal-gems.example', password: 'Royal-Gems-School-2026' } });
  assert.equal(reg.status, 200);
  assert.equal((await c.get('/api/v1/public/schools/royal-gems')).status, 404, 'pending school is not public');
  let r = await c.post('/api/v1/auth/login', { loginId: 'royal.owner', password: 'Royal-Gems-School-2026' });
  assert.equal(r.status, 403); assert.match(r.body.error.message, /verification/i);
  const v = await c.post('/api/v1/auth/verify-email', { token: reg.body.devVerificationToken });
  assert.equal(v.status, 200); assert.equal(v.body.awaitingApproval, true);
  r = await c.post('/api/v1/auth/login', { loginId: 'royal.owner', password: 'Royal-Gems-School-2026' });
  assert.equal(r.status, 403); assert.match(r.body.error.message, /waiting for approval/i);
  assert.equal((await c.get('/api/v1/public/schools/royal-gems')).status, 404);
  // platform approves
  const list = await platform.get('/api/v1/platform/schools?status=pending');
  const sch = list.body.items.find((x) => x.slug === 'royal-gems'); assert.ok(sch && sch.email_verified_at);
  assert.equal((await aOwner.patch(`/api/v1/platform/schools/${sch.id}`, { status: 'active', reason: 'try' })).status, 403, 'schools cannot approve themselves');
  const ap = await platform.patch(`/api/v1/platform/schools/${sch.id}`, { status: 'active', reason: 'Documents checked' });
  assert.equal(ap.status, 200); assert.equal(ap.body.approved, true); assert.match(ap.body.portalUrl, /#\/s\/royal-gems$/);
  const db = await H.dbAs('owner');
  try {
    const mail = (await db.query("SELECT body_text FROM outbox_emails WHERE template = 'school_approved' AND to_address = 'owner@royal-gems.example'")).rows[0];
    assert.ok(mail && mail.body_text.includes('/#/s/royal-gems'), 'owner gets the portal link');
    const s = (await db.query("SELECT approved_at, approved_by FROM schools WHERE slug = 'royal-gems'")).rows[0]; assert.ok(s.approved_at && s.approved_by);
    const au = (await db.query("SELECT 1 FROM audit_logs WHERE action = 'platform.school_approved' AND resource_id = $1", [sch.id])).rowCount; assert.equal(au, 1);
  } finally { await db.end(); }
  // public profile: name/motto only — no contact data, no internal fields
  const pub = await c.get('/api/v1/public/schools/ROYAL-GEMS');
  assert.equal(pub.status, 200); assert.equal(pub.body.name, 'Royal Gems Academy'); assert.equal(pub.body.motto, 'Light and Truth'); assert.equal(pub.body.logoUrl, null);
  assert.deepEqual(Object.keys(pub.body).sort(), ['brandColor', 'id', 'logoUrl', 'motto', 'name', 'schoolType', 'slug']);
  assert.equal((await c.get('/api/v1/public/schools/no-such-school')).status, 404);
  assert.equal((await c.get('/api/v1/public/schools/..%2f..')).status, 400);
  // owner can now sign in (school-scoped login via the portal's schoolId)
  const owner = await H.login(S.app, 'royal.owner', { password: 'Royal-Gems-School-2026' });
  assert.equal((await owner.get('/api/v1/auth/me')).body.school.name, 'Royal Gems Academy');
  // suspended → disappears from the public portal again
  await platform.patch(`/api/v1/platform/schools/${sch.id}`, { status: 'suspended', reason: 'test suspension' });
  assert.equal((await c.get('/api/v1/public/schools/royal-gems')).status, 404);
});

test('branding: logo + colour appear on the public portal; head of school & signature on report cards', async () => {
  const anon = H.client(S.app);
  assert.equal((await aOwner.patch('/api/v1/school/branding', { brandColor: 'red' })).status, 400);
  assert.equal((await aTeacher.patch('/api/v1/school/branding', { brandColor: '#123456' })).status, 403);
  assert.equal((await aOwner.patch('/api/v1/school/branding', { brandColor: '#0A7D61' })).status, 200);
  const up = await aOwner.post('/api/v1/school/logo', undefined, { multipart: H.multipart({}, { name: 'logo.png', type: 'image/png', data: H.PNG_1PX }) });
  assert.equal(up.status, 200);
  const pub = await anon.get('/api/v1/public/schools/school-a');
  assert.equal(pub.body.brandColor, '#0A7D61'); assert.equal(pub.body.logoUrl, '/api/v1/public/schools/school-a/logo');
  const logo = await anon.get(pub.body.logoUrl);
  assert.equal(logo.status, 200); assert.equal(logo.headers['content-type'], 'image/png'); assert.match(logo.headers['content-security-policy'], /sandbox/);
  assert.equal((await anon.get(pub.body.logoUrl, { headers: { 'if-none-match': logo.headers.etag } })).status, 304);
  assert.equal((await anon.get('/api/v1/public/schools/school-b/logo')).status, 404, 'school without a logo');
  // head of school
  assert.equal((await aOwner.patch('/api/v1/school/head', { headEmail: 'not-an-email' })).status, 400);
  assert.equal((await aOwner.patch('/api/v1/school/head', { headPhone: '12' })).status, 400);
  const hd = await aOwner.patch('/api/v1/school/head', { headName: 'Dr (Mrs) Bisi Alade', headTitle: 'Principal', headPhone: '0800 000 0001', headEmail: 'principal@school-a.example' });
  assert.equal(hd.status, 200); assert.equal(hd.body.head_name, 'Dr (Mrs) Bisi Alade');
  assert.equal((await aTeacher.patch('/api/v1/school/head', { headName: 'Hacker' })).status, 403);
  const sig = await aOwner.post('/api/v1/school/head/signature', undefined, { multipart: H.multipart({}, { name: 'sig.png', type: 'image/png', data: H.PNG_1PX }) });
  assert.equal(sig.status, 200);
  const sch = (await aOwner.get('/api/v1/school')).body.school;
  assert.equal(sch.head_signature_file_id, sig.body.fileId); assert.match(sch.portal_url, /#\/s\/school-a$/);
  // parents can load the head's signature (printed on report cards) but not foreign files
  assert.equal((await aParent.get(`/api/v1/files/${sig.body.fileId}`)).status, 200);
  assert.equal((await bOwner.get(`/api/v1/files/${sig.body.fileId}`)).status, 404);
  const me = await aOwner.get('/api/v1/auth/me'); assert.equal(me.body.school.brand_color, '#0A7D61');
  // report template settings validated
  assert.equal((await aOwner.put('/api/v1/school/settings', { reportCard: { template: 'fancy' } })).status, 400);
  assert.equal((await aOwner.put('/api/v1/school/settings', { reportCard: { template: 'modern', showGradeKey: true, showAttendance: true } })).status, 200);
});

test('results: overview, approval queue, processing and annual broadsheet — tenant-scoped and permission-checked', async () => {
  const cls = S.A.classes[0]; const termId = S.A.termId;
  const sheets = await aExam.get(`/api/v1/results/sheets?termId=${termId}&classId=${cls.id}`);
  const subj = sheets.body.items[0];
  const sh = await aExam.post('/api/v1/results/sheets', { termId, classId: cls.id, subjectId: subj.subject_id });
  const d = await aExam.get(`/api/v1/results/sheets/${sh.body.id}`);
  const entries = d.body.rows.map((r, i) => ({ studentId: r.studentId, scores: { ca1: 10 + i, ca2: 12, exam: 30 + i * 3 } }));
  assert.equal((await aExam.put(`/api/v1/results/sheets/${sh.body.id}/scores`, { entries, expectedVersion: d.body.sheet.version })).status, 200);
  // CA-only save leaves the exam column untouched (CA / Exam entry pages)
  const d2 = await aExam.get(`/api/v1/results/sheets/${sh.body.id}`);
  await aExam.put(`/api/v1/results/sheets/${sh.body.id}/scores`, { entries: [{ studentId: d2.body.rows[0].studentId, scores: { ca1: 19 } }], expectedVersion: d2.body.sheet.version });
  const d3 = await aExam.get(`/api/v1/results/sheets/${sh.body.id}`);
  assert.equal(Number(d3.body.rows[0].scores.ca1), 19); assert.equal(Number(d3.body.rows[0].scores.exam), 30);
  assert.equal((await aExam.post(`/api/v1/results/sheets/${sh.body.id}/submit`)).status, 200);

  const ov = await aExam.get(`/api/v1/results/overview?termId=${termId}`);
  assert.equal(ov.status, 200);
  const row = ov.body.items.find((x) => x.id === cls.id); assert.equal(row.submitted, 1); assert.ok(row.students > 0); assert.equal(row.ready_to_publish, false);
  assert.ok(ov.body.items.every((x) => S.B.classes.every((b) => b.id !== x.id)), 'no foreign classes');
  const q = await aOwner.get(`/api/v1/results/queue?termId=${termId}`);
  assert.equal(q.status, 200); const item = q.body.items.find((x) => x.id === sh.body.id);
  assert.ok(item); assert.equal(item.submitted_by_name.length > 0, true);
  const qMine = await aExam.get(`/api/v1/results/queue?termId=${termId}`);
  assert.equal(qMine.body.items.find((x) => x.id === sh.body.id).can_approve, false, 'four-eyes: submitter cannot act');
  assert.equal((await aTeacher.get(`/api/v1/results/queue?termId=${termId}`)).status, 403);
  assert.equal((await bOwner.get(`/api/v1/results/queue?termId=${termId}`)).status, 404, 'foreign term');
  // processing
  const pr = await aExam.post('/api/v1/results/process', { termId, classId: cls.id });
  assert.equal(pr.status, 200); assert.ok(pr.body.items[0].withResults > 0);
  assert.equal((await aTeacher.post('/api/v1/results/process', { termId })).status, 403);
  assert.equal((await bOwner.post('/api/v1/results/process', { termId: S.B.termId, classId: cls.id })).status, 404);
  // annual broadsheet
  const an = await aExam.get(`/api/v1/results/annual?classId=${cls.id}`);
  assert.equal(an.status, 200); assert.equal(an.body.terms.length, 3); assert.equal(an.body.subjects.length, 1); assert.equal(an.body.provisional, true);
  const top = an.body.rows[0]; assert.equal(top.position, 1); assert.ok(top.annualAverage > 0); assert.ok(['Pass', 'Fail'].includes(top.status));
  assert.equal((await bOwner.get(`/api/v1/results/annual?classId=${cls.id}`)).status, 404);
  assert.equal((await aStudent.get(`/api/v1/results/annual?classId=${cls.id}`)).status, 403);
});

test('analytics: class/subject/grade/gender stats, student trend, teacher activity — scoped and permission-checked', async () => {
  const termId = S.A.termId;
  const a = await aOwner.get(`/api/v1/results/analytics?termId=${termId}&scope=all`);
  assert.equal(a.status, 200); assert.ok(a.body.totals.students > 0); assert.ok(a.body.bySubject.length >= 1); assert.ok(a.body.grades.length >= 1); assert.ok(a.body.top.length >= 1);
  assert.ok(a.body.byClass.every((x) => x.pass_rate >= 0 && x.pass_rate <= 100));
  const approvedOnly = await aOwner.get(`/api/v1/results/analytics?termId=${termId}`);
  assert.equal(approvedOnly.body.totals.students, 0, 'default scope counts only approved/published results');
  assert.equal((await aStudent.get(`/api/v1/results/analytics?termId=${termId}`)).status, 403);
  assert.equal((await bOwner.get(`/api/v1/results/analytics?termId=${termId}`)).status, 404);
  const sid = a.body.top[0].id;
  const st = await aOwner.get(`/api/v1/results/analytics/student/${sid}`);
  assert.equal(st.status, 200); assert.equal(st.body.terms.length, 1); assert.ok(st.body.subjects.length >= 1);
  assert.equal((await bOwner.get(`/api/v1/results/analytics/student/${sid}`)).status, 404, 'foreign student');
  assert.equal((await aParent.get(`/api/v1/results/analytics/student/${sid}`)).status, 403);
  const ta = await aOwner.get(`/api/v1/teachers/activity?termId=${termId}`);
  assert.equal(ta.status, 200); assert.ok(ta.body.items.length >= 2);
  assert.ok(ta.body.items.every((x) => typeof x.sheets_started === 'number' && typeof x.scores_entered === 'number'));
  assert.equal((await aStudent.get('/api/v1/teachers/activity')).status, 403);
});

test('system info, support contacts and the school data backup workbook', async () => {
  const si = await aOwner.get('/api/v1/system/info');
  assert.equal(si.status, 200); assert.equal(si.body.app.api, 'v1'); assert.ok(si.body.usage.students > 0); assert.match(si.body.school.portal_url, /#\/s\/school-a$/);
  assert.ok(!JSON.stringify(si.body).match(/postgres|password|secret|node_modules/i), 'no internals');
  assert.equal((await aTeacher.get('/api/v1/system/info')).status, 403);
  assert.equal((await aStudent.get('/api/v1/system/support')).status, 200);
  assert.equal((await aTeacher.post('/api/v1/school/backup')).status, 403);
  const j = await aOwner.post('/api/v1/school/backup'); assert.equal(j.status, 200); assert.ok(j.body.jobId);
  const w = require('../src/jobs/worker'); while (await w.runOne());
  const job = await aOwner.get(`/api/v1/jobs/${j.body.jobId}`);
  assert.equal(job.body.status, 'done', JSON.stringify(job.body)); assert.ok(job.body.result.datasets.students > 0); assert.ok('results' in job.body.result.datasets);
  const f = await aOwner.get(`/api/v1/files/${job.body.result.fileId}`);
  assert.equal(f.status, 200); assert.match(f.headers['content-disposition'], /backup/);
  const ExcelJS = require('exceljs'); const wb = new ExcelJS.Workbook(); await wb.xlsx.load(f.raw.rawPayload);
  const names = wb.worksheets.map((x) => x.name); assert.ok(names.includes('README') && names.includes('students') && names.includes('classes'));
  assert.equal((await bOwner.get(`/api/v1/files/${job.body.result.fileId}`)).status, 404);
  assert.equal((await aExam.get(`/api/v1/files/${job.body.result.fileId}`)).status, 404, 'only the requester can download');
});

test('every export dataset works in CSV and Excel (regression: payments export referenced a dropped column)', async () => {
  const { DATASETS } = require('../src/routes/data');
  for (const ds of Object.keys(DATASETS)) {
    for (const format of ['csv', 'xlsx']) {
      const r = await aOwner.get(`/api/v1/exports/${ds}?format=${format}&termId=${S.A.termId}`);
      assert.equal(r.status, 200, `${ds}.${format} → ${r.status} ${r.raw.body.slice(0, 200)}`);
    }
  }
});
