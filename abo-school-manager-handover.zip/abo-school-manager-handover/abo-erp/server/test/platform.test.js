'use strict';
// Memberships, branch isolation, token-reuse detection, idempotency, concurrency, allocations, CORS,
// automatic security-event detection, OpenAPI, legacy account import, teacher assignments.
const H = require('./helpers');
const test = require('node:test');
const assert = require('node:assert/strict');

let S, aOwner, bOwner, aBursar, aAccounts, aTeacher2, aExam, aStudent, annex;
test.before(async () => {
  S = await H.setup();
  [aOwner, bOwner, aBursar, aAccounts, aTeacher2, aExam, aStudent, annex] = await Promise.all(['sa.owner', 'sb.owner', 'sa.bursar', 'sa.accounts', 'sa.teacher2', 'sa.exams', 'sa.student', 'sa.annex'].map((l) => H.login(S.app, l)));
});
test.after(() => H.teardown());
const events = async (kind) => { const db = await H.dbAs('owner'); try { return (await db.query('SELECT * FROM security_events WHERE kind = $1', [kind])).rows; } finally { await db.end(); } };

test('memberships: invite an existing account into a second school, accept, switch; identity protected across schools', async () => {
  const inv = await bOwner.post('/api/v1/users/invite', { login: 'sa.teacher2', roleKeys: ['teacher'] });
  assert.equal(inv.status, 200); assert.equal(inv.body.status, 'invited');
  assert.equal((await bOwner.post('/api/v1/users/invite', { login: 'sa.teacher2', roleKeys: ['teacher'] })).status, 409);
  assert.equal((await bOwner.post('/api/v1/users/invite', { login: 'nobody.at.all', roleKeys: ['teacher'] })).status, 404);
  const ms = await aTeacher2.get('/api/v1/auth/memberships');
  const invite = ms.body.items.find((m) => m.status === 'invited'); assert.ok(invite);
  assert.equal((await aTeacher2.post('/api/v1/auth/switch-school', { schoolId: S.B.schoolId })).status, 404, 'cannot switch before accepting');
  assert.equal((await aTeacher2.post(`/api/v1/auth/memberships/${invite.id}/respond`, { accept: true })).status, 200);
  const sw = await aTeacher2.post('/api/v1/auth/switch-school', { schoolId: S.B.schoolId }); assert.equal(sw.status, 200);
  const me = await aTeacher2.get('/api/v1/auth/me');
  assert.equal(me.body.school.id, S.B.schoolId); assert.deepEqual(me.body.roles.map((r) => r.key), ['teacher']);
  const list = await aTeacher2.get('/api/v1/students?pageSize=100');
  assert.ok(list.body.items.every((s) => s.admission_no.startsWith('SB/')), 'now sees ONLY school B data');
  // identity-level operations are refused to either school now that the identity is shared
  const uidB = (await bOwner.get('/api/v1/users?q=sa.teacher2')).body.items[0].id;
  assert.equal((await bOwner.post(`/api/v1/users/${uidB}/access-code`, {})).status, 403);
  assert.equal((await aOwner.post(`/api/v1/users/${uidB}/access-code`, {})).status, 403);
  assert.equal((await aOwner.patch(`/api/v1/users/${uidB}`, { fullName: 'Renamed By A' })).status, 403);
  // school B suspends ITS membership: B session revoked, school A sign-in still works
  assert.equal((await bOwner.post(`/api/v1/users/${uidB}/status`, { status: 'disabled', reason: 'contract ended' })).status, 200);
  assert.equal((await aTeacher2.get('/api/v1/auth/me')).status, 401);
  const again = await H.login(S.app, 'sa.teacher2'); assert.equal((await again.get('/api/v1/auth/me')).body.school.id, S.A.schoolId);
  const sel = await H.client(S.app).post('/api/v1/auth/login', { loginId: 'sa.teacher2', password: H.PASSWORD, schoolId: S.B.schoolId });
  assert.equal(sel.status, 403, 'suspended membership cannot be selected');
});

test('login accepts email as well as Login ID; users carry first/middle/last names', async () => {
  const c = H.client(S.app);
  assert.equal((await c.post('/api/v1/auth/login', { loginId: 'parent@school-a.example', password: H.PASSWORD })).status, 200);
  const u = await aOwner.post('/api/v1/users', { firstName: 'Adaeze', middleName: 'Ngozi', lastName: 'Okoro', loginId: 'sa.adaeze', roleKeys: ['teacher'] });
  assert.equal(u.status, 200); assert.equal(u.body.user.full_name, 'Adaeze Ngozi Okoro');
  const row = (await aOwner.get('/api/v1/users?q=sa.adaeze')).body.items[0];
  assert.deepEqual([row.first_name, row.middle_name, row.last_name], ['Adaeze', 'Ngozi', 'Okoro']);
  assert.equal((await aOwner.post('/api/v1/users', { firstName: 'Dup', lastName: 'Mail', loginId: 'sa.dupmail', email: 'parent@school-a.example', roleKeys: ['teacher'] })).status, 409, 'emails are globally unique');
});

test('branch isolation: a branch-restricted member sees only their branch (API + RLS)', async () => {
  const me = await annex.get('/api/v1/auth/me'); assert.equal(me.body.branch.name, 'Annex');
  const mine = await annex.get('/api/v1/students?pageSize=100');
  assert.ok(mine.body.total > 0); assert.ok(mine.body.items.every((s) => s.class_name === 'JSS 1A'));
  const all = await aOwner.get('/api/v1/students?pageSize=100');
  const mainStudent = all.body.items.find((s) => s.class_name === 'BASIC 1A');
  assert.equal((await annex.get(`/api/v1/students/${mainStudent.id}`)).status, 404);
  const basic = S.A.classes.find((c) => c.display_name === 'BASIC 1A');
  assert.equal((await annex.get(`/api/v1/attendance/class/${basic.id}`)).status, 404);
  assert.equal((await annex.get(`/api/v1/results/broadsheet?termId=${S.A.termId}&classId=${basic.id}`)).status, 404);
  const ac = await annex.get('/api/v1/academic'); assert.deepEqual(ac.body.classes.map((c) => c.display_name), ['JSS 1A']);
  const created = await annex.post('/api/v1/students', { admissionNo: 'ANX/9', firstName: 'Annex', lastName: 'Pupil', gender: 'Male' });
  assert.equal(created.status, 200);
  const db = await H.dbAs('app');
  try {
    await db.query('BEGIN');
    await db.query("SELECT set_config('app.school_id', $1, true), set_config('app.branch_id', $2, true)", [S.A.schoolId, S.A.ids.branches.annex]);
    const b = (await db.query('SELECT DISTINCT branch_id FROM students')).rows.map((r) => r.branch_id);
    assert.deepEqual(b, [S.A.ids.branches.annex], 'database returns only the Annex branch');
    assert.equal((await db.query('SELECT count(*)::int AS n FROM invoices i JOIN students s ON s.id = i.student_id WHERE s.branch_id <> $1', [S.A.ids.branches.annex])).rows[0].n, 0);
    await db.query('ROLLBACK');
  } finally { await db.end(); }
});

test('refresh-token reuse detection: replaying a rotated-out token revokes the whole session + high event', async () => {
  const c = await H.login(S.app, 'sa.teacher1');
  const [name, oldTok] = [...c.jar][0];
  const db = await H.dbAs('owner');
  try {
    await db.query("UPDATE sessions SET rotated_at = now() - interval '1 hour' WHERE user_id = (SELECT id FROM users WHERE login_id = 'sa.teacher1') AND revoked_at IS NULL");
    assert.equal((await c.get('/api/v1/auth/me')).status, 200); assert.notEqual(c.jar.get(name), oldTok, 'rotated');
    await db.query("UPDATE sessions SET prev_valid_until = now() - interval '1 second' WHERE prev_token_hash IS NOT NULL AND revoked_at IS NULL");
  } finally { await db.end(); }
  const replay = await S.app.inject({ method: 'GET', url: '/api/v1/auth/me', headers: { cookie: `${name}=${oldTok}` } });
  assert.equal(replay.statusCode, 401);
  assert.equal((await c.get('/api/v1/auth/me')).status, 401, 'the legitimate (new) token is revoked too');
  assert.ok((await events('session_token_reuse')).length >= 1);
});

let invA, invB, sibA, sibB;
test('payments: Idempotency-Key prevents duplicates (sequential, concurrent) and rejects key reuse', async () => {
  await aBursar.post('/api/v1/fees/invoices/generate', { termId: S.A.termId });
  const pme = await (await H.login(S.app, 'sa.parent')).get('/api/v1/auth/me');
  [sibA, sibB] = pme.body.children.map((k) => k.id);
  const inv = (await aBursar.get('/api/v1/fees/invoices?pageSize=100')).body.items;
  invA = inv.find((i) => i.student_id === sibA); invB = inv.find((i) => i.student_id === sibB);
  const body = { invoiceId: invA.id, amountKobo: 100000, method: 'cash' };
  const h = { headers: { 'idempotency-key': 'pay-test-0001' } };
  const r1 = await aAccounts.post('/api/v1/fees/payments', body, h); const r2 = await aAccounts.post('/api/v1/fees/payments', body, h);
  assert.equal(r1.status, 200); assert.equal(r2.status, 200); assert.equal(r2.headers['idempotent-replayed'], 'true');
  assert.equal(r1.body.receipt_no, r2.body.receipt_no, 'same receipt returned');
  assert.equal((await aAccounts.post('/api/v1/fees/payments', { ...body, amountKobo: 200000 }, h)).status, 422, 'key reuse with a different body');
  const k = { headers: { 'idempotency-key': 'pay-test-concurrent-02' } };
  const both = await Promise.all([aAccounts.post('/api/v1/fees/payments', body, k), aAccounts.post('/api/v1/fees/payments', body, k)]);
  assert.deepEqual(both.map((x) => x.status), [200, 200]); assert.equal(both[0].body.id, both[1].body.id, 'concurrent duplicates collapse to one payment');
  const paid = (await aBursar.get(`/api/v1/fees/invoices/${invA.id}`)).body;
  assert.equal(paid.payments.length, 2); assert.equal(Number(paid.invoice.paid_kobo), 200000);
});

test('concurrency: parallel payments can never over-pay an invoice (row locks + CHECK constraint)', async () => {
  const cur = (await aBursar.get(`/api/v1/fees/invoices/${invA.id}`)).body.invoice;
  const bal = Number(cur.total_kobo) - Number(cur.paid_kobo);
  const half = Math.floor(bal / 2) + 1;                                 // two of these together exceed the balance
  const res = await Promise.all([aAccounts.post('/api/v1/fees/payments', { invoiceId: invA.id, amountKobo: half, method: 'transfer' }), aAccounts.post('/api/v1/fees/payments', { invoiceId: invA.id, amountKobo: half, method: 'transfer' })]);
  assert.deepEqual(res.map((r) => r.status).sort(), [200, 400]);
  const after = (await aBursar.get(`/api/v1/fees/invoices/${invA.id}`)).body.invoice;
  assert.ok(Number(after.paid_kobo) <= Number(after.total_kobo));
});

test('payment allocations: one payment across two siblings\' invoices, one receipt; sums must match', async () => {
  const bB = (await aBursar.get(`/api/v1/fees/invoices/${invB.id}`)).body.invoice;
  const mism = await aAccounts.post('/api/v1/fees/payments', { amountKobo: 300000, method: 'transfer', allocations: [{ invoiceId: invB.id, amountKobo: 100000 }] });
  assert.equal(mism.status, 400);
  const curA = (await aBursar.get(`/api/v1/fees/invoices/${invA.id}`)).body.invoice;
  const leftA = Number(curA.total_kobo) - Number(curA.paid_kobo);
  const p = await aAccounts.post('/api/v1/fees/payments', { amountKobo: leftA + 50000, method: 'transfer', reference: 'FAM-TRF-1', allocations: [{ invoiceId: invA.id, amountKobo: leftA }, { invoiceId: invB.id, amountKobo: 50000 }] });
  assert.equal(p.status, 200, JSON.stringify(p.body)); assert.equal(p.body.allocations.length, 2); assert.match(p.body.receipt_no, /^RCT-/);
  assert.equal((await aBursar.get(`/api/v1/fees/invoices/${invA.id}`)).body.invoice.status, 'paid');
  assert.equal(Number((await aBursar.get(`/api/v1/fees/invoices/${invB.id}`)).body.invoice.paid_kobo), Number(bB.paid_kobo) + 50000);
  const parent = await H.login(S.app, 'sa.parent');
  const rc = await parent.get(`/api/v1/fees/receipts/${p.body.id}`); assert.equal(rc.status, 200); assert.equal(rc.body.allocations.length, 2);
  // auto-allocation by learner, and no over-payment
  const auto = await aAccounts.post('/api/v1/fees/payments', { studentId: sibB, amountKobo: 10000000000, method: 'cash' });
  assert.equal(auto.status, 400); assert.match(auto.body.error.message, /exceeds/);
});

test('student-specific charges recompute totals on the server; removal cannot leave an invoice over-paid', async () => {
  const before = (await aBursar.get(`/api/v1/fees/invoices/${invB.id}`)).body.invoice;
  const ch = await aBursar.post(`/api/v1/fees/invoices/${invB.id}/items`, { description: 'Excursion to Olumo Rock', amountKobo: 750000 });
  assert.equal(ch.status, 200);
  const after = (await aBursar.get(`/api/v1/fees/invoices/${invB.id}`)).body;
  assert.equal(Number(after.invoice.total_kobo), Number(before.total_kobo) + 750000); assert.ok(after.items.some((i) => i.kind === 'student_charge'));
  assert.equal((await aBursar.del(`/api/v1/fees/invoice-items/${ch.body.id}`, { reason: 'Parent opted out' })).status, 200);
  assert.equal(Number((await aBursar.get(`/api/v1/fees/invoices/${invB.id}`)).body.invoice.total_kobo), Number(before.total_kobo));
});

test('concurrency: simultaneous score saves with the same version → one wins, one gets 409', async () => {
  const cls = S.A.classes.find((c) => c.display_name === 'BASIC 1A');
  const subs = (await aOwner.get(`/api/v1/academic/classes/${cls.id}/subjects`)).body.items;
  const sh = await aExam.post('/api/v1/results/sheets', { termId: S.A.termId, classId: cls.id, subjectId: subs.find((s) => !s.subject.startsWith('X')).subject_id });
  const d = await aExam.get(`/api/v1/results/sheets/${sh.body.id}`);
  if (d.body.sheet.status !== 'draft') return;                       // seeded demo results may already be published for this class
  const v = d.body.sheet.version; const sid = d.body.rows[0].studentId;
  const res = await Promise.all([aExam.put(`/api/v1/results/sheets/${sh.body.id}/scores`, { entries: [{ studentId: sid, scores: { ca1: 10 } }], expectedVersion: v }),
    aExam.put(`/api/v1/results/sheets/${sh.body.id}/scores`, { entries: [{ studentId: sid, scores: { ca1: 15 } }], expectedVersion: v })]);
  assert.deepEqual(res.map((r) => r.status).sort(), [200, 409]);
});

test('concurrency: double CBT submission → exactly one grading; cbt_results row written', async () => {
  const cls = S.A.classes.find((c) => c.display_name === 'BASIC 1A');
  const e = await aOwner.post('/api/v1/cbt/exams', { title: 'Race quiz', durationMinutes: 10, classId: cls.id });
  await aOwner.post(`/api/v1/cbt/exams/${e.body.id}/questions`, { type: 'true_false', text: 'Abuja is the capital', correct: true });
  await aOwner.post(`/api/v1/cbt/exams/${e.body.id}/publish`, {});
  const p = await aStudent.post(`/api/v1/cbt/exams/${e.body.id}/start`, {});
  const q = p.body.questions[0];
  await aStudent.put(`/api/v1/cbt/attempts/${p.body.attemptId}/answers`, { answers: [{ questionId: q.id, optionId: q.options.find((o) => o.text === 'True').id }] });
  const res = await Promise.all([aStudent.post(`/api/v1/cbt/attempts/${p.body.attemptId}/submit`, {}), aStudent.post(`/api/v1/cbt/attempts/${p.body.attemptId}/submit`, {})]);
  assert.deepEqual(res.map((r) => r.status).sort(), [200, 409]);
  const db = await H.dbAs('owner');
  try {
    const r = (await db.query('SELECT score, max_score, passed FROM cbt_results WHERE attempt_id = $1', [p.body.attemptId])).rows;
    assert.equal(r.length, 1); assert.equal(Number(r[0].score), 1); assert.equal(r[0].passed, true);
  } finally { await db.end(); }
});

test('CORS: only trusted origins are reflected (never *), with credentials', async () => {
  const ok = await S.app.inject({ method: 'OPTIONS', url: '/api/v1/auth/login', headers: { origin: 'http://localhost:8080', 'access-control-request-method': 'POST' } });
  assert.equal(ok.headers['access-control-allow-origin'], 'http://localhost:8080'); assert.equal(ok.headers['access-control-allow-credentials'], 'true');
  const bad = await S.app.inject({ method: 'OPTIONS', url: '/api/v1/auth/login', headers: { origin: 'https://evil.example', 'access-control-request-method': 'POST' } });
  assert.equal(bad.headers['access-control-allow-origin'], undefined);
  const get = await S.app.inject({ method: 'GET', url: '/api/v1/auth/me', headers: { origin: 'https://evil.example' } });
  assert.notEqual(get.headers['access-control-allow-origin'], '*'); assert.equal(get.headers['access-control-allow-origin'], undefined);
});

test('security events are raised automatically: cross-tenant probe, privilege escalation, repeated denials', async () => {
  const bStudent = (await bOwner.get('/api/v1/students?pageSize=1')).body.items[0].id;
  assert.equal((await aOwner.get(`/api/v1/students/${bStudent}`)).status, 404);
  await new Promise((r) => setTimeout(r, 150));
  const xt = await events('cross_tenant_access_attempt');
  assert.ok(xt.some((e) => e.detail.resourceId === bStudent && e.school_id === S.A.schoolId));
  const t = await H.login(S.app, 'sa.teacher1');
  for (let i = 0; i < 11; i++) await t.post('/api/v1/users', { fullName: 'Nope Nope', loginId: `nope.${i}`, roleKeys: ['teacher'] });
  await new Promise((r) => setTimeout(r, 150));
  assert.ok((await events('privilege_escalation_attempt')).length >= 1);
  assert.ok((await events('repeated_authorization_failures')).length >= 1);
});

test('DTO guard blocks secret-bearing fields; API responses never contain hashes or storage keys', async () => {
  const { leaks } = require('../src/lib/dto');
  assert.equal(leaks('{"id":1,"password_hash":"$argon2id$..."}'), true); assert.equal(leaks('{"storage_key":"x"}'), true); assert.equal(leaks('{"id":1,"name":"ok"}'), false);
  for (const url of ['/api/v1/users?pageSize=100', '/api/v1/auth/me', '/api/v1/documents', '/api/v1/auth/sessions', '/api/v1/students?pageSize=100']) {
    const r = await aOwner.get(url); assert.equal(r.status, 200, url); assert.equal(leaks(r.raw.body), false, url);
  }
});

test('OpenAPI 3.1 document is generated from the live validation schemas', async () => {
  const r = await S.app.inject({ method: 'GET', url: '/api/v1/openapi.json' });
  assert.equal(r.statusCode, 200); const d = r.json();
  assert.equal(d.openapi, '3.1.0'); assert.ok(Object.keys(d.paths).length >= 120);
  const op = d.paths['/students/{id}'].patch;
  assert.deepEqual(op['x-permissions'], ['students.update']); assert.equal(op.requestBody.content['application/json'].schema.additionalProperties, false);
  assert.ok(d.components.securitySchemes.cookieAuth && d.components.securitySchemes.csrfToken);
  assert.ok(d.paths['/students'].get.parameters.some((p) => p.name === 'pageSize' && p.schema.maximum === 100));
});

test('legacy import: accounts become PENDING with one-time access codes; audit history flagged unverified', async () => {
  const legacy = { subjects: ['Mathematics'], globalSettings: { session: '2025/2026', term: '1ST', className: 'PRIMARY 6A' }, students: [{ name: 'Legacy Kid', gender: 'Male', attendanceNo: 'LG/77', subjects: [] }],
    userAccounts: { admins: [{ loginId: 'legacy.admin', name: 'Legacy Admin' }], teachers: [{ loginId: 'legacy.teach', name: 'Legacy Teacher' }], students: [{ loginId: 'bad id!', name: 'x' }, { loginId: 'legacy.kid', name: 'Legacy Kid', admissionNo: 'LG/77' }],
      audit: [{ time: '2025-10-01T08:00:00Z', actor: 'Old Admin', role: 'admin', action: 'Edited scores' }] } };
  const pv = await aOwner.post('/api/v1/migration/legacy/preview', undefined, { multipart: H.multipart({}, { name: 'b.json', data: JSON.stringify(legacy) }) });
  assert.equal(pv.status, 200); assert.equal(pv.body.counts.accounts, 3, 'invalid login id filtered'); assert.equal(pv.body.counts.auditEntries, 1);
  const cm = await aOwner.post(`/api/v1/migration/legacy/${pv.body.importId}/commit`, { importAccounts: true, importAudit: true });
  assert.equal(cm.status, 200, 'COMMIT ' + JSON.stringify(cm.body)); assert.equal(cm.body.accounts, 3); assert.equal(cm.body.accessSlips.length, 3);
  const c = H.client(S.app);
  assert.equal((await c.post('/api/v1/auth/login', { loginId: 'legacy.kid', password: 'anything-at-all' })).status, 401, 'no password-less accounts');
  const slip = cm.body.accessSlips.find((s) => s.loginId === 'legacy.kid');
  assert.equal((await c.post('/api/v1/auth/activate', { loginId: 'legacy.kid', accessCode: slip.accessCode, newPassword: 'Blue-Mango-2026' })).status, 200);
  const me = await H.login(S.app, 'legacy.kid', { password: 'Blue-Mango-2026' });
  assert.equal((await me.get('/api/v1/auth/me')).body.portal, 'student');
  const au = await aOwner.get('/api/v1/audit?action=legacy'); assert.equal(au.body.items[0].metadata.unverified, true);
  assert.equal((await aOwner.get('/api/v1/audit/verify')).body.ok, true, 'hash chain intact after import');
});

test('teacher assignments grant (and revoke) access to a class subject; attendance sessions record remarks', async () => {
  const cls = S.A.classes.find((c) => c.display_name === 'BASIC 1B');
  const subs = (await aOwner.get(`/api/v1/academic/classes/${cls.id}/subjects`)).body.items;
  const target = subs.find((s) => s.teacher === 'Mr Tunde Bello');            // not teacher2's subject
  const t2 = await H.login(S.app, 'sa.teacher2');
  assert.equal((await t2.post('/api/v1/results/sheets', { termId: S.A.termId, classId: cls.id, subjectId: target.subject_id })).status, 403);
  const teachers = (await aOwner.get('/api/v1/teachers?pageSize=100')).body.items;
  const okeke = teachers.find((t) => t.full_name === 'Mrs Ngozi Okeke');
  assert.equal((await aOwner.patch(`/api/v1/teachers/${okeke.id}`, { trcnNumber: 'TRCN/2019/000123', qualification: 'B.Ed Mathematics' })).status, 200);
  const as = await aOwner.post(`/api/v1/teachers/${okeke.id}/assignments`, { classId: cls.id, subjectId: target.subject_id, role: 'assistant' });
  assert.equal(as.status, 200);
  assert.equal((await t2.post('/api/v1/results/sheets', { termId: S.A.termId, classId: cls.id, subjectId: target.subject_id })).status, 200, 'assignment grants access');
  assert.equal((await aOwner.del(`/api/v1/teachers/assignments/${as.body.id}`)).status, 200);
  assert.equal((await t2.post('/api/v1/results/sheets', { termId: S.A.termId, classId: cls.id, subjectId: target.subject_id })).status, 403, 'revocation is immediate');
  // attendance session
  const t1 = await H.login(S.app, 'sa.teacher1');
  const basic = S.A.classes.find((c) => c.display_name === 'BASIC 1A');
  const roster = (await t1.get(`/api/v1/attendance/class/${basic.id}`)).body.items;
  const day = new Date().toISOString().slice(0, 10);
  const r = await t1.put(`/api/v1/attendance/class/${basic.id}`, { date: day, remarks: 'Rainy morning', entries: roster.map((x) => ({ studentId: x.student_id, status: 'present' })) });
  assert.equal(r.status, 200); assert.ok(r.body.sessionId);
  const again = await t1.put(`/api/v1/attendance/class/${basic.id}`, { date: day, entries: roster.map((x) => ({ studentId: x.student_id, status: 'present' })) });
  assert.equal(again.body.sessionId, r.body.sessionId, 'one register per class per day');
  assert.equal((await t1.get(`/api/v1/attendance/class/${basic.id}?date=${day}`)).body.session.remarks, 'Rainy morning');
});

test('ops script create-platform-admin: creates a forced-change platform admin; rejects bad input and duplicates', async () => {
  const { createPlatformAdmin } = require('../../scripts/create-platform-admin');
  const pw = require('../src/security/passwords');
  await assert.rejects(createPlatformAdmin({ login: 'ops.admin' }), /required/);
  await assert.rejects(createPlatformAdmin({ login: 'bad login!', email: 'ops@example.com' }), /PLATFORM_ADMIN_LOGIN/);
  await assert.rejects(createPlatformAdmin({ login: 'ops.admin', email: 'not-an-email' }), /valid email/);
  const made = await createPlatformAdmin({ login: 'ops.admin', email: 'ops-admin@example.com' });
  assert.ok(made.password.length >= 20);
  const db = await H.dbAs('owner');
  try {
    const u = (await db.query('SELECT * FROM users WHERE login_id = $1', ['ops.admin'])).rows[0];
    assert.equal(u.is_platform_admin, true); assert.equal(u.must_change_password, true); assert.equal(u.school_id, null);
    assert.ok(await pw.verify(u.password_hash, made.password), 'printed one-time password matches the stored Argon2id hash');
  } finally { await db.end(); }
  await assert.rejects(createPlatformAdmin({ login: 'ops.admin', email: 'other@example.com' }), /already exists/);
});
