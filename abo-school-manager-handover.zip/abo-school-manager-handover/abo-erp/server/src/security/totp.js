'use strict';
// RFC 6238 TOTP (HMAC-SHA1, 30 s, 6 digits) with ±1 step drift and replay protection (caller stores last step).
const crypto = require('node:crypto');
const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
function b32encode(buf) {
  let bits = 0, val = 0, out = '';
  for (const b of buf) { val = (val << 8) | b; bits += 8; while (bits >= 5) { out += B32[(val >>> (bits - 5)) & 31]; bits -= 5; } }
  if (bits > 0) out += B32[(val << (5 - bits)) & 31];
  return out;
}
function b32decode(s) {
  const clean = String(s).toUpperCase().replace(/[^A-Z2-7]/g, '');
  let bits = 0, val = 0; const out = [];
  for (const ch of clean) { val = (val << 5) | B32.indexOf(ch); bits += 5; if (bits >= 8) { out.push((val >>> (bits - 8)) & 255); bits -= 8; } }
  return Buffer.from(out);
}
const generateSecret = () => b32encode(crypto.randomBytes(20));
function hotp(secretB32, counter, digits = 6, algo = 'sha1') {
  const buf = Buffer.alloc(8); buf.writeBigUInt64BE(BigInt(counter));
  const h = crypto.createHmac(algo, b32decode(secretB32)).update(buf).digest();
  const o = h[h.length - 1] & 15;
  const code = ((h[o] & 127) << 24) | (h[o + 1] << 16) | (h[o + 2] << 8) | h[o + 3];
  return String(code % 10 ** digits).padStart(digits, '0');
}
const stepAt = (ms = Date.now()) => Math.floor(ms / 1000 / 30);
// returns the matched step (number) or null. Rejects steps <= lastStep (replay).
function verify(secretB32, code, { lastStep = null, window = 1, now = Date.now() } = {}) {
  if (!/^\d{6}$/.test(String(code || ''))) return null;
  const cur = stepAt(now);
  for (let w = -window; w <= window; w++) {
    const s = cur + w;
    if (lastStep !== null && s <= lastStep) continue;
    const a = Buffer.from(hotp(secretB32, s)); const b = Buffer.from(String(code));
    if (crypto.timingSafeEqual(a, b)) return s;
  }
  return null;
}
const otpauthUri = (secret, account, issuer) =>
  `otpauth://totp/${encodeURIComponent(issuer)}:${encodeURIComponent(account)}?secret=${secret}&issuer=${encodeURIComponent(issuer)}&algorithm=SHA1&digits=6&period=30`;
module.exports = { generateSecret, hotp, verify, stepAt, otpauthUri, b32encode, b32decode };
