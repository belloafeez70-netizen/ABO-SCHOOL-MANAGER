'use strict';
// Argon2id password hashing (OWASP parameters, configurable) + password policy.
const argon2 = require('argon2');
const config = require('../config');

const OPTS = { type: argon2.argon2id, memoryCost: config.argon2.memoryCost, timeCost: config.argon2.timeCost, parallelism: config.argon2.parallelism };
const hash = (pw) => argon2.hash(pw, OPTS);
async function verify(hashStr, pw) {
  if (!hashStr) return false;
  try { return await argon2.verify(hashStr, pw); } catch { return false; }
}
const needsRehash = (hashStr) => { try { return argon2.needsRehash(hashStr, OPTS); } catch { return true; } };

// Dummy hash used when the login ID does not exist so response time does not reveal account existence.
let dummy; const dummyHash = async () => (dummy ||= await hash('dummy-password-for-timing-equalisation'));

// Small embedded block-list of the most common passwords (NIST 800-63B §5.1.1.2 “known compromised”).
const COMMON = new Set(`password password1 password123 123456 12345678 123456789 1234567890 qwerty qwerty123 abc123
111111 000000 iloveyou admin admin123 welcome welcome1 letmein monkey dragon football baseball sunshine princess
passw0rd master trustno1 school school123 teacher student nigeria nigeria123 lagos123 abuja123 jesus123 god123
changeme secret 1q2w3e4r zaq12wsx asdfghjkl qwertyuiop p@ssw0rd p@ssword superman batman 987654321`.split(/\s+/));

function checkPolicy(pw, { loginId = '', fullName = '', staff = true } = {}) {
  const errs = [];
  const min = staff ? 10 : 8;
  if (typeof pw !== 'string' || pw.length < min) errs.push(`Use at least ${min} characters.`);
  if (typeof pw === 'string' && pw.length > 128) errs.push('Use at most 128 characters.');
  const low = String(pw || '').toLowerCase();
  if (COMMON.has(low) || COMMON.has(low.replace(/[0-9!@#$%]+$/, ''))) errs.push('This password is too common.');
  if (loginId && low.includes(String(loginId).toLowerCase())) errs.push('Do not include your Login ID in the password.');
  const first = String(fullName || '').split(/\s+/)[0];
  if (first && first.length >= 4 && low.includes(first.toLowerCase())) errs.push('Do not include your name in the password.');
  if (/^(.)\1+$/.test(String(pw || ''))) errs.push('Do not repeat a single character.');
  const classes = [/[a-z]/, /[A-Z]/, /[0-9]/, /[^A-Za-z0-9]/].filter((r) => r.test(pw || '')).length;
  if (staff && classes < 3 && String(pw || '').length < 16) errs.push('Mix at least three of: lowercase, uppercase, digits, symbols (or use 16+ characters).');
  return errs;
}
module.exports = { hash, verify, needsRehash, dummyHash, checkPolicy };
