'use strict';
const crypto = require('node:crypto');
const config = require('../config');

const randomToken = (bytes = 32) => crypto.randomBytes(bytes).toString('base64url');
const sha256 = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');
const hmac = (key, s) => crypto.createHmac('sha256', key).update(String(s)).digest('base64url');
function safeEqual(a, b) {
  const x = Buffer.from(String(a)); const y = Buffer.from(String(b));
  if (x.length !== y.length) { crypto.timingSafeEqual(x, x); return false; }
  return crypto.timingSafeEqual(x, y);
}
// AES-256-GCM authenticated encryption for secrets at rest (e.g. TOTP seeds). Format v1:<iv>.<tag>.<ct>
function encrypt(plain, key = config.secrets.dataKey) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', key.subarray(0, 32), iv);
  const ct = Buffer.concat([c.update(String(plain), 'utf8'), c.final()]);
  return `v1:${iv.toString('base64url')}.${c.getAuthTag().toString('base64url')}.${ct.toString('base64url')}`;
}
function decrypt(blob, key = config.secrets.dataKey) {
  const m = /^v1:([\w-]+)\.([\w-]+)\.([\w-]*)$/.exec(String(blob || ''));
  if (!m) throw new Error('bad ciphertext');
  const d = crypto.createDecipheriv('aes-256-gcm', key.subarray(0, 32), Buffer.from(m[1], 'base64url'));
  d.setAuthTag(Buffer.from(m[2], 'base64url'));
  return Buffer.concat([d.update(Buffer.from(m[3], 'base64url')), d.final()]).toString('utf8');
}
// human-friendly one-time codes (no ambiguous chars)
const ALPH = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function humanCode(len = 10) {
  const b = crypto.randomBytes(len); let s = '';
  for (let i = 0; i < len; i++) s += ALPH[b[i] % ALPH.length];
  return s;
}
module.exports = { randomToken, sha256, hmac, safeEqual, encrypt, decrypt, humanCode };
