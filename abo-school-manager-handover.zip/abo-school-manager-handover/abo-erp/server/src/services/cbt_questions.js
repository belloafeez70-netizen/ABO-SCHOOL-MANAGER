'use strict';
// Question model shared by the question bank, the exam builder and the bulk importer.
const { E } = require('../lib/errors');
const { obj, str } = require('../lib/schema');

const TYPES = ['mcq', 'multi_select', 'true_false', 'short_answer', 'numeric', 'fill_blank', 'theory'];
const optUuid = { type: ['string', 'null'], format: 'uuid' };
const questionBody = obj({
  type: { enum: TYPES }, text: str(4000, 1), marks: { type: 'number', exclusiveMinimum: 0, maximum: 100 },
  theoryGuide: { type: ['string', 'null'], maxLength: 2000 }, imageFileId: optUuid,
  subjectId: optUuid, classId: optUuid, sessionId: optUuid, termId: optUuid,
  topic: { type: ['string', 'null'], maxLength: 120 }, subtopic: { type: ['string', 'null'], maxLength: 120 },
  difficulty: { enum: ['easy', 'medium', 'hard'] }, explanation: { type: ['string', 'null'], maxLength: 4000 },
  correct: { type: 'boolean' },
  options: { type: 'array', maxItems: 8, items: obj({ text: str(1000, 1), isCorrect: { type: 'boolean' }, imageFileId: optUuid }, ['text']) },
  accepted: { type: 'array', maxItems: 20, items: str(200, 1) }, caseSensitive: { type: 'boolean' },
  numericValue: { type: 'number' }, tolerance: { type: 'number', minimum: 0, maximum: 1000000 },
}, ['type', 'text']);

// validate + normalise → { options, answerKey } (throws friendly 400s)
function normalise(q) {
  let options = []; let answerKey = null;
  const opts = (q.options || []).map((o) => ({ text: String(o.text).trim(), isCorrect: !!o.isCorrect, imageFileId: o.imageFileId || null })).filter((o) => o.text);
  switch (q.type) {
    case 'mcq':
      if (opts.length < 2) throw E.bad('Multiple-choice questions need at least 2 options.', { field: 'options' });
      if (opts.filter((o) => o.isCorrect).length !== 1) throw E.bad('Mark exactly one option as correct.', { field: 'options' });
      options = opts; break;
    case 'multi_select':
      if (opts.length < 2) throw E.bad('Multiple-select questions need at least 2 options.', { field: 'options' });
      if (!opts.some((o) => o.isCorrect)) throw E.bad('Mark at least one correct option.', { field: 'options' });
      options = opts; break;
    case 'true_false':
      if (typeof q.correct !== 'boolean') throw E.bad('Choose whether the statement is true or false.', { field: 'correct' });
      options = [{ text: 'True', isCorrect: q.correct === true }, { text: 'False', isCorrect: q.correct === false }]; break;
    case 'numeric':
      if (typeof q.numericValue !== 'number' || !Number.isFinite(q.numericValue)) throw E.bad('Give the correct numerical answer.', { field: 'numericValue' });
      answerKey = { value: q.numericValue, tolerance: Math.abs(Number(q.tolerance) || 0) }; break;
    case 'fill_blank': {
      const acc = (q.accepted || []).map((x) => String(x).trim()).filter(Boolean);
      if (!acc.length) throw E.bad('Give at least one accepted answer for the blank.', { field: 'accepted' });
      answerKey = { accepted: acc, caseSensitive: !!q.caseSensitive }; break;
    }
    case 'short_answer': {
      const acc = (q.accepted || []).map((x) => String(x).trim()).filter(Boolean);
      answerKey = acc.length ? { accepted: acc, caseSensitive: !!q.caseSensitive } : null; break;       // no key → teacher marks it
    }
    case 'theory': break;
    default: throw E.bad('Unknown question type.');
  }
  return { options, answerKey };
}

async function assertRefs(c, q) {
  const checks = [['subjects', q.subjectId, 'Subject'], ['classes', q.classId, 'Class'], ['academic_sessions', q.sessionId, 'Session'], ['terms', q.termId, 'Term']];
  for (const [t, id, label] of checks) if (id && !(await c.query(`SELECT 1 FROM ${t} WHERE id = $1`, [id])).rowCount) throw E.notFound(label);
  for (const f of [q.imageFileId, ...(q.options || []).map((o) => o.imageFileId)].filter(Boolean)) {
    if (!(await c.query("SELECT 1 FROM uploads WHERE id = $1 AND purpose = 'cbt_image' AND deleted_at IS NULL", [f])).rowCount) throw E.notFound('Image');
  }
}

async function insertQuestion(c, schoolId, userId, examId, q, position, { sourceId = null } = {}) {
  const { options, answerKey } = normalise(q);
  await assertRefs(c, q);
  const r = (await c.query(`INSERT INTO cbt_questions (school_id, exam_id, subject_id, class_id, session_id, term_id, type, text, image_file_id, marks, position, theory_guide,
      topic, subtopic, difficulty, explanation, answer_key, source_question_id, created_by, updated_by)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,COALESCE($15,'medium'),$16,$17,$18,$19,$19) RETURNING id`,
  [schoolId, examId, q.subjectId || null, q.classId || null, q.sessionId || null, q.termId || null, q.type, q.text, q.imageFileId || null, q.marks || 1, position,
    q.theoryGuide || null, q.topic ? String(q.topic).trim() : null, q.subtopic ? String(q.subtopic).trim() : null, q.difficulty || null, q.explanation || null,
    answerKey ? JSON.stringify(answerKey) : null, sourceId, userId])).rows[0];
  for (const [i, o] of options.entries()) await c.query('INSERT INTO cbt_options (school_id, question_id, text, is_correct, position, image_file_id) VALUES ($1,$2,$3,$4,$5,$6)', [schoolId, r.id, o.text, o.isCorrect, i, o.imageFileId || null]);
  return r.id;
}

// replace the content of a question in place (bank questions, or draft-exam questions)
async function updateQuestion(c, schoolId, userId, id, q) {
  const { options, answerKey } = normalise(q);
  await assertRefs(c, q);
  await c.query(`UPDATE cbt_questions SET subject_id = $2, class_id = $3, session_id = $4, term_id = $5, type = $6, text = $7, image_file_id = $8, marks = $9, theory_guide = $10,
      topic = $11, subtopic = $12, difficulty = COALESCE($13, difficulty), explanation = $14, answer_key = $15, updated_by = $16 WHERE id = $1`,
  [id, q.subjectId || null, q.classId || null, q.sessionId || null, q.termId || null, q.type, q.text, q.imageFileId || null, q.marks || 1, q.theoryGuide || null,
    q.topic ? String(q.topic).trim() : null, q.subtopic ? String(q.subtopic).trim() : null, q.difficulty || null, q.explanation || null, answerKey ? JSON.stringify(answerKey) : null, userId]);
  await c.query('DELETE FROM cbt_options WHERE question_id = $1', [id]);
  for (const [i, o] of options.entries()) await c.query('INSERT INTO cbt_options (school_id, question_id, text, is_correct, position, image_file_id) VALUES ($1,$2,$3,$4,$5,$6)', [schoolId, id, o.text, o.isCorrect, i, o.imageFileId || null]);
}

// full question (staff view: includes the key)
async function loadQuestions(c, where, params) {
  return (await c.query(`SELECT q.id, q.exam_id, q.type, q.text, q.marks, q.position, q.theory_guide, q.image_file_id, q.subject_id, q.class_id, q.session_id, q.term_id, q.topic, q.subtopic,
      q.difficulty, q.explanation, q.answer_key, q.status, q.review_note, q.reviewed_at, q.source_question_id, q.created_at, q.updated_at, s.name AS subject, cl.display_name AS class_name, u.full_name AS created_by_name,
      COALESCE((SELECT json_agg(json_build_object('id', o.id, 'text', o.text, 'isCorrect', o.is_correct, 'imageFileId', o.image_file_id) ORDER BY o.position) FROM cbt_options o WHERE o.question_id = q.id), '[]') AS options
    FROM cbt_questions q LEFT JOIN subjects s ON s.id = q.subject_id LEFT JOIN classes cl ON cl.id = q.class_id LEFT JOIN users u ON u.id = q.created_by
    WHERE ${where}`, params)).rows;
}
// question row → body accepted by insertQuestion (for duplicating / copying into an exam)
function toBody(q) {
  const b = { type: q.type, text: q.text, marks: Number(q.marks), theoryGuide: q.theory_guide, imageFileId: q.image_file_id, subjectId: q.subject_id, classId: q.class_id,
    sessionId: q.session_id, termId: q.term_id, topic: q.topic, subtopic: q.subtopic, difficulty: q.difficulty, explanation: q.explanation,
    options: (q.options || []).map((o) => ({ text: o.text, isCorrect: o.isCorrect, imageFileId: o.imageFileId })) };
  if (q.type === 'true_false') b.correct = !!(q.options || []).find((o) => o.text === 'True' && o.isCorrect);
  const k = q.answer_key || {};
  if (k.accepted) { b.accepted = k.accepted; b.caseSensitive = !!k.caseSensitive; }
  if (q.type === 'numeric') { b.numericValue = Number(k.value); b.tolerance = Number(k.tolerance) || 0; }
  return b;
}

async function copyToExam(c, schoolId, userId, examId, bankIds) {
  const present = new Set((await c.query('SELECT source_question_id FROM cbt_questions WHERE exam_id = $1 AND source_question_id IS NOT NULL', [examId])).rows.map((r) => r.source_question_id));
  const ids = bankIds.filter((id) => !present.has(id));
  if (!ids.length) return 0;
  const bank = await loadQuestions(c, "q.id = ANY($1::uuid[]) AND q.exam_id IS NULL AND q.status = 'active'", [ids]);
  const byId = new Map(bank.map((q) => [q.id, q]));
  let pos = (await c.query('SELECT COALESCE(max(position), 0) AS p FROM cbt_questions WHERE exam_id = $1', [examId])).rows[0].p;
  let n = 0;
  for (const id of ids) { const q = byId.get(id); if (!q) continue; await insertQuestion(c, schoolId, userId, examId, toBody(q), ++pos, { sourceId: q.id }); n++; }
  return n;
}
module.exports = { TYPES, questionBody, normalise, insertQuestion, updateQuestion, loadQuestions, toBody, copyToExam };
