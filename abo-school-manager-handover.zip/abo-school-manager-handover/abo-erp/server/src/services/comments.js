'use strict';
// Report-card comment helper — the offline app's comment wording, moved to the server. Suggestions only: nothing is
// saved until a teacher/head reviews it and presses Save (PUT /results/report-cards/bulk, which is audited).
const clampAvg = (a) => Math.max(1, Math.min(100, Math.round(Number(a) || 1)));

function scoreComment(avg, name) {
  const n = clampAvg(avg);
  const target = Math.min(100, n + (n >= 90 ? 1 : n >= 70 ? 3 : n >= 50 ? 5 : 10));
  if (n === 100) return `${name} achieved a perfect 100%, showing complete mastery and outstanding readiness for greater challenges.`;
  if (n >= 97) return `${name} scored ${n}%, an almost perfect performance; the next goal is precision, leadership and consistent excellence.`;
  if (n >= 90) return `${name} scored ${n}%, an exceptional result with very strong understanding; careful revision can push this toward ${target}%.`;
  if (n >= 80) return `${name} scored ${n}%, an excellent performance; steady practice can lift the result toward ${target}% next term.`;
  if (n >= 70) return `${name} scored ${n}%, a very good performance; more consistency in classwork and tests can raise the average to ${target}%.`;
  if (n >= 60) return `${name} scored ${n}%, a good pass; more practice with corrections is needed to move into higher grades.`;
  if (n >= 50) return `${name} scored ${n}%, an average result; regular study and past questions can lift this to ${target}%.`;
  if (n >= 40) return `${name} scored ${n}%, a weak pass; urgent improvement is needed through regular practice and teacher support.`;
  if (n >= 30) return `${name} scored ${n}%, below expectation; close supervision, remedial work and consistent study time are needed.`;
  if (n >= 20) return `${name} scored ${n}%, a poor result; key topics should be retaught with daily practice and parental support.`;
  return `${name} scored ${n}%, a critical level; urgent academic support, counselling and structured remedial lessons are needed.`;
}

// teacher's comment: result + strongest / weakest subject + attendance
function teacherComment({ firstName, average, strongest, weakest, present, daysOpen }) {
  const name = firstName || 'This learner';
  let s = scoreComment(average, name);
  if (strongest && weakest && strongest !== weakest) s += ` Best in ${strongest}; ${weakest} needs more attention.`;
  else if (strongest) s += ` Best in ${strongest}.`;
  if (daysOpen > 0 && present !== null && present !== undefined) {
    const rate = present / daysOpen;
    s += rate >= 0.9 ? ' Attendance was very good.' : rate >= 0.75 ? ' Attendance was satisfactory but can improve.' : ' Attendance needs urgent improvement.';
  }
  return s.slice(0, 600);
}

// head's / principal's comment
function headComment({ firstName, average, section }) {
  const name = firstName || 'The learner'; const avg = clampAvg(average);
  const title = section === 'secondary' ? 'principal' : 'head teacher';
  if (avg >= 85) return `The ${title} commends ${name} for an outstanding ${avg}% average. Keep aiming higher.`;
  if (avg >= 70) return `${name} has done very well with ${avg}%. Maintain the effort and improve weak areas.`;
  if (avg >= 60) return `${name} has a good ${avg}% result. More commitment will lead to excellence.`;
  if (avg >= 50) return `${name} is encouraged to study harder after this ${avg}% average for better performance next term.`;
  if (avg >= 40) return `${name} needs more seriousness and steady support after scoring ${avg}%.`;
  return `${name} must improve greatly from ${avg}%. Parent/guardian cooperation is needed for better progress.`;
}
module.exports = { scoreComment, teacherComment, headComment };
