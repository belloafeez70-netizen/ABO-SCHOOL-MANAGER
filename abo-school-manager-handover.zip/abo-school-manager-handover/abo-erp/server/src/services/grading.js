'use strict';
// Server-side result computation — ported from the legacy computeGrade()/getRemark()/recalculateAll()
// so existing schools get identical grades and positions. Pure functions (unit-tested).

const DEFAULT_GRADING = {
  secondary: [ // WAEC scale (legacy "secondary")
    { min: 85, grade: 'A+', remark: 'Astounding' }, { min: 75, grade: 'A1', remark: 'Excellent' },
    { min: 70, grade: 'B2', remark: 'Very Good' }, { min: 65, grade: 'B3', remark: 'Good' },
    { min: 60, grade: 'C4', remark: 'Credit' }, { min: 55, grade: 'C5', remark: 'Credit' },
    { min: 50, grade: 'C6', remark: 'Credit Pass' }, { min: 45, grade: 'D7', remark: 'Pass' },
    { min: 40, grade: 'E8', remark: 'Weak Pass' }, { min: 0, grade: 'F9', remark: 'Fail' },
  ],
  primary: [
    { min: 90, grade: 'A+', remark: 'Astounding' },
    { min: 80, grade: 'A', remark: 'Excellent performance! Keep it up!' },
    { min: 70, grade: 'B+', remark: 'Very good performance. You can do better.' },
    { min: 60, grade: 'B', remark: 'Good result. Work harder for excellence.' },
    { min: 50, grade: 'C', remark: 'Average performance. Study more to improve.' },
    { min: 40, grade: 'D', remark: 'Fair result. A lot of improvement is needed.' },
    { min: 0, grade: 'F', remark: 'Poor result. You are advised to improve urgently.' },
  ],
};
DEFAULT_GRADING.nursery = DEFAULT_GRADING.primary;
const DEFAULT_COMPONENTS = [
  { key: 'ca1', label: '1st CA', max: 20 }, { key: 'ca2', label: '2nd CA', max: 20 }, { key: 'exam', label: 'Exam', max: 60 },
];

const round2 = (n) => Math.round((Number(n) + Number.EPSILON) * 100) / 100;

function validateComponents(list) {
  if (!Array.isArray(list) || list.length < 1 || list.length > 6) return 'Use between 1 and 6 assessment components.';
  const keys = new Set(); let sum = 0;
  for (const c of list) {
    if (!/^[a-z0-9_]{1,20}$/.test(c.key || '')) return `Invalid component key "${c.key}".`;
    if (keys.has(c.key)) return `Duplicate component key "${c.key}".`;
    keys.add(c.key);
    if (!(Number(c.max) > 0 && Number(c.max) <= 100)) return `Component ${c.key} maximum must be between 1 and 100.`;
    sum += Number(c.max);
  }
  if (Math.abs(sum - 100) > 0.001) return `Component maxima must add up to 100 (currently ${sum}).`;
  return null;
}
function validateBands(bands) {
  if (!Array.isArray(bands) || bands.length < 2) return 'A grading scale needs at least two bands.';
  const sorted = [...bands].sort((a, b) => b.min - a.min);
  if (sorted[sorted.length - 1].min !== 0) return 'The lowest band must start at 0.';
  for (const b of sorted) if (!(b.min >= 0 && b.min <= 100) || !b.grade) return 'Each band needs a grade and a minimum between 0 and 100.';
  return null;
}
function gradeFor(score, bands) {
  const s = Math.max(0, Math.min(100, Math.round(Number(score) || 0)));
  const sorted = [...bands].sort((a, b) => b.min - a.min);
  const band = sorted.find((b) => s >= b.min) || sorted[sorted.length - 1];
  return { grade: band.grade, remark: band.remark || '' };
}
// competition ranking ("1224"), identical to legacy recalculateAll()
function rank(entries /* [{id, value}] */) {
  const sorted = [...entries].sort((a, b) => b.value - a.value);
  const out = new Map(); let last = null, lastRank = 0;
  sorted.forEach((e, i) => { if (last === null || e.value !== last) lastRank = i + 1; out.set(e.id, lastRank); last = e.value; });
  return out;
}
// scores: Map<studentId, Map<componentKey, number|null>>
function computeSheet(components, scores, bands) {
  const rows = [];
  for (const [studentId, comp] of scores) {
    let total = 0, any = false;
    for (const c of components) {
      const v = comp.get(c.key);
      if (v !== null && v !== undefined) {
        if (v < 0 || v > c.max) throw Object.assign(new Error(`score out of range for ${c.key}`), { code: 'SCORE_RANGE' });
        total += Number(v); any = true;
      }
    }
    if (!any) continue;
    total = round2(total);
    rows.push({ studentId, total, ...gradeFor(total, bands) });
  }
  const pos = rank(rows.map((r) => ({ id: r.studentId, value: r.total })));
  rows.forEach((r) => { r.position = pos.get(r.studentId); });
  return rows;
}
// subjectTotals: Map<studentId, number[]>  → broadsheet rows
function computeTerm(subjectTotals, bands, passMark = 40) {
  const rows = [];
  for (const [studentId, totals] of subjectTotals) {
    if (!totals.length) { rows.push({ studentId, subjectsCount: 0, total: 0, average: 0, highest: null, lowest: null, grade: null, status: 'Pending' }); continue; }
    const total = round2(totals.reduce((a, b) => a + b, 0));
    const average = round2(total / totals.length);
    rows.push({ studentId, subjectsCount: totals.length, total, average, highest: Math.max(...totals), lowest: Math.min(...totals),
      grade: gradeFor(average, bands).grade, status: average >= passMark ? 'Pass' : 'Fail' });
  }
  const pos = rank(rows.filter((r) => r.status !== 'Pending').map((r) => ({ id: r.studentId, value: r.average })));
  rows.forEach((r) => { r.position = pos.get(r.studentId) || null; r.classSize = rows.length; });
  return rows;
}
const ordinal = (n) => { if (!n) return ''; const s = ['th', 'st', 'nd', 'rd'], v = n % 100; return n + (s[(v - 20) % 10] || s[v] || s[0]); };

// Offline, rule-based remark generator (ported from the legacy "Offline AI" remarks).
function offlineRemark({ average, grade, status, weakest, strongest }) {
  const a = Number(average) || 0;
  const open = a >= 85 ? 'An outstanding term.' : a >= 70 ? 'A very good term.' : a >= 55 ? 'A good effort this term.' : a >= 40 ? 'A fair performance this term.' : 'This term was challenging.';
  const mid = strongest ? ` Strongest in ${strongest}.` : '';
  const tail = weakest && a < 85 ? ` More attention is needed in ${weakest}.` : '';
  const close = status === 'Fail' ? ' Extra support and consistent study are strongly advised.' : a >= 70 ? ' Keep up the excellent work.' : ' With steady practice, better results are within reach.';
  return `${open}${mid}${tail}${close}`.slice(0, 600);
}
module.exports = { DEFAULT_GRADING, DEFAULT_COMPONENTS, validateComponents, validateBands, gradeFor, rank, computeSheet, computeTerm, ordinal, offlineRemark, round2 };
