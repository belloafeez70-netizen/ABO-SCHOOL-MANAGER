'use strict';
// SMTP delivery via nodemailer when SMTP_URL is configured (e.g. smtps://user:pass@smtp.provider.com:465).
// Without SMTP: in development/test the message is marked 'dev_logged' (NOT sent); in staging/production
// startup is allowed but the job fails loudly so operators notice.
const config = require('../config');
let transport = null;
function getTransport() {
  if (!config.mail.smtpUrl) return null;
  if (!transport) transport = require('nodemailer').createTransport(config.mail.smtpUrl);
  return transport;
}
async function send({ to, subject, text }) {
  const t = getTransport();
  if (!t) {
    if (config.isProdLike) throw new Error('SMTP_URL is not configured');
    return { status: 'dev_logged' };
  }
  await t.sendMail({ from: config.mail.from, to, subject, text });
  return { status: 'sent' };
}
module.exports = { send };
