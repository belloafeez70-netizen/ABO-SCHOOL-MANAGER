'use strict';
// Server-authoritative result computation over the database (uses the pure functions in grading.js).
const G = require('./grading');

async function settings(c) {
  const s = (await c.query('SELECT grading, pass_mark, report_card, results_require_review FROM school_settings LIMIT 1')).rows[0]
    || { grading: G.DEFAULT_GRADING, pass_mark: 40, report_card: {}, results_require_review: true };
  const comps = (await c.query('SELECT key, label, max_score AS max, is_exam FROM assessment_components WHERE active ORDER BY position, key')).rows;
  s.assessment_components = comps.length ? comps : G.DEFAULT_COMPONENTS.map((x) => ({ ...x, is_exam: x.key === 'exam' }));
  return s;
}
const bandsFor = (st, section) => (st.grading && st.grading[section]) || G.DEFAULT_GRADING[section] || G.DEFAULT_GRADING.primary;

async function roster(c, termId, classId) {
  return (await c.query(`SELECT s.id, s.first_name, s.last_name, s.other_names, s.admission_no, s.gender FROM terms t
    JOIN student_enrollments e ON e.session_id = t.session_id AND e.class_id = $2 AND e.status <> 'withdrawn'
    JOIN students s ON s.id = e.student_id AND s.deleted_at IS NULL
    WHERE t.id = $1 ORDER BY s.last_name, s.first_name`, [termId, classId])).rows;
}

async function recomputeSheet(c, sheetId) {
  const sh = (await c.query('SELECT a.*, cl.section FROM assessments a JOIN classes cl ON cl.id = a.class_id WHERE a.id = $1', [sheetId])).rows[0];
  const st = await settings(c);
  const scores = new Map();
  for (const r of (await c.query('SELECT student_id, component_key, score FROM assessment_scores WHERE sheet_id = $1', [sheetId])).rows) {
    if (!scores.has(r.student_id)) scores.set(r.student_id, new Map());
    scores.get(r.student_id).set(r.component_key, r.score);
  }
  const rows = G.computeSheet(sh.components, scores, bandsFor(st, sh.section));
  await c.query('DELETE FROM examination_results WHERE sheet_id = $1', [sheetId]);
  if (rows.length) {
    await c.query(`INSERT INTO examination_results (school_id, sheet_id, student_id, total, grade, remark, subject_position)
      SELECT $1, $2, x.student_id, x.total, x.grade, x.remark, x.position FROM json_to_recordset($3::json) AS x(student_id uuid, total numeric, grade text, remark text, position int)`,
    [sh.school_id, sheetId, JSON.stringify(rows.map((r) => ({ student_id: r.studentId, total: r.total, grade: r.grade, remark: r.remark, position: r.position })))]);
  }
  return rows;
}

async function computeClassTerm(c, termId, classId, { publish = false } = {}) {
  const cls = (await c.query('SELECT id, section, school_id, display_name FROM classes WHERE id = $1', [classId])).rows[0];
  const st = await settings(c);
  const students = await roster(c, termId, classId);
  const res = (await c.query(`SELECT er.student_id, er.total FROM examination_results er JOIN assessments a ON a.id = er.sheet_id
    WHERE a.term_id = $1 AND a.class_id = $2`, [termId, classId])).rows;
  const totals = new Map(students.map((s) => [s.id, []]));
  for (const r of res) if (totals.has(r.student_id)) totals.get(r.student_id).push(Number(r.total));
  const rows = G.computeTerm(totals, bandsFor(st, cls.section), Number(st.pass_mark));
  await c.query('DELETE FROM result_summaries WHERE term_id = $1 AND class_id = $2', [termId, classId]);
  if (rows.length) {
    await c.query(`INSERT INTO result_summaries (school_id, term_id, class_id, student_id, subjects_count, total, average, highest, lowest, grade, position, class_size, status, published)
      SELECT $1, $2, $3, x.student_id, x.subjects_count, x.total, x.average, x.highest, x.lowest, x.grade, x.position, x.class_size, x.status, $4
      FROM json_to_recordset($5::json) AS x(student_id uuid, subjects_count int, total numeric, average numeric, highest numeric, lowest numeric, grade text, position int, class_size int, status text)`,
    [cls.school_id, termId, classId, publish, JSON.stringify(rows.map((r) => ({ student_id: r.studentId, subjects_count: r.subjectsCount, total: r.total, average: r.average,
      highest: r.highest, lowest: r.lowest, grade: r.grade, position: r.position, class_size: r.classSize, status: r.status })))]);
  }
  return rows;
}

async function broadsheet(c, termId, classId) {
  const students = await roster(c, termId, classId);
  const sheets = (await c.query(`SELECT a.id, a.status, a.components, s.id AS subject_id, s.name AS subject FROM assessments a JOIN subjects s ON s.id = a.subject_id
    WHERE a.term_id = $1 AND a.class_id = $2 ORDER BY s.name`, [termId, classId])).rows;
  const cells = (await c.query(`SELECT er.sheet_id, er.student_id, er.total, er.grade, er.subject_position FROM examination_results er JOIN assessments a ON a.id = er.sheet_id
    WHERE a.term_id = $1 AND a.class_id = $2`, [termId, classId])).rows;
  const term = (await c.query('SELECT student_id, subjects_count, total, average, highest, lowest, grade, position, class_size, status, published FROM result_summaries WHERE term_id = $1 AND class_id = $2', [termId, classId])).rows;
  const byStudent = new Map(term.map((t) => [t.student_id, t]));
  const cellMap = new Map(cells.map((x) => [`${x.sheet_id}:${x.student_id}`, x]));
  return {
    subjects: sheets.map((s) => ({ sheetId: s.id, subjectId: s.subject_id, name: s.subject, status: s.status })),
    rows: students.map((s) => ({
      studentId: s.id, name: `${s.last_name} ${s.first_name}`, admissionNo: s.admission_no, gender: s.gender,
      scores: sheets.map((sh) => { const x = cellMap.get(`${sh.id}:${s.id}`); return x ? { total: x.total, grade: x.grade, position: x.subject_position } : null; }),
      summary: byStudent.get(s.id) || null,
    })).sort((a, b) => ((a.summary && a.summary.position) || 1e9) - ((b.summary && b.summary.position) || 1e9)),
    published: term.length > 0 && term.every((t) => t.published),
  };
}
module.exports = { settings, bandsFor, roster, recomputeSheet, computeClassTerm, broadsheet };
