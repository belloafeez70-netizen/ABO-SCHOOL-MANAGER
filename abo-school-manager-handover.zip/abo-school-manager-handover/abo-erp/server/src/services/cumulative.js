'use strict';
// Cumulative results ("results so far this session").
//
// For a class and a term, every term of the same session up to and including that term is brought together:
//   • each subject: the learner's total in every term, total marks so far, cumulative average, grade, remark and the
//     learner's cumulative position in that subject;
//   • overall: this term's average and position, every earlier term's average, the cumulative average, grade,
//     cumulative position, pass/fail, the change since last term and a short plain-English summary.
// 3rd term cumulative = the whole session (annual) result.
//
// How the cumulative average is worked out (school setting report_card.cumulativeDivisor):
//   'taken' (default) — divide by the terms the learner was actually scored in. A pupil who joined in 2nd term with
//                       60 and 70 gets 65 — new pupils are not punished for terms before they came.
//   'all'             — divide by the terms in which the subject was taught in the class; a term the learner missed
//                       counts as 0 (60 and 70 after a missed 1st term = 43.33).
// Overall cumulative average = average of the learner's subject cumulative averages (the same rule as the annual
// broadsheet). Ranking is 1-2-2-4 (two learners on the same average share a position).
// Results follow the learner, not the class: a pupil who changed arm mid-session keeps earlier terms' scores.
// Everything is computed in SQL-scoped reads inside the caller's tenant transaction (RLS + branch scope apply).
const G = require('./grading');
const R = require('./results');
const { E } = require('../lib/errors');

const round2 = G.round2;
const TERM_WORD = { '1ST': 'first', '2ND': 'second', '3RD': 'third' };
const TERM_LABEL = { '1ST': '1st term', '2ND': '2nd term', '3RD': '3rd term' };
const sum = (xs) => xs.reduce((a, b) => a + b, 0);
const avg = (xs) => (xs.length ? round2(sum(xs) / xs.length) : null);

function divisorOf(st) {
  const d = st && st.report_card && st.report_card.cumulativeDivisor;
  return d === 'all' ? 'all' : 'taken';
}

// friendly words for an average (independent of the grading scale, so it reads well for every school)
function band(a) {
  if (a === null || a === undefined) return '';
  return a >= 85 ? 'outstanding' : a >= 70 ? 'very good' : a >= 60 ? 'good' : a >= 50 ? 'fair' : a >= 40 ? 'just passing' : 'below the pass mark';
}

// One short paragraph a parent can read in ten seconds. No pronouns (we do not guess gender), no jargon.
function summarySentence(row, { termName, classSize, terms, passMark }) {
  const first = row.firstName || row.name.split(' ').slice(-1)[0];
  if (row.cumulativeAverage === null) return `${first} has no scores yet this session.`;
  const upto = terms.length > 1 ? `After the ${TERM_WORD[termName] || termName.toLowerCase()} term` : 'This term';
  const parts = [`${upto}, ${first}’s ${terms.length > 1 ? 'cumulative ' : ''}average is ${row.cumulativeAverage}% (${row.grade}), which is ${band(row.cumulativeAverage)}.`];
  if (row.change !== null && terms.length > 1) {
    if (Math.abs(row.change) < 0.5) parts.push('That is about the same as last term.');
    else parts.push(`This term’s average is ${Math.abs(row.change)} points ${row.change > 0 ? 'higher' : 'lower'} than last term.`);
  }
  if (row.cumulativePosition) parts.push(`${first} is ${G.ordinal(row.cumulativePosition)} of ${classSize} in the class ${terms.length > 1 ? 'so far this session' : 'this term'}.`);
  if (row.best) parts.push(`Best subject so far: ${row.best.name} (${row.best.average}%).`);
  if (row.weakest && row.weakest.name !== (row.best && row.best.name) && row.weakest.average < Math.max(passMark + 15, 55)) parts.push(`Needs more attention: ${row.weakest.name} (${row.weakest.average}%).`);
  if (row.status === 'Fail') parts.push('Extra help at home and in school is advised.');
  return parts.join(' ');
}

/**
 * @param c         pg client inside withTx (tenant-scoped)
 * @param termId    the term the cumulative runs up to (inclusive)
 * @param classId   the class (its enrolled learners for the session)
 * @param opts.publishedOnly  only published score sheets (students/parents)
 * @param opts.studentIds     restrict learners (positions are still computed over the whole class)
 */
async function classCumulative(c, termId, classId, { publishedOnly = false } = {}) {
  const term = (await c.query('SELECT t.id, t.name, t.session_id, se.name AS session FROM terms t JOIN academic_sessions se ON se.id = t.session_id WHERE t.id = $1', [termId])).rows[0];
  if (!term) throw E.notFound('Term');
  const cls = (await c.query('SELECT id, display_name, section FROM classes WHERE id = $1', [classId])).rows[0];
  if (!cls) throw E.notFound('Class');
  // '1ST' < '2ND' < '3RD' sorts correctly as text (CHECK constraint guarantees the three names)
  const terms = (await c.query('SELECT id, name FROM terms WHERE session_id = $1 AND name <= $2 ORDER BY name', [term.session_id, term.name])).rows;
  const termIds = terms.map((t) => t.id);
  const students = (await c.query(`SELECT s.id, s.first_name, s.last_name, s.other_names, s.admission_no, s.gender FROM student_enrollments e
      JOIN students s ON s.id = e.student_id AND s.deleted_at IS NULL
      WHERE e.session_id = $1 AND e.class_id = $2 AND e.status <> 'withdrawn' ORDER BY s.last_name, s.first_name`, [term.session_id, classId])).rows;
  const ids = students.map((s) => s.id);
  const cells = ids.length ? (await c.query(`SELECT a.term_id, a.class_id, a.subject_id, sb.name AS subject, a.status, er.student_id, er.total
      FROM examination_results er JOIN assessments a ON a.id = er.sheet_id JOIN subjects sb ON sb.id = a.subject_id
      WHERE a.term_id = ANY($1::uuid[]) AND er.student_id = ANY($2::uuid[]) ${publishedOnly ? "AND a.status = 'published'" : ''}`, [termIds, ids])).rows : [];
  // which subjects the class was taught in which term (for the 'all' divisor) — includes sheets with no score for a learner
  const offered = (await c.query(`SELECT DISTINCT a.term_id, a.subject_id FROM assessments a WHERE a.class_id = $1 AND a.term_id = ANY($2::uuid[]) ${publishedOnly ? "AND a.status = 'published'" : ''}`, [classId, termIds])).rows;
  const st = await R.settings(c); const bands = R.bandsFor(st, cls.section); const passMark = Number(st.pass_mark); const divisor = divisorOf(st);

  const subjects = [...new Map(cells.map((x) => [x.subject_id, { id: x.subject_id, name: x.subject }])).values()].sort((a, b) => a.name.localeCompare(b.name));
  const offeredIn = new Map(subjects.map((s) => [s.id, new Set()]));
  for (const o of offered) if (offeredIn.has(o.subject_id)) offeredIn.get(o.subject_id).add(o.term_id);
  for (const x of cells) offeredIn.get(x.subject_id).add(x.term_id);      // scored elsewhere (arm change) still counts
  const cell = new Map(cells.map((x) => [`${x.student_id}:${x.subject_id}:${x.term_id}`, Number(x.total)]));

  const rows = students.map((s) => {
    const subj = subjects.map((sb) => {
      const termTotals = terms.map((t) => (cell.has(`${s.id}:${sb.id}:${t.id}`) ? cell.get(`${s.id}:${sb.id}:${t.id}`) : null));
      const got = termTotals.filter((v) => v !== null);
      if (!got.length) return { termTotals, taken: 0, total: null, average: null, grade: null, remark: null, position: null };
      const total = round2(sum(got));
      const n = divisor === 'all' ? Math.max(got.length, terms.filter((t) => offeredIn.get(sb.id).has(t.id)).length) : got.length;
      const average = round2(total / n);
      const g = G.gradeFor(average, bands);
      return { termTotals, taken: got.length, total, average, grade: g.grade, remark: g.remark, position: null };
    });
    // each term's own average (what the report card for that term showed)
    const termAverages = terms.map((t, ti) => avg(subj.map((x) => x.termTotals[ti]).filter((v) => v !== null)));
    const cumAvgs = subj.map((x) => x.average).filter((v) => v !== null);
    const cumulativeAverage = avg(cumAvgs);
    const entries = subj.reduce((n, x) => n + x.taken, 0);
    const marksObtained = round2(sum(subj.map((x) => x.total || 0)));
    const thisTerm = termAverages[terms.length - 1];
    const prev = terms.length > 1 ? termAverages[terms.length - 2] : null;
    const scored = subj.map((x, i) => ({ name: subjects[i].name, average: x.average })).filter((x) => x.average !== null).sort((a, b) => b.average - a.average);
    return {
      studentId: s.id, name: `${s.last_name} ${s.first_name}`, firstName: s.first_name, admissionNo: s.admission_no, gender: s.gender,
      subjects: subj, termAverages,
      thisTermAverage: thisTerm, thisTermTotal: (() => { const v = subj.map((x) => x.termTotals[terms.length - 1]).filter((y) => y !== null); return v.length ? round2(sum(v)) : null; })(),
      thisTermPosition: null,
      cumulativeAverage, marksObtained: entries ? marksObtained : null, marksObtainable: entries * 100, subjectsTaken: cumAvgs.length,
      grade: cumulativeAverage === null ? null : G.gradeFor(cumulativeAverage, bands).grade,
      remark: cumulativeAverage === null ? null : G.gradeFor(cumulativeAverage, bands).remark,
      status: cumulativeAverage === null ? 'Pending' : cumulativeAverage >= passMark ? 'Pass' : 'Fail',
      change: thisTerm !== null && prev !== null ? round2(thisTerm - prev) : null,
      best: scored[0] || null, weakest: scored.length > 1 ? scored[scored.length - 1] : null,
      cumulativePosition: null,
    };
  });
  // positions: overall cumulative, this term, and per subject (1-2-2-4)
  const cpos = G.rank(rows.filter((r) => r.cumulativeAverage !== null).map((r) => ({ id: r.studentId, value: r.cumulativeAverage })));
  const tpos = G.rank(rows.filter((r) => r.thisTermAverage !== null).map((r) => ({ id: r.studentId, value: r.thisTermAverage })));
  for (const r of rows) { r.cumulativePosition = cpos.get(r.studentId) || null; r.thisTermPosition = tpos.get(r.studentId) || null; }
  subjects.forEach((sb, i) => {
    const p = G.rank(rows.filter((r) => r.subjects[i].average !== null).map((r) => ({ id: r.studentId, value: r.subjects[i].average })));
    for (const r of rows) r.subjects[i].position = p.get(r.studentId) || null;
  });
  const classSize = rows.length;
  for (const r of rows) r.summary = summarySentence(r, { termName: term.name, classSize, terms, passMark });
  rows.sort((a, b) => (a.cumulativePosition || 1e9) - (b.cumulativePosition || 1e9) || a.name.localeCompare(b.name));

  // class statistics per subject and overall
  const stat = (xs) => (xs.length ? { average: avg(xs), highest: Math.max(...xs), lowest: Math.min(...xs), count: xs.length } : { average: null, highest: null, lowest: null, count: 0 });
  const subjectStats = subjects.map((sb, i) => ({
    ...stat(rows.map((r) => r.subjects[i].average).filter((v) => v !== null)),
    termAverages: terms.map((t, ti) => avg(rows.map((r) => r.subjects[i].termTotals[ti]).filter((v) => v !== null))),
    passed: rows.filter((r) => r.subjects[i].average !== null && r.subjects[i].average >= passMark).length,
  }));
  const overall = stat(rows.map((r) => r.cumulativeAverage).filter((v) => v !== null));
  overall.passed = rows.filter((r) => r.status === 'Pass').length;
  overall.termAverages = terms.map((t, ti) => avg(rows.map((r) => r.termAverages[ti]).filter((v) => v !== null)));

  return {
    session: term.session, sessionId: term.session_id, termId: term.id, term: term.name, termLabel: TERM_LABEL[term.name] || term.name,
    terms: terms.map((t) => ({ id: t.id, name: t.name, label: TERM_LABEL[t.name] || t.name })),
    isAnnual: term.name === '3RD', classId: cls.id, class_name: cls.display_name, section: cls.section,
    subjects, rows, subjectStats, overall, classSize, passMark, divisor,
    provisional: cells.some((x) => x.status !== 'published'),
    method: divisor === 'all'
      ? 'Cumulative subject average = total marks so far ÷ number of terms the subject was taught (a missed term counts as 0). Overall cumulative average = average of the subject cumulative averages.'
      : 'Cumulative subject average = total marks so far ÷ number of terms the learner was scored in that subject. Overall cumulative average = average of the subject cumulative averages.',
  };
}

// one learner's slice, for the report card (positions stay class-wide)
function forStudent(cum, studentId) {
  const r = cum.rows.find((x) => x.studentId === studentId);
  if (!r) return null;
  return {
    session: cum.session, term: cum.term, termLabel: cum.termLabel, terms: cum.terms, isAnnual: cum.isAnnual, classSize: cum.classSize, passMark: cum.passMark,
    divisor: cum.divisor, method: cum.method, provisional: cum.provisional,
    subjects: cum.subjects.map((s, i) => ({ name: s.name, ...r.subjects[i], classAverage: cum.subjectStats[i].average })).filter((s) => s.taken > 0),
    termAverages: r.termAverages, thisTermAverage: r.thisTermAverage, thisTermPosition: r.thisTermPosition,
    cumulativeAverage: r.cumulativeAverage, cumulativePosition: r.cumulativePosition, ordinalCumulativePosition: r.cumulativePosition ? G.ordinal(r.cumulativePosition) : null,
    grade: r.grade, remark: r.remark, status: r.status, change: r.change, marksObtained: r.marksObtained, marksObtainable: r.marksObtainable,
    classAverage: cum.overall.average, summary: r.summary,
  };
}

module.exports = { classCumulative, forStudent, summarySentence, divisorOf, TERM_LABEL };
