'use strict';
// CBT server-side engine: shuffling, objective marking, result finalisation, and the validated push of CBT
// scores into the EXISTING result sheets (assessment_scores → recompute → broadsheet / report card).
const crypto = require('node:crypto');

function shuffle(arr) {                         // Fisher–Yates with CSPRNG
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) { const j = crypto.randomInt(i + 1); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}
const OPTION_TYPES = new Set(['mcq', 'multi_select', 'true_false']);
const norm = (s, cs) => { const t = String(s ?? '').normalize('NFKC').trim().replace(/\s+/g, ' '); return cs ? t : t.toLowerCase(); };
// questions that a person must mark (essay; short answer without an answer key)
const isManual = (q) => q.type === 'theory' || (q.type === 'short_answer' && !(q.answer_key && Array.isArray(q.answer_key.accepted) && q.answer_key.accepted.length));

// pure marking of one answer → true | false | null (null = needs a human)
function markAnswer(q, a, correctIds) {
  if (isManual(q)) return null;
  if (!a) return false;
  switch (q.type) {
    case 'mcq': case 'true_false': return !!(a.option_id && correctIds.has(a.option_id));
    case 'multi_select': {
      const chosen = new Set(a.option_ids || []); const want = [...correctIds];
      return chosen.size === want.length && want.every((id) => chosen.has(id));
    }
    case 'numeric': {
      const k = q.answer_key || {}; const v = Number(String(a.text_answer ?? '').replace(/,/g, '').replace(/\s+/g, ''));
      if (a.text_answer === null || a.text_answer === undefined || String(a.text_answer).trim() === '' || !Number.isFinite(v)) return false;
      return Math.abs(v - Number(k.value)) <= Math.abs(Number(k.tolerance) || 0) + 1e-9;
    }
    case 'short_answer': case 'fill_blank': {
      const k = q.answer_key || {}; const cs = !!k.caseSensitive;
      return (k.accepted || []).some((x) => norm(x, cs) === norm(a.text_answer, cs) && norm(a.text_answer, cs) !== '');
    }
    default: return false;
  }
}

// Server-side grading. Keys (cbt_options.is_correct, cbt_questions.answer_key) never reach candidates.
async function gradeAttempt(c, attemptId, { auto = false } = {}) {
  const at = (await c.query('SELECT * FROM cbt_attempts WHERE id = $1 FOR UPDATE', [attemptId])).rows[0];   // serialises concurrent submits
  if (!at || at.status !== 'in_progress') return at ? { ...at, _already: true } : null;
  const qs = (await c.query('SELECT id, type, marks, answer_key FROM cbt_questions WHERE id = ANY($1::uuid[])', [at.question_order])).rows;
  const answers = new Map((await c.query('SELECT question_id, option_id, option_ids, text_answer FROM cbt_answers WHERE attempt_id = $1', [attemptId])).rows.map((r) => [r.question_id, r]));
  const correct = new Map();
  for (const r of (await c.query('SELECT question_id, id FROM cbt_options WHERE question_id = ANY($1::uuid[]) AND is_correct', [at.question_order])).rows) {
    if (!correct.has(r.question_id)) correct.set(r.question_id, new Set()); correct.get(r.question_id).add(r.id);
  }
  let objective = 0; let max = 0; let manual = false;
  const updates = [];
  for (const q of qs) {
    max += Number(q.marks);
    const a = answers.get(q.id);
    const ok = markAnswer(q, a, correct.get(q.id) || new Set());
    if (ok === null) { manual = true; continue; }
    if (ok) objective += Number(q.marks);
    if (a) updates.push({ question_id: q.id, is_correct: ok, marks: ok ? Number(q.marks) : 0 });
  }
  if (updates.length) {
    await c.query(`UPDATE cbt_answers an SET is_correct = x.is_correct, marks_awarded = x.marks FROM json_to_recordset($2::json) AS x(question_id uuid, is_correct boolean, marks numeric)
      WHERE an.attempt_id = $1 AND an.question_id = x.question_id`, [attemptId, JSON.stringify(updates)]);
  }
  const status = manual ? (auto ? 'auto_submitted' : 'submitted') : (auto ? 'auto_submitted' : 'graded');
  await c.query(`UPDATE cbt_attempts SET status = $2::text, submitted_at = LEAST(now(), deadline_at + interval '30 seconds'), objective_score = $3::numeric, max_score = $4::numeric,
    score = CASE WHEN $5::boolean THEN NULL ELSE $3::numeric END, needs_manual_grading = $5::boolean WHERE id = $1`, [attemptId, status, objective, max, manual]);
  const done = (await c.query('SELECT * FROM cbt_attempts WHERE id = $1', [attemptId])).rows[0];
  if (!manual) await finalize(c, done);
  return done;
}
// write the authoritative, final result row (once per attempt). Released immediately only if the exam says so.
async function finalize(c, at) {
  const e = (await c.query('SELECT pass_mark, show_result FROM cbt_exams WHERE id = $1', [at.exam_id])).rows[0];
  const max = Number(at.max_score) || 0; const score = Number(at.score) || 0; const pct = max ? Math.round(score / max * 10000) / 100 : 0;
  await c.query(`INSERT INTO cbt_results (school_id, attempt_id, exam_id, student_id, score, max_score, percentage, passed, released, released_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9, CASE WHEN $9 THEN now() END)
    ON CONFLICT (attempt_id) DO UPDATE SET score = EXCLUDED.score, max_score = EXCLUDED.max_score, percentage = EXCLUDED.percentage, passed = EXCLUDED.passed, finalized_at = now()`,
  [at.school_id, at.id, at.exam_id, at.student_id, score, max, pct, pct >= Number(e.pass_mark), !!e.show_result]);
}

// Candidates of an exam: explicit list if present, otherwise the exam's class (current session), otherwise nobody.
async function candidateIds(c, exam) {
  const explicit = (await c.query('SELECT student_id FROM cbt_exam_candidates WHERE exam_id = $1', [exam.id])).rows.map((r) => r.student_id);
  if (explicit.length) return explicit;
  if (!exam.class_id) return [];
  return (await c.query(`SELECT en.student_id FROM student_enrollments en JOIN academic_sessions se ON se.id = en.session_id AND se.is_current JOIN students s ON s.id = en.student_id AND s.deleted_at IS NULL
    WHERE en.class_id = $1 AND en.status = 'active'`, [exam.class_id])).rows.map((r) => r.student_id);
}
async function isCandidate(c, exam, studentId, classId) {
  const n = (await c.query('SELECT count(*)::int AS n, bool_or(student_id = $2) AS me FROM cbt_exam_candidates WHERE exam_id = $1', [exam.id, studentId])).rows[0];
  if (n.n > 0) return !!n.me;
  return !exam.class_id || exam.class_id === classId;      // legacy: class-wide (or open to all when no class set)
}

// derived lifecycle label used by dashboards/filters
function lifecycle(e, now = new Date()) {
  if (e.status === 'draft') return 'draft';
  if (e.status === 'closed') return 'completed';
  if (e.starts_at && new Date(e.starts_at) > now) return 'scheduled';
  if (e.ends_at && new Date(e.ends_at) <= now) return 'completed';
  return 'active';
}

module.exports = { shuffle, gradeAttempt, finalize, markAnswer, isManual, candidateIds, isCandidate, lifecycle, OPTION_TYPES };
