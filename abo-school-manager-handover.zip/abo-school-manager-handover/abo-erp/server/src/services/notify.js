'use strict';
// In-app notifications + email outbox (sent by the worker via SMTP; see services/mailer.js).
async function notify(client, schoolId, userIds, { kind, title, body = null, link = null }) {
  const ids = [...new Set((userIds || []).filter(Boolean))];
  if (!ids.length) return 0;
  await client.query(`INSERT INTO notifications (school_id, user_id, kind, title, body, link)
    SELECT $1, u, $3, $4, $5, $6 FROM unnest($2::uuid[]) AS u`, [schoolId, ids, kind, String(title).slice(0, 160), body && String(body).slice(0, 1000), link]);
  return ids.length;
}
async function queueEmail(client, { schoolId = null, to, subject, body, template = null }) {
  if (!to) return null;
  const r = await client.query(`INSERT INTO outbox_emails (school_id, to_address, subject, body_text, template) VALUES ($1,$2,$3,$4,$5) RETURNING id`,
    [schoolId, String(to).slice(0, 160), String(subject).slice(0, 200), String(body).slice(0, 20000), template]);
  await client.query(`INSERT INTO jobs (school_id, kind, payload) VALUES ($1, 'email.send', $2)`, [schoolId, { emailId: r.rows[0].id }]);
  return r.rows[0].id;
}
async function enqueue(client, { schoolId = null, kind, payload = {}, createdBy = null, runAt = null }) {
  const r = await client.query(`INSERT INTO jobs (school_id, kind, payload, created_by, run_at) VALUES ($1,$2,$3,$4,COALESCE($5, now())) RETURNING id`,
    [schoolId, kind, payload, createdBy, runAt]);
  return r.rows[0].id;
}
module.exports = { notify, queueEmail, enqueue };
