'use strict';
// Demo schools for advertising and demonstrations.
//
// • Two independent demo schools (a primary/nursery school and a secondary school), each a normal tenant: their data is
//   isolated by the same Row-Level Security as every customer school, and they are flagged schools.is_demo.
// • Demo accounts have NO password (nobody can sign in to them with the normal form). A visitor presses "Try the demo"
//   and gets a session that the SERVER ends after at most 5 minutes (platform setting 1–5). The countdown in the page is
//   only a display — the session's expiry is enforced on every request.
// • In a demo session the dangerous permissions are removed (logins, roles, school settings, exports/imports, money
//   reversal, audit/security views, sign-in-as, billing…) and those API areas are refused outright.
// • When a demo school was changed and nobody is using it any more, the worker deletes it and builds it again from the
//   sample data below, so the next visitor always sees the original demo. Real schools are never touched: the reset only
//   ever deletes rows of a school whose is_demo flag is true (checked in the DELETE itself).
const crypto = require('node:crypto');
const { withTx, raw } = require('../db/pool');
const { createSchool } = require('./provision');
const R = require('./results');
const S = require('../auth/sessions');
const { E } = require('../lib/errors');

const DEMOS = [
  { key: 'primary', slug: 'demo-sunrise', name: 'Sunrise Nursery & Primary School', type: 'primary', prefix: 'demo1', motto: 'Learning with joy',
    address: '24 Allen Avenue, Ikeja, Lagos', head: 'Mrs Bisola Adeyemi',
    classes: [['Creche', '', 'nursery', 'Creche'], ['Nursery 1', '', 'nursery', 'Nursery'], ['Nursery 2', '', 'nursery', 'Nursery'], ['Kindergarten', '', 'nursery', 'Kindergarten'],
      ['Primary 1', 'A', 'primary', 'Primary'], ['Primary 1', 'B', 'primary', 'Primary'], ['Primary 4', '', 'primary', 'Primary'], ['Primary 6', '', 'primary', 'Primary']],
    subjects: ['English Language', 'Mathematics', 'Basic Science', 'Social Studies', 'Civic Education', 'Computer Studies', 'Yoruba', 'Creative Arts'] },
  { key: 'secondary', slug: 'demo-unity', name: 'Unity College', type: 'secondary', prefix: 'demo2', motto: 'Excellence and integrity',
    address: '7 Ring Road, Ibadan, Oyo State', head: 'Dr Emeka Nwosu',
    classes: [['JSS 1', 'A', 'secondary', 'JSS'], ['JSS 1', 'B', 'secondary', 'JSS'], ['JSS 2', '', 'secondary', 'JSS'], ['JSS 3', '', 'secondary', 'JSS'],
      ['SS 1', 'Science', 'secondary', 'SS'], ['SS 1', 'Arts', 'secondary', 'SS'], ['SS 2', '', 'secondary', 'SS'], ['SS 3', '', 'secondary', 'SS']],
    subjects: ['English Language', 'Mathematics', 'Basic Science', 'Physics', 'Chemistry', 'Biology', 'Economics', 'Civic Education'] },
];
// the people a visitor can try the demo as (no owner: owner controls are never part of a demo)
const AS = { admin: 'admin', teacher: 'teacher1', parent: 'parent', student: 'student' };
// removed from every demo session (UX + API: `req.can` is false, and these URL areas are refused)
const DEMO_BLOCKED_PERMS = ['users.view', 'roles.view', 'users.create', 'users.update', 'users.disable', 'users.assign_role', 'users.impersonate', 'roles.manage', 'settings.update', 'settings.branding',
  'imports.run', 'reports.export', 'audit_logs.view', 'security.view', 'promotion.run', 'students.delete', 'teachers.delete', 'staff.delete', 'documents.delete', 'documents.upload',
  'payments.reverse', 'fees.approve', 'cashbook.void', 'store.void', 'ai.use'];
const DEMO_BLOCKED_URL = /^\/api\/v1\/(auth\/(mfa|password|switch-school|logout-all|sessions|memberships|act-as|passkeys)|users|roles|platform|billing|exports|imports|backup|migration|school\/(settings|web-address)|files\/upload|clock\/passkeys)(\/|\?|$)/;

const FIRST = ['Ada', 'Tunde', 'Chioma', 'Emeka', 'Fatima', 'Ibrahim', 'Kemi', 'Segun', 'Ngozi', 'Bola', 'Zainab', 'David', 'Amaka', 'Yusuf', 'Funmi', 'Obinna', 'Halima', 'Tobi', 'Grace', 'Musa', 'Temi', 'Uche'];
const LAST = ['Okafor', 'Bello', 'Adeyemi', 'Eze', 'Abubakar', 'Ogunleye', 'Nwosu', 'Ibrahim', 'Balogun', 'Okeke', 'Afolabi', 'Danjuma', 'Olawale', 'Chukwu'];

// ── which schools are demo schools (cached; refreshed every 30 s and after a reset) ──
let cache = { at: 0, ids: new Set(), slugs: new Map() };
async function refresh(force = false) {
  if (!force && Date.now() - cache.at < 30000) return cache;
  const rows = (await raw('SELECT * FROM app.demo_school_ids()')).rows;
  cache = { at: Date.now(), ids: new Set(rows.map((r) => r.id)), slugs: new Map(rows.map((r) => [r.slug, r.id])) };
  return cache;
}
const isDemoSchool = async (id) => !!id && (await refresh()).ids.has(id);
const isDemoSchoolCached = (id) => !!id && cache.ids.has(id);

// ── build one demo school from the sample data (no passwords anywhere) ──
async function seedDemo(def) {
  const schoolId = crypto.randomUUID();
  return withTx({ schoolId }, async (c) => {
    const roleIds = await createSchool(c, { id: schoolId, slug: def.slug, name: def.name, schoolType: def.type, address: def.address, phone: '0800 000 0000', email: `hello@${def.slug}.example`, motto: def.motto, status: 'active' });
    await c.query('UPDATE schools SET email_verified_at = now(), is_demo = true, head_name = $2, demo_reset_at = now(), demo_dirty_at = NULL WHERE id = $1', [schoolId, def.head]);
    const user = async (suffix, name, roles, email) => {
      const u = (await c.query('INSERT INTO users (school_id, login_id, full_name, email, password_hash) VALUES ($1,$2,$3,$4,NULL) RETURNING id', [schoolId, `${def.prefix}.${suffix}`, name, email || null])).rows[0];
      await c.query("INSERT INTO school_memberships (user_id, school_id, status, is_default) VALUES ($1,$2,'active',true)", [u.id, schoolId]);
      for (const r of roles) await c.query('INSERT INTO user_roles (school_id, user_id, role_id) VALUES ($1,$2,$3)', [schoolId, u.id, roleIds[r]]);
      return u.id;
    };
    const admin = await user('admin', 'Mr Kunle Adebayo', ['administrator']);
    const t1 = await user('teacher1', 'Mr Tunde Bello', ['teacher', 'form_teacher']);
    const t2 = await user('teacher2', 'Mrs Ngozi Okeke', ['teacher']);
    const staff1 = (await c.query("INSERT INTO staff (school_id, user_id, full_name, employee_id, gender, designation, phone) VALUES ($1,$2,'Mr Tunde Bello','ST001','Male','Class Teacher','08030000101') RETURNING id", [schoolId, t1])).rows[0].id;
    const staff2 = (await c.query("INSERT INTO staff (school_id, user_id, full_name, employee_id, gender, designation, phone) VALUES ($1,$2,'Mrs Ngozi Okeke','ST002','Female','Subject Teacher','08030000102') RETURNING id", [schoolId, t2])).rows[0].id;
    await c.query("INSERT INTO staff (school_id, user_id, full_name, employee_id, gender, designation, is_teacher) VALUES ($1,$2,'Mr Kunle Adebayo','ST003','Male','Administrator', false)", [schoolId, admin]);
    const sess = (await c.query("INSERT INTO academic_sessions (school_id, name, starts_on, ends_on, is_current) VALUES ($1,'2025/2026','2025-09-08','2026-07-24',true) RETURNING id", [schoolId])).rows[0].id;
    const termIds = {};
    for (const t of ['1ST', '2ND', '3RD']) termIds[t] = (await c.query('INSERT INTO terms (school_id, session_id, name, is_current, days_open, next_term_begins) VALUES ($1,$2,$3,$4,62,$5) RETURNING id', [schoolId, sess, t, t === '2ND', t === '2ND' ? '2026-04-20' : null])).rows[0].id;
    const subj = {};
    for (const s of def.subjects) subj[s] = (await c.query('INSERT INTO subjects (school_id, name) VALUES ($1,$2) RETURNING id', [schoolId, s])).rows[0].id;
    const classes = [];
    for (const [i, [n, arm, section, level]] of def.classes.entries()) {
      const cl = (await c.query('INSERT INTO classes (school_id, name, arm, section, level, form_teacher_id, sort_order) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id, display_name',
        [schoolId, n.toUpperCase(), arm.toUpperCase(), section, level, i === 4 || (def.type === 'secondary' && i === 0) ? staff1 : null, i])).rows[0];
      classes.push(cl);
      for (const [j, s] of def.subjects.entries()) await c.query('INSERT INTO class_subjects (school_id, class_id, subject_id, teacher_id) VALUES ($1,$2,$3,$4)', [schoolId, cl.id, subj[s], j % 2 === 0 ? staff1 : staff2]);
    }
    const main = def.type === 'secondary' ? classes[0] : classes[4];      // the class with results, pupils on the portal, notes…
    let n = 0; const students = [];
    for (const cl of classes) {
      const count = cl === main ? 10 : 4;
      for (let i = 0; i < count; i++) {
        n++;
        const s = (await c.query(`INSERT INTO students (school_id, admission_no, first_name, last_name, gender, date_of_birth, admission_date) VALUES ($1,$2,$3,$4,$5,$6,'2025-09-08') RETURNING id, first_name, last_name`,
          [schoolId, `${def.prefix.toUpperCase()}/${String(n).padStart(4, '0')}`, FIRST[(n * 5) % FIRST.length], LAST[(n * 7) % LAST.length], n % 2 ? 'Female' : 'Male', `${def.type === 'secondary' ? 2011 : 2017}-0${(n % 9) + 1}-1${n % 9}`])).rows[0];
        await c.query('INSERT INTO student_enrollments (school_id, student_id, class_id, session_id, roll_no) VALUES ($1,$2,$3,$4,$5)', [schoolId, s.id, cl.id, sess, i + 1]);
        students.push({ ...s, classId: cl.id });
        const g = (await c.query("INSERT INTO guardians (school_id, full_name, relationship, phone, email) VALUES ($1,$2,$3,$4,$5) RETURNING id", [schoolId, `${n % 2 ? 'Mrs' : 'Mr'} ${s.last_name}`, n % 2 ? 'Mother' : 'Father', `0803${String(10000000 + n).slice(1)}`, `parent${n}@${def.slug}.example`])).rows[0];
        await c.query('INSERT INTO student_guardians (school_id, student_id, guardian_id, is_primary) VALUES ($1,$2,$3,true)', [schoolId, s.id, g.id]);
      }
    }
    const roster = students.filter((s) => s.classId === main.id);
    const st0 = roster[0];
    const studentUser = await user('student', `${st0.first_name} ${st0.last_name}`, ['student']);
    await c.query('UPDATE students SET user_id = $2 WHERE id = $1', [st0.id, studentUser]);
    const parentUser = await user('parent', `Mrs ${st0.last_name}`, ['parent'], `parent@${def.slug}.example`);
    const pg = (await c.query("INSERT INTO guardians (school_id, user_id, full_name, relationship, phone, email) VALUES ($1,$2,$3,'Mother','08030000001',$4) RETURNING id", [schoolId, parentUser, `Mrs ${st0.last_name}`, `parent@${def.slug}.example`])).rows[0];
    await c.query('INSERT INTO student_guardians (school_id, student_id, guardian_id, is_primary) VALUES ($1,$2,$3,false)', [schoolId, st0.id, pg.id]);
    // results: 1st and 2nd term scored and published for the main class (cumulative results and report cards have data)
    const st = await R.settings(c);
    for (const [ti, tid] of [termIds['1ST'], termIds['2ND']].entries()) {
      for (const [si, sname] of def.subjects.entries()) {
        const sh = (await c.query('INSERT INTO assessments (school_id, term_id, class_id, subject_id, components, created_by) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id', [schoolId, tid, main.id, subj[sname], JSON.stringify(st.assessment_components), t1])).rows[0].id;
        for (const [ri, r] of roster.entries()) {
          const hv = (ri * 31 + si * 17 + ti * 11 + ri * si * 3 + ri * ri * 5) % 97;
          for (const [k, v] of [['ca1', 8 + (hv % 13)], ['ca2', 7 + ((hv * 7) % 14)], ['exam', 22 + ((hv * 11 + ri * 3) % 39)]]) {
            await c.query('INSERT INTO assessment_scores (school_id, sheet_id, student_id, component_key, score, entered_by) VALUES ($1,$2,$3,$4,$5,$6)', [schoolId, sh, r.id, k, v, t1]);
          }
        }
        await R.recomputeSheet(c, sh);
        await c.query("UPDATE assessments SET status = 'published', submitted_by = $2, submitted_at = now(), reviewed_by = $3, reviewed_at = now(), approved_by = $3, approved_at = now(), published_by = $3, published_at = now() WHERE id = $1", [sh, t1, admin]);
      }
      await R.computeClassTerm(c, tid, main.id, { publish: true });
      await c.query('INSERT INTO report_cards (school_id, term_id, student_id, teacher_comment, head_comment) SELECT $1, $2, s.id, $3, $4 FROM unnest($5::uuid[]) AS s(id)',
        [schoolId, tid, ti === 0 ? 'A good start to the session. Keep working hard.' : 'Steady progress this term. Keep it up.', 'Well done. Aim higher next term.', roster.map((r) => r.id)]);
    }
    // fees, notices, lesson note
    const cat = async (code) => (await c.query('SELECT id FROM fee_categories WHERE code = $1', [code])).rows[0].id;
    await c.query("INSERT INTO fee_structures (school_id, name, category_id, amount_kobo, term_id) VALUES ($1,'Tuition — 2nd Term',$3,$5,$2), ($1,'Development Levy',$4,1500000,NULL)",
      [schoolId, termIds['2ND'], await cat('tuition'), await cat('development'), def.type === 'secondary' ? 12000000 : 8500000]);
    await c.query("INSERT INTO announcements (school_id, title, body, audience, priority, pinned, created_by) VALUES ($1,'Welcome to the 2nd term','Resumption is Monday 8:00am. Pupils should come in full uniform with their books.','all','important',true,$2), ($1,'PTA meeting','The PTA meeting holds on Saturday at 10am in the school hall. All parents are welcome.','parents','normal',false,$2)", [schoolId, admin]);
    await c.query(`INSERT INTO lesson_notes (school_id, term_id, class_id, subject_id, staff_id, author_id, week, duration, topic, objectives, content, evaluation, status, submitted_at, reviewed_by, reviewed_at)
      VALUES ($1,$2,$3,$4,$5,$6,1,'40 minutes','Parts of Speech: Nouns','Pupils should be able to define a noun and give examples.','A noun is the name of a person, animal, place or thing. Common and proper nouns with examples from the classroom.','What is a noun? Give five examples.','approved', now(), $7, now())`,
    [schoolId, termIds['2ND'], main.id, subj['English Language'], staff1, t1, admin]);
    return { schoolId, slug: def.slug };
  });
}

// create any missing demo school (called before a demo starts, and by `node scripts/seed-demo.js`)
async function ensureDemoSchools() {
  const have = await refresh(true);
  const out = [];
  for (const def of DEMOS) {
    if (have.slugs.has(def.slug)) continue;
    const taken = (await raw('SELECT app.school_slug_taken($1) AS t', [def.slug])).rows[0].t;
    if (taken) throw new Error(`The address ${def.slug} is used by a real school — demo schools need it. Rename that school or change DEMOS in services/demo.js.`);
    out.push(await seedDemo(def));
  }
  if (out.length) await refresh(true);
  return out;
}

// delete + rebuild a demo school. The DELETE is guarded by is_demo, so a real school can never be reset.
async function resetDemoSchool(slug) {
  const def = DEMOS.find((d) => d.slug === slug); if (!def) throw new Error('not a demo school');
  const sc = (await withTx({ platform: true, readOnly: true }, (c) => c.query('SELECT id FROM schools WHERE slug = $1 AND is_demo', [slug]))).rows[0];
  const done = !sc ? true : await withTx({ schoolId: sc.id }, async (c) => {     // inside the demo school's own tenant
    if (!(await c.query('SELECT pg_try_advisory_xact_lock(hashtextextended($1, 0)) AS ok', [`demo-reset:${slug}`])).rows[0].ok) return false;
    const busy = (await c.query('SELECT 1 FROM sessions WHERE school_id = $1 AND revoked_at IS NULL AND expires_at > now() LIMIT 1', [sc.id])).rowCount;
    if (busy) return false;
    await c.query("SELECT set_config('app.demo_reset', 'on', true)");
    const r = await c.query('DELETE FROM schools WHERE id = $1 AND is_demo', [sc.id]);
    return r.rowCount === 1;
  });
  if (!done) return false;
  await refresh(true);
  await seedDemo(def);
  await refresh(true);
  return true;
}

// worker: rebuild demo schools that were changed and are no longer in use
async function resetIdleDemos(log = () => {}) {
  const rows = (await withTx({ platform: true }, (c) => c.query(`SELECT s.slug FROM schools s WHERE s.is_demo AND s.demo_dirty_at IS NOT NULL
    AND NOT EXISTS (SELECT 1 FROM sessions x WHERE x.school_id = s.id AND x.revoked_at IS NULL AND x.expires_at > now())`))).rows;
  let n = 0;
  for (const r of rows) { try { if (await resetDemoSchool(r.slug)) { n++; log('demo school restored', { slug: r.slug }); } } catch (e) { log('demo reset failed', { slug: r.slug, error: e.message }); } }
  return n;
}

// changed by a demo visitor → restore after the last visitor leaves (at most one write per school per 10 s)
const dirtyAt = new Map();
async function markDirty(schoolId) {
  if (!isDemoSchoolCached(schoolId)) return;
  const last = dirtyAt.get(schoolId) || 0; if (Date.now() - last < 10000) return;
  dirtyAt.set(schoolId, Date.now());
  await withTx({ platform: true }, (c) => c.query('UPDATE schools SET demo_dirty_at = now() WHERE id = $1 AND is_demo', [schoolId])).catch(() => {});
}

// start a demo session for a visitor: returns the session token (cookie) and when it ends
async function startDemo({ school, as, ip, ua }) {
  const st = (await raw('SELECT * FROM app.demo_settings()')).rows[0] || { demo_enabled: false, demo_minutes: 5 };
  if (!st.demo_enabled) throw E.notFound('Demo');
  const def = DEMOS.find((d) => d.key === school); if (!def || !AS[as]) throw E.bad('Choose a demo school and who you want to be.');
  await ensureDemoSchools();
  const schoolId = (await refresh()).slugs.get(def.slug); if (!schoolId) throw E.notFound('Demo school');
  const minutes = Math.min(5, Math.max(1, Number(st.demo_minutes) || 5));
  return withTx({ schoolId }, async (c) => {
    const live = (await c.query('SELECT count(*)::int AS n FROM sessions WHERE school_id = $1 AND demo AND revoked_at IS NULL AND expires_at > now()', [schoolId])).rows[0].n;
    if (live >= 300) throw new (require('../lib/errors').AppError)(503, 'BUSY', 'Many people are trying the demo right now. Please try again in a minute.');
    const u = (await c.query('SELECT id FROM users WHERE school_id = $1 AND login_id = $2 AND status = \'active\'', [schoolId, `${def.prefix}.${AS[as]}`])).rows[0];
    if (!u) throw E.notFound('Demo account');
    const { token, sessionId } = await S.createSession(c, { userId: u.id, schoolId, mfaState: 'none', ip, ua });
    const r = (await c.query(`UPDATE sessions SET demo = true, expires_at = now() + make_interval(mins => $2), idle_expires_at = now() + make_interval(mins => $2) WHERE id = $1 RETURNING expires_at`, [sessionId, minutes])).rows[0];
    return { token, sessionId, expiresAt: r.expires_at, minutes, school: { name: def.name, slug: def.slug } };
  });
}

// demo links (028): only a hash of the code is stored
const passHash = (code) => crypto.createHash('sha256').update(`abo-demo-pass:${String(code).trim().toUpperCase()}`).digest('hex');
function newPassCode() { const A = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'; const b = crypto.randomBytes(12); let s = ''; for (let i = 0; i < 12; i++) { s += A[b[i] % A.length]; if (i === 3 || i === 7) s += '-'; } return `DEMO-${s}`; }
module.exports = { passHash, newPassCode, DEMOS, AS, DEMO_BLOCKED_PERMS, DEMO_BLOCKED_URL, refresh, isDemoSchool, isDemoSchoolCached, ensureDemoSchools, resetDemoSchool, resetIdleDemos, markDirty, startDemo, seedDemo };
