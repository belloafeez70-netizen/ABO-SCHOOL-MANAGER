'use strict';
// Tenant provisioning: school row, default settings, system roles (from templates) and the owner account.
// Runs inside a transaction whose app.school_id is the NEW school's id, so RLS WITH CHECK applies.
const { ROLE_TEMPLATES } = require('../rbac/catalog');
const { DEFAULT_GRADING, DEFAULT_COMPONENTS } = require('./grading');

async function seedRoles(client, schoolId) {
  const ids = {};
  for (const t of ROLE_TEMPLATES) {
    const r = await client.query(`INSERT INTO roles (school_id, key, name, is_system, mfa_required, portal) VALUES ($1,$2,$3,true,$4,$5)
      ON CONFLICT (school_id, key) DO UPDATE SET name = EXCLUDED.name RETURNING id`, [schoolId, t.key, t.name, !!t.mfa, t.portal || 'staff']);
    ids[t.key] = r.rows[0].id;
    await client.query(`INSERT INTO role_permissions (school_id, role_id, permission_key) SELECT $1, $2, unnest($3::text[]) ON CONFLICT DO NOTHING`,
      [schoolId, ids[t.key], t.perms]);
  }
  return ids;
}
async function createSchool(client, { id, slug, name, schoolType, address, phone, email, website, motto, registrationNumber, status = 'pending' }) {
  await client.query(`INSERT INTO schools (id, slug, name, school_type, address, phone, email, website, motto, registration_number, status)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`, [id, slug, name, schoolType, address || null, phone || null, email || null, website || null, motto || null, registrationNumber || null, status]);
  await client.query(`INSERT INTO school_settings (school_id, grading, onboarding) VALUES ($1,$2,$3)`, [id, DEFAULT_GRADING, { step: 'profile', completed: [] }]);
  await require('../routes/cashbook').ensureDefaults(client, id);   // starter cashbook categories
  for (const [i, c] of DEFAULT_COMPONENTS.entries()) {
    await client.query('INSERT INTO assessment_components (school_id, key, label, max_score, is_exam, position) VALUES ($1,$2,$3,$4,$5,$6)', [id, c.key, c.label, c.max, c.key === 'exam', i]);
  }
  await client.query(`INSERT INTO fee_categories (school_id, code, name) SELECT $1, c.code, c.name FROM (VALUES ('tuition','Tuition'),('development','Development levy'),('uniform','Uniform'),
    ('books','Books'),('transport','Transport'),('exam','Examination'),('ict','ICT / Computer'),('feeding','Feeding'),('boarding','Boarding'),('other','Other')) AS c(code, name)`, [id]);
  // every new school starts on the platform's free trial (only the platform can activate or extend it — see 026 RLS)
  await client.query(`INSERT INTO school_subscriptions (school_id, status, trial_ends_at) VALUES ($1, 'trial', now() + make_interval(days => COALESCE(app.platform_trial_days(), 14))) ON CONFLICT DO NOTHING`, [id]);
  return seedRoles(client, id);
}
module.exports = { createSchool, seedRoles };
