'use strict';
// Object storage abstraction. Files are NEVER served from a public path: downloads go through an
// authorised API route which streams (local driver) or 302-redirects to a 60-second presigned URL (S3).
//   local – STORAGE_DIR on disk (development / single-node)
//   s3    – any S3-compatible private bucket (AWS S3, Cloudflare R2, Backblaze B2, MinIO, DO Spaces)
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const net = require('node:net');
const config = require('../config');

// ── content sniffing: trust magic bytes, not the client's filename / Content-Type ──
const SIGS = [
  { mime: 'image/png', ext: 'png', test: (b) => b.length > 8 && b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) },
  { mime: 'image/jpeg', ext: 'jpg', test: (b) => b.length > 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff },
  { mime: 'image/gif', ext: 'gif', test: (b) => b.length > 6 && /^GIF8[79]a/.test(b.subarray(0, 6).toString('latin1')) },
  { mime: 'image/webp', ext: 'webp', test: (b) => b.length > 12 && b.subarray(0, 4).toString('latin1') === 'RIFF' && b.subarray(8, 12).toString('latin1') === 'WEBP' },
  { mime: 'application/pdf', ext: 'pdf', test: (b) => b.length > 5 && b.subarray(0, 5).toString('latin1') === '%PDF-' },
  { mime: 'application/zip', ext: 'zip', test: (b) => b.length > 4 && b[0] === 0x50 && b[1] === 0x4b && b[2] === 0x03 && b[3] === 0x04 },
];
function sniff(buf, originalName = '') {
  for (const s of SIGS) if (s.test(buf)) {
    if (s.mime === 'application/zip') {                    // OOXML containers
      const ext = path.extname(originalName).toLowerCase();
      if (ext === '.docx') return { mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', ext: 'docx' };
      if (ext === '.xlsx') return { mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', ext: 'xlsx' };
      if (ext === '.pptx') return { mime: 'application/vnd.openxmlformats-officedocument.presentationml.presentation', ext: 'pptx' };
      return { mime: 'application/zip', ext: 'zip' };
    }
    return { mime: s.mime, ext: s.ext };
  }
  // CSV / plain text: must be valid UTF-8 with no NUL bytes and not look like HTML/SVG/script
  const head = buf.subarray(0, 4096);
  if (!head.includes(0) && /\.(csv|txt)$/i.test(originalName)) {
    const t = head.toString('utf8');
    if (!/<\s*(script|html|svg|iframe|!doctype)/i.test(t)) return { mime: /\.csv$/i.test(originalName) ? 'text/csv' : 'text/plain', ext: /\.csv$/i.test(originalName) ? 'csv' : 'txt' };
  }
  return null;
}
const PURPOSE_RULES = {
  logo: ['image/png', 'image/jpeg', 'image/webp'],              // SVG deliberately NOT allowed (script-capable)
  passport: ['image/png', 'image/jpeg', 'image/webp'],
  signature: ['image/png', 'image/jpeg', 'image/webp'],
  cbt_image: ['image/png', 'image/jpeg', 'image/webp', 'image/gif'],
  document: ['application/pdf', 'image/png', 'image/jpeg', 'image/webp',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation'],
  lesson_note: ['application/pdf', 'image/png', 'image/jpeg', 'image/webp',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation'],
  study_material: ['application/pdf', 'image/png', 'image/jpeg', 'image/webp',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation'],
  import: ['text/csv', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'text/plain'],
  export: ['text/csv', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
};
const PURPOSE_MAX = { logo: 1.5 * 1024 * 1024, passport: 1024 * 1024, signature: 512 * 1024, cbt_image: 1024 * 1024 };
const safeName = (n) => String(n || 'file').normalize('NFKC').replace(/[^\w.\- ]+/g, '_').replace(/^\.+/, '').slice(0, 120) || 'file';

// ── optional ClamAV (clamd INSTREAM protocol) ──
function clamScan(buf) {
  const { host, port } = config.storage.clamav;
  if (!host) return Promise.resolve('skipped');
  return new Promise((resolve) => {
    const sock = net.createConnection({ host, port });
    let out = '';
    sock.setTimeout(15000, () => { sock.destroy(); resolve('error'); });
    sock.on('error', () => resolve('error'));
    sock.on('connect', () => {
      sock.write('zINSTREAM\0');
      for (let i = 0; i < buf.length; i += 64 * 1024) {
        const chunk = buf.subarray(i, i + 64 * 1024); const len = Buffer.alloc(4); len.writeUInt32BE(chunk.length); sock.write(len); sock.write(chunk);
      }
      sock.write(Buffer.alloc(4));
    });
    sock.on('data', (d) => { out += d.toString(); });
    sock.on('end', () => resolve(/OK\0?$/.test(out.trim()) ? 'clean' : /FOUND/.test(out) ? 'infected' : 'error'));
  });
}

// ── AWS Signature V4 (query-string presign + header-signed PUT/DELETE) ──
const hmacRaw = (k, s) => crypto.createHmac('sha256', k).update(s).digest();
const hex = (b) => crypto.createHash('sha256').update(b).digest('hex');
const enc = (s) => encodeURIComponent(s).replace(/[!'()*]/g, (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase());
function sigKey(secret, date, region) { return hmacRaw(hmacRaw(hmacRaw(hmacRaw('AWS4' + secret, date), region), 's3'), 'aws4_request'); }
function s3Target(s3, key) {
  const ep = new URL(s3.endpoint || `https://s3.${s3.region}.amazonaws.com`);
  const k = key.split('/').map(enc).join('/');
  // keep a path in the endpoint (Supabase Storage: https://<ref>.storage.supabase.co/storage/v1/s3)
  const pre = ep.pathname.replace(/\/+$/, '');
  return s3.forcePathStyle ? { host: ep.host, path: `${pre}/${s3.bucket}/${k}`, proto: ep.protocol } : { host: `${s3.bucket}.${ep.host}`, path: `${pre}/${k}`, proto: ep.protocol };
}
// exported for tests
function presign(s3, method, key, expires = 60, now = new Date(), extraQuery = {}) {
  const t = s3Target(s3, key);
  const amz = now.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, ''); const d = amz.slice(0, 8);
  const scope = `${d}/${s3.region}/s3/aws4_request`;
  const q = { 'X-Amz-Algorithm': 'AWS4-HMAC-SHA256', 'X-Amz-Credential': `${s3.accessKeyId}/${scope}`, 'X-Amz-Date': amz, 'X-Amz-Expires': String(expires), 'X-Amz-SignedHeaders': 'host', ...extraQuery };
  const qs = Object.keys(q).sort().map((k) => `${enc(k)}=${enc(q[k])}`).join('&');
  const canon = [method, t.path, qs, `host:${t.host}\n`, 'host', 'UNSIGNED-PAYLOAD'].join('\n');
  const sts = ['AWS4-HMAC-SHA256', amz, scope, hex(canon)].join('\n');
  const sig = crypto.createHmac('sha256', sigKey(s3.secretAccessKey, d, s3.region)).update(sts).digest('hex');
  return `${t.proto}//${t.host}${t.path}?${qs}&X-Amz-Signature=${sig}`;
}
async function s3Request(s3, method, key, body, contentType) {
  const t = s3Target(s3, key);
  const amz = new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, ''); const d = amz.slice(0, 8);
  const scope = `${d}/${s3.region}/s3/aws4_request`;
  const payloadHash = hex(body || Buffer.alloc(0));
  const headers = { host: t.host, 'x-amz-content-sha256': payloadHash, 'x-amz-date': amz, ...(contentType ? { 'content-type': contentType } : {}) };
  const names = Object.keys(headers).sort();
  const canon = [method, t.path, '', names.map((n) => `${n}:${headers[n]}\n`).join(''), names.join(';'), payloadHash].join('\n');
  const sts = ['AWS4-HMAC-SHA256', amz, scope, hex(canon)].join('\n');
  const sig = crypto.createHmac('sha256', sigKey(s3.secretAccessKey, d, s3.region)).update(sts).digest('hex');
  const res = await fetch(`${t.proto}//${t.host}${t.path}`, { method, body, headers: { ...headers, authorization: `AWS4-HMAC-SHA256 Credential=${s3.accessKeyId}/${scope}, SignedHeaders=${names.join(';')}, Signature=${sig}` } });
  if (!res.ok && !(method === 'DELETE' && res.status === 404)) throw new Error(`object storage ${method} failed (${res.status})`);
  return res;
}

const drivers = {
  local: {
    async put(key, buf) { const p = path.join(config.storage.dir, key); await fsp.mkdir(path.dirname(p), { recursive: true, mode: 0o700 }); await fsp.writeFile(p, buf, { mode: 0o600 }); },
    async stream(key) { const p = path.join(config.storage.dir, key); if (!p.startsWith(path.resolve(config.storage.dir))) throw new Error('bad key'); return fs.createReadStream(p); },
    async read(key) { return fsp.readFile(path.join(config.storage.dir, key)); },
    async del(key) { await fsp.rm(path.join(config.storage.dir, key), { force: true }); },
    signedUrl: null,
  },
  s3: {
    put: (key, buf, mime) => s3Request(config.storage.s3, 'PUT', key, buf, mime),
    async read(key) { const r = await s3Request(config.storage.s3, 'GET', key); return Buffer.from(await r.arrayBuffer()); },
    // stream through the API (default): same-origin for the Netlify-hosted app, so no bucket CORS / CSP exceptions needed
    async stream(key) { const r = await s3Request(config.storage.s3, 'GET', key); return require('node:stream').Readable.fromWeb(r.body); },
    del: (key) => s3Request(config.storage.s3, 'DELETE', key),
    signedUrl: (key, name, mime) => presign(config.storage.s3, 'GET', key, 60, new Date(), {
      'response-content-disposition': `attachment; filename="${safeName(name)}"`, 'response-content-type': mime }),
  },
};
const driver = () => drivers[config.storage.driver] || drivers.local;

// Validate + store an upload. Returns the uploads row. Caller supplies a tenant transaction client.
async function saveUpload(client, { schoolId, userId, purpose, buffer, originalName }) {
  const { E } = require('../lib/errors');
  if (!buffer || !buffer.length) throw E.bad('The file is empty.');
  const max = PURPOSE_MAX[purpose] || config.storage.maxUploadBytes;
  if (buffer.length > max) throw E.bad(`The file is too large (max ${(max / 1024 / 1024).toFixed(1)} MB).`);
  const kind = sniff(buffer, originalName);
  if (!kind || !(PURPOSE_RULES[purpose] || []).includes(kind.mime)) throw E.bad('This file type is not allowed here.');
  const scan = await clamScan(buffer);
  if (scan === 'infected') throw E.bad('The file failed the malware scan.');
  const id = crypto.randomUUID();
  const now = new Date();
  const key = `${schoolId || 'platform'}/${purpose}/${now.getUTCFullYear()}/${String(now.getUTCMonth() + 1).padStart(2, '0')}/${id}.${kind.ext}`;
  await driver().put(key, buffer, kind.mime);
  const r = await client.query(`INSERT INTO uploads (id, school_id, storage_key, original_name, mime, size_bytes, sha256, purpose, scan_status, uploaded_by)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id, original_name, mime, size_bytes, purpose, scan_status, created_at`,
  [id, schoolId, key, safeName(originalName), kind.mime, buffer.length, crypto.createHash('sha256').update(buffer).digest('hex'), purpose, scan, userId]);
  return r.rows[0];
}
module.exports = { sniff, saveUpload, driver, presign, clamScan, safeName, PURPOSE_RULES };
