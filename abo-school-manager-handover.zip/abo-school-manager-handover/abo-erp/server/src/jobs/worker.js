'use strict';
// Background worker: Postgres-backed queue (FOR UPDATE SKIP LOCKED via app.claim_job) — safe to run
// several worker processes in parallel. Also runs periodic sweeps (CBT auto-submit, session cleanup).
const os = require('node:os');
const config = require('../config');
const { withTx, raw, pool } = require('../db/pool');
const mailer = require('../services/mailer');
const metrics = require('../lib/metrics');
const { gradeAttempt } = require('../services/cbt');
const { notify } = require('../services/notify');
const { saveUpload } = require('../storage');

const WORKER = `${os.hostname()}:${process.pid}`;
const SENSITIVE = new Set(['password_reset', 'verify_email']);
const log = (msg, extra = {}) => { if (!config.isTest) process.stdout.write(JSON.stringify({ level: 'info', worker: WORKER, msg, ...extra }) + '\n'); };

const handlers = {
  async 'email.send'(job) {
    const ctx = { schoolId: job.school_id, platform: !job.school_id };
    const m = (await withTx(ctx, (c) => c.query('SELECT * FROM outbox_emails WHERE id = $1', [job.payload.emailId]))).rows[0];
    if (!m || m.status === 'sent') return { skipped: true };
    const r = await mailer.send({ to: m.to_address, subject: m.subject, text: m.body_text });
    if (r.status === 'dev_logged') log('DEV email (not sent — configure SMTP_URL)', { to: m.to_address, subject: m.subject, body: m.body_text });
    await withTx(ctx, (c) => c.query(`UPDATE outbox_emails SET status = $2, sent_at = now(), attempts = attempts + 1,
      body_text = CASE WHEN $3 THEN '[redacted after delivery]' ELSE body_text END WHERE id = $1`, [m.id, r.status, SENSITIVE.has(m.template) && r.status === 'sent']));
    return r;
  },
  // 30-minute reminder before a scheduled CBT (skipped if the exam was rescheduled, closed or deleted)
  async 'cbt.reminder'(job) {
    const { candidateIds } = require('../services/cbt');
    return withTx({ schoolId: job.school_id }, async (c) => {
      const e = (await c.query('SELECT * FROM cbt_exams WHERE id = $1', [job.payload.examId])).rows[0];
      if (!e || e.status !== 'published' || !e.starts_at || new Date(e.starts_at).toISOString() !== new Date(job.payload.startsAt).toISOString()) return { skipped: true };
      const users = (await c.query('SELECT user_id FROM students WHERE id = ANY($1::uuid[]) AND user_id IS NOT NULL', [await candidateIds(c, e)])).rows.map((r) => r.user_id);
      const t = new Date(e.starts_at).toLocaleTimeString('en-NG', { hour: 'numeric', minute: '2-digit', timeZone: 'Africa/Lagos' });
      await notify(c, job.school_id, users, { kind: 'cbt', title: `Reminder: ${e.title} starts at ${t}`, link: '#/my-cbt' });
      return { notified: users.length };
    });
  },
  // full school data backup: one worksheet per dataset the requester can still export (re-checked now)
  async 'backup.build'(job) {
    const { buildExport, DATASETS } = require('../routes/data');
    const { toXlsxBook } = require('../lib/csv');
    const { userId } = job.payload;
    return withTx({ schoolId: job.school_id, userId }, async (c) => {
      const perms = new Set((await c.query('SELECT DISTINCT rp.permission_key FROM user_roles ur JOIN role_permissions rp ON rp.role_id = ur.role_id WHERE ur.user_id = $1', [userId])).rows.map((r) => r.permission_key));
      if (!perms.has('reports.export') || !perms.has('settings.view')) throw new Error('permission revoked');
      const sheets = []; const counts = {};
      for (const [name, d] of Object.entries(DATASETS)) {
        if (!perms.has(d.perm)) continue;
        const { cols, rows } = await buildExport(c, { auth: { schoolId: job.school_id } }, name, {});
        sheets.push({ title: name, columns: cols, rows }); counts[name] = rows.length;
      }
      const school = (await c.query('SELECT name, slug FROM schools WHERE id = $1', [job.school_id])).rows[0];
      sheets.unshift({ title: 'README', columns: [{ key: 'k', label: 'Item' }, { key: 'v', label: 'Value' }], rows: [
        { k: 'School', v: school.name }, { k: 'Generated', v: new Date().toISOString() }, { k: 'Datasets', v: Object.entries(counts).map(([k, n]) => `${k}: ${n}`).join(', ') },
        { k: 'Note', v: 'Read-only copy of your school data. To restore records, use the import templates (Students, Staff, Guardians, Classes, Subjects, Scores) or ask A.B.O. support for a point-in-time restore.' }] });
      const buffer = await toXlsxBook(sheets);
      const up = await saveUpload(c, { schoolId: job.school_id, userId, purpose: 'export', buffer, originalName: `${school.slug}-backup-${new Date().toISOString().slice(0, 10)}.xlsx` });
      await notify(c, job.school_id, [userId], { kind: 'export', title: 'Your school data backup is ready', link: `#/downloads/${up.id}` });
      return { fileId: up.id, datasets: counts };
    });
  },
  async 'export.build'(job) {
    const { buildExport, DATASETS } = require('../routes/data');
    const { toCsv, toXlsx } = require('../lib/csv');
    const { dataset, query, userId } = job.payload;
    return withTx({ schoolId: job.school_id, userId }, async (c) => {
      const perms = (await c.query('SELECT DISTINCT rp.permission_key FROM user_roles ur JOIN role_permissions rp ON rp.role_id = ur.role_id WHERE ur.user_id = $1', [userId])).rows.map((r) => r.permission_key);
      if (!perms.includes('reports.export')) throw new Error('permission revoked');          // re-check at execution time
      const need = dataset === 'broadsheet' || dataset === 'cumulative' ? 'results.view' : (DATASETS[dataset] || {}).perm;
      if (!need || !perms.includes(need)) throw new Error('permission revoked');
      const { cols, rows } = await buildExport(c, { auth: { schoolId: job.school_id } }, dataset, query || {});
      const xlsx = query && query.format === 'xlsx';
      const buffer = xlsx ? await toXlsx(dataset, cols, rows) : Buffer.from(toCsv(cols, rows), 'utf8');
      const up = await saveUpload(c, { schoolId: job.school_id, userId, purpose: 'export', buffer, originalName: `${dataset}-${new Date().toISOString().slice(0, 10)}.${xlsx ? 'xlsx' : 'csv'}` });
      await notify(c, job.school_id, [userId], { kind: 'export', title: `Your ${dataset} export is ready`, link: `#/downloads/${up.id}` });
      return { fileId: up.id, rows: rows.length };
    });
  },
};

async function runOne() {
  const job = (await raw('SELECT * FROM app.claim_job($1)', [WORKER])).rows[0];
  if (!job) return false;
  const ctx = { schoolId: job.school_id, platform: !job.school_id };
  try {
    const h = handlers[job.kind];
    if (!h) throw new Error(`unknown job kind ${job.kind}`);
    const result = await h(job);
    await withTx(ctx, (c) => c.query("UPDATE jobs SET status = 'done', result = $2, finished_at = now(), last_error = NULL WHERE id = $1", [job.id, result || {}]));
    metrics.inc('jobs_total', { kind: job.kind, status: 'done' });
  } catch (e) {
    const final = job.attempts >= job.max_attempts;
    await withTx(ctx, (c) => c.query(`UPDATE jobs SET status = $2, last_error = $3, run_at = now() + make_interval(secs => $4), locked_at = NULL, finished_at = CASE WHEN $2 = 'failed' THEN now() END WHERE id = $1`,
      [job.id, final ? 'failed' : 'queued', String(e.message).slice(0, 500), Math.min(3600, 15 * 2 ** job.attempts)]));
    metrics.inc('jobs_total', { kind: job.kind, status: final ? 'failed' : 'retry' });
    if (final) require('../lib/alerts').alert('job_failed', { message: `${job.kind}: ${e.message}`, route: `job:${job.kind}` });
    log('job error', { job: job.id, kind: job.kind, error: e.message, final });
  }
  return true;
}

async function sweep() {
  // auto-submit CBT attempts whose server-side deadline has passed
  for (const a of (await raw('SELECT * FROM app.expired_cbt_attempts(200)')).rows) {
    await withTx({ schoolId: a.school_id }, (c) => gradeAttempt(c, a.attempt_id, { auto: true })).catch((e) => log('cbt sweep error', { error: e.message }));
  }
  // demo schools changed by visitors are restored once nobody is using them (5-minute demo sessions)
  await require('../services/demo').resetIdleDemos(log).catch((e) => log('demo reset error', { error: e.message }));
  // housekeeping (platform scope)
  await withTx({ platform: true }, async (c) => {
    await c.query("DELETE FROM sessions WHERE expires_at < now() - interval '30 days' OR revoked_at < now() - interval '30 days'");
    await c.query("DELETE FROM user_tokens WHERE expires_at < now() - interval '7 days'");
    await c.query("DELETE FROM jobs WHERE status = 'done' AND finished_at < now() - interval '14 days'");
    // subscriptions: a paid period or a trial that has ended becomes "expired" (demo schools are never billed)
    await c.query(`UPDATE school_subscriptions ss SET status = 'expired', updated_at = now() FROM schools s WHERE s.id = ss.school_id AND NOT s.is_demo
      AND ((ss.status = 'active' AND ss.current_period_end < now()) OR (ss.status = 'trial' AND ss.trial_ends_at < now()))`);
  }).catch((e) => log('housekeeping error', { error: e.message }));
}

function start({ intervalMs = 1000, sweepMs = 30000 } = {}) {
  let stopped = false; let busy = false;
  const tick = async () => {
    if (stopped || busy) return; busy = true;
    try { while (!stopped && await runOne()); } catch (e) { log('worker loop error', { error: e.message }); } finally { busy = false; }
  };
  const t1 = setInterval(tick, intervalMs); const t2 = setInterval(() => sweep().catch(() => {}), sweepMs);
  t1.unref(); t2.unref();
  return { stop: () => { stopped = true; clearInterval(t1); clearInterval(t2); }, tick, sweep };
}

if (require.main === module) {
  const w = start();
  log('worker started');
  const stop = async () => { w.stop(); await pool.end(); process.exit(0); };
  process.on('SIGTERM', stop); process.on('SIGINT', stop);
}
module.exports = { start, runOne, sweep, handlers };
