'use strict';
// Phase 6 (part 1) — features of the offline app, now with server-side rules:
//   • Staff clock-in / clock-out. The distance to the school gate is worked out HERE from the reported position, never
//     trusted from the browser; one clock-in and one clock-out per person per school day (database constraint).
//   • School calendar (learners only see events meant for everyone).
//   • Birthdays of pupils and staff.
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, str, uuid, idParams } = require('../lib/schema');
const { ctx } = require('../auth/plugin');
const { audit, auditAlone } = require('../audit/audit');
const config = require('../config');
const WA = require('@simplewebauthn/server');

// WebAuthn (fingerprint / face): the relying party is the web address people open (PUBLIC_ORIGIN)
const RP_ID = () => new URL(config.publicOrigin).hostname;
async function newChallenge(c, req, purpose, challenge) {
  await c.query("DELETE FROM webauthn_challenges WHERE user_id = $1 AND (expires_at < now() OR used_at IS NOT NULL)", [req.auth.userId]);
  return (await c.query('INSERT INTO webauthn_challenges (school_id, user_id, purpose, challenge) VALUES ($1,$2,$3,$4) RETURNING id', [req.auth.schoolId, req.auth.userId, purpose, challenge])).rows[0].id;
}
// single use, 5 minutes, only for this person and purpose. Runs in its OWN transaction, so a failed attempt still uses
// the challenge up (otherwise a refused answer would roll back and the same challenge could be tried again).
async function takeChallenge(_c, req, purpose, id) {
  const r = (await withTx(ctx(req), (c) => c.query(`UPDATE webauthn_challenges SET used_at = now() WHERE id = $1 AND user_id = $2 AND purpose = $3 AND used_at IS NULL AND expires_at > now() RETURNING challenge`,
    [id, req.auth.userId, purpose]))).rows[0];
  if (!r) throw E.bad('The fingerprint/face check has expired. Please try again.');
  return r.challenge;
}
// verify a clock-in fingerprint/face answer from the phone; returns true or throws
async function verifyPasskey(c, req, challengeId, response) {
  if (!response || typeof response !== 'object' || typeof response.id !== 'string' || !challengeId) throw E.bad('Confirm with your fingerprint or face to clock in.');
  const expectedChallenge = await takeChallenge(c, req, 'clock', challengeId);
  const cred = (await c.query('SELECT id, credential_id, public_key, counter, transports FROM webauthn_credentials WHERE credential_id = $1 AND user_id = $2 AND revoked_at IS NULL', [response.id, req.auth.userId])).rows[0];
  if (!cred) throw E.bad('This phone is not set up for fingerprint/face clock-in. Set it up first.');
  let v;
  try {
    v = await WA.verifyAuthenticationResponse({ response, expectedChallenge, expectedOrigin: config.publicOrigin, expectedRPID: RP_ID(), requireUserVerification: true,
      credential: { id: cred.credential_id, publicKey: new Uint8Array(cred.public_key), counter: Number(cred.counter), transports: cred.transports } });
  } catch (e) { throw E.bad('The fingerprint/face check could not be confirmed. Please try again.'); }
  if (!v.verified) throw E.bad('The fingerprint/face check could not be confirmed. Please try again.');
  await c.query('UPDATE webauthn_credentials SET counter = $2, last_used_at = now() WHERE id = $1', [cred.id, v.authenticationInfo.newCounter]);
  return true;
}

const DAY = { type: 'string', format: 'date' };
const txt = (max) => ({ type: ['string', 'null'], maxLength: max });
const coord = (min, max) => ({ type: ['number', 'null'], minimum: min, maximum: max });

// great-circle distance in metres (haversine)
function distanceM(lat1, lng1, lat2, lng2) {
  const R = 6371000, rad = (d) => (d * Math.PI) / 180;
  const a = Math.sin(rad(lat2 - lat1) / 2) ** 2 + Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(rad(lng2 - lng1) / 2) ** 2;
  return Math.round(2 * R * Math.asin(Math.min(1, Math.sqrt(a))));
}
// the school's own date and time right now (schools.timezone, default Africa/Lagos)
async function schoolNow(c, schoolId) {
  return (await c.query(`SELECT (now() AT TIME ZONE s.timezone)::date::text AS day, to_char(now() AT TIME ZONE s.timezone, 'HH24:MI:SS') AS time, s.timezone
    FROM schools s WHERE s.id = $1`, [schoolId])).rows[0];
}
async function clockSettings(c) {
  return (await c.query('SELECT require_location, require_biometric, site_lat, site_lng, radius_m, late_after::text AS late_after, updated_at FROM clock_settings LIMIT 1')).rows[0]
    || { require_location: false, require_biometric: false, site_lat: null, site_lng: null, radius_m: 150, late_after: '08:00:00', updated_at: null };
}
const publicSettings = (s) => ({ requireLocation: s.require_location, requireBiometric: !!s.require_biometric, hasSite: s.site_lat !== null, radiusM: s.radius_m, lateAfter: String(s.late_after).slice(0, 5) });

module.exports = async function schoolLifeRoutes(app) {
  const A = app.authenticate;

  // ───────────────────────── staff clock-in ─────────────────────────
  app.get('/clock/me', { onRequest: [A, app.perm('clock.use')] }, async (req) => withTx(ctx(req), async (c) => {
    const st = await clockSettings(c); const now = await schoolNow(c, req.auth.schoolId);
    if (!req.auth.staffId) return { staff: false, settings: publicSettings(st), today: now.day, entries: [] };
    const entries = (await c.query(`SELECT day::text, kind, at, late, distance_m, verified_by FROM staff_clock WHERE staff_id = $1 ORDER BY day DESC, at DESC LIMIT 60`, [req.auth.staffId])).rows;
    const today = entries.filter((e) => e.day === now.day);
    const passkeys = (await c.query('SELECT id, device_label, created_at, last_used_at FROM webauthn_credentials WHERE user_id = $1 AND revoked_at IS NULL ORDER BY created_at', [req.auth.userId])).rows;
    return { staff: true, settings: publicSettings(st), today: now.day, in: today.find((e) => e.kind === 'in') || null, out: today.find((e) => e.kind === 'out') || null, entries, passkeys };
  }));

  const clockBody = obj({ lat: coord(-90, 90), lng: coord(-180, 180), accuracy: { type: ['number', 'null'], minimum: 0, maximum: 100000 }, device: txt(120), note: txt(300),
    passkey: { type: ['object', 'null'], maxProperties: 10 }, passkeyChallengeId: { ...uuid, type: ['string', 'null'] } });

  // ── fingerprint / face (passkeys) ──
  app.post('/clock/passkeys/register-options', { onRequest: [A, app.perm('clock.use')], config: { rateLimit: { max: 20, timeWindow: '10 minutes' } } }, async (req) => withTx(ctx(req), async (c) => {
    if (!req.auth.staffId) throw E.forbidden('Only staff with a staff record can set up fingerprint/face clock-in.');
    const existing = (await c.query('SELECT credential_id, transports FROM webauthn_credentials WHERE user_id = $1 AND revoked_at IS NULL', [req.auth.userId])).rows;
    const school = (await c.query('SELECT name FROM schools WHERE id = $1', [req.auth.schoolId])).rows[0];
    const options = await WA.generateRegistrationOptions({ rpName: `${school.name} · A.B.O.`.slice(0, 60), rpID: RP_ID(), userName: req.auth.loginId, userDisplayName: req.auth.fullName || req.auth.loginId,
      userID: new TextEncoder().encode(req.auth.userId), attestationType: 'none', timeout: 120000,
      excludeCredentials: existing.map((x) => ({ id: x.credential_id, transports: x.transports })),
      authenticatorSelection: { residentKey: 'preferred', userVerification: 'required', authenticatorAttachment: 'platform' } });
    return { challengeId: await newChallenge(c, req, 'register', options.challenge), options };
  }));
  app.post('/clock/passkeys', { onRequest: [A, app.perm('clock.use')], schema: { body: obj({ challengeId: uuid, response: { type: 'object', maxProperties: 10 }, label: txt(80) }, ['challengeId', 'response']) } }, async (req) => withTx(ctx(req), async (c) => {
    if (!req.auth.staffId) throw E.forbidden('Only staff with a staff record can set up fingerprint/face clock-in.');
    const expectedChallenge = await takeChallenge(c, req, 'register', req.body.challengeId);
    let v;
    try { v = await WA.verifyRegistrationResponse({ response: req.body.response, expectedChallenge, expectedOrigin: config.publicOrigin, expectedRPID: RP_ID(), requireUserVerification: true }); }
    catch (e) { throw E.bad('This phone could not be set up. Make sure fingerprint or face unlock is turned on, then try again.'); }
    if (!v.verified || !v.registrationInfo) throw E.bad('This phone could not be set up. Please try again.');
    const k = v.registrationInfo.credential;
    try {
      const r = (await c.query(`INSERT INTO webauthn_credentials (school_id, user_id, credential_id, public_key, counter, transports, device_label) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
        [req.auth.schoolId, req.auth.userId, k.id, Buffer.from(k.publicKey), k.counter || 0, k.transports || [], req.body.label || 'Phone'])).rows[0];
      await audit(c, req, 'clock.passkey_added', { type: 'user', id: req.auth.userId, meta: { label: req.body.label || 'Phone' } });
      return { id: r.id };
    } catch (e) { if (e.code === '23505') throw E.conflict('This phone is already set up.'); throw e; }
  }));
  app.delete('/clock/passkeys/:id', { onRequest: [A, app.perm('clock.use', 'clock.manage')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const k = (await c.query('SELECT id, user_id FROM webauthn_credentials WHERE id = $1 AND revoked_at IS NULL', [req.params.id])).rows[0];
    if (!k || (k.user_id !== req.auth.userId && !req.can('clock.manage'))) throw E.notFound('Phone');
    await c.query('UPDATE webauthn_credentials SET revoked_at = now() WHERE id = $1', [k.id]);
    await audit(c, req, 'clock.passkey_removed', { type: 'user', id: k.user_id });
    return { ok: true };
  }));
  app.post('/clock/passkeys/clock-options', { onRequest: [A, app.perm('clock.use')], config: { rateLimit: { max: 30, timeWindow: '1 minute' } } }, async (req) => withTx(ctx(req), async (c) => {
    const creds = (await c.query('SELECT credential_id, transports FROM webauthn_credentials WHERE user_id = $1 AND revoked_at IS NULL', [req.auth.userId])).rows;
    if (!creds.length) throw E.bad('This account has no phone set up for fingerprint/face clock-in yet.');
    const options = await WA.generateAuthenticationOptions({ rpID: RP_ID(), userVerification: 'required', timeout: 120000, allowCredentials: creds.map((x) => ({ id: x.credential_id, transports: x.transports })) });
    return { challengeId: await newChallenge(c, req, 'clock', options.challenge), options };
  }));
  for (const kind of ['in', 'out']) {
    app.post(`/clock/${kind}`, { onRequest: [A, app.perm('clock.use')], schema: { body: clockBody }, config: { rateLimit: { max: 20, timeWindow: '1 minute' } } }, async (req) => withTx(ctx(req), async (c) => {
      if (!req.auth.staffId) throw E.forbidden('Only staff with a staff record can clock in. Ask the school office to link your account to your staff record.');
      const b = req.body || {}; const st = await clockSettings(c); const now = await schoolNow(c, req.auth.schoolId);
      const hasPos = Number.isFinite(b.lat) && Number.isFinite(b.lng);
      let distance = null;
      if (hasPos && st.site_lat !== null) distance = distanceM(b.lat, b.lng, st.site_lat, st.site_lng);
      if (st.require_location) {
        if (!hasPos) throw E.bad('Your location is needed to clock in. Allow location for this site and try again.');
        if (Number.isFinite(b.accuracy) && b.accuracy > 1000) throw E.bad(`Your location is not precise enough (about ${Math.round(b.accuracy)} m). Step outside or turn on GPS, then try again.`);
        if (distance > st.radius_m) {
          await auditAlone(req, `clock.${kind}_refused`, { type: 'staff', id: req.auth.staffId, success: false, meta: { distanceM: distance, radiusM: st.radius_m } });   // own transaction: kept although this request fails
          throw E.bad(`You are about ${distance >= 1000 ? (distance / 1000).toFixed(1) + ' km' : distance + ' m'} from school. Clock-in works within ${st.radius_m} m of the school.`, { distanceM: distance, radiusM: st.radius_m });
        }
      }
      let verifiedBy = null;
      if (st.require_biometric || b.passkey) { await verifyPasskey(c, req, b.passkeyChallengeId, b.passkey); verifiedBy = 'passkey'; }
      if (kind === 'out') {
        const had = (await c.query("SELECT 1 FROM staff_clock WHERE staff_id = $1 AND day = $2 AND kind = 'in'", [req.auth.staffId, now.day])).rowCount;
        if (!had) throw E.conflict('You have not clocked in today, so you cannot clock out.');
      }
      const late = kind === 'in' && now.time > String(st.late_after);
      let row;
      try {
        row = (await c.query(`INSERT INTO staff_clock (school_id, staff_id, user_id, day, kind, late, lat, lng, accuracy_m, distance_m, device, note, verified_by)
          VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING id, day::text, kind, at, late, distance_m, verified_by`,
        [req.auth.schoolId, req.auth.staffId, req.auth.userId, now.day, kind, late, hasPos ? b.lat : null, hasPos ? b.lng : null,
          Number.isFinite(b.accuracy) ? Math.round(b.accuracy) : null, distance, b.device || null, b.note || null, verifiedBy])).rows[0];
      } catch (e) {
        if (e.code === '23505') throw E.conflict(kind === 'in' ? 'You have already clocked in today.' : 'You have already clocked out today.');
        throw e;
      }
      await audit(c, req, `clock.${kind}`, { type: 'staff', id: req.auth.staffId, meta: { late, distanceM: distance, verifiedBy } });
      return row;
    }));
  }

  app.get('/clock/register', { onRequest: [A, app.perm('clock.view')], schema: { querystring: obj({ date: DAY }) } }, async (req) => withTx(ctx(req), async (c) => {
    const now = await schoolNow(c, req.auth.schoolId); const day = req.query.date || now.day;
    const rows = (await c.query(`SELECT st.id AS staff_id, st.full_name, st.designation, st.is_teacher,
        i.at AS in_at, i.late, i.distance_m AS in_distance_m, o.at AS out_at, o.distance_m AS out_distance_m
      FROM staff st
      LEFT JOIN staff_clock i ON i.staff_id = st.id AND i.day = $1 AND i.kind = 'in'
      LEFT JOIN staff_clock o ON o.staff_id = st.id AND o.day = $1 AND o.kind = 'out'
      WHERE st.employment_status = 'active' ORDER BY st.full_name LIMIT 2000`, [day])).rows;
    const items = rows.map((r) => ({ ...r, status: r.in_at ? (r.late ? 'late' : 'present') : (day >= now.day ? 'not_in' : 'absent') }));
    const count = (s) => items.filter((x) => x.status === s).length;
    return { date: day, today: now.day, timezone: now.timezone, items, summary: { staff: items.length, present: count('present'), late: count('late'), notIn: count('not_in') + count('absent'), clockedOut: items.filter((x) => x.out_at).length } };
  }));

  app.get('/clock/settings', { onRequest: [A, app.perm('clock.manage', 'clock.view')] }, async (req) => withTx(ctx(req), async (c) => {
    const s = await clockSettings(c);
    return { ...publicSettings(s), siteLat: s.site_lat, siteLng: s.site_lng, updatedAt: s.updated_at };
  }));
  app.put('/clock/settings', {
    onRequest: [A, app.perm('clock.manage')],
    schema: { body: obj({ requireLocation: { type: 'boolean' }, requireBiometric: { type: 'boolean' }, siteLat: coord(-90, 90), siteLng: coord(-180, 180), radiusM: { type: 'integer', minimum: 20, maximum: 5000 },
      lateAfter: { type: 'string', pattern: '^([01][0-9]|2[0-3]):[0-5][0-9]$' } }, ['requireLocation']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const b = req.body; const cur = await clockSettings(c);
    const lat = b.siteLat !== undefined ? b.siteLat : cur.site_lat; const lng = b.siteLng !== undefined ? b.siteLng : cur.site_lng;
    if ((lat === null) !== (lng === null)) throw E.bad('Give both the latitude and the longitude of the school.');
    if (b.requireLocation && lat === null) throw E.bad('Set the school location first (stand at the school gate and press "Use my location").');
    const r = (await c.query(`INSERT INTO clock_settings (school_id, require_location, site_lat, site_lng, radius_m, late_after, updated_by, require_biometric) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
      ON CONFLICT (school_id) DO UPDATE SET require_location = EXCLUDED.require_location, site_lat = EXCLUDED.site_lat, site_lng = EXCLUDED.site_lng,
        radius_m = EXCLUDED.radius_m, late_after = EXCLUDED.late_after, updated_by = EXCLUDED.updated_by, require_biometric = EXCLUDED.require_biometric
      RETURNING require_location, require_biometric, site_lat, site_lng, radius_m, late_after::text AS late_after, updated_at`,
    [req.auth.schoolId, b.requireLocation, lat, lng, b.radiusM ?? cur.radius_m, b.lateAfter || String(cur.late_after).slice(0, 5), req.auth.userId, b.requireBiometric ?? !!cur.require_biometric])).rows[0];
    await audit(c, req, 'clock.settings_updated', { type: 'school', id: req.auth.schoolId, meta: { requireLocation: r.require_location, requireBiometric: r.require_biometric, radiusM: r.radius_m, lateAfter: r.late_after } });
    return { ...publicSettings(r), siteLat: r.site_lat, siteLng: r.site_lng, updatedAt: r.updated_at };
  }));

  // ───────────────────────── school calendar ─────────────────────────
  const isLearner = (req) => req.auth.portal === 'student' || req.auth.portal === 'parent';
  app.get('/calendar', { onRequest: [A, app.perm('calendar.view')], schema: { querystring: obj({ from: DAY, to: DAY }) } }, async (req) => withTx(ctx(req), async (c) => {
    const now = await schoolNow(c, req.auth.schoolId);
    const from = req.query.from || now.day.slice(0, 8) + '01';
    const to = req.query.to || (await c.query("SELECT (($1::date + interval '3 months') - interval '1 day')::date::text AS d", [from])).rows[0].d;
    if (to < from) throw E.bad('"to" must be on or after "from".');
    const p = [from, to]; let extra = '';
    if (isLearner(req)) extra = " AND e.audience = 'all'";
    const items = (await c.query(`SELECT e.id, e.title, e.description, e.kind, e.audience, e.starts_on::text, e.ends_on::text, e.updated_at, u.full_name AS created_by_name
      FROM calendar_events e LEFT JOIN users u ON u.id = e.created_by
      WHERE e.deleted_at IS NULL AND e.ends_on >= $1 AND e.starts_on <= $2${extra} ORDER BY e.starts_on, e.title LIMIT 500`, p)).rows;
    return { from, to, today: now.day, items, canManage: req.can('calendar.manage') };
  }));
  const evBody = (required) => ({ body: obj({ title: str(160, 2), description: txt(2000), kind: { enum: ['holiday', 'exam', 'event', 'meeting', 'other'] },
    audience: { enum: ['all', 'staff'] }, startsOn: DAY, endsOn: { type: ['string', 'null'], format: 'date' } }, required) });
  const checkRange = (s, e) => { if (e < s) throw E.bad('The end date must be on or after the start date.'); if ((Date.parse(e) - Date.parse(s)) / 864e5 > 366) throw E.bad('An event can last at most one year.'); };
  app.post('/calendar', { onRequest: [A, app.perm('calendar.manage')], schema: evBody(['title', 'startsOn']) }, async (req) => withTx(ctx(req), async (c) => {
    const b = req.body; const ends = b.endsOn || b.startsOn; checkRange(b.startsOn, ends);
    const r = (await c.query(`INSERT INTO calendar_events (school_id, title, description, kind, audience, starts_on, ends_on, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
      RETURNING id, title, description, kind, audience, starts_on::text, ends_on::text`, [req.auth.schoolId, b.title.trim(), b.description || null, b.kind || 'event', b.audience || 'all', b.startsOn, ends, req.auth.userId])).rows[0];
    await audit(c, req, 'calendar.created', { type: 'calendar_event', id: r.id, meta: { title: r.title, startsOn: r.starts_on } });
    return r;
  }));
  app.patch('/calendar/:id', { onRequest: [A, app.perm('calendar.manage')], schema: { params: idParams, ...evBody([]) } }, async (req) => withTx(ctx(req), async (c) => {
    const cur = (await c.query('SELECT * FROM calendar_events WHERE id = $1 AND deleted_at IS NULL FOR UPDATE', [req.params.id])).rows[0];
    if (!cur) throw E.notFound('Calendar event');
    const b = req.body; const s = b.startsOn || cur.starts_on;   // dates arrive as 'YYYY-MM-DD' (pool type parser)
    const e = b.endsOn !== undefined ? (b.endsOn || s) : (cur.ends_on < s ? s : cur.ends_on);
    checkRange(s, e);
    const r = (await c.query(`UPDATE calendar_events SET title = $2, description = $3, kind = $4, audience = $5, starts_on = $6, ends_on = $7 WHERE id = $1
      RETURNING id, title, description, kind, audience, starts_on::text, ends_on::text`, [cur.id, (b.title ?? cur.title).trim(), b.description !== undefined ? b.description : cur.description,
      b.kind || cur.kind, b.audience || cur.audience, s, e])).rows[0];
    await audit(c, req, 'calendar.updated', { type: 'calendar_event', id: r.id });
    return r;
  }));
  app.delete('/calendar/:id', { onRequest: [A, app.perm('calendar.manage')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const r = await c.query('UPDATE calendar_events SET deleted_at = now() WHERE id = $1 AND deleted_at IS NULL RETURNING title', [req.params.id]);
    if (!r.rowCount) throw E.notFound('Calendar event');
    await audit(c, req, 'calendar.deleted', { type: 'calendar_event', id: req.params.id, meta: { title: r.rows[0].title } });
    return { ok: true };
  }));

  // ───────────────────────── birthdays ─────────────────────────
  app.get('/birthdays', { onRequest: [A, app.perm('birthdays.view')], schema: { querystring: obj({ days: { type: 'integer', minimum: 0, maximum: 366, default: 30 } }) } }, async (req) => withTx(ctx(req), async (c) => {
    const now = await schoolNow(c, req.auth.schoolId); const days = req.query.days ?? 30;
    const people = (await c.query(`SELECT 'student' AS kind, s.id, trim(concat_ws(' ', s.first_name, s.other_names, s.last_name)) AS name, s.date_of_birth::text AS dob, s.gender,
        (SELECT cl.display_name FROM student_enrollments e JOIN academic_sessions a ON a.id = e.session_id AND a.is_current JOIN classes cl ON cl.id = e.class_id
          WHERE e.student_id = s.id LIMIT 1) AS detail
      FROM students s WHERE s.deleted_at IS NULL AND s.status = 'active' AND s.date_of_birth IS NOT NULL
      UNION ALL
      SELECT 'staff', st.id, st.full_name, st.date_of_birth::text, st.gender, st.designation FROM staff st WHERE st.employment_status = 'active' AND st.date_of_birth IS NOT NULL`)).rows;
    const [ty, tm, td] = now.day.split('-').map(Number); const today = Date.UTC(ty, tm - 1, td);
    const leap = (y) => (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0;
    const items = [];
    for (const p of people) {
      const [by, bm, bd] = p.dob.split('-').map(Number);
      const on = (y) => Date.UTC(y, bm - 1, bm === 2 && bd === 29 && !leap(y) ? 28 : bd);   // 29 Feb → 28 Feb in other years
      let y = ty; if (on(y) < today) y++;
      const inDays = Math.round((on(y) - today) / 864e5);
      if (inDays > days) continue;
      items.push({ kind: p.kind, id: p.id, name: p.name, detail: p.detail, gender: p.gender, date: new Date(on(y)).toISOString().slice(0, 10), inDays, turns: y - by });
    }
    items.sort((a, b) => a.inDays - b.inDays || a.name.localeCompare(b.name));
    return { today: now.day, days, items, counts: { today: items.filter((x) => x.inDays === 0).length, students: items.filter((x) => x.kind === 'student').length, staff: items.filter((x) => x.kind === 'staff').length } };
  }));
};
module.exports.distanceM = distanceM;
