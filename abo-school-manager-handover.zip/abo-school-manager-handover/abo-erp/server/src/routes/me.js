'use strict';
const { withTx, raw } = require('../db/pool');
const S = require('../auth/sessions');

module.exports = async function meRoutes(app) {
  app.get('/auth/me', { config: { allowMfaPending: true, allowMfaEnroll: true, allowPasswordChange: true }, onRequest: [app.authenticate] }, async (req) => {
    const a = req.auth;
    let school = null; let children = []; let branch = null; let unread = { notifications: 0, announcements: 0, messages: 0 };
    if (a.schoolId && a.mfaState !== 'pending' && a.mfaState !== 'enroll_required') {
      await withTx({ schoolId: a.schoolId, userId: a.userId, readOnly: true }, async (c) => {
        school = (await c.query(`SELECT s.id, s.slug, s.name, s.school_type, s.motto, s.address, s.phone, s.email, s.website, s.status,
          s.logo_file_id, s.currency, s.timezone, s.brand_color,
          (SELECT json_build_object('id', t.id, 'name', t.name, 'session', se.name) FROM terms t JOIN academic_sessions se ON se.id = t.session_id WHERE t.is_current LIMIT 1) AS current_term
          FROM schools s WHERE s.id = $1`, [a.schoolId])).rows[0] || null;
        if (a.branchId) branch = (await c.query('SELECT id, name, code FROM school_branches WHERE id = $1', [a.branchId])).rows[0] || null;
        if (a.children.length) children = (await c.query(`SELECT s.id, s.first_name, s.last_name, s.admission_no,
          (SELECT c.display_name FROM student_enrollments e JOIN classes c ON c.id = e.class_id JOIN academic_sessions se ON se.id = e.session_id AND se.is_current WHERE e.student_id = s.id LIMIT 1) AS class_name
          FROM students s WHERE s.id = ANY($1::uuid[]) ORDER BY s.first_name`, [a.children])).rows;
        if (!a.support) {
          unread.notifications = (await c.query('SELECT count(*)::int AS n FROM notifications WHERE user_id = $1 AND read_at IS NULL', [a.userId])).rows[0].n;
          unread.messages = (await c.query(`SELECT count(*)::int AS n FROM conversation_participants tp JOIN conversations t ON t.id = tp.conversation_id
            WHERE tp.user_id = $1 AND (tp.last_read_at IS NULL OR tp.last_read_at < t.last_message_at)`, [a.userId])).rows[0].n;
        }
      });
    }
    return {
      user: { id: a.userId, loginId: a.loginId, fullName: a.fullName, branchRestricted: !!a.branchId, email: a.email, mfaEnabled: a.mfaEnabled, mustChangePassword: a.mustChangePassword },
      mfaState: a.mfaState, portal: a.portal, isPlatform: a.isPlatform, support: a.support,
      actingAs: a.actingBy ? { byName: a.actingBy.fullName, byLoginId: a.actingBy.loginId, expiresAt: a.actingBy.expiresAt, startedAt: a.actingBy.startedAt, reason: a.actingBy.reason } : null,
      roles: a.roles.map((r) => ({ key: r.key, name: r.name })), permissions: [...a.perms].sort(),
      studentId: a.studentId, staffId: a.staffId, children, school, branch, unread, csrf: S.csrfFor(a.sessionId),
      demo: a.demo ? { expiresAt: a.demo.expiresAt, serverNow: new Date().toISOString() } : null,
      memberships: a.isPlatform || a.actingBy ? [] : (await raw('SELECT * FROM app.auth_user_memberships($1)', [a.userId])).rows.map((m) => ({ id: m.membership_id, schoolId: m.school_id, schoolName: m.school_name, status: m.status, current: m.school_id === a.homeSchoolId })),
    };
  });
};
