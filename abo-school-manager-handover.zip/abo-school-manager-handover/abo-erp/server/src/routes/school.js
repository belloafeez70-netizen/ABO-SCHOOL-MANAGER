'use strict';
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, str, optStr, email, phone } = require('../lib/schema');
const { ctx } = require('../auth/plugin');
const { audit } = require('../audit/audit');
const { saveUpload } = require('../storage');
const G = require('../services/grading');
const config = require('../config');
const hex = { type: ['string', 'null'], pattern: '^#[0-9a-fA-F]{6}$' };
const blank = (v) => (v === '' ? null : v);

const band = obj({ min: { type: 'number', minimum: 0, maximum: 100 }, grade: str(4, 1), remark: str(120) }, ['min', 'grade']);

module.exports = async function schoolRoutes(app) {
  app.get('/school', { onRequest: [app.authenticate, app.perm('settings.view')] }, async (req) =>
    withTx(ctx(req), async (c) => {
      const s = (await c.query(`SELECT id, slug, registration_number, name, school_type, motto, address, phone, email, website, logo_file_id, country, timezone, currency, status, plan, max_students,
        subscription_status, subscription_expires_at, brand_color, head_name, head_title, head_phone, head_email, head_signature_file_id, approved_at, created_at FROM schools WHERE id = $1`, [req.auth.schoolId])).rows[0];
      s.portal_url = `${config.publicOrigin}/#/s/${s.slug}`;
      const settings = (await c.query('SELECT grading, pass_mark, report_card, ai_enabled, mfa_required_roles, results_require_review FROM school_settings WHERE school_id = $1', [req.auth.schoolId])).rows[0];
      settings.assessment_components = (await c.query('SELECT key, label, max_score AS max, is_exam FROM assessment_components WHERE active ORDER BY position, key')).rows;
      const branches = (await c.query('SELECT id, name, code, address, phone, status FROM school_branches ORDER BY name')).rows;
      return { school: s, settings, branches };
    }));

  // registration number is part of the profile
  app.patch('/school', {
    onRequest: [app.authenticate, app.perm('settings.update')],
    schema: { body: obj({ name: str(160, 2), schoolType: { enum: ['primary', 'secondary', 'mixed'] }, motto: optStr(160), address: optStr(300), phone, email, website: optStr(160), registrationNumber: optStr(60) }) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const b = req.body; const map = { name: 'name', schoolType: 'school_type', motto: 'motto', address: 'address', phone: 'phone', email: 'email', website: 'website', registrationNumber: 'registration_number' };
    const sets = []; const p = [req.auth.schoolId];
    for (const [k, col] of Object.entries(map)) if (b[k] !== undefined) { p.push(b[k]); sets.push(`${col} = $${p.length}`); }
    if (!sets.length) throw E.bad('Nothing to update.');
    const r = await c.query(`UPDATE schools SET ${sets.join(', ')} WHERE id = $1 RETURNING id, name, school_type, motto, address, phone, email, website, registration_number`, p);
    await audit(c, req, 'school.profile_updated', { type: 'school', id: req.auth.schoolId, meta: { fields: Object.keys(b) } });
    return r.rows[0];
  }));

  app.put('/school/settings', {
    onRequest: [app.authenticate, app.perm('settings.update')],
    schema: { body: obj({
      grading: obj({ primary: { type: 'array', items: band, maxItems: 15 }, secondary: { type: 'array', items: band, maxItems: 15 }, nursery: { type: 'array', items: band, maxItems: 15 } }),
      assessmentComponents: { type: 'array', maxItems: 6, items: obj({ key: { type: 'string', pattern: '^[a-z0-9_]{1,20}$' }, label: str(30, 1), max: { type: 'number', minimum: 1, maximum: 100 }, isExam: { type: 'boolean' } }, ['key', 'label', 'max']) },
      resultsRequireReview: { type: 'boolean' },
      passMark: { type: 'number', minimum: 0, maximum: 100 },
      reportCard: obj({ showPosition: { type: 'boolean' }, showClassAverage: { type: 'boolean' }, principalTitle: str(60), footer: str(300), domains: { type: 'array', items: str(40, 1), maxItems: 20 },
        template: { enum: ['classic', 'modern', 'compact'] }, showAttendance: { type: 'boolean' }, showGradeKey: { type: 'boolean' }, showSubjectPosition: { type: 'boolean' }, showPassport: { type: 'boolean' }, showSignature: { type: 'boolean' }, accent: hex,
          showCumulative: { type: 'boolean' }, cumulativeDivisor: { enum: ['taken', 'all'] } }),
      aiEnabled: { type: 'boolean' },
      mfaRequiredRoles: { type: 'array', items: { type: 'string', pattern: '^[a-z][a-z0-9_]{1,40}$' }, maxItems: 30 },
    }) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const b = req.body;
    if (b.assessmentComponents) { const err = G.validateComponents(b.assessmentComponents); if (err) throw E.bad(err); }
    if (b.grading) for (const k of Object.keys(b.grading)) { const err = G.validateBands(b.grading[k]); if (err) throw E.bad(`${k}: ${err}`); }
    const cur = (await c.query('SELECT * FROM school_settings WHERE school_id = $1 FOR UPDATE', [req.auth.schoolId])).rows[0];
    if (b.assessmentComponents) {       // replace the active component set (existing sheets keep their frozen copy)
      await c.query('UPDATE assessment_components SET active = false');
      for (const [i, x] of b.assessmentComponents.entries()) {
        await c.query(`INSERT INTO assessment_components (school_id, key, label, max_score, is_exam, position, active) VALUES ($1,$2,$3,$4,$5,$6,true)
          ON CONFLICT (school_id, key) DO UPDATE SET label = EXCLUDED.label, max_score = EXCLUDED.max_score, is_exam = EXCLUDED.is_exam, position = EXCLUDED.position, active = true`,
        [req.auth.schoolId, x.key, x.label, x.max, x.isExam ?? x.key === 'exam', i]);
      }
    }
    const r = await c.query(`UPDATE school_settings SET grading = $2, pass_mark = $3, report_card = $4, ai_enabled = $5, mfa_required_roles = $6, results_require_review = $7
      WHERE school_id = $1 RETURNING grading, pass_mark, report_card, ai_enabled, mfa_required_roles, results_require_review`, [
      req.auth.schoolId, b.grading ? { ...cur.grading, ...b.grading } : cur.grading,
      b.passMark ?? cur.pass_mark, b.reportCard ? { ...cur.report_card, ...b.reportCard } : cur.report_card, b.aiEnabled ?? cur.ai_enabled, b.mfaRequiredRoles || cur.mfa_required_roles,
      b.resultsRequireReview ?? cur.results_require_review,
    ]);
    r.rows[0].assessment_components = (await c.query('SELECT key, label, max_score AS max, is_exam FROM assessment_components WHERE active ORDER BY position')).rows;
    await audit(c, req, 'school.settings_updated', { type: 'school_settings', id: req.auth.schoolId, meta: { fields: Object.keys(b) } });
    return r.rows[0];
  }));

  app.post('/school/logo', { onRequest: [app.authenticate, app.perm('settings.branding')], config: { rateLimit: { max: 10, timeWindow: '1 minute' } } }, async (req) => {
    const file = await req.file();
    if (!file) throw E.bad('Attach an image file.');
    const buffer = await file.toBuffer();
    return withTx(ctx(req), async (c) => {
      const up = await saveUpload(c, { schoolId: req.auth.schoolId, userId: req.auth.userId, purpose: 'logo', buffer, originalName: file.filename });
      await c.query('UPDATE schools SET logo_file_id = $2 WHERE id = $1', [req.auth.schoolId, up.id]);
      await audit(c, req, 'school.logo_updated', { type: 'upload', id: up.id });
      return { fileId: up.id };
    });
  });

  // ── branding: accent colour (logo upload above) ──
  app.patch('/school/branding', { onRequest: [app.authenticate, app.perm('settings.branding')], schema: { body: obj({ brandColor: hex }, ['brandColor']) } }, async (req) =>
    withTx(ctx(req), async (c) => {
      const r = await c.query('UPDATE schools SET brand_color = $2 WHERE id = $1 RETURNING brand_color', [req.auth.schoolId, req.body.brandColor]);
      await audit(c, req, 'school.branding_updated', { type: 'school', id: req.auth.schoolId, meta: { brandColor: req.body.brandColor } });
      return r.rows[0];
    }));
  app.delete('/school/logo', { onRequest: [app.authenticate, app.perm('settings.branding')] }, async (req) =>
    withTx(ctx(req), async (c) => {
      await c.query('UPDATE schools SET logo_file_id = NULL WHERE id = $1', [req.auth.schoolId]);
      await audit(c, req, 'school.logo_removed', { type: 'school', id: req.auth.schoolId });
      return { ok: true };
    }));

  // ── principal / head of school (printed on report cards) ──
  const headPhone = { type: ['string', 'null'], pattern: '^([+0-9 ()-]{7,20})?$' };
  app.patch('/school/head', {
    onRequest: [app.authenticate, app.perm('settings.update')],
    schema: { body: obj({ headName: { type: ['string', 'null'], maxLength: 120 }, headTitle: { type: ['string', 'null'], maxLength: 60 }, headPhone, headEmail: { type: ['string', 'null'], maxLength: 160, pattern: '^([^\\s@]+@[^\\s@]+\\.[^\\s@]+)?$' } }) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const b = req.body; const map = { headName: 'head_name', headTitle: 'head_title', headPhone: 'head_phone', headEmail: 'head_email' };
    for (const k of ['headName', 'headTitle']) if (b[k] && b[k].trim().length === 1) throw E.bad(`${k === 'headName' ? 'Name' : 'Title'} is too short.`, { field: k });
    const sets = []; const p = [req.auth.schoolId];
    for (const [k, col] of Object.entries(map)) if (b[k] !== undefined) { p.push(blank(typeof b[k] === 'string' ? b[k].trim() : b[k])); sets.push(`${col} = $${p.length}`); }
    if (!sets.length) throw E.bad('Nothing to update.');
    const r = await c.query(`UPDATE schools SET ${sets.join(', ')} WHERE id = $1 RETURNING head_name, head_title, head_phone, head_email, head_signature_file_id`, p);
    await audit(c, req, 'school.head_updated', { type: 'school', id: req.auth.schoolId, meta: { fields: Object.keys(b) } });
    return r.rows[0];
  }));
  app.post('/school/head/signature', { onRequest: [app.authenticate, app.perm('settings.update')], config: { rateLimit: { max: 10, timeWindow: '1 minute' } } }, async (req) => {
    const file = await req.file();
    if (!file) throw E.bad('Attach an image of the signature (PNG, JPG or WEBP).');
    const buffer = await file.toBuffer();
    return withTx(ctx(req), async (c) => {
      const up = await saveUpload(c, { schoolId: req.auth.schoolId, userId: req.auth.userId, purpose: 'signature', buffer, originalName: file.filename });
      await c.query('UPDATE schools SET head_signature_file_id = $2 WHERE id = $1', [req.auth.schoolId, up.id]);
      await audit(c, req, 'school.head_signature_updated', { type: 'upload', id: up.id });
      return { fileId: up.id };
    });
  });
  app.delete('/school/head/signature', { onRequest: [app.authenticate, app.perm('settings.update')] }, async (req) =>
    withTx(ctx(req), async (c) => {
      await c.query('UPDATE schools SET head_signature_file_id = NULL WHERE id = $1', [req.auth.schoolId]);
      await audit(c, req, 'school.head_signature_removed', { type: 'school', id: req.auth.schoolId });
      return { ok: true };
    }));

  const branchBody = obj({ name: str(120, 2), code: { type: ['string', 'null'], pattern: '^[A-Za-z0-9-]{1,20}$' }, address: optStr(300), phone, status: { enum: ['active', 'closed'] } });
  app.get('/school/branches', { onRequest: [app.authenticate, app.perm('settings.view', 'academic.view')] }, async (req) => withTx(ctx(req), async (c) => ({
    items: (await c.query(`SELECT b.id, b.name, b.code, b.address, b.phone, b.status, (SELECT count(*)::int FROM classes cl WHERE cl.branch_id = b.id) AS classes FROM school_branches b ORDER BY b.name`)).rows,
  })));
  app.post('/school/branches', { onRequest: [app.authenticate, app.perm('settings.update')], schema: { body: { ...branchBody, required: ['name'] } } }, async (req) =>
    withTx(ctx(req), async (c) => {
      const r = await c.query('INSERT INTO school_branches (school_id, name, code, address, phone) VALUES ($1,$2,$3,$4,$5) RETURNING id, name, code, address, phone, status',
        [req.auth.schoolId, req.body.name, req.body.code || null, req.body.address || null, req.body.phone || null]);
      await audit(c, req, 'school.branch_created', { type: 'branch', id: r.rows[0].id, meta: { name: req.body.name } });
      return r.rows[0];
    }));
  app.patch('/school/branches/:id', { onRequest: [app.authenticate, app.perm('settings.update')], schema: { params: obj({ id: { type: 'string', format: 'uuid' } }, ['id']), body: branchBody } }, async (req) =>
    withTx(ctx(req), async (c) => {
      const b = req.body; const map = { name: 'name', code: 'code', address: 'address', phone: 'phone', status: 'status' };
      const sets = []; const p = [req.params.id];
      for (const [k, col] of Object.entries(map)) if (b[k] !== undefined) { p.push(b[k]); sets.push(`${col} = $${p.length}`); }
      if (!sets.length) throw E.bad('Nothing to update.');
      const r = await c.query(`UPDATE school_branches SET ${sets.join(', ')} WHERE id = $1 RETURNING id, name, code, address, phone, status`, p);
      if (!r.rowCount) throw E.notFound('Branch');
      await audit(c, req, 'school.branch_updated', { type: 'branch', id: req.params.id, meta: { fields: Object.keys(b) } });
      return r.rows[0];
    }));
};
