'use strict';
// Result processing dashboards, approval queue, annual (cumulative) broadsheet, performance analytics and
// teacher activity. All aggregates are computed in SQL inside the caller's tenant (RLS + branch scope);
// nothing here trusts a client-computed figure.
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, uuid, idParams } = require('../lib/schema');
const { ctx } = require('../auth/plugin');
const { audit } = require('../audit/audit');
const R = require('../services/results');
const G = require('../services/grading');
const CUM = require('../services/cumulative');

const round2 = (n) => Math.round(Number(n) * 100) / 100;
const scopeSql = (scope) => (scope === 'all' ? '' : "AND a.status IN ('approved','published')");

async function currentTerm(c, termId) {
  if (termId) { const t = (await c.query('SELECT id FROM terms WHERE id = $1', [termId])).rows[0]; if (!t) throw E.notFound('Term'); return t.id; }
  const t = (await c.query('SELECT id FROM terms WHERE is_current LIMIT 1')).rows[0];
  if (!t) throw E.notFound('Current term');
  return t.id;
}

module.exports = async function analyticsRoutes(app) {
  const A = app.authenticate;
  const VIEW = app.perm('results.view', 'reports.view');

  // ── per-class workflow status for a term (Result Processing / Approval / Publishing pages) ──
  app.get('/results/overview', { onRequest: [A, app.perm('results.view')], schema: { querystring: obj({ termId: uuid }) } }, async (req) =>
    withTx(ctx(req), async (c) => {
      const termId = await currentTerm(c, req.query.termId);
      const rows = (await c.query(`SELECT cl.id, cl.display_name, cl.section,
          (SELECT count(*) FROM class_subjects cs WHERE cs.class_id = cl.id)::int AS subjects,
          (SELECT count(*) FROM student_enrollments e JOIN terms t ON t.id = $1 AND e.session_id = t.session_id JOIN students s ON s.id = e.student_id AND s.deleted_at IS NULL
             WHERE e.class_id = cl.id AND e.status <> 'withdrawn')::int AS students,
          count(a.id) FILTER (WHERE a.status = 'draft')::int AS draft, count(a.id) FILTER (WHERE a.status = 'submitted')::int AS submitted,
          count(a.id) FILTER (WHERE a.status = 'reviewed')::int AS reviewed, count(a.id) FILTER (WHERE a.status = 'approved')::int AS approved,
          count(a.id) FILTER (WHERE a.status = 'published')::int AS published,
          (SELECT max(rs.computed_at) FROM result_summaries rs WHERE rs.term_id = $1 AND rs.class_id = cl.id) AS processed_at,
          EXISTS (SELECT 1 FROM result_summaries rs WHERE rs.term_id = $1 AND rs.class_id = cl.id AND rs.published) AS is_published
        FROM classes cl LEFT JOIN assessments a ON a.class_id = cl.id AND a.term_id = $1
        GROUP BY cl.id ORDER BY cl.sort_order, cl.display_name`, [termId])).rows;
      for (const r of rows) {
        r.not_started = Math.max(0, r.subjects - (r.draft + r.submitted + r.reviewed + r.approved + r.published));
        r.ready_to_publish = r.subjects > 0 && r.not_started === 0 && r.draft + r.submitted + r.reviewed === 0 && r.approved > 0;
      }
      return { termId, items: rows, requireReview: (await R.settings(c)).results_require_review !== false };
    }));

  // ── approval queue: sheets waiting for review / approval across the school ──
  app.get('/results/queue', {
    onRequest: [A, app.perm('results.review', 'results.approve', 'results.publish')],
    schema: { querystring: obj({ termId: uuid, status: { enum: ['awaiting', 'draft', 'submitted', 'reviewed', 'approved', 'published'], default: 'awaiting' } }) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const termId = await currentTerm(c, req.query.termId);
    const st = req.query.status === 'awaiting' ? ['submitted', 'reviewed'] : [req.query.status];
    const requireReview = (await R.settings(c)).results_require_review !== false;
    const rows = (await c.query(`SELECT a.id, a.status, a.version, a.submitted_at, a.reviewed_at, a.approved_at, a.review_note, a.submitted_by,
        s.name AS subject, cl.display_name AS class_name, cl.id AS class_id, st.full_name AS teacher, su.full_name AS submitted_by_name,
        (SELECT count(DISTINCT x.student_id)::int FROM assessment_scores x WHERE x.sheet_id = a.id) AS scored
      FROM assessments a JOIN subjects s ON s.id = a.subject_id JOIN classes cl ON cl.id = a.class_id
      LEFT JOIN class_subjects cs ON cs.class_id = a.class_id AND cs.subject_id = a.subject_id LEFT JOIN staff st ON st.id = cs.teacher_id
      LEFT JOIN users su ON su.id = a.submitted_by
      WHERE a.term_id = $1 AND a.status = ANY($2::text[]) ORDER BY a.submitted_at NULLS LAST, cl.sort_order, cl.display_name, s.name LIMIT 500`, [termId, st])).rows;
    for (const r of rows) {
      const mine = r.submitted_by === req.auth.userId; delete r.submitted_by;
      r.can_review = !mine && req.can('results.review') && r.status === 'submitted';
      r.can_approve = !mine && req.can('results.approve') && (r.status === 'reviewed' || (r.status === 'submitted' && !requireReview));
      r.mine = mine;
    }
    return { termId, requireReview, items: rows };
  }));

  // ── result processing: (re)compute provisional totals, averages, grades and positions ──
  app.post('/results/process', {
    onRequest: [A, app.perm('results.approve', 'results.publish', 'results.enter_any')],
    schema: { body: obj({ termId: uuid, classId: uuid }, ['termId']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const termId = await currentTerm(c, req.body.termId);
    let classes = (await c.query(`SELECT DISTINCT cl.id, cl.display_name FROM classes cl JOIN assessments a ON a.class_id = cl.id AND a.term_id = $1
      ${req.body.classId ? 'WHERE cl.id = $2' : ''} ORDER BY cl.display_name`, req.body.classId ? [termId, req.body.classId] : [termId])).rows;
    if (req.body.classId && !classes.length) {
      if (!(await c.query('SELECT 1 FROM classes WHERE id = $1', [req.body.classId])).rowCount) throw E.notFound('Class');
      throw E.bad('This class has no score sheets for the term yet.');
    }
    const out = [];
    for (const cl of classes) {
      await c.query('SELECT pg_advisory_xact_lock(hashtextextended($1, 0))', [`publish:${termId}:${cl.id}`]);
      const published = (await c.query('SELECT 1 FROM result_summaries WHERE term_id = $1 AND class_id = $2 AND published LIMIT 1', [termId, cl.id])).rowCount > 0;
      if (published) { out.push({ classId: cl.id, className: cl.display_name, skipped: 'published' }); continue; }
      for (const sh of (await c.query('SELECT id FROM assessments WHERE term_id = $1 AND class_id = $2', [termId, cl.id])).rows) await R.recomputeSheet(c, sh.id);
      const rows = await R.computeClassTerm(c, termId, cl.id, { publish: false });
      out.push({ classId: cl.id, className: cl.display_name, students: rows.length, withResults: rows.filter((r) => r.status !== 'Pending').length });
    }
    classes = null;
    await audit(c, req, 'results.processed', { type: 'term', id: termId, meta: { classes: out.length, classId: req.body.classId || null } });
    return { termId, items: out };
  }));

  // ── annual (cumulative) broadsheet for a session ──
  app.get('/results/annual', {
    onRequest: [A, app.perm('results.view')], config: { rateLimit: { max: 30, timeWindow: '1 minute' } },
    schema: { querystring: obj({ sessionId: uuid, classId: uuid }, ['classId']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const se = req.query.sessionId
      ? (await c.query('SELECT id, name FROM academic_sessions WHERE id = $1', [req.query.sessionId])).rows[0]
      : (await c.query('SELECT id, name FROM academic_sessions WHERE is_current LIMIT 1')).rows[0];
    if (!se) throw E.notFound('Session');
    const cl = (await c.query('SELECT id, display_name, section FROM classes WHERE id = $1', [req.query.classId])).rows[0];
    if (!cl) throw E.notFound('Class');
    const terms = (await c.query('SELECT id, name FROM terms WHERE session_id = $1 ORDER BY name', [se.id])).rows;
    const students = (await c.query(`SELECT s.id, s.first_name, s.last_name, s.admission_no, s.gender FROM student_enrollments e JOIN students s ON s.id = e.student_id AND s.deleted_at IS NULL
      WHERE e.session_id = $1 AND e.class_id = $2 AND e.status <> 'withdrawn' ORDER BY s.last_name, s.first_name`, [se.id, cl.id])).rows;
    const cells = (await c.query(`SELECT a.term_id, a.subject_id, sb.name AS subject, a.status, er.student_id, er.total FROM assessments a
      JOIN subjects sb ON sb.id = a.subject_id JOIN examination_results er ON er.sheet_id = a.id
      WHERE a.class_id = $1 AND a.term_id = ANY($2::uuid[])`, [cl.id, terms.map((t) => t.id)])).rows;
    const summaries = (await c.query('SELECT term_id, student_id, average, position FROM result_summaries WHERE class_id = $1 AND term_id = ANY($2::uuid[])', [cl.id, terms.map((t) => t.id)])).rows;
    const st = await R.settings(c); const bands = R.bandsFor(st, cl.section); const passMark = Number(st.pass_mark);
    const subjects = [...new Map(cells.map((x) => [x.subject_id, { id: x.subject_id, name: x.subject }])).values()].sort((a, b) => a.name.localeCompare(b.name));
    const cell = new Map(cells.map((x) => [`${x.student_id}:${x.subject_id}:${x.term_id}`, Number(x.total)]));
    const summ = new Map(summaries.map((x) => [`${x.student_id}:${x.term_id}`, x]));
    const rows = students.map((s) => {
      const subj = subjects.map((sb) => {
        const termTotals = terms.map((t) => (cell.has(`${s.id}:${sb.id}:${t.id}`) ? cell.get(`${s.id}:${sb.id}:${t.id}`) : null));
        const got = termTotals.filter((v) => v !== null);
        const annual = got.length ? round2(got.reduce((a, b) => a + b, 0) / got.length) : null;
        return { termTotals, annual, grade: annual === null ? null : G.gradeFor(annual, bands).grade };
      });
      const annuals = subj.map((x) => x.annual).filter((v) => v !== null);
      const annualAverage = annuals.length ? round2(annuals.reduce((a, b) => a + b, 0) / annuals.length) : null;
      return {
        studentId: s.id, name: `${s.last_name} ${s.first_name}`, admissionNo: s.admission_no, gender: s.gender, subjects: subj,
        termAverages: terms.map((t) => { const x = summ.get(`${s.id}:${t.id}`); return x ? Number(x.average) : null; }),
        annualTotal: annuals.length ? round2(annuals.reduce((a, b) => a + b, 0)) : null, annualAverage,
        grade: annualAverage === null ? null : G.gradeFor(annualAverage, bands).grade,
        status: annualAverage === null ? 'Pending' : annualAverage >= passMark ? 'Pass' : 'Fail',
      };
    });
    const pos = G.rank(rows.filter((r) => r.annualAverage !== null).map((r) => ({ id: r.studentId, value: r.annualAverage })));
    for (const r of rows) r.position = pos.get(r.studentId) || null;
    rows.sort((a, b) => (a.position || 1e9) - (b.position || 1e9) || a.name.localeCompare(b.name));
    return { session: se.name, sessionId: se.id, classId: cl.id, class_name: cl.display_name, terms, subjects, rows, passMark,
      provisional: cells.some((x) => x.status !== 'published'), classSize: rows.length };
  }));

  // ── cumulative result sheet: every term of the session up to the chosen term (3rd term = whole session) ──
  app.get('/results/cumulative', {
    onRequest: [A, app.perm('results.view')], config: { rateLimit: { max: 30, timeWindow: '1 minute' } },
    schema: { querystring: obj({ termId: uuid, classId: uuid }, ['classId']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const termId = await currentTerm(c, req.query.termId);
    return CUM.classCumulative(c, termId, req.query.classId);
  }));

  // ── school / class / subject performance for a term ──
  app.get('/results/analytics', {
    onRequest: [A, VIEW], config: { rateLimit: { max: 30, timeWindow: '1 minute' } },
    schema: { querystring: obj({ termId: uuid, classId: uuid, scope: { enum: ['approved', 'all'], default: 'approved' } }) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const termId = await currentTerm(c, req.query.termId);
    const passMark = Number((await R.settings(c)).pass_mark);
    const sc = scopeSql(req.query.scope); const cls = req.query.classId || null;
    if (cls && !(await c.query('SELECT 1 FROM classes WHERE id = $1', [cls])).rowCount) throw E.notFound('Class');
    const p = [termId, passMark, cls];
    const base = `FROM examination_results er JOIN assessments a ON a.id = er.sheet_id WHERE a.term_id = $1 AND $2::numeric >= 0 ${sc} AND ($3::uuid IS NULL OR a.class_id = $3)`;
    const perStudent = `SELECT a.class_id, er.student_id, avg(er.total) AS avg_total, count(*) AS n ${base} GROUP BY a.class_id, er.student_id`;
    const totals = (await c.query(`WITH ps AS (${perStudent}) SELECT count(*)::int AS students, round(avg(avg_total), 2) AS average,
        count(*) FILTER (WHERE avg_total >= $2)::int AS passed, round(max(avg_total), 2) AS highest, round(min(avg_total), 2) AS lowest FROM ps`, p)).rows[0];
    const byClass = (await c.query(`WITH ps AS (${perStudent}) SELECT cl.id, cl.display_name, count(*)::int AS students, round(avg(ps.avg_total), 2) AS average,
        round(max(ps.avg_total), 2) AS highest, round(min(ps.avg_total), 2) AS lowest, count(*) FILTER (WHERE ps.avg_total >= $2)::int AS passed
      FROM ps JOIN classes cl ON cl.id = ps.class_id GROUP BY cl.id ORDER BY cl.sort_order, cl.display_name`, p)).rows;
    const bySubject = (await c.query(`SELECT sb.id, sb.name, count(*)::int AS entries, round(avg(er.total), 2) AS average, max(er.total) AS highest, min(er.total) AS lowest,
        count(*) FILTER (WHERE er.total >= $2)::int AS passed
      ${base.replace('FROM examination_results er JOIN assessments a ON a.id = er.sheet_id', 'FROM examination_results er JOIN assessments a ON a.id = er.sheet_id JOIN subjects sb ON sb.id = a.subject_id')}
      GROUP BY sb.id ORDER BY avg(er.total) DESC`, p)).rows;
    const subjGrades = (await c.query(`SELECT a.subject_id, er.grade, count(*)::int AS n ${base} GROUP BY a.subject_id, er.grade`, p)).rows;
    for (const s of bySubject) { s.grades = Object.fromEntries(subjGrades.filter((g) => g.subject_id === s.id).map((g) => [g.grade, g.n])); s.pass_rate = s.entries ? round2(s.passed / s.entries * 100) : 0; }
    const grades = (await c.query(`SELECT er.grade, count(*)::int AS n ${base} GROUP BY er.grade ORDER BY er.grade`, p)).rows;
    const top = (await c.query(`WITH ps AS (${perStudent}) SELECT s.id, s.first_name, s.last_name, s.admission_no, cl.display_name AS class_name, round(ps.avg_total, 2) AS average, ps.n::int AS subjects
      FROM ps JOIN students s ON s.id = ps.student_id JOIN classes cl ON cl.id = ps.class_id ORDER BY ps.avg_total DESC, s.last_name LIMIT 10`, p)).rows;
    const bottom = (await c.query(`WITH ps AS (${perStudent}) SELECT s.id, s.first_name, s.last_name, s.admission_no, cl.display_name AS class_name, round(ps.avg_total, 2) AS average, ps.n::int AS subjects
      FROM ps JOIN students s ON s.id = ps.student_id JOIN classes cl ON cl.id = ps.class_id ORDER BY ps.avg_total ASC, s.last_name LIMIT 10`, p)).rows;
    const gender = (await c.query(`WITH ps AS (${perStudent}) SELECT COALESCE(s.gender, 'Unknown') AS gender, count(*)::int AS students, round(avg(ps.avg_total), 2) AS average,
        count(*) FILTER (WHERE ps.avg_total >= $2)::int AS passed FROM ps JOIN students s ON s.id = ps.student_id GROUP BY 1 ORDER BY 1`, p)).rows;
    for (const x of [...byClass, ...gender]) x.pass_rate = x.students ? round2(x.passed / x.students * 100) : 0;
    const term = (await c.query('SELECT t.id, t.name, se.name AS session FROM terms t JOIN academic_sessions se ON se.id = t.session_id WHERE t.id = $1', [termId])).rows[0];
    return { term, scope: req.query.scope, passMark, totals: { ...totals, pass_rate: totals.students ? round2(totals.passed / totals.students * 100) : 0 }, byClass, bySubject, grades, top, bottom, gender };
  }));

  // ── one learner across terms (Student Performance) ──
  app.get('/results/analytics/student/:id', { onRequest: [A, app.perm('results.view')], schema: { params: idParams } }, async (req) =>
    withTx(ctx(req), async (c) => {
      const s = (await c.query('SELECT id, first_name, last_name, other_names, admission_no, gender, passport_file_id FROM students WHERE id = $1 AND deleted_at IS NULL', [req.params.id])).rows[0];
      if (!s) throw E.notFound('Student');
      const cells = (await c.query(`SELECT t.id AS term_id, t.name AS term, se.name AS session, se.starts_on, cl.display_name AS class_name, sb.name AS subject, er.total, er.grade, er.subject_position, a.status
        FROM examination_results er JOIN assessments a ON a.id = er.sheet_id JOIN terms t ON t.id = a.term_id JOIN academic_sessions se ON se.id = t.session_id
        JOIN classes cl ON cl.id = a.class_id JOIN subjects sb ON sb.id = a.subject_id WHERE er.student_id = $1 ORDER BY se.starts_on NULLS LAST, se.name, t.name, sb.name`, [s.id])).rows;
      const summ = new Map((await c.query('SELECT term_id, average, position, class_size, grade, published FROM result_summaries WHERE student_id = $1', [s.id])).rows.map((x) => [x.term_id, x]));
      const terms = [];
      for (const x of cells) {
        let t = terms.find((y) => y.termId === x.term_id);
        if (!t) { t = { termId: x.term_id, label: `${x.session} · ${x.term}`, className: x.class_name, totals: [], published: true }; terms.push(t); }
        t.totals.push(Number(x.total)); if (x.status !== 'published') t.published = false;
      }
      for (const t of terms) {
        const sm = summ.get(t.termId);
        t.average = round2(t.totals.reduce((a, b) => a + b, 0) / t.totals.length); t.subjects = t.totals.length; delete t.totals;
        t.position = sm ? sm.position : null; t.classSize = sm ? sm.class_size : null; t.grade = sm ? sm.grade : null;
      }
      const subjects = [...new Set(cells.map((x) => x.subject))].map((name) => ({ name, byTerm: Object.fromEntries(cells.filter((x) => x.subject === name).map((x) => [x.term_id, { total: Number(x.total), grade: x.grade, position: x.subject_position }])) }));
      return { student: s, terms, subjects };
    }));

  // ── teacher activity for a term ──
  app.get('/teachers/activity', { onRequest: [A, app.perm('teachers.view')], schema: { querystring: obj({ termId: uuid }) } }, async (req) =>
    withTx(ctx(req), async (c) => {
      const termId = await currentTerm(c, req.query.termId);
      const rows = (await c.query(`SELECT t.id, s.id AS staff_id, s.full_name, s.employee_id, u.last_login_at, (u.id IS NOT NULL) AS has_account,
          (SELECT count(*) FROM (SELECT DISTINCT x.class_id, x.subject_id FROM teacher_class_access x WHERE x.staff_id = s.id AND x.subject_id IS NOT NULL) y)::int AS subjects_assigned,
          (SELECT count(DISTINCT x.class_id) FROM teacher_class_access x WHERE x.staff_id = s.id)::int AS classes,
          (SELECT count(DISTINCT a.id) FROM assessments a JOIN teacher_class_access x ON x.staff_id = s.id AND x.class_id = a.class_id AND x.subject_id = a.subject_id WHERE a.term_id = $1)::int AS sheets_started,
          (SELECT count(DISTINCT a.id) FROM assessments a JOIN teacher_class_access x ON x.staff_id = s.id AND x.class_id = a.class_id AND x.subject_id = a.subject_id WHERE a.term_id = $1 AND a.status <> 'draft')::int AS sheets_submitted,
          (SELECT count(DISTINCT a.id) FROM assessments a JOIN teacher_class_access x ON x.staff_id = s.id AND x.class_id = a.class_id AND x.subject_id = a.subject_id WHERE a.term_id = $1 AND a.status IN ('approved','published'))::int AS sheets_approved,
          (SELECT count(*) FROM assessment_scores sc JOIN assessments a ON a.id = sc.sheet_id WHERE a.term_id = $1 AND sc.entered_by = s.user_id AND s.user_id IS NOT NULL)::int AS scores_entered,
          (SELECT max(sc.updated_at) FROM assessment_scores sc JOIN assessments a ON a.id = sc.sheet_id WHERE a.term_id = $1 AND sc.entered_by = s.user_id AND s.user_id IS NOT NULL) AS last_score_at,
          (SELECT count(*) FROM attendance_sessions ats WHERE ats.term_id = $1 AND ats.taken_by = s.user_id AND s.user_id IS NOT NULL)::int AS registers_taken
        FROM teachers t JOIN staff s ON s.id = t.staff_id LEFT JOIN users u ON u.id = s.user_id
        WHERE t.status = 'active' ORDER BY s.full_name`, [termId])).rows;
      return { termId, items: rows };
    }));
};
