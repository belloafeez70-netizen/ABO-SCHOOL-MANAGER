'use strict';
const crypto = require('node:crypto');
const config = require('../config');
const { withTx, raw } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, str, optStr, email, phone } = require('../lib/schema');
const pw = require('../security/passwords');
const { sha256, randomToken } = require('../security/crypto');
const { createSchool } = require('../services/provision');
const { queueEmail } = require('../services/notify');
const { audit, securityEvent } = require('../audit/audit');
const { ctx } = require('../auth/plugin');

module.exports = async function onboardingRoutes(app) {
  // public self-registration (rate-limited); school stays 'pending' until the owner verifies their email
  app.post('/onboarding/register', {
    config: { rateLimit: { max: config.rateLimit.registerPerHour, timeWindow: '1 hour' } },
    schema: { body: obj({
      school: obj({ name: str(160, 2), slug: { type: 'string', pattern: '^[a-z0-9-]{3,30}$' }, registrationNumber: optStr(60), schoolType: { enum: ['primary', 'secondary', 'mixed'] },
        address: optStr(300), phone, email, website: optStr(160), motto: optStr(160) }, ['name', 'slug', 'schoolType']),
      owner: obj({ fullName: str(160, 2), firstName: str(80, 1), lastName: str(80, 1), loginId: { type: 'string', pattern: '^[A-Za-z0-9._@-]{3,64}$' }, email: { type: 'string', format: 'email', maxLength: 160 }, phone, password: str(128, 1) },
        ['loginId', 'email', 'password']),
    }, ['school', 'owner']) },
  }, async (req) => {
    const { school, owner } = req.body;
    owner.fullName = owner.fullName || [owner.firstName, owner.lastName].filter(Boolean).join(' ');
    if (owner.fullName.length < 2) throw E.bad('Give your first and last name.', { field: 'firstName' });
    const errs = pw.checkPolicy(owner.password, { loginId: owner.loginId, fullName: owner.fullName, staff: true });
    if (errs.length) throw E.bad(errs.join(' '), { password: errs });
    if ((await raw('SELECT app.school_slug_taken($1) AS t', [school.slug])).rows[0].t) throw E.conflict('That school web address (slug) is already taken.');
    if ((await raw('SELECT app.email_taken($1) AS t', [owner.email])).rows[0].t) throw E.conflict('That email already has an A.B.O. account — sign in and ask to be invited, or use another email.');
    if ((await raw('SELECT app.login_id_taken($1) AS t', [owner.loginId])).rows[0].t) throw E.conflict('That Login ID is already taken.');
    const schoolId = crypto.randomUUID();
    const hash = await pw.hash(owner.password);
    const token = randomToken(32);
    await withTx({ schoolId }, async (c) => {
      const roles = await createSchool(c, { id: schoolId, ...school, email: school.email || owner.email, status: 'pending' });
      const u = (await c.query(`INSERT INTO users (school_id, login_id, email, full_name, phone, password_hash, password_changed_at)
        VALUES ($1,$2,$3,$4,$5,$6, now()) RETURNING id`, [schoolId, owner.loginId, owner.email, owner.fullName, owner.phone || null, hash])).rows[0];
      await c.query("INSERT INTO school_memberships (user_id, school_id, status, is_default) VALUES ($1,$2,'active',true)", [u.id, schoolId]);
      await c.query('INSERT INTO user_roles (school_id, user_id, role_id) VALUES ($1,$2,$3)', [schoolId, u.id, roles.school_owner]);
      await c.query("INSERT INTO user_tokens (user_id, school_id, kind, token_hash, expires_at) VALUES ($1,$2,'email_verify',$3, now() + interval '48 hours')", [u.id, schoolId, sha256(token)]);
      await queueEmail(c, { schoolId, to: owner.email, subject: `Verify your email to activate ${school.name}`, template: 'verify_email',
        body: `Hello ${owner.fullName},\n\nWelcome to A.B.O. School Manager. Verify your email within 48 hours to activate ${school.name}:\n\n${config.publicOrigin}/#/verify?token=${token}\n` });
      await audit(c, { ip: req.ip, headers: req.headers, auth: { schoolId, userId: u.id, loginId: owner.loginId, roles: ['school_owner'] } }, 'school.registered', { type: 'school', id: schoolId, meta: { slug: school.slug, type: school.schoolType } });
    });
    securityEvent({ schoolId, kind: 'school_registered', severity: 'info', detail: { slug: school.slug }, ip: req.ip });
    return {
      ok: true, message: config.schoolApproval === 'auto' ? 'School registered. Check your email to verify and activate your account.' : 'School registered. Check your email to verify your address — the A.B.O. team will then approve your school and send you its own sign-in link.',
      // development/test ONLY: lets you finish onboarding without an SMTP server. Never returned in staging/production.
      ...(!config.isProdLike ? { devVerificationToken: token } : {}),
    };
  });

  // onboarding checklist computed from real data
  app.get('/onboarding/status', { onRequest: [app.authenticate, app.perm('settings.view')] }, async (req) => {
    return withTx(ctx(req), async (c) => {
      const q = async (sql) => (await c.query(sql)).rows[0];
      const s = await q(`SELECT s.name, s.address, s.phone, s.email, s.logo_file_id, s.email_verified_at, ss.updated_at > s.created_at + interval '1 second' AS settings_touched
        FROM schools s JOIN school_settings ss ON ss.school_id = s.id LIMIT 1`);
      const n = await q(`SELECT (SELECT count(*) FROM academic_sessions)::int AS sessions, (SELECT count(*) FROM terms WHERE is_current)::int AS current_terms,
        (SELECT count(*) FROM classes)::int AS classes, (SELECT count(*) FROM subjects)::int AS subjects, (SELECT count(*) FROM class_subjects)::int AS class_subjects,
        (SELECT count(*) FROM students WHERE deleted_at IS NULL)::int AS students, (SELECT count(*) FROM staff)::int AS staff,
        (SELECT count(*) FROM user_roles)::int AS role_grants, (SELECT count(*) FROM fee_structures)::int AS fee_items`);
      const steps = [
        { key: 'register', label: 'Register school', done: true },
        { key: 'verify', label: 'Verify owner email', done: !!s.email_verified_at },
        { key: 'profile', label: 'Complete school profile (address, phone, email)', done: !!(s.address && s.phone && s.email), link: '#/settings' },
        { key: 'session', label: 'Create academic session', done: n.sessions > 0, link: '#/academic' },
        { key: 'term', label: 'Set the current term', done: n.current_terms > 0, link: '#/academic' },
        { key: 'classes', label: 'Create classes & arms', done: n.classes > 0, link: '#/academic' },
        { key: 'subjects', label: 'Add subjects and assign to classes', done: n.subjects > 0 && n.class_subjects > 0, link: '#/academic' },
        { key: 'students', label: 'Import or add students', done: n.students > 0, link: '#/students' },
        { key: 'staff', label: 'Add teachers & staff', done: n.staff > 0, link: '#/staff' },
        { key: 'roles', label: 'Give staff accounts & roles', done: n.role_grants > 1, link: '#/users' },
        { key: 'grading', label: 'Review grading & assessment components', done: !!s.settings_touched, link: '#/settings' },
        { key: 'fees', label: 'Configure fees', done: n.fee_items > 0, link: '#/fees' },
        { key: 'logo', label: 'Upload school logo', done: !!s.logo_file_id, link: '#/settings' },
      ];
      return { steps, done: steps.filter((x) => x.done).length, total: steps.length };
    });
  });
};
