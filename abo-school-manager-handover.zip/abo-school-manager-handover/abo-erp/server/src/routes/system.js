'use strict';
// School-facing system information, help/support contacts and the school data backup (Excel workbook).
// Nothing here exposes server internals (no hostnames, versions of Node/PostgreSQL, secrets or env vars).
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { ctx } = require('../auth/plugin');
const { audit } = require('../audit/audit');
const { enqueue } = require('../services/notify');
const config = require('../config');
const pkg = require('../../../package.json');

module.exports = async function systemRoutes(app) {
  const A = app.authenticate;

  app.get('/system/info', { onRequest: [A, app.perm('settings.view')] }, async (req) =>
    withTx(ctx(req), async (c) => {
      const school = (await c.query(`SELECT name, slug, status, plan, max_students, subscription_status, subscription_expires_at, created_at, approved_at, timezone, currency
        FROM schools WHERE id = $1`, [req.auth.schoolId])).rows[0];
      const usage = (await c.query(`SELECT
          (SELECT count(*) FROM students WHERE deleted_at IS NULL AND status = 'active')::int AS students,
          (SELECT count(*) FROM staff WHERE employment_status <> 'exited')::int AS staff,
          (SELECT count(*) FROM active_members)::int AS users,
          (SELECT count(*) FROM active_members m JOIN users u ON u.id = m.id WHERE u.mfa_enabled)::int AS users_with_2fa,
          (SELECT count(*) FROM classes)::int AS classes, (SELECT count(*) FROM subjects)::int AS subjects,
          (SELECT count(*) FROM documents)::int AS documents,
          (SELECT COALESCE(sum(size_bytes), 0)::bigint FROM uploads WHERE deleted_at IS NULL AND school_id = app.current_school()) AS storage_bytes`)).rows[0];
      const migration = (await c.query('SELECT version FROM schema_migrations ORDER BY version DESC LIMIT 1')).rows[0];
      const term = (await c.query('SELECT t.name, se.name AS session FROM terms t JOIN academic_sessions se ON se.id = t.session_id WHERE t.is_current LIMIT 1')).rows[0] || null;
      return {
        app: { name: 'A.B.O. School Manager', version: pkg.version, api: 'v1', schema: migration ? migration.version : null, environment: config.isProdLike ? config.env : 'development', serverTime: new Date().toISOString() },
        school: { ...school, portal_url: `${config.publicOrigin}/#/s/${school.slug}` }, usage, currentTerm: term,
        backups: { managedBy: 'platform', description: 'The A.B.O. platform keeps continuous point-in-time recovery of the database plus encrypted nightly backups stored separately. You can also download your own copy of your school data at any time.' },
      };
    }));

  // help & support contacts (every signed-in user)
  app.get('/system/support', { onRequest: [A] }, async () => ({
    email: config.support.email || null, phone: config.support.phone || null, hours: config.support.hours,
  }));

  // full school data backup → background job → Excel workbook (one sheet per dataset the requester may export)
  app.post('/school/backup', { onRequest: [A, app.perm('reports.export')], config: { rateLimit: { max: 3, timeWindow: '10 minutes' } } }, async (req) => {
    if (!req.can('settings.view')) throw E.forbidden('A school data backup requires access to school settings.');
    return withTx({ ...ctx(req), readOnly: false }, async (c) => {
      const jobId = await enqueue(c, { schoolId: req.auth.schoolId, kind: 'backup.build', payload: { userId: req.auth.userId }, createdBy: req.auth.userId });
      await audit(c, req, 'data.backup_requested', { type: 'backup', id: jobId });
      return { jobId };
    });
  });
};
