'use strict';
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, str, optStr, uuid, phone, idParams, listQuery } = require('../lib/schema');
const { notify } = require('../services/notify');
const { page, paged, likeEscape } = require('../lib/http');
const { ctx, invalidateSchool, invalidateUser } = require('../auth/plugin');
const { audit, securityEvent } = require('../audit/audit');
const { sha256, humanCode } = require('../security/crypto');
const { PERMISSIONS, SELF_SCOPED } = require('../rbac/catalog');

const ACCESS_CODE_DAYS = 7;

// Privilege-escalation guard: you may only grant roles whose permissions you hold yourself.
async function assertCanGrant(c, req, roleIds) {
  if (!roleIds.length) return [];
  const roles = (await c.query('SELECT id, key, name FROM roles WHERE id = ANY($1::uuid[])', [roleIds])).rows;
  if (roles.length !== roleIds.length) throw E.notFound('Role');
  const perms = (await c.query('SELECT DISTINCT permission_key FROM role_permissions WHERE role_id = ANY($1::uuid[])', [roleIds])).rows.map((r) => r.permission_key);
  const missing = perms.filter((p) => !SELF_SCOPED.has(p) && !req.auth.perms.has(p));
  if (missing.length) throw E.forbidden('You cannot grant a role with permissions you do not have yourself.');
  if (roles.some((r) => r.key === 'school_owner') && !req.auth.roles.some((r) => r.key === 'school_owner')) throw E.forbidden('Only a School Owner can grant the School Owner role.');
  return roles;
}
async function roleIdsFor(c, keys) {
  if (!keys || !keys.length) return [];
  const r = await c.query('SELECT id, key FROM roles WHERE key = ANY($1::text[])', [keys]);
  if (r.rowCount !== new Set(keys).size) throw E.bad('One or more roles do not exist.');
  return r.rows.map((x) => x.id);
}
async function issueCode(c, userId) {
  const code = humanCode(10);
  await c.query(`UPDATE users SET access_code_hash = $2, access_code_expires_at = now() + make_interval(days => $3), failed_attempts = 0, locked_until = NULL WHERE id = $1`,
    [userId, sha256(code), ACCESS_CODE_DAYS]);
  return { accessCode: `${code.slice(0, 5)}-${code.slice(5)}`, expiresInDays: ACCESS_CODE_DAYS };
}
// identity-level operations (profile, credentials, MFA) only for identities this school exclusively owns
async function assertExclusive(c, req, userId) {
  const n = (await c.query('SELECT app.other_memberships($1, $2) AS n', [userId, req.auth.schoolId])).rows[0].n;
  if (n > 0) throw E.forbidden('This person also belongs to another school. They must manage their own profile and sign-in; you can still suspend their access to your school.');
}
async function memberExists(c, userId) {
  if (!(await c.query('SELECT 1 FROM school_memberships WHERE user_id = $1', [userId])).rowCount) throw E.notFound('User');
}
async function targetIsOwner(c, userId) {
  return (await c.query("SELECT 1 FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = $1 AND r.key = 'school_owner'", [userId])).rowCount > 0;
}

module.exports = async function userRoutes(app) {
  const A = app.authenticate;

  app.get('/users', { onRequest: [A, app.perm('users.view')], schema: { querystring: listQuery({ role: { type: 'string', maxLength: 40 }, status: { enum: ['active', 'disabled', 'pending'] } }) } }, async (req) => {
    const pg = page(req.query);
    return withTx(ctx(req), async (c) => {
      const p = []; const w = [];
      if (req.query.q) { p.push(`%${likeEscape(req.query.q.toLowerCase())}%`); w.push(`(lower(u.full_name) LIKE $${p.length} OR lower(u.login_id) LIKE $${p.length} OR lower(u.email) LIKE $${p.length})`); }
      if (req.query.status) { p.push(req.query.status === 'disabled' ? 'suspended' : req.query.status); w.push(`(m.status = $${p.length} OR (u.status = 'pending' AND $${p.length} = 'pending'))`); }
      if (req.query.role) { p.push(req.query.role); w.push(`EXISTS (SELECT 1 FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = u.id AND r.key = $${p.length})`); }
      const where = w.length ? 'WHERE ' + w.join(' AND ') : '';
      const from = `FROM school_memberships m JOIN users u ON u.id = m.user_id`;
      const total = (await c.query(`SELECT count(*)::int AS n ${from} ${where}`, p)).rows[0].n;
      const rows = (await c.query(`SELECT u.id, u.login_id, u.full_name, u.first_name, u.middle_name, u.last_name, u.email, u.phone,
          CASE WHEN m.status = 'suspended' THEN 'disabled' WHEN u.status = 'pending' THEN 'pending' WHEN m.status = 'invited' THEN 'invited' ELSE u.status END AS status,
          m.status AS membership_status, m.branch_id, b.name AS branch, u.mfa_enabled, u.last_login_at,
          (u.locked_until > now()) AS locked, (u.password_hash IS NULL) AS awaiting_activation,
          COALESCE((SELECT json_agg(json_build_object('key', r.key, 'name', r.name) ORDER BY r.name) FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = u.id), '[]') AS roles
        ${from} LEFT JOIN school_branches b ON b.id = m.branch_id ${where} ORDER BY u.full_name LIMIT ${pg.limit} OFFSET ${pg.offset}`, p)).rows;
      return paged(rows, total, pg);
    });
  });

  app.post('/users', {
    onRequest: [A, app.perm('users.create')],
    schema: { body: obj({
      fullName: str(160, 2), firstName: str(80, 1), middleName: optStr(80), lastName: str(80, 1), branchId: { type: ['string', 'null'], format: 'uuid' },
      loginId: { type: 'string', pattern: '^[A-Za-z0-9._@-]{3,64}$' }, email: { type: ['string', 'null'], format: 'email', maxLength: 160 }, phone,
      roleKeys: { type: 'array', items: { type: 'string', maxLength: 40 }, maxItems: 5, minItems: 1 },
      link: obj({ type: { enum: ['staff', 'student', 'guardian'] }, id: uuid }, ['type', 'id']),
    }, ['loginId', 'roleKeys']) },
  }, async (req) => {
    const b = req.body;
    if (!req.can('users.assign_role')) throw E.forbidden('You need permission to assign roles.');
    const out = await withTx(ctx(req), async (c) => {
      const roleIds = await roleIdsFor(c, b.roleKeys);
      await assertCanGrant(c, req, roleIds);
      if (!b.fullName && !(b.firstName && b.lastName)) throw E.bad('Give the person\'s first and last name.', { field: 'firstName' });
      const taken = (await c.query('SELECT app.login_id_taken($1) AS t', [b.loginId])).rows[0].t;
      if (taken) throw E.conflict('That Login ID is already taken. If the person already has an A.B.O. account, invite them instead.');
      if (b.email && (await c.query('SELECT app.email_taken($1) AS t', [b.email])).rows[0].t) throw E.conflict('That email already belongs to an account. Invite the existing account instead.');
      const branch = req.auth.branchId || b.branchId || null;      // branch-restricted admins can only create users in their branch
      const u = (await c.query(`INSERT INTO users (school_id, login_id, email, full_name, first_name, middle_name, last_name, phone, status) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,'pending')
        RETURNING id, login_id, full_name, email, status`, [req.auth.schoolId, b.loginId, b.email || null, b.fullName || null, b.firstName || null, b.middleName || null, b.lastName || null, b.phone || null])).rows[0];
      await c.query('INSERT INTO school_memberships (user_id, school_id, branch_id, status, is_default, invited_by) VALUES ($1,$2,$3,\'active\',true,$4)', [u.id, req.auth.schoolId, branch, req.auth.userId]);
      for (const rid of roleIds) await c.query('INSERT INTO user_roles (school_id, user_id, role_id, granted_by) VALUES ($1,$2,$3,$4)', [req.auth.schoolId, u.id, rid, req.auth.userId]);
      if (b.link) {
        const table = { staff: 'staff', student: 'students', guardian: 'guardians' }[b.link.type];
        const r = await c.query(`UPDATE ${table} SET user_id = $2 WHERE id = $1 AND user_id IS NULL RETURNING id`, [b.link.id, u.id]);
        if (!r.rowCount) throw E.bad(`That ${b.link.type} record was not found or already has an account.`);
      }
      const code = await issueCode(c, u.id);
      await audit(c, req, 'users.created', { type: 'user', id: u.id, meta: { loginId: b.loginId, roles: b.roleKeys, link: b.link ? b.link.type : null } });
      return { user: u, ...code };
    });
    return out;
  });

  app.patch('/users/:id', {
    onRequest: [A, app.perm('users.update')],
    schema: { params: idParams, body: obj({ fullName: str(160, 2), email: { type: ['string', 'null'], format: 'email', maxLength: 160 }, phone }) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const b = req.body;
    await memberExists(c, req.params.id); await assertExclusive(c, req, req.params.id);
    const r = await c.query(`UPDATE users SET full_name = COALESCE($2, full_name), email = CASE WHEN $5 THEN $3 ELSE email END, phone = CASE WHEN $6 THEN $4 ELSE phone END
      WHERE id = $1 RETURNING id, login_id, full_name, email, phone, status`,
    [req.params.id, b.fullName || null, b.email ?? null, b.phone ?? null, b.email !== undefined, b.phone !== undefined]);
    if (!r.rowCount) throw E.notFound('User');
    await audit(c, req, 'users.updated', { type: 'user', id: req.params.id, meta: { fields: Object.keys(b) } });
    return r.rows[0];
  }));

  app.post('/users/:id/access-code', { onRequest: [A, app.perm('users.update')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    await memberExists(c, req.params.id);
    const u = (await c.query('SELECT id, login_id, full_name FROM users WHERE id = $1', [req.params.id])).rows[0];
    if (!u) throw E.notFound('User');
    await assertExclusive(c, req, u.id);
    if (await targetIsOwner(c, u.id) && !req.auth.roles.some((r) => r.key === 'school_owner')) throw E.forbidden();
    const code = await issueCode(c, u.id);
    await audit(c, req, 'users.access_code_issued', { type: 'user', id: u.id });
    return { loginId: u.login_id, fullName: u.full_name, ...code };
  }));

  app.post('/users/:id/status', {
    onRequest: [A, app.perm('users.disable')],
    schema: { params: idParams, body: obj({ status: { enum: ['active', 'disabled'] }, reason: str(300, 3) }, ['status', 'reason']) },
  }, async (req) => {
    if (req.params.id === req.auth.userId) throw E.bad('You cannot change the status of your own account.');
    await withTx(ctx(req), async (c) => {
      if (await targetIsOwner(c, req.params.id) && !req.auth.roles.some((r) => r.key === 'school_owner')) throw E.forbidden();
      // the school controls ITS membership; the global identity is only disabled when no other school uses it
      const r = await c.query('UPDATE school_memberships SET status = $2 WHERE user_id = $1 AND school_id = $3 RETURNING id', [req.params.id, req.body.status === 'disabled' ? 'suspended' : 'active', req.auth.schoolId]);
      if (!r.rowCount) throw E.notFound('User');
      const others = (await c.query('SELECT app.other_memberships($1, $2) AS n', [req.params.id, req.auth.schoolId])).rows[0].n;
      if (!others) await c.query("UPDATE users SET status = $2 WHERE id = $1 AND status <> 'pending'", [req.params.id, req.body.status]);
      if (req.body.status === 'disabled') await c.query("UPDATE sessions SET revoked_at = now(), revoked_reason = 'membership_suspended' WHERE user_id = $1 AND school_id = $2 AND revoked_at IS NULL", [req.params.id, req.auth.schoolId]);
      await audit(c, req, req.body.status === 'disabled' ? 'users.disabled' : 'users.enabled', { type: 'user', id: req.params.id, meta: { reason: req.body.reason } });
    });
    invalidateUser(req.params.id);
    return { ok: true };
  });

  // lost phone + lost recovery codes: admin resets MFA (user must re-enrol at next sign-in if their role requires it)
  app.post('/users/:id/mfa-reset', { onRequest: [A, app.perm('users.update')], schema: { params: idParams, body: obj({ reason: str(300, 5) }, ['reason']) } }, async (req) => {
    if (req.params.id === req.auth.userId) throw E.bad('You cannot reset your own two-factor authentication.');
    await withTx(ctx(req), async (c) => {
      await memberExists(c, req.params.id); await assertExclusive(c, req, req.params.id);
      if (await targetIsOwner(c, req.params.id) && !req.auth.roles.some((r) => r.key === 'school_owner')) throw E.forbidden();
      await c.query('UPDATE users SET mfa_enabled = false, mfa_secret_enc = NULL, mfa_last_step = NULL WHERE id = $1', [req.params.id]);
      await c.query('DELETE FROM mfa_recovery_codes WHERE user_id = $1', [req.params.id]);
      await c.query("UPDATE sessions SET revoked_at = now(), revoked_reason = 'mfa_reset' WHERE user_id = $1 AND revoked_at IS NULL", [req.params.id]);
      await audit(c, req, 'users.mfa_reset', { type: 'user', id: req.params.id, meta: { reason: req.body.reason } });
    });
    invalidateUser(req.params.id);
    securityEvent({ schoolId: req.auth.schoolId, userId: req.auth.userId, kind: 'mfa_reset_by_admin', severity: 'high', detail: { target: req.params.id, reason: req.body.reason }, ip: req.ip });
    return { ok: true };
  });

  app.post('/users/:id/unlock', { onRequest: [A, app.perm('users.update')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    await memberExists(c, req.params.id);
    const r = await c.query('UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = $1 RETURNING id', [req.params.id]);
    if (!r.rowCount) throw E.notFound('User');
    await audit(c, req, 'users.unlocked', { type: 'user', id: req.params.id });
    return { ok: true };
  }));

  app.post('/users/:id/revoke-sessions', { onRequest: [A, app.perm('users.disable')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    await memberExists(c, req.params.id);
    const r = await c.query("UPDATE sessions SET revoked_at = now(), revoked_reason = 'admin_revoked' WHERE user_id = $1 AND school_id = $2 AND revoked_at IS NULL", [req.params.id, req.auth.schoolId]);
    await audit(c, req, 'users.sessions_revoked', { type: 'user', id: req.params.id, meta: { count: r.rowCount } });
    return { ok: true, revoked: r.rowCount };
  }));

  app.put('/users/:id/roles', {
    onRequest: [A, app.perm('users.assign_role')],
    schema: { params: idParams, body: obj({ roleKeys: { type: 'array', items: { type: 'string', maxLength: 40 }, maxItems: 5 } }, ['roleKeys']) },
  }, async (req) => {
    const out = await withTx(ctx(req), async (c) => {
      await memberExists(c, req.params.id);
      const next = await roleIdsFor(c, req.body.roleKeys);
      const current = (await c.query('SELECT role_id FROM user_roles WHERE user_id = $1', [req.params.id])).rows.map((r) => r.role_id);
      const added = next.filter((x) => !current.includes(x)); const removed = current.filter((x) => !next.includes(x));
      await assertCanGrant(c, req, added);
      await assertCanGrant(c, req, removed);   // you also cannot strip roles more powerful than your own
      const ownerRole = (await c.query("SELECT id FROM roles WHERE key = 'school_owner'")).rows[0];
      if (ownerRole && removed.includes(ownerRole.id)) {
        const owners = (await c.query('SELECT count(*)::int AS n FROM user_roles WHERE role_id = $1', [ownerRole.id])).rows[0].n;
        if (owners <= 1) throw E.bad('A school must keep at least one School Owner.');
      }
      if (removed.length) await c.query('DELETE FROM user_roles WHERE user_id = $1 AND role_id = ANY($2::uuid[])', [req.params.id, removed]);
      for (const rid of added) await c.query('INSERT INTO user_roles (school_id, user_id, role_id, granted_by) VALUES ($1,$2,$3,$4)', [req.auth.schoolId, req.params.id, rid, req.auth.userId]);
      await audit(c, req, 'users.roles_changed', { type: 'user', id: req.params.id, meta: { roles: req.body.roleKeys, added: added.length, removed: removed.length } });
      return { ok: true };
    });
    invalidateUser(req.params.id);
    securityEvent({ schoolId: req.auth.schoolId, userId: req.auth.userId, kind: 'role_change', severity: 'low', detail: { target: req.params.id, roles: req.body.roleKeys }, ip: req.ip });
    return out;
  });

  // invite an EXISTING A.B.O. account (e.g. a proprietor who runs two schools); they accept from their account
  app.post('/users/invite', {
    onRequest: [A, app.perm('users.create')],
    schema: { body: obj({ login: str(160, 3), roleKeys: { type: 'array', items: { type: 'string', maxLength: 40 }, minItems: 1, maxItems: 5 }, branchId: { type: ['string', 'null'], format: 'uuid' } }, ['login', 'roleKeys']) },
  }, async (req) => {
    if (!req.can('users.assign_role')) throw E.forbidden('You need permission to assign roles.');
    return withTx(ctx(req), async (c) => {
      const uid = (await c.query('SELECT app.find_user_id($1) AS id', [req.body.login])).rows[0].id;
      if (!uid) throw E.notFound('Account');
      if ((await c.query('SELECT 1 FROM school_memberships WHERE user_id = $1', [uid])).rowCount) throw E.conflict('This person is already a member of your school.');
      const roleIds = await roleIdsFor(c, req.body.roleKeys);
      await assertCanGrant(c, req, roleIds);
      await c.query("INSERT INTO school_memberships (user_id, school_id, branch_id, status, invited_by) VALUES ($1,$2,$3,'invited',$4)", [uid, req.auth.schoolId, req.auth.branchId || req.body.branchId || null, req.auth.userId]);
      for (const rid of roleIds) await c.query('INSERT INTO user_roles (school_id, user_id, role_id, granted_by) VALUES ($1,$2,$3,$4)', [req.auth.schoolId, uid, rid, req.auth.userId]);
      await notify(c, req.auth.schoolId, [uid], { kind: 'invitation', title: 'You have been invited to join a school on A.B.O.', body: 'Open My account → Schools to accept or decline.', link: '#/account' });
      await audit(c, req, 'users.invited', { type: 'user', id: uid, meta: { roles: req.body.roleKeys } });
      return { ok: true, userId: uid, status: 'invited' };
    });
  });
  // restrict a member to one branch (or lift the restriction)
  app.put('/users/:id/membership', {
    onRequest: [A, app.perm('users.update')], schema: { params: idParams, body: obj({ branchId: { type: ['string', 'null'], format: 'uuid' } }, ['branchId']) },
  }, async (req) => {
    if (req.auth.branchId) throw E.forbidden('Branch-restricted administrators cannot change branch assignments.');
    const out = await withTx(ctx(req), async (c) => {
      const r = await c.query('UPDATE school_memberships SET branch_id = $2 WHERE user_id = $1 RETURNING id', [req.params.id, req.body.branchId]);
      if (!r.rowCount) throw E.notFound('User');
      await c.query("UPDATE sessions SET revoked_at = now(), revoked_reason = 'branch_changed' WHERE user_id = $1 AND school_id = $2 AND revoked_at IS NULL", [req.params.id, req.auth.schoolId]);
      await audit(c, req, 'users.branch_changed', { type: 'user', id: req.params.id, meta: { branchId: req.body.branchId } });
      return { ok: true };
    });
    invalidateUser(req.params.id);
    return out;
  });

  // ── roles & permissions ──
  app.get('/permissions', { onRequest: [A, app.perm('roles.view')] }, async () =>
    ({ items: Object.entries(PERMISSIONS).filter(([, v]) => v[2] !== 'platform').map(([key, [module, description]]) => ({ key, module, description })) }));

  app.get('/roles', { onRequest: [A, app.perm('roles.view', 'users.create')] }, async (req) => withTx(ctx(req), async (c) => ({
    items: (await c.query(`SELECT r.id, r.key, r.name, r.description, r.is_system, r.mfa_required, r.portal,
      COALESCE((SELECT array_agg(permission_key ORDER BY permission_key) FROM role_permissions rp WHERE rp.role_id = r.id), '{}') AS permissions,
      (SELECT count(*)::int FROM user_roles ur WHERE ur.role_id = r.id) AS users
      FROM roles r ORDER BY r.is_system DESC, r.name`)).rows,
  })));

  const roleBody = obj({ key: { type: 'string', pattern: '^[a-z][a-z0-9_]{1,40}$' }, name: str(80, 2), description: optStr(300), mfaRequired: { type: 'boolean' },
    portal: { enum: ['staff', 'student', 'parent'] }, permissions: { type: 'array', items: { type: 'string', maxLength: 60 }, maxItems: 100 } });
  const checkPerms = (req, list) => {
    for (const p of list) {
      if (!PERMISSIONS[p] || PERMISSIONS[p][2] === 'platform') throw E.bad(`Unknown permission ${p}.`);
      if (!SELF_SCOPED.has(p) && !req.auth.perms.has(p)) throw E.forbidden('You cannot grant permissions you do not have yourself.');
    }
  };
  app.post('/roles', { onRequest: [A, app.perm('roles.manage')], schema: { body: { ...roleBody, required: ['key', 'name', 'permissions'] } } }, async (req) => {
    checkPerms(req, req.body.permissions);
    return withTx(ctx(req), async (c) => {
      const r = (await c.query(`INSERT INTO roles (school_id, key, name, description, mfa_required, portal) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id, key, name`,
        [req.auth.schoolId, req.body.key, req.body.name, req.body.description || null, !!req.body.mfaRequired, req.body.portal || 'staff'])).rows[0];
      await c.query('INSERT INTO role_permissions (school_id, role_id, permission_key) SELECT $1, $2, unnest($3::text[])', [req.auth.schoolId, r.id, req.body.permissions]);
      await audit(c, req, 'roles.created', { type: 'role', id: r.id, meta: { key: r.key, permissions: req.body.permissions } });
      return r;
    });
  });
  app.patch('/roles/:id', { onRequest: [A, app.perm('roles.manage')], schema: { params: idParams, body: roleBody } }, async (req) => {
    const b = req.body;
    if (b.permissions) checkPerms(req, b.permissions);
    const out = await withTx(ctx(req), async (c) => {
      const role = (await c.query('SELECT * FROM roles WHERE id = $1 FOR UPDATE', [req.params.id])).rows[0];
      if (!role) throw E.notFound('Role');
      if (role.key === 'school_owner') throw E.forbidden('The School Owner role cannot be modified.');
      if (b.key && role.is_system && b.key !== role.key) throw E.bad('System role keys cannot change.');
      await c.query('UPDATE roles SET name = COALESCE($2, name), description = COALESCE($3, description), mfa_required = COALESCE($4, mfa_required) WHERE id = $1',
        [role.id, b.name || null, b.description || null, b.mfaRequired ?? null]);
      if (b.permissions) {
        const current = (await c.query('SELECT permission_key FROM role_permissions WHERE role_id = $1', [role.id])).rows.map((r) => r.permission_key);
        checkPerms(req, current.filter((p) => !b.permissions.includes(p)));   // can't strip permissions you don't hold
        await c.query('DELETE FROM role_permissions WHERE role_id = $1', [role.id]);
        await c.query('INSERT INTO role_permissions (school_id, role_id, permission_key) SELECT $1, $2, unnest($3::text[])', [req.auth.schoolId, role.id, b.permissions]);
      }
      await audit(c, req, 'roles.updated', { type: 'role', id: role.id, meta: { key: role.key, fields: Object.keys(b), permissions: b.permissions } });
      return { ok: true };
    });
    invalidateSchool(req.auth.schoolId);
    securityEvent({ schoolId: req.auth.schoolId, userId: req.auth.userId, kind: 'permission_change', severity: 'low', detail: { role: req.params.id }, ip: req.ip });
    return out;
  });
  app.delete('/roles/:id', { onRequest: [A, app.perm('roles.manage')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const role = (await c.query('SELECT * FROM roles WHERE id = $1', [req.params.id])).rows[0];
    if (!role) throw E.notFound('Role');
    if (role.is_system) throw E.bad('System roles cannot be deleted.');
    const n = (await c.query('SELECT count(*)::int AS n FROM user_roles WHERE role_id = $1', [role.id])).rows[0].n;
    if (n) throw E.conflict('Remove this role from all users first.');
    await c.query('DELETE FROM roles WHERE id = $1', [role.id]);
    await audit(c, req, 'roles.deleted', { type: 'role', id: role.id, meta: { key: role.key } });
    return { ok: true };
  }));
};
