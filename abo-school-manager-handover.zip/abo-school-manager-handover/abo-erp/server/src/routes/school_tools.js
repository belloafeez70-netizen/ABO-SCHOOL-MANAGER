'use strict';
// The last offline-edition tools, on the server (027):
//   • Devices — the school's fingerprint readers, card scanners, tablets… (a simple register; retire, never delete in use)
//   • Print Centre data — blank attendance register for a class, the cash ledger with a running balance, the stock sheet
//   • Score sheet layout ("Design Score Sheet") — which columns print on the class score sheet, its title and footer
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, str, uuid, idParams } = require('../lib/schema');
const { ctx } = require('../auth/plugin');
const { audit } = require('../audit/audit');

const KINDS = ['fingerprint', 'card', 'tablet', 'phone', 'computer', 'camera', 'other'];
const DAY = { type: 'string', format: 'date' };
const nul = (n) => ({ type: ['string', 'null'], maxLength: n });
const LAYOUT_DEFAULT = { showBreakdown: true, showPosition: true, showTotal: true, showAverage: true, showGrade: true, showStatus: true, title: '', footer: '' };

module.exports = async function schoolToolsRoutes(app) {
  const A = app.authenticate;

  // ── devices ──
  const devBody = { name: str(80, 2), kind: { enum: KINDS }, serial: nul(80), location: nul(120), status: { enum: ['active', 'repair', 'retired'] }, notes: nul(300) };
  app.get('/devices', { onRequest: [A, app.perm('devices.view', 'devices.manage')] }, async (req) => withTx(ctx(req), async (c) => {
    const items = (await c.query(`SELECT d.id, d.name, d.kind, d.serial, d.location, d.status, d.notes, d.created_at, d.updated_at, u.full_name AS added_by
      FROM school_devices d LEFT JOIN users u ON u.id = d.created_by ORDER BY d.status = 'retired', d.name`)).rows;
    return { items, counts: { total: items.length, active: items.filter((d) => d.status === 'active').length, repair: items.filter((d) => d.status === 'repair').length } };
  }));
  app.post('/devices', { onRequest: [A, app.perm('devices.manage')], schema: { body: obj(devBody, ['name', 'kind']) } }, async (req) => withTx(ctx(req), async (c) => {
    const b = req.body;
    try {
      const r = (await c.query(`INSERT INTO school_devices (school_id, name, kind, serial, location, status, notes, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
        [req.auth.schoolId, b.name.trim(), b.kind, (b.serial || '').trim() || null, (b.location || '').trim() || null, b.status || 'active', (b.notes || '').trim() || null, req.auth.userId])).rows[0];
      await audit(c, req, 'devices.added', { type: 'school_device', id: r.id, meta: { name: r.name, kind: r.kind } });
      return r;
    } catch (e) { if (e.code === '23505') throw E.conflict('A device with that serial number is already on the list.'); throw e; }
  }));
  app.patch('/devices/:id', { onRequest: [A, app.perm('devices.manage')], schema: { params: idParams, body: obj(devBody) } }, async (req) => withTx(ctx(req), async (c) => {
    const cur = (await c.query('SELECT * FROM school_devices WHERE id = $1', [req.params.id])).rows[0]; if (!cur) throw E.notFound('Device');
    const b = { ...cur, ...req.body };
    const t = (v) => (v === null || v === undefined ? null : String(v).trim() || null);
    try {
      const r = (await c.query('UPDATE school_devices SET name = $2, kind = $3, serial = $4, location = $5, status = $6, notes = $7 WHERE id = $1 RETURNING *',
        [cur.id, String(b.name).trim(), b.kind, t(b.serial), t(b.location), b.status, t(b.notes)])).rows[0];
      await audit(c, req, 'devices.updated', { type: 'school_device', id: r.id, meta: { fields: Object.keys(req.body), status: r.status } });
      return r;
    } catch (e) { if (e.code === '23505') throw E.conflict('A device with that serial number is already on the list.'); throw e; }
  }));
  app.delete('/devices/:id', { onRequest: [A, app.perm('devices.manage')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const cur = (await c.query('SELECT id, name FROM school_devices WHERE id = $1', [req.params.id])).rows[0]; if (!cur) throw E.notFound('Device');
    await c.query('DELETE FROM school_devices WHERE id = $1', [cur.id]);
    await audit(c, req, 'devices.removed', { type: 'school_device', id: cur.id, meta: { name: cur.name } });
    return { ok: true };
  }));

  // ── print centre ──
  app.get('/print/register', { onRequest: [A, app.perm('attendance.view', 'attendance.create', 'students.view')], schema: { querystring: obj({ classId: uuid }, ['classId']) } }, async (req) => withTx(ctx(req), async (c) => {
    const cls = (await c.query('SELECT id, display_name FROM classes WHERE id = $1', [req.query.classId])).rows[0]; if (!cls) throw E.notFound('Class');
    const items = (await c.query(`SELECT s.id, s.first_name, s.last_name, s.admission_no, s.gender FROM student_enrollments e
      JOIN academic_sessions se ON se.id = e.session_id AND se.is_current JOIN students s ON s.id = e.student_id AND s.deleted_at IS NULL
      WHERE e.class_id = $1 AND e.status = 'active' ORDER BY s.last_name, s.first_name`, [cls.id])).rows;
    const term = (await c.query('SELECT t.name, se.name AS session FROM terms t JOIN academic_sessions se ON se.id = t.session_id WHERE t.is_current LIMIT 1')).rows[0] || null;
    return { className: cls.display_name, term, items };
  }));
  app.get('/print/ledger', { onRequest: [A, app.perm('cashbook.view')], schema: { querystring: obj({ from: DAY, to: DAY }, ['from', 'to']) } }, async (req) => withTx(ctx(req), async (c) => {
    if (req.query.from > req.query.to) throw E.bad('"From" must be on or before "to".');
    const opening = Number((await c.query(`SELECT coalesce(sum(CASE WHEN kind = 'income' THEN amount_kobo ELSE -amount_kobo END), 0)::bigint AS b FROM cash_entries
      WHERE voided_at IS NULL AND method <> 'petty_cash' AND entry_date < $1`, [req.query.from])).rows[0].b);
    const rows = (await c.query(`SELECT e.entry_date::text AS date, e.kind, k.name AS category, e.description, e.party, e.reference, e.method, e.amount_kobo
      FROM cash_entries e JOIN cash_categories k ON k.id = e.category_id
      WHERE e.voided_at IS NULL AND e.entry_date BETWEEN $1 AND $2 ORDER BY e.entry_date, e.created_at LIMIT 5000`, [req.query.from, req.query.to])).rows;
    // running balance of the main cash (petty-cash box movements are shown but kept out of the main balance)
    let bal = opening;
    for (const r of rows) { if (r.method !== 'petty_cash') bal += (r.kind === 'income' ? 1 : -1) * Number(r.amount_kobo); r.balance_kobo = bal; }
    return { from: req.query.from, to: req.query.to, openingKobo: opening, closingKobo: bal, items: rows,
      note: 'School-fee payments and store sales are in Fees & Payments and the School Store. Petty-cash box movements are listed but not counted in the main balance.' };
  }));
  app.get('/print/stock', { onRequest: [A, app.perm('store.view', 'store.manage')] }, async (req) => withTx(ctx(req), async (c) => {
    const items = (await c.query(`SELECT name, category, sku, stock_qty, reorder_level, unit_price_kobo, ${req.can('store.manage') ? 'cost_price_kobo' : 'NULL::bigint AS cost_price_kobo'},
        (stock_qty * unit_price_kobo)::bigint AS value_kobo, (reorder_level > 0 AND stock_qty <= reorder_level) AS low
      FROM store_items WHERE active ORDER BY category NULLS LAST, name`)).rows;
    return { items, totalValueKobo: items.reduce((a, i) => a + Number(i.value_kobo), 0), low: items.filter((i) => i.low).length };
  }));

  // ── score sheet layout ──
  app.get('/broadsheet/layout', { onRequest: [A, app.perm('results.view', 'settings.view')] }, async (req) => withTx(ctx(req), async (c) => {
    const r = (await c.query('SELECT broadsheet_layout FROM school_settings LIMIT 1')).rows[0];
    return { layout: { ...LAYOUT_DEFAULT, ...((r && r.broadsheet_layout) || {}) } };
  }));
  app.put('/broadsheet/layout', { onRequest: [A, app.perm('settings.update')], schema: { body: obj({ showBreakdown: { type: 'boolean' }, showPosition: { type: 'boolean' }, showTotal: { type: 'boolean' },
    showAverage: { type: 'boolean' }, showGrade: { type: 'boolean' }, showStatus: { type: 'boolean' }, title: { type: 'string', maxLength: 120 }, footer: { type: 'string', maxLength: 300 } }) } },
  async (req) => withTx(ctx(req), async (c) => {
    const r = (await c.query('UPDATE school_settings SET broadsheet_layout = broadsheet_layout || $2::jsonb WHERE school_id = $1 RETURNING broadsheet_layout', [req.auth.schoolId, JSON.stringify(req.body)])).rows[0];
    await audit(c, req, 'broadsheet.layout_updated', { type: 'school_settings', id: req.auth.schoolId, meta: { fields: Object.keys(req.body) } });
    return { layout: { ...LAYOUT_DEFAULT, ...r.broadsheet_layout } };
  }));
};
