'use strict';
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, str, optStr, uuid, date, email, phone, idParams, listQuery } = require('../lib/schema');
const { page, paged, likeEscape, sortBy } = require('../lib/http');
const { ctx } = require('../auth/plugin');
const { audit } = require('../audit/audit');

const studentBody = obj({
  admissionNo: str(40, 1), firstName: str(80, 1), lastName: str(80, 1), otherNames: optStr(80), gender: { enum: ['Male', 'Female'] },
  dateOfBirth: date, address: optStr(300), medicalNotes: optStr(1000), classId: { type: ['string', 'null'], format: 'uuid' },
  admissionDate: date, phone, email,
});
const guardianBody = obj({ fullName: str(160, 2), relationship: str(40, 2), phone, whatsapp: phone, email, address: optStr(300), occupation: optStr(80) });
const staffBody = obj({ fullName: str(160, 2), employeeId: optStr(40), branchId: { type: ['string', 'null'], format: 'uuid' }, gender: { enum: ['Male', 'Female', null] }, phone, email, designation: optStr(80), isTeacher: { type: 'boolean' },
  employmentStatus: { enum: ['active', 'on_leave', 'exited'] }, dateJoined: date, dateOfBirth: date });

async function currentSession(c) {
  const s = (await c.query('SELECT id FROM academic_sessions WHERE is_current LIMIT 1')).rows[0];
  return s ? s.id : null;
}

module.exports = async function peopleRoutes(app) {
  const A = app.authenticate;

  // ───────── students ─────────
  app.get('/students', {
    onRequest: [A, app.perm('students.view')],
    schema: { querystring: listQuery({ classId: uuid, status: { enum: ['active', 'graduated', 'transferred', 'withdrawn'] } }) },
  }, async (req) => {
    const pg = page(req.query);
    const order = sortBy(req.query, { name: "s.last_name || ' ' || s.first_name", admissionNo: 's.admission_no', created: 's.created_at', className: 'c.display_name' }, 'name');
    return withTx(ctx(req), async (c) => {
      const p = []; const w = ['s.deleted_at IS NULL'];
      p.push(req.query.status || 'active'); w.push(`s.status = $${p.length}`);
      if (req.query.q) { p.push(`%${likeEscape(req.query.q.toLowerCase())}%`); w.push(`(lower(s.last_name || ' ' || s.first_name || ' ' || coalesce(s.other_names,'')) LIKE $${p.length} OR lower(s.admission_no) LIKE $${p.length})`); }
      if (req.query.classId) { p.push(req.query.classId); w.push(`e.class_id = $${p.length}`); }
      const joins = 'LEFT JOIN academic_sessions cs ON cs.is_current LEFT JOIN student_enrollments e ON e.student_id = s.id AND e.session_id = cs.id LEFT JOIN classes c ON c.id = e.class_id';
      const cols = `s.id, s.admission_no, s.first_name, s.last_name, s.other_names, s.gender, s.date_of_birth, s.status, s.passport_file_id,
        c.id AS class_id, c.display_name AS class_name, (s.user_id IS NOT NULL) AS has_account`;
      // Phase 7 (load test): when the list is neither filtered nor sorted by class, take the page of pupils FIRST
      // (index-ordered, see migration 023) and only then look up the classes of those 25 pupils.
      if (!req.query.classId && !order.startsWith('c.')) {
        const total = (await c.query(`SELECT count(*)::int AS n FROM students s WHERE ${w.join(' AND ')}`, p)).rows[0].n;
        const rows = (await c.query(`WITH pg AS (SELECT s.* FROM students s WHERE ${w.join(' AND ')} ORDER BY ${order} LIMIT ${pg.limit} OFFSET ${pg.offset})
          SELECT ${cols} FROM pg s ${joins} ORDER BY ${order}`, p)).rows;
        return paged(rows, total, pg);
      }
      const from = `FROM students s ${joins} WHERE ${w.join(' AND ')}`;
      const total = (await c.query(`SELECT count(*)::int AS n ${from}`, p)).rows[0].n;
      const rows = (await c.query(`SELECT ${cols} ${from} ORDER BY ${order} LIMIT ${pg.limit} OFFSET ${pg.offset}`, p)).rows;
      return paged(rows, total, pg);
    });
  });

  app.get('/students/:id', { onRequest: [A, app.perm('students.view', 'results.view_own', 'results.view_children')], schema: { params: idParams } }, async (req) => {
    const staff = req.can('students.view');
    if (!staff && req.params.id !== req.auth.studentId && !req.auth.children.includes(req.params.id)) throw E.notFound('Student');   // BOLA guard
    return withTx(ctx(req), async (c) => {
      const s = (await c.query(`SELECT s.*, c.display_name AS class_name, c.id AS class_id FROM students s
        LEFT JOIN academic_sessions cs ON cs.is_current LEFT JOIN student_enrollments e ON e.student_id = s.id AND e.session_id = cs.id LEFT JOIN classes c ON c.id = e.class_id
        WHERE s.id = $1 AND s.deleted_at IS NULL`, [req.params.id])).rows[0];
      if (!s) throw E.notFound('Student');
      if (!req.can('students.update')) { delete s.medical_notes; if (!staff) delete s.address; }   // least privilege on sensitive fields
      delete s.user_id;
      const guardians = staff || req.can('guardians.view') ? (await c.query(`SELECT g.id, g.full_name, g.relationship, g.phone, g.whatsapp, g.email, sg.is_primary FROM student_guardians sg
        JOIN guardians g ON g.id = sg.guardian_id WHERE sg.student_id = $1 ORDER BY sg.is_primary DESC`, [req.params.id])).rows : [];
      const history = (await c.query(`SELECT e.id, se.name AS session, c.display_name AS class_name, e.status FROM student_enrollments e JOIN academic_sessions se ON se.id = e.session_id
        JOIN classes c ON c.id = e.class_id WHERE e.student_id = $1 ORDER BY se.name DESC`, [req.params.id])).rows;
      return { student: s, guardians, history };
    });
  });

  app.post('/students', { onRequest: [A, app.perm('students.create')], schema: { body: { ...studentBody, required: ['admissionNo', 'firstName', 'lastName', 'gender'] } } }, async (req) =>
    withTx(ctx(req), async (c) => {
      const b = req.body;
      const lim = (await c.query(`SELECT s.max_students, (SELECT count(*)::int FROM students WHERE status = 'active' AND deleted_at IS NULL) AS n FROM schools s WHERE s.id = $1`, [req.auth.schoolId])).rows[0];
      if (lim.n >= lim.max_students) throw E.forbidden(`Your plan allows ${lim.max_students} active students. Contact support to upgrade.`);
      // branch: the class's branch, or the creator's branch when they are branch-restricted
      const branch = req.auth.branchId || (b.classId ? ((await c.query('SELECT branch_id FROM classes WHERE id = $1', [b.classId])).rows[0] || {}).branch_id : null) || null;
      const s = (await c.query(`INSERT INTO students (school_id, admission_no, first_name, last_name, other_names, gender, date_of_birth, address, medical_notes, branch_id, admission_date, phone, email)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,COALESCE($11::date, CURRENT_DATE),$12,$13) RETURNING id, admission_no, first_name, last_name`,
      [req.auth.schoolId, b.admissionNo.trim(), b.firstName.trim(), b.lastName.trim(), b.otherNames || null, b.gender, b.dateOfBirth || null, b.address || null, b.medicalNotes || null, branch, b.admissionDate || null, b.phone || null, b.email || null])).rows[0];
      if (b.classId) {
        const sess = await currentSession(c);
        if (!sess) throw E.bad('Set a current academic session before enrolling students.');
        await c.query('INSERT INTO student_enrollments (school_id, student_id, class_id, session_id) VALUES ($1,$2,$3,$4)', [req.auth.schoolId, s.id, b.classId, sess]);
      }
      await audit(c, req, 'students.created', { type: 'student', id: s.id, meta: { admissionNo: s.admission_no } });
      return s;
    }));

  app.patch('/students/:id', { onRequest: [A, app.perm('students.update')], schema: { params: idParams, body: studentBody } }, async (req) => withTx(ctx(req), async (c) => {
    const b = req.body;
    const map = { admissionNo: 'admission_no', firstName: 'first_name', lastName: 'last_name', otherNames: 'other_names', gender: 'gender', dateOfBirth: 'date_of_birth', address: 'address', medicalNotes: 'medical_notes', admissionDate: 'admission_date', phone: 'phone', email: 'email' };
    const sets = []; const p = [req.params.id];
    for (const [k, col] of Object.entries(map)) if (b[k] !== undefined) { p.push(b[k] === '' ? null : b[k]); sets.push(`${col} = $${p.length}`); }
    if (sets.length) {
      const r = await c.query(`UPDATE students SET ${sets.join(', ')} WHERE id = $1 AND deleted_at IS NULL RETURNING id`, p);
      if (!r.rowCount) throw E.notFound('Student');
    }
    if (b.classId !== undefined) {             // class transfer within the current session
      const sess = await currentSession(c);
      if (!sess) throw E.bad('No current academic session.');
      if (b.classId) await c.query(`INSERT INTO student_enrollments (school_id, student_id, class_id, session_id) VALUES ($1,$2,$3,$4)
        ON CONFLICT (student_id, session_id) DO UPDATE SET class_id = EXCLUDED.class_id, status = 'active'`, [req.auth.schoolId, req.params.id, b.classId, sess]);
    }
    await audit(c, req, 'students.updated', { type: 'student', id: req.params.id, meta: { fields: Object.keys(b) } });
    return { ok: true };
  }));

  app.post('/students/:id/status', { onRequest: [A, app.perm('students.update')], schema: { params: idParams, body: obj({ status: { enum: ['active', 'graduated', 'transferred', 'withdrawn'] }, reason: str(300, 3) }, ['status', 'reason']) } }, async (req) =>
    withTx(ctx(req), async (c) => {
      const r = await c.query('UPDATE students SET status = $2 WHERE id = $1 AND deleted_at IS NULL RETURNING id', [req.params.id, req.body.status]);
      if (!r.rowCount) throw E.notFound('Student');
      await audit(c, req, 'students.status_changed', { type: 'student', id: req.params.id, meta: req.body });
      return { ok: true };
    }));

  app.delete('/students/:id', { onRequest: [A, app.perm('students.delete')], schema: { params: idParams, body: obj({ reason: str(300, 3) }, ['reason']) } }, async (req) => withTx(ctx(req), async (c) => {
    // soft delete (records are retained for results/fees history and audit); account is disabled
    const r = await c.query("UPDATE students SET deleted_at = now(), status = 'withdrawn' WHERE id = $1 AND deleted_at IS NULL RETURNING user_id", [req.params.id]);
    if (!r.rowCount) throw E.notFound('Student');
    if (r.rows[0].user_id) {
      await c.query("UPDATE users SET status = 'disabled' WHERE id = $1", [r.rows[0].user_id]);
      await c.query("UPDATE sessions SET revoked_at = now(), revoked_reason = 'student_deleted' WHERE user_id = $1 AND revoked_at IS NULL", [r.rows[0].user_id]);
    }
    await audit(c, req, 'students.deleted', { type: 'student', id: req.params.id, meta: { reason: req.body.reason } });
    return { ok: true };
  }));

  // ───────── guardians / parents ─────────
  app.get('/guardians', { onRequest: [A, app.perm('guardians.view')], schema: { querystring: listQuery() } }, async (req) => {
    const pg = page(req.query);
    return withTx(ctx(req), async (c) => {
      const p = []; let w = '';
      if (req.query.q) { p.push(`%${likeEscape(req.query.q.toLowerCase())}%`); w = `WHERE lower(g.full_name) LIKE $1 OR g.phone LIKE $1`; }
      const total = (await c.query(`SELECT count(*)::int AS n FROM guardians g ${w}`, p)).rows[0].n;
      const rows = (await c.query(`SELECT g.id, g.full_name, g.relationship, g.phone, g.whatsapp, g.email, (g.user_id IS NOT NULL) AS has_account,
        COALESCE((SELECT json_agg(json_build_object('id', s.id, 'name', s.first_name || ' ' || s.last_name)) FROM student_guardians sg JOIN students s ON s.id = sg.student_id WHERE sg.guardian_id = g.id), '[]') AS children
        FROM guardians g ${w} ORDER BY g.full_name LIMIT ${pg.limit} OFFSET ${pg.offset}`, p)).rows;
      return paged(rows, total, pg);
    });
  });
  app.post('/guardians', { onRequest: [A, app.perm('guardians.manage')], schema: { body: { ...guardianBody, properties: { ...guardianBody.properties, studentIds: { type: 'array', items: uuid, maxItems: 20 } }, required: ['fullName', 'relationship'] } } }, async (req) =>
    withTx(ctx(req), async (c) => {
      const b = req.body;
      const g = (await c.query(`INSERT INTO guardians (school_id, full_name, relationship, phone, whatsapp, email, address, occupation) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id, full_name`,
        [req.auth.schoolId, b.fullName, b.relationship, b.phone || null, b.whatsapp || null, b.email || null, b.address || null, b.occupation || null])).rows[0];
      for (const sid of b.studentIds || []) await c.query('INSERT INTO student_guardians (school_id, student_id, guardian_id) VALUES ($1,$2,$3)', [req.auth.schoolId, sid, g.id]);
      await audit(c, req, 'guardians.created', { type: 'guardian', id: g.id, meta: { children: (b.studentIds || []).length } });
      return g;
    }));
  app.patch('/guardians/:id', { onRequest: [A, app.perm('guardians.manage')], schema: { params: idParams, body: guardianBody } }, async (req) => withTx(ctx(req), async (c) => {
    const b = req.body; const map = { fullName: 'full_name', relationship: 'relationship', phone: 'phone', whatsapp: 'whatsapp', email: 'email', address: 'address', occupation: 'occupation' };
    const sets = []; const p = [req.params.id];
    for (const [k, col] of Object.entries(map)) if (b[k] !== undefined) { p.push(b[k]); sets.push(`${col} = $${p.length}`); }
    if (!sets.length) throw E.bad('Nothing to update.');
    const r = await c.query(`UPDATE guardians SET ${sets.join(', ')} WHERE id = $1 RETURNING id`, p);
    if (!r.rowCount) throw E.notFound('Guardian');
    await audit(c, req, 'guardians.updated', { type: 'guardian', id: req.params.id, meta: { fields: Object.keys(b) } });
    return { ok: true };
  }));
  app.put('/guardians/:id/students', { onRequest: [A, app.perm('guardians.manage')], schema: { params: idParams, body: obj({ studentIds: { type: 'array', items: uuid, maxItems: 20 } }, ['studentIds']) } }, async (req) =>
    withTx(ctx(req), async (c) => {
      const g = await c.query('SELECT id FROM guardians WHERE id = $1', [req.params.id]);
      if (!g.rowCount) throw E.notFound('Guardian');
      await c.query('DELETE FROM student_guardians WHERE guardian_id = $1', [req.params.id]);
      for (const sid of req.body.studentIds) await c.query('INSERT INTO student_guardians (school_id, student_id, guardian_id) VALUES ($1,$2,$3)', [req.auth.schoolId, sid, req.params.id]);
      await audit(c, req, 'guardians.links_set', { type: 'guardian', id: req.params.id, meta: { children: req.body.studentIds.length } });
      return { ok: true };
    }));

  // ───────── staff / teachers ─────────
  app.get('/staff', { onRequest: [A, app.perm('staff.view', 'academic.manage')], schema: { querystring: listQuery({ teachersOnly: { type: 'boolean' } }) } }, async (req) => {
    const pg = page(req.query);
    return withTx(ctx(req), async (c) => {
      const p = []; const w = [];
      if (req.query.q) { p.push(`%${likeEscape(req.query.q.toLowerCase())}%`); w.push(`lower(s.full_name) LIKE $${p.length}`); }
      if (req.query.teachersOnly) w.push('s.is_teacher');
      const where = w.length ? 'WHERE ' + w.join(' AND ') : '';
      const total = (await c.query(`SELECT count(*)::int AS n FROM staff s ${where}`, p)).rows[0].n;
      const rows = (await c.query(`SELECT s.id, s.employee_id, s.full_name, s.gender, s.phone, s.email, s.designation, s.is_teacher, s.employment_status, s.date_joined, s.date_of_birth, (s.user_id IS NOT NULL) AS has_account, s.user_id, u.last_login_at,
        (SELECT string_agg(DISTINCT c.display_name, ', ') FROM class_subjects cs JOIN classes c ON c.id = cs.class_id WHERE cs.teacher_id = s.id) AS teaches
        FROM staff s LEFT JOIN users u ON u.id = s.user_id ${where} ORDER BY s.full_name LIMIT ${pg.limit} OFFSET ${pg.offset}`, p)).rows;
      return paged(rows, total, pg);
    });
  });
  app.post('/staff', { onRequest: [A, app.perm('staff.create')], schema: { body: { ...staffBody, required: ['fullName'] } } }, async (req) => withTx(ctx(req), async (c) => {
    const b = req.body;
    const s = (await c.query(`INSERT INTO staff (school_id, full_name, employee_id, gender, phone, email, designation, is_teacher, employment_status, date_joined, branch_id, date_of_birth)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING id, full_name`, [req.auth.schoolId, b.fullName, b.employeeId || null, b.gender || null, b.phone || null, b.email || null,
      b.designation || null, b.isTeacher !== false, b.employmentStatus || 'active', b.dateJoined || null, req.auth.branchId || b.branchId || null, b.dateOfBirth || null])).rows[0];
    await audit(c, req, 'staff.created', { type: 'staff', id: s.id });
    return s;
  }));
  app.patch('/staff/:id', { onRequest: [A, app.perm('staff.update')], schema: { params: idParams, body: staffBody } }, async (req) => withTx(ctx(req), async (c) => {
    const b = req.body; const map = { fullName: 'full_name', employeeId: 'employee_id', gender: 'gender', phone: 'phone', email: 'email', designation: 'designation', isTeacher: 'is_teacher', employmentStatus: 'employment_status', dateJoined: 'date_joined', dateOfBirth: 'date_of_birth' };
    const sets = []; const p = [req.params.id];
    for (const [k, col] of Object.entries(map)) if (b[k] !== undefined) { p.push(b[k]); sets.push(`${col} = $${p.length}`); }
    if (!sets.length) throw E.bad('Nothing to update.');
    const r = await c.query(`UPDATE staff SET ${sets.join(', ')} WHERE id = $1 RETURNING id`, p);
    if (!r.rowCount) throw E.notFound('Staff member');
    await audit(c, req, 'staff.updated', { type: 'staff', id: req.params.id, meta: { fields: Object.keys(b) } });
    return { ok: true };
  }));
  app.delete('/staff/:id', { onRequest: [A, app.perm('staff.delete')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    // staff are marked exited (history retained); linked account disabled
    const r = await c.query("UPDATE staff SET employment_status = 'exited' WHERE id = $1 RETURNING user_id", [req.params.id]);
    if (!r.rowCount) throw E.notFound('Staff member');
    if (r.rows[0].user_id) {
      await c.query("UPDATE users SET status = 'disabled' WHERE id = $1", [r.rows[0].user_id]);
      await c.query("UPDATE sessions SET revoked_at = now(), revoked_reason = 'staff_exited' WHERE user_id = $1 AND revoked_at IS NULL", [r.rows[0].user_id]);
    }
    await c.query('UPDATE class_subjects SET teacher_id = NULL WHERE teacher_id = $1', [req.params.id]);
    await audit(c, req, 'staff.exited', { type: 'staff', id: req.params.id });
    return { ok: true };
  }));

  // ───────── teachers (teaching profile) & teacher assignments ─────────
  app.get('/teachers', { onRequest: [A, app.perm('teachers.view', 'staff.view')], schema: { querystring: listQuery() } }, async (req) => {
    const pg = page(req.query);
    return withTx(ctx(req), async (c) => {
      const p = []; let w = "WHERE t.status = 'active'";
      if (req.query.q) { p.push(`%${likeEscape(req.query.q.toLowerCase())}%`); w += ` AND lower(s.full_name) LIKE $${p.length}`; }
      const total = (await c.query(`SELECT count(*)::int AS n FROM teachers t JOIN staff s ON s.id = t.staff_id ${w}`, p)).rows[0].n;
      const rows = (await c.query(`SELECT t.id, t.staff_id, s.full_name, s.employee_id, s.email, s.phone, t.trcn_number, t.qualification, t.specialization, t.status,
          COALESCE((SELECT json_agg(json_build_object('classId', a.class_id, 'className', cl.display_name, 'subjectId', a.subject_id, 'subject', sb.name, 'role', a.role))
            FROM teacher_class_access a JOIN classes cl ON cl.id = a.class_id LEFT JOIN subjects sb ON sb.id = a.subject_id WHERE a.staff_id = t.staff_id), '[]') AS assignments
        FROM teachers t JOIN staff s ON s.id = t.staff_id ${w} ORDER BY s.full_name LIMIT ${pg.limit} OFFSET ${pg.offset}`, p)).rows;
      return paged(rows, total, pg);
    });
  });
  app.patch('/teachers/:id', { onRequest: [A, app.perm('teachers.update')], schema: { params: idParams, body: obj({ trcnNumber: optStr(40), qualification: optStr(120), specialization: optStr(120), status: { enum: ['active', 'inactive'] } }) } }, async (req) =>
    withTx(ctx(req), async (c) => {
      const b = req.body; const map = { trcnNumber: 'trcn_number', qualification: 'qualification', specialization: 'specialization', status: 'status' };
      const sets = []; const p = [req.params.id];
      for (const [k, col] of Object.entries(map)) if (b[k] !== undefined) { p.push(b[k]); sets.push(`${col} = $${p.length}`); }
      if (!sets.length) throw E.bad('Nothing to update.');
      const r = await c.query(`UPDATE teachers SET ${sets.join(', ')} WHERE id = $1 RETURNING id`, p);
      if (!r.rowCount) throw E.notFound('Teacher');
      await audit(c, req, 'teachers.updated', { type: 'teacher', id: req.params.id, meta: { fields: Object.keys(b) } });
      return { ok: true };
    }));
  app.post('/teachers/:id/assignments', {
    onRequest: [A, app.perm('teachers.update')],
    schema: { params: idParams, body: obj({ classId: uuid, subjectId: { type: ['string', 'null'], format: 'uuid' }, sessionId: { type: ['string', 'null'], format: 'uuid' }, role: { enum: ['subject_teacher', 'form_teacher', 'assistant'] } }, ['classId', 'role']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const t = (await c.query("SELECT staff_id FROM teachers WHERE id = $1 AND status = 'active'", [req.params.id])).rows[0];
    if (!t) throw E.notFound('Teacher');
    if (req.body.role === 'subject_teacher' && !req.body.subjectId) throw E.bad('Choose the subject for a subject-teacher assignment.');
    if (req.body.subjectId && !(await c.query('SELECT 1 FROM class_subjects WHERE class_id = $1 AND subject_id = $2', [req.body.classId, req.body.subjectId])).rowCount) throw E.bad('That subject is not offered in this class.');
    const r = (await c.query(`INSERT INTO teacher_assignments (school_id, staff_id, class_id, subject_id, session_id, role, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
      [req.auth.schoolId, t.staff_id, req.body.classId, req.body.subjectId || null, req.body.sessionId || null, req.body.role, req.auth.userId])).rows[0];
    await audit(c, req, 'teachers.assigned', { type: 'teacher_assignment', id: r.id, meta: req.body });
    return { id: r.id };
  }));
  app.delete('/teachers/assignments/:id', { onRequest: [A, app.perm('teachers.update', 'teachers.delete')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const r = await c.query('DELETE FROM teacher_assignments WHERE id = $1 RETURNING staff_id, class_id', [req.params.id]);
    if (!r.rowCount) throw E.notFound('Assignment');
    await audit(c, req, 'teachers.unassigned', { type: 'teacher_assignment', id: req.params.id, meta: r.rows[0] });
    return { ok: true };
  }));
};
