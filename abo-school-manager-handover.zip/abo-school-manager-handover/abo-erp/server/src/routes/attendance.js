'use strict';
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, uuid, str, idParams } = require('../lib/schema');
const { ctx } = require('../auth/plugin');
const { audit } = require('../audit/audit');
const { notify } = require('../services/notify');

// Ownership rule: attendance.update → any class; attendance.mark → only classes where you are form teacher.
async function assertClassScope(c, req, classId, anyPerm) {
  if (!(await c.query('SELECT 1 FROM classes WHERE id = $1', [classId])).rowCount) throw E.notFound('Class');
  if (req.can(anyPerm)) return;
  const r = await c.query("SELECT 1 FROM teacher_class_access WHERE class_id = $1 AND staff_id = $2 AND role IN ('form_teacher','assistant')", [classId, req.auth.staffId]);
  if (!r.rowCount) throw E.forbidden('You can only take registers for classes assigned to you.');
}
const today = () => new Date().toISOString().slice(0, 10);

module.exports = async function attendanceRoutes(app) {
  const A = app.authenticate;

  app.get('/attendance/class/:id', {
    onRequest: [A, app.perm('attendance.view', 'attendance.create', 'attendance.update')],
    schema: { params: idParams, querystring: obj({ date: { type: 'string', format: 'date' } }) },
  }, async (req) => withTx(ctx(req), async (c) => {
    await assertClassScope(c, req, req.params.id, req.can('attendance.view') ? 'attendance.view' : 'attendance.update');
    const d = req.query.date || today();
    const rows = (await c.query(`SELECT s.id AS student_id, s.first_name, s.last_name, s.admission_no, a.status, a.note
      FROM student_enrollments e JOIN academic_sessions cs ON cs.id = e.session_id AND cs.is_current JOIN students s ON s.id = e.student_id
      LEFT JOIN attendance_records a ON a.student_id = s.id AND a.date = $2
      WHERE e.class_id = $1 AND e.status = 'active' AND s.deleted_at IS NULL ORDER BY s.last_name, s.first_name`, [req.params.id, d])).rows;
    const session = (await c.query('SELECT a.id, a.remarks, a.updated_at, u.full_name AS taken_by FROM attendance_sessions a LEFT JOIN users u ON u.id = a.taken_by WHERE a.class_id = $1 AND a.date = $2', [req.params.id, d])).rows[0] || null;
    return { date: d, session, items: rows };
  }));

  app.put('/attendance/class/:id', {
    onRequest: [A, app.perm('attendance.create', 'attendance.update')],
    schema: { params: idParams, body: obj({ date: { type: 'string', format: 'date' }, notifyParents: { type: 'boolean', default: true }, remarks: { type: ['string', 'null'], maxLength: 500 },
      entries: { type: 'array', minItems: 1, maxItems: 500, items: obj({ studentId: uuid, status: { enum: ['present', 'absent', 'late', 'excused'] }, note: { type: ['string', 'null'], maxLength: 200 } }, ['studentId', 'status']) } }, ['date', 'entries']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const { date, entries } = req.body;
    if (date > today()) throw E.bad('Attendance cannot be marked for a future date.');
    await assertClassScope(c, req, req.params.id, 'attendance.update');
    const enrolled = new Set((await c.query(`SELECT e.student_id FROM student_enrollments e JOIN academic_sessions cs ON cs.id = e.session_id AND cs.is_current
      WHERE e.class_id = $1 AND e.status = 'active'`, [req.params.id])).rows.map((r) => r.student_id));
    const bad = entries.filter((e) => !enrolled.has(e.studentId));
    if (bad.length) throw E.bad(`${bad.length} student(s) are not enrolled in this class.`);
    const term = (await c.query('SELECT id FROM terms WHERE is_current LIMIT 1')).rows[0];
    // one register (attendance session) per class per day; records reference it
    const sess = (await c.query(`INSERT INTO attendance_sessions (school_id, class_id, term_id, date, taken_by, remarks) VALUES ($1,$2,$3,$4,$5,$6)
      ON CONFLICT (class_id, date) DO UPDATE SET taken_by = EXCLUDED.taken_by, remarks = COALESCE(EXCLUDED.remarks, attendance_sessions.remarks) RETURNING id, (xmax = 0) AS created`,
    [req.auth.schoolId, req.params.id, term ? term.id : null, date, req.auth.userId, req.body.remarks ?? null])).rows[0];
    await c.query(`INSERT INTO attendance_records (school_id, student_id, class_id, term_id, date, status, note, marked_by, session_id)
      SELECT $1, x.student_id, $2, $3, $4, x.status, x.note, $5, $7 FROM json_to_recordset($6::json) AS x(student_id uuid, status text, note text)
      ON CONFLICT (student_id, date) DO UPDATE SET status = EXCLUDED.status, note = EXCLUDED.note, class_id = EXCLUDED.class_id, marked_by = EXCLUDED.marked_by, marked_at = now(), session_id = EXCLUDED.session_id`,
    [req.auth.schoolId, req.params.id, term ? term.id : null, date, req.auth.userId, JSON.stringify(entries.map((e) => ({ student_id: e.studentId, status: e.status, note: e.note || null }))), sess.id]);
    const absent = entries.filter((e) => e.status === 'absent').map((e) => e.studentId);
    if (req.body.notifyParents && absent.length && date === today()) {
      const parents = (await c.query(`SELECT g.user_id, s.first_name FROM student_guardians sg JOIN guardians g ON g.id = sg.guardian_id JOIN students s ON s.id = sg.student_id
        WHERE sg.student_id = ANY($1::uuid[]) AND g.user_id IS NOT NULL`, [absent])).rows;
      for (const p of parents) await notify(c, req.auth.schoolId, [p.user_id], { kind: 'attendance', title: `${p.first_name} was marked absent today`, body: 'Please contact the school if this is unexpected.', link: '#/child' });
    }
    const counts = entries.reduce((m, e) => ({ ...m, [e.status]: (m[e.status] || 0) + 1 }), {});
    await audit(c, req, sess.created ? 'attendance.created' : 'attendance.updated', { type: 'attendance_session', id: sess.id, meta: { classId: req.params.id, date, ...counts } });
    return { ok: true, saved: entries.length, counts, sessionId: sess.id };
  }));

  app.get('/attendance/summary', {
    onRequest: [A, app.perm('attendance.view', 'attendance.create', 'attendance.update')],
    schema: { querystring: obj({ classId: uuid, termId: uuid }, ['classId']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    if (!req.can('attendance.view')) await assertClassScope(c, req, req.query.classId, 'attendance.update');
    const term = req.query.termId || ((await c.query('SELECT id FROM terms WHERE is_current LIMIT 1')).rows[0] || {}).id;
    const rows = (await c.query(`SELECT s.id AS student_id, s.first_name, s.last_name, s.admission_no,
        count(a.*) FILTER (WHERE a.status IN ('present','late'))::int AS present, count(a.*) FILTER (WHERE a.status = 'absent')::int AS absent,
        count(a.*) FILTER (WHERE a.status = 'late')::int AS late, count(a.*) FILTER (WHERE a.status = 'excused')::int AS excused
      FROM student_enrollments e JOIN academic_sessions cs ON cs.id = e.session_id AND cs.is_current JOIN students s ON s.id = e.student_id
      LEFT JOIN attendance_records a ON a.student_id = s.id AND a.term_id = $2
      WHERE e.class_id = $1 AND e.status = 'active' GROUP BY s.id ORDER BY s.last_name, s.first_name`, [req.query.classId, term || null])).rows;
    return { termId: term || null, items: rows };
  }));

  app.get('/attendance/student/:id', { onRequest: [A, app.perm('attendance.view', 'results.view_own', 'results.view_children')], schema: { params: idParams } }, async (req) => {
    if (!req.can('attendance.view') && req.params.id !== req.auth.studentId && !req.auth.children.includes(req.params.id)) throw E.notFound('Student');
    return withTx(ctx(req), async (c) => ({
      items: (await (async () => { if (!(await c.query('SELECT 1 FROM students WHERE id = $1', [req.params.id])).rowCount) throw E.notFound('Student'); })(), await c.query(`SELECT date, status, note FROM attendance_records WHERE student_id = $1 ORDER BY date DESC LIMIT 120`, [req.params.id])).rows,
    }));
  });
};
