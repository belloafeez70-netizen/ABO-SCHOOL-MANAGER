'use strict';
// Lesson Notes: teachers write weekly notes for the class/subjects assigned to them → submit → a head (lesson_notes.review)
// approves or returns with a comment. Approved notes marked "share with class" become readable by the students of that
// class (and their parents) — never drafts, never returned notes. Every rule below is enforced server-side; RLS keeps
// each school's notes isolated.
const { withTx } = require('../db/pool');
const { E, AppError } = require('../lib/errors');
const { obj, str, uuid, idParams, listQuery } = require('../lib/schema');
const { page, paged, likeEscape } = require('../lib/http');
const { ctx } = require('../auth/plugin');
const { audit } = require('../audit/audit');
const { notify } = require('../services/notify');
const { saveUpload } = require('../storage');

const txt = (max) => ({ type: ['string', 'null'], maxLength: max });
const BODY = {
  termId: uuid, classId: uuid, subjectId: uuid,
  week: { type: 'integer', minimum: 1, maximum: 16 },
  lessonDate: { type: ['string', 'null'], format: 'date' },
  duration: txt(40), topic: str(200, 2), subtopic: txt(200), objectives: txt(4000), materials: txt(2000),
  priorKnowledge: txt(2000), content: str(60000, 1), evaluation: txt(4000), assignment: txt(4000),
  shareWithClass: { type: 'boolean' },
};
const COLS = { week: 'week', lessonDate: 'lesson_date', duration: 'duration', topic: 'topic', subtopic: 'subtopic', objectives: 'objectives',
  materials: 'materials', priorKnowledge: 'prior_knowledge', content: 'content', evaluation: 'evaluation', assignment: 'assignment', shareWithClass: 'share_with_class' };
const EDITABLE = ['draft', 'returned'];

const SELECT = `SELECT n.id, n.term_id, n.class_id, n.subject_id, n.week, n.lesson_date, n.duration, n.topic, n.subtopic, n.objectives, n.materials,
    n.prior_knowledge, n.content, n.evaluation, n.assignment, n.file_id, n.share_with_class, n.status, n.version, n.submitted_at, n.reviewed_at,
    n.review_note, n.created_at, n.updated_at, n.author_id, au.full_name AS author, rv.full_name AS reviewer,
    cl.display_name AS class_name, sb.name AS subject, t.name AS term_name, ss.name AS session_name,
    up.original_name AS file_name, up.mime AS file_mime, up.size_bytes AS file_size
  FROM lesson_notes n JOIN classes cl ON cl.id = n.class_id JOIN subjects sb ON sb.id = n.subject_id
  JOIN terms t ON t.id = n.term_id JOIN academic_sessions ss ON ss.id = t.session_id
  LEFT JOIN users au ON au.id = n.author_id LEFT JOIN users rv ON rv.id = n.reviewed_by
  LEFT JOIN uploads up ON up.id = n.file_id AND up.deleted_at IS NULL`;

const isLearner = (req) => req.auth.portal === 'student' || req.auth.portal === 'parent';
const isStaffReader = (req) => req.can('lesson_notes.view') || req.can('lesson_notes.review');
const learnerIds = (req) => [req.auth.studentId, ...(req.auth.children || [])].filter(Boolean);

// classes the learner (or the parent's children) are enrolled in for the CURRENT session
async function learnerClasses(c, studentIds) {
  if (!studentIds.length) return [];
  return (await c.query(`SELECT DISTINCT e.class_id FROM student_enrollments e JOIN academic_sessions s ON s.id = e.session_id AND s.is_current
    WHERE e.student_id = ANY($1::uuid[])`, [studentIds])).rows.map((r) => r.class_id);
}
async function mayWriteFor(c, req, classId, subjectId) {
  if (req.can('lesson_notes.review')) return true;                         // heads may write for any class
  if (!req.can('lesson_notes.create') || !req.auth.staffId) return false;
  return (await c.query(`SELECT 1 FROM teacher_class_access WHERE staff_id = $1 AND class_id = $2 AND subject_id = $3
    AND role IN ('subject_teacher','assistant')`, [req.auth.staffId, classId, subjectId])).rowCount > 0;
}
async function load(c, id) {
  const n = (await c.query(`${SELECT} WHERE n.id = $1 AND n.deleted_at IS NULL`, [id])).rows[0];
  if (!n) throw E.notFound('Lesson note');
  return n;
}
// read access to ONE note (staff: own or viewer; learner: approved + shared + own class)
async function canRead(c, req, n) {
  if (!isLearner(req)) return n.author_id === req.auth.userId || isStaffReader(req);
  if (!(req.can('lesson_notes.view_own') || req.can('lesson_notes.view_children'))) return false;
  if (n.status !== 'approved' || !n.share_with_class) return false;
  return (await learnerClasses(c, learnerIds(req))).includes(n.class_id);
}
const learnerView = (n) => {             // learners never see workflow/reviewer fields
  const { review_note: _r, reviewer: _v, version: _x, submitted_at: _s, author_id: _a, ...rest } = n;
  return rest;
};
async function reviewers(c, excludeUserId) {
  return (await c.query(`SELECT DISTINCT u.id FROM active_members u JOIN user_roles ur ON ur.user_id = u.id
    JOIN role_permissions rp ON rp.role_id = ur.role_id AND rp.permission_key = 'lesson_notes.review' WHERE u.id <> $1 LIMIT 200`, [excludeUserId])).rows.map((r) => r.id);
}

module.exports = async function lessonNoteRoutes(app) {
  const A = app.authenticate;
  const STAFF = app.perm('lesson_notes.create', 'lesson_notes.view', 'lesson_notes.review');

  // what the caller may write for: their assigned class/subject pairs (heads: every class/subject offered)
  app.get('/lesson-notes/options', { onRequest: [A, app.perm('lesson_notes.create', 'lesson_notes.review')] }, async (req) => withTx(ctx(req), async (c) => {
    const all = req.can('lesson_notes.review');
    const rows = all
      ? (await c.query(`SELECT cs.class_id, cl.display_name AS class_name, cs.subject_id, s.name AS subject FROM class_subjects cs
          JOIN classes cl ON cl.id = cs.class_id JOIN subjects s ON s.id = cs.subject_id ORDER BY cl.sort_order, cl.display_name, s.name`)).rows
      : req.auth.staffId ? (await c.query(`SELECT DISTINCT a.class_id, cl.display_name AS class_name, a.subject_id, s.name AS subject, cl.sort_order
          FROM teacher_class_access a JOIN classes cl ON cl.id = a.class_id JOIN subjects s ON s.id = a.subject_id
          WHERE a.staff_id = $1 AND a.subject_id IS NOT NULL AND a.role IN ('subject_teacher','assistant') ORDER BY cl.sort_order, cl.display_name, s.name`, [req.auth.staffId])).rows : [];
    const terms = (await c.query(`SELECT t.id, t.name, s.name AS session_name, t.is_current FROM terms t JOIN academic_sessions s ON s.id = t.session_id
      ORDER BY s.starts_on DESC NULLS LAST, t.starts_on NULLS LAST, t.name`)).rows;
    return { pairs: rows.map(({ sort_order: _s, ...r }) => r), terms, allClasses: all };
  }));

  // staff list (teachers: own notes; viewers/reviewers: every note)
  app.get('/lesson-notes', {
    onRequest: [A, STAFF],
    schema: { querystring: listQuery({ termId: uuid, classId: uuid, subjectId: uuid, status: { enum: ['draft', 'submitted', 'approved', 'returned'] },
      scope: { enum: ['mine', 'all', 'review'] }, week: { type: 'integer', minimum: 1, maximum: 16 } }) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const q = req.query; const pg = page(q); const p = []; const w = ['n.deleted_at IS NULL'];
    const scope = !isStaffReader(req) ? 'mine' : (q.scope || 'all');
    if (scope === 'mine') { p.push(req.auth.userId); w.push(`n.author_id = $${p.length}`); }
    if (scope === 'review') w.push("n.status = 'submitted'");
    for (const [k, col] of [['termId', 'n.term_id'], ['classId', 'n.class_id'], ['subjectId', 'n.subject_id'], ['status', 'n.status'], ['week', 'n.week']]) {
      if (q[k] !== undefined && q[k] !== '') { p.push(q[k]); w.push(`${col} = $${p.length}`); }
    }
    if (q.q) { p.push(`%${likeEscape(q.q)}%`); w.push(`(n.topic ILIKE $${p.length} OR n.subtopic ILIKE $${p.length} OR au.full_name ILIKE $${p.length})`); }
    const where = w.join(' AND ');
    const total = (await c.query(`SELECT count(*)::int AS n FROM lesson_notes n LEFT JOIN users au ON au.id = n.author_id WHERE ${where}`, p)).rows[0].n;
    const rows = (await c.query(`SELECT n.id, n.week, n.lesson_date, n.topic, n.subtopic, n.status, n.share_with_class, n.submitted_at, n.reviewed_at, n.updated_at,
        n.author_id, au.full_name AS author, cl.display_name AS class_name, sb.name AS subject, t.name AS term_name, (n.file_id IS NOT NULL) AS has_file
      FROM lesson_notes n JOIN classes cl ON cl.id = n.class_id JOIN subjects sb ON sb.id = n.subject_id JOIN terms t ON t.id = n.term_id
      LEFT JOIN users au ON au.id = n.author_id WHERE ${where}
      ORDER BY ${scope === 'review' ? 'n.submitted_at ASC' : 'n.updated_at DESC'} LIMIT ${pg.limit} OFFSET ${pg.offset}`, p)).rows;
    return paged(rows, total, pg);
  }));

  // compliance summary for heads: per teacher/subject/class — notes written, submitted, approved, returned, last week covered
  app.get('/lesson-notes/summary', { onRequest: [A, app.perm('lesson_notes.view', 'lesson_notes.review')], schema: { querystring: obj({ termId: uuid }, ['termId']) } }, async (req) =>
    withTx(ctx(req), async (c) => {
      const rows = (await c.query(`SELECT au.full_name AS teacher, cl.display_name AS class_name, sb.name AS subject,
          count(*)::int AS total, count(*) FILTER (WHERE n.status = 'draft')::int AS draft, count(*) FILTER (WHERE n.status = 'submitted')::int AS submitted,
          count(*) FILTER (WHERE n.status = 'approved')::int AS approved, count(*) FILTER (WHERE n.status = 'returned')::int AS returned,
          max(n.week) FILTER (WHERE n.status = 'approved')::int AS last_approved_week, max(n.updated_at) AS last_activity
        FROM lesson_notes n JOIN classes cl ON cl.id = n.class_id JOIN subjects sb ON sb.id = n.subject_id LEFT JOIN users au ON au.id = n.author_id
        WHERE n.deleted_at IS NULL AND n.term_id = $1 GROUP BY au.full_name, cl.display_name, cl.sort_order, sb.name
        ORDER BY au.full_name, cl.sort_order, sb.name LIMIT 1000`, [req.query.termId])).rows;
      const totals = rows.reduce((t, r) => { for (const k of ['total', 'draft', 'submitted', 'approved', 'returned']) t[k] += r[k]; return t; }, { total: 0, draft: 0, submitted: 0, approved: 0, returned: 0 });
      // assigned class/subject pairs with NO note this term (the gaps heads chase)
      const missing = (await c.query(`SELECT st.full_name AS teacher, cl.display_name AS class_name, sb.name AS subject
        FROM class_subjects cs JOIN classes cl ON cl.id = cs.class_id JOIN subjects sb ON sb.id = cs.subject_id LEFT JOIN staff st ON st.id = cs.teacher_id
        WHERE cs.teacher_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM lesson_notes n WHERE n.deleted_at IS NULL AND n.term_id = $1 AND n.class_id = cs.class_id AND n.subject_id = cs.subject_id)
        ORDER BY st.full_name, cl.sort_order, sb.name LIMIT 500`, [req.query.termId])).rows;
      return { items: rows, totals, missing };
    }));

  // learner list: approved + shared notes for the student's (or children's) current classes
  app.get('/my/lesson-notes', {
    onRequest: [A, app.perm('lesson_notes.view_own', 'lesson_notes.view_children')],
    schema: { querystring: obj({ studentId: uuid, subjectId: uuid, termId: uuid }) },
  }, async (req) => withTx(ctx(req), async (c) => {
    let ids = learnerIds(req);
    if (req.query.studentId) { if (!ids.includes(req.query.studentId)) throw E.notFound('Student'); ids = [req.query.studentId]; }
    const classes = await learnerClasses(c, ids);
    if (!classes.length) return { items: [], subjects: [] };
    const p = [classes]; const w = ["n.deleted_at IS NULL", "n.status = 'approved'", 'n.share_with_class', 'n.class_id = ANY($1::uuid[])'];
    if (req.query.subjectId) { p.push(req.query.subjectId); w.push(`n.subject_id = $${p.length}`); }
    if (req.query.termId) { p.push(req.query.termId); w.push(`n.term_id = $${p.length}`); }
    const rows = (await c.query(`SELECT n.id, n.week, n.lesson_date, n.topic, n.subtopic, n.subject_id, sb.name AS subject, cl.display_name AS class_name,
        t.name AS term_name, au.full_name AS author, (n.file_id IS NOT NULL) AS has_file, n.reviewed_at
      FROM lesson_notes n JOIN subjects sb ON sb.id = n.subject_id JOIN classes cl ON cl.id = n.class_id JOIN terms t ON t.id = n.term_id
      LEFT JOIN users au ON au.id = n.author_id WHERE ${w.join(' AND ')} ORDER BY t.starts_on DESC NULLS LAST, sb.name, n.week DESC LIMIT 300`, p)).rows;
    const subjects = (await c.query(`SELECT DISTINCT sb.id, sb.name FROM lesson_notes n JOIN subjects sb ON sb.id = n.subject_id
      WHERE n.deleted_at IS NULL AND n.status = 'approved' AND n.share_with_class AND n.class_id = ANY($1::uuid[]) ORDER BY sb.name`, [classes])).rows;
    return { items: rows, subjects };
  }));

  app.get('/lesson-notes/:id', { onRequest: [A, app.perm('lesson_notes.create', 'lesson_notes.view', 'lesson_notes.review', 'lesson_notes.view_own', 'lesson_notes.view_children')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const n = await load(c, req.params.id);
    if (!(await canRead(c, req, n))) throw E.notFound('Lesson note');
    if (isLearner(req)) return learnerView(n);
    const mine = n.author_id === req.auth.userId;
    return { ...n, can: { edit: mine && EDITABLE.includes(n.status), submit: mine && EDITABLE.includes(n.status), delete: mine && EDITABLE.includes(n.status),
      review: req.can('lesson_notes.review') && n.status === 'submitted' && !mine, reopen: req.can('lesson_notes.review') && n.status === 'approved' } };
  }));

  app.post('/lesson-notes', {
    onRequest: [A, app.perm('lesson_notes.create', 'lesson_notes.review')], config: { rateLimit: { max: 60, timeWindow: '1 minute' } },
    schema: { body: obj(BODY, ['termId', 'classId', 'subjectId', 'week', 'topic', 'content']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const b = req.body;
    for (const [t, id, label] of [['terms', b.termId, 'Term'], ['classes', b.classId, 'Class'], ['subjects', b.subjectId, 'Subject']]) {
      if (!(await c.query(`SELECT 1 FROM ${t} WHERE id = $1`, [id])).rowCount) throw E.notFound(label);
    }
    if (!(await mayWriteFor(c, req, b.classId, b.subjectId))) throw E.forbidden('This subject is not assigned to you for this class.');
    const r = (await c.query(`INSERT INTO lesson_notes (school_id, term_id, class_id, subject_id, staff_id, author_id, week, lesson_date, duration, topic, subtopic,
        objectives, materials, prior_knowledge, content, evaluation, assignment, share_with_class)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,COALESCE($18,true)) RETURNING id, status, version`,
    [req.auth.schoolId, b.termId, b.classId, b.subjectId, req.auth.staffId || null, req.auth.userId, b.week, b.lessonDate || null, b.duration || null, b.topic.trim(),
      b.subtopic || null, b.objectives || null, b.materials || null, b.priorKnowledge || null, b.content, b.evaluation || null, b.assignment || null, b.shareWithClass])).rows[0];
    await audit(c, req, 'lesson_notes.created', { type: 'lesson_note', id: r.id, meta: { classId: b.classId, subjectId: b.subjectId, week: b.week } });
    return r;
  }));

  // author edits a draft / returned note (optimistic concurrency via version)
  app.patch('/lesson-notes/:id', {
    onRequest: [A, app.perm('lesson_notes.create', 'lesson_notes.review')],
    schema: { params: idParams, body: obj({ ...Object.fromEntries(Object.entries(BODY).filter(([k]) => COLS[k])), version: { type: 'integer', minimum: 1 } }, ['version']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const n = (await c.query('SELECT * FROM lesson_notes WHERE id = $1 AND deleted_at IS NULL FOR UPDATE', [req.params.id])).rows[0];
    if (!n || n.author_id !== req.auth.userId) throw E.notFound('Lesson note');
    if (!EDITABLE.includes(n.status)) throw new AppError(409, 'NOTE_LOCKED', n.status === 'approved' ? 'Approved notes are locked. Ask a reviewer to reopen it.' : 'This note is waiting for review and cannot be edited now.');
    if (n.version !== req.body.version) throw new AppError(409, 'VERSION_CONFLICT', 'This note was changed in another window. Reload and try again.');
    const sets = []; const p = [req.params.id];
    for (const [k, col] of Object.entries(COLS)) if (req.body[k] !== undefined) { p.push(k === 'topic' ? String(req.body[k]).trim() : req.body[k]); sets.push(`${col} = $${p.length}`); }
    if (!sets.length) return { id: n.id, version: n.version };
    const r = (await c.query(`UPDATE lesson_notes SET ${sets.join(', ')}, version = version + 1 WHERE id = $1 RETURNING id, status, version`, p)).rows[0];
    await audit(c, req, 'lesson_notes.updated', { type: 'lesson_note', id: n.id, meta: { fields: Object.keys(req.body).filter((k) => k !== 'version') } });
    return r;
  }));

  app.post('/lesson-notes/:id/submit', { onRequest: [A, app.perm('lesson_notes.create', 'lesson_notes.review')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const n = (await c.query(`UPDATE lesson_notes SET status = 'submitted', submitted_at = now(), version = version + 1
      WHERE id = $1 AND author_id = $2 AND deleted_at IS NULL AND status IN ('draft','returned') RETURNING id, topic, week, version`, [req.params.id, req.auth.userId])).rows[0];
    if (!n) throw E.conflict('Only your own draft or returned notes can be submitted.');
    await notify(c, req.auth.schoolId, await reviewers(c, req.auth.userId), { kind: 'lesson_note', title: `Lesson note for review: Week ${n.week} · ${n.topic}`, link: `#/lesson-notes/${n.id}` });
    await audit(c, req, 'lesson_notes.submitted', { type: 'lesson_note', id: n.id });
    return { ok: true, status: 'submitted', version: n.version };
  }));

  // reviewer decision: approve, or return with a comment (required). Authors cannot approve their own note.
  app.post('/lesson-notes/:id/review', {
    onRequest: [A, app.perm('lesson_notes.review')],
    schema: { params: idParams, body: obj({ decision: { enum: ['approve', 'return'] }, note: { type: ['string', 'null'], maxLength: 2000 } }, ['decision']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const { decision } = req.body; const note = (req.body.note || '').trim() || null;
    if (decision === 'return' && (!note || note.length < 3)) throw E.bad('Tell the teacher what to correct (at least 3 characters).', { field: 'note' });
    const cur = (await c.query('SELECT author_id, status FROM lesson_notes WHERE id = $1 AND deleted_at IS NULL FOR UPDATE', [req.params.id])).rows[0];
    if (!cur) throw E.notFound('Lesson note');
    if (cur.author_id === req.auth.userId) throw E.forbidden('You cannot review your own lesson note.');
    if (cur.status !== 'submitted') throw E.conflict('Only submitted notes can be reviewed.');
    const n = (await c.query(`UPDATE lesson_notes SET status = $2, reviewed_by = $3, reviewed_at = now(), review_note = $4, version = version + 1
      WHERE id = $1 RETURNING id, topic, week, author_id`, [req.params.id, decision === 'approve' ? 'approved' : 'returned', req.auth.userId, note])).rows[0];
    await notify(c, req.auth.schoolId, [n.author_id], { kind: 'lesson_note', title: decision === 'approve' ? `Lesson note approved: Week ${n.week} · ${n.topic}` : `Lesson note returned for correction: Week ${n.week} · ${n.topic}`,
      body: note, link: `#/lesson-notes/${n.id}` });
    await audit(c, req, decision === 'approve' ? 'lesson_notes.approved' : 'lesson_notes.returned', { type: 'lesson_note', id: n.id, meta: { note } });
    return { ok: true, status: decision === 'approve' ? 'approved' : 'returned' };
  }));

  // reviewer reopens an approved note (e.g. an error found later) → back to the author as "returned"
  app.post('/lesson-notes/:id/reopen', {
    onRequest: [A, app.perm('lesson_notes.review')], schema: { params: idParams, body: obj({ note: str(2000, 3) }, ['note']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const n = (await c.query(`UPDATE lesson_notes SET status = 'returned', reviewed_by = $2, reviewed_at = now(), review_note = $3, version = version + 1
      WHERE id = $1 AND deleted_at IS NULL AND status = 'approved' RETURNING id, author_id, topic, week`, [req.params.id, req.auth.userId, req.body.note.trim()])).rows[0];
    if (!n) throw E.conflict('Only approved notes can be reopened.');
    await notify(c, req.auth.schoolId, [n.author_id], { kind: 'lesson_note', title: `Lesson note reopened: Week ${n.week} · ${n.topic}`, body: req.body.note, link: `#/lesson-notes/${n.id}` });
    await audit(c, req, 'lesson_notes.reopened', { type: 'lesson_note', id: n.id, meta: { note: req.body.note } });
    return { ok: true, status: 'returned' };
  }));

  // attach one file (PDF, Word, PowerPoint or image) — replaces any previous attachment
  app.post('/lesson-notes/:id/attachment', {
    onRequest: [A, app.perm('lesson_notes.create', 'lesson_notes.review')], schema: { params: idParams }, config: { rateLimit: { max: 30, timeWindow: '1 minute' } },
  }, async (req) => {
    const data = await req.file(); if (!data) throw E.bad('Attach a file.');
    const buffer = await data.toBuffer();
    return withTx(ctx(req), async (c) => {
      const n = (await c.query('SELECT author_id, status, file_id FROM lesson_notes WHERE id = $1 AND deleted_at IS NULL FOR UPDATE', [req.params.id])).rows[0];
      if (!n || n.author_id !== req.auth.userId) throw E.notFound('Lesson note');
      if (!EDITABLE.includes(n.status)) throw new AppError(409, 'NOTE_LOCKED', 'Attachments can only be changed while the note is a draft or returned.');
      const up = await saveUpload(c, { schoolId: req.auth.schoolId, userId: req.auth.userId, purpose: 'lesson_note', buffer, originalName: data.filename });
      if (n.file_id) await c.query('UPDATE uploads SET deleted_at = now() WHERE id = $1', [n.file_id]);
      await c.query('UPDATE lesson_notes SET file_id = $2, version = version + 1 WHERE id = $1', [req.params.id, up.id]);
      await audit(c, req, 'lesson_notes.attachment_uploaded', { type: 'lesson_note', id: req.params.id, meta: { mime: up.mime, bytes: up.size_bytes } });
      return { fileId: up.id };
    });
  });

  app.delete('/lesson-notes/:id', { onRequest: [A, app.perm('lesson_notes.create', 'lesson_notes.review')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const n = (await c.query(`UPDATE lesson_notes SET deleted_at = now() WHERE id = $1 AND author_id = $2 AND deleted_at IS NULL AND status IN ('draft','returned')
      RETURNING id, topic`, [req.params.id, req.auth.userId])).rows[0];
    if (!n) throw E.conflict('Only your own draft or returned notes can be deleted.');
    await audit(c, req, 'lesson_notes.deleted', { type: 'lesson_note', id: n.id, meta: { topic: n.topic } });
    return { ok: true };
  }));
};

module.exports.canReadFile = async function canReadLessonFile(c, req, fileId) {
  const n = (await c.query(`SELECT n.author_id, n.status, n.share_with_class, n.class_id FROM lesson_notes n WHERE n.file_id = $1 AND n.deleted_at IS NULL`, [fileId])).rows[0];
  if (!n) return false;
  return canRead(c, req, n);
};
