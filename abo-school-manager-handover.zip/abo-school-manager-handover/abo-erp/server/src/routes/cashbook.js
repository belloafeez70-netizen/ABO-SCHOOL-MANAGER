'use strict';
// Cashbook — the offline app's income / expenses / petty cash, with server-side rules:
//   • amounts are integer kobo; an entry is never edited or deleted, only VOIDED with a reason (a database trigger
//     enforces this), so the book can always be audited;
//   • the summary adds confirmed school-fee payments and store sales, so the owner sees ALL money in and out;
//   • petty cash is a method: a TOP-UP of the petty-cash box is recorded as income with method "petty_cash" (it is
//     money moving into the box, so the summary does NOT count it as new income), spending from the box is an expense
//     with method "petty_cash" (a real expense). Balance = top-ups − spending, and it can never go below zero.
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, str, uuid, idParams, listQuery } = require('../lib/schema');
const { page, paged, likeEscape } = require('../lib/http');
const { ctx } = require('../auth/plugin');
const { audit } = require('../audit/audit');
const { withIdempotency } = require('../lib/idempotency');

const DAY = { type: 'string', format: 'date' };
const METHODS = ['cash', 'transfer', 'pos', 'cheque', 'petty_cash'];
const lockPetty = (c, schoolId) => c.query("SELECT pg_advisory_xact_lock(hashtext('abo:pettycash:' || $1::text))", [schoolId]);   // no two spends at once
const DEFAULTS = {
  income: ['PTA levy', 'Uniform sales', 'Book sales', 'Donations', 'Money into petty cash', 'Other income'],
  expense: ['Salaries', 'Electricity & fuel', 'Repairs & maintenance', 'Stationery & printing', 'Transport', 'Food & refreshments', 'Other expenses'],
};
async function today(c, schoolId) { return (await c.query('SELECT (now() AT TIME ZONE timezone)::date::text AS d FROM schools WHERE id = $1', [schoolId])).rows[0].d; }
// starter categories: created with every new school (services/provision.js) and for existing schools by migration 018
async function ensureDefaults(c, schoolId) {
  for (const [kind, names] of Object.entries(DEFAULTS)) for (const n of names) {
    await c.query('INSERT INTO cash_categories (school_id, kind, name) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING', [schoolId, kind, n]);
  }
}

module.exports = async function cashbookRoutes(app) {
  const A = app.authenticate; const VIEW = app.perm('cashbook.view'); const REC = app.perm('cashbook.record');

  app.get('/cashbook/categories', { onRequest: [A, VIEW] }, async (req) => withTx(ctx(req), async (c) => {
    const items = (await c.query(`SELECT k.id, k.kind, k.name, k.active, count(e.id) FILTER (WHERE e.voided_at IS NULL)::int AS entries
      FROM cash_categories k LEFT JOIN cash_entries e ON e.category_id = k.id GROUP BY k.id ORDER BY k.kind, k.active DESC, k.name`)).rows;
    return { items };
  }));
  app.post('/cashbook/categories', { onRequest: [A, REC], schema: { body: obj({ kind: { enum: ['income', 'expense'] }, name: str(80, 2) }, ['kind', 'name']) } }, async (req) => withTx(ctx(req), async (c) => {
    try {
      const r = (await c.query('INSERT INTO cash_categories (school_id, kind, name) VALUES ($1,$2,$3) RETURNING id, kind, name, active', [req.auth.schoolId, req.body.kind, req.body.name.trim()])).rows[0];
      await audit(c, req, 'cashbook.category_created', { type: 'cash_category', id: r.id, meta: { kind: r.kind, name: r.name } });
      return r;
    } catch (e) { if (e.code === '23505') throw E.conflict('A category with that name already exists.'); throw e; }
  }));
  app.patch('/cashbook/categories/:id', { onRequest: [A, REC], schema: { params: idParams, body: obj({ name: str(80, 2), active: { type: 'boolean' } }) } }, async (req) => withTx(ctx(req), async (c) => {
    const cur = (await c.query('SELECT * FROM cash_categories WHERE id = $1', [req.params.id])).rows[0]; if (!cur) throw E.notFound('Category');
    try {
      const r = (await c.query('UPDATE cash_categories SET name = $2, active = $3 WHERE id = $1 RETURNING id, kind, name, active', [cur.id, (req.body.name ?? cur.name).trim(), req.body.active ?? cur.active])).rows[0];
      await audit(c, req, 'cashbook.category_updated', { type: 'cash_category', id: r.id, meta: { name: r.name, active: r.active } });
      return r;
    } catch (e) { if (e.code === '23505') throw E.conflict('A category with that name already exists.'); throw e; }
  }));

  app.get('/cashbook/entries', {
    onRequest: [A, VIEW],
    schema: { querystring: listQuery({ from: DAY, to: DAY, kind: { enum: ['income', 'expense'] }, categoryId: uuid, method: { enum: METHODS }, includeVoided: { type: 'boolean' } }) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const q = req.query; const pg = page(q); const p = []; const w = [];
    if (!q.includeVoided) w.push('e.voided_at IS NULL');
    for (const [k, col] of [['from', 'e.entry_date >='], ['to', 'e.entry_date <='], ['kind', 'e.kind ='], ['categoryId', 'e.category_id ='], ['method', 'e.method =']]) {
      if (q[k] !== undefined && q[k] !== '') { p.push(q[k]); w.push(`${col} $${p.length}`); }
    }
    if (q.q) { p.push(`%${likeEscape(q.q)}%`); w.push(`(e.description ILIKE $${p.length} OR e.party ILIKE $${p.length} OR e.reference ILIKE $${p.length})`); }
    const where = w.length ? `WHERE ${w.join(' AND ')}` : '';
    const total = (await c.query(`SELECT count(*)::int AS n FROM cash_entries e ${where}`, p)).rows[0].n;
    const sums = (await c.query(`SELECT coalesce(sum(amount_kobo) FILTER (WHERE kind = 'income' AND voided_at IS NULL), 0)::bigint AS income,
      coalesce(sum(amount_kobo) FILTER (WHERE kind = 'expense' AND voided_at IS NULL), 0)::bigint AS expense FROM cash_entries e ${where}`, p)).rows[0];
    const rows = (await c.query(`SELECT e.id, e.kind, e.category_id, k.name AS category, e.amount_kobo, e.entry_date::text, e.method, e.reference, e.party, e.description,
        e.created_at, u.full_name AS recorded_by, e.voided_at, e.void_reason, v.full_name AS voided_by
      FROM cash_entries e JOIN cash_categories k ON k.id = e.category_id LEFT JOIN users u ON u.id = e.created_by LEFT JOIN users v ON v.id = e.voided_by
      ${where} ORDER BY e.entry_date DESC, e.created_at DESC LIMIT ${pg.limit} OFFSET ${pg.offset}`, p)).rows;
    return { ...paged(rows, total, pg), totals: { incomeKobo: Number(sums.income), expenseKobo: Number(sums.expense) } };
  }));

  app.post('/cashbook/entries', {
    onRequest: [A, REC],
    schema: { body: obj({ kind: { enum: ['income', 'expense'] }, categoryId: uuid, amountKobo: { type: 'integer', minimum: 1, maximum: 100000000000 }, entryDate: DAY,
      method: { enum: METHODS }, reference: { type: ['string', 'null'], maxLength: 80 }, party: { type: ['string', 'null'], maxLength: 160 }, description: str(300, 2) },
    ['kind', 'categoryId', 'amountKobo', 'entryDate', 'method', 'description']) },
  }, async (req, reply) => withTx(ctx(req), async (c) => withIdempotency(c, req, reply, 'cashbook.entry', async () => {
    const b = req.body;
    const cat = (await c.query('SELECT id, kind, active, name FROM cash_categories WHERE id = $1', [b.categoryId])).rows[0];
    if (!cat) throw E.bad('Choose a category.', { field: 'categoryId' });
    if (cat.kind !== b.kind) throw E.bad(`"${cat.name}" is ${cat.kind === 'income' ? 'an income' : 'an expense'} category.`, { field: 'categoryId' });
    if (!cat.active) throw E.bad(`The category "${cat.name}" is switched off.`, { field: 'categoryId' });
    const t = await today(c, req.auth.schoolId);
    if (b.entryDate > t) throw E.bad('The date cannot be in the future.', { field: 'entryDate' });
    if (b.kind === 'expense' && b.method === 'petty_cash') {
      await lockPetty(c, req.auth.schoolId);
      const bal = Number((await c.query(`SELECT coalesce(sum(CASE WHEN kind = 'income' THEN amount_kobo ELSE -amount_kobo END), 0)::bigint AS b FROM cash_entries
        WHERE method = 'petty_cash' AND voided_at IS NULL`)).rows[0].b);
      if (b.amountKobo > bal) throw E.bad(`There is only ₦${(bal / 100).toLocaleString('en-NG', { minimumFractionDigits: 2 })} in petty cash. Put money into petty cash first.`, { field: 'amountKobo' });
    }
    const r = (await c.query(`INSERT INTO cash_entries (school_id, kind, category_id, amount_kobo, entry_date, method, reference, party, description, created_by)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id, kind, category_id, amount_kobo, entry_date::text, method, reference, party, description, created_at`,
    [req.auth.schoolId, b.kind, cat.id, b.amountKobo, b.entryDate, b.method, b.reference || null, b.party || null, b.description.trim(), req.auth.userId])).rows[0];
    await audit(c, req, 'cashbook.recorded', { type: 'cash_entry', id: r.id, meta: { kind: r.kind, amountKobo: r.amount_kobo, method: r.method, category: cat.name } });
    return { ...r, category: cat.name };
  })));

  app.post('/cashbook/entries/:id/void', { onRequest: [A, app.perm('cashbook.void')], schema: { params: idParams, body: obj({ reason: str(300, 3) }, ['reason']) } }, async (req) => withTx(ctx(req), async (c) => {
    const cur = (await c.query('SELECT id, voided_at, amount_kobo, kind, method FROM cash_entries WHERE id = $1 FOR UPDATE', [req.params.id])).rows[0];
    if (!cur) throw E.notFound('Cashbook entry');
    if (cur.voided_at) throw E.conflict('This entry was already voided.');
    if (cur.kind === 'income' && cur.method === 'petty_cash') {     // voiding money put INTO petty cash must not make the box negative
      await lockPetty(c, req.auth.schoolId);
      const bal = Number((await c.query(`SELECT coalesce(sum(CASE WHEN kind = 'income' THEN amount_kobo ELSE -amount_kobo END), 0)::bigint AS b FROM cash_entries
        WHERE method = 'petty_cash' AND voided_at IS NULL`)).rows[0].b);
      if (bal - Number(cur.amount_kobo) < 0) throw E.conflict('Voiding this would make petty cash negative. Void the spending from petty cash first.');
    }
    await c.query('UPDATE cash_entries SET voided_at = now(), voided_by = $2, void_reason = $3 WHERE id = $1', [cur.id, req.auth.userId, req.body.reason.trim()]);
    await audit(c, req, 'cashbook.voided', { type: 'cash_entry', id: cur.id, meta: { amountKobo: cur.amount_kobo, kind: cur.kind, reason: req.body.reason.trim() } });
    return { ok: true };
  }));

  app.get('/cashbook/summary', { onRequest: [A, VIEW], schema: { querystring: obj({ from: DAY, to: DAY }) } }, async (req) => withTx(ctx(req), async (c) => {
    const t = await today(c, req.auth.schoolId);
    const from = req.query.from || t.slice(0, 8) + '01'; const to = req.query.to || t;
    if (to < from) throw E.bad('"to" must be on or after "from".');
    const byCat = (await c.query(`SELECT e.kind, k.name AS category, sum(e.amount_kobo)::bigint AS amount_kobo, count(*)::int AS entries
      FROM cash_entries e JOIN cash_categories k ON k.id = e.category_id WHERE e.voided_at IS NULL AND e.entry_date BETWEEN $1 AND $2
        AND NOT (e.kind = 'income' AND e.method = 'petty_cash')     -- petty-cash top-ups move money, they are not new income
      GROUP BY e.kind, k.name ORDER BY e.kind, sum(e.amount_kobo) DESC`, [from, to])).rows.map((r) => ({ ...r, amount_kobo: Number(r.amount_kobo) }));
    const fees = Number((await c.query(`SELECT coalesce(sum(p.amount_kobo), 0)::bigint AS s FROM payments p JOIN schools s ON s.id = p.school_id
      WHERE p.status = 'confirmed' AND (p.paid_at AT TIME ZONE s.timezone)::date BETWEEN $1 AND $2`, [from, to])).rows[0].s);
    const store = Number((await c.query(`SELECT coalesce(sum(x.total_kobo), 0)::bigint AS s FROM store_sales x JOIN schools s ON s.id = x.school_id
      WHERE x.voided_at IS NULL AND (x.sold_at AT TIME ZONE s.timezone)::date BETWEEN $1 AND $2`, [from, to])).rows[0].s);
    const other = byCat.filter((r) => r.kind === 'income').reduce((a, r) => a + r.amount_kobo, 0);
    const spent = byCat.filter((r) => r.kind === 'expense').reduce((a, r) => a + r.amount_kobo, 0);
    const pc = (await c.query(`SELECT coalesce(sum(amount_kobo) FILTER (WHERE kind = 'income'), 0)::bigint AS put_in, coalesce(sum(amount_kobo) FILTER (WHERE kind = 'expense'), 0)::bigint AS spent
      FROM cash_entries WHERE method = 'petty_cash' AND voided_at IS NULL AND entry_date <= $1`, [to])).rows[0];
    return { from, to, feesKobo: fees, storeSalesKobo: store, otherIncomeKobo: other, totalIncomeKobo: fees + store + other, expenseKobo: spent, netKobo: fees + store + other - spent,
      pettyCash: { putInKobo: Number(pc.put_in), spentKobo: Number(pc.spent), balanceKobo: Number(pc.put_in) - Number(pc.spent) }, byCategory: byCat };
  }));
};
module.exports.ensureDefaults = ensureDefaults;
module.exports.DEFAULTS = DEFAULTS;
