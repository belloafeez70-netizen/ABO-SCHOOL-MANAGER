'use strict';
const { withTx } = require('../db/pool');
const { obj, listQuery } = require('../lib/schema');
const { page, paged, likeEscape } = require('../lib/http');
const { ctx } = require('../auth/plugin');

module.exports = async function auditRoutes(app) {
  const A = app.authenticate;
  app.get('/audit', { onRequest: [A, app.perm('audit_logs.view')], schema: { querystring: listQuery({ action: { type: 'string', maxLength: 60 }, actor: { type: 'string', format: 'uuid' }, from: { type: 'string', format: 'date' }, to: { type: 'string', format: 'date' } }) } }, async (req) => {
    const pg = page(req.query);
    return withTx(ctx(req), async (c) => {
      const p = [req.auth.schoolId]; const w = ['school_id = $1'];
      if (req.query.action) { p.push(`${likeEscape(req.query.action)}%`); w.push(`action LIKE $${p.length}`); }
      if (req.query.actor) { p.push(req.query.actor); w.push(`actor_user_id = $${p.length}`); }
      if (req.query.from) { p.push(req.query.from); w.push(`created_at >= $${p.length}::date`); }
      if (req.query.to) { p.push(req.query.to); w.push(`created_at < $${p.length}::date + 1`); }
      if (req.query.q) { p.push(`%${likeEscape(req.query.q.toLowerCase())}%`); w.push(`(lower(actor_login) LIKE $${p.length} OR lower(action) LIKE $${p.length} OR resource_id ILIKE $${p.length})`); }
      const total = (await c.query(`SELECT count(*)::int AS n FROM audit_logs WHERE ${w.join(' AND ')}`, p)).rows[0].n;
      const rows = (await c.query(`SELECT id, seq, created_at, actor_login, actor_roles, action, resource_type, resource_id, success, host(ip) AS ip, user_agent, metadata
        FROM audit_logs WHERE ${w.join(' AND ')} ORDER BY seq DESC LIMIT ${pg.limit} OFFSET ${pg.offset}`, p)).rows;
      return paged(rows, total, pg);
    });
  });
  app.get('/audit/verify', { onRequest: [A, app.perm('audit_logs.view')] }, async (req) => withTx(ctx(req), async (c) =>
    (await c.query('SELECT * FROM app.audit_verify($1)', [req.auth.schoolId])).rows[0]));

  app.get('/security/login-events', { onRequest: [A, app.perm('security.view', 'audit_logs.view')], schema: { querystring: listQuery({ failedOnly: { type: 'boolean' } }) } }, async (req) => {
    const pg = page(req.query);
    return withTx(ctx(req), async (c) => {
      const w = req.query.failedOnly ? 'WHERE NOT l.success' : '';
      const total = (await c.query(`SELECT count(*)::int AS n FROM login_events l ${w}`)).rows[0].n;
      const rows = (await c.query(`SELECT l.id, l.created_at, l.login_attempt, l.success, l.reason, host(l.ip) AS ip, l.user_agent, u.full_name FROM login_events l LEFT JOIN users u ON u.id = l.user_id
        ${w} ORDER BY l.created_at DESC LIMIT ${pg.limit} OFFSET ${pg.offset}`)).rows;
      return paged(rows, total, pg);
    });
  });
  app.get('/security/events', { onRequest: [A, app.perm('security.view', 'audit_logs.view')], schema: { querystring: listQuery() } }, async (req) => {
    const pg = page(req.query);
    return withTx(ctx(req), async (c) => {
      const total = (await c.query('SELECT count(*)::int AS n FROM security_events')).rows[0].n;
      const rows = (await c.query(`SELECT e.id, e.kind, e.severity, e.detail, host(e.ip) AS ip, e.created_at, u.full_name FROM security_events e LEFT JOIN users u ON u.id = e.user_id
        ORDER BY e.created_at DESC LIMIT ${pg.limit} OFFSET ${pg.offset}`)).rows;
      return paged(rows, total, pg);
    });
  });
};
