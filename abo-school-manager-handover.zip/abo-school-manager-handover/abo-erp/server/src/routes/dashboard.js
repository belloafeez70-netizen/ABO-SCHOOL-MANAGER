'use strict';
// Role-aware dashboard aggregates — small, indexed queries; never ships whole tables to the browser.
const { withTx } = require('../db/pool');
const { ctx } = require('../auth/plugin');

module.exports = async function dashboardRoutes(app) {
  app.get('/dashboard', { onRequest: [app.authenticate] }, async (req) => {
    const a = req.auth;
    if (a.portal === 'platform') return { portal: 'platform' };
    return withTx(ctx(req), async (c) => {
      const out = { portal: a.portal, cards: {} };
      const term = (await c.query('SELECT t.id, t.name, s.name AS session FROM terms t JOIN academic_sessions s ON s.id = t.session_id WHERE t.is_current LIMIT 1')).rows[0] || null;
      out.term = term;
      if (a.portal === 'staff') {
        if (req.can('students.view')) out.cards.students = (await c.query(`SELECT count(*)::int AS total, count(*) FILTER (WHERE gender = 'Male')::int AS male, count(*) FILTER (WHERE gender = 'Female')::int AS female FROM students WHERE status = 'active' AND deleted_at IS NULL`)).rows[0];
        if (req.can('staff.view')) out.cards.staff = (await c.query("SELECT count(*)::int AS total, count(*) FILTER (WHERE is_teacher)::int AS teachers FROM staff WHERE employment_status <> 'exited'")).rows[0];
        if (req.can('academic.view')) out.cards.classes = (await c.query('SELECT count(*)::int AS total FROM classes')).rows[0];
        if (req.can('attendance.view')) out.cards.attendanceToday = (await c.query(`SELECT count(*) FILTER (WHERE status IN ('present','late'))::int AS present, count(*) FILTER (WHERE status = 'absent')::int AS absent FROM attendance_records WHERE date = CURRENT_DATE`)).rows[0];
        if (req.can('fees.view') && term) out.cards.fees = (await c.query(`SELECT COALESCE(sum(total_kobo),0)::bigint AS billed, COALESCE(sum(paid_kobo),0)::bigint AS collected FROM invoices WHERE status <> 'void' AND term_id = $1`, [term.id])).rows[0];
        if (req.can('results.view') && term) out.cards.results = (await c.query(`SELECT count(*) FILTER (WHERE status = 'draft')::int AS draft, count(*) FILTER (WHERE status = 'submitted')::int AS submitted, count(*) FILTER (WHERE status = 'approved')::int AS approved, count(*) FILTER (WHERE status = 'published')::int AS published FROM assessments WHERE term_id = $1`, [term.id])).rows[0];
        if (req.can('results.approve')) out.cards.pendingCorrections = (await c.query("SELECT count(*)::int AS n FROM result_corrections WHERE status = 'pending'")).rows[0].n;
        if (req.can('cbt.view')) out.cards.cbt = (await c.query("SELECT count(*) FILTER (WHERE status = 'published')::int AS live, count(*) FILTER (WHERE status = 'draft')::int AS drafts FROM cbt_exams")).rows[0];
        if (a.staffId) out.myClasses = (await c.query(`SELECT cl.id, cl.display_name, bool_or(t.role IN ('form_teacher','assistant')) AS form_teacher FROM teacher_class_access t JOIN classes cl ON cl.id = t.class_id
          WHERE t.staff_id = $1 GROUP BY cl.id, cl.display_name ORDER BY cl.display_name`, [a.staffId])).rows;
        if (a.staffId) out.mySubjects = (await c.query(`SELECT DISTINCT t.class_id, cl.display_name AS class_name, t.subject_id, s.name AS subject FROM teacher_class_access t JOIN classes cl ON cl.id = t.class_id JOIN subjects s ON s.id = t.subject_id
          WHERE t.staff_id = $1 ORDER BY cl.display_name, s.name`, [a.staffId])).rows;
        if (req.can('students.view')) out.enrolmentByClass = (await c.query(`SELECT cl.display_name AS label, count(e.*)::int AS value FROM classes cl LEFT JOIN student_enrollments e ON e.class_id = cl.id AND e.status = 'active'
          AND e.session_id = (SELECT id FROM academic_sessions WHERE is_current LIMIT 1) GROUP BY cl.id ORDER BY cl.sort_order, cl.display_name LIMIT 40`)).rows;
      } else {
        const kids = [a.studentId, ...a.children].filter(Boolean);
        out.children = (await c.query(`SELECT s.id, s.first_name, s.last_name, s.admission_no, cl.display_name AS class_name, cl.id AS class_id,
            (SELECT json_build_object('average', tr.average, 'position', tr.position, 'class_size', tr.class_size, 'grade', tr.grade) FROM result_summaries tr WHERE tr.student_id = s.id AND tr.published AND tr.term_id = $2) AS result,
            (SELECT COALESCE(sum(total_kobo - paid_kobo),0)::bigint FROM invoices i WHERE i.student_id = s.id AND i.status IN ('unpaid','partial')) AS balance_kobo,
            (SELECT count(*)::int FROM invoices i WHERE i.student_id = s.id AND i.status <> 'void') AS invoices,
            (SELECT count(*)::int FROM attendance_records at WHERE at.student_id = s.id AND at.term_id = $2 AND at.status = 'absent') AS absences
          FROM students s LEFT JOIN academic_sessions cs ON cs.is_current LEFT JOIN student_enrollments e ON e.student_id = s.id AND e.session_id = cs.id LEFT JOIN classes cl ON cl.id = e.class_id
          WHERE s.id = ANY($1::uuid[])`, [kids, term ? term.id : null])).rows;
        if (a.studentId) out.cbtOpen = (await c.query(`SELECT count(*)::int AS n FROM cbt_exams e WHERE e.status = 'published' AND (e.ends_at IS NULL OR e.ends_at > now())
          AND (e.class_id IS NULL OR e.class_id = $1)`, [out.children[0] && out.children[0].class_id])).rows[0].n;
      }
      out.announcements = (await c.query(`SELECT id, title, priority, publish_at FROM announcements WHERE publish_at <= now() AND (expires_at IS NULL OR expires_at > now())
        AND (audience = 'all' OR audience = $1) AND class_id IS NULL ORDER BY pinned DESC, publish_at DESC LIMIT 5`, [a.portal === 'staff' ? 'staff' : a.portal === 'parent' ? 'parents' : 'students'])).rows;
      return out;
    });
  });
};
