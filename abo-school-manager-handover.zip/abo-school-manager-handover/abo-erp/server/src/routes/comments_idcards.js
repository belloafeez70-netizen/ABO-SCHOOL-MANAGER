'use strict';
// Phase 6 (part 2):
//   • Comment helper — suggested teacher and head comments for a whole class, reviewed and saved in one go.
//     The same rules as the single report-card save apply: only the class's form teacher (or someone with
//     results.enter_any) writes teacher comments; only reviewers (results.approve) write head comments.
//   • ID cards — the data for printable pupil and staff ID cards (the browser draws the cards and a real Code-128
//     barcode of the admission / staff number).
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, uuid } = require('../lib/schema');
const { ctx } = require('../auth/plugin');
const { audit } = require('../audit/audit');
const R = require('../services/results');
const C = require('../services/comments');

async function access(c, req, classId) {
  const cls = (await c.query('SELECT id, display_name, section, form_teacher_id FROM classes WHERE id = $1', [classId])).rows[0];
  if (!cls) throw E.notFound('Class');
  const teacher = req.can('results.enter_any') || (!!req.auth.staffId && cls.form_teacher_id === req.auth.staffId);
  const head = req.can('results.approve');
  return { cls, teacher, head };
}

module.exports = async function commentsIdCardsRoutes(app) {
  const A = app.authenticate;

  app.get('/results/comment-helper', {
    onRequest: [A, app.perm('results.enter', 'results.enter_any', 'results.approve')],
    schema: { querystring: obj({ termId: uuid, classId: uuid }, ['termId', 'classId']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const { termId, classId } = req.query;
    const { cls, teacher, head } = await access(c, req, classId);
    if (!teacher && !head) throw E.forbidden('Only the form teacher of this class or a reviewer can write report-card comments.');
    const term = (await c.query('SELECT id, name, days_open FROM terms WHERE id = $1', [termId])).rows[0]; if (!term) throw E.notFound('Term');
    const roster = await R.roster(c, termId, classId);
    const ids = roster.map((s) => s.id);
    const sums = new Map((await c.query('SELECT student_id, average, position, grade, status, class_size FROM result_summaries WHERE term_id = $1 AND class_id = $2', [termId, classId])).rows.map((r) => [r.student_id, r]));
    const subs = new Map();
    for (const r of (await c.query(`SELECT er.student_id, s.name, er.total FROM examination_results er JOIN assessments a ON a.id = er.sheet_id JOIN subjects s ON s.id = a.subject_id
      WHERE a.term_id = $1 AND a.class_id = $2 ORDER BY er.total DESC, s.name`, [termId, classId])).rows) { if (!subs.has(r.student_id)) subs.set(r.student_id, []); subs.get(r.student_id).push(r); }
    const att = new Map((await c.query(`SELECT student_id, count(*) FILTER (WHERE status IN ('present','late'))::int AS present FROM attendance_records
      WHERE term_id = $1 AND student_id = ANY($2::uuid[]) GROUP BY student_id`, [termId, ids])).rows.map((r) => [r.student_id, r.present]));
    const rc = new Map((await c.query('SELECT student_id, teacher_comment, head_comment FROM report_cards WHERE term_id = $1 AND student_id = ANY($2::uuid[])', [termId, ids])).rows.map((r) => [r.student_id, r]));
    const items = roster.map((s) => {
      const sm = sums.get(s.id); const list = subs.get(s.id) || []; const cur = rc.get(s.id) || {};
      const base = { studentId: s.id, name: [s.last_name, s.first_name, s.other_names].filter(Boolean).join(' '), admissionNo: s.admission_no,
        average: sm ? Number(sm.average) : null, position: sm ? sm.position : null, classSize: sm ? sm.class_size : null, grade: sm ? sm.grade : null,
        teacherComment: cur.teacher_comment || null, headComment: cur.head_comment || null };
      if (!sm) return { ...base, suggestedTeacher: null, suggestedHead: null, note: 'No computed result yet — compute the class broadsheet first.' };
      return { ...base,
        suggestedTeacher: teacher ? C.teacherComment({ firstName: s.first_name, average: sm.average, strongest: list[0] && list[0].name, weakest: list.length > 1 ? list[list.length - 1].name : null,
          present: att.has(s.id) ? att.get(s.id) : null, daysOpen: term.days_open }) : null,
        suggestedHead: head ? C.headComment({ firstName: s.first_name, average: sm.average, section: cls.section }) : null };
    });
    return { class: { id: cls.id, name: cls.display_name }, term: { id: term.id, name: term.name }, can: { teacher, head }, items };
  }));

  app.put('/results/report-cards/bulk', {
    onRequest: [A, app.perm('results.enter', 'results.enter_any', 'results.approve')],
    schema: { body: obj({ termId: uuid, classId: uuid, items: { type: 'array', minItems: 1, maxItems: 200, items: obj({ studentId: uuid,
      teacherComment: { type: ['string', 'null'], maxLength: 600 }, headComment: { type: ['string', 'null'], maxLength: 600 } }, ['studentId']) } }, ['termId', 'classId', 'items']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const { termId, classId, items } = req.body;
    const { teacher, head } = await access(c, req, classId);
    if (items.some((x) => x.headComment !== undefined) && !head) throw E.forbidden('Only reviewers can write the head/principal comment.');
    if (items.some((x) => x.teacherComment !== undefined) && !teacher) throw E.forbidden('Only the form teacher of this class can write the class teacher comment.');
    if (!(await c.query('SELECT 1 FROM terms WHERE id = $1', [termId])).rowCount) throw E.notFound('Term');
    const inClass = new Set((await R.roster(c, termId, classId)).map((s) => s.id));
    const stray = items.filter((x) => !inClass.has(x.studentId));
    if (stray.length) throw E.bad(`${stray.length} pupil(s) are not in this class for this term.`);
    if (new Set(items.map((x) => x.studentId)).size !== items.length) throw E.bad('A pupil appears twice in the list.');
    let saved = 0;
    for (const x of items) {
      const t = x.teacherComment !== undefined; const hc = x.headComment !== undefined;
      if (!t && !hc) continue;
      const clean = (v) => (v === null || v === undefined ? null : (String(v).trim() || null));
      await c.query(`INSERT INTO report_cards (school_id, term_id, student_id, teacher_comment, head_comment, updated_by, updated_at) VALUES ($1,$2,$3,$4,$5,$6, now())
        ON CONFLICT (term_id, student_id) DO UPDATE SET teacher_comment = CASE WHEN $7 THEN EXCLUDED.teacher_comment ELSE report_cards.teacher_comment END,
          head_comment = CASE WHEN $8 THEN EXCLUDED.head_comment ELSE report_cards.head_comment END, updated_by = EXCLUDED.updated_by, updated_at = now()`,
      [req.auth.schoolId, termId, x.studentId, clean(x.teacherComment), clean(x.headComment), req.auth.userId, t, hc]);
      saved++;
    }
    await audit(c, req, 'results.report_cards_bulk_updated', { type: 'class', id: classId, meta: { termId, saved } });
    return { ok: true, saved };
  }));

  // ───────────────────────── ID cards ─────────────────────────
  const schoolInfo = async (c) => (await c.query(`SELECT s.name, s.motto, s.address, s.phone, s.logo_file_id, s.brand_color,
    (SELECT name FROM academic_sessions WHERE is_current LIMIT 1) AS session FROM schools s LIMIT 1`)).rows[0];
  app.get('/id-cards/students', { onRequest: [A, app.perm('students.view')], schema: { querystring: obj({ classId: uuid }, ['classId']) } }, async (req) => withTx({ ...ctx(req), readOnly: false }, async (c) => {   // writes an audit entry
    const cls = (await c.query('SELECT id, display_name FROM classes WHERE id = $1', [req.query.classId])).rows[0]; if (!cls) throw E.notFound('Class');
    const people = (await c.query(`SELECT s.id, trim(concat_ws(' ', s.first_name, s.other_names, s.last_name)) AS name, s.admission_no, s.gender, s.passport_file_id,
        (SELECT coalesce(g.phone, g.whatsapp) FROM student_guardians sg JOIN guardians g ON g.id = sg.guardian_id WHERE sg.student_id = s.id ORDER BY sg.is_primary DESC LIMIT 1) AS guardian_phone
      FROM student_enrollments e JOIN academic_sessions a ON a.id = e.session_id AND a.is_current JOIN students s ON s.id = e.student_id AND s.deleted_at IS NULL AND s.status = 'active'
      WHERE e.class_id = $1 AND e.status <> 'withdrawn' ORDER BY s.last_name, s.first_name LIMIT 500`, [cls.id])).rows;
    await audit(c, req, 'idcards.students_prepared', { type: 'class', id: cls.id, meta: { count: people.length } });
    return { school: await schoolInfo(c), className: cls.display_name, people: people.map((p) => ({ ...p, className: cls.display_name })) };
  }));
  app.get('/id-cards/staff', { onRequest: [A, app.perm('staff.view')] }, async (req) => withTx({ ...ctx(req), readOnly: false }, async (c) => {
    const people = (await c.query(`SELECT id, full_name AS name, employee_id AS staff_no, designation, gender, phone FROM staff WHERE employment_status = 'active' ORDER BY full_name LIMIT 1000`)).rows;
    await audit(c, req, 'idcards.staff_prepared', { meta: { count: people.length } });
    return { school: await schoolInfo(c), people };
  }));
};
