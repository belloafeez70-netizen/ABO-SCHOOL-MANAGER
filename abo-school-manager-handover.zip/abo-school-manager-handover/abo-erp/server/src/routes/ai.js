'use strict';
// AI remark suggestions. Keys live ONLY on the server. Student data sent to the provider is minimised and
// pseudonymised (no names, admission numbers, dates of birth, contacts). Suggestions are NEVER saved
// automatically — a human must accept them via PUT /results/report-cards/:id (which is audited).
const config = require('../config');
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, uuid } = require('../lib/schema');
const { ctx } = require('../auth/plugin');
const { audit } = require('../audit/audit');
const G = require('../services/grading');

function buildPrompt(summary, subjects) {
  // only aggregate academic signals — no PII
  const lines = subjects.map((s) => `- ${s.subject}: ${s.total}/100 (${s.grade})`).join('\n');
  return [
    { role: 'system', content: 'You write short, encouraging, specific end-of-term report-card remarks for Nigerian school pupils. 2 sentences, max 45 words. Never invent facts, never mention names.' },
    { role: 'user', content: `Term average: ${summary.average}. Overall grade: ${summary.grade || 'n/a'}. Status: ${summary.status}.\nSubjects:\n${lines}\nWrite the class teacher's remark about "the pupil".` },
  ];
}

module.exports = async function aiRoutes(app) {
  app.post('/ai/remark-suggestion', {
    onRequest: [app.authenticate, app.perm('ai.use')], config: { rateLimit: { max: 30, timeWindow: '1 minute' } },
    schema: { body: obj({ studentId: uuid, termId: uuid }, ['studentId', 'termId']) },
  }, async (req) => {
    const data = await withTx({ ...ctx(req), readOnly: false }, async (c) => {
      const st = (await c.query('SELECT ai_enabled FROM school_settings LIMIT 1')).rows[0];
      const tr = (await c.query('SELECT average, grade, status FROM result_summaries WHERE term_id = $1 AND student_id = $2', [req.body.termId, req.body.studentId])).rows[0];
      if (!tr) throw E.bad('Compute or publish the broadsheet for this class first.');
      const subjects = (await c.query(`SELECT s.name AS subject, er.total, er.grade FROM examination_results er JOIN assessments a ON a.id = er.sheet_id JOIN subjects s ON s.id = a.subject_id
        WHERE a.term_id = $1 AND er.student_id = $2 ORDER BY er.total DESC`, [req.body.termId, req.body.studentId])).rows;
      await audit(c, req, 'ai.remark_suggested', { type: 'student', id: req.body.studentId, meta: { online: !!(st && st.ai_enabled && config.ai.apiKey) } });
      return { enabled: !!(st && st.ai_enabled), tr, subjects };
    });
    const offline = G.offlineRemark({ average: data.tr.average, grade: data.tr.grade, status: data.tr.status, strongest: data.subjects[0] && data.subjects[0].subject, weakest: data.subjects.length > 1 ? data.subjects[data.subjects.length - 1].subject : null });
    if (!data.enabled || !config.ai.apiKey || !config.ai.providerUrl) return { suggestion: offline, source: 'offline', note: 'Suggestion only — review and edit before saving.' };
    try {
      const res = await fetch(config.ai.providerUrl, {
        method: 'POST', headers: { authorization: `Bearer ${config.ai.apiKey}`, 'content-type': 'application/json' },
        body: JSON.stringify({ model: config.ai.model, messages: buildPrompt(data.tr, data.subjects), max_tokens: 120, temperature: 0.6 }), signal: AbortSignal.timeout(config.ai.timeoutMs),
      });
      const j = await res.json();
      const text = j && j.choices && j.choices[0] && j.choices[0].message && String(j.choices[0].message.content || '').trim();
      if (!res.ok || !text) throw new Error('bad provider response');
      return { suggestion: text.slice(0, 600), source: 'online', note: 'Suggestion only — review and edit before saving.' };
    } catch (e) {
      req.log.warn({ err: e.message }, 'AI provider failed; using offline remark');
      return { suggestion: offline, source: 'offline', note: 'Online AI unavailable — offline suggestion shown.' };
    }
  });
};
module.exports.buildPrompt = buildPrompt;
