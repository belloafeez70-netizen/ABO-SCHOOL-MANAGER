'use strict';
// Pre-authentication school portal: once the platform approves a school, its own sign-in page
// (/#/s/<slug>) shows the school's name, motto, colour and logo. Only ACTIVE schools are visible;
// pending, suspended and unknown slugs all answer the same 404 (nothing to enumerate).
const { raw } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj } = require('../lib/schema');
const { driver } = require('../storage');
const config = require('../config');
// lazy: services/demo → provision → routes → auth/plugin would be a require cycle
const demoSvc = () => require('../services/demo');
const S = require('../auth/sessions');
const { auditAlone } = require('../audit/audit');

const slugParams = obj({ slug: { type: 'string', pattern: '^[A-Za-z0-9-]{3,30}$' } }, ['slug']);
const limit = { rateLimit: { max: 60, timeWindow: '1 minute' } };

module.exports = async function publicRoutes(app) {
  // Tiny reachability check for the web app ("is the school server behind this page?"). No database, no data, no
  // version details — just a fixed answer, so a page opened in a preview or on a disconnected site can say so clearly.
  app.get('/public/status', { config: { rateLimit: { max: 120, timeWindow: '1 minute' } } }, async (req, reply) => {
    reply.header('cache-control', 'no-store');
    return { ok: true, service: 'abo-api' };
  });
  // ── Demo (028, owner's request): ONLY with a demo link made by the A.B.O. platform owner in the platform console.
  //    Two demo schools, 5-minute sessions (the server ends them; the page only shows the countdown). Without a valid
  //    link nothing is shown and nothing can start.
  const passOf = (v) => (typeof v === 'string' && /^[A-Za-z0-9-]{8,40}$/.test(v) ? demoSvc().passHash(v) : null);
  const settings = async () => (await raw('SELECT * FROM app.demo_settings()')).rows[0] || { demo_enabled: false, demo_minutes: 5 };
  app.get('/public/demo', { config: limit, schema: { querystring: obj({ pass: { type: 'string', maxLength: 60 } }) } }, async (req, reply) => {
    reply.header('cache-control', 'no-store');
    const st = await settings();
    const h = passOf(req.query.pass);
    const p = h ? (await raw('SELECT * FROM app.demo_pass_check($1)', [h])).rows[0] : null;
    if (!st.demo_enabled || !p) return { enabled: !!st.demo_enabled, passValid: false, contact: 'A.B.O. Edu Consultant · 0805 144 6681' };
    return { enabled: true, passValid: true, usesLeft: p.uses_left, passExpiresAt: p.expires_at, minutes: Math.min(5, st.demo_minutes || 5),
      schools: demoSvc().DEMOS.filter((d) => !p.school_key || d.key === p.school_key).map((d) => ({ key: d.key, name: d.name, kind: d.type === 'secondary' ? 'Secondary school (JSS 1 – SS 3)' : 'Creche, nursery and primary school', motto: d.motto })),
      as: [{ key: 'admin', label: 'School office (administrator)' }, { key: 'teacher', label: 'Teacher' }, { key: 'parent', label: 'Parent' }, { key: 'student', label: 'Pupil / student' }] };
  });
  app.post('/public/demo/start', {
    config: { rateLimit: { max: 10, timeWindow: '1 minute' } },
    schema: { body: obj({ school: { enum: demoSvc().DEMOS.map((d) => d.key) }, as: { enum: Object.keys(demoSvc().AS) }, pass: { type: 'string', maxLength: 60 } }, ['school', 'as', 'pass']) },
  }, async (req, reply) => {
    const h = passOf(req.body.pass);
    const passId = h ? (await raw('SELECT app.demo_pass_use($1, $2) AS id', [h, req.body.school])).rows[0].id : null;
    if (!passId) throw E.forbidden('This demo link is not valid any more. Ask A.B.O. Edu Consultant (0805 144 6681) for a new one.');
    let r;
    try { r = await demoSvc().startDemo({ school: req.body.school, as: req.body.as, ip: req.ip, ua: req.headers['user-agent'] }); }
    catch (e) { await raw('SELECT app.demo_pass_refund($1)', [passId]).catch(() => {}); throw e; }        // not started → the use is given back
    S.setCookie(reply, r.token);
    await auditAlone({ ip: req.ip, headers: req.headers, auth: null }, 'demo.started', { type: 'demo', id: r.school.slug, meta: { as: req.body.as, minutes: r.minutes, passId } }).catch(() => {});
    return { ok: true, expiresAt: r.expiresAt, minutes: r.minutes, school: r.school.name, csrf: S.csrfFor(r.sessionId) };
  });

  app.get('/public/schools/:slug', { config: limit, schema: { params: slugParams } }, async (req, reply) => {
    const s = (await raw('SELECT * FROM app.public_school_profile($1)', [req.params.slug])).rows[0];
    if (!s) throw E.notFound('School');
    reply.header('Cache-Control', 'public, max-age=60');
    return {
      id: s.id, slug: s.slug, name: s.name, motto: s.motto, schoolType: s.school_type, brandColor: s.brand_color,
      logoUrl: s.has_logo ? `/api/v1/public/schools/${encodeURIComponent(s.slug)}/logo` : null,
    };
  });

  app.get('/public/schools/:slug/logo', { config: limit, schema: { params: slugParams } }, async (req, reply) => {
    const f = (await raw('SELECT * FROM app.public_school_logo($1)', [req.params.slug])).rows[0];
    if (!f) throw E.notFound('Logo');
    if (config.storage.driver === 's3') return reply.redirect(driver().signedUrl(f.storage_key, 'logo', f.mime), 302);
    reply.header('Content-Type', f.mime).header('Content-Length', f.size_bytes)
      .header('Content-Disposition', 'inline; filename="logo"')
      .header('Content-Security-Policy', "default-src 'none'; sandbox").header('X-Content-Type-Options', 'nosniff')
      .header('Cache-Control', 'public, max-age=300').header('ETag', `"${f.sha256.slice(0, 32)}"`)
      .header('Cross-Origin-Resource-Policy', config.corp);
    if (req.headers['if-none-match'] === `"${f.sha256.slice(0, 32)}"`) return reply.code(304).send();
    return reply.send(await driver().stream(f.storage_key));
  });
};
