'use strict';
// "Sign in as" — the school owner looks at and works in the app exactly as another member of the SAME school sees it,
// to help them or check their work. Rules (all enforced here and in the auth plugin):
//   • only holders of users.impersonate (school owners by default), on their own session, with two-step sign-in verified
//     where the platform requires it; never as themselves, another owner/impersonator, or a platform administrator;
//   • a written reason and a time limit (5–60 minutes); the session token is renewed at start and stop;
//   • while acting: no security settings, no switching school, no private messages, no account/role management;
//   • everything done is recorded in the audit log under the OWNER's name "(as …)", a security event is raised and the
//     person is notified that the owner signed in as them.
const config = require('../config');
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, str, uuid } = require('../lib/schema');
const { ctx } = require('../auth/plugin');
const S = require('../auth/sessions');
const { audit, securityEvent } = require('../audit/audit');
const { notify } = require('../services/notify');

module.exports = async function actAsRoutes(app) {
  const A = app.authenticate;
  const own = (req) => ({ schoolId: req.auth.schoolId, userId: req.auth.realUserId || req.auth.userId });

  app.get('/auth/act-as/candidates', { onRequest: [A, app.perm('users.impersonate')], schema: { querystring: obj({ q: { type: 'string', maxLength: 80 } }) } }, async (req) => withTx(ctx(req), async (c) => {
    const p = [req.auth.userId]; let w = '';
    if (req.query.q) { p.push(`%${req.query.q.replace(/[\\%_]/g, (m) => '\\' + m)}%`); w = `AND (u.full_name ILIKE $2 OR u.login_id ILIKE $2)`; }
    const rows = (await c.query(`SELECT u.id, u.login_id, u.full_name, array_agg(DISTINCT r.name ORDER BY r.name) AS roles,
        bool_or(r.key = 'school_owner' OR rp.permission_key IS NOT NULL) AS protected
      FROM users u JOIN school_memberships m ON m.user_id = u.id AND m.status = 'active'
      JOIN user_roles ur ON ur.user_id = u.id JOIN roles r ON r.id = ur.role_id
      LEFT JOIN role_permissions rp ON rp.role_id = r.id AND rp.permission_key = 'users.impersonate'
      WHERE u.id <> $1 AND u.status = 'active' AND NOT u.is_platform_admin ${w}
      GROUP BY u.id ORDER BY u.full_name LIMIT 200`, p)).rows;
    return { items: rows.filter((r) => !r.protected).map(({ protected: _p, ...r }) => r) };
  }));

  app.post('/auth/act-as', {
    onRequest: [A, app.perm('users.impersonate')], config: { rateLimit: { max: 10, timeWindow: '10 minutes' } },
    schema: { body: obj({ userId: uuid, reason: str(300, 5), minutes: { type: 'integer', minimum: 5, maximum: 60, default: 30 } }, ['userId', 'reason']) },
  }, async (req, reply) => {
    if (req.auth.actingBy) throw E.forbidden('You are already signed in as someone else.');
    if (config.isProdLike && req.auth.mfaState !== 'verified') throw E.forbidden('Turn on two-step sign-in for your account before signing in as someone else.');
    const b = req.body; const minutes = b.minutes || 30;
    if (b.userId === req.auth.userId) throw E.bad('You are already yourself.');
    const out = await withTx(own(req), async (c) => {
      const t = (await c.query(`SELECT u.id, u.login_id, u.full_name, u.status, u.is_platform_admin, m.status AS membership,
          EXISTS (SELECT 1 FROM user_roles ur JOIN roles r ON r.id = ur.role_id LEFT JOIN role_permissions rp ON rp.role_id = r.id AND rp.permission_key = 'users.impersonate'
            WHERE ur.user_id = u.id AND (r.key = 'school_owner' OR rp.permission_key IS NOT NULL)) AS protected
        FROM users u LEFT JOIN school_memberships m ON m.user_id = u.id AND m.school_id = $2 WHERE u.id = $1`, [b.userId, req.auth.schoolId])).rows[0];
      if (!t || t.membership !== 'active') throw E.notFound('Person');
      if (t.status !== 'active') throw E.bad('This account is turned off.');
      if (t.is_platform_admin || t.protected) throw E.forbidden('You cannot sign in as another owner or someone who can also sign in as others.');
      const r = await c.query(`UPDATE sessions SET acting_user_id = $2, acting_expires_at = now() + make_interval(mins => $3), acting_reason = $4, acting_started_at = now()
        WHERE id = $1 AND revoked_at IS NULL RETURNING acting_expires_at`, [req.auth.sessionId, t.id, minutes, b.reason.trim()]);
      if (!r.rowCount) throw E.unauth();
      S.setCookie(reply, await S.rotate(c, req.auth.sessionId));
      await audit(c, req, 'auth.act_as_started', { type: 'user', id: t.id, meta: { as: t.login_id, minutes, reason: b.reason.trim() } });
      await notify(c, req.auth.schoolId, [t.id], { kind: 'security', title: 'The school owner signed in as you', body: `${req.auth.fullName} signed in as you for up to ${minutes} minutes. Reason: ${b.reason.trim()}`, link: '#/' });
      return { as: { id: t.id, loginId: t.login_id, fullName: t.full_name }, expiresAt: r.rows[0].acting_expires_at };
    });
    await securityEvent({ schoolId: req.auth.schoolId, userId: req.auth.userId, kind: 'impersonation_started', severity: 'medium', detail: { as: out.as.loginId, minutes }, ip: req.ip });
    return { ok: true, ...out };
  });

  app.post('/auth/act-as/stop', { onRequest: [A] }, async (req, reply) => {
    const real = req.auth.realUserId || req.auth.userId;
    return withTx({ schoolId: req.auth.schoolId, userId: real }, async (c) => {
      const s = (await c.query('SELECT acting_user_id FROM sessions WHERE id = $1 FOR UPDATE', [req.auth.sessionId])).rows[0];
      if (!s || !s.acting_user_id) return { ok: true, wasActing: false };
      await c.query('UPDATE sessions SET acting_user_id = NULL, acting_expires_at = NULL, acting_reason = NULL, acting_started_at = NULL WHERE id = $1', [req.auth.sessionId]);
      S.setCookie(reply, await S.rotate(c, req.auth.sessionId));
      await audit(c, { ip: req.ip, headers: req.headers, auth: { ...req.auth, actingBy: null, userId: real, loginId: req.auth.actingBy ? req.auth.actingBy.loginId : req.auth.loginId } }, 'auth.act_as_stopped', { type: 'user', id: s.acting_user_id });
      return { ok: true, wasActing: true };
    });
  });
};
