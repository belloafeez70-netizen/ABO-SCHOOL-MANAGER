'use strict';
// CBT / Online Examination — exams, candidates, taking, marking, release and the push into the existing results.
// Security: tenant isolation by RLS on every table; staff see only exams in their scope (exam officers/admins see
// all, teachers see exams they created or for classes/subjects they teach); students only reach their own
// attempts; answer keys, timers and scores are server-side only.
const crypto = require('node:crypto');
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, str, uuid, idParams, dateTime } = require('../lib/schema');
const { ctx } = require('../auth/plugin');
const { audit } = require('../audit/audit');
const { notify, enqueue } = require('../services/notify');
const { sessionKey } = require('../lib/ratekey');
const pw = require('../security/passwords');
const R = require('../services/results');
const G = require('../services/grading');
const { shuffle, gradeAttempt, finalize, isManual, candidateIds, isCandidate, lifecycle } = require('../services/cbt');
const Q = require('../services/cbt_questions');

const perSession = (max, win = '1 minute') => ({ rateLimit: { max, timeWindow: win, keyGenerator: sessionKey } });
const optUuid = { type: ['string', 'null'], format: 'uuid' };
const examFields = {
  title: str(160, 2), instructions: { type: ['string', 'null'], maxLength: 4000 }, category: { enum: ['test', 'exam', 'practice', 'assignment', 'ca', 'mock'] },
  subjectId: optUuid, classId: optUuid, termId: optUuid, sessionId: optUuid,
  durationMinutes: { type: 'integer', minimum: 1, maximum: 600 }, startsAt: dateTime, endsAt: dateTime, maxAttempts: { type: 'integer', minimum: 1, maximum: 20 },
  shuffleQuestions: { type: 'boolean' }, shuffleOptions: { type: 'boolean' }, showResult: { type: 'boolean' }, passMark: { type: 'number', minimum: 0, maximum: 100 },
  allowBackNav: { type: 'boolean' }, allowReview: { type: 'boolean' }, showAnswers: { type: 'boolean' }, allowResume: { type: 'boolean' }, fullscreen: { type: 'boolean' }, autosave: { type: 'boolean' },
  accessCode: { type: ['string', 'null'], pattern: '^[A-Za-z0-9-]{4,20}$' },
  scoreComponent: { type: ['string', 'null'], pattern: '^[a-z0-9_]{1,20}$' }, scorePolicy: { enum: ['best', 'latest'] },
};
const examBody = obj(examFields);
const COLS = { title: 'title', instructions: 'instructions', category: 'category', subjectId: 'subject_id', classId: 'class_id', termId: 'term_id', sessionId: 'session_id',
  durationMinutes: 'duration_minutes', startsAt: 'starts_at', endsAt: 'ends_at', maxAttempts: 'max_attempts', shuffleQuestions: 'shuffle_questions', shuffleOptions: 'shuffle_options',
  showResult: 'show_result', passMark: 'pass_mark', allowBackNav: 'allow_back_nav', allowReview: 'allow_review', showAnswers: 'show_answers', allowResume: 'allow_resume',
  fullscreen: 'fullscreen', autosave: 'autosave', scoreComponent: 'score_component', scorePolicy: 'score_policy' };
const LIVE_EDITABLE = new Set(['endsAt', 'startsAt', 'showResult', 'showAnswers', 'instructions']);   // allowed after publish
const DEFAULTS = { durationMinutes: 30, passMark: 50, maxAttempts: 1, shuffleQuestions: true, shuffleOptions: true, showResult: false, showAnswers: false, allowBackNav: true, allowReview: true, allowResume: true, fullscreen: false, autosave: true };

// ── scope: who may see which exam (inside the tenant) ──
const FULL = (req) => req.can('cbt.publish') || !!req.auth.support;
function scopeSql(req, p, a = 'e') {
  if (FULL(req)) return 'TRUE';
  p.push(req.auth.userId); const u = p.length; p.push(req.auth.staffId || null); const s = p.length;
  return `(${a}.created_by = $${u} OR EXISTS (SELECT 1 FROM teacher_class_access t WHERE t.staff_id = $${s}::uuid AND t.class_id = ${a}.class_id AND (t.subject_id IS NULL OR ${a}.subject_id IS NULL OR t.subject_id = ${a}.subject_id)))`;
}
async function loadExam(c, req, id, { lock = false } = {}) {
  const p = [id]; const sc = scopeSql(req, p);
  const e = (await c.query(`SELECT e.* FROM cbt_exams e WHERE e.id = $1 AND ${sc} ${lock ? 'FOR UPDATE OF e' : ''}`, p)).rows[0];
  if (!e) throw E.notFound('Exam');
  return e;
}
const publicExam = (e) => { const { access_code_hash: h, ...rest } = e; return { ...rest, has_access_code: !!h, lifecycle: lifecycle(e) }; };
async function cbtDefaults(c) { const r = (await c.query('SELECT cbt FROM school_settings LIMIT 1')).rows[0]; return { ...DEFAULTS, ...((r && r.cbt) || {}) }; }
async function bandsForExam(c, e) {
  const st = await R.settings(c);
  const sec = e.class_id ? ((await c.query('SELECT section FROM classes WHERE id = $1', [e.class_id])).rows[0] || {}).section : null;
  const type = sec || ((await c.query('SELECT school_type FROM schools LIMIT 1')).rows[0].school_type === 'secondary' ? 'secondary' : 'primary');
  return R.bandsFor(st, type);
}
async function currentClassOf(c, studentId) {
  const r = (await c.query(`SELECT e.class_id FROM student_enrollments e JOIN academic_sessions s ON s.id = e.session_id AND s.is_current WHERE e.student_id = $1 AND e.status = 'active'`, [studentId])).rows[0];
  return r ? r.class_id : null;
}
async function ownAttempt(c, req, id, lock = false) {
  const at = (await c.query(`SELECT a.*, e.title, e.show_result, e.show_answers, e.instructions, e.allow_back_nav, e.allow_review, e.fullscreen, e.autosave, e.allow_resume, e.subject_id, e.class_id AS exam_class_id, e.pass_mark
    FROM cbt_attempts a JOIN cbt_exams e ON e.id = a.exam_id WHERE a.id = $1 ${lock ? 'FOR UPDATE OF a' : ''}`, [id])).rows[0];
  if (!at || at.student_id !== req.auth.studentId) throw E.notFound('Attempt');     // BOLA guard
  return at;
}
// the candidate's paper: questions + options WITHOUT any key, saved answers, flags and server clock
async function paper(c, at) {
  const qs = (await c.query('SELECT id, type, text, image_file_id, marks FROM cbt_questions WHERE id = ANY($1::uuid[])', [at.question_order])).rows;
  const qmap = new Map(qs.map((q) => [q.id, q]));
  const opts = (await c.query('SELECT id, question_id, text, image_file_id FROM cbt_options WHERE question_id = ANY($1::uuid[])', [at.question_order])).rows;   // NOTE: no is_correct
  const byQ = new Map(); for (const o of opts) { if (!byQ.has(o.question_id)) byQ.set(o.question_id, new Map()); byQ.get(o.question_id).set(o.id, o); }
  const saved = new Map((await c.query('SELECT question_id, option_id, option_ids, text_answer, flagged FROM cbt_answers WHERE attempt_id = $1', [at.id])).rows.map((r) => [r.question_id, r]));
  const meta = (await c.query(`SELECT e.title, e.instructions, e.allow_back_nav, e.allow_review, e.fullscreen, e.autosave, s.name AS subject, cl.display_name AS class_name,
      st.first_name || ' ' || st.last_name AS student_name, st.admission_no, st.passport_file_id, sc.name AS school_name, sc.logo_file_id
    FROM cbt_exams e LEFT JOIN subjects s ON s.id = e.subject_id LEFT JOIN classes cl ON cl.id = e.class_id JOIN students st ON st.id = $2 JOIN schools sc ON sc.id = e.school_id WHERE e.id = $1`, [at.exam_id, at.student_id])).rows[0];
  return {
    attemptId: at.id, examId: at.exam_id, title: meta.title, instructions: meta.instructions, subject: meta.subject, className: meta.class_name,
    student: { name: meta.student_name, admissionNo: meta.admission_no }, school: { name: meta.school_name, logoFileId: meta.logo_file_id },
    settings: { allowBackNav: meta.allow_back_nav, allowReview: meta.allow_review, fullscreen: meta.fullscreen, autosave: meta.autosave },
    deadlineAt: at.deadline_at, startedAt: at.started_at, serverNow: new Date().toISOString(), status: at.status, furthestIndex: at.furthest_index,
    questions: at.question_order.map((qid, i) => {
      const q = qmap.get(qid); const om = byQ.get(qid) || new Map(); const order = (at.option_order[qid] || [...om.keys()]);
      const s = saved.get(qid);
      return { n: i + 1, id: q.id, type: q.type, text: q.text, imageFileId: q.image_file_id, marks: q.marks,
        options: order.map((oid) => om.get(oid)).filter(Boolean).map((o) => ({ id: o.id, text: o.text, imageFileId: o.image_file_id })),
        answer: s ? { optionId: s.option_id, optionIds: s.option_ids || [], text: s.text_answer } : null, flagged: !!(s && s.flagged) };
    }),
  };
}
async function validateForPublish(c, e) {
  const problems = [];
  const n = (await c.query('SELECT count(*)::int AS n FROM cbt_questions WHERE exam_id = $1', [e.id])).rows[0].n;
  if (!n) problems.push('Add at least one question.');
  if (e.ends_at && new Date(e.ends_at) <= new Date()) problems.push('The closing date/time is in the past.');
  if ((await candidateIds(c, e)).length === 0) problems.push('Add candidates (a class or specific students).');
  if (e.score_component) {
    if (!e.subject_id || !e.class_id || !e.term_id) problems.push('Exams that feed the result sheet need a subject, class and term.');
    const comps = (await R.settings(c)).assessment_components.map((x) => x.key);
    if (!comps.includes(e.score_component)) problems.push(`“${e.score_component}” is not one of the school's assessment components (${comps.join(', ')}).`);
  }
  return { questions: n, problems };
}
// pick each candidate's counted result (best / latest finalised, non-void)
async function countedResults(c, e) {
  return (await c.query(`SELECT DISTINCT ON (r.student_id) r.*, a.attempt_no, a.started_at, a.submitted_at, a.status AS attempt_status
    FROM cbt_results r JOIN cbt_attempts a ON a.id = r.attempt_id AND a.status <> 'void' WHERE r.exam_id = $1
    ORDER BY r.student_id, ${e.score_policy === 'latest' ? 'a.attempt_no DESC' : 'r.percentage DESC, a.attempt_no ASC'}`, [e.id])).rows;
}

module.exports = async function cbtRoutes(app) {
  const A = app.authenticate;

  // ───────── staff: exams ─────────
  app.get('/cbt/exams', {
    onRequest: [A, app.perm('cbt.view')],
    schema: { querystring: obj({ status: { enum: ['all', 'draft', 'scheduled', 'active', 'completed'] }, q: { type: 'string', maxLength: 80 }, subjectId: uuid, classId: uuid, termId: uuid, page: { type: 'integer', minimum: 1, maximum: 10000 }, pageSize: { type: 'integer', minimum: 1, maximum: 100 } }) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const p = []; const w = [scopeSql(req, p)]; const q = req.query;
    if (q.q) { p.push(`%${q.q.toLowerCase().replace(/[\\%_]/g, (m) => '\\' + m)}%`); w.push(`lower(e.title) LIKE $${p.length}`); }
    for (const [k, col] of [['subjectId', 'subject_id'], ['classId', 'class_id'], ['termId', 'term_id']]) if (q[k]) { p.push(q[k]); w.push(`e.${col} = $${p.length}`); }
    if (q.status === 'draft') w.push("e.status = 'draft'");
    if (q.status === 'scheduled') w.push("e.status = 'published' AND e.starts_at > now()");
    if (q.status === 'active') w.push("e.status = 'published' AND (e.starts_at IS NULL OR e.starts_at <= now()) AND (e.ends_at IS NULL OR e.ends_at > now())");
    if (q.status === 'completed') w.push("(e.status = 'closed' OR (e.status = 'published' AND e.ends_at <= now()))");
    const where = 'WHERE ' + w.join(' AND ');
    const size = q.pageSize || 50; const pg = q.page || 1;
    const total = (await c.query(`SELECT count(*)::int AS n FROM cbt_exams e ${where}`, p)).rows[0].n;
    const rows = (await c.query(`SELECT e.id, e.title, e.category, e.status, e.duration_minutes, e.starts_at, e.ends_at, e.max_attempts, e.score_component, e.created_at, e.published_at,
        cl.display_name AS class_name, s.name AS subject, t.name AS term,
        (SELECT count(*)::int FROM cbt_questions q WHERE q.exam_id = e.id) AS questions, (SELECT COALESCE(sum(q.marks), 0) FROM cbt_questions q WHERE q.exam_id = e.id) AS total_marks,
        (SELECT count(*)::int FROM cbt_attempts a WHERE a.exam_id = e.id AND a.status <> 'void') AS attempts,
        COALESCE(NULLIF((SELECT count(*)::int FROM cbt_exam_candidates x WHERE x.exam_id = e.id), 0),
          (SELECT count(*)::int FROM student_enrollments en JOIN academic_sessions se ON se.id = en.session_id AND se.is_current WHERE en.class_id = e.class_id AND en.status = 'active')) AS candidates,
        (SELECT round(avg(r.percentage), 1) FROM cbt_results r JOIN cbt_attempts a ON a.id = r.attempt_id AND a.status <> 'void' WHERE r.exam_id = e.id) AS average
      FROM cbt_exams e LEFT JOIN classes cl ON cl.id = e.class_id LEFT JOIN subjects s ON s.id = e.subject_id LEFT JOIN terms t ON t.id = e.term_id
      ${where} ORDER BY COALESCE(e.starts_at, e.created_at) DESC LIMIT ${size} OFFSET ${(pg - 1) * size}`, p)).rows;
    for (const r of rows) r.lifecycle = lifecycle(r);
    return { items: rows, total, page: pg, pages: Math.max(1, Math.ceil(total / size)) };
  }));

  app.post('/cbt/exams', { onRequest: [A, app.perm('cbt.create')], schema: { body: { ...examBody, required: ['title'] } } }, async (req) => withTx(ctx(req), async (c) => {
    const b = { ...(await cbtDefaults(c)), ...req.body };
    for (const [t, id, label] of [['subjects', b.subjectId, 'Subject'], ['classes', b.classId, 'Class'], ['terms', b.termId, 'Term'], ['academic_sessions', b.sessionId, 'Session']]) {
      if (id && !(await c.query(`SELECT 1 FROM ${t} WHERE id = $1`, [id])).rowCount) throw E.notFound(label);
    }
    if (b.startsAt && b.endsAt && new Date(b.endsAt) <= new Date(b.startsAt)) throw E.bad('The closing time must be after the opening time.', { field: 'endsAt' });
    const cols = ['school_id', 'created_by']; const vals = [req.auth.schoolId, req.auth.userId];
    for (const [k, col] of Object.entries(COLS)) if (b[k] !== undefined && b[k] !== null) { cols.push(col); vals.push(b[k]); }
    if (req.body.accessCode) { cols.push('access_code_hash'); vals.push(await pw.hash(req.body.accessCode.toUpperCase())); }
    const r = (await c.query(`INSERT INTO cbt_exams (${cols.join(', ')}) VALUES (${vals.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING id, title, status`, vals)).rows[0];
    await audit(c, req, 'cbt.exam_created', { type: 'cbt_exam', id: r.id, meta: { title: r.title } });
    return r;
  }));

  app.get('/cbt/exams/:id', { onRequest: [A, app.perm('cbt.view')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const e = await loadExam(c, req, req.params.id);
    const questions = await Q.loadQuestions(c, 'q.exam_id = $1 ORDER BY q.position, q.created_at', [e.id]);
    const meta = (await c.query(`SELECT s.name AS subject, cl.display_name AS class_name, t.name AS term, se.name AS session FROM cbt_exams e LEFT JOIN subjects s ON s.id = e.subject_id
      LEFT JOIN classes cl ON cl.id = e.class_id LEFT JOIN terms t ON t.id = e.term_id LEFT JOIN academic_sessions se ON se.id = COALESCE(e.session_id, t.session_id) WHERE e.id = $1`, [e.id])).rows[0];
    const readiness = e.status === 'draft' ? await validateForPublish(c, e) : { questions: questions.length, problems: [] };
    return { exam: { ...publicExam(e), ...meta }, questions, totalMarks: questions.reduce((t, q) => t + Number(q.marks), 0), candidates: (await candidateIds(c, e)).length,
      explicitCandidates: (await c.query('SELECT count(*)::int AS n FROM cbt_exam_candidates WHERE exam_id = $1', [e.id])).rows[0].n, problems: readiness.problems };
  }));

  app.patch('/cbt/exams/:id', { onRequest: [A, app.perm('cbt.update')], schema: { params: idParams, body: examBody } }, async (req) => withTx(ctx(req), async (c) => {
    const e = await loadExam(c, req, req.params.id, { lock: true });
    const b = req.body;
    if (e.status === 'closed') throw E.locked('This exam is closed.');
    if (e.status !== 'draft' && !Object.keys(b).every((k) => LIVE_EDITABLE.has(k))) throw E.locked('Published exams can only have their schedule, instructions or result visibility changed.');
    const sets = []; const p = [e.id];
    for (const [k, col] of Object.entries(COLS)) if (b[k] !== undefined) { p.push(b[k]); sets.push(`${col} = $${p.length}`); }
    if (b.accessCode !== undefined) { p.push(b.accessCode ? await pw.hash(b.accessCode.toUpperCase()) : null); sets.push(`access_code_hash = $${p.length}`); }
    if (!sets.length) throw E.bad('Nothing to update.');
    const u = (await c.query(`UPDATE cbt_exams SET ${sets.join(', ')} WHERE id = $1 RETURNING starts_at, ends_at`, p)).rows[0];
    if (u.starts_at && u.ends_at && new Date(u.ends_at) <= new Date(u.starts_at)) throw E.bad('The closing time must be after the opening time.', { field: 'endsAt' });
    await audit(c, req, 'cbt.exam_updated', { type: 'cbt_exam', id: e.id, meta: { fields: Object.keys(b).map((k) => (k === 'accessCode' ? 'accessCode(set)' : k)) } });
    return { ok: true };
  }));

  app.delete('/cbt/exams/:id', { onRequest: [A, app.perm('cbt.update')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const e = await loadExam(c, req, req.params.id, { lock: true });
    if (e.status !== 'draft') throw E.locked('Only draft exams can be deleted. Close published exams instead.');
    if ((await c.query('SELECT 1 FROM cbt_attempts WHERE exam_id = $1 LIMIT 1', [e.id])).rowCount) throw E.conflict('This exam already has attempts.');
    await c.query('DELETE FROM cbt_exams WHERE id = $1', [e.id]);
    await audit(c, req, 'cbt.exam_deleted', { type: 'cbt_exam', id: e.id, meta: { title: e.title } });
    return { ok: true };
  }));

  // ── exam questions ──
  app.post('/cbt/exams/:id/questions', { onRequest: [A, app.perm('cbt.update', 'cbt.create')], schema: { params: idParams, body: Q.questionBody } }, async (req) => withTx(ctx(req), async (c) => {
    const e = await loadExam(c, req, req.params.id, { lock: true });
    if (e.status !== 'draft') throw E.locked('Questions cannot change after an exam is published.');
    const pos = (await c.query('SELECT COALESCE(max(position), 0) + 1 AS p FROM cbt_questions WHERE exam_id = $1', [e.id])).rows[0].p;
    const id = await Q.insertQuestion(c, req.auth.schoolId, req.auth.userId, e.id, { subjectId: e.subject_id, classId: e.class_id, ...req.body }, pos);
    await audit(c, req, 'cbt.question_added', { type: 'cbt_question', id, meta: { exam: e.id, type: req.body.type } });
    return { id };
  }));
  app.patch('/cbt/questions/:id', { onRequest: [A, app.perm('cbt.update')], schema: { params: idParams, body: Q.questionBody } }, async (req) => withTx(ctx(req), async (c) => {
    const q = (await c.query('SELECT q.id, q.exam_id FROM cbt_questions q WHERE q.id = $1 AND q.exam_id IS NOT NULL', [req.params.id])).rows[0];
    if (!q) throw E.notFound('Question');
    const e = await loadExam(c, req, q.exam_id, { lock: true });
    if (e.status !== 'draft') throw E.locked('Questions cannot change after an exam is published.');
    await Q.updateQuestion(c, req.auth.schoolId, req.auth.userId, q.id, req.body);
    await audit(c, req, 'cbt.question_edited', { type: 'cbt_question', id: q.id, meta: { exam: e.id } });
    return { ok: true };
  }));
  app.delete('/cbt/questions/:id', { onRequest: [A, app.perm('cbt.update')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const q = (await c.query('SELECT q.id, q.exam_id FROM cbt_questions q WHERE q.id = $1', [req.params.id])).rows[0];
    if (!q) throw E.notFound('Question');
    if (q.exam_id) { const e = await loadExam(c, req, q.exam_id, { lock: true }); if (e.status !== 'draft') throw E.locked('Questions cannot change after an exam is published.'); }
    await c.query('DELETE FROM cbt_questions WHERE id = $1', [q.id]);
    await audit(c, req, 'cbt.question_deleted', { type: 'cbt_question', id: q.id, meta: { exam: q.exam_id } });
    return { ok: true };
  }));
  app.post('/cbt/exams/:id/from-bank', { onRequest: [A, app.perm('cbt.update')], schema: { params: idParams, body: obj({ questionIds: { type: 'array', items: uuid, minItems: 1, maxItems: 200 } }, ['questionIds']) } }, async (req) => withTx(ctx(req), async (c) => {
    const e = await loadExam(c, req, req.params.id, { lock: true });
    if (e.status !== 'draft') throw E.locked('Questions cannot change after an exam is published.');
    const added = await Q.copyToExam(c, req.auth.schoolId, req.auth.userId, e.id, req.body.questionIds);
    await audit(c, req, 'cbt.bank_imported', { type: 'cbt_exam', id: e.id, meta: { count: added } });
    return { added };
  }));
  // automatic selection: e.g. 10 easy + 20 medium + 10 hard, or per topic — random, from ACTIVE bank questions
  app.post('/cbt/exams/:id/generate', {
    onRequest: [A, app.perm('cbt.update')],
    schema: { params: idParams, body: obj({ rules: { type: 'array', minItems: 1, maxItems: 20, items: obj({ count: { type: 'integer', minimum: 1, maximum: 200 }, difficulty: { enum: ['easy', 'medium', 'hard'] }, topic: { type: ['string', 'null'], maxLength: 120 }, type: { enum: Q.TYPES } }, ['count']) },
      subjectId: optUuid, classId: optUuid, sameClassOnly: { type: 'boolean' } }, ['rules']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const e = await loadExam(c, req, req.params.id, { lock: true });
    if (e.status !== 'draft') throw E.locked('Questions cannot change after an exam is published.');
    const subjectId = req.body.subjectId || e.subject_id; const classId = req.body.classId || e.class_id;
    const used = new Set((await c.query('SELECT source_question_id FROM cbt_questions WHERE exam_id = $1 AND source_question_id IS NOT NULL', [e.id])).rows.map((r) => r.source_question_id));
    const picked = []; const short = [];
    for (const rule of req.body.rules) {
      const p = []; const w = ["q.exam_id IS NULL", "q.status = 'active'"];
      if (subjectId) { p.push(subjectId); w.push(`q.subject_id = $${p.length}`); }
      if (classId && req.body.sameClassOnly) { p.push(classId); w.push(`q.class_id = $${p.length}`); }
      if (rule.difficulty) { p.push(rule.difficulty); w.push(`q.difficulty = $${p.length}`); }
      if (rule.topic) { p.push(rule.topic.trim().toLowerCase()); w.push(`lower(q.topic) = $${p.length}`); }
      if (rule.type) { p.push(rule.type); w.push(`q.type = $${p.length}`); }
      const pool = (await c.query(`SELECT q.id FROM cbt_questions q WHERE ${w.join(' AND ')}`, p)).rows.map((r) => r.id).filter((id) => !used.has(id) && !picked.includes(id));
      if (pool.length < rule.count) short.push(`${rule.count} ${[rule.difficulty, rule.topic, rule.type].filter(Boolean).join(' · ') || 'questions'} requested, only ${pool.length} available`);
      picked.push(...shuffle(pool).slice(0, rule.count));
    }
    if (short.length) throw E.bad(`Not enough questions in the bank: ${short.join('; ')}.`, { shortfall: short });
    const added = await Q.copyToExam(c, req.auth.schoolId, req.auth.userId, e.id, picked);
    await audit(c, req, 'cbt.questions_generated', { type: 'cbt_exam', id: e.id, meta: { rules: req.body.rules, added } });
    return { added };
  }));
  app.put('/cbt/exams/:id/order', { onRequest: [A, app.perm('cbt.update')], schema: { params: idParams, body: obj({ questionIds: { type: 'array', items: uuid, minItems: 1, maxItems: 500 } }, ['questionIds']) } }, async (req) => withTx(ctx(req), async (c) => {
    const e = await loadExam(c, req, req.params.id, { lock: true });
    if (e.status !== 'draft') throw E.locked('Questions cannot change after an exam is published.');
    const cur = (await c.query('SELECT id FROM cbt_questions WHERE exam_id = $1', [e.id])).rows.map((r) => r.id);
    const ids = req.body.questionIds;
    if (ids.length !== cur.length || new Set(ids).size !== ids.length || !ids.every((id) => cur.includes(id))) throw E.bad('Send every question of this exam exactly once.');
    await c.query('UPDATE cbt_questions q SET position = x.n FROM unnest($1::uuid[]) WITH ORDINALITY AS x(id, n) WHERE q.id = x.id AND q.exam_id = $2', [ids, e.id]);
    return { ok: true };
  }));

  // ── candidates ──
  app.get('/cbt/exams/:id/candidates', { onRequest: [A, app.perm('cbt.view')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const e = await loadExam(c, req, req.params.id);
    const explicit = (await c.query('SELECT count(*)::int AS n FROM cbt_exam_candidates WHERE exam_id = $1', [e.id])).rows[0].n > 0;
    const ids = await candidateIds(c, e);
    const rows = (await c.query(`SELECT s.id, s.first_name, s.last_name, s.admission_no, (s.user_id IS NOT NULL) AS has_login,
        (SELECT cl.display_name FROM student_enrollments en JOIN academic_sessions se ON se.id = en.session_id AND se.is_current JOIN classes cl ON cl.id = en.class_id WHERE en.student_id = s.id AND en.status = 'active' LIMIT 1) AS class_name,
        (SELECT count(*)::int FROM cbt_attempts a WHERE a.exam_id = $2 AND a.student_id = s.id AND a.status <> 'void') AS attempts,
        (SELECT a.status FROM cbt_attempts a WHERE a.exam_id = $2 AND a.student_id = s.id AND a.status <> 'void' ORDER BY a.attempt_no DESC LIMIT 1) AS last_status,
        (SELECT max(r.percentage) FROM cbt_results r JOIN cbt_attempts a ON a.id = r.attempt_id AND a.status <> 'void' WHERE r.exam_id = $2 AND r.student_id = s.id) AS best_percentage
      FROM students s WHERE s.id = ANY($1::uuid[]) ORDER BY s.last_name, s.first_name`, [ids, e.id])).rows;
    return { mode: explicit ? 'selected' : e.class_id ? 'class' : 'none', items: rows };
  }));
  app.post('/cbt/exams/:id/candidates', {
    onRequest: [A, app.perm('cbt.update')],
    schema: { params: idParams, body: obj({ classIds: { type: 'array', items: uuid, maxItems: 50 }, studentIds: { type: 'array', items: uuid, maxItems: 2000 } }) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const e = await loadExam(c, req, req.params.id, { lock: true });
    if (e.status === 'closed') throw E.locked('This exam is closed.');
    const ids = new Set(req.body.studentIds || []);
    // switching from class-wide to explicit: keep the current class candidates so nobody is dropped silently
    const explicitNow = (await c.query('SELECT count(*)::int AS n FROM cbt_exam_candidates WHERE exam_id = $1', [e.id])).rows[0].n;
    if (!explicitNow && e.class_id) for (const s of await candidateIds(c, e)) ids.add(s);
    for (const cid of req.body.classIds || []) {
      if (!(await c.query('SELECT 1 FROM classes WHERE id = $1', [cid])).rowCount) throw E.notFound('Class');
      for (const r of (await c.query(`SELECT en.student_id FROM student_enrollments en JOIN academic_sessions se ON se.id = en.session_id AND se.is_current JOIN students s ON s.id = en.student_id AND s.deleted_at IS NULL
        WHERE en.class_id = $1 AND en.status = 'active'`, [cid])).rows) ids.add(r.student_id);
    }
    if (!ids.size) throw E.bad('Choose at least one class or student.');
    const found = (await c.query('SELECT id FROM students WHERE id = ANY($1::uuid[]) AND deleted_at IS NULL', [[...ids]])).rows.map((r) => r.id);
    if (req.body.studentIds && req.body.studentIds.some((id) => !found.includes(id))) throw E.notFound('Student');
    const ins = await c.query(`INSERT INTO cbt_exam_candidates (school_id, exam_id, student_id, added_by) SELECT $1, $2, x, $3 FROM unnest($4::uuid[]) AS x ON CONFLICT DO NOTHING RETURNING student_id`,
      [req.auth.schoolId, e.id, req.auth.userId, found]);
    if (e.status === 'published' && ins.rowCount) {
      const users = (await c.query('SELECT user_id FROM students WHERE id = ANY($1::uuid[]) AND user_id IS NOT NULL', [ins.rows.map((r) => r.student_id)])).rows.map((r) => r.user_id);
      await notify(c, req.auth.schoolId, users, { kind: 'cbt', title: `You have been added to the CBT: ${e.title}`, link: '#/my-cbt' });
    }
    await audit(c, req, 'cbt.candidates_added', { type: 'cbt_exam', id: e.id, meta: { added: ins.rowCount, classes: (req.body.classIds || []).length } });
    return { added: ins.rowCount, total: (await c.query('SELECT count(*)::int AS n FROM cbt_exam_candidates WHERE exam_id = $1', [e.id])).rows[0].n };
  }));
  app.delete('/cbt/exams/:id/candidates', { onRequest: [A, app.perm('cbt.update')], schema: { params: idParams, body: obj({ studentIds: { type: 'array', items: uuid, minItems: 1, maxItems: 2000 } }, ['studentIds']) } }, async (req) => withTx(ctx(req), async (c) => {
    const e = await loadExam(c, req, req.params.id, { lock: true });
    if (e.status === 'closed') throw E.locked('This exam is closed.');
    const explicitNow = (await c.query('SELECT count(*)::int AS n FROM cbt_exam_candidates WHERE exam_id = $1', [e.id])).rows[0].n;
    if (!explicitNow && e.class_id) {          // materialise the class list, then remove
      const all = await candidateIds(c, e);
      await c.query('INSERT INTO cbt_exam_candidates (school_id, exam_id, student_id, added_by) SELECT $1, $2, x, $3 FROM unnest($4::uuid[]) AS x ON CONFLICT DO NOTHING', [req.auth.schoolId, e.id, req.auth.userId, all]);
    }
    const r = await c.query('DELETE FROM cbt_exam_candidates WHERE exam_id = $1 AND student_id = ANY($2::uuid[])', [e.id, req.body.studentIds]);
    const left = (await c.query('SELECT count(*)::int AS n FROM cbt_exam_candidates WHERE exam_id = $1', [e.id])).rows[0].n;
    if (!left) throw E.bad('An exam must keep at least one candidate. Add others before removing the last one.');
    await audit(c, req, 'cbt.candidates_removed', { type: 'cbt_exam', id: e.id, meta: { removed: r.rowCount } });
    return { removed: r.rowCount, total: left };
  }));

  // ── publish / schedule / close ──
  app.post('/cbt/exams/:id/publish', { onRequest: [A, app.perm('cbt.publish')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const e = await loadExam(c, req, req.params.id, { lock: true });
    if (e.status !== 'draft') throw E.conflict('Only draft exams can be published.');
    const v = await validateForPublish(c, e);
    if (v.problems.length) throw E.bad(`This exam is not ready: ${v.problems.join(' ')}`, { problems: v.problems });
    await c.query("UPDATE cbt_exams SET status = 'published', published_by = $2, published_at = now() WHERE id = $1", [e.id, req.auth.userId]);
    const users = (await c.query('SELECT user_id FROM students WHERE id = ANY($1::uuid[]) AND user_id IS NOT NULL', [await candidateIds(c, e)])).rows.map((r) => r.user_id);
    const when = e.starts_at && new Date(e.starts_at) > new Date() ? new Date(e.starts_at) : null;
    const fmt = (d) => d.toLocaleString('en-NG', { weekday: 'short', day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit', timeZone: 'Africa/Lagos' });
    await notify(c, req.auth.schoolId, users, { kind: 'cbt', title: when ? `${e.title} has been scheduled for ${fmt(when)}` : `New CBT: ${e.title} is now open`, link: '#/my-cbt' });
    if (when && when.getTime() - Date.now() > 40 * 60000) await enqueue(c, { schoolId: req.auth.schoolId, kind: 'cbt.reminder', payload: { examId: e.id, startsAt: e.starts_at }, runAt: new Date(when.getTime() - 30 * 60000) });
    await audit(c, req, 'cbt.exam_published', { type: 'cbt_exam', id: e.id, meta: { questions: v.questions, candidates: users.length, scheduledFor: when } });
    return { ok: true, lifecycle: when ? 'scheduled' : 'active' };
  }));
  app.post('/cbt/exams/:id/close', { onRequest: [A, app.perm('cbt.publish')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const e = await loadExam(c, req, req.params.id, { lock: true });
    if (e.status !== 'published') throw E.conflict('Only published exams can be closed.');
    await c.query("UPDATE cbt_exams SET status = 'closed' WHERE id = $1", [e.id]);
    const live = (await c.query("SELECT id FROM cbt_attempts WHERE exam_id = $1 AND status = 'in_progress'", [e.id])).rows;
    for (const a of live) await gradeAttempt(c, a.id, { auto: true });
    await audit(c, req, 'cbt.exam_closed', { type: 'cbt_exam', id: e.id, meta: { autoSubmitted: live.length } });
    return { ok: true, autoSubmitted: live.length };
  }));

  // ───────── staff: attempts, marking, results ─────────
  app.get('/cbt/exams/:id/attempts', { onRequest: [A, app.perm('cbt.results')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const e = await loadExam(c, req, req.params.id);
    return { items: (await c.query(`SELECT a.id, a.attempt_no, a.status, a.started_at, a.submitted_at, a.score, a.objective_score, a.max_score, a.needs_manual_grading, a.focus_losses,
      s.first_name || ' ' || s.last_name AS student, s.admission_no FROM cbt_attempts a JOIN students s ON s.id = a.student_id WHERE a.exam_id = $1 ORDER BY s.last_name, a.attempt_no`, [e.id])).rows };
  }));
  app.get('/cbt/attempts/:id/review', { onRequest: [A, app.perm('cbt.grade', 'cbt.results')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const at = (await c.query('SELECT a.*, s.first_name || \' \' || s.last_name AS student, s.admission_no FROM cbt_attempts a JOIN students s ON s.id = a.student_id WHERE a.id = $1', [req.params.id])).rows[0];
    if (!at) throw E.notFound('Attempt');
    await loadExam(c, req, at.exam_id);                                  // scope check
    const items = (await c.query(`SELECT q.id, q.type, q.text, q.marks, q.theory_guide, q.explanation, q.answer_key, q.topic, an.text_answer, an.option_id, an.option_ids, an.is_correct, an.marks_awarded, an.flagged, an.time_spent_seconds,
      (SELECT text FROM cbt_options o WHERE o.id = an.option_id) AS chosen,
      (SELECT string_agg(o.text, ' | ' ORDER BY o.position) FROM cbt_options o WHERE o.id = ANY(an.option_ids)) AS chosen_many,
      (SELECT string_agg(o.text, ' | ' ORDER BY o.position) FROM cbt_options o WHERE o.question_id = q.id AND o.is_correct) AS correct_option
      FROM unnest($1::uuid[]) WITH ORDINALITY AS u(qid, n) JOIN cbt_questions q ON q.id = u.qid LEFT JOIN cbt_answers an ON an.attempt_id = $2 AND an.question_id = q.id ORDER BY u.n`, [at.question_order, at.id])).rows;
    for (const it of items) it.manual = isManual(it);
    return { attempt: { id: at.id, examId: at.exam_id, student: at.student, admissionNo: at.admission_no, status: at.status, attemptNo: at.attempt_no, score: at.score, objectiveScore: at.objective_score,
      maxScore: at.max_score, focusLosses: at.focus_losses, startedAt: at.started_at, submittedAt: at.submitted_at, needsManualGrading: at.needs_manual_grading }, items };
  }));
  app.post('/cbt/attempts/:id/grade', {
    onRequest: [A, app.perm('cbt.grade')],
    schema: { params: idParams, body: obj({ grades: { type: 'array', minItems: 1, maxItems: 200, items: obj({ questionId: uuid, marks: { type: 'number', minimum: 0, maximum: 100 } }, ['questionId', 'marks']) } }, ['grades']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const at = (await c.query('SELECT * FROM cbt_attempts WHERE id = $1 FOR UPDATE', [req.params.id])).rows[0];
    if (!at) throw E.notFound('Attempt');
    await loadExam(c, req, at.exam_id);
    if (at.status === 'in_progress') throw E.conflict('This attempt is still in progress.');
    if (at.status === 'void') throw E.conflict('This attempt was reset.');
    const qs = new Map((await c.query('SELECT id, type, marks, answer_key FROM cbt_questions WHERE id = ANY($1::uuid[])', [at.question_order])).rows.map((q) => [q.id, q]));
    for (const g of req.body.grades) {
      const q = qs.get(g.questionId);
      if (!q || !isManual(q)) throw E.bad('Only essay / unkeyed short-answer questions in this attempt can be marked manually.');
      if (g.marks > Number(q.marks)) throw E.bad(`Marks cannot exceed ${q.marks}.`);
      await c.query(`INSERT INTO cbt_answers (school_id, attempt_id, question_id, marks_awarded) VALUES ($1,$2,$3,$4)
        ON CONFLICT (attempt_id, question_id) DO UPDATE SET marks_awarded = EXCLUDED.marks_awarded`, [req.auth.schoolId, at.id, g.questionId, g.marks]);
    }
    const manualIds = [...qs.values()].filter(isManual).map((q) => q.id);
    const m = (await c.query(`SELECT COALESCE(sum(an.marks_awarded), 0) AS t, count(*) FILTER (WHERE an.marks_awarded IS NULL)::int AS ungraded
      FROM unnest($2::uuid[]) AS x(qid) LEFT JOIN cbt_answers an ON an.question_id = x.qid AND an.attempt_id = $1`, [at.id, manualIds])).rows[0];
    const done = m.ungraded === 0;
    const upd = await c.query(`UPDATE cbt_attempts SET theory_score = $2::numeric, score = CASE WHEN $3::boolean THEN COALESCE(objective_score,0) + $2::numeric ELSE NULL END, needs_manual_grading = NOT $3::boolean,
      status = CASE WHEN $3::boolean THEN 'graded' ELSE status END, graded_by = $4, graded_at = now() WHERE id = $1 RETURNING *`, [at.id, m.t, done, req.auth.userId]);
    if (done) await finalize(c, upd.rows[0]);
    await audit(c, req, 'cbt.attempt_graded', { type: 'cbt_attempt', id: at.id, meta: { manualMarks: Number(m.t), complete: done } });
    return { ok: true, complete: done };
  }));

  // results table for an exam (JSON, or CSV/XLSX download)
  app.get('/cbt/exams/:id/results', { onRequest: [A, app.perm('cbt.results')], schema: { params: idParams, querystring: obj({ format: { enum: ['json', 'csv', 'xlsx'] } }) } }, async (req, reply) => {
    const out = await withTx(ctx(req), async (c) => {
      const e = await loadExam(c, req, req.params.id);
      const bands = await bandsForExam(c, e);
      const ids = await candidateIds(c, e);
      const counted = new Map((await countedResults(c, e)).map((r) => [r.student_id, r]));
      const students = (await c.query(`SELECT s.id, s.first_name, s.last_name, s.admission_no,
          (SELECT count(*)::int FROM cbt_attempts a WHERE a.exam_id = $2 AND a.student_id = s.id AND a.status <> 'void') AS attempts,
          (SELECT a.id FROM cbt_attempts a WHERE a.exam_id = $2 AND a.student_id = s.id AND a.status <> 'void' ORDER BY a.attempt_no DESC LIMIT 1) AS last_attempt_id,
          (SELECT a.status FROM cbt_attempts a WHERE a.exam_id = $2 AND a.student_id = s.id AND a.status <> 'void' ORDER BY a.attempt_no DESC LIMIT 1) AS last_status
        FROM students s WHERE s.id = ANY($1::uuid[]) OR s.id IN (SELECT student_id FROM cbt_attempts WHERE exam_id = $2) ORDER BY s.last_name, s.first_name`, [ids, e.id])).rows;
      const items = students.map((s) => {
        const r = counted.get(s.id);
        return { studentId: s.id, student: `${s.last_name} ${s.first_name}`, admissionNo: s.admission_no, attempts: s.attempts, lastAttemptId: s.last_attempt_id, attemptStatus: s.last_status || 'not started',
          resultId: r ? r.id : null, attemptId: r ? r.attempt_id : null, attemptNo: r ? r.attempt_no : null, score: r ? Number(r.score) : null, maxScore: r ? Number(r.max_score) : null,
          percentage: r ? Number(r.percentage) : null, grade: r ? G.gradeFor(Number(r.percentage), bands).grade : null, passed: r ? r.passed : null,
          timeUsedSeconds: r && r.submitted_at ? Math.max(0, Math.round((new Date(r.submitted_at) - new Date(r.started_at)) / 1000)) : null,
          released: r ? r.released : false, withheldReason: r ? r.withheld_reason : null };
      });
      return { exam: publicExam(e), items };
    });
    if (!req.query.format || req.query.format === 'json') return out;
    const { toCsv, toXlsx } = require('../lib/csv');
    const cols = [['student', 'Student'], ['admissionNo', 'Admission No'], ['score', 'Score'], ['maxScore', 'Out of'], ['percentage', '%'], ['grade', 'Grade'], ['passedText', 'Status'], ['time', 'Time used (min)'], ['attemptNo', 'Attempt'], ['releasedText', 'Released']].map(([key, label]) => ({ key, label }));
    const rows = out.items.map((x) => ({ ...x, passedText: x.passed === null ? x.attemptStatus : x.passed ? 'PASS' : 'FAIL', time: x.timeUsedSeconds === null ? '' : Math.round(x.timeUsedSeconds / 6) / 10, releasedText: x.released ? 'yes' : 'no' }));
    await withTx({ ...ctx(req), readOnly: false }, (c) => audit(c, req, 'data.exported', { type: 'export', id: 'cbt_results', meta: { exam: req.params.id, rows: rows.length, format: req.query.format } }));
    const name = `cbt-results-${out.exam.title.replace(/[^A-Za-z0-9]+/g, '-').slice(0, 40)}`;
    if (req.query.format === 'xlsx') { reply.header('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet').header('Content-Disposition', `attachment; filename="${name}.xlsx"`); return toXlsx('CBT results', cols, rows); }
    reply.header('Content-Type', 'text/csv; charset=utf-8').header('Content-Disposition', `attachment; filename="${name}.csv"`);
    return toCsv(cols, rows);
  });

  const releaseOne = async (c, req, resultId, release, reason) => {
    const r = (await c.query('SELECT r.*, a.status AS attempt_status FROM cbt_results r JOIN cbt_attempts a ON a.id = r.attempt_id WHERE r.id = $1 FOR UPDATE OF r', [resultId])).rows[0];
    if (!r) throw E.notFound('Result');
    const e = await loadExam(c, req, r.exam_id);
    if (r.attempt_status === 'void') throw E.conflict('This attempt was reset.');
    await c.query(`UPDATE cbt_results SET released = $2, released_at = CASE WHEN $2 THEN now() ELSE NULL END, released_by = CASE WHEN $2 THEN $3::uuid ELSE NULL END,
      withheld_reason = CASE WHEN $2 THEN NULL ELSE $4 END WHERE id = $1`, [r.id, release, req.auth.userId, reason || null]);
    if (release && !r.released) {
      const u = (await c.query('SELECT user_id FROM students WHERE id = $1', [r.student_id])).rows[0];
      if (u && u.user_id) await notify(c, req.auth.schoolId, [u.user_id], { kind: 'cbt', title: `Your result for ${e.title} has been released`, link: `#/cbt/result/${r.attempt_id}` });
    }
    return r;
  };
  app.post('/cbt/results/:id/release', { onRequest: [A, app.perm('cbt.publish')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const r = await releaseOne(c, req, req.params.id, true);
    await audit(c, req, 'cbt.result_released', { type: 'cbt_result', id: r.id, meta: { exam: r.exam_id } });
    return { ok: true };
  }));
  app.post('/cbt/results/:id/withhold', { onRequest: [A, app.perm('cbt.publish')], schema: { params: idParams, body: obj({ reason: str(300, 3) }, ['reason']) } }, async (req) => withTx(ctx(req), async (c) => {
    const r = await releaseOne(c, req, req.params.id, false, req.body.reason);
    await audit(c, req, 'cbt.result_withheld', { type: 'cbt_result', id: r.id, meta: { exam: r.exam_id, reason: req.body.reason } });
    return { ok: true };
  }));
  app.post('/cbt/exams/:id/release', { onRequest: [A, app.perm('cbt.publish')], schema: { params: idParams, body: obj({ release: { type: 'boolean' } }, ['release']) } }, async (req) => withTx(ctx(req), async (c) => {
    const e = await loadExam(c, req, req.params.id);
    const ids = (await c.query(`SELECT r.id FROM cbt_results r JOIN cbt_attempts a ON a.id = r.attempt_id AND a.status <> 'void' WHERE r.exam_id = $1 AND r.released <> $2 AND (NOT $2 OR r.withheld_reason IS NULL)`, [e.id, req.body.release])).rows;
    for (const r of ids) await releaseOne(c, req, r.id, req.body.release, req.body.release ? null : 'Withheld by the school');
    await audit(c, req, req.body.release ? 'cbt.results_released' : 'cbt.results_withheld', { type: 'cbt_exam', id: e.id, meta: { count: ids.length } });
    return { ok: true, changed: ids.length };
  }));
  // reset: void an attempt (kept for the record) so the candidate can sit again
  app.post('/cbt/attempts/:id/reset', { onRequest: [A, app.perm('cbt.publish')], schema: { params: idParams, body: obj({ reason: str(300, 3) }, ['reason']) } }, async (req) => withTx(ctx(req), async (c) => {
    const at = (await c.query('SELECT * FROM cbt_attempts WHERE id = $1 FOR UPDATE', [req.params.id])).rows[0];
    if (!at) throw E.notFound('Attempt');
    const e = await loadExam(c, req, at.exam_id);
    if (at.status === 'void') throw E.conflict('This attempt was already reset.');
    if (e.scores_pushed_at) throw E.conflict('Scores from this exam were already sent to the result sheet. Correct the result sheet through a correction request instead.');
    await c.query("UPDATE cbt_attempts SET status = 'void', void_reason = $2, voided_by = $3, voided_at = now() WHERE id = $1", [at.id, req.body.reason, req.auth.userId]);
    await c.query('DELETE FROM cbt_results WHERE attempt_id = $1', [at.id]);
    const u = (await c.query('SELECT user_id FROM students WHERE id = $1', [at.student_id])).rows[0];
    if (u && u.user_id) await notify(c, req.auth.schoolId, [u.user_id], { kind: 'cbt', title: `Your attempt at ${e.title} was reset — you may sit the exam again`, link: '#/my-cbt' });
    await audit(c, req, 'cbt.attempt_reset', { type: 'cbt_attempt', id: at.id, meta: { exam: e.id, student: at.student_id, reason: req.body.reason, previousStatus: at.status } });
    return { ok: true };
  }));

  // ── CBT score → EXISTING result sheet (validated; school's components, weighting, grading & workflow apply) ──
  app.post('/cbt/exams/:id/push-scores', {
    onRequest: [A, app.perm('cbt.publish')],
    schema: { params: idParams, body: obj({ dryRun: { type: 'boolean' } }) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const e = await loadExam(c, req, req.params.id, { lock: true });
    if (!e.score_component) throw E.bad('This exam is not set to feed the result sheet. Choose the assessment component (e.g. Exam, CA1) in the exam settings.');
    if (!e.subject_id || !e.class_id || !e.term_id) throw E.bad('Set the subject, class and term of this exam first.');
    if (!req.can('results.enter_any')) {
      const ok = req.can('results.enter') && req.auth.staffId && (await c.query("SELECT 1 FROM teacher_class_access WHERE class_id = $1 AND subject_id = $2 AND staff_id = $3 AND role IN ('subject_teacher','assistant')", [e.class_id, e.subject_id, req.auth.staffId])).rowCount;
      if (!ok) throw E.forbidden('Sending scores to the result sheet needs score-entry rights for this class and subject.');
    }
    if (!(await c.query('SELECT 1 FROM class_subjects WHERE class_id = $1 AND subject_id = $2', [e.class_id, e.subject_id])).rowCount) throw E.bad('This subject is not offered in the exam class (Academics › Subject Allocation).');
    const live = (await c.query("SELECT count(*)::int AS n FROM cbt_attempts WHERE exam_id = $1 AND status = 'in_progress'", [e.id])).rows[0].n;
    if (live && !req.body.dryRun) throw E.conflict(`${live} candidate(s) are still writing. Close the exam or wait for them to finish.`);
    const st = await R.settings(c);
    const sh = (await c.query(`INSERT INTO assessments (school_id, term_id, class_id, subject_id, components, created_by) VALUES ($1,$2,$3,$4,$5,$6)
      ON CONFLICT (term_id, class_id, subject_id) DO UPDATE SET updated_at = assessments.updated_at RETURNING id, status, components, version`,
    [req.auth.schoolId, e.term_id, e.class_id, e.subject_id, JSON.stringify(st.assessment_components), req.auth.userId])).rows[0];
    const comp = (sh.components || []).find((x) => x.key === e.score_component);
    if (!comp) throw E.bad(`The ${e.score_component.toUpperCase()} column does not exist on this subject's score sheet.`);
    if (sh.status !== 'draft') throw E.locked(`The ${sh.status} score sheet is locked. Send scores before it is submitted, or use a correction request.`);
    const roster = new Map((await R.roster(c, e.term_id, e.class_id)).map((s) => [s.id, s]));
    const pending = (await c.query(`SELECT DISTINCT s.first_name || ' ' || s.last_name AS name FROM cbt_attempts a JOIN students s ON s.id = a.student_id WHERE a.exam_id = $1 AND a.needs_manual_grading AND a.status <> 'void'`, [e.id])).rows.map((r) => r.name);
    const rows = []; const skipped = [];
    for (const r of await countedResults(c, e)) {
      const s = roster.get(r.student_id);
      if (!s) { skipped.push({ studentId: r.student_id, reason: 'not on this class register for the term' }); continue; }
      const value = Math.round(Number(r.percentage) / 100 * Number(comp.max) * 10) / 10;            // CBT % scaled to the component's maximum
      rows.push({ student_id: r.student_id, name: `${s.last_name} ${s.first_name}`, percentage: Number(r.percentage), score: value });
    }
    if (req.body.dryRun) return { dryRun: true, sheetId: sh.id, component: comp, rows, skipped, pendingManualMarking: pending, stillWriting: live };
    if (!rows.length) throw E.bad('There are no finalised CBT results to send yet.');
    await c.query(`INSERT INTO assessment_scores (school_id, sheet_id, student_id, component_key, score, entered_by)
      SELECT $1, $2, x.student_id, $3, x.score, $4 FROM json_to_recordset($5::json) AS x(student_id uuid, score numeric)
      ON CONFLICT (sheet_id, student_id, component_key) DO UPDATE SET score = EXCLUDED.score, entered_by = EXCLUDED.entered_by WHERE assessment_scores.score IS DISTINCT FROM EXCLUDED.score`,
    [req.auth.schoolId, sh.id, e.score_component, req.auth.userId, JSON.stringify(rows.map((x) => ({ student_id: x.student_id, score: x.score })))]);
    await R.recomputeSheet(c, sh.id);
    await c.query('UPDATE assessments SET version = version + 1 WHERE id = $1', [sh.id]);
    await c.query('UPDATE cbt_exams SET scores_pushed_at = now(), scores_pushed_by = $2 WHERE id = $1', [e.id, req.auth.userId]);
    await audit(c, req, 'cbt.scores_pushed', { type: 'cbt_exam', id: e.id, meta: { sheet: sh.id, component: e.score_component, written: rows.length, skipped: skipped.length, pendingManual: pending.length } });
    return { ok: true, sheetId: sh.id, written: rows.length, skipped, pendingManualMarking: pending };
  }));

  // ───────── student: take exams ─────────
  app.get('/cbt/available', { onRequest: [A, app.perm('cbt.take')], config: perSession(120) }, async (req) => withTx(ctx(req), async (c) => {
    if (!req.auth.studentId) return { items: [] };
    const cls = await currentClassOf(c, req.auth.studentId);
    return { items: (await c.query(`SELECT e.id, e.title, e.category, e.instructions, e.duration_minutes, e.starts_at, e.ends_at, e.max_attempts, s.name AS subject, cl.display_name AS class_name,
        (e.access_code_hash IS NOT NULL) AS needs_code, e.fullscreen,
        (SELECT count(*)::int FROM cbt_questions q WHERE q.exam_id = e.id) AS questions,
        (SELECT count(*)::int FROM cbt_attempts a WHERE a.exam_id = e.id AND a.student_id = $1 AND a.status <> 'void') AS attempts_used,
        (SELECT a.id FROM cbt_attempts a WHERE a.exam_id = e.id AND a.student_id = $1 AND a.status = 'in_progress') AS live_attempt
      FROM cbt_exams e LEFT JOIN subjects s ON s.id = e.subject_id LEFT JOIN classes cl ON cl.id = e.class_id
      WHERE e.status = 'published' AND (e.ends_at IS NULL OR e.ends_at > now())
        AND (EXISTS (SELECT 1 FROM cbt_exam_candidates x WHERE x.exam_id = e.id AND x.student_id = $1)
             OR (NOT EXISTS (SELECT 1 FROM cbt_exam_candidates x WHERE x.exam_id = e.id) AND (e.class_id IS NULL OR e.class_id = $2)))
      ORDER BY e.starts_at NULLS FIRST, e.created_at DESC`, [req.auth.studentId, cls])).rows };
  }));

  app.post('/cbt/exams/:id/start', {
    onRequest: [A, app.perm('cbt.take')], config: perSession(20),
    schema: { params: idParams, body: { type: ['object', 'null'], additionalProperties: false, properties: { accessCode: { type: ['string', 'null'], maxLength: 40 } } } },
  }, async (req) => withTx(ctx(req), async (c) => {
    if (!req.auth.studentId) throw E.forbidden('Only student accounts can take exams.');
    const e = (await c.query('SELECT * FROM cbt_exams WHERE id = $1 FOR SHARE', [req.params.id])).rows[0];
    if (!e || e.status !== 'published') throw E.notFound('Exam');
    const cls = await currentClassOf(c, req.auth.studentId);
    if (!(await isCandidate(c, e, req.auth.studentId, cls))) throw E.notFound('Exam');
    const now = new Date();
    if (e.starts_at && new Date(e.starts_at) > now) throw E.forbidden('This exam has not started yet.');
    if (e.ends_at && new Date(e.ends_at) <= now) throw E.forbidden('This exam window has closed.');
    const live = (await c.query("SELECT * FROM cbt_attempts WHERE exam_id = $1 AND student_id = $2 AND status = 'in_progress' FOR UPDATE", [e.id, req.auth.studentId])).rows[0];
    if (live) {
      if (!e.allow_resume) {                                        // no resuming: close the interrupted attempt with what was saved
        await gradeAttempt(c, live.id, { auto: true });
        await audit(c, req, 'cbt.attempt_submitted', { type: 'cbt_attempt', id: live.id, meta: { auto: true, reason: 'resume_not_allowed' } });
        return { resumeBlocked: true, attemptId: live.id, message: 'This exam does not allow resuming. Your saved answers were submitted.' };
      }
      return paper(c, live);                                        // resume (refresh / reconnect)
    }
    if (e.access_code_hash) {
      const code = String((req.body && req.body.accessCode) || '').trim().toUpperCase();
      if (!code || !(await pw.verify(e.access_code_hash, code))) throw E.forbidden('The access code is not correct. Ask the invigilator for the code.');
    }
    const used = (await c.query("SELECT count(*) FILTER (WHERE status <> 'void')::int AS n, COALESCE(max(attempt_no), 0)::int AS last FROM cbt_attempts WHERE exam_id = $1 AND student_id = $2", [e.id, req.auth.studentId])).rows[0];
    if (used.n >= e.max_attempts) throw E.forbidden('You have used all attempts for this exam.');
    const qs = (await c.query('SELECT id FROM cbt_questions WHERE exam_id = $1 ORDER BY position, created_at', [e.id])).rows.map((r) => r.id);
    if (!qs.length) throw E.notFound('Exam');
    const order = e.shuffle_questions ? shuffle(qs) : qs;
    const optOrder = {};
    for (const r of (await c.query('SELECT question_id, array_agg(id ORDER BY position) AS ids FROM cbt_options WHERE question_id = ANY($1::uuid[]) GROUP BY question_id', [qs])).rows) {
      optOrder[r.question_id] = e.shuffle_options ? shuffle(r.ids) : r.ids;
    }
    let deadline = new Date(now.getTime() + e.duration_minutes * 60000);
    if (e.ends_at && new Date(e.ends_at) < deadline) deadline = new Date(e.ends_at);
    const at = (await c.query(`INSERT INTO cbt_attempts (school_id, exam_id, student_id, attempt_no, deadline_at, question_order, option_order, ip, user_agent)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`, [req.auth.schoolId, e.id, req.auth.studentId, used.last + 1, deadline, order, optOrder, req.ip, String(req.headers['user-agent'] || '').slice(0, 300)])).rows[0];
    await audit(c, req, 'cbt.attempt_started', { type: 'cbt_attempt', id: at.id, meta: { exam: e.id, attemptNo: at.attempt_no } });
    return paper(c, at);
  }));

  app.get('/cbt/attempts/:id/paper', { onRequest: [A, app.perm('cbt.take')], config: perSession(60), schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const at = await ownAttempt(c, req, req.params.id);
    if (at.status !== 'in_progress') throw E.conflict('This attempt has been submitted.');
    return paper(c, at);
  }));

  // autosave (idempotent upsert per question → re-sending after a reconnect never duplicates)
  app.put('/cbt/attempts/:id/answers', {
    onRequest: [A, app.perm('cbt.take')], config: perSession(240),
    schema: { params: idParams, body: obj({ answers: { type: 'array', minItems: 1, maxItems: 200, items: obj({ questionId: uuid, optionId: optUuid, optionIds: { type: 'array', maxItems: 8, items: uuid }, text: { type: ['string', 'null'], maxLength: 10000 }, flagged: { type: 'boolean' }, timeSpent: { type: 'integer', minimum: 0, maximum: 3600 } }, ['questionId']) } }, ['answers']) },
  }, async (req) => withTx({ ...ctx(req), readOnly: false }, async (c) => {
    const at = await ownAttempt(c, req, req.params.id, true);
    if (at.status !== 'in_progress') throw E.conflict('Your examination has already been submitted.');
    if (Date.now() > new Date(at.deadline_at).getTime() + 30000) {
      await gradeAttempt(c, at.id, { auto: true });                 // commit the auto-submission (do not throw → no rollback)
      return { ok: false, timeUp: true, message: 'Time is up. Your saved answers were submitted automatically.' };
    }
    const index = new Map(at.question_order.map((q, i) => [q, i]));
    const qtypes = new Map((await c.query('SELECT id, type FROM cbt_questions WHERE id = ANY($1::uuid[])', [at.question_order])).rows.map((r) => [r.id, r.type]));
    let furthest = at.furthest_index;
    for (const a of req.body.answers) {
      if (!index.has(a.questionId)) throw E.bad('Question is not part of this attempt.');
      const i = index.get(a.questionId);
      if (!at.allow_back_nav && i < at.furthest_index) throw E.conflict('Going back to earlier questions is not allowed in this exam.');
      furthest = Math.max(furthest, i);
      const t = qtypes.get(a.questionId);
      const ids = [...new Set([a.optionId, ...(a.optionIds || [])].filter(Boolean))];
      if (ids.length) {
        if (t !== 'multi_select' && ids.length > 1) throw E.bad('Choose only one option for this question.');
        const ok = (await c.query('SELECT count(*)::int AS n FROM cbt_options WHERE id = ANY($1::uuid[]) AND question_id = $2', [ids, a.questionId])).rows[0].n;
        if (ok !== ids.length) throw E.bad('Invalid option for this question.');
      }
      const single = t === 'multi_select' ? null : (ids[0] || null); const many = t === 'multi_select' ? ids : null;
      await c.query(`INSERT INTO cbt_answers (school_id, attempt_id, question_id, option_id, option_ids, text_answer, flagged, time_spent_seconds, saved_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8, now())
        ON CONFLICT (attempt_id, question_id) DO UPDATE SET option_id = EXCLUDED.option_id, option_ids = EXCLUDED.option_ids, text_answer = EXCLUDED.text_answer,
          flagged = EXCLUDED.flagged, time_spent_seconds = LEAST(86400, cbt_answers.time_spent_seconds + EXCLUDED.time_spent_seconds), saved_at = now()`,
      [req.auth.schoolId, at.id, a.questionId, single, many, a.text ?? null, !!a.flagged, a.timeSpent || 0]);
    }
    if (furthest !== at.furthest_index) await c.query('UPDATE cbt_attempts SET furthest_index = $2 WHERE id = $1', [at.id, furthest]);
    return { ok: true, saved: req.body.answers.length, serverNow: new Date().toISOString(), deadlineAt: at.deadline_at };
  }));

  app.post('/cbt/attempts/:id/focus-loss', { onRequest: [A, app.perm('cbt.take')], schema: { params: idParams }, config: perSession(60) }, async (req) => withTx(ctx(req), async (c) => {
    const at = await ownAttempt(c, req, req.params.id);
    if (at.status === 'in_progress') await c.query('UPDATE cbt_attempts SET focus_losses = focus_losses + 1 WHERE id = $1', [at.id]);
    return { ok: true };
  }));

  app.post('/cbt/attempts/:id/submit', { onRequest: [A, app.perm('cbt.take')], schema: { params: idParams, body: { type: ['object', 'null'], additionalProperties: false, properties: {} } }, config: perSession(20) }, async (req) => withTx(ctx(req), async (c) => {
    const at = await ownAttempt(c, req, req.params.id);
    if (at.status !== 'in_progress') throw E.conflict('Your examination has already been submitted.');
    const late = Date.now() > new Date(at.deadline_at).getTime() + 30000;
    const g = await gradeAttempt(c, at.id, { auto: late });
    if (g._already) throw E.conflict('Your examination has already been submitted.');     // concurrent double-submit
    await audit(c, req, 'cbt.attempt_submitted', { type: 'cbt_attempt', id: at.id, meta: { auto: late, objective: g.objective_score, max: g.max_score } });
    const r = (await c.query('SELECT released FROM cbt_results WHERE attempt_id = $1', [at.id])).rows[0];
    // immediate feedback when the exam allows it (objective part only while essays await marking)
    const showNow = !!(r && r.released) || (at.show_result && g.needs_manual_grading);
    return { ok: true, status: g.status, attemptId: at.id, resultAvailable: !!(r && r.released),
      ...(showNow ? { score: g.score, objectiveScore: g.objective_score, maxScore: g.max_score, pendingTheory: g.needs_manual_grading } : { message: g.needs_manual_grading ? 'Submitted. Some answers will be marked by your teacher before the result is released.' : 'Submitted. Your school will release the result.' }) };
  }));

  // candidate's own result (only when released; answers only if the exam allows)
  app.get('/cbt/attempts/:id/result', { onRequest: [A, app.perm('cbt.take')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const at = await ownAttempt(c, req, req.params.id);
    if (at.status === 'in_progress') throw E.conflict('This attempt is still in progress.');
    const r = (await c.query('SELECT * FROM cbt_results WHERE attempt_id = $1', [at.id])).rows[0];
    const meta = (await c.query(`SELECT e.title, s.name AS subject, cl.display_name AS class_name, st.first_name || ' ' || st.last_name AS student_name, st.admission_no FROM cbt_exams e
      LEFT JOIN subjects s ON s.id = e.subject_id LEFT JOIN classes cl ON cl.id = e.class_id JOIN students st ON st.id = $2 WHERE e.id = $1`, [at.exam_id, at.student_id])).rows[0];
    if (!r || !r.released) return { released: false, title: meta.title, message: at.needs_manual_grading ? 'Your answers are being marked. The result will appear here when it is released.' : 'Your result has not been released yet.' };
    const e = (await c.query('SELECT * FROM cbt_exams WHERE id = $1', [at.exam_id])).rows[0];
    const bands = await bandsForExam(c, e);
    const rows = (await c.query(`SELECT q.id, q.type, q.text, q.marks, q.explanation, q.answer_key, an.option_id, an.option_ids, an.text_answer, an.is_correct, an.marks_awarded,
        (SELECT string_agg(o.text, ' | ' ORDER BY o.position) FROM cbt_options o WHERE o.id = an.option_id OR o.id = ANY(an.option_ids)) AS your_answer,
        (SELECT string_agg(o.text, ' | ' ORDER BY o.position) FROM cbt_options o WHERE o.question_id = q.id AND o.is_correct) AS correct_option
      FROM unnest($1::uuid[]) WITH ORDINALITY AS u(qid, n) JOIN cbt_questions q ON q.id = u.qid LEFT JOIN cbt_answers an ON an.attempt_id = $2 AND an.question_id = q.id ORDER BY u.n`, [at.question_order, at.id])).rows;
    const answered = (x) => !!(x.option_id || (x.option_ids && x.option_ids.length) || (x.text_answer && String(x.text_answer).trim()));
    const out = {
      released: true, title: meta.title, subject: meta.subject, className: meta.class_name, student: { name: meta.student_name, admissionNo: meta.admission_no },
      score: Number(r.score), maxScore: Number(r.max_score), percentage: Number(r.percentage), grade: G.gradeFor(Number(r.percentage), bands).grade, passed: r.passed, passMark: Number(e.pass_mark),
      timeUsedSeconds: at.submitted_at ? Math.max(0, Math.round((new Date(at.submitted_at) - new Date(at.started_at)) / 1000)) : null,
      questions: rows.length, attempted: rows.filter(answered).length, correct: rows.filter((x) => x.is_correct === true).length,
      incorrect: rows.filter((x) => answered(x) && x.is_correct === false).length, unanswered: rows.filter((x) => !answered(x)).length,
    };
    if (e.show_answers) {
      out.review = rows.map((x, i) => ({ n: i + 1, text: x.text, type: x.type, marks: Number(x.marks), marksAwarded: x.marks_awarded === null ? null : Number(x.marks_awarded), yourAnswer: x.your_answer || x.text_answer || null,
        correct: x.is_correct, correctAnswer: x.correct_option || (x.answer_key ? (x.answer_key.accepted ? x.answer_key.accepted.join(' / ') : x.answer_key.value !== undefined ? String(x.answer_key.value) : null) : null), explanation: x.explanation }));
    }
    return out;
  }));

  app.get('/cbt/my-results', { onRequest: [A, app.perm('cbt.take')] }, async (req) => withTx(ctx(req), async (c) => ({
    items: req.auth.studentId ? (await c.query(`SELECT a.id, e.title, s.name AS subject, a.attempt_no, a.status, a.submitted_at, CASE WHEN r.released THEN r.score END AS score, CASE WHEN r.released THEN r.max_score END AS max_score,
      CASE WHEN r.released THEN r.percentage END AS percentage, CASE WHEN r.released THEN r.passed END AS passed, COALESCE(r.released, false) AS released, a.needs_manual_grading
      FROM cbt_attempts a JOIN cbt_exams e ON e.id = a.exam_id LEFT JOIN subjects s ON s.id = e.subject_id LEFT JOIN cbt_results r ON r.attempt_id = a.id
      WHERE a.student_id = $1 AND a.status NOT IN ('in_progress','void') ORDER BY a.started_at DESC`, [req.auth.studentId])).rows : [],
  })));
};
module.exports.scopeSql = scopeSql;
module.exports.loadExam = loadExam;
module.exports.bandsForExam = bandsForExam;
module.exports.countedResults = countedResults;
void crypto;
