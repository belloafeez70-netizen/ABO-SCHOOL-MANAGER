'use strict';
// Petty cash requests — the offline edition's "Petty Cash" page, on the server (027):
//   1. any staff member ASKS for petty cash (purpose + amount);
//   2. a different person with pettycash.approve APPROVES or refuses (nobody approves their own request — also a DB rule);
//   3. the cashier HANDS IT OUT → recorded in the cashbook as "spent from petty cash" (the box can never go below zero);
//   4. the staff member brings receipts and change → the cashier SETTLES it: the hand-out entry is voided and replaced by
//      the amount really spent, so the change is back in the box and the books show only real spending.
// Every step is audited; nothing is ever edited or deleted.
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, str, uuid, idParams } = require('../lib/schema');
const { ctx } = require('../auth/plugin');
const { audit } = require('../audit/audit');
const { withIdempotency } = require('../lib/idempotency');
const { notify } = require('../services/notify');

const KOBO = { type: 'integer', minimum: 1, maximum: 100000000000 };
const naira = (k) => `₦${(Number(k) / 100).toLocaleString('en-NG', { minimumFractionDigits: 2 })}`;
const lockPetty = (c, schoolId) => c.query("SELECT pg_advisory_xact_lock(hashtext('abo:pettycash:' || $1::text))", [schoolId]);   // same lock as the cashbook
async function boxBalance(c) {
  return Number((await c.query(`SELECT coalesce(sum(CASE WHEN kind = 'income' THEN amount_kobo ELSE -amount_kobo END), 0)::bigint AS b FROM cash_entries
    WHERE method = 'petty_cash' AND voided_at IS NULL`)).rows[0].b);
}
async function today(c, schoolId) { return (await c.query('SELECT (now() AT TIME ZONE timezone)::date::text AS d FROM schools WHERE id = $1', [schoolId])).rows[0].d; }
async function nextNo(c, schoolId) {
  const y = new Date().getFullYear();
  const r = (await c.query(`INSERT INTO doc_counters (school_id, kind, year, last_no) VALUES ($1,'pettycash',$2,1)
    ON CONFLICT (school_id, kind, year) DO UPDATE SET last_no = doc_counters.last_no + 1 RETURNING last_no`, [schoolId, y])).rows[0].last_no;
  return `PCR-${y}-${String(r).padStart(6, '0')}`;
}
const SELECT = `SELECT r.id, r.ref_no, r.purpose, r.amount_kobo, r.status, r.created_at, r.requested_by, ru.full_name AS requested_by_name,
    r.decided_at, du.full_name AS decided_by_name, r.decision_note, r.given_at, gu.full_name AS given_by_name, r.spent_kobo, r.returned_kobo,
    r.settled_at, su.full_name AS settled_by_name, r.settle_note
  FROM petty_cash_requests r JOIN users ru ON ru.id = r.requested_by LEFT JOIN users du ON du.id = r.decided_by
  LEFT JOIN users gu ON gu.id = r.given_by LEFT JOIN users su ON su.id = r.settled_by`;

module.exports = async function pettyCashRoutes(app) {
  const A = app.authenticate;
  const ANY = app.perm('pettycash.request', 'pettycash.approve', 'cashbook.view', 'cashbook.record');
  const seesAll = (req) => req.can('pettycash.approve') || req.can('cashbook.view') || req.can('cashbook.record');
  async function load(c, id, lock = false) {
    const r = (await c.query(`SELECT * FROM petty_cash_requests WHERE id = $1${lock ? ' FOR UPDATE' : ''}`, [id])).rows[0];
    if (!r) throw E.notFound('Petty cash request');
    return r;
  }

  app.get('/pettycash/requests', { onRequest: [A, ANY], schema: { querystring: obj({ status: { enum: ['pending', 'approved', 'rejected', 'given', 'settled', 'cancelled'] } }) } }, async (req) => withTx(ctx(req), async (c) => {
    const p = []; const w = [];
    if (!seesAll(req)) { p.push(req.auth.userId); w.push(`r.requested_by = $${p.length}`); }      // staff see only their own requests
    if (req.query.status) { p.push(req.query.status); w.push(`r.status = $${p.length}`); }
    const items = (await c.query(`${SELECT} ${w.length ? `WHERE ${w.join(' AND ')}` : ''} ORDER BY r.created_at DESC LIMIT 500`, p)).rows;
    const counts = (await c.query(`SELECT status, count(*)::int AS n, coalesce(sum(amount_kobo), 0)::bigint AS kobo FROM petty_cash_requests r
      ${seesAll(req) ? '' : 'WHERE r.requested_by = $1'} GROUP BY status`, seesAll(req) ? [] : [req.auth.userId])).rows;
    return { items, counts: Object.fromEntries(counts.map((x) => [x.status, { n: x.n, kobo: Number(x.kobo) }])), boxKobo: seesAll(req) ? await boxBalance(c) : null,
      can: { approve: req.can('pettycash.approve'), pay: req.can('cashbook.record'), ask: req.can('pettycash.request') } };
  }));

  app.post('/pettycash/requests', {
    onRequest: [A, app.perm('pettycash.request')], config: { rateLimit: { max: 20, timeWindow: '1 minute' } },
    schema: { body: obj({ purpose: str(300, 3), amountKobo: KOBO }, ['purpose', 'amountKobo']) },
  }, async (req, reply) => withTx(ctx(req), async (c) => withIdempotency(c, req, reply, 'pettycash.request', async () => {
    const no = await nextNo(c, req.auth.schoolId);
    const r = (await c.query(`INSERT INTO petty_cash_requests (school_id, ref_no, requested_by, purpose, amount_kobo) VALUES ($1,$2,$3,$4,$5) RETURNING id, ref_no, status`,
      [req.auth.schoolId, no, req.auth.userId, req.body.purpose.trim(), req.body.amountKobo])).rows[0];
    await audit(c, req, 'pettycash.requested', { type: 'petty_cash_request', id: r.id, meta: { refNo: no, amountKobo: req.body.amountKobo } });
    const approvers = (await c.query(`SELECT DISTINCT u.id FROM active_members u JOIN user_roles ur ON ur.user_id = u.id
      JOIN role_permissions rp ON rp.role_id = ur.role_id AND rp.permission_key = 'pettycash.approve' WHERE u.id <> $1 LIMIT 20`, [req.auth.userId])).rows.map((x) => x.id);
    await notify(c, req.auth.schoolId, approvers.slice(0, 20), { kind: 'finance', title: `Petty cash request ${no}: ${naira(req.body.amountKobo)}`, body: req.body.purpose.trim(), link: '#/petty-cash' });
    return r;
  })));

  app.post('/pettycash/requests/:id/decide', { onRequest: [A, app.perm('pettycash.approve')], schema: { params: idParams, body: obj({ approve: { type: 'boolean' }, note: { type: ['string', 'null'], maxLength: 300 } }, ['approve']) } },
    async (req) => withTx(ctx(req), async (c) => {
      const r = await load(c, req.params.id, true);
      if (r.status !== 'pending') throw E.conflict('This request was already decided.');
      if (r.requested_by === req.auth.userId) throw E.forbidden('Another person must approve your own request.');
      const note = (req.body.note || '').trim() || null;
      if (!req.body.approve && !note) throw E.bad('Say why the request is refused.', { field: 'note' });
      await c.query('UPDATE petty_cash_requests SET status = $2, decided_by = $3, decided_at = now(), decision_note = $4 WHERE id = $1', [r.id, req.body.approve ? 'approved' : 'rejected', req.auth.userId, note]);
      await audit(c, req, req.body.approve ? 'pettycash.approved' : 'pettycash.refused', { type: 'petty_cash_request', id: r.id, meta: { refNo: r.ref_no, amountKobo: r.amount_kobo, note } });
      await notify(c, req.auth.schoolId, [r.requested_by], { kind: 'finance', title: `Petty cash ${r.ref_no} ${req.body.approve ? 'approved' : 'refused'}`, body: note, link: '#/petty-cash' });
      return { ok: true, status: req.body.approve ? 'approved' : 'rejected' };
    }));

  app.post('/pettycash/requests/:id/cancel', { onRequest: [A, ANY], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const r = await load(c, req.params.id, true);
    if (r.requested_by !== req.auth.userId && !req.can('pettycash.approve')) throw E.notFound('Petty cash request');
    if (!['pending', 'approved'].includes(r.status)) throw E.conflict('Only a request that has not been paid out can be cancelled.');
    await c.query("UPDATE petty_cash_requests SET status = 'cancelled' WHERE id = $1", [r.id]);
    await audit(c, req, 'pettycash.cancelled', { type: 'petty_cash_request', id: r.id, meta: { refNo: r.ref_no } });
    return { ok: true };
  }));

  // hand the money out: an expense from the petty-cash box, in the category the cashier picks
  app.post('/pettycash/requests/:id/give', { onRequest: [A, app.perm('cashbook.record')], schema: { params: idParams, body: obj({ categoryId: uuid }, ['categoryId']) } },
    async (req, reply) => withTx(ctx(req), async (c) => withIdempotency(c, req, reply, 'pettycash.give', async () => {
      const r = await load(c, req.params.id, true);
      if (r.status !== 'approved') throw E.conflict(r.status === 'pending' ? 'This request has not been approved yet.' : 'This request cannot be paid out.');
      const cat = (await c.query('SELECT id, kind, active, name FROM cash_categories WHERE id = $1', [req.body.categoryId])).rows[0];
      if (!cat || cat.kind !== 'expense' || !cat.active) throw E.bad('Choose an expense category that is switched on.', { field: 'categoryId' });
      await lockPetty(c, req.auth.schoolId);
      const bal = await boxBalance(c);
      if (Number(r.amount_kobo) > bal) throw E.bad(`There is only ${naira(bal)} in petty cash. Put money into petty cash first.`);
      const who = (await c.query('SELECT full_name FROM users WHERE id = $1', [r.requested_by])).rows[0].full_name;
      const e = (await c.query(`INSERT INTO cash_entries (school_id, kind, category_id, amount_kobo, entry_date, method, reference, party, description, created_by)
        VALUES ($1,'expense',$2,$3,$4,'petty_cash',$5,$6,$7,$8) RETURNING id`, [req.auth.schoolId, cat.id, r.amount_kobo, await today(c, req.auth.schoolId), r.ref_no, who, `Petty cash: ${r.purpose}`.slice(0, 300), req.auth.userId])).rows[0];
      await c.query("UPDATE petty_cash_requests SET status = 'given', given_by = $2, given_at = now(), given_entry_id = $3 WHERE id = $1", [r.id, req.auth.userId, e.id]);
      await audit(c, req, 'pettycash.given', { type: 'petty_cash_request', id: r.id, meta: { refNo: r.ref_no, amountKobo: r.amount_kobo, category: cat.name } });
      await notify(c, req.auth.schoolId, [r.requested_by], { kind: 'finance', title: `Petty cash ${r.ref_no}: money handed out`, body: 'Bring the receipts and any change to the cashier.', link: '#/petty-cash' });
      return { ok: true, status: 'given', entryId: e.id };
    })));

  // settle: receipts + change come back; the books end up showing only what was really spent
  app.post('/pettycash/requests/:id/settle', { onRequest: [A, app.perm('cashbook.record')], schema: { params: idParams, body: obj({ spentKobo: { type: 'integer', minimum: 0, maximum: 100000000000 }, note: { type: ['string', 'null'], maxLength: 300 } }, ['spentKobo']) } },
    async (req) => withTx(ctx(req), async (c) => {
      const r = await load(c, req.params.id, true);
      if (r.status !== 'given') throw E.conflict('Only money that was handed out can be settled.');
      const spent = req.body.spentKobo; const amount = Number(r.amount_kobo);
      if (spent > amount) throw E.bad(`More than ${naira(amount)} cannot be spent from this request. Make a new request for the rest.`, { field: 'spentKobo' });
      const returned = amount - spent; const note = (req.body.note || '').trim() || null;
      await lockPetty(c, req.auth.schoolId);
      let spentEntry = r.given_entry_id;
      if (returned > 0) {
        const g = (await c.query('SELECT * FROM cash_entries WHERE id = $1 FOR UPDATE', [r.given_entry_id])).rows[0];
        await c.query('UPDATE cash_entries SET voided_at = now(), voided_by = $2, void_reason = $3 WHERE id = $1 AND voided_at IS NULL',
          [g.id, req.auth.userId, `Settled ${r.ref_no}: ${naira(spent)} spent, ${naira(returned)} change returned to petty cash`.slice(0, 300)]);
        spentEntry = null;
        if (spent > 0) {
          spentEntry = (await c.query(`INSERT INTO cash_entries (school_id, kind, category_id, amount_kobo, entry_date, method, reference, party, description, created_by)
            VALUES ($1,'expense',$2,$3,$4,'petty_cash',$5,$6,$7,$8) RETURNING id`, [req.auth.schoolId, g.category_id, spent, g.entry_date, r.ref_no, g.party, g.description, req.auth.userId])).rows[0].id;
        }
      }
      await c.query("UPDATE petty_cash_requests SET status = 'settled', spent_kobo = $2, returned_kobo = $3, spent_entry_id = $4, settled_by = $5, settled_at = now(), settle_note = $6 WHERE id = $1",
        [r.id, spent, returned, spentEntry, req.auth.userId, note]);
      await audit(c, req, 'pettycash.settled', { type: 'petty_cash_request', id: r.id, meta: { refNo: r.ref_no, spentKobo: spent, returnedKobo: returned } });
      return { ok: true, status: 'settled', spentKobo: spent, returnedKobo: returned, boxKobo: await boxBalance(c) };
    }));
};
