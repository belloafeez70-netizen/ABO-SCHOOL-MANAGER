'use strict';
// Results workflow: teacher enters → submits → reviewer approves (four-eyes) → publisher publishes (locked).
// Locked scores can only change through an approved correction request (DB trigger enforces the lock).
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, str, uuid, idParams } = require('../lib/schema');
const { ctx } = require('../auth/plugin');
const { audit, securityEvent } = require('../audit/audit');
const { notify } = require('../services/notify');
const R = require('../services/results');
const G = require('../services/grading');
const CUM = require('../services/cumulative');

async function usersWith(c, perm) {
  return (await c.query(`SELECT DISTINCT ur.user_id FROM user_roles ur JOIN role_permissions rp ON rp.role_id = ur.role_id
    JOIN active_members u ON u.id = ur.user_id WHERE rp.permission_key = $1`, [perm])).rows.map((r) => r.user_id);
}
async function loadSheet(c, id, lock = false) {
  const s = (await c.query(`SELECT a.*, s.name AS subject, cl.display_name AS class_name, cl.section FROM assessments a
    JOIN subjects s ON s.id = a.subject_id JOIN classes cl ON cl.id = a.class_id WHERE a.id = $1 ${lock ? 'FOR UPDATE OF a' : ''}`, [id])).rows[0];
  if (!s) throw E.notFound('Score sheet');
  return s;
}
async function canEnter(c, req, classId, subjectId) {
  if (req.can('results.enter_any')) return true;
  if (!req.can('results.enter') || !req.auth.staffId) return false;
  return (await c.query("SELECT 1 FROM teacher_class_access WHERE class_id = $1 AND subject_id = $2 AND staff_id = $3 AND role IN ('subject_teacher','assistant')", [classId, subjectId, req.auth.staffId])).rowCount > 0;
}
async function mustExist(c, table, id, label) {
  const r = await c.query(`SELECT 1 FROM ${table} WHERE id = $1`, [id]);      // RLS scopes this to the caller's school
  if (!r.rowCount) throw E.notFound(label);
}
async function studentAccess(req, studentId) {
  if (req.can('results.view')) return 'staff';
  if (req.can('results.view_own') && studentId === req.auth.studentId) return 'self';
  if (req.can('results.view_children') && req.auth.children.includes(studentId)) return 'parent';
  throw E.notFound('Student');       // don't reveal existence of other students (BOLA)
}

module.exports = async function resultRoutes(app) {
  const A = app.authenticate;
  const ENTER = app.perm('results.enter', 'results.enter_any');

  app.get('/results/sheets', { onRequest: [A, app.perm('results.view', 'results.enter', 'results.enter_any')], schema: { querystring: obj({ termId: uuid, classId: uuid }, ['termId', 'classId']) } }, async (req) =>
    withTx(ctx(req), async (c) => {
      const rows = (await c.query(`SELECT cs.subject_id, s.name AS subject, cs.teacher_id, st.full_name AS teacher, a.id AS sheet_id, COALESCE(a.status, 'not_started') AS status, a.version,
          a.review_note, a.submitted_at, a.approved_at, a.published_at, (SELECT count(DISTINCT student_id)::int FROM assessment_scores x WHERE x.sheet_id = a.id) AS scored
        FROM class_subjects cs JOIN subjects s ON s.id = cs.subject_id LEFT JOIN staff st ON st.id = cs.teacher_id
        LEFT JOIN assessments a ON a.class_id = cs.class_id AND a.subject_id = cs.subject_id AND a.term_id = $1
        WHERE cs.class_id = $2 ORDER BY s.name`, [req.query.termId, req.query.classId])).rows;
      const mine = req.auth.staffId ? new Set((await c.query("SELECT subject_id FROM teacher_class_access WHERE class_id = $1 AND staff_id = $2 AND subject_id IS NOT NULL", [req.query.classId, req.auth.staffId])).rows.map((x) => x.subject_id)) : new Set();
      for (const r of rows) r.can_enter = req.can('results.enter_any') || (req.can('results.enter') && mine.has(r.subject_id));
      const size = (await R.roster(c, req.query.termId, req.query.classId)).length;
      return { items: rows, classSize: size };
    }));

  app.post('/results/sheets', { onRequest: [A, ENTER], schema: { body: obj({ termId: uuid, classId: uuid, subjectId: uuid }, ['termId', 'classId', 'subjectId']) } }, async (req) =>
    withTx(ctx(req), async (c) => {
      const { termId, classId, subjectId } = req.body;
      await mustExist(c, 'terms', termId, 'Term'); await mustExist(c, 'classes', classId, 'Class'); await mustExist(c, 'subjects', subjectId, 'Subject');
      if (!(await canEnter(c, req, classId, subjectId))) throw E.forbidden('This subject is not assigned to you for this class.');
      const assigned = await c.query('SELECT 1 FROM class_subjects WHERE class_id = $1 AND subject_id = $2', [classId, subjectId]);
      if (!assigned.rowCount) throw E.bad('This subject is not offered in this class.');
      const st = await R.settings(c);
      const r = await c.query(`INSERT INTO assessments (school_id, term_id, class_id, subject_id, components, created_by) VALUES ($1,$2,$3,$4,$5,$6)
        ON CONFLICT (term_id, class_id, subject_id) DO UPDATE SET updated_at = assessments.updated_at RETURNING id, (xmax = 0) AS created`,
      [req.auth.schoolId, termId, classId, subjectId, JSON.stringify(st.assessment_components), req.auth.userId]);
      if (r.rows[0].created) await audit(c, req, 'results.sheet_created', { type: 'assessment', id: r.rows[0].id });
      return { id: r.rows[0].id };
    }));

  app.get('/results/sheets/:id', { onRequest: [A, app.perm('results.view', 'results.enter', 'results.enter_any')], schema: { params: idParams } }, async (req) =>
    withTx(ctx(req), async (c) => {
      const sh = await loadSheet(c, req.params.id);
      const mayEnter = await canEnter(c, req, sh.class_id, sh.subject_id);
      if (!req.can('results.view') && !mayEnter) throw E.notFound('Score sheet');
      const students = await R.roster(c, sh.term_id, sh.class_id);
      const scores = (await c.query('SELECT student_id, component_key, score FROM assessment_scores WHERE sheet_id = $1', [sh.id])).rows;
      const computed = (await c.query('SELECT student_id, total, grade, remark, subject_position FROM examination_results WHERE sheet_id = $1', [sh.id])).rows;
      const byS = new Map(); for (const s of scores) { if (!byS.has(s.student_id)) byS.set(s.student_id, {}); byS.get(s.student_id)[s.component_key] = s.score; }
      const cm = new Map(computed.map((x) => [x.student_id, x]));
      return {
        sheet: { id: sh.id, termId: sh.term_id, classId: sh.class_id, subjectId: sh.subject_id, subject: sh.subject, className: sh.class_name, components: sh.components,
          status: sh.status, version: sh.version, reviewNote: sh.review_note, submittedAt: sh.submitted_at, approvedAt: sh.approved_at, publishedAt: sh.published_at },
        canEdit: mayEnter && sh.status === 'draft', canSubmit: mayEnter && sh.status === 'draft',
        canReview: req.can('results.review') && sh.status === 'submitted' && sh.submitted_by !== req.auth.userId,
        canApprove: req.can('results.approve') && sh.submitted_by !== req.auth.userId && (sh.status === 'reviewed' || (sh.status === 'submitted' && (await R.settings(c)).results_require_review === false)),
        rows: students.map((s) => ({ studentId: s.id, name: `${s.last_name} ${s.first_name}`, admissionNo: s.admission_no, scores: byS.get(s.id) || {}, result: cm.get(s.id) || null })),
        passMark: Number((await R.settings(c)).pass_mark),
      };
    }));

  app.put('/results/sheets/:id/scores', {
    onRequest: [A, ENTER],
    schema: { params: idParams, body: obj({ entries: { type: 'array', minItems: 1, maxItems: 500, items: obj({ studentId: uuid,
      scores: { type: 'object', maxProperties: 6, propertyNames: { pattern: '^[a-z0-9_]{1,20}$' }, additionalProperties: { type: ['number', 'null'], minimum: 0, maximum: 100 } } }, ['studentId', 'scores']) },
    expectedVersion: { type: 'integer', minimum: 1 } }, ['entries']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const sh = await loadSheet(c, req.params.id, true);
    if (!(await canEnter(c, req, sh.class_id, sh.subject_id))) throw E.forbidden('This subject is not assigned to you for this class.');
    if (sh.status !== 'draft') throw E.locked(sh.status === 'submitted' ? 'This sheet has been submitted for review and is read-only.' : 'These results are approved/published and locked. Use a correction request.');
    if (req.body.expectedVersion && req.body.expectedVersion !== sh.version) throw E.conflict('This sheet changed since you opened it. Reload and try again.');
    const comp = new Map(sh.components.map((x) => [x.key, Number(x.max)]));
    const allowed = new Set((await R.roster(c, sh.term_id, sh.class_id)).map((s) => s.id));
    const rows = [];
    for (const e of req.body.entries) {
      if (!allowed.has(e.studentId)) throw E.bad('One or more students are not in this class.');
      for (const [k, v] of Object.entries(e.scores)) {
        if (!comp.has(k)) throw E.bad(`Unknown assessment component "${k}".`);
        if (v !== null && (v < 0 || v > comp.get(k))) throw E.bad(`${k.toUpperCase()} must be between 0 and ${comp.get(k)}.`);
        rows.push({ student_id: e.studentId, component_key: k, score: v });
      }
    }
    await c.query(`INSERT INTO assessment_scores (school_id, sheet_id, student_id, component_key, score, entered_by)
      SELECT $1, $2, x.student_id, x.component_key, x.score, $3 FROM json_to_recordset($4::json) AS x(student_id uuid, component_key text, score numeric)
      ON CONFLICT (sheet_id, student_id, component_key) DO UPDATE SET score = EXCLUDED.score, entered_by = EXCLUDED.entered_by
      WHERE assessment_scores.score IS DISTINCT FROM EXCLUDED.score`,               // unchanged cells are not rewritten
    [req.auth.schoolId, sh.id, req.auth.userId, JSON.stringify(rows)]);
    const computed = await R.recomputeSheet(c, sh.id);
    const version = (await c.query('UPDATE assessments SET version = version + 1 WHERE id = $1 RETURNING version', [sh.id])).rows[0].version;   // optimistic-lock token
    await audit(c, req, 'results.scores_entered', { type: 'assessment', id: sh.id, meta: { students: req.body.entries.length, cells: rows.length } });
    return { ok: true, computed, version };
  }));

  app.post('/results/sheets/:id/submit', { onRequest: [A, ENTER], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const sh = await loadSheet(c, req.params.id, true);
    if (!(await canEnter(c, req, sh.class_id, sh.subject_id))) throw E.forbidden();
    if (sh.status !== 'draft') throw E.conflict('Only draft sheets can be submitted.');
    const n = (await c.query('SELECT count(*)::int AS n FROM examination_results WHERE sheet_id = $1', [sh.id])).rows[0].n;
    if (!n) throw E.bad('Enter at least one score before submitting.');
    await c.query("UPDATE assessments SET status = 'submitted', submitted_by = $2, submitted_at = now(), review_note = NULL WHERE id = $1", [sh.id, req.auth.userId]);
    await notify(c, req.auth.schoolId, (await usersWith(c, 'results.approve')).filter((u) => u !== req.auth.userId), { kind: 'results', title: `${sh.subject} (${sh.class_name}) submitted for review`, link: `#/results/sheet/${sh.id}` });
    await audit(c, req, 'results.sheet_submitted', { type: 'assessment', id: sh.id, meta: { students: n } });
    return { ok: true, status: 'submitted' };
  }));

  // SUBMITTED → REVIEWED (results.review) → APPROVED (results.approve). Neither step may be done by the submitter.
  // Schools may switch off the separate review step (school_settings.results_require_review = false).
  app.post('/results/sheets/:id/review', {
    onRequest: [A, app.perm('results.review', 'results.approve')],
    schema: { params: idParams, body: obj({ action: { enum: ['review', 'approve', 'return'] }, note: { type: 'string', maxLength: 500 } }, ['action']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const sh = await loadSheet(c, req.params.id, true);
    const { action } = req.body;
    const requireReview = (await R.settings(c)).results_require_review !== false;
    if (sh.submitted_by === req.auth.userId) {
      securityEvent({ schoolId: req.auth.schoolId, userId: req.auth.userId, kind: 'self_approval_attempt', severity: 'medium', detail: { sheet: sh.id, action }, ip: req.ip });
      throw E.forbidden('You cannot review or approve a sheet you submitted yourself (four-eyes rule).');
    }
    if (action === 'return') {
      if (!['submitted', 'reviewed'].includes(sh.status)) throw E.conflict('Only submitted or reviewed sheets can be returned.');
      if (!req.body.note) throw E.bad('Add a note explaining what needs to change.');
      await c.query("UPDATE assessments SET status = 'draft', review_note = $2, submitted_at = NULL, submitted_by = NULL, reviewed_by = NULL, reviewed_at = NULL, version = version + 1 WHERE id = $1", [sh.id, req.body.note]);
    } else if (action === 'review') {
      if (!req.can('results.review')) throw E.forbidden();
      if (sh.status !== 'submitted') throw E.conflict('Only submitted sheets can be reviewed.');
      await c.query("UPDATE assessments SET status = 'reviewed', reviewed_by = $2, reviewed_at = now(), review_note = $3 WHERE id = $1", [sh.id, req.auth.userId, req.body.note || null]);
    } else {
      if (!req.can('results.approve')) throw E.forbidden();
      const allowed = requireReview ? ['reviewed'] : ['submitted', 'reviewed'];
      if (!allowed.includes(sh.status)) throw E.conflict(requireReview ? 'This sheet must be reviewed before it can be approved.' : 'Only submitted sheets can be approved.');
      await c.query("UPDATE assessments SET status = 'approved', approved_by = $2, approved_at = now(), review_note = COALESCE($3, review_note) WHERE id = $1", [sh.id, req.auth.userId, req.body.note || null]);
    }
    const next = action === 'return' ? 'draft' : action === 'review' ? 'reviewed' : 'approved';
    if (sh.submitted_by) await notify(c, req.auth.schoolId, [sh.submitted_by], { kind: 'results', title: `${sh.subject} (${sh.class_name}) ${next === 'draft' ? 'returned for changes' : next}`, body: req.body.note || null, link: `#/results/sheet/${sh.id}` });
    if (next === 'reviewed') await notify(c, req.auth.schoolId, (await usersWith(c, 'results.approve')).filter((u) => u !== req.auth.userId && u !== sh.submitted_by), { kind: 'results', title: `${sh.subject} (${sh.class_name}) reviewed — ready for approval`, link: `#/results/sheet/${sh.id}` });
    await audit(c, req, { return: 'results.sheet_returned', review: 'results.sheet_reviewed', approve: 'results.sheet_approved' }[action], { type: 'assessment', id: sh.id, meta: { note: req.body.note || null, from: sh.status } });
    return { ok: true, status: next };
  }));

  app.post('/results/publish', { onRequest: [A, app.perm('results.publish')], schema: { body: obj({ termId: uuid, classId: uuid }, ['termId', 'classId']) } }, async (req) =>
    withTx(ctx(req), async (c) => {
      const { termId, classId } = req.body;
      await mustExist(c, 'terms', termId, 'Term'); await mustExist(c, 'classes', classId, 'Class');
      await c.query('SELECT pg_advisory_xact_lock(hashtextextended($1, 0))', [`publish:${termId}:${classId}`]);
      const sheets = (await c.query('SELECT id, status FROM assessments WHERE term_id = $1 AND class_id = $2 FOR UPDATE', [termId, classId])).rows;
      if (!sheets.length) throw E.bad('There are no score sheets for this class and term.');
      const pending = sheets.filter((s) => s.status !== 'approved' && s.status !== 'published');   // draft/submitted/reviewed block publication
      if (pending.length) throw E.conflict(`${pending.length} subject sheet(s) are not yet approved.`);
      await c.query("UPDATE assessments SET status = 'published', published_by = $3, published_at = now() WHERE term_id = $1 AND class_id = $2 AND status = 'approved'", [termId, classId, req.auth.userId]);
      const rows = await R.computeClassTerm(c, termId, classId, { publish: true });
      const snap = await R.broadsheet(c, termId, classId);
      const v = (await c.query('SELECT COALESCE(max(version), 0) + 1 AS v FROM broadsheets WHERE term_id = $1 AND class_id = $2', [termId, classId])).rows[0].v;
      await c.query('INSERT INTO broadsheets (school_id, term_id, class_id, version, snapshot, published_by) VALUES ($1,$2,$3,$4,$5,$6)', [req.auth.schoolId, termId, classId, v, snap, req.auth.userId]);
      await c.query(`INSERT INTO report_cards (school_id, term_id, student_id) SELECT $1, $2, x FROM unnest($3::uuid[]) AS x ON CONFLICT (term_id, student_id) DO NOTHING`, [req.auth.schoolId, termId, rows.map((r) => r.studentId)]);
      const ids = rows.map((r) => r.studentId);
      const recipients = (await c.query(`SELECT s.user_id FROM students s WHERE s.id = ANY($1::uuid[]) AND s.user_id IS NOT NULL
        UNION SELECT g.user_id FROM student_guardians sg JOIN guardians g ON g.id = sg.guardian_id WHERE sg.student_id = ANY($1::uuid[]) AND g.user_id IS NOT NULL`, [ids])).rows.map((r) => r.user_id);
      await notify(c, req.auth.schoolId, recipients, { kind: 'results', title: 'Term results are now available', link: '#/my-results' });
      await audit(c, req, 'results.published', { type: 'class_term', id: `${classId}:${termId}`, meta: { students: rows.length, subjects: sheets.length, broadsheetVersion: v } });
      return { ok: true, students: rows.length, broadsheetVersion: v };
    }));

  app.get('/results/broadsheet', { onRequest: [A, app.perm('results.view')], config: { rateLimit: { max: 30, timeWindow: '1 minute' } }, schema: { querystring: obj({ termId: uuid, classId: uuid }, ['termId', 'classId']) } }, async (req) =>
    withTx({ ...ctx(req), readOnly: !!req.auth.support }, async (c) => {
      await mustExist(c, 'terms', req.query.termId, 'Class or term'); await mustExist(c, 'classes', req.query.classId, 'Class or term');
      const published = (await c.query('SELECT 1 FROM result_summaries WHERE term_id = $1 AND class_id = $2 AND published LIMIT 1', [req.query.termId, req.query.classId])).rowCount > 0;
      if (!published && !req.auth.support) await R.computeClassTerm(c, req.query.termId, req.query.classId, { publish: false });   // provisional preview
      const data = await R.broadsheet(c, req.query.termId, req.query.classId);
      const meta = (await c.query(`SELECT t.name AS term, se.name AS session, cl.display_name AS class_name FROM terms t JOIN academic_sessions se ON se.id = t.session_id, classes cl WHERE t.id = $1 AND cl.id = $2`, [req.query.termId, req.query.classId])).rows[0];
      if (!meta) throw E.notFound('Class or term');
      return { ...meta, provisional: !published, ...data };
    }));

  app.get('/results/broadsheets/archive', { onRequest: [A, app.perm('results.view')], schema: { querystring: obj({ classId: uuid }) } }, async (req) => withTx(ctx(req), async (c) => ({
    items: (await c.query(`SELECT b.id, b.version, b.published_at, t.name AS term, se.name AS session, cl.display_name AS class_name FROM broadsheets b
      JOIN terms t ON t.id = b.term_id JOIN academic_sessions se ON se.id = t.session_id JOIN classes cl ON cl.id = b.class_id
      ${req.query.classId ? 'WHERE b.class_id = $1' : ''} ORDER BY b.published_at DESC LIMIT 200`, req.query.classId ? [req.query.classId] : [])).rows,
  })));

  // ── student report card (published only for students/parents) ──
  app.get('/results/student/:id', { onRequest: [A, app.perm('results.view', 'results.view_own', 'results.view_children')], schema: { params: idParams, querystring: obj({ termId: uuid }) } }, async (req) => {
    const who = await studentAccess(req, req.params.id);
    return withTx(ctx(req), async (c) => {
      await mustExist(c, 'students', req.params.id, 'Student');
      const termId = req.query.termId || ((await c.query('SELECT id FROM terms WHERE is_current LIMIT 1')).rows[0] || {}).id;
      if (!termId) throw E.notFound('Term');
      const tr = (await c.query(`SELECT tr.*, cl.display_name AS class_name, cl.section FROM result_summaries tr JOIN classes cl ON cl.id = tr.class_id WHERE tr.term_id = $1 AND tr.student_id = $2`, [termId, req.params.id])).rows[0];
      // the terms this learner has a report card for (portals: published only) — lets parents open past terms
      const resultTerms = (await c.query(`SELECT t.id, t.name, se.name AS session FROM result_summaries rs JOIN terms t ON t.id = rs.term_id JOIN academic_sessions se ON se.id = t.session_id
        WHERE rs.student_id = $1 ${who === 'staff' ? '' : 'AND rs.published'} ORDER BY se.starts_on DESC NULLS LAST, se.name DESC, t.name DESC LIMIT 30`, [req.params.id])).rows;
      if (who !== 'staff' && (!tr || !tr.published)) return { available: false, message: 'Results for this term have not been published yet.', termId, resultTerms };
      const subjects = (await c.query(`SELECT s.name AS subject, a.components, er.total, er.grade, er.remark, er.subject_position, a.status,
          COALESCE((SELECT json_object_agg(x.component_key, x.score) FROM assessment_scores x WHERE x.sheet_id = a.id AND x.student_id = $2), '{}') AS scores,
          (SELECT round(avg(e2.total), 2) FROM examination_results e2 WHERE e2.sheet_id = a.id) AS class_average
        FROM examination_results er JOIN assessments a ON a.id = er.sheet_id JOIN subjects s ON s.id = a.subject_id
        WHERE a.term_id = $1 AND er.student_id = $2 ${who === 'staff' ? '' : "AND a.status = 'published'"} ORDER BY s.name`, [termId, req.params.id])).rows;
      const student = (await c.query('SELECT id, first_name, last_name, other_names, admission_no, gender, date_of_birth, passport_file_id FROM students WHERE id = $1', [req.params.id])).rows[0];
      const rc = (await c.query('SELECT teacher_comment, head_comment, domains, days_present, days_absent FROM report_cards WHERE term_id = $1 AND student_id = $2', [termId, req.params.id])).rows[0] || {};
      const att = (await c.query(`SELECT count(*) FILTER (WHERE status IN ('present','late'))::int AS present, count(*) FILTER (WHERE status = 'absent')::int AS absent FROM attendance_records WHERE student_id = $1 AND term_id = $2`, [req.params.id, termId])).rows[0];
      const term = (await c.query('SELECT t.name, t.days_open, t.next_term_begins, se.name AS session FROM terms t JOIN academic_sessions se ON se.id = t.session_id WHERE t.id = $1', [termId])).rows[0];
      const school = (await c.query('SELECT name, motto, address, phone, email, logo_file_id, school_type, brand_color, head_name, head_title, head_signature_file_id FROM schools LIMIT 1')).rows[0];
      const st = await R.settings(c);
      // results so far this session (2nd/3rd term report cards); parents and pupils only ever see published terms
      let cumulative = null;
      const classId = tr ? tr.class_id : ((await c.query('SELECT e.class_id FROM student_enrollments e JOIN terms t ON t.session_id = e.session_id AND t.id = $1 WHERE e.student_id = $2 LIMIT 1', [termId, req.params.id])).rows[0] || {}).class_id;
      if (classId && term && term.name !== '1ST' && !(st.report_card && st.report_card.showCumulative === false)) {
        cumulative = CUM.forStudent(await CUM.classCumulative(c, termId, classId, { publishedOnly: who !== 'staff' }), req.params.id);
        if (cumulative && cumulative.terms.length < 2) cumulative = null;
      }
      return { available: true, provisional: !tr || !tr.published, student, term, school, summary: tr || null, subjects, reportCard: rc, attendance: att,
        grading: st.grading, reportSettings: st.report_card, ordinalPosition: tr && tr.position ? G.ordinal(tr.position) : null, cumulative, termId, resultTerms };
    });
  });

  app.put('/results/report-cards/:id', {
    onRequest: [A, app.perm('results.enter', 'results.enter_any', 'results.approve')],
    schema: { params: idParams, body: obj({ termId: uuid, teacherComment: { type: ['string', 'null'], maxLength: 600 }, headComment: { type: ['string', 'null'], maxLength: 600 },
      domains: { type: 'object', maxProperties: 20, additionalProperties: { type: 'integer', minimum: 1, maximum: 5 } }, daysPresent: { type: ['integer', 'null'], minimum: 0, maximum: 366 }, daysAbsent: { type: ['integer', 'null'], minimum: 0, maximum: 366 } }, ['termId']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const b = req.body;
    await mustExist(c, 'students', req.params.id, 'Student'); await mustExist(c, 'terms', b.termId, 'Term');
    if (b.headComment !== undefined && !req.can('results.approve')) throw E.forbidden('Only reviewers can write the head/principal comment.');
    if ((b.teacherComment !== undefined || b.domains || b.daysPresent !== undefined) && !req.can('results.enter_any')) {
      const own = await c.query(`SELECT 1 FROM terms t JOIN student_enrollments e ON e.session_id = t.session_id AND e.student_id = $2 JOIN classes cl ON cl.id = e.class_id AND cl.form_teacher_id = $3 WHERE t.id = $1`,
        [b.termId, req.params.id, req.auth.staffId]);
      if (!own.rowCount) throw E.forbidden('Only the form teacher can write the class teacher comment.');
    }
    await c.query(`INSERT INTO report_cards (school_id, term_id, student_id, teacher_comment, head_comment, domains, days_present, days_absent, updated_by, updated_at)
      VALUES ($1,$2,$3,$4,$5,COALESCE($6,'{}'::jsonb),$7,$8,$9, now())
      ON CONFLICT (term_id, student_id) DO UPDATE SET teacher_comment = CASE WHEN $10 THEN EXCLUDED.teacher_comment ELSE report_cards.teacher_comment END,
        head_comment = CASE WHEN $11 THEN EXCLUDED.head_comment ELSE report_cards.head_comment END, domains = COALESCE($6, report_cards.domains),
        days_present = CASE WHEN $12 THEN EXCLUDED.days_present ELSE report_cards.days_present END, days_absent = CASE WHEN $12 THEN EXCLUDED.days_absent ELSE report_cards.days_absent END,
        updated_by = EXCLUDED.updated_by, updated_at = now()`,
    [req.auth.schoolId, b.termId, req.params.id, b.teacherComment ?? null, b.headComment ?? null, b.domains || null, b.daysPresent ?? null, b.daysAbsent ?? null, req.auth.userId,
      b.teacherComment !== undefined, b.headComment !== undefined, b.daysPresent !== undefined || b.daysAbsent !== undefined]);
    await audit(c, req, 'results.report_card_updated', { type: 'student', id: req.params.id, meta: { termId: b.termId, fields: Object.keys(b) } });
    return { ok: true };
  }));

  // ── corrections (the only path to change locked results) ──
  app.post('/results/corrections', {
    onRequest: [A, app.perm('results.update')],
    schema: { body: obj({ sheetId: uuid, studentId: uuid, componentKey: { type: 'string', pattern: '^[a-z0-9_]{1,20}$' }, newScore: { type: 'number', minimum: 0, maximum: 100 }, reason: str(500, 5) }, ['sheetId', 'studentId', 'componentKey', 'newScore', 'reason']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const b = req.body;
    const sh = await loadSheet(c, b.sheetId);
    if (!['approved', 'published'].includes(sh.status)) throw E.bad('Draft sheets can be edited directly; corrections are for locked results.');
    if (!req.can('results.approve') && !(await canEnter(c, req, sh.class_id, sh.subject_id))) throw E.forbidden();
    const comp = sh.components.find((x) => x.key === b.componentKey);
    if (!comp) throw E.bad('Unknown assessment component.');
    if (b.newScore > comp.max) throw E.bad(`Score cannot exceed ${comp.max}.`);
    const old = (await c.query('SELECT score FROM assessment_scores WHERE sheet_id = $1 AND student_id = $2 AND component_key = $3', [sh.id, b.studentId, b.componentKey])).rows[0];
    const r = (await c.query(`INSERT INTO result_corrections (school_id, sheet_id, student_id, component_key, old_score, new_score, reason, requested_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
      [req.auth.schoolId, sh.id, b.studentId, b.componentKey, old ? old.score : null, b.newScore, b.reason, req.auth.userId])).rows[0];
    await notify(c, req.auth.schoolId, (await usersWith(c, 'results.approve')).filter((u) => u !== req.auth.userId), { kind: 'results', title: `Correction requested: ${sh.subject} (${sh.class_name})`, link: '#/corrections' });
    await audit(c, req, 'results.correction_requested', { type: 'result_correction', id: r.id, meta: { sheet: sh.id, student: b.studentId, component: b.componentKey, from: old ? old.score : null, to: b.newScore } });
    return { id: r.id, status: 'pending' };
  }));

  app.get('/results/corrections', { onRequest: [A, app.perm('results.update', 'results.approve')], schema: { querystring: obj({ status: { enum: ['pending', 'approved', 'rejected'] } }) } }, async (req) =>
    withTx(ctx(req), async (c) => ({
      items: (await c.query(`SELECT rc.id, rc.status, rc.component_key, rc.old_score, rc.new_score, rc.reason, rc.requested_at, rc.reviewed_at, rc.review_note,
          s.first_name || ' ' || s.last_name AS student, sub.name AS subject, cl.display_name AS class_name, ru.full_name AS requested_by_name, (rc.requested_by = $2) AS mine
        FROM result_corrections rc JOIN students s ON s.id = rc.student_id JOIN assessments a ON a.id = rc.sheet_id JOIN subjects sub ON sub.id = a.subject_id
        JOIN classes cl ON cl.id = a.class_id LEFT JOIN users ru ON ru.id = rc.requested_by
        WHERE ($1::text IS NULL OR rc.status = $1) ${req.can('results.approve') ? '' : 'AND rc.requested_by = $2'} ORDER BY rc.requested_at DESC LIMIT 200`, [req.query.status || null, req.auth.userId])).rows,
    })));

  app.post('/results/corrections/:id/review', {
    onRequest: [A, app.perm('results.approve')],
    schema: { params: idParams, body: obj({ action: { enum: ['approve', 'reject'] }, note: { type: 'string', maxLength: 500 } }, ['action']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const rc = (await c.query('SELECT * FROM result_corrections WHERE id = $1 FOR UPDATE', [req.params.id])).rows[0];
    if (!rc) throw E.notFound('Correction');
    if (rc.status !== 'pending') throw E.conflict('This correction has already been reviewed.');
    if (rc.requested_by === req.auth.userId) throw E.forbidden('You cannot approve your own correction request (four-eyes rule).');
    await c.query('UPDATE result_corrections SET status = $2, reviewed_by = $3, reviewed_at = now(), review_note = $4 WHERE id = $1', [rc.id, req.body.action === 'approve' ? 'approved' : 'rejected', req.auth.userId, req.body.note || null]);
    let recomputed = false;
    if (req.body.action === 'approve') {
      const sh = await loadSheet(c, rc.sheet_id, true);
      await c.query("SELECT set_config('app.correction_sheet', $1, true)", [sh.id]);        // narrowly unlock THIS sheet for THIS transaction
      await c.query(`INSERT INTO assessment_scores (school_id, sheet_id, student_id, component_key, score, entered_by) VALUES ($1,$2,$3,$4,$5,$6)
        ON CONFLICT (sheet_id, student_id, component_key) DO UPDATE SET score = EXCLUDED.score, entered_by = EXCLUDED.entered_by`, [req.auth.schoolId, sh.id, rc.student_id, rc.component_key, rc.new_score, req.auth.userId]);
      await c.query("SELECT set_config('app.correction_sheet', '', true)");
      await R.recomputeSheet(c, sh.id);
      await c.query('UPDATE assessments SET version = version + 1 WHERE id = $1', [sh.id]);
      if (sh.status === 'published') {
        await R.computeClassTerm(c, sh.term_id, sh.class_id, { publish: true });
        const snap = await R.broadsheet(c, sh.term_id, sh.class_id);
        const v = (await c.query('SELECT COALESCE(max(version), 0) + 1 AS v FROM broadsheets WHERE term_id = $1 AND class_id = $2', [sh.term_id, sh.class_id])).rows[0].v;
        await c.query('INSERT INTO broadsheets (school_id, term_id, class_id, version, snapshot, published_by) VALUES ($1,$2,$3,$4,$5,$6)', [req.auth.schoolId, sh.term_id, sh.class_id, v, snap, req.auth.userId]);
      }
      recomputed = true;
    }
    await notify(c, req.auth.schoolId, [rc.requested_by], { kind: 'results', title: `Correction ${req.body.action === 'approve' ? 'approved and applied' : 'rejected'}`, body: req.body.note || null, link: '#/corrections' });
    await audit(c, req, req.body.action === 'approve' ? 'results.correction_applied' : 'results.correction_rejected', { type: 'result_correction', id: rc.id, meta: { from: rc.old_score, to: rc.new_score, note: req.body.note || null } });
    return { ok: true, recomputed };
  }));

  app.get('/results/sheets/:id/history', { onRequest: [A, app.perm('results.approve', 'audit_logs.view')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => ({
    items: (await mustExist(c, 'assessments', req.params.id, 'Score sheet'), await c.query(`SELECT h.id, h.component_key, h.old_score, h.new_score, h.changed_at, h.via_correction, s.first_name || ' ' || s.last_name AS student, u.full_name AS changed_by
      FROM assessment_score_history h JOIN students s ON s.id = h.student_id LEFT JOIN users u ON u.id = h.changed_by WHERE h.sheet_id = $1 ORDER BY h.changed_at DESC LIMIT 500`, [req.params.id])).rows,
  })));
};
