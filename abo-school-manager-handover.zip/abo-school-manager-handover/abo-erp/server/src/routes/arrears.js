'use strict';
// Old debts — the offline edition's "Old Debts" page, on the server (027). Fees a learner still owed from before (last
// term, or from the school's previous system) become ONE "brought forward" invoice per learner:
//   • paste or upload "admission number (or full name), amount, note" → preview shows who was found → import;
//   • parents see the invoice in their portal and can pay it like any other (cash, transfer or online);
//   • the same old debt can never be billed twice (one open brought-forward invoice per learner, enforced by the database);
//   • a wrong one is voided with a reason (like every invoice), never deleted.
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, str } = require('../lib/schema');
const { ctx } = require('../auth/plugin');
const { audit } = require('../audit/audit');
const { withIdempotency } = require('../lib/idempotency');

const DESC = 'Fees owed from before (brought forward)';
const MAX_KOBO = 100000000000;
const rowsSchema = { type: 'array', minItems: 1, maxItems: 2000,
  items: obj({ ref: str(120, 1), amountKobo: { type: 'integer', minimum: 1, maximum: MAX_KOBO }, note: { type: ['string', 'null'], maxLength: 300 } }, ['ref', 'amountKobo']) };
const norm = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9/ -]/g, ' ').replace(/\s+/g, ' ').trim();

async function nextNo(c, schoolId) {
  const y = new Date().getFullYear();
  const r = (await c.query(`INSERT INTO doc_counters (school_id, kind, year, last_no) VALUES ($1,'arrears',$2,1)
    ON CONFLICT (school_id, kind, year) DO UPDATE SET last_no = doc_counters.last_no + 1 RETURNING last_no`, [schoolId, y])).rows[0].last_no;
  return `BFW-${y}-${String(r).padStart(6, '0')}`;
}

// find each line's learner: admission number first, then the full name (either order); a name shared by two learners is
// never guessed — the school must use the admission number for those
async function matchRows(c, rows) {
  const students = (await c.query(`SELECT s.id, s.admission_no, s.first_name, s.last_name,
      (SELECT cl.display_name FROM student_enrollments e JOIN academic_sessions se ON se.id = e.session_id AND se.is_current JOIN classes cl ON cl.id = e.class_id
        WHERE e.student_id = s.id AND e.status = 'active' LIMIT 1) AS class_name
    FROM students s WHERE s.deleted_at IS NULL`)).rows;
  const byAdm = new Map(); const byName = new Map();
  for (const s of students) {
    if (s.admission_no) byAdm.set(norm(s.admission_no), s);
    for (const k of [norm(`${s.first_name} ${s.last_name}`), norm(`${s.last_name} ${s.first_name}`)]) byName.set(k, (byName.get(k) || []).concat(s));
  }
  const open = new Set((await c.query("SELECT student_id FROM invoices WHERE kind = 'brought_forward' AND status <> 'void'")).rows.map((r) => r.student_id));
  const seen = new Set(); let line = 0;
  return rows.map((r) => {
    line++;
    const out = { line, ref: r.ref.trim(), amountKobo: r.amountKobo, note: (r.note || '').trim() || null, status: 'ok', studentId: null, name: null, admissionNo: null, className: null };
    let s = byAdm.get(norm(r.ref));
    if (!s) {
      const list = [...new Map((byName.get(norm(r.ref)) || []).map((x) => [x.id, x])).values()];
      if (list.length > 1) { out.status = 'ambiguous'; return out; }
      s = list[0];
    }
    if (!s) { out.status = 'not_found'; return out; }
    Object.assign(out, { studentId: s.id, name: `${s.last_name} ${s.first_name}`.trim(), admissionNo: s.admission_no, className: s.class_name });
    if (open.has(s.id)) out.status = 'exists';
    else if (seen.has(s.id)) out.status = 'duplicate';
    seen.add(s.id);
    return out;
  });
}
const summary = (items) => {
  const ok = items.filter((i) => i.status === 'ok');
  return { rows: items.length, ready: ok.length, totalKobo: ok.reduce((a, i) => a + i.amountKobo, 0),
    notFound: items.filter((i) => i.status === 'not_found').length, ambiguous: items.filter((i) => i.status === 'ambiguous').length,
    alreadyBilled: items.filter((i) => i.status === 'exists').length, duplicates: items.filter((i) => i.status === 'duplicate').length };
};

module.exports = async function arrearsRoutes(app) {
  const A = app.authenticate;

  app.get('/fees/arrears', { onRequest: [A, app.perm('fees.view')] }, async (req) => withTx(ctx(req), async (c) => {
    const items = (await c.query(`SELECT i.id, i.invoice_no, i.student_id, s.first_name, s.last_name, s.admission_no, i.total_kobo, i.paid_kobo,
        (i.total_kobo - i.paid_kobo) AS balance_kobo, i.status, i.note, i.due_date::text, i.issued_at,
        (SELECT cl.display_name FROM student_enrollments e JOIN academic_sessions se ON se.id = e.session_id AND se.is_current JOIN classes cl ON cl.id = e.class_id
          WHERE e.student_id = s.id AND e.status = 'active' LIMIT 1) AS class_name
      FROM invoices i JOIN students s ON s.id = i.student_id WHERE i.kind = 'brought_forward' ORDER BY i.status = 'void', s.last_name, s.first_name LIMIT 5000`)).rows;
    const live = items.filter((i) => i.status !== 'void');
    return { items, totals: { learners: live.length, billedKobo: live.reduce((a, i) => a + Number(i.total_kobo), 0), paidKobo: live.reduce((a, i) => a + Number(i.paid_kobo), 0),
      owedKobo: live.reduce((a, i) => a + Number(i.balance_kobo), 0), settled: live.filter((i) => i.status === 'paid').length } };
  }));

  app.post('/fees/arrears/preview', { onRequest: [A, app.perm('fees.create')], config: { rateLimit: { max: 30, timeWindow: '1 minute' } }, schema: { body: obj({ rows: rowsSchema }, ['rows']) } },
    async (req) => withTx(ctx(req), async (c) => { const items = await matchRows(c, req.body.rows); return { items, summary: summary(items) }; }));

  app.post('/fees/arrears/import', {
    onRequest: [A, app.perm('fees.create')], config: { rateLimit: { max: 10, timeWindow: '1 minute' } },
    schema: { body: obj({ rows: rowsSchema, dueDate: { type: ['string', 'null'], format: 'date' } }, ['rows']) },
  }, async (req, reply) => withTx(ctx(req), async (c) => withIdempotency(c, req, reply, 'arrears.import', async () => {
    const items = await matchRows(c, req.body.rows);          // matched again inside the transaction: the preview is never trusted
    let created = 0; let totalKobo = 0;
    for (const it of items.filter((i) => i.status === 'ok')) {
      const no = await nextNo(c, req.auth.schoolId);
      await c.query('SAVEPOINT bf');
      try {
        const inv = (await c.query(`INSERT INTO invoices (school_id, invoice_no, student_id, term_id, kind, note, subtotal_kobo, discount_kobo, total_kobo, status, due_date, issued_by)
          VALUES ($1,$2,$3,NULL,'brought_forward',$4,$5,0,$5,'unpaid',$6,$7) RETURNING id`, [req.auth.schoolId, no, it.studentId, it.note, it.amountKobo, req.body.dueDate || null, req.auth.userId])).rows[0];
        await c.query(`INSERT INTO invoice_items (school_id, invoice_id, fee_structure_id, description, amount_kobo, kind, created_by) VALUES ($1,$2,NULL,$3,$4,'brought_forward',$5)`,
          [req.auth.schoolId, inv.id, it.note ? `${DESC} — ${it.note}`.slice(0, 200) : DESC, it.amountKobo, req.auth.userId]);
        await c.query('RELEASE SAVEPOINT bf');
        it.invoiceNo = no; created++; totalKobo += it.amountKobo;
      } catch (e) {
        await c.query('ROLLBACK TO SAVEPOINT bf');
        if (e.code === '23505') { it.status = 'exists'; continue; }      // billed by someone else a moment ago
        throw e;
      }
    }
    await audit(c, req, 'fees.arrears_imported', { type: 'school', id: req.auth.schoolId, meta: { created, totalKobo, rows: items.length } });
    return { created, totalKobo, items, summary: summary(items) };
  })));
};
