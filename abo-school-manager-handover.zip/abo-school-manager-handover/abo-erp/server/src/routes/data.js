'use strict';
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, uuid, idParams } = require('../lib/schema');
const { ctx } = require('../auth/plugin');
const { audit, securityEvent } = require('../audit/audit');
const { raw } = require('../db/pool');
const EXPORT_ALERT_PER_HOUR = Number(process.env.EXPORT_ALERT_PER_HOUR || 20);
const crypto = require('node:crypto');
const perSession = (max, win) => ({ rateLimit: { max, timeWindow: win, keyGenerator: (req) => { const k = Object.values(req.cookies || {})[0]; return k ? `s:${crypto.createHash('sha256').update(k).digest('hex').slice(0, 24)}` : `ip:${req.ip}`; } } });
const { enqueue } = require('../services/notify');
const { sniff } = require('../storage');
const { parseCsv, toCsv, toXlsx, readXlsx } = require('../lib/csv');
const R = require('../services/results');
const CUM = require('../services/cumulative');

const MAX_ROWS = 5000;
const norm = (h) => String(h || '').toLowerCase().replace(/[^a-z0-9]/g, '');
const KIND_PERM = { students: 'students.create', staff: 'staff.create', guardians: 'guardians.manage', subjects: 'academic.manage', classes: 'academic.manage', scores: 'results.enter_any' };
const HEADERS = {
  students: { admissionno: 'admission_no', firstname: 'first_name', lastname: 'last_name', surname: 'last_name', othernames: 'other_names', gender: 'gender', sex: 'gender', dateofbirth: 'date_of_birth', dob: 'date_of_birth', class: 'class', classname: 'class', parentname: 'parent_name', parentphone: 'parent_phone', parentemail: 'parent_email', relationship: 'relationship', address: 'address' },
  staff: { fullname: 'full_name', name: 'full_name', staffno: 'employee_id', employeeid: 'employee_id', gender: 'gender', phone: 'phone', email: 'email', designation: 'designation', isteacher: 'is_teacher', teacher: 'is_teacher' },
  guardians: { fullname: 'full_name', name: 'full_name', relationship: 'relationship', phone: 'phone', whatsapp: 'whatsapp', email: 'email', studentadmissionno: 'student_admission_no', admissionno: 'student_admission_no' },
  subjects: { name: 'name', subject: 'name', code: 'code' },
  classes: { name: 'name', class: 'name', arm: 'arm', section: 'section', level: 'section' },
  scores: { admissionno: 'admission_no', subject: 'subject', class: 'class' },   // + component keys (ca1, ca2, exam …)
};
const REQUIRED = { students: ['admission_no', 'first_name', 'last_name', 'gender'], staff: ['full_name'], guardians: ['full_name'], subjects: ['name'], classes: ['name', 'section'], scores: ['admission_no', 'subject', 'class'] };
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/; const PHONE = /^[+0-9 ()-]{7,20}$/;
function parseDate(v) {
  if (!v) return null; const s = String(v).trim();
  let m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s); if (m) return `${m[1]}-${m[2]}-${m[3]}`;
  m = /^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$/.exec(s); if (m) return `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`;
  return undefined;
}
const gender = (v) => { const s = String(v || '').trim().toLowerCase(); return s === 'm' || s === 'male' || s === 'boy' ? 'Male' : s === 'f' || s === 'female' || s === 'girl' ? 'Female' : null; };

async function validate(c, kind, rows, st) {
  const errors = []; const valid = []; const seen = new Set();
  const classes = new Map((await c.query('SELECT id, display_name, section FROM classes')).rows.map((r) => [r.display_name.replace(/\s+/g, '').toUpperCase(), r]));
  const subjects = new Map((await c.query('SELECT id, name FROM subjects')).rows.map((r) => [r.name.toLowerCase(), r]));
  const admNos = kind === 'students' || kind === 'guardians' || kind === 'scores'
    ? new Map((await c.query('SELECT id, lower(admission_no) AS a FROM students WHERE deleted_at IS NULL')).rows.map((r) => [r.a, r.id])) : new Map();
  const comps = (st && st.assessment_components) || [];
  rows.forEach((r, i) => {
    const n = i + 2; const err = (field, message) => errors.push({ row: n, field, message });
    for (const f of REQUIRED[kind]) if (!String(r[f] || '').trim()) err(f, 'is required');
    const before = errors.length;
    const o = {};
    if (kind === 'students') {
      o.admission_no = String(r.admission_no || '').trim(); o.first_name = String(r.first_name || '').trim(); o.last_name = String(r.last_name || '').trim(); o.other_names = String(r.other_names || '').trim() || null;
      o.gender = gender(r.gender); if (r.gender && !o.gender) err('gender', 'must be Male/Female (or M/F)');
      o.date_of_birth = parseDate(r.date_of_birth); if (o.date_of_birth === undefined) err('date_of_birth', 'use YYYY-MM-DD or DD/MM/YYYY');
      if (r.class) { const cl = classes.get(String(r.class).replace(/\s+/g, '').toUpperCase()); if (!cl) err('class', `class "${r.class}" does not exist`); else o.class_id = cl.id; }
      const key = o.admission_no.toLowerCase();
      if (key && admNos.has(key)) err('admission_no', 'already exists in this school');
      if (key && seen.has(key)) err('admission_no', 'is duplicated in this file'); seen.add(key);
      o.parent_name = String(r.parent_name || '').trim() || null; o.parent_phone = String(r.parent_phone || '').trim() || null; o.parent_email = String(r.parent_email || '').trim() || null; o.relationship = String(r.relationship || '').trim() || 'Parent';
      if (o.parent_phone && !PHONE.test(o.parent_phone)) err('parent_phone', 'is not a valid phone number');
      if (o.parent_email && !EMAIL.test(o.parent_email)) err('parent_email', 'is not a valid email');
      o.address = String(r.address || '').trim() || null;
      if (o.first_name.length > 80 || o.last_name.length > 80 || o.admission_no.length > 40) err('name', 'is too long');
    } else if (kind === 'staff') {
      o.full_name = String(r.full_name || '').trim(); o.employee_id = String(r.employee_id || '').trim() || null; o.gender = r.gender ? gender(r.gender) : null;
      o.phone = String(r.phone || '').trim() || null; o.email = String(r.email || '').trim() || null; o.designation = String(r.designation || '').trim() || null;
      o.is_teacher = !/^(no|n|false|0)$/i.test(String(r.is_teacher || 'yes').trim());
      if (o.email && !EMAIL.test(o.email)) err('email', 'is not a valid email');
      if (o.phone && !PHONE.test(o.phone)) err('phone', 'is not a valid phone number');
    } else if (kind === 'guardians') {
      o.full_name = String(r.full_name || '').trim(); o.relationship = String(r.relationship || '').trim() || 'Parent'; o.phone = String(r.phone || '').trim() || null;
      o.whatsapp = String(r.whatsapp || '').trim() || null; o.email = String(r.email || '').trim() || null;
      if (r.student_admission_no) { const sid = admNos.get(String(r.student_admission_no).trim().toLowerCase()); if (!sid) err('student_admission_no', 'student not found'); else o.student_id = sid; }
      if (o.email && !EMAIL.test(o.email)) err('email', 'is not a valid email');
    } else if (kind === 'subjects') {
      o.name = String(r.name || '').trim(); o.code = String(r.code || '').trim() || null;
      if (subjects.has(o.name.toLowerCase())) err('name', 'already exists');
      if (seen.has(o.name.toLowerCase())) err('name', 'is duplicated in this file'); seen.add(o.name.toLowerCase());
    } else if (kind === 'classes') {
      o.name = String(r.name || '').trim().toUpperCase(); o.arm = String(r.arm || '').trim().toUpperCase(); o.section = String(r.section || '').trim().toLowerCase();
      if (!['nursery', 'primary', 'secondary'].includes(o.section)) err('section', 'must be nursery, primary or secondary');
      const k = (o.name + o.arm).replace(/\s+/g, ''); if (classes.has(k)) err('name', 'class already exists'); if (seen.has(k)) err('name', 'duplicated in this file'); seen.add(k);
    } else if (kind === 'scores') {
      const sid = admNos.get(String(r.admission_no || '').trim().toLowerCase()); if (!sid) err('admission_no', 'student not found'); o.student_id = sid;
      const cl = classes.get(String(r.class || '').replace(/\s+/g, '').toUpperCase()); if (!cl) err('class', 'class not found'); o.class_id = cl && cl.id;
      const sb = subjects.get(String(r.subject || '').trim().toLowerCase()); if (!sb) err('subject', 'subject not found'); o.subject_id = sb && sb.id;
      o.scores = {};
      for (const cmp of comps) {
        const raw = r[cmp.key]; if (raw === undefined || String(raw).trim() === '') continue;
        const v = Number(raw); if (!Number.isFinite(v) || v < 0 || v > cmp.max) err(cmp.key, `must be a number between 0 and ${cmp.max}`); else o.scores[cmp.key] = v;
      }
      if (!Object.keys(o.scores).length) err('scores', 'no score columns found (use ' + comps.map((x) => x.key).join(', ') + ')');
    }
    if (errors.length === before) valid.push({ n, ...o });
  });
  return { valid, errors };
}

async function commit(c, req, kind, rows) {
  const sch = req.auth.schoolId; let n = 0;
  const sess = (await c.query('SELECT id FROM academic_sessions WHERE is_current LIMIT 1')).rows[0];
  if (kind === 'students') {
    const lim = (await c.query(`SELECT s.max_students, (SELECT count(*)::int FROM students WHERE status = 'active' AND deleted_at IS NULL) AS n FROM schools s WHERE s.id = $1`, [sch])).rows[0];
    if (lim.n + rows.length > lim.max_students) throw E.forbidden(`This import would exceed your plan limit of ${lim.max_students} active students.`);
    if (rows.some((r) => r.class_id) && !sess) throw E.bad('Set a current academic session before importing students with classes.');
    for (const r of rows) {
      const s = (await c.query(`INSERT INTO students (school_id, admission_no, first_name, last_name, other_names, gender, date_of_birth, address) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
        [sch, r.admission_no, r.first_name, r.last_name, r.other_names, r.gender, r.date_of_birth, r.address])).rows[0];
      if (r.class_id) await c.query('INSERT INTO student_enrollments (school_id, student_id, class_id, session_id) VALUES ($1,$2,$3,$4)', [sch, s.id, r.class_id, sess.id]);
      if (r.parent_name) {
        let g = r.parent_phone ? (await c.query('SELECT id FROM guardians WHERE phone = $1 LIMIT 1', [r.parent_phone])).rows[0] : null;   // siblings share a guardian
        if (!g) g = (await c.query('INSERT INTO guardians (school_id, full_name, relationship, phone, email) VALUES ($1,$2,$3,$4,$5) RETURNING id', [sch, r.parent_name, r.relationship, r.parent_phone, r.parent_email])).rows[0];
        await c.query('INSERT INTO student_guardians (school_id, student_id, guardian_id, is_primary) VALUES ($1,$2,$3,true) ON CONFLICT DO NOTHING', [sch, s.id, g.id]);
      }
      n++;
    }
  } else if (kind === 'staff') {
    for (const r of rows) { await c.query('INSERT INTO staff (school_id, full_name, employee_id, gender, phone, email, designation, is_teacher) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)', [sch, r.full_name, r.employee_id, r.gender, r.phone, r.email, r.designation, r.is_teacher]); n++; }
  } else if (kind === 'guardians') {
    for (const r of rows) {
      const g = (await c.query('INSERT INTO guardians (school_id, full_name, relationship, phone, whatsapp, email) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id', [sch, r.full_name, r.relationship, r.phone, r.whatsapp, r.email])).rows[0];
      if (r.student_id) await c.query('INSERT INTO student_guardians (school_id, student_id, guardian_id) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING', [sch, r.student_id, g.id]);
      n++;
    }
  } else if (kind === 'subjects') {
    for (const r of rows) { await c.query('INSERT INTO subjects (school_id, name, code) VALUES ($1,$2,$3)', [sch, r.name, r.code]); n++; }
  } else if (kind === 'classes') {
    for (const r of rows) { await c.query('INSERT INTO classes (school_id, name, arm, section) VALUES ($1,$2,$3,$4)', [sch, r.name, r.arm, r.section]); n++; }
  } else if (kind === 'scores') {
    const term = (await c.query('SELECT id FROM terms WHERE is_current LIMIT 1')).rows[0];
    if (!term) throw E.bad('Set the current term before importing scores.');
    const st = await R.settings(c); const touched = new Set();
    for (const r of rows) {
      const cs = await c.query('SELECT 1 FROM class_subjects WHERE class_id = $1 AND subject_id = $2', [r.class_id, r.subject_id]);
      if (!cs.rowCount) throw E.bad(`Row ${r.n}: subject is not offered in that class.`);
      const sh = (await c.query(`INSERT INTO assessments (school_id, term_id, class_id, subject_id, components, created_by) VALUES ($1,$2,$3,$4,$5,$6)
        ON CONFLICT (term_id, class_id, subject_id) DO UPDATE SET updated_at = assessments.updated_at RETURNING id, status`, [sch, term.id, r.class_id, r.subject_id, JSON.stringify(st.assessment_components), req.auth.userId])).rows[0];
      if (sh.status !== 'draft') throw E.locked(`Row ${r.n}: that subject's sheet is ${sh.status} and locked.`);
      for (const [k, v] of Object.entries(r.scores)) await c.query(`INSERT INTO assessment_scores (school_id, sheet_id, student_id, component_key, score, entered_by) VALUES ($1,$2,$3,$4,$5,$6)
        ON CONFLICT (sheet_id, student_id, component_key) DO UPDATE SET score = EXCLUDED.score, entered_by = EXCLUDED.entered_by`, [sch, sh.id, r.student_id, k, v, req.auth.userId]);
      touched.add(sh.id); n++;
    }
    for (const id of touched) await R.recomputeSheet(c, id);
  }
  return n;
}

// ───────── export datasets (each has its own permission; all require reports.export) ─────────
const DATASETS = {
  students: { perm: 'students.view', cols: [['admission_no', 'Admission No'], ['last_name', 'Surname'], ['first_name', 'First Name'], ['other_names', 'Other Names'], ['gender', 'Gender'], ['date_of_birth', 'Date of Birth'], ['class_name', 'Class'], ['status', 'Status']],
    sql: `SELECT s.admission_no, s.last_name, s.first_name, s.other_names, s.gender, s.date_of_birth, c.display_name AS class_name, s.status FROM students s LEFT JOIN academic_sessions cs ON cs.is_current
      LEFT JOIN student_enrollments e ON e.student_id = s.id AND e.session_id = cs.id LEFT JOIN classes c ON c.id = e.class_id WHERE s.deleted_at IS NULL AND ($1::uuid IS NULL OR e.class_id = $1) ORDER BY c.display_name, s.last_name`, args: (q) => [q.classId || null] },
  staff: { perm: 'staff.view', cols: [['employee_id', 'Staff No'], ['full_name', 'Name'], ['gender', 'Gender'], ['phone', 'Phone'], ['email', 'Email'], ['designation', 'Designation'], ['employment_status', 'Status']],
    sql: 'SELECT employee_id, full_name, gender, phone, email, designation, employment_status FROM staff ORDER BY full_name', args: () => [] },
  guardians: { perm: 'guardians.view', cols: [['full_name', 'Name'], ['relationship', 'Relationship'], ['phone', 'Phone'], ['email', 'Email'], ['children', 'Children']],
    sql: `SELECT g.full_name, g.relationship, g.phone, g.email, (SELECT string_agg(s.first_name || ' ' || s.last_name, '; ') FROM student_guardians sg JOIN students s ON s.id = sg.student_id WHERE sg.guardian_id = g.id) AS children FROM guardians g ORDER BY g.full_name`, args: () => [] },
  invoices: { perm: 'fees.view', cols: [['invoice_no', 'Invoice'], ['student', 'Student'], ['admission_no', 'Admission No'], ['total', 'Total (₦)'], ['paid', 'Paid (₦)'], ['balance', 'Balance (₦)'], ['status', 'Status']],
    sql: `SELECT i.invoice_no, s.first_name || ' ' || s.last_name AS student, s.admission_no, i.total_kobo / 100.0 AS total, i.paid_kobo / 100.0 AS paid, (i.total_kobo - i.paid_kobo) / 100.0 AS balance, i.status
      FROM invoices i JOIN students s ON s.id = i.student_id WHERE ($1::uuid IS NULL OR i.term_id = $1) ORDER BY i.invoice_no`, args: (q) => [q.termId || null] },
  payments: { perm: 'fees.view', cols: [['receipt_no', 'Receipt'], ['paid_at', 'Date'], ['student', 'Student'], ['amount', 'Amount (₦)'], ['method', 'Method'], ['reference', 'Reference'], ['status', 'Status']],
    sql: `SELECT r.receipt_no, p.paid_at, COALESCE(s.first_name || ' ' || s.last_name, g.full_name) AS student, p.amount_kobo / 100.0 AS amount, p.method, p.reference, p.status
      FROM payments p LEFT JOIN receipts r ON r.payment_id = p.id LEFT JOIN students s ON s.id = p.student_id LEFT JOIN guardians g ON g.id = p.payer_guardian_id ORDER BY p.paid_at DESC`, args: () => [] },
  attendance: { perm: 'attendance.view', cols: [['date', 'Date'], ['student', 'Student'], ['admission_no', 'Admission No'], ['status', 'Status'], ['note', 'Note']],
    sql: `SELECT a.date, s.first_name || ' ' || s.last_name AS student, s.admission_no, a.status, a.note FROM attendance_records a JOIN students s ON s.id = a.student_id WHERE ($1::uuid IS NULL OR a.class_id = $1) AND ($2::uuid IS NULL OR a.term_id = $2) ORDER BY a.date DESC, s.last_name`, args: (q) => [q.classId || null, q.termId || null] },
  classes: { perm: 'academic.view', cols: [['display_name', 'Class'], ['section', 'Section'], ['form_teacher', 'Form Teacher'], ['capacity', 'Capacity'], ['branch', 'Branch']],
    sql: `SELECT c.display_name, c.section, st.full_name AS form_teacher, c.capacity, b.name AS branch FROM classes c LEFT JOIN staff st ON st.id = c.form_teacher_id LEFT JOIN school_branches b ON b.id = c.branch_id ORDER BY c.sort_order, c.display_name`, args: () => [] },
  subjects: { perm: 'academic.view', cols: [['name', 'Subject'], ['code', 'Code'], ['classes', 'Offered In']],
    sql: `SELECT sb.name, sb.code, (SELECT string_agg(c.display_name, ', ' ORDER BY c.display_name) FROM class_subjects cs JOIN classes c ON c.id = cs.class_id WHERE cs.subject_id = sb.id) AS classes FROM subjects sb ORDER BY sb.name`, args: () => [] },
  results: { perm: 'results.view', cols: [['session', 'Session'], ['term', 'Term'], ['class_name', 'Class'], ['subject', 'Subject'], ['admission_no', 'Admission No'], ['student', 'Student'], ['total', 'Total'], ['grade', 'Grade'], ['position', 'Subject Position'], ['status', 'Sheet Status']],
    sql: `SELECT se.name AS session, t.name AS term, c.display_name AS class_name, sb.name AS subject, s.admission_no, s.last_name || ' ' || s.first_name AS student, er.total, er.grade, er.subject_position AS position, a.status
      FROM examination_results er JOIN assessments a ON a.id = er.sheet_id JOIN terms t ON t.id = a.term_id JOIN academic_sessions se ON se.id = t.session_id JOIN classes c ON c.id = a.class_id
      JOIN subjects sb ON sb.id = a.subject_id JOIN students s ON s.id = er.student_id WHERE ($1::uuid IS NULL OR a.term_id = $1) AND ($2::uuid IS NULL OR a.class_id = $2)
      ORDER BY se.name, t.name, c.display_name, sb.name, s.last_name LIMIT 100000`, args: (q) => [q.termId || null, q.classId || null] },
  audit: { perm: 'audit_logs.view', cols: [['seq', 'Seq'], ['created_at', 'Time'], ['actor_login', 'Actor'], ['action', 'Action'], ['resource_type', 'Resource'], ['resource_id', 'Resource ID'], ['success', 'Success'], ['ip', 'IP'], ['hash', 'Hash']],
    sql: 'SELECT seq, created_at, actor_login, action, resource_type, resource_id, success, host(ip) AS ip, hash FROM audit_logs WHERE school_id = app.current_school() ORDER BY seq DESC LIMIT 50000', args: () => [] },
};

async function buildExport(c, req, dataset, q) {
  const d = DATASETS[dataset];
  if (dataset === 'broadsheet') {
    if (!q.termId || !q.classId) throw E.bad('termId and classId are required for broadsheet exports.');
    const b = await R.broadsheet(c, q.termId, q.classId);
    const cols = [{ key: 'pos', label: 'Pos' }, { key: 'name', label: 'Name' }, { key: 'adm', label: 'Adm No' }, ...b.subjects.map((s, i) => ({ key: `s${i}`, label: s.name })), { key: 'total', label: 'Total' }, { key: 'avg', label: 'Average' }, { key: 'grade', label: 'Grade' }, { key: 'status', label: 'Status' }];
    const rows = b.rows.map((r) => { const o = { pos: r.summary && r.summary.position, name: r.name, adm: r.admissionNo, total: r.summary && r.summary.total, avg: r.summary && r.summary.average, grade: r.summary && r.summary.grade, status: r.summary && r.summary.status };
      r.scores.forEach((s, i) => { o[`s${i}`] = s ? s.total : ''; }); return o; });
    return { cols, rows };
  }
  if (dataset === 'cumulative') {
    if (!q.termId || !q.classId) throw E.bad('termId and classId are required for cumulative exports.');
    const b = await CUM.classCumulative(c, q.termId, q.classId);
    const cols = [{ key: 'pos', label: 'Cum. position' }, { key: 'name', label: 'Name' }, { key: 'adm', label: 'Adm No' }];
    b.subjects.forEach((s, i) => { b.terms.forEach((t, ti) => cols.push({ key: `s${i}t${ti}`, label: `${s.name} ${t.label}` })); cols.push({ key: `s${i}c`, label: `${s.name} cum. average` }, { key: `s${i}g`, label: `${s.name} grade` }); });
    b.terms.forEach((t, ti) => cols.push({ key: `ta${ti}`, label: `${t.label} average` }));
    cols.push({ key: 'cavg', label: 'Cumulative average' }, { key: 'grade', label: 'Grade' }, { key: 'status', label: 'Status' }, { key: 'tpos', label: 'This term position' }, { key: 'summary', label: 'Summary' });
    const rows = b.rows.map((r) => { const o = { pos: r.cumulativePosition, name: r.name, adm: r.admissionNo, cavg: r.cumulativeAverage, grade: r.grade, status: r.status, tpos: r.thisTermPosition, summary: r.summary };
      r.subjects.forEach((s, i) => { s.termTotals.forEach((v, ti) => { o[`s${i}t${ti}`] = v ?? ''; }); o[`s${i}c`] = s.average ?? ''; o[`s${i}g`] = s.grade || ''; });
      r.termAverages.forEach((v, ti) => { o[`ta${ti}`] = v ?? ''; }); return o; });
    return { cols, rows };
  }
  if (!d) throw E.notFound('Dataset');
  return { cols: d.cols.map(([key, label]) => ({ key, label })), rows: (await c.query(d.sql, d.args(q))).rows };
}

module.exports = async function dataRoutes(app) {
  const A = app.authenticate;

  app.post('/imports/:kind/preview', { onRequest: [A, app.perm('imports.run')], config: { rateLimit: { max: 20, timeWindow: '1 minute' } }, schema: { params: obj({ kind: { enum: Object.keys(KIND_PERM) } }, ['kind']) } }, async (req) => {
    const kind = req.params.kind;
    if (!req.can(KIND_PERM[kind])) throw E.forbidden(`Importing ${kind} requires the ${KIND_PERM[kind]} permission.`);
    const data = await req.file(); if (!data) throw E.bad('Attach a CSV or Excel file.');
    const buffer = await data.toBuffer();
    const type = sniff(buffer, data.filename);
    let table;
    if (type && type.ext === 'xlsx') table = await readXlsx(buffer, MAX_ROWS + 1);
    else if (type && (type.ext === 'csv' || type.ext === 'txt')) table = parseCsv(buffer.toString('utf8'), MAX_ROWS + 1);
    else throw E.bad('Upload a .csv or .xlsx file.');
    if (table.length < 2) throw E.bad('The file has no data rows.');
    if (table.length - 1 > MAX_ROWS) throw E.bad(`Import at most ${MAX_ROWS} rows per file.`);
    const map = { ...HEADERS[kind] };
    return withTx(ctx(req), async (c) => {
      const st = await R.settings(c);
      if (kind === 'scores') for (const cmp of st.assessment_components) map[norm(cmp.key)] = cmp.key;
      const header = table[0].map((h) => map[norm(h)] || null);
      const missing = REQUIRED[kind].filter((f) => !header.includes(f));
      if (missing.length) throw E.bad(`Missing required column(s): ${missing.join(', ')}.`);
      const rows = table.slice(1).map((r) => { const o = {}; header.forEach((k, i) => { if (k) o[k] = r[i] !== undefined ? String(r[i]).trim() : ''; }); return o; });
      const { valid, errors } = await validate(c, kind, rows, st);
      const imp = (await c.query(`INSERT INTO imports (school_id, kind, file_name, total_rows, valid_rows, errors, rows, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
        [req.auth.schoolId, kind, String(data.filename).slice(0, 120), rows.length, valid.length, JSON.stringify(errors), JSON.stringify(valid), req.auth.userId])).rows[0];
      await audit(c, req, 'data.import_previewed', { type: 'import', id: imp.id, meta: { kind, total: rows.length, valid: valid.length, errors: errors.length } });
      return { importId: imp.id, kind, totalRows: rows.length, validRows: valid.length, errorCount: errors.length, errors: errors.slice(0, 200), sample: valid.slice(0, 5) };
    });
  });

  app.post('/imports/:id/commit', { onRequest: [A, app.perm('imports.run')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const imp = (await c.query('SELECT * FROM imports WHERE id = $1 FOR UPDATE', [req.params.id])).rows[0];
    if (!imp) throw E.notFound('Import');
    if (!req.can(KIND_PERM[imp.kind])) throw E.forbidden();
    if (imp.status !== 'previewed') throw E.conflict('This import was already processed.');
    if (Date.now() - new Date(imp.created_at).getTime() > 60 * 60000) { await c.query("UPDATE imports SET status = 'expired' WHERE id = $1", [imp.id]); throw E.bad('This preview has expired. Upload the file again.'); }
    // rows were validated at preview; DB unique/FK/check constraints are the final guard and the whole commit is atomic
    const n = await commit(c, req, imp.kind, imp.rows);
    await c.query("UPDATE imports SET status = 'committed', committed_at = now(), summary = $2 WHERE id = $1", [imp.id, { imported: n }]);
    await audit(c, req, 'data.imported', { type: 'import', id: imp.id, meta: { kind: imp.kind, imported: n, skippedInvalid: imp.total_rows - imp.valid_rows } });
    return { ok: true, imported: n, skipped: imp.total_rows - imp.valid_rows };
  }));

  app.get('/imports/:id/errors.csv', { onRequest: [A, app.perm('imports.run')], schema: { params: idParams } }, async (req, reply) => {
    const imp = await withTx(ctx(req), async (c) => (await c.query('SELECT errors, kind FROM imports WHERE id = $1', [req.params.id])).rows[0]);
    if (!imp) throw E.notFound('Import');
    reply.header('Content-Type', 'text/csv; charset=utf-8').header('Content-Disposition', `attachment; filename="${imp.kind}-import-errors.csv"`);
    return toCsv([{ key: 'row', label: 'Row' }, { key: 'field', label: 'Field' }, { key: 'message', label: 'Problem' }], imp.errors);
  });

  app.get('/imports/templates/:kind.csv', { onRequest: [A, app.perm('imports.run')], schema: { params: obj({ kind: { enum: Object.keys(KIND_PERM) } }, ['kind']) } }, async (req, reply) => {
    const t = { students: 'admission_no,first_name,last_name,other_names,gender,date_of_birth,class,parent_name,parent_phone,parent_email,relationship\nBOPC/001,Ada,Okafor,,Female,2014-03-09,BASIC 1A,Mrs Okafor,08030000000,okafor@example.com,Mother',
      staff: 'full_name,employee_id,gender,phone,email,designation,is_teacher\nMr Tunde Bello,ST001,Male,08050000000,tunde@example.com,Class Teacher,yes',
      guardians: 'full_name,relationship,phone,whatsapp,email,student_admission_no\nMrs Okafor,Mother,08030000000,08030000000,okafor@example.com,BOPC/001',
      subjects: 'name,code\nEnglish Language,ENG\nMathematics,MTH', classes: 'name,arm,section\nBASIC 1,A,primary\nBASIC 1,B,primary\nJSS 1,A,secondary',
      scores: 'admission_no,class,subject,ca1,ca2,exam\nBOPC/001,BASIC 1A,Mathematics,18,17,52' }[req.params.kind];
    reply.header('Content-Type', 'text/csv; charset=utf-8').header('Content-Disposition', `attachment; filename="${req.params.kind}-template.csv"`);
    return t + '\n';
  });

  app.get('/exports/:dataset', {
    onRequest: [A, app.perm('reports.export')], config: perSession(30, '1 minute'),
    schema: { params: obj({ dataset: { enum: [...Object.keys(DATASETS), 'broadsheet', 'cumulative'] } }, ['dataset']), querystring: obj({ format: { enum: ['csv', 'xlsx'], default: 'csv' }, classId: uuid, termId: uuid, async: { type: 'boolean' } }) },
  }, async (req, reply) => {
    const ds = req.params.dataset; const need = ds === 'broadsheet' || ds === 'cumulative' ? 'results.view' : DATASETS[ds].perm;
    if (!req.can(need)) throw E.forbidden(`Exporting ${ds} requires ${need}.`);
    if (req.query.async) {
      const jobId = await withTx({ ...ctx(req), readOnly: false }, async (c) => {
        const id = await enqueue(c, { schoolId: req.auth.schoolId, kind: 'export.build', payload: { dataset: ds, query: req.query, userId: req.auth.userId }, createdBy: req.auth.userId });
        await audit(c, req, 'data.export_queued', { type: 'export', id: ds, meta: { format: req.query.format, jobId: id } });
        return id;
      });
      return { jobId };
    }
    const { cols, rows } = await withTx({ ...ctx(req), readOnly: !!req.auth.support }, async (c) => {
      const out = await buildExport(c, req, ds, req.query);
      if (!req.auth.support) await audit(c, req, 'data.exported', { type: 'export', id: ds, meta: { format: req.query.format, rows: out.rows.length, classId: req.query.classId || null, termId: req.query.termId || null } });
      return out;
    });
    // abnormal export activity (bulk data exfiltration signal)
    const n = (await raw('SELECT app.recent_exports($1) AS n', [req.auth.userId])).rows[0].n;
    if (n >= EXPORT_ALERT_PER_HOUR && n % EXPORT_ALERT_PER_HOUR === 0) securityEvent({ schoolId: req.auth.schoolId, userId: req.auth.userId, kind: 'abnormal_export_activity', severity: 'high', detail: { exportsLastHour: n, dataset: ds }, ip: req.ip });
    const name = `${ds}-${new Date().toISOString().slice(0, 10)}`;
    if (req.query.format === 'xlsx') {
      reply.header('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet').header('Content-Disposition', `attachment; filename="${name}.xlsx"`);
      return toXlsx(ds, cols, rows);
    }
    reply.header('Content-Type', 'text/csv; charset=utf-8').header('Content-Disposition', `attachment; filename="${name}.csv"`);
    return toCsv(cols, rows);
  });
};
module.exports.buildExport = buildExport;
module.exports.DATASETS = DATASETS;
