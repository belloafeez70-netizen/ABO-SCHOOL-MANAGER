'use strict';
// Platform (A.B.O. operator) console. Separate from school administration; requires is_platform_admin
// (and MFA in staging/production). Cross-school reads use platform mode or definer functions only.
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, str, uuid, listQuery } = require('../lib/schema');
const { page, paged, likeEscape } = require('../lib/http');
const { platformCtx, invalidateSchool } = require('../auth/plugin');
const { audit, securityEvent } = require('../audit/audit');
const { queueEmail, notify } = require('../services/notify');
const config = require('../config');

module.exports = async function platformRoutes(app) {
  const guard = [app.authenticate, app.platformOnly];

  app.get('/platform/schools', { onRequest: guard, schema: { querystring: listQuery({ status: { enum: ['pending', 'active', 'suspended'] } }) } }, async (req) => {
    const pg = page(req.query);
    return withTx({ ...platformCtx(req), readOnly: true }, async (c) => {
      const where = []; const p = [];
      if (req.query.q) { p.push(`%${likeEscape(req.query.q.toLowerCase())}%`); where.push(`(lower(s.name) LIKE $${p.length} OR lower(s.slug) LIKE $${p.length})`); }
      if (req.query.status) { p.push(req.query.status); where.push(`s.status = $${p.length}`); }
      const w = where.length ? 'WHERE ' + where.join(' AND ') : '';
      const total = (await c.query(`SELECT count(*)::int AS n FROM schools s ${w}`, p)).rows[0].n;
      const rows = (await c.query(`SELECT s.id, s.slug, s.registration_number, s.subscription_status, s.subscription_expires_at, s.name, s.school_type, s.status, s.plan, s.email, s.phone, s.created_at, s.approved_at, s.email_verified_at, s.logo_file_id IS NOT NULL AS has_logo, st.students, st.staff, st.users, st.active_sessions
        FROM schools s LEFT JOIN app.platform_school_stats() st ON st.school_id = s.id ${w} ORDER BY s.created_at DESC LIMIT ${pg.limit} OFFSET ${pg.offset}`, p)).rows;
      return paged(rows, total, pg);
    });
  });

  app.patch('/platform/schools/:id', {
    onRequest: [...guard, app.perm('platform.schools.manage')],
    schema: { params: obj({ id: uuid }, ['id']), body: obj({ status: { enum: ['active', 'suspended'] }, plan: str(40, 2), maxStudents: { type: 'integer', minimum: 1, maximum: 100000 }, reason: str(300, 3) }, ['reason']) },
  }, async (req) => {
    const b = req.body;
    const row = await withTx(platformCtx(req), async (c) => {
      const before = (await c.query('SELECT status, approved_at FROM schools WHERE id = $1 FOR UPDATE', [req.params.id])).rows[0];
      if (!before) throw E.notFound('School');
      const approving = b.status === 'active' && before.status === 'pending';
      const r = await c.query(`UPDATE schools SET status = COALESCE($2, status), plan = COALESCE($3, plan), max_students = COALESCE($4, max_students),
          approved_at = CASE WHEN $5 THEN now() ELSE approved_at END, approved_by = CASE WHEN $5 THEN $6::uuid ELSE approved_by END
        WHERE id = $1 RETURNING id, slug, name, status, plan, max_students, approved_at`, [req.params.id, b.status || null, b.plan || null, b.maxStudents || null, approving, req.auth.userId]);
      if (b.status === 'suspended') await c.query("UPDATE sessions SET revoked_at = now(), revoked_reason = 'school_suspended' WHERE school_id = $1 AND revoked_at IS NULL", [req.params.id]);
      const out = r.rows[0]; out.portalUrl = `${config.publicOrigin}/#/s/${out.slug}`;
      if (approving) {
        // tell the owner(s): the school is approved, here is its own branded sign-in page
        for (const o of (await c.query('SELECT * FROM app.platform_school_owners($1)', [req.params.id])).rows) {
          await queueEmail(c, { schoolId: req.params.id, to: o.email, template: 'school_approved', subject: `${out.name} is approved on A.B.O. School Manager`,
            body: `Hello ${o.full_name},\n\nGood news — ${out.name} has been approved. You can now sign in and set up your school.\n\nYour school's sign-in page (share it with your staff, students and parents):\n${out.portalUrl}\n\nUpload your logo under School → Logo & Branding so it appears on the sign-in page, report cards and receipts.\n` });
          await notify(c, req.params.id, [o.user_id], { kind: 'school', title: `${out.name} has been approved`, body: 'Upload your logo and share your school sign-in page with staff and parents.', link: '#/school/branding' });
        }
      }
      await audit(c, req, approving ? 'platform.school_approved' : 'platform.school_updated', { schoolId: null, type: 'school', id: req.params.id, meta: { ...b, from: before.status } });
      out.approved = approving;
      return out;
    });
    invalidateSchool(req.params.id);
    if (b.status === 'suspended') securityEvent({ schoolId: req.params.id, userId: req.auth.userId, kind: 'school_suspended', severity: 'medium', detail: { reason: b.reason }, ip: req.ip });
    return row;
  });

  // time-limited, read-only, audited support view of one school
  app.post('/platform/support', {
    onRequest: [...guard, app.perm('platform.support')],
    schema: { body: obj({ schoolId: uuid, reason: str(300, 10), minutes: { type: 'integer', minimum: 5, maximum: 120, default: 30 } }, ['schoolId', 'reason']) },
  }, async (req) => {
    await withTx(platformCtx(req), async (c) => {
      const s = await c.query('SELECT id FROM schools WHERE id = $1', [req.body.schoolId]);
      if (!s.rowCount) throw E.notFound('School');
      await c.query(`UPDATE sessions SET support_school_id = $2, support_reason = $3, support_expires_at = now() + make_interval(mins => $4) WHERE id = $1`,
        [req.auth.sessionId, req.body.schoolId, req.body.reason, req.body.minutes]);
      await audit(c, req, 'platform.support_started', { schoolId: null, type: 'school', id: req.body.schoolId, meta: { reason: req.body.reason, minutes: req.body.minutes } });
    });
    // also record it in the SCHOOL's own audit chain so the school can see who looked
    await withTx({ schoolId: req.body.schoolId, userId: req.auth.userId }, (c) => audit(c, req, 'platform.support_started', { schoolId: req.body.schoolId, type: 'school', id: req.body.schoolId, meta: { reason: req.body.reason } }));
    securityEvent({ schoolId: req.body.schoolId, userId: req.auth.userId, kind: 'platform_support_access', severity: 'medium', detail: { reason: req.body.reason }, ip: req.ip });
    return { ok: true };
  });
  app.delete('/platform/support', { onRequest: guard }, async (req) => {
    await withTx(platformCtx(req), async (c) => {
      await c.query('UPDATE sessions SET support_school_id = NULL, support_reason = NULL, support_expires_at = NULL WHERE id = $1', [req.auth.sessionId]);
      await audit(c, req, 'platform.support_ended', { schoolId: null });
    });
    return { ok: true };
  });

  app.get('/platform/security-events', { onRequest: [...guard, app.perm('platform.security.view')], schema: { querystring: listQuery({ severity: { enum: ['info', 'low', 'medium', 'high', 'critical'] } }) } }, async (req) => {
    const pg = page(req.query);
    return withTx({ ...platformCtx(req), readOnly: true }, async (c) => {
      const p = []; let w = '';
      if (req.query.severity) { p.push(req.query.severity); w = 'WHERE e.severity = $1'; }
      const total = (await c.query(`SELECT count(*)::int AS n FROM security_events e ${w}`, p)).rows[0].n;
      const rows = (await c.query(`SELECT e.id, e.kind, e.severity, e.detail, host(e.ip) AS ip, e.created_at, s.name AS school
        FROM security_events e LEFT JOIN schools s ON s.id = e.school_id ${w} ORDER BY e.created_at DESC LIMIT ${pg.limit} OFFSET ${pg.offset}`, p)).rows;
      return paged(rows, total, pg);
    });
  });

  app.get('/platform/health', { onRequest: [...guard, app.perm('platform.health.view')] }, async (req) => {
    return withTx({ ...platformCtx(req), readOnly: true }, async (c) => {
      const jobs = (await c.query(`SELECT status, count(*)::int AS n FROM jobs WHERE created_at > now() - interval '24 hours' GROUP BY status`)).rows;
      const logins = (await c.query(`SELECT success, count(*)::int AS n FROM login_events WHERE created_at > now() - interval '24 hours' GROUP BY success`)).rows;
      const sec = (await c.query(`SELECT severity, count(*)::int AS n FROM security_events WHERE created_at > now() - interval '24 hours' GROUP BY severity`)).rows;
      const db = (await c.query(`SELECT pg_database_size(current_database())::bigint AS bytes, (SELECT count(*) FROM pg_stat_activity WHERE datname = current_database())::int AS connections`)).rows[0];
      const mail = (await c.query(`SELECT status, count(*)::int AS n FROM outbox_emails WHERE created_at > now() - interval '24 hours' GROUP BY status`)).rows;
      const totals = (await c.query(`SELECT count(*)::int AS schools, count(*) FILTER (WHERE status = 'active')::int AS active FROM schools`)).rows[0];
      return { uptimeSeconds: Math.round(process.uptime()), memoryMb: Math.round(process.memoryUsage().rss / 1048576), db, jobs, logins, security: sec, mail, totals };
    });
  });
};
