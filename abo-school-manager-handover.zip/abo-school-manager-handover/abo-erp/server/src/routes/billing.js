'use strict';
// Subscriptions & payment settings.
//
// PLATFORM OWNER (A.B.O.; platform admins only, MFA in staging/production):
//   settings (demo timer 1–5 minutes, trial days, currency, Paystack keys), plans & prices, every school's subscription,
//   every payment attempt. The Paystack SECRET key is stored encrypted (AES-256-GCM, DATA_ENCRYPTION_KEY) and is never
//   sent back to any browser — the page only sees "set / not set" and a hint like sk_live_…a1b2. An environment variable
//   PLATFORM_PAYSTACK_SECRET_KEY, when present, takes precedence (keeps the key out of the database entirely).
// SCHOOLS (settings.view to look, settings.update to pay): their own plan, status, expiry and payment history; start a
//   Paystack checkout whose amount is computed on the SERVER from the plan.
// A payment counts only after server-to-server verification with Paystack (status success, same amount and currency);
// the webhook must carry a valid HMAC-SHA512 signature. Unverified payments stay "pending" — never "success".
const crypto = require('node:crypto');
const { withTx, raw } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, str, uuid, idParams } = require('../lib/schema');
const { ctx, platformCtx } = require('../auth/plugin');
const { audit, securityEvent } = require('../audit/audit');
const { encrypt, decrypt } = require('../security/crypto');
const config = require('../config');

const KOBO = (n) => Math.round(Number(n) * 100);
async function platformSecret() {
  if (process.env.PLATFORM_PAYSTACK_SECRET_KEY) return process.env.PLATFORM_PAYSTACK_SECRET_KEY;
  const r = (await withTx({ platform: true, readOnly: true }, (c) => c.query('SELECT paystack_secret_enc FROM platform_settings WHERE id'))).rows[0];
  if (!r || !r.paystack_secret_enc) return null;
  try { return decrypt(r.paystack_secret_enc); } catch { return null; }
}
const hint = (k) => (k ? `${k.slice(0, 8)}…${k.slice(-4)}` : null);

// verify one subscription payment with Paystack and, if genuinely paid, extend the school's subscription (idempotent)
async function verifySubscription(reference, meta = {}) {
  const secret = await platformSecret();
  if (!secret) return { ok: false, status: 'not_configured' };
  const sid = (await raw('SELECT app.subscription_payment_school($1) AS s', [reference])).rows[0].s;
  if (!sid) return { ok: false, status: 'unknown_reference' };
  const vr = await fetch(`${config.payments.paystackBaseUrl}/transaction/verify/${encodeURIComponent(reference)}`, { headers: { authorization: `Bearer ${secret}` }, signal: AbortSignal.timeout(15000) });
  const v = await vr.json().catch(() => ({}));
  const gw = v && v.data ? String(v.data.status || '') : 'unreachable';
  return withTx({ platform: true }, async (c) => {
    const p = (await c.query('SELECT p.*, pl.period_days, pl.name AS plan_name FROM subscription_payments p JOIN subscription_plans pl ON pl.id = p.plan_id WHERE p.reference = $1 FOR UPDATE OF p', [reference])).rows[0];
    if (!p) return { ok: false, status: 'unknown_reference' };
    if (p.status === 'success') return { ok: true, status: 'success', already: true, periodEnd: p.period_end_after };
    if (!vr.ok || !v.status || !v.data || gw !== 'success') {
      if (['failed', 'abandoned', 'reversed'].includes(gw)) await c.query('UPDATE subscription_payments SET status = $2, gateway_status = $3 WHERE id = $1', [p.id, gw === 'abandoned' ? 'abandoned' : 'failed', gw]);
      return { ok: false, status: gw || 'pending' };
    }
    if (Number(v.data.amount) !== Number(p.amount_kobo) || String(v.data.currency || 'NGN') !== p.currency) {
      await c.query("UPDATE subscription_payments SET status = 'failed', gateway_status = 'amount_mismatch' WHERE id = $1", [p.id]);
      securityEvent({ schoolId: p.school_id, kind: 'payment_amount_mismatch', severity: 'high', detail: { reference, expected: p.amount_kobo, got: v.data.amount } });
      return { ok: false, status: 'amount_mismatch' };
    }
    const sub = (await c.query(`INSERT INTO school_subscriptions (school_id, plan_id, status, current_period_end, updated_at)
        VALUES ($1, $2, 'active', now() + make_interval(days => $3), now())
      ON CONFLICT (school_id) DO UPDATE SET plan_id = EXCLUDED.plan_id, status = 'active', updated_at = now(),
        current_period_end = GREATEST(now(), COALESCE(school_subscriptions.current_period_end, now())) + make_interval(days => $3)
      RETURNING current_period_end`, [p.school_id, p.plan_id, p.period_days])).rows[0];
    await c.query("UPDATE subscription_payments SET status = 'success', verified_at = now(), gateway_status = 'success', period_end_after = $2 WHERE id = $1", [p.id, sub.current_period_end]);
    await audit(c, { ip: meta.ip, headers: meta.headers || {}, auth: { schoolId: null, userId: meta.userId || null, loginId: meta.by || 'paystack', roles: [] } }, 'billing.payment_verified',
      { schoolId: p.school_id, type: 'subscription_payment', id: p.id, meta: { reference, plan: p.plan_name, amountKobo: Number(p.amount_kobo), periodEnd: sub.current_period_end } });
    return { ok: true, status: 'success', periodEnd: sub.current_period_end };
  });
}

module.exports = async function billingRoutes(app) {
  const A = app.authenticate;
  const P = [A, app.platformOnly, app.perm('platform.billing.manage')];

  // ── platform owner: settings ──
  app.get('/platform/billing/settings', { onRequest: P }, async (req) => withTx(platformCtx(req), async (c) => {
    const s = (await c.query('SELECT demo_enabled, demo_minutes, trial_days, currency, gateway, paystack_public_key, paystack_secret_hint, (paystack_secret_enc IS NOT NULL) AS secret_set, bank_details, updated_at FROM platform_settings WHERE id')).rows[0];
    return { ...s, secretFromEnvironment: !!process.env.PLATFORM_PAYSTACK_SECRET_KEY, webhookUrl: `${config.publicOrigin}/api/v1/billing/webhook/paystack` };
  }));
  app.put('/platform/billing/settings', {
    onRequest: P,
    schema: { body: obj({ demoEnabled: { type: 'boolean' }, demoMinutes: { type: 'integer', minimum: 1, maximum: 5 }, trialDays: { type: 'integer', minimum: 0, maximum: 90 }, currency: { enum: ['NGN', 'GHS', 'KES', 'ZAR', 'USD'] },
      paystackPublicKey: { type: ['string', 'null'], pattern: '^pk_(test|live)_[A-Za-z0-9]{8,80}$' }, paystackSecretKey: { type: ['string', 'null'], pattern: '^sk_(test|live)_[A-Za-z0-9]{8,80}$' }, clearSecret: { type: 'boolean' },
      bankDetails: { type: ['string', 'null'], maxLength: 500 } }) },
  }, async (req) => withTx(platformCtx(req), async (c) => {
    const b = req.body;
    if (b.paystackSecretKey && b.paystackPublicKey && b.paystackSecretKey.slice(3, 7) !== b.paystackPublicKey.slice(3, 7)) throw E.bad('The public and secret keys must both be test keys or both be live keys.');
    await c.query(`UPDATE platform_settings SET demo_enabled = COALESCE($1, demo_enabled), demo_minutes = COALESCE($2, demo_minutes), trial_days = COALESCE($3, trial_days), currency = COALESCE($4, currency),
      paystack_public_key = CASE WHEN $5 THEN $6 ELSE paystack_public_key END,
      paystack_secret_enc = CASE WHEN $9 THEN NULL WHEN $7::text IS NOT NULL THEN $7 ELSE paystack_secret_enc END,
      paystack_secret_hint = CASE WHEN $9 THEN NULL WHEN $8::text IS NOT NULL THEN $8 ELSE paystack_secret_hint END,
      bank_details = CASE WHEN $10 THEN $11 ELSE bank_details END, updated_by = $12, updated_at = now() WHERE id`,
    [b.demoEnabled ?? null, b.demoMinutes ?? null, b.trialDays ?? null, b.currency || null, b.paystackPublicKey !== undefined, b.paystackPublicKey || null,
      b.paystackSecretKey ? encrypt(b.paystackSecretKey) : null, b.paystackSecretKey ? hint(b.paystackSecretKey) : null, !!b.clearSecret, b.bankDetails !== undefined, b.bankDetails || null, req.auth.userId]);
    // never log the key itself
    await audit(c, req, 'billing.settings_updated', { type: 'platform_settings', id: 'platform', meta: { fields: Object.keys(b).filter((k) => k !== 'paystackSecretKey'), secretChanged: !!b.paystackSecretKey || !!b.clearSecret } });
    return { ok: true };
  }));

  // ── platform owner: plans ──
  const planBody = obj({ code: { type: 'string', pattern: '^[a-z0-9_-]{2,30}$' }, name: str(60, 2), description: { type: ['string', 'null'], maxLength: 300 }, price: { type: 'number', minimum: 0, maximum: 1000000000 },
    period: { enum: ['month', 'term', 'year'] }, periodDays: { type: 'integer', minimum: 1, maximum: 400 }, active: { type: 'boolean' }, sortOrder: { type: 'integer', minimum: 0, maximum: 1000 } });
  app.get('/platform/billing/plans', { onRequest: P }, async (req) => withTx(platformCtx(req), async (c) => ({ items: (await c.query('SELECT * FROM subscription_plans ORDER BY active DESC, sort_order, price_kobo')).rows })));
  app.post('/platform/billing/plans', { onRequest: P, schema: { body: { ...planBody, required: ['code', 'name', 'price', 'period', 'periodDays'] } } }, async (req) => withTx(platformCtx(req), async (c) => {
    const b = req.body;
    if ((await c.query('SELECT 1 FROM subscription_plans WHERE code = $1', [b.code])).rowCount) throw E.conflict('A plan with this code already exists.');
    const r = (await c.query('INSERT INTO subscription_plans (code, name, description, price_kobo, period, period_days, sort_order) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *',
      [b.code, b.name, b.description || null, KOBO(b.price), b.period, b.periodDays, b.sortOrder || 0])).rows[0];
    await audit(c, req, 'billing.plan_created', { type: 'subscription_plan', id: r.id, meta: { code: b.code, priceKobo: r.price_kobo, period: b.period } });
    return r;
  }));
  app.patch('/platform/billing/plans/:id', { onRequest: P, schema: { params: idParams, body: planBody } }, async (req) => withTx(platformCtx(req), async (c) => {
    const b = req.body;
    const r = (await c.query(`UPDATE subscription_plans SET name = COALESCE($2, name), description = CASE WHEN $3 THEN $4 ELSE description END, price_kobo = COALESCE($5, price_kobo),
      period = COALESCE($6, period), period_days = COALESCE($7, period_days), active = COALESCE($8, active), sort_order = COALESCE($9, sort_order), updated_at = now() WHERE id = $1 RETURNING *`,
    [req.params.id, b.name || null, b.description !== undefined, b.description || null, b.price !== undefined ? KOBO(b.price) : null, b.period || null, b.periodDays || null, b.active ?? null, b.sortOrder ?? null])).rows[0];
    if (!r) throw E.notFound('Plan');
    await audit(c, req, 'billing.plan_updated', { type: 'subscription_plan', id: r.id, meta: { fields: Object.keys(b) } });
    return r;
  }));

  // ── platform owner: every school's subscription + payments ──
  app.get('/platform/billing/subscriptions', { onRequest: P }, async (req) => withTx(platformCtx(req), async (c) => ({
    items: (await c.query(`SELECT s.id AS school_id, s.name, s.slug, s.status AS school_status, s.is_demo, ss.status, ss.trial_ends_at, ss.current_period_end, p.name AS plan, ss.note,
        (SELECT max(verified_at) FROM subscription_payments x WHERE x.school_id = s.id AND x.status = 'success') AS last_paid_at
      FROM schools s LEFT JOIN school_subscriptions ss ON ss.school_id = s.id LEFT JOIN subscription_plans p ON p.id = ss.plan_id
      ORDER BY s.is_demo, s.name LIMIT 2000`)).rows,
  })));
  app.patch('/platform/billing/subscriptions/:id', {
    onRequest: P,
    schema: { params: idParams, body: obj({ status: { enum: ['trial', 'active', 'past_due', 'expired', 'cancelled'] }, planId: { type: ['string', 'null'], format: 'uuid' }, periodEnd: { type: ['string', 'null'], format: 'date-time' },
      trialEnd: { type: ['string', 'null'], format: 'date-time' }, note: str(300, 3) }, ['note']) },
  }, async (req) => withTx(platformCtx(req), async (c) => {
    const b = req.body;   // manual change (e.g. a confirmed bank transfer) — a reason is required and it is audited
    if (!(await c.query('SELECT 1 FROM schools WHERE id = $1', [req.params.id])).rowCount) throw E.notFound('School');
    const r = (await c.query(`INSERT INTO school_subscriptions (school_id, status, plan_id, current_period_end, trial_ends_at, note, updated_by, updated_at) VALUES ($1, COALESCE($2,'trial'), $3, $4, $5, $6, $7, now())
      ON CONFLICT (school_id) DO UPDATE SET status = COALESCE($2, school_subscriptions.status), plan_id = CASE WHEN $8 THEN $3 ELSE school_subscriptions.plan_id END,
        current_period_end = CASE WHEN $9 THEN $4 ELSE school_subscriptions.current_period_end END, trial_ends_at = CASE WHEN $10 THEN $5 ELSE school_subscriptions.trial_ends_at END,
        note = $6, updated_by = $7, updated_at = now() RETURNING *`,
    [req.params.id, b.status || null, b.planId || null, b.periodEnd || null, b.trialEnd || null, b.note, req.auth.userId, b.planId !== undefined, b.periodEnd !== undefined, b.trialEnd !== undefined])).rows[0];
    await audit(c, req, 'billing.subscription_changed_manually', { schoolId: req.params.id, type: 'school_subscription', id: req.params.id, meta: { ...b } });
    return r;
  }));
  app.get('/platform/billing/payments', { onRequest: P }, async (req) => withTx(platformCtx(req), async (c) => ({
    items: (await c.query(`SELECT p.id, p.reference, p.amount_kobo, p.currency, p.status, p.gateway_status, p.verified_at, p.created_at, p.period_end_after, s.name AS school, pl.name AS plan
      FROM subscription_payments p JOIN schools s ON s.id = p.school_id JOIN subscription_plans pl ON pl.id = p.plan_id ORDER BY p.created_at DESC LIMIT 500`)).rows,
  })));
  app.post('/platform/billing/payments/:id/verify', { onRequest: P, schema: { params: idParams } }, async (req) => {
    const ref = (await withTx(platformCtx(req), (c) => c.query('SELECT reference FROM subscription_payments WHERE id = $1', [req.params.id]))).rows[0];
    if (!ref) throw E.notFound('Payment');
    return verifySubscription(ref.reference, { ip: req.ip, headers: req.headers, userId: req.auth.userId, by: req.auth.loginId });
  });

  // ── school: my subscription ──
  app.get('/billing', { onRequest: [A, app.perm('settings.view')] }, async (req) => withTx(ctx(req), async (c) => {
    const sub = (await c.query('SELECT ss.status, ss.trial_ends_at, ss.current_period_end, p.name AS plan, p.code FROM school_subscriptions ss LEFT JOIN subscription_plans p ON p.id = ss.plan_id WHERE ss.school_id = $1', [req.auth.schoolId])).rows[0] || null;
    const plans = (await c.query('SELECT id, code, name, description, price_kobo, period, period_days FROM subscription_plans WHERE active ORDER BY sort_order, price_kobo')).rows;
    const payments = (await c.query('SELECT p.reference, p.amount_kobo, p.status, p.verified_at, p.created_at, p.period_end_after, pl.name AS plan FROM subscription_payments p JOIN subscription_plans pl ON pl.id = p.plan_id ORDER BY p.created_at DESC LIMIT 50')).rows;
    const online = !!(await platformSecret());
    const bankDetails = (await raw('SELECT app.platform_bank_details() AS b')).rows[0].b;
    return { subscription: sub, plans, payments, onlinePayments: online, bankDetails, canPay: req.can('settings.update') };
  }));
  app.post('/billing/checkout', {
    onRequest: [A, app.perm('settings.update')], config: { rateLimit: { max: 10, timeWindow: '1 minute' } },
    schema: { body: obj({ planId: uuid, email: { type: 'string', format: 'email', maxLength: 160 } }, ['planId', 'email']) },
  }, async (req) => {
    const secret = await platformSecret();
    if (!secret) throw E.notConfigured('Online payment is not set up yet. Pay by bank transfer and send the receipt to A.B.O.; your subscription will be updated after confirmation.');
    const p = await withTx(ctx(req), async (c) => {
      const plan = (await c.query('SELECT * FROM subscription_plans WHERE id = $1 AND active', [req.body.planId])).rows[0];
      if (!plan) throw E.notFound('Plan');
      const reference = `SUB-${crypto.randomBytes(12).toString('hex')}`;
      await c.query('INSERT INTO subscription_payments (school_id, plan_id, reference, amount_kobo, currency, created_by) VALUES ($1,$2,$3,$4,$5,$6)', [req.auth.schoolId, plan.id, reference, plan.price_kobo, 'NGN', req.auth.userId]);
      await audit(c, req, 'billing.checkout_started', { type: 'subscription_payment', id: reference, meta: { plan: plan.code, amountKobo: Number(plan.price_kobo) } });
      return { reference, amount: Number(plan.price_kobo), plan };
    });
    const res = await fetch(`${config.payments.paystackBaseUrl}/transaction/initialize`, {
      method: 'POST', headers: { authorization: `Bearer ${secret}`, 'content-type': 'application/json' }, signal: AbortSignal.timeout(15000),
      body: JSON.stringify({ email: req.body.email, amount: p.amount, reference: p.reference, currency: 'NGN', callback_url: `${config.publicOrigin}/#/billing?reference=${p.reference}`, metadata: { kind: 'subscription', plan: p.plan.code } }),
    }).catch(() => null);
    const j = res ? await res.json().catch(() => ({})) : {};
    if (!res || !res.ok || !j.status || !j.data || !/^https:\/\//.test(j.data.authorization_url || '')) throw new (require('../lib/errors').AppError)(502, 'GATEWAY_ERROR', 'The payment service did not answer. Nothing was charged — please try again.');
    return { authorizationUrl: j.data.authorization_url, reference: p.reference };
  });
  // the page comes back from Paystack with ?reference=… — the SERVER asks Paystack (never trusts the browser)
  app.post('/billing/verify', { onRequest: [A, app.perm('settings.view')], config: { rateLimit: { max: 20, timeWindow: '1 minute' } }, schema: { body: obj({ reference: { type: 'string', pattern: '^SUB-[A-Za-z0-9-]{8,60}$' } }, ['reference']) } }, async (req) => {
    const own = (await withTx(ctx(req), (c) => c.query('SELECT 1 FROM subscription_payments WHERE reference = $1', [req.body.reference]))).rowCount;
    if (!own) throw E.notFound('Payment');
    return verifySubscription(req.body.reference, { ip: req.ip, headers: req.headers, userId: req.auth.userId, by: req.auth.loginId });
  });

  // ── Paystack webhook for subscriptions (set this URL in the PLATFORM's Paystack dashboard) ──
  app.register(async (hook) => {
    hook.addContentTypeParser('application/json', { parseAs: 'buffer', bodyLimit: 256 * 1024 }, (req, body, done) => done(null, body));
    hook.post('/billing/webhook/paystack', { config: { webhook: true, rateLimit: { max: 300, timeWindow: '1 minute' } } }, async (req, reply) => {
      const secret = await platformSecret();
      if (!secret) return reply.code(404).send({ error: { code: 'NOT_FOUND', message: 'Endpoint not found.', requestId: req.id } });
      const sig = String(req.headers['x-paystack-signature'] || '');
      const expected = crypto.createHmac('sha512', secret).update(req.body).digest('hex');
      const valid = sig.length === expected.length && crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected));
      if (!valid) { securityEvent({ kind: 'payment_webhook_bad_signature', severity: 'high', detail: { target: 'billing' }, ip: req.ip }); return reply.code(401).send({ error: { code: 'INVALID_SIGNATURE', message: 'Invalid signature.', requestId: req.id } }); }
      let evt; try { evt = JSON.parse(req.body.toString('utf8')); } catch { return reply.code(400).send({ error: { code: 'BAD_REQUEST', message: 'Malformed payload.', requestId: req.id } }); }
      const ref = evt && evt.data && String(evt.data.reference || '');
      if (evt.event !== 'charge.success' || !/^SUB-[A-Za-z0-9-]{8,60}$/.test(ref)) return { ok: true };
      const r = await verifySubscription(ref, { ip: req.ip, headers: req.headers, by: 'paystack-webhook' });
      return r.ok ? { ok: true } : reply.code(202).send({ ok: false, status: r.status });
    });
  });
};
module.exports.verifySubscription = verifySubscription;
module.exports.platformSecret = platformSecret;
