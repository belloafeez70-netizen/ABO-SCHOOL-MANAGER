'use strict';
// Browser error intake: the web app (hosted on Netlify) reports uncaught JavaScript errors here so they show up in the
// same logs/alerts as server errors. Public but tightly limited: small schema, 20 reports/min per client, no cookies or
// personal data accepted (the client strips query strings; the server scrubs again).
const { obj, str } = require('../lib/schema');
const metrics = require('../lib/metrics');
const { alert, scrub } = require('../lib/alerts');

const recent = []; // timestamps (instance-wide) for spike detection
module.exports = async function telemetryRoutes(app) {
  app.post('/client-errors', {
    config: { rateLimit: { max: 20, timeWindow: '1 minute', keyGenerator: (req) => `ce:${req.ip}` } },
    schema: { body: obj({ message: str(500, 1), source: str(300), line: { type: 'integer', minimum: 0, maximum: 1e7 }, column: { type: 'integer', minimum: 0, maximum: 1e7 },
      stack: str(2000), route: str(200), release: str(80), kind: { enum: ['error', 'unhandledrejection'] } }, ['message']) },
  }, async (req, reply) => {
    const b = req.body;
    const route = scrub(String(b.route || '').split('?')[0]).slice(0, 120);
    req.log.warn({ clientError: { message: scrub(b.message), source: scrub(String(b.source || '').split('?')[0]), line: b.line, column: b.column, route, kind: b.kind || 'error', release: b.release,
      stack: scrub(b.stack).slice(0, 1500) }, ua: String(req.headers['user-agent'] || '').slice(0, 160) }, 'client error');
    metrics.inc('client_errors_total', { kind: b.kind || 'error' });
    const now = Date.now(); recent.push(now); while (recent.length && now - recent[0] > 300000) recent.shift();
    if (recent.length >= 25) alert('client_error_spike', { message: `${recent.length} browser errors in 5 min; latest: ${b.message}`, route: `web:${route}` });
    return reply.code(202).send({ ok: true });
  });
};
