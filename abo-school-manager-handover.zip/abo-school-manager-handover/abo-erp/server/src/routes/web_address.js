'use strict';
// School web address (the offline app's "School Web Address", server edition): the public sign-in page of the school is
// <site>/#/s/<address>. The school may change the address; the old one keeps working (school_slug_history) and can
// never be given to another school, so printed letters, flyers and WhatsApp links never lead to the wrong school.
const config = require('../config');
const { withTx, raw } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj } = require('../lib/schema');
const { ctx } = require('../auth/plugin');
const { audit } = require('../audit/audit');

const RESERVED = new Set(['www', 'api', 'app', 'admin', 'abo', 'login', 'signin', 'register', 'platform', 'support', 'help', 'mail', 'static', 'assets', 'status', 'school', 'schools', 'test', 'demo']);
const PATTERN = /^[a-z0-9](?:[a-z0-9-]{1,38})[a-z0-9]$/;
function check(slug) {
  if (!PATTERN.test(slug)) return 'Use 3–40 small letters (a–z), numbers or dashes. Start and end with a letter or number.';
  if (/--/.test(slug)) return 'Do not use two dashes together.';
  if (RESERVED.has(slug)) return 'That address is kept for the system. Choose another one.';
  return null;
}

module.exports = async function webAddressRoutes(app) {
  const A = app.authenticate;
  app.get('/school/web-address', { onRequest: [A, app.perm('settings.view')] }, async (req) => withTx(ctx(req), async (c) => {
    const s = (await c.query('SELECT slug, status FROM schools WHERE id = $1', [req.auth.schoolId])).rows[0];
    const old = (await c.query('SELECT slug, replaced_at FROM school_slug_history WHERE school_id = $1 ORDER BY replaced_at DESC LIMIT 20', [req.auth.schoolId])).rows;
    return { slug: s.slug, portalUrl: `${config.publicOrigin}/#/s/${s.slug}`, publicNow: s.status === 'active', oldAddresses: old, canChange: req.can('settings.update') };
  }));
  app.get('/school/web-address/check', { onRequest: [A, app.perm('settings.update')], schema: { querystring: obj({ slug: { type: 'string', maxLength: 60 } }, ['slug']) } }, async (req) => {
    const slug = String(req.query.slug || '').trim().toLowerCase();
    const err = check(slug); if (err) return { ok: false, message: err };
    const mine = (await withTx(ctx(req), (c) => c.query('SELECT 1 FROM schools WHERE id = $1 AND lower(slug) = $2 UNION SELECT 1 FROM school_slug_history WHERE school_id = $1 AND lower(slug) = $2', [req.auth.schoolId, slug]))).rowCount > 0;
    if (mine) return { ok: true, message: 'This is (or was) your own address.' };
    const taken = (await raw('SELECT app.school_slug_taken($1) AS t', [slug])).rows[0].t;
    return taken ? { ok: false, message: 'Another school already uses that address.' } : { ok: true, message: 'That address is free.' };
  });
  app.put('/school/web-address', {
    onRequest: [A, app.perm('settings.update')], config: { rateLimit: { max: 20, timeWindow: '1 hour' } },
    schema: { body: obj({ slug: { type: 'string', maxLength: 60 } }, ['slug']) },
  }, async (req) => {
    const slug = String(req.body.slug || '').trim().toLowerCase();
    const err = check(slug); if (err) throw E.bad(err, { field: 'slug' });
    return withTx(ctx(req), async (c) => {
      const cur = (await c.query('SELECT slug FROM schools WHERE id = $1 FOR UPDATE', [req.auth.schoolId])).rows[0];
      if (cur.slug.toLowerCase() === slug) return { slug, unchanged: true, portalUrl: `${config.publicOrigin}/#/s/${slug}` };
      const ownOld = (await c.query('SELECT 1 FROM school_slug_history WHERE school_id = $1 AND lower(slug) = $2', [req.auth.schoolId, slug])).rowCount > 0;
      if (!ownOld && (await raw('SELECT app.school_slug_taken($1) AS t', [slug])).rows[0].t) throw E.conflict('Another school already uses that address.');
      if (ownOld) await c.query('DELETE FROM school_slug_history WHERE school_id = $1 AND lower(slug) = $2', [req.auth.schoolId, slug]);   // going back to an old address
      await c.query('INSERT INTO school_slug_history (slug, school_id) VALUES ($1,$2) ON CONFLICT (slug) DO NOTHING', [cur.slug.toLowerCase(), req.auth.schoolId]);
      try { await c.query('UPDATE schools SET slug = $2 WHERE id = $1', [req.auth.schoolId, slug]); } catch (e) { if (e.code === '23505') throw E.conflict('Another school already uses that address.'); throw e; }
      await audit(c, req, 'school.web_address_changed', { type: 'school', id: req.auth.schoolId, meta: { from: cur.slug, to: slug } });
      return { slug, portalUrl: `${config.publicOrigin}/#/s/${slug}`, previous: cur.slug };
    });
  });
};
