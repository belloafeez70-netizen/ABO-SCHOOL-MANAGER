'use strict';
const config = require('../config');
const { withTx, raw } = require('../db/pool');
const { E, AppError } = require('../lib/errors');
const { obj, str, uuid } = require('../lib/schema');
const pw = require('../security/passwords');
const totp = require('../security/totp');
const { sha256, randomToken, encrypt, decrypt, humanCode } = require('../security/crypto');
// lazy: services/demo → provision → routes → auth/plugin would be a require cycle
const demoSvc = () => require('../services/demo');
const S = require('../auth/sessions');
const { audit, auditAlone, securityEvent, loginEvent } = require('../audit/audit');
const { notify, queueEmail } = require('../services/notify');
const { invalidateUser } = require('../auth/plugin');
const metrics = require('../lib/metrics');

const GENERIC_FAIL = 'Invalid Login ID or password.';
// identity-level updates run as the user themself (users RLS: id = app.current_user_id())
const userCtx = (u, schoolId = null) => ({ schoolId, userId: u.id, platform: !!u.is_platform_admin && !schoolId });
const memberships = async (userId) => (await raw('SELECT * FROM app.auth_user_memberships($1)', [userId])).rows;
// choose the school to sign into: requested slug/id if allowed, else default → most recently used
function pickMembership(list, wanted) {
  const ok = list.filter((m) => m.status === 'active' && m.school_status === 'active');
  if (wanted) return ok.find((m) => m.school_id === wanted) || null;
  return ok[0] || null;
}
// Sign-in identifiers (website parity): Login ID or e-mail for everyone; students may also use their ADMISSION NUMBER
// and parents their PHONE NUMBER. Alternative identifiers are resolved inside one school when the request comes from
// the school's own page (schoolId), and only when exactly one account matches (app.auth_resolve_login).
const PORTALS = ['staff', 'student', 'parent'];
const looksLikePhone = (v) => /^[+\d][\d\s()-]{8,}$/.test(v) && v.replace(/\D/g, '').length >= 10;
async function findAccount(ident, { schoolId = null, portal = null } = {}) {
  const id = String(ident || '').trim();
  const direct = (await raw('SELECT * FROM app.auth_find_user($1)', [id])).rows[0];
  if (direct) return direct;
  const kinds = portal === 'student' ? ['admission'] : portal === 'parent' ? ['phone'] : portal === 'staff' ? [] : [looksLikePhone(id) ? 'phone' : 'admission'];
  for (const kind of kinds) {
    const lid = (await raw('SELECT app.auth_resolve_login($1, $2, $3) AS l', [id, schoolId, kind])).rows[0].l;
    if (lid) { const u = (await raw('SELECT * FROM app.auth_find_user($1)', [lid])).rows[0]; if (u) return Object.assign(u, { resolvedBy: kind }); }
  }
  return null;
}
// the school-issued one-time access code may be typed in the password box (first sign-in)
function accessCodeMatches(u, input) {
  const code = String(input || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  return !!(u && code.length >= 6 && code.length <= 20 && u.access_code_hash && u.access_code_expires_at && new Date(u.access_code_expires_at) > new Date() &&
    require('../security/crypto').safeEqual(u.access_code_hash, sha256(code)));
}
const fingerprint = (ua, ip) => sha256(`${S.uaLabel(ua)}|${String(ip || '').split('.').slice(0, 3).join('.')}`);

async function mfaStateFor(c, user) {
  if (user.mfa_enabled) return 'pending';
  if (user.is_platform_admin) return config.isProdLike ? 'enroll_required' : 'none';
  const r = await c.query(`SELECT EXISTS (
      SELECT 1 FROM user_roles ur JOIN roles r ON r.id = ur.role_id
      LEFT JOIN school_settings ss ON ss.school_id = r.school_id
      WHERE ur.user_id = $1 AND (r.mfa_required OR r.key = ANY (COALESCE(ss.mfa_required_roles, '{}')))) AS req`, [user.id]);
  return r.rows[0].req ? 'enroll_required' : 'none';
}

module.exports = async function authRoutes(app) {
  const loginLimit = { rateLimit: { max: config.rateLimit.loginPerMinute, timeWindow: '1 minute' } };
  // Unauthenticated credential endpoints: limit per ACCOUNT per IP (so a whole class can sign in from one school IP
  // at 8am), plus a per-IP ceiling across all accounts (credential stuffing). Account lockout still applies.
  const acctKey = (field) => (req) => `a:${req.ip}:${require('node:crypto').createHash('sha256').update(String((req.body && req.body[field]) || '').trim().toLowerCase()).digest('hex').slice(0, 24)}`;
  const acctLimit = (field, max = config.rateLimit.loginPerMinute, timeWindow = '1 minute') => ({ rateLimit: { max, timeWindow, hook: 'preHandler', keyGenerator: acctKey(field) } });
  const authCeiling = require('../lib/ratekey').ipCeiling({ perMinute: config.rateLimit.authIpPerMinute, message: 'Too many sign-in attempts from this network. Please wait a minute.' });

  // ───────────── login ─────────────
  app.post('/auth/login', {
    config: acctLimit('loginId'), onRequest: [authCeiling],
    schema: { body: obj({ loginId: str(160, 3), password: str(128, 1), schoolId: uuid, portal: { enum: PORTALS } }, ['loginId', 'password']) },
  }, async (req, reply) => {
    const { loginId, password } = req.body;
    const ip = req.ip; const ua = req.headers['user-agent'];
    const u = await findAccount(loginId, { schoolId: req.body.schoolId || null, portal: req.body.portal || null });
    const ms = u && !u.is_platform_admin ? await memberships(u.id) : [];
    if (u) u.school_id = ms[0] ? ms[0].school_id : null;       // school used for event visibility only
    const fail = async (reason, user = null) => {
      metrics.inc('auth_login_failures_total', { reason });
      await loginEvent({ schoolId: user ? user.school_id : null, userId: user ? user.id : null, attempt: loginId, success: false, reason, ip, ua });
      // credential-stuffing heuristic: many failures from one IP across accounts
      const n = (await withTx({ platform: true }, (c) => c.query(`SELECT count(*)::int AS n, count(DISTINCT login_attempt)::int AS a FROM login_events
        WHERE ip = $1 AND NOT success AND created_at > now() - interval '10 minutes'`, [ip]))).rows[0];
      if (n.n === 20 || (n.a >= 8 && n.n % 10 === 0)) securityEvent({ kind: 'credential_stuffing_suspected', severity: 'high', detail: { failures: n.n, accounts: n.a }, ip });
      throw new AppError(401, 'INVALID_CREDENTIALS', GENERIC_FAIL);
    };
    // first sign-in with the school-issued access code in the password box → ask the holder to create a password
    const activation = async () => {
      if (u.status === 'disabled') return fail('inactive', u);
      if (!u.is_platform_admin && !pickMembership(ms, req.body.schoolId)) return fail('no_active_membership', u);   // suspended by the school
      await loginEvent({ schoolId: u.school_id, userId: u.id, attempt: loginId, success: false, reason: 'activation_required', ip, ua });
      return { ok: true, activationRequired: true, loginId: u.login_id, message: 'Access code accepted. Create your personal password to finish signing in.' };
    };
    if (!u) { await pw.verify(await pw.dummyHash(), password); return fail('unknown_user'); }
    if (u.locked_until && new Date(u.locked_until) > new Date()) { await pw.verify(await pw.dummyHash(), password); return fail('locked', u); }
    if (!u.password_hash) { await pw.verify(await pw.dummyHash(), password); return accessCodeMatches(u, password) ? activation() : fail('not_activated', u); }
    const ok = await pw.verify(u.password_hash, password);
    if (!ok && accessCodeMatches(u, password)) return activation();
    if (!ok) {
      const n = u.failed_attempts + 1;
      const over = n - config.lockout.threshold;
      const lockMin = over >= 0 ? Math.min(config.lockout.baseMinutes * 2 ** over, config.lockout.maxMinutes) : 0;
      await withTx(userCtx(u), (c) => c.query(`UPDATE users SET failed_attempts = $2, locked_until = CASE WHEN $3::int > 0 THEN now() + make_interval(mins => $3::int) ELSE locked_until END WHERE id = $1`, [u.id, n, lockMin]));
      if (lockMin > 0) {
        securityEvent({ schoolId: u.school_id, userId: u.id, kind: 'account_locked', severity: over >= 2 ? 'high' : 'medium', detail: { failures: n, minutes: lockMin }, ip });
        await auditAlone({ ip, headers: req.headers, auth: null }, 'auth.account_locked', { schoolId: u.school_id, type: 'user', id: u.id, success: false, meta: { failures: n, minutes: lockMin } });
      }
      return fail('bad_password', u);
    }
    if (u.status !== 'active') return fail('inactive', u);
    // demo-school accounts are only reachable through "Try the demo" (5-minute sessions), never with a password
    if (!u.is_platform_admin && ms.length && (await Promise.all(ms.map((m) => demoSvc().isDemoSchool(m.school_id)))).some(Boolean)) return fail('demo_account', u);
    let target = null;
    if (!u.is_platform_admin) {
      target = pickMembership(ms, req.body.schoolId);
      if (!target) {
        const anyMs = ms.find((m) => !req.body.schoolId || m.school_id === req.body.schoolId);
        const reason = !anyMs ? 'no_membership' : anyMs.school_status !== 'active' ? `school_${anyMs.school_status}` : `membership_${anyMs.status}`;
        await loginEvent({ schoolId: anyMs ? anyMs.school_id : null, userId: u.id, attempt: loginId, success: false, reason, ip, ua });
        if (anyMs && anyMs.school_status === 'pending') {
          const verified = (await raw('SELECT app.school_email_verified($1) AS v', [anyMs.school_id])).rows[0].v;
          throw new AppError(403, 'SCHOOL_INACTIVE', verified ? 'Your school is waiting for approval by the A.B.O. team. You will receive an e-mail once it is approved.' : 'Your school account is awaiting email verification. Open the link we e-mailed you.');
        }
        if (anyMs && anyMs.school_status === 'suspended') throw new AppError(403, 'SCHOOL_INACTIVE', 'This school account is suspended. Please contact support.');
        throw new AppError(403, 'NO_ACTIVE_MEMBERSHIP', 'Your access to this school is not active. Please contact the school office.');
      }
      u.school_id = target.school_id;
    }
    const out = await withTx(userCtx(u, u.school_id), async (c) => {
      const full = (await c.query('SELECT * FROM users WHERE id = $1', [u.id])).rows[0];
      const upd = pw.needsRehash(u.password_hash) ? await pw.hash(password) : null;
      await c.query(`UPDATE users SET failed_attempts = 0, locked_until = NULL, last_login_at = now(), last_login_ip = $2,
        password_hash = COALESCE($3, password_hash) WHERE id = $1`, [u.id, ip, upd]);
      const mfaState = await mfaStateFor(c, full);
      const { token, sessionId } = await S.createSession(c, { userId: u.id, schoolId: u.school_id, mfaState, ip, ua });
      if (u.school_id) await c.query('SELECT app.touch_membership($1, $2)', [u.id, u.school_id]);
      // suspicious-login detection: new device/network for an account that has history
      const fp = fingerprint(ua, ip);
      const known = (await c.query('SELECT count(*)::int AS n, bool_or(fingerprint = $2) AS seen FROM known_devices WHERE user_id = $1', [u.id, fp])).rows[0];
      await c.query(`INSERT INTO known_devices (user_id, school_id, fingerprint) VALUES ($1,$2,$3)
        ON CONFLICT (user_id, fingerprint) DO UPDATE SET last_seen = now()`, [u.id, u.school_id, fp]);
      const newDevice = known.n > 0 && !known.seen;
      if (newDevice) {
        await notify(c, u.school_id, [u.id], { kind: 'security', title: 'New sign-in to your account', body: `A sign-in from ${S.uaLabel(ua)} was detected. If this wasn't you, change your password and sign out other sessions.`, link: '#/security' });
        if (full.email) await queueEmail(c, { schoolId: u.school_id, to: full.email, subject: 'New sign-in to your A.B.O. account', body: `Hello ${full.full_name},\n\nA new sign-in from ${S.uaLabel(ua)} was detected on your account. If this was not you, reset your password immediately and sign out all sessions from the Security page.\n`, template: 'new_device' });
      }
      await c.query('INSERT INTO login_events (school_id, user_id, login_attempt, success, reason, ip, user_agent) VALUES ($1,$2,$3,true,$4,$5,$6)',
        [u.school_id, u.id, loginId, mfaState === 'pending' ? 'password_ok_mfa_pending' : 'ok', ip, String(ua || '').slice(0, 300)]);
      await audit(c, { ip, headers: req.headers, auth: { schoolId: u.school_id, userId: u.id, loginId: full.login_id, roles: [] } }, 'auth.login', { type: 'session', id: sessionId, meta: { mfaState, newDevice } });
      return { token, sessionId, mfaState, newDevice, mustChange: full.must_change_password };
    });
    if (out.newDevice) securityEvent({ schoolId: u.school_id, userId: u.id, kind: 'new_device_login', severity: 'low', detail: {}, ip });
    S.setCookie(reply, out.token);
    return { ok: true, mfaRequired: out.mfaState === 'pending', mfaEnrollRequired: out.mfaState === 'enroll_required', mustChangePassword: out.mustChange, csrf: S.csrfFor(out.sessionId) };
  });

  // ───────────── MFA verification (second step of login) ─────────────
  app.post('/auth/mfa/verify', {
    config: { ...loginLimit, allowMfaPending: true },
    onRequest: [app.authenticate],
    schema: { body: obj({ code: { type: 'string', pattern: '^[0-9]{6}$' }, recoveryCode: { type: 'string', pattern: '^[A-Z2-9-]{10,12}$' } }) },
  }, async (req, reply) => {
    const a = req.auth;
    if (a.mfaState !== 'pending') throw E.bad('Two-factor verification is not pending for this session.');
    const c0 = { schoolId: a.homeSchoolId, userId: a.userId, platform: !a.homeSchoolId };
    const result = await withTx(c0, async (c) => {
      const u = (await c.query('SELECT mfa_secret_enc, mfa_last_step FROM users WHERE id = $1 FOR UPDATE', [a.userId])).rows[0];
      let ok = false; let method = 'totp';
      if (req.body.code) {
        const step = totp.verify(decrypt(u.mfa_secret_enc), req.body.code, { lastStep: u.mfa_last_step === null ? null : Number(u.mfa_last_step) });
        if (step !== null) { ok = true; await c.query('UPDATE users SET mfa_last_step = $2 WHERE id = $1', [a.userId, step]); }
      } else if (req.body.recoveryCode) {
        method = 'recovery';
        const h = sha256(req.body.recoveryCode.replace(/-/g, ''));
        const r = await c.query('UPDATE mfa_recovery_codes SET used_at = now() WHERE user_id = $1 AND code_hash = $2 AND used_at IS NULL RETURNING id', [a.userId, h]);
        ok = r.rowCount === 1;
      }
      if (!ok) {
        const f = (await c.query('UPDATE sessions SET mfa_failures = mfa_failures + 1 WHERE id = $1 RETURNING mfa_failures', [a.sessionId])).rows[0].mfa_failures;
        if (f >= 5) await c.query("UPDATE sessions SET revoked_at = now(), revoked_reason = 'mfa_failures' WHERE id = $1", [a.sessionId]);
        return { ok: false, revoked: f >= 5 };
      }
      await c.query("UPDATE sessions SET mfa_state = 'verified', mfa_failures = 0 WHERE id = $1", [a.sessionId]);
      const token = await S.rotate(c, a.sessionId);
      await audit(c, req, 'auth.mfa_verified', { type: 'session', id: a.sessionId, meta: { method } });
      return { ok: true, token };
    });
    if (!result.ok) {
      await auditAlone(req, 'auth.mfa_failed', { type: 'session', id: a.sessionId, success: false });
      if (result.revoked) { securityEvent({ schoolId: a.homeSchoolId, userId: a.userId, kind: 'mfa_bruteforce', severity: 'high', ip: req.ip }); S.clearCookie(reply); throw E.unauth('Too many incorrect codes. Please sign in again.'); }
      throw new AppError(401, 'MFA_INVALID', 'That code is not valid. Try the latest code from your authenticator app.');
    }
    S.setCookie(reply, result.token);
    return { ok: true };
  });

  // ───────────── MFA enrolment ─────────────
  app.post('/auth/mfa/setup', { config: { allowMfaEnroll: true }, onRequest: [app.authenticate] }, async (req) => {
    const a = req.auth;
    if (a.mfaEnabled) throw E.conflict('Two-factor authentication is already enabled.');
    const secret = totp.generateSecret();
    await withTx({ schoolId: a.homeSchoolId, userId: a.userId, platform: !a.homeSchoolId }, (c) =>
      c.query('UPDATE users SET mfa_secret_enc = $2 WHERE id = $1', [a.userId, encrypt(secret)]));
    const uri = totp.otpauthUri(secret, a.loginId, config.mfaIssuer);
    const svg = await require('qrcode').toString(uri, { type: 'svg', margin: 1, errorCorrectionLevel: 'M' });
    return { secret, otpauthUri: uri, qrSvgDataUrl: 'data:image/svg+xml;base64,' + Buffer.from(svg).toString('base64') };
  });

  app.post('/auth/mfa/enable', {
    config: { allowMfaEnroll: true, ...loginLimit }, onRequest: [app.authenticate],
    schema: { body: obj({ code: { type: 'string', pattern: '^[0-9]{6}$' } }, ['code']) },
  }, async (req, reply) => {
    const a = req.auth;
    const out = await withTx({ schoolId: a.homeSchoolId, userId: a.userId, platform: !a.homeSchoolId }, async (c) => {
      const u = (await c.query('SELECT mfa_secret_enc, mfa_enabled FROM users WHERE id = $1 FOR UPDATE', [a.userId])).rows[0];
      if (u.mfa_enabled) throw E.conflict('Two-factor authentication is already enabled.');
      if (!u.mfa_secret_enc) throw E.bad('Start setup first.');
      const step = totp.verify(decrypt(u.mfa_secret_enc), req.body.code);
      if (step === null) throw new AppError(400, 'MFA_INVALID', 'That code is not valid. Check the time on your phone and try again.');
      const codes = Array.from({ length: 10 }, () => humanCode(10));
      await c.query('DELETE FROM mfa_recovery_codes WHERE user_id = $1', [a.userId]);
      await c.query(`INSERT INTO mfa_recovery_codes (user_id, school_id, code_hash) SELECT $1, $2, unnest($3::text[])`, [a.userId, a.homeSchoolId, codes.map((x) => sha256(x))]);
      await c.query('UPDATE users SET mfa_enabled = true, mfa_enrolled_at = now(), mfa_last_step = $2 WHERE id = $1', [a.userId, step]);
      await c.query("UPDATE sessions SET mfa_state = 'verified' WHERE id = $1", [a.sessionId]);
      const token = await S.rotate(c, a.sessionId);
      await audit(c, req, 'auth.mfa_enabled', { type: 'user', id: a.userId });
      return { codes: codes.map((x) => `${x.slice(0, 5)}-${x.slice(5)}`), token };
    });
    S.setCookie(reply, out.token);
    securityEvent({ schoolId: a.homeSchoolId, userId: a.userId, kind: 'mfa_enabled', severity: 'info', ip: req.ip });
    return { ok: true, recoveryCodes: out.codes };
  });

  app.post('/auth/mfa/disable', {
    onRequest: [app.authenticate], config: loginLimit,
    schema: { body: obj({ password: str(128, 1), code: { type: 'string', pattern: '^[0-9]{6}$' } }, ['password', 'code']) },
  }, async (req) => {
    const a = req.auth;
    await withTx({ schoolId: a.homeSchoolId, userId: a.userId, platform: !a.homeSchoolId }, async (c) => {
      const u = (await c.query('SELECT * FROM users WHERE id = $1 FOR UPDATE', [a.userId])).rows[0];
      if (!u.mfa_enabled) throw E.bad('Two-factor authentication is not enabled.');
      if ((await mfaStateFor(c, { ...u, mfa_enabled: false })) === 'enroll_required') throw E.forbidden('Your role requires two-factor authentication; it cannot be disabled.');
      if (!(await pw.verify(u.password_hash, req.body.password))) throw new AppError(401, 'INVALID_CREDENTIALS', 'Password is incorrect.');
      if (totp.verify(decrypt(u.mfa_secret_enc), req.body.code, { lastStep: u.mfa_last_step === null ? null : Number(u.mfa_last_step) }) === null) throw new AppError(400, 'MFA_INVALID', 'That code is not valid.');
      await c.query('UPDATE users SET mfa_enabled = false, mfa_secret_enc = NULL, mfa_last_step = NULL WHERE id = $1', [a.userId]);
      await c.query('DELETE FROM mfa_recovery_codes WHERE user_id = $1', [a.userId]);
      await audit(c, req, 'auth.mfa_disabled', { type: 'user', id: a.userId });
    });
    securityEvent({ schoolId: a.homeSchoolId, userId: a.userId, kind: 'mfa_disabled', severity: 'medium', ip: req.ip });
    return { ok: true };
  });

  // ───────────── password change / forgot / reset / activation ─────────────
  app.post('/auth/password/change', {
    config: { allowPasswordChange: true, ...loginLimit }, onRequest: [app.authenticate],
    schema: { body: obj({ currentPassword: str(128, 1), newPassword: str(128, 1) }, ['currentPassword', 'newPassword']) },
  }, async (req, reply) => {
    const a = req.auth;
    const token = await withTx({ schoolId: a.homeSchoolId, userId: a.userId, platform: !a.homeSchoolId }, async (c) => {
      const u = (await c.query('SELECT * FROM users WHERE id = $1 FOR UPDATE', [a.userId])).rows[0];
      if (!(await pw.verify(u.password_hash, req.body.currentPassword))) throw new AppError(401, 'INVALID_CREDENTIALS', 'Current password is incorrect.');
      const errs = pw.checkPolicy(req.body.newPassword, { loginId: u.login_id, fullName: u.full_name, staff: a.portal === 'staff' || a.portal === 'platform' });
      if (req.body.newPassword === req.body.currentPassword) errs.push('Choose a password different from the current one.');
      if (errs.length) throw E.bad(errs.join(' '), { password: errs });
      await c.query('UPDATE users SET password_hash = $2, must_change_password = false, password_changed_at = now() WHERE id = $1', [a.userId, await pw.hash(req.body.newPassword)]);
      await c.query("UPDATE sessions SET revoked_at = now(), revoked_reason = 'password_changed' WHERE user_id = $1 AND id <> $2 AND revoked_at IS NULL", [a.userId, a.sessionId]);
      const t = await S.rotate(c, a.sessionId);
      await audit(c, req, 'auth.password_changed', { type: 'user', id: a.userId });
      return t;
    });
    invalidateUser(a.userId);
    S.setCookie(reply, token);
    return { ok: true };
  });

  app.post('/auth/password/forgot', {
    config: acctLimit('identifier', 5, '15 minutes'), onRequest: [authCeiling],
    schema: { body: obj({ identifier: str(160, 3) }, ['identifier']) },
  }, async (req) => {
    const id = req.body.identifier.trim();
    let users = [];
    if (id.includes('@') && !/^[A-Za-z0-9._-]+$/.test(id)) users = (await raw('SELECT * FROM app.auth_find_user_by_email($1)', [id])).rows;
    if (!users.length) { const u = (await raw('SELECT * FROM app.auth_find_user($1)', [id])).rows[0]; if (u && u.status === 'active') users = [u]; }
    users = users.slice(0, 1);
    for (const u of users) {
      const ms = await memberships(u.id); u.school_id = ms[0] ? ms[0].school_id : null;
      await withTx(userCtx(u, u.school_id), async (c) => {
        const email = (await c.query('SELECT email, login_id, full_name FROM users WHERE id = $1', [u.id])).rows[0];
        if (!email || !email.email) return;           // no email on file → school admin must issue an access code
        const token = randomToken(32);
        await c.query("UPDATE user_tokens SET used_at = now() WHERE user_id = $1 AND kind = 'password_reset' AND used_at IS NULL", [u.id]);
        await c.query("INSERT INTO user_tokens (user_id, school_id, kind, token_hash, expires_at) VALUES ($1,$2,'password_reset',$3, now() + interval '30 minutes')", [u.id, u.school_id, sha256(token)]);
        await queueEmail(c, { schoolId: u.school_id, to: email.email, subject: 'Reset your A.B.O. School Manager password', template: 'password_reset',
          body: `Hello ${email.full_name},\n\nUse this link within 30 minutes to reset the password for Login ID ${email.login_id}:\n\n${config.publicOrigin}/#/reset?token=${token}\n\nIf you did not request this, ignore this email.\n` });
        await audit(c, { ip: req.ip, headers: req.headers, auth: null }, 'auth.password_reset_requested', { schoolId: u.school_id, type: 'user', id: u.id });
      });
    }
    // identical response whether or not the account exists (no enumeration)
    return { ok: true, message: 'If an account with an email address matches, a reset link has been sent. Students and parents without email should ask the school office for a new access code.' };
  });

  app.post('/auth/password/reset', {
    config: loginLimit,
    schema: { body: obj({ token: str(100, 20), newPassword: str(128, 1) }, ['token', 'newPassword']) },
  }, async (req) => {
    const t = (await raw('SELECT * FROM app.auth_find_token($1, $2)', [sha256(req.body.token), 'password_reset'])).rows[0];
    if (!t || t.used_at || new Date(t.expires_at) < new Date()) throw E.bad('This reset link is invalid or has expired.');
    await withTx({ schoolId: t.school_id, userId: t.user_id, platform: !t.school_id }, async (c) => {
      const u = (await c.query('SELECT * FROM users WHERE id = $1 FOR UPDATE', [t.user_id])).rows[0];
      const staff = !(await c.query("SELECT 1 FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = $1 AND r.portal <> 'staff'", [u.id])).rowCount;
      const errs = pw.checkPolicy(req.body.newPassword, { loginId: u.login_id, fullName: u.full_name, staff });
      if (errs.length) throw E.bad(errs.join(' '), { password: errs });
      const used = await c.query('UPDATE user_tokens SET used_at = now() WHERE id = $1 AND used_at IS NULL', [t.token_id]);
      if (!used.rowCount) throw E.bad('This reset link has already been used.');
      await c.query('UPDATE users SET password_hash = $2, must_change_password = false, password_changed_at = now(), failed_attempts = 0, locked_until = NULL WHERE id = $1', [u.id, await pw.hash(req.body.newPassword)]);
      await c.query("UPDATE sessions SET revoked_at = now(), revoked_reason = 'password_reset' WHERE user_id = $1 AND revoked_at IS NULL", [u.id]);
      await audit(c, { ip: req.ip, headers: req.headers, auth: { schoolId: u.school_id, userId: u.id, loginId: u.login_id, roles: [] } }, 'auth.password_reset', { type: 'user', id: u.id });
    });
    invalidateUser(t.user_id);
    return { ok: true };
  });

  // first-time activation with a one-time access code issued by the school (replaces the legacy "Login ID only" model)
  app.post('/auth/activate', {
    config: acctLimit('loginId'), onRequest: [authCeiling],
    schema: { body: obj({ loginId: str(160, 3), accessCode: str(20, 6), newPassword: str(128, 1), schoolId: uuid, portal: { enum: PORTALS } }, ['loginId', 'accessCode', 'newPassword']) },
  }, async (req) => {
    const u = await findAccount(req.body.loginId, { schoolId: req.body.schoolId || null, portal: req.body.portal || null });
    const valid = accessCodeMatches(u, req.body.accessCode) && u.status !== 'disabled' && !(u.locked_until && new Date(u.locked_until) > new Date()) &&
      (u.is_platform_admin || !!pickMembership(await memberships(u.id), req.body.schoolId));
    if (!valid) {
      if (u) await withTx(userCtx(u), (c) => c.query(`UPDATE users SET failed_attempts = failed_attempts + 1,
        locked_until = CASE WHEN failed_attempts + 1 >= $2 THEN now() + interval '15 minutes' ELSE locked_until END WHERE id = $1`, [u.id, config.lockout.threshold]));
      await loginEvent({ schoolId: u ? u.school_id : null, userId: u ? u.id : null, attempt: req.body.loginId, success: false, reason: 'bad_access_code', ip: req.ip, ua: req.headers['user-agent'] });
      throw new AppError(401, 'INVALID_CREDENTIALS', 'Login ID or access code is incorrect or expired.');
    }
    const ams = await memberships(u.id); u.school_id = ams[0] ? ams[0].school_id : null;
    await withTx(userCtx(u, u.school_id), async (c) => {
      const full = (await c.query('SELECT * FROM users WHERE id = $1 FOR UPDATE', [u.id])).rows[0];
      const staff = !(await c.query("SELECT 1 FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = $1 AND r.portal <> 'staff'", [u.id])).rowCount;
      const errs = pw.checkPolicy(req.body.newPassword, { loginId: full.login_id, fullName: full.full_name, staff });
      if (errs.length) throw E.bad(errs.join(' '), { password: errs });
      await c.query(`UPDATE users SET password_hash = $2, access_code_hash = NULL, access_code_expires_at = NULL, status = 'active',
        must_change_password = false, password_changed_at = now(), failed_attempts = 0, locked_until = NULL WHERE id = $1`, [u.id, await pw.hash(req.body.newPassword)]);
      await audit(c, { ip: req.ip, headers: req.headers, auth: { schoolId: u.school_id, userId: u.id, loginId: full.login_id, roles: [] } }, 'auth.account_activated', { type: 'user', id: u.id });
    });
    return { ok: true, loginId: u.login_id, message: 'Account activated. You can now sign in with your new password.' };
  });

  app.post('/auth/verify-email', {
    config: { rateLimit: { max: 10, timeWindow: '15 minutes' } },
    schema: { body: obj({ token: str(100, 20) }, ['token']) },
  }, async (req) => {
    const t = (await raw('SELECT * FROM app.auth_find_token($1, $2)', [sha256(req.body.token), 'email_verify'])).rows[0];
    if (!t || t.used_at || new Date(t.expires_at) < new Date()) throw E.bad('This verification link is invalid or has expired.');
    let activated = false; let awaiting = false;
    await withTx({ schoolId: t.school_id, userId: t.user_id }, async (c) => {
      await c.query('UPDATE user_tokens SET used_at = now() WHERE id = $1', [t.token_id]);
      await c.query('UPDATE users SET email_verified_at = now() WHERE id = $1', [t.user_id]);
      // manual approval (default): the school stays PENDING until a platform admin approves it
      const auto = config.schoolApproval === 'auto';
      const s = await c.query(`UPDATE schools SET email_verified_at = COALESCE(email_verified_at, now()),
          status = CASE WHEN $2 THEN 'active' ELSE status END, approved_at = CASE WHEN $2 THEN now() ELSE approved_at END
        WHERE id = $1 AND status = 'pending' RETURNING id, status`, [t.school_id, auto]);
      activated = !!(s.rows[0] && s.rows[0].status === 'active');
      awaiting = !!(s.rows[0] && s.rows[0].status === 'pending');
      await audit(c, { ip: req.ip, headers: req.headers, auth: { schoolId: t.school_id, userId: t.user_id, loginId: null, roles: [] } }, 'auth.email_verified', { type: 'user', id: t.user_id, meta: { schoolActivated: activated, awaitingApproval: awaiting } });
    });
    if (awaiting) return { ok: true, awaitingApproval: true, message: 'Email verified. Your school is now waiting for approval by the A.B.O. team — we will e-mail you as soon as it is approved.' };
    return { ok: true, message: activated ? 'Email verified. Your school is active — you can sign in now.' : 'Email verified. You can sign in now.' };
  });

  // ───────────── memberships: list, accept invitations, switch school ─────────────
  app.get('/auth/memberships', { onRequest: [app.authenticate] }, async (req) => ({
    items: (await memberships(req.auth.userId)).map((m) => ({ id: m.membership_id, schoolId: m.school_id, schoolName: m.school_name, schoolStatus: m.school_status, status: m.status, current: m.school_id === req.auth.homeSchoolId, branchId: m.branch_id })),
  }));
  app.post('/auth/memberships/:id/respond', {
    onRequest: [app.authenticate], schema: { params: obj({ id: uuid }, ['id']), body: obj({ accept: { type: 'boolean' } }, ['accept']) },
  }, async (req) => {
    const r = await raw('SELECT app.respond_membership($1, $2, $3) AS s', [req.params.id, req.auth.userId, req.body.accept]);
    const school = r.rows[0].s;
    if (!school) throw E.notFound('Invitation');
    await withTx({ schoolId: school, userId: req.auth.userId }, (c) => audit(c, req, req.body.accept ? 'users.membership_accepted' : 'users.membership_declined', { schoolId: school, type: 'membership', id: req.params.id }));
    return { ok: true };
  });
  app.post('/auth/switch-school', {
    onRequest: [app.authenticate], config: { rateLimit: { max: 30, timeWindow: '1 minute' } }, schema: { body: obj({ schoolId: uuid }, ['schoolId']) },
  }, async (req, reply) => {
    const a = req.auth;
    if (a.isPlatform) throw E.bad('Platform administrators use the support view instead.');
    const target = pickMembership(await memberships(a.userId), req.body.schoolId);
    if (!target) throw E.notFound('School');
    const out = await withTx({ schoolId: target.school_id, userId: a.userId }, async (c) => {
      const u = (await c.query('SELECT * FROM users WHERE id = $1', [a.userId])).rows[0];
      let mfaState = await mfaStateFor(c, { ...u, mfa_enabled: false });            // does the NEW school require MFA?
      if (u.mfa_enabled) mfaState = a.mfaState === 'verified' ? 'verified' : 'pending';
      else if (mfaState !== 'enroll_required') mfaState = 'none';
      await c.query('UPDATE sessions SET school_id = $2, mfa_state = $3, support_school_id = NULL WHERE id = $1', [a.sessionId, target.school_id, mfaState]);
      await c.query('SELECT app.touch_membership($1, $2)', [a.userId, target.school_id]);
      const token = await S.rotate(c, a.sessionId);
      await audit(c, req, 'auth.school_switched', { schoolId: target.school_id, type: 'session', id: a.sessionId, meta: { from: a.homeSchoolId } });
      return { token, mfaState };
    });
    invalidateUser(a.userId);
    S.setCookie(reply, out.token);
    return { ok: true, mfaState: out.mfaState };
  });

  // ───────────── sessions ─────────────
  app.post('/auth/logout', { config: { allowMfaPending: true, allowMfaEnroll: true, allowPasswordChange: true }, onRequest: [app.authenticate] }, async (req, reply) => {
    const a = req.auth;
    await withTx({ schoolId: a.homeSchoolId, userId: a.userId, platform: !a.homeSchoolId }, async (c) => {
      await c.query("UPDATE sessions SET revoked_at = now(), revoked_reason = 'logout' WHERE id = $1", [a.sessionId]);
      await audit(c, req, 'auth.logout', { schoolId: a.homeSchoolId, type: 'session', id: a.sessionId });
    });
    S.clearCookie(reply);
    return { ok: true };
  });
  app.post('/auth/logout-all', { onRequest: [app.authenticate] }, async (req, reply) => {
    const a = req.auth;
    await withTx({ schoolId: a.homeSchoolId, userId: a.userId, platform: !a.homeSchoolId }, async (c) => {
      const r = await c.query("UPDATE sessions SET revoked_at = now(), revoked_reason = 'logout_all' WHERE user_id = $1 AND revoked_at IS NULL", [a.userId]);
      await audit(c, req, 'auth.logout_all', { schoolId: a.homeSchoolId, type: 'user', id: a.userId, meta: { sessions: r.rowCount } });
    });
    S.clearCookie(reply);
    return { ok: true };
  });
  app.get('/auth/sessions', { config: { allowMfaEnroll: true }, onRequest: [app.authenticate] }, async (req) => {
    const a = req.auth;
    const rows = await withTx({ schoolId: a.homeSchoolId, userId: a.userId, platform: !a.homeSchoolId, readOnly: true }, (c) => c.query(
      `SELECT id, device_label, host(ip) AS ip, created_at, last_seen_at, expires_at, mfa_state, (id = $2) AS current
       FROM sessions WHERE user_id = $1 AND revoked_at IS NULL AND expires_at > now() ORDER BY last_seen_at DESC`, [a.userId, a.sessionId]));
    return { items: rows.rows };
  });
  app.delete('/auth/sessions/:id', { onRequest: [app.authenticate], schema: { params: obj({ id: uuid }, ['id']) } }, async (req) => {
    const a = req.auth;
    await withTx({ schoolId: a.homeSchoolId, userId: a.userId, platform: !a.homeSchoolId }, async (c) => {
      const r = await c.query("UPDATE sessions SET revoked_at = now(), revoked_reason = 'user_revoked' WHERE id = $1 AND user_id = $2 AND revoked_at IS NULL", [req.params.id, a.userId]);
      if (!r.rowCount) throw E.notFound('Session');
      await audit(c, req, 'auth.session_revoked', { schoolId: a.homeSchoolId, type: 'session', id: req.params.id });
    });
    return { ok: true };
  });
};
