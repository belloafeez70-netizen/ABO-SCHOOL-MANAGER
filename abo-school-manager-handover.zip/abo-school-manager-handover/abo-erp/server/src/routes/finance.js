'use strict';
// Fees & payments. Integer kobo everywhere. Invoice totals are computed on the server from fee structures,
// student-specific charges and approved discounts. A payment is allocated to one or more invoices
// (payment_allocations); each confirmed payment gets exactly one receipt. Client-supplied totals are never
// trusted; allocations are validated against row-locked invoice balances; Idempotency-Key prevents
// duplicate payments; online payments are credited only after provider verification.
const crypto = require('node:crypto');
const config = require('../config');
const { withTx, raw } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, str, uuid, kobo, idParams, listQuery, date } = require('../lib/schema');
const { page, paged, likeEscape } = require('../lib/http');
const { ctx } = require('../auth/plugin');
const { audit, securityEvent } = require('../audit/audit');
const { notify } = require('../services/notify');
const { withIdempotency } = require('../lib/idempotency');

const naira = (k) => `₦${(Number(k) / 100).toLocaleString('en-NG')}`;
async function nextNo(c, schoolId, kind, prefix) {
  const y = new Date().getFullYear();
  const r = (await c.query(`INSERT INTO doc_counters (school_id, kind, year, last_no) VALUES ($1,$2,$3,1)
    ON CONFLICT (school_id, kind, year) DO UPDATE SET last_no = doc_counters.last_no + 1 RETURNING last_no`, [schoolId, kind, y])).rows[0].last_no;
  return `${prefix}-${y}-${String(r).padStart(6, '0')}`;
}
const statusFor = (paid, total) => (paid <= 0 ? 'unpaid' : paid >= total ? 'paid' : 'partial');
async function recomputeInvoice(c, invoiceId) {
  const r = (await c.query(`UPDATE invoices i SET subtotal_kobo = x.sub, total_kobo = x.sub - LEAST(i.discount_kobo, x.sub)
      , discount_kobo = LEAST(i.discount_kobo, x.sub)
    FROM (SELECT COALESCE(sum(amount_kobo), 0)::bigint AS sub FROM invoice_items WHERE invoice_id = $1) x WHERE i.id = $1 RETURNING i.total_kobo, i.paid_kobo`, [invoiceId])).rows[0];
  await c.query('UPDATE invoices SET status = $2 WHERE id = $1 AND status <> \'void\'', [invoiceId, statusFor(Number(r.paid_kobo), Number(r.total_kobo))]);
}

// Allocate `amount` of a new payment across invoices. Invoices are locked in id order (deadlock-free).
async function allocate(c, schoolId, paymentId, allocations) {
  const sorted = [...allocations].sort((a, b) => a.invoiceId.localeCompare(b.invoiceId));
  const touched = [];
  for (const a of sorted) {
    const inv = (await c.query('SELECT * FROM invoices WHERE id = $1 FOR UPDATE', [a.invoiceId])).rows[0];
    if (!inv) throw E.notFound('Invoice');
    if (inv.status === 'void') throw E.bad(`Invoice ${inv.invoice_no} is void.`);
    const balance = Number(inv.total_kobo) - Number(inv.paid_kobo);
    if (a.amountKobo > balance) throw E.bad(`Amount for ${inv.invoice_no} exceeds its outstanding balance of ${naira(balance)}.`);
    await c.query('INSERT INTO payment_allocations (school_id, payment_id, invoice_id, amount_kobo) VALUES ($1,$2,$3,$4)', [schoolId, paymentId, inv.id, a.amountKobo]);
    const paid = Number(inv.paid_kobo) + a.amountKobo;
    await c.query('UPDATE invoices SET paid_kobo = $2, status = $3 WHERE id = $1', [inv.id, paid, statusFor(paid, Number(inv.total_kobo))]);
    touched.push({ ...inv, allocated: a.amountKobo });
  }
  return touched;
}
async function recordPayment(c, req, { amount, method, reference, note, paidAt, allocations, provider = null, providerRef = null, receivedBy, payerStudentId = null, payerGuardianId = null, schoolId }) {
  const sum = allocations.reduce((x, a) => x + a.amountKobo, 0);
  if (sum !== amount) throw E.bad('Allocations must add up exactly to the payment amount.');
  // lock every target invoice FIRST, in id order — inserting the payment/allocation rows takes FK key-share
  // locks on the invoices, and upgrading those later would deadlock two concurrent payments
  await c.query('SELECT id FROM invoices WHERE id = ANY($1::uuid[]) ORDER BY id FOR UPDATE', [allocations.map((x) => x.invoiceId)]);
  const p = (await c.query(`INSERT INTO payments (school_id, invoice_id, student_id, payer_guardian_id, amount_kobo, method, reference, status, provider, provider_ref, verified_at, note, received_by, paid_at)
    VALUES ($1,$2,$3,$4,$5,$6,$7,'confirmed',$8,$9,$10,$11,$12,COALESCE($13, now())) RETURNING id, amount_kobo, reference`,
  [schoolId, allocations.length === 1 ? allocations[0].invoiceId : null, payerStudentId, payerGuardianId, amount, method, reference, provider, providerRef, provider ? new Date() : null, note || null, receivedBy, paidAt || null])).rows[0];
  const invs = await allocate(c, schoolId, p.id, allocations);
  const receiptNo = await nextNo(c, schoolId, 'receipt', 'RCT');
  await c.query('INSERT INTO receipts (school_id, payment_id, receipt_no, issued_by) VALUES ($1,$2,$3,$4)', [schoolId, p.id, receiptNo, receivedBy]);
  const students = [...new Set(invs.map((i) => i.student_id))];
  const recipients = (await c.query(`SELECT g.user_id FROM student_guardians sg JOIN guardians g ON g.id = sg.guardian_id WHERE sg.student_id = ANY($1::uuid[]) AND g.user_id IS NOT NULL
    UNION SELECT user_id FROM students WHERE id = ANY($1::uuid[]) AND user_id IS NOT NULL`, [students])).rows.map((r) => r.user_id);
  await notify(c, schoolId, recipients, { kind: 'fees', title: `Payment received: ${naira(amount)}`, body: `Receipt ${receiptNo}`, link: '#/my-fees' });
  return { id: p.id, receipt_no: receiptNo, amount_kobo: amount, reference: p.reference, allocations: invs.map((i) => ({ invoiceId: i.id, invoiceNo: i.invoice_no, amountKobo: i.allocated })) };
}
async function feeAccess(req, studentId) {
  if (req.can('fees.view')) return;
  if (req.can('fees.view_own') && studentId === req.auth.studentId) return;
  if (req.can('fees.view_children') && req.auth.children.includes(studentId)) return;
  throw E.notFound('Invoice');
}
// per-session rate-limit key (falls back to IP) for expensive / money-moving endpoints
const perSession = (max, win) => ({ rateLimit: { max, timeWindow: win, keyGenerator: (req) => { const k = Object.values(req.cookies || {})[0]; return k ? `s:${crypto.createHash('sha256').update(k).digest('hex').slice(0, 24)}` : `ip:${req.ip}`; } } });

module.exports = async function financeRoutes(app) {
  const A = app.authenticate;

  // ── fee categories ──
  app.get('/fees/categories', { onRequest: [A, app.perm('fees.view')] }, async (req) => withTx(ctx(req), async (c) => ({
    items: (await c.query('SELECT id, code, name, active FROM fee_categories ORDER BY name')).rows,
  })));
  app.post('/fees/categories', { onRequest: [A, app.perm('fees.create')], schema: { body: obj({ code: { type: 'string', pattern: '^[a-z0-9_]{2,30}$' }, name: str(80, 2) }, ['code', 'name']) } }, async (req) =>
    withTx(ctx(req), async (c) => {
      const r = (await c.query('INSERT INTO fee_categories (school_id, code, name) VALUES ($1,$2,$3) RETURNING id, code, name', [req.auth.schoolId, req.body.code, req.body.name])).rows[0];
      await audit(c, req, 'fees.category_created', { type: 'fee_category', id: r.id, meta: req.body });
      return r;
    }));
  app.patch('/fees/categories/:id', { onRequest: [A, app.perm('fees.update')], schema: { params: idParams, body: obj({ name: str(80, 2), active: { type: 'boolean' } }) } }, async (req) =>
    withTx(ctx(req), async (c) => {
      const r = await c.query('UPDATE fee_categories SET name = COALESCE($2, name), active = COALESCE($3, active) WHERE id = $1 RETURNING id', [req.params.id, req.body.name || null, req.body.active ?? null]);
      if (!r.rowCount) throw E.notFound('Category');
      await audit(c, req, 'fees.category_updated', { type: 'fee_category', id: req.params.id, meta: req.body });
      return { ok: true };
    }));

  // ── fee structures (what the school charges, per term/class) ──
  app.get('/fees/structures', { onRequest: [A, app.perm('fees.view')] }, async (req) => withTx(ctx(req), async (c) => ({
    items: (await c.query(`SELECT f.id, f.name, f.category_id, fc.name AS category, fc.code AS category_code, f.amount_kobo, f.term_id, f.class_id, f.mandatory, f.active, cl.display_name AS class_name, t.name AS term
      FROM fee_structures f JOIN fee_categories fc ON fc.id = f.category_id LEFT JOIN classes cl ON cl.id = f.class_id LEFT JOIN terms t ON t.id = f.term_id ORDER BY f.active DESC, f.name`)).rows,
  })));
  const structBody = obj({ name: str(120, 2), categoryId: uuid, amountKobo: kobo, termId: { type: ['string', 'null'], format: 'uuid' }, classId: { type: ['string', 'null'], format: 'uuid' }, mandatory: { type: 'boolean' }, active: { type: 'boolean' } });
  app.post('/fees/structures', { onRequest: [A, app.perm('fees.create')], schema: { body: { ...structBody, required: ['name', 'categoryId', 'amountKobo'] } } }, async (req) => withTx(ctx(req), async (c) => {
    const b = req.body;
    const r = (await c.query(`INSERT INTO fee_structures (school_id, name, category_id, amount_kobo, term_id, class_id, mandatory, created_by) VALUES ($1,$2,$3,$4,$5,$6,COALESCE($7,true),$8) RETURNING id, name, amount_kobo`,
      [req.auth.schoolId, b.name, b.categoryId, b.amountKobo, b.termId || null, b.classId || null, b.mandatory, req.auth.userId])).rows[0];
    await audit(c, req, 'fees.structure_created', { type: 'fee_structure', id: r.id, meta: { name: r.name, amountKobo: r.amount_kobo } });
    return r;
  }));
  app.patch('/fees/structures/:id', { onRequest: [A, app.perm('fees.update')], schema: { params: idParams, body: structBody } }, async (req) => withTx(ctx(req), async (c) => {
    const b = req.body; const map = { name: 'name', categoryId: 'category_id', amountKobo: 'amount_kobo', termId: 'term_id', classId: 'class_id', mandatory: 'mandatory', active: 'active' };
    const sets = []; const p = [req.params.id];
    for (const [k, col] of Object.entries(map)) if (b[k] !== undefined) { p.push(b[k]); sets.push(`${col} = $${p.length}`); }
    if (!sets.length) throw E.bad('Nothing to update.');
    const r = await c.query(`UPDATE fee_structures SET ${sets.join(', ')} WHERE id = $1 RETURNING id`, p);
    if (!r.rowCount) throw E.notFound('Fee structure');
    await audit(c, req, 'fees.structure_updated', { type: 'fee_structure', id: req.params.id, meta: b });
    return { ok: true };
  }));

  // ── discounts & scholarships (four-eyes approval) ──
  app.get('/fees/discounts', { onRequest: [A, app.perm('fees.view')] }, async (req) => withTx(ctx(req), async (c) => ({
    items: (await c.query(`SELECT d.*, s.first_name || ' ' || s.last_name AS student FROM fee_discounts d JOIN students s ON s.id = d.student_id ORDER BY d.created_at DESC LIMIT 300`)).rows,
  })));
  app.post('/fees/discounts', {
    onRequest: [A, app.perm('fees.create')],
    schema: { body: obj({ studentId: uuid, termId: { type: ['string', 'null'], format: 'uuid' }, kind: { enum: ['discount', 'scholarship', 'sibling', 'staff_child'] }, percent: { type: ['number', 'null'], exclusiveMinimum: 0, maximum: 100 }, amountKobo: { type: ['integer', 'null'], minimum: 1, maximum: 100000000000 }, reason: str(300, 3) }, ['studentId', 'kind', 'reason']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const b = req.body;
    if ((b.percent == null) === (b.amountKobo == null)) throw E.bad('Give either a percentage or a fixed amount.');
    const r = (await c.query(`INSERT INTO fee_discounts (school_id, student_id, term_id, kind, percent, amount_kobo, reason, requested_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id, status`,
      [req.auth.schoolId, b.studentId, b.termId || null, b.kind, b.percent ?? null, b.amountKobo ?? null, b.reason, req.auth.userId])).rows[0];
    await audit(c, req, 'fees.discount_requested', { type: 'fee_discount', id: r.id, meta: b });
    return r;
  }));
  app.post('/fees/discounts/:id/review', { onRequest: [A, app.perm('fees.approve')], schema: { params: idParams, body: obj({ action: { enum: ['approve', 'reject'] } }, ['action']) } }, async (req) => withTx(ctx(req), async (c) => {
    const d = (await c.query('SELECT * FROM fee_discounts WHERE id = $1 FOR UPDATE', [req.params.id])).rows[0];
    if (!d) throw E.notFound('Discount');
    if (d.status !== 'pending') throw E.conflict('Already reviewed.');
    if (d.requested_by === req.auth.userId) throw E.forbidden('You cannot approve your own discount request (four-eyes rule).');
    await c.query('UPDATE fee_discounts SET status = $2, approved_by = $3, approved_at = now() WHERE id = $1', [d.id, req.body.action === 'approve' ? 'approved' : 'rejected', req.auth.userId]);
    await audit(c, req, `fees.discount_${req.body.action === 'approve' ? 'approved' : 'rejected'}`, { type: 'fee_discount', id: d.id });
    return { ok: true };
  }));

  // ── invoices ──
  app.post('/fees/invoices/generate', {
    onRequest: [A, app.perm('fees.create')], config: perSession(10, '1 minute'),
    schema: { body: obj({ termId: uuid, classId: { type: ['string', 'null'], format: 'uuid' }, studentIds: { type: 'array', items: uuid, maxItems: 5000 }, dueDate: date }, ['termId']) },
  }, async (req, reply) => withTx(ctx(req), async (c) => withIdempotency(c, req, reply, 'invoices.generate', async () => {
    const b = req.body;
    const term = (await c.query('SELECT t.id, t.session_id FROM terms t WHERE t.id = $1', [b.termId])).rows[0];
    if (!term) throw E.notFound('Term');
    const p = [term.session_id]; let w = "e.session_id = $1 AND e.status = 'active' AND s.status = 'active' AND s.deleted_at IS NULL";
    if (b.classId) { p.push(b.classId); w += ` AND e.class_id = $${p.length}`; }
    if (b.studentIds && b.studentIds.length) { p.push(b.studentIds); w += ` AND s.id = ANY($${p.length}::uuid[])`; }
    const students = (await c.query(`SELECT s.id, e.class_id FROM student_enrollments e JOIN students s ON s.id = e.student_id WHERE ${w}`, p)).rows;
    const items = (await c.query('SELECT * FROM fee_structures WHERE active AND mandatory AND (term_id IS NULL OR term_id = $1)', [b.termId])).rows;
    let created = 0, skipped = 0;
    for (const s of students) {
      if ((await c.query("SELECT 1 FROM invoices WHERE student_id = $1 AND term_id = $2 AND status <> 'void'", [s.id, b.termId])).rowCount) { skipped++; continue; }
      const lines = items.filter((i) => !i.class_id || i.class_id === s.class_id);
      if (!lines.length) { skipped++; continue; }
      const subtotal = lines.reduce((a, i) => a + Number(i.amount_kobo), 0);
      let discount = 0;
      for (const d of (await c.query("SELECT percent, amount_kobo FROM fee_discounts WHERE student_id = $1 AND status = 'approved' AND (term_id IS NULL OR term_id = $2)", [s.id, b.termId])).rows) {
        discount += d.percent != null ? Math.round(subtotal * Number(d.percent) / 100) : Number(d.amount_kobo);
      }
      discount = Math.min(discount, subtotal);
      const no = await nextNo(c, req.auth.schoolId, 'invoice', 'INV');
      const inv = (await c.query(`INSERT INTO invoices (school_id, invoice_no, student_id, term_id, subtotal_kobo, discount_kobo, total_kobo, status, due_date, issued_by)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`, [req.auth.schoolId, no, s.id, b.termId, subtotal, discount, subtotal - discount, subtotal - discount === 0 ? 'paid' : 'unpaid', b.dueDate || null, req.auth.userId])).rows[0];
      for (const i of lines) await c.query('INSERT INTO invoice_items (school_id, invoice_id, fee_structure_id, description, amount_kobo, kind, created_by) VALUES ($1,$2,$3,$4,$5,\'structure\',$6)', [req.auth.schoolId, inv.id, i.id, i.name, i.amount_kobo, req.auth.userId]);
      created++;
    }
    await audit(c, req, 'fees.invoices_generated', { type: 'term', id: b.termId, meta: { created, skipped, classId: b.classId || null } });
    return { created, skipped };
  })));

  app.get('/fees/invoices', { onRequest: [A, app.perm('fees.view')], schema: { querystring: listQuery({ termId: uuid, classId: uuid, studentId: uuid, status: { enum: ['unpaid', 'partial', 'paid', 'void'] }, outstanding: { type: 'boolean' } }) } }, async (req) => {
    const pg = page(req.query);
    return withTx(ctx(req), async (c) => {
      const p = []; const w = [];
      if (req.query.termId) { p.push(req.query.termId); w.push(`i.term_id = $${p.length}`); }
      if (req.query.studentId) { p.push(req.query.studentId); w.push(`i.student_id = $${p.length}`); }
      if (req.query.status) { p.push(req.query.status); w.push(`i.status = $${p.length}`); }
      if (req.query.outstanding) w.push("i.status IN ('unpaid','partial')");
      if (req.query.classId) { p.push(req.query.classId); w.push(`EXISTS (SELECT 1 FROM student_enrollments e WHERE e.student_id = i.student_id AND e.class_id = $${p.length})`); }
      if (req.query.q) { p.push(`%${likeEscape(req.query.q.toLowerCase())}%`); w.push(`(lower(s.first_name || ' ' || s.last_name) LIKE $${p.length} OR lower(i.invoice_no) LIKE $${p.length} OR lower(s.admission_no) LIKE $${p.length})`); }
      const where = w.length ? 'WHERE ' + w.join(' AND ') : '';
      const total = (await c.query(`SELECT count(*)::int AS n FROM invoices i JOIN students s ON s.id = i.student_id ${where}`, p)).rows[0].n;
      const rows = (await c.query(`SELECT i.id, i.invoice_no, i.status, i.total_kobo, i.paid_kobo, (i.total_kobo - i.paid_kobo) AS balance_kobo, i.due_date, i.issued_at,
        s.id AS student_id, s.first_name || ' ' || s.last_name AS student, s.admission_no FROM invoices i JOIN students s ON s.id = i.student_id ${where}
        ORDER BY i.issued_at DESC LIMIT ${pg.limit} OFFSET ${pg.offset}`, p)).rows;
      return paged(rows, total, pg);
    });
  });

  app.get('/fees/invoices/:id', { onRequest: [A, app.perm('fees.view', 'fees.view_own', 'fees.view_children')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const inv = (await c.query(`SELECT i.*, s.first_name, s.last_name, s.admission_no, t.name AS term, se.name AS session FROM invoices i JOIN students s ON s.id = i.student_id
      LEFT JOIN terms t ON t.id = i.term_id LEFT JOIN academic_sessions se ON se.id = t.session_id WHERE i.id = $1`, [req.params.id])).rows[0];
    if (!inv) throw E.notFound('Invoice');
    await feeAccess(req, inv.student_id);
    const items = (await c.query('SELECT id, description, amount_kobo, kind FROM invoice_items WHERE invoice_id = $1 ORDER BY kind, description', [inv.id])).rows;
    const payments = (await c.query(`SELECT p.id, pa.amount_kobo, p.amount_kobo AS payment_total_kobo, p.method, p.reference, r.receipt_no, p.status, p.paid_at
      FROM payment_allocations pa JOIN payments p ON p.id = pa.payment_id LEFT JOIN receipts r ON r.payment_id = p.id WHERE pa.invoice_id = $1 ORDER BY p.paid_at`, [inv.id])).rows;
    const school = (await c.query('SELECT name, address, phone, email, logo_file_id FROM schools LIMIT 1')).rows[0];
    return { invoice: inv, lines: items, items, payments, school, onlinePayments: !!config.payments.paystackSecret };
  }));

  // student-specific charges (e.g. lost book, excursion) → invoice totals recomputed on the server
  app.post('/fees/invoices/:id/items', { onRequest: [A, app.perm('fees.update')], schema: { params: idParams, body: obj({ description: str(160, 2), amountKobo: { type: 'integer', minimum: 1, maximum: 100000000000 }, feeStructureId: { type: ['string', 'null'], format: 'uuid' } }, ['description', 'amountKobo']) } }, async (req) =>
    withTx(ctx(req), async (c) => {
      const inv = (await c.query('SELECT * FROM invoices WHERE id = $1 FOR UPDATE', [req.params.id])).rows[0];
      if (!inv) throw E.notFound('Invoice');
      if (inv.status === 'void') throw E.bad('This invoice is void.');
      const it = (await c.query(`INSERT INTO invoice_items (school_id, invoice_id, fee_structure_id, description, amount_kobo, kind, created_by) VALUES ($1,$2,$3,$4,$5,'student_charge',$6) RETURNING id`,
        [req.auth.schoolId, inv.id, req.body.feeStructureId || null, req.body.description, req.body.amountKobo, req.auth.userId])).rows[0];
      await recomputeInvoice(c, inv.id);
      await audit(c, req, 'fees.charge_added', { type: 'invoice', id: inv.id, meta: { item: it.id, description: req.body.description, amountKobo: req.body.amountKobo } });
      return { id: it.id };
    }));
  app.delete('/fees/invoice-items/:id', { onRequest: [A, app.perm('fees.update')], schema: { params: idParams, body: obj({ reason: str(300, 3) }, ['reason']) } }, async (req) => withTx(ctx(req), async (c) => {
    const it = (await c.query("SELECT ii.*, i.paid_kobo, i.total_kobo, i.status FROM invoice_items ii JOIN invoices i ON i.id = ii.invoice_id WHERE ii.id = $1 FOR UPDATE OF i", [req.params.id])).rows[0];
    if (!it) throw E.notFound('Invoice item');
    if (it.kind !== 'student_charge') throw E.bad('Only student-specific charges can be removed; void and regenerate the invoice to change structure items.');
    if (Number(it.total_kobo) - Number(it.amount_kobo) < Number(it.paid_kobo)) throw E.conflict('Removing this charge would leave the invoice over-paid. Reverse a payment first.');
    await c.query('DELETE FROM invoice_items WHERE id = $1', [it.id]);
    await recomputeInvoice(c, it.invoice_id);
    await audit(c, req, 'fees.charge_removed', { type: 'invoice', id: it.invoice_id, meta: { item: it.id, reason: req.body.reason, amountKobo: it.amount_kobo } });
    return { ok: true };
  }));

  app.post('/fees/invoices/:id/void', { onRequest: [A, app.perm('fees.update')], schema: { params: idParams, body: obj({ reason: str(300, 3) }, ['reason']) } }, async (req) => withTx(ctx(req), async (c) => {
    const inv = (await c.query('SELECT * FROM invoices WHERE id = $1 FOR UPDATE', [req.params.id])).rows[0];
    if (!inv) throw E.notFound('Invoice');
    if (Number(inv.paid_kobo) > 0) throw E.conflict('Reverse all payments before voiding this invoice.');
    await c.query("UPDATE invoices SET status = 'void', voided_by = $2, voided_at = now(), void_reason = $3 WHERE id = $1", [inv.id, req.auth.userId, req.body.reason]);
    await audit(c, req, 'fees.invoice_voided', { type: 'invoice', id: inv.id, meta: { invoiceNo: inv.invoice_no, reason: req.body.reason } });
    return { ok: true };
  }));

  // ── payments & receipts ──
  app.post('/fees/payments', {
    onRequest: [A, app.perm('payments.record')], config: perSession(60, '1 minute'),
    schema: { body: obj({
      amountKobo: { type: 'integer', minimum: 1, maximum: 100000000000 }, method: { enum: ['cash', 'transfer', 'pos', 'cheque'] },
      reference: { type: 'string', pattern: '^[A-Za-z0-9._/-]{3,60}$' }, paidAt: { type: 'string', format: 'date-time' }, note: { type: 'string', maxLength: 300 },
      invoiceId: uuid, studentId: uuid, guardianId: uuid,
      allocations: { type: 'array', minItems: 1, maxItems: 20, items: obj({ invoiceId: uuid, amountKobo: { type: 'integer', minimum: 1, maximum: 100000000000 } }, ['invoiceId', 'amountKobo']) },
    }, ['amountKobo', 'method']) },
  }, async (req, reply) => withTx(ctx(req), async (c) => withIdempotency(c, req, reply, 'payments.record', async () => {
    const b = req.body;
    if (b.paidAt && new Date(b.paidAt) > new Date(Date.now() + 5 * 60000)) throw E.bad('Payment date cannot be in the future.');
    let allocations = b.allocations;
    if (!allocations && b.invoiceId) allocations = [{ invoiceId: b.invoiceId, amountKobo: b.amountKobo }];
    if (!allocations && b.studentId) {             // auto-allocate to the learner's oldest outstanding invoices
      let left = b.amountKobo; allocations = [];
      for (const i of (await c.query("SELECT id, total_kobo - paid_kobo AS bal FROM invoices WHERE student_id = $1 AND status IN ('unpaid','partial') ORDER BY issued_at, invoice_no", [b.studentId])).rows) {
        if (left <= 0) break; const take = Math.min(left, Number(i.bal)); if (take > 0) { allocations.push({ invoiceId: i.id, amountKobo: take }); left -= take; }
      }
      if (left > 0) throw E.bad(`Amount exceeds the learner's total outstanding balance by ${naira(left)}. Overpayments/credits are not accepted.`);
    }
    if (!allocations || !allocations.length) throw E.bad('Specify invoiceId, allocations, or studentId.');
    if (new Set(allocations.map((a) => a.invoiceId)).size !== allocations.length) throw E.bad('Each invoice may appear only once.');
    const first = (await c.query('SELECT student_id FROM invoices WHERE id = $1', [allocations[0].invoiceId])).rows[0];
    const out = await recordPayment(c, req, { amount: b.amountKobo, method: b.method, reference: b.reference || `MAN-${crypto.randomBytes(5).toString('hex').toUpperCase()}`, note: b.note,
      paidAt: b.paidAt, allocations, receivedBy: req.auth.userId, payerStudentId: b.studentId || (first && first.student_id) || null, payerGuardianId: b.guardianId || null, schoolId: req.auth.schoolId });
    await audit(c, req, 'fees.payment_recorded', { type: 'payment', id: out.id, meta: { amountKobo: b.amountKobo, method: b.method, receipt: out.receipt_no, invoices: out.allocations.length } });
    return out;
  })));

  app.post('/fees/payments/:id/reverse', { onRequest: [A, app.perm('payments.reverse')], schema: { params: idParams, body: obj({ reason: str(300, 5) }, ['reason']) } }, async (req) => withTx(ctx(req), async (c) => {
    const p = (await c.query('SELECT * FROM payments WHERE id = $1 FOR UPDATE', [req.params.id])).rows[0];
    if (!p) throw E.notFound('Payment');
    if (p.status !== 'confirmed') throw E.conflict('Only confirmed payments can be reversed.');
    if (p.received_by === req.auth.userId) throw E.forbidden('You cannot reverse a payment you recorded (four-eyes rule).');
    await c.query("UPDATE payments SET status = 'reversed', reversed_by = $2, reversed_at = now(), reversal_reason = $3 WHERE id = $1", [p.id, req.auth.userId, req.body.reason]);
    for (const a of (await c.query('SELECT invoice_id, amount_kobo FROM payment_allocations WHERE payment_id = $1 ORDER BY invoice_id', [p.id])).rows) {
      const inv = (await c.query('SELECT total_kobo, paid_kobo FROM invoices WHERE id = $1 FOR UPDATE', [a.invoice_id])).rows[0];
      const paid = Number(inv.paid_kobo) - Number(a.amount_kobo);
      await c.query('UPDATE invoices SET paid_kobo = $2, status = $3 WHERE id = $1', [a.invoice_id, paid, statusFor(paid, Number(inv.total_kobo))]);
    }
    await audit(c, req, 'fees.payment_reversed', { type: 'payment', id: p.id, meta: { amountKobo: p.amount_kobo, reason: req.body.reason } });
    return { ok: true };
  }));

  app.get('/fees/payments', { onRequest: [A, app.perm('fees.view')], schema: { querystring: listQuery({ from: { type: 'string', format: 'date' }, to: { type: 'string', format: 'date' }, method: { type: 'string', maxLength: 20 } }) } }, async (req) => {
    const pg = page(req.query);
    return withTx(ctx(req), async (c) => {
      const p = []; const w = [];
      if (req.query.from) { p.push(req.query.from); w.push(`p.paid_at >= $${p.length}::date`); }
      if (req.query.to) { p.push(req.query.to); w.push(`p.paid_at < $${p.length}::date + 1`); }
      if (req.query.method) { p.push(req.query.method); w.push(`p.method = $${p.length}`); }
      if (req.query.q) { p.push(`%${likeEscape(req.query.q.toLowerCase())}%`); w.push(`(lower(r.receipt_no) LIKE $${p.length} OR lower(p.reference) LIKE $${p.length} OR lower(s.first_name || ' ' || s.last_name) LIKE $${p.length})`); }
      const where = w.length ? 'WHERE ' + w.join(' AND ') : '';
      const from = 'FROM payments p LEFT JOIN receipts r ON r.payment_id = p.id LEFT JOIN students s ON s.id = p.student_id LEFT JOIN users u ON u.id = p.received_by';
      const total = (await c.query(`SELECT count(*)::int AS n ${from} ${where}`, p)).rows[0].n;
      const rows = (await c.query(`SELECT p.id, r.receipt_no, p.reference, p.amount_kobo, p.method, p.status, p.paid_at, s.first_name || ' ' || s.last_name AS student, u.full_name AS received_by,
          (SELECT string_agg(i.invoice_no, ', ') FROM payment_allocations pa JOIN invoices i ON i.id = pa.invoice_id WHERE pa.payment_id = p.id) AS invoice_no
        ${from} ${where} ORDER BY p.paid_at DESC LIMIT ${pg.limit} OFFSET ${pg.offset}`, p)).rows;
      return paged(rows, total, pg);
    });
  });

  app.get('/fees/receipts/:id', { onRequest: [A, app.perm('fees.view', 'fees.view_own', 'fees.view_children')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const r = (await c.query(`SELECT p.*, r.receipt_no, r.issued_at, s.first_name, s.last_name, s.admission_no, u.full_name AS received_by_name
      FROM payments p LEFT JOIN receipts r ON r.payment_id = p.id LEFT JOIN students s ON s.id = p.student_id LEFT JOIN users u ON u.id = p.received_by WHERE p.id = $1`, [req.params.id])).rows[0];
    if (!r) throw E.notFound('Receipt');
    const allocs = (await c.query(`SELECT pa.amount_kobo, i.id AS invoice_id, i.invoice_no, i.student_id, i.total_kobo, i.paid_kobo FROM payment_allocations pa JOIN invoices i ON i.id = pa.invoice_id WHERE pa.payment_id = $1`, [r.id])).rows;
    if (!req.can('fees.view')) { const own = allocs.some((a) => a.student_id === req.auth.studentId || req.auth.children.includes(a.student_id)); if (!own) throw E.notFound('Receipt'); }
    const school = (await c.query('SELECT name, address, phone, email, logo_file_id FROM schools LIMIT 1')).rows[0];
    r.invoice_no = allocs.map((a) => a.invoice_no).join(', ');
    r.total_kobo = allocs.reduce((x, a) => x + Number(a.total_kobo), 0); r.paid_kobo = allocs.reduce((x, a) => x + Number(a.paid_kobo), 0);
    return { receipt: r, allocations: allocs, school };
  }));

  app.get('/fees/summary', { onRequest: [A, app.perm('fees.view')], schema: { querystring: obj({ termId: uuid }) }, config: perSession(30, '1 minute') }, async (req) => withTx(ctx(req), async (c) => {
    const term = req.query.termId || ((await c.query('SELECT id FROM terms WHERE is_current LIMIT 1')).rows[0] || {}).id || null;
    const t = (await c.query(`SELECT COALESCE(sum(total_kobo),0)::bigint AS billed, COALESCE(sum(paid_kobo),0)::bigint AS collected, COALESCE(sum(total_kobo - paid_kobo),0)::bigint AS outstanding,
      count(*)::int AS invoices, count(*) FILTER (WHERE status = 'paid')::int AS paid, count(*) FILTER (WHERE status IN ('unpaid','partial'))::int AS owing
      FROM invoices WHERE status <> 'void' AND ($1::uuid IS NULL OR term_id = $1)`, [term])).rows[0];
    const byClass = (await c.query(`SELECT cl.display_name AS class_name, COALESCE(sum(i.total_kobo),0)::bigint AS billed, COALESCE(sum(i.paid_kobo),0)::bigint AS collected
      FROM invoices i JOIN terms t ON t.id = i.term_id JOIN student_enrollments e ON e.student_id = i.student_id AND e.session_id = t.session_id JOIN classes cl ON cl.id = e.class_id
      WHERE i.status <> 'void' AND ($1::uuid IS NULL OR i.term_id = $1) GROUP BY cl.display_name, cl.sort_order ORDER BY cl.sort_order, cl.display_name`, [term])).rows;
    const methods = (await c.query(`SELECT p.method, COALESCE(sum(pa.amount_kobo),0)::bigint AS amount FROM payment_allocations pa JOIN payments p ON p.id = pa.payment_id JOIN invoices i ON i.id = pa.invoice_id
      WHERE p.status = 'confirmed' AND ($1::uuid IS NULL OR i.term_id = $1) GROUP BY p.method`, [term])).rows;
    return { termId: term, ...t, collectionRate: Number(t.billed) ? Math.round(Number(t.collected) / Number(t.billed) * 1000) / 10 : 0, byClass, methods };
  }));

  app.get('/fees/my', { onRequest: [A, app.perm('fees.view_own', 'fees.view_children')] }, async (req) => withTx(ctx(req), async (c) => {
    const ids = [req.auth.studentId, ...req.auth.children].filter(Boolean);
    return { items: (await c.query(`SELECT i.id, i.invoice_no, i.kind, i.note, i.status, i.total_kobo, i.paid_kobo, (i.total_kobo - i.paid_kobo) AS balance_kobo, i.due_date, t.name AS term, se.name AS session,
      s.first_name || ' ' || s.last_name AS student, s.id AS student_id FROM invoices i JOIN students s ON s.id = i.student_id LEFT JOIN terms t ON t.id = i.term_id LEFT JOIN academic_sessions se ON se.id = t.session_id
      WHERE i.student_id = ANY($1::uuid[]) AND i.status <> 'void' ORDER BY i.issued_at DESC`, [ids])).rows, onlinePayments: !!config.payments.paystackSecret };
  }));

  // ── online payment (Paystack): initialise server-side with the SERVER-computed balance ──
  app.post('/fees/invoices/:id/pay-online', { onRequest: [A, app.perm('fees.view_own', 'fees.view_children', 'payments.record')], config: perSession(10, '1 minute'), schema: { params: idParams, body: obj({ email: { type: 'string', format: 'email', maxLength: 160 } }, ['email']) } }, async (req) => {
    if (!config.payments.paystackSecret) throw E.notConfigured('Online payments are not configured for this school yet.');
    const { inv, ref, amount } = await withTx({ ...ctx(req), readOnly: false }, async (c) => {
      const i = (await c.query('SELECT * FROM invoices WHERE id = $1', [req.params.id])).rows[0];
      if (!i) throw E.notFound('Invoice');
      await feeAccess(req, i.student_id);
      if (i.status === 'paid' || i.status === 'void') throw E.bad('This invoice has nothing to pay.');
      const r = `ABO-${i.school_id.slice(0, 8)}-${crypto.randomBytes(8).toString('hex')}`;
      const amt = Number(i.total_kobo) - Number(i.paid_kobo);
      await c.query(`INSERT INTO payments (school_id, invoice_id, student_id, amount_kobo, method, reference, status, provider, received_by) VALUES ($1,$2,$3,$4,'online',$5,'pending','paystack',$6)`,
        [i.school_id, i.id, i.student_id, amt, r, req.auth.userId]);
      await audit(c, req, 'fees.online_payment_initiated', { type: 'invoice', id: i.id, meta: { reference: r, amountKobo: amt } });
      return { inv: i, ref: r, amount: amt };
    });
    let j = null;
    try {
      const res = await fetch(`${config.payments.paystackBaseUrl}/transaction/initialize`, {
        method: 'POST', headers: { authorization: `Bearer ${config.payments.paystackSecret}`, 'content-type': 'application/json' },
        body: JSON.stringify({ email: req.body.email, amount, reference: ref, currency: 'NGN', callback_url: `${config.publicOrigin}/#/my-fees`, metadata: { invoiceId: inv.id, schoolId: inv.school_id } }),
        signal: AbortSignal.timeout(15000),
      });
      const body = await res.json().catch(() => ({}));
      if (res.ok && body.status && body.data && body.data.authorization_url) j = body;
    } catch (err) { req.log.warn({ err: { name: err.name, message: err.message } }, 'paystack initialize failed'); }
    if (!j) {
      // provider unreachable / timed out / rejected: close the pending attempt so it never lingers as "pending"
      await withTx({ ...ctx(req), readOnly: false }, (c) => c.query(`UPDATE payments SET status = 'failed' WHERE reference = $1 AND status = 'pending'`, [ref])).catch(() => {});
      throw E.upstream('The payment provider is unavailable. Please try again later.');
    }
    return { authorizationUrl: j.data.authorization_url, reference: ref };
  });

  // ── Paystack webhook: HMAC-SHA512 signature + server-to-server verification before crediting ──
  app.register(async (hook) => {
    hook.addContentTypeParser('application/json', { parseAs: 'buffer', bodyLimit: 256 * 1024 }, (req, body, done) => done(null, body));
    hook.post('/payments/webhook/paystack', { config: { webhook: true, rateLimit: { max: 300, timeWindow: '1 minute' } } }, async (req, reply) => {
      const secret = config.payments.paystackSecret;
      if (!secret) return reply.code(404).send({ error: { code: 'NOT_FOUND', message: 'Endpoint not found.', requestId: req.id } });
      const sig = String(req.headers['x-paystack-signature'] || '');
      const expected = crypto.createHmac('sha512', secret).update(req.body).digest('hex');
      const valid = sig.length === expected.length && crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected));
      let evt; try { evt = JSON.parse(req.body.toString('utf8')); } catch { return reply.code(400).send({ error: { code: 'BAD_REQUEST', message: 'Malformed payload.', requestId: req.id } }); }
      const ref = evt && evt.data && String(evt.data.reference || '').slice(0, 100);
      if (!valid) { securityEvent({ kind: 'payment_webhook_bad_signature', severity: 'high', detail: { reference: ref }, ip: req.ip }); return reply.code(401).send({ error: { code: 'INVALID_SIGNATURE', message: 'Invalid signature.', requestId: req.id } }); }
      if (!ref) return { ok: true };
      const sid = (await raw('SELECT app.payment_school_by_reference($1, $2) AS s', ['paystack', ref])).rows[0].s;
      await withTx({ schoolId: sid || null, platform: !sid }, (c) => c.query(`INSERT INTO payment_records (school_id, provider, event, reference, signature_valid, payload) VALUES ($1,'paystack',$2,$3,true,$4)
        ON CONFLICT (provider, reference, event) DO NOTHING`, [sid || null, String(evt.event || 'unknown').slice(0, 60), ref, evt]));
      if (evt.event !== 'charge.success' || !sid) return { ok: true };
      const vr = await fetch(`${config.payments.paystackBaseUrl}/transaction/verify/${encodeURIComponent(ref)}`, { headers: { authorization: `Bearer ${secret}` }, signal: AbortSignal.timeout(15000) });
      const v = await vr.json().catch(() => ({}));
      if (!vr.ok || !v.status || !v.data || v.data.status !== 'success') return reply.code(202).send({ ok: false, message: 'verification pending' });
      await withTx({ schoolId: sid }, async (c) => {
        const p = (await c.query("SELECT * FROM payments WHERE reference = $1 AND status = 'pending' FOR UPDATE", [ref])).rows[0];
        if (!p) return;                                                                   // idempotent: already processed
        if (Number(v.data.amount) !== Number(p.amount_kobo) || String(v.data.currency || 'NGN') !== 'NGN') {
          await c.query("UPDATE payments SET status = 'failed', note = 'amount mismatch on verification' WHERE id = $1", [p.id]);
          securityEvent({ schoolId: sid, kind: 'payment_amount_mismatch', severity: 'high', detail: { reference: ref, expected: p.amount_kobo, got: v.data.amount } });
          return;
        }
        await c.query('DELETE FROM payments WHERE id = $1', [p.id]);                      // replace the pending row with the confirmed one
        const done = await recordPayment(c, { auth: null }, { amount: Number(p.amount_kobo), method: 'online', reference: ref, provider: 'paystack', providerRef: String(v.data.id || ''),
          receivedBy: p.received_by, allocations: [{ invoiceId: p.invoice_id, amountKobo: Number(p.amount_kobo) }], payerStudentId: p.student_id, schoolId: sid });
        await c.query("UPDATE payment_records SET verified = true WHERE provider = 'paystack' AND reference = $1", [ref]);
        await audit(c, { ip: req.ip, headers: req.headers, auth: { schoolId: sid, userId: null, loginId: 'paystack-webhook', roles: [] } }, 'fees.online_payment_confirmed', { type: 'payment', id: done.id, meta: { reference: ref, amountKobo: p.amount_kobo } });
      });
      return { ok: true };
    });
  });
};
