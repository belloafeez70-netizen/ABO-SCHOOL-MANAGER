'use strict';
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { idParams } = require('../lib/schema');
const { ctx } = require('../auth/plugin');
module.exports = async function jobRoutes(app) {
  app.get('/jobs/:id', { onRequest: [app.authenticate], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const j = (await c.query('SELECT id, kind, status, attempts, last_error, result, created_at, finished_at, created_by FROM jobs WHERE id = $1', [req.params.id])).rows[0];
    if (!j || j.created_by !== req.auth.userId) throw E.notFound('Job');
    delete j.created_by;
    if (j.last_error) j.last_error = 'The job failed. Please try again or contact support.';
    return j;
  }));
};
