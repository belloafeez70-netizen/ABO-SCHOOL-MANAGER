'use strict';
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, idParams } = require('../lib/schema');
const { ctx } = require('../auth/plugin');
const { audit } = require('../audit/audit');
const { saveUpload, driver } = require('../storage');
const config = require('../config');

const field = (data, name, max = 200) => { const f = data.fields && data.fields[name]; const v = f && typeof f.value === 'string' ? f.value.trim() : ''; return v.slice(0, max); };
const UUID = /^[0-9a-f-]{36}$/i;

// purpose-aware authorisation for a single file (tenant isolation already enforced by RLS)
async function canRead(c, req, f) {
  if (f.scan_status === 'infected') return false;
  switch (f.purpose) {
    case 'logo': return true;
    case 'signature': {
      if (req.auth.portal === 'staff') return true;
      // the head's signature is printed on report cards, so students/parents of the school may load it
      return (await c.query('SELECT 1 FROM schools WHERE head_signature_file_id = $1', [f.id])).rowCount > 0;
    }
    case 'passport': {
      if (req.can('students.view')) return true;
      const s = (await c.query('SELECT id FROM students WHERE passport_file_id = $1', [f.id])).rows[0];
      return !!s && (s.id === req.auth.studentId || req.auth.children.includes(s.id));
    }
    case 'cbt_image': {
      if (req.can('cbt.view')) return true;
      if (!req.auth.studentId) return false;
      return (await c.query(`SELECT 1 FROM cbt_attempts a JOIN cbt_questions q ON q.id = ANY(a.question_order)
        LEFT JOIN cbt_options o ON o.question_id = q.id WHERE a.student_id = $1 AND (q.image_file_id = $2 OR o.image_file_id = $2) LIMIT 1`, [req.auth.studentId, f.id])).rowCount > 0;
    }
    case 'document': {
      if (req.can('documents.view')) return true;
      const d = (await c.query("SELECT owner_id FROM documents WHERE file_id = $1 AND owner_type = 'student' AND visibility = 'owner_and_staff'", [f.id])).rows[0];
      return !!d && (d.owner_id === req.auth.studentId || req.auth.children.includes(d.owner_id));
    }
    case 'lesson_note': return require('./lesson_notes').canReadFile(c, req, f.id);
    case 'study_material': return require('./materials').canReadFile(c, req, f.id);
    case 'export': case 'import': return f.uploaded_by === req.auth.userId;
    default: return false;
  }
}

module.exports = async function fileRoutes(app) {
  const A = app.authenticate;

  app.get('/files/:id', { onRequest: [A], schema: { params: idParams } }, async (req, reply) => {
    const f = await withTx({ ...ctx(req), readOnly: false }, async (c) => {
      const row = (await c.query('SELECT * FROM uploads WHERE id = $1 AND deleted_at IS NULL', [req.params.id])).rows[0];
      if (!row || !(await canRead(c, req, row))) throw E.notFound('File');
      if (['document', 'export'].includes(row.purpose) && !req.auth.support) await audit(c, req, 'files.downloaded', { type: 'upload', id: row.id, meta: { purpose: row.purpose, name: row.original_name } });
      return row;
    });
    const inline = /^image\/(png|jpeg|webp|gif)$/.test(f.mime);
    if (config.storage.driver === 's3' && config.storage.s3.downloadMode === 'redirect') return reply.redirect(driver().signedUrl(f.storage_key, f.original_name, f.mime), 302);
    reply.header('Content-Type', f.mime).header('Content-Length', f.size_bytes)
      .header('Content-Disposition', `${inline ? 'inline' : 'attachment'}; filename="${f.original_name.replace(/"/g, '')}"`)
      .header('Content-Security-Policy', "default-src 'none'; sandbox").header('Cache-Control', 'private, max-age=300')
      .header('Cross-Origin-Resource-Policy', config.corp);
    return reply.send(await driver().stream(f.storage_key));
  });

  app.post('/students/:id/passport', { onRequest: [A, app.perm('students.update')], schema: { params: idParams }, config: { rateLimit: { max: 30, timeWindow: '1 minute' } } }, async (req) => {
    const data = await req.file(); if (!data) throw E.bad('Attach an image.');
    const buffer = await data.toBuffer();
    return withTx(ctx(req), async (c) => {
      const s = await c.query('SELECT id FROM students WHERE id = $1 AND deleted_at IS NULL', [req.params.id]);
      if (!s.rowCount) throw E.notFound('Student');
      const up = await saveUpload(c, { schoolId: req.auth.schoolId, userId: req.auth.userId, purpose: 'passport', buffer, originalName: data.filename });
      await c.query('UPDATE students SET passport_file_id = $2 WHERE id = $1', [req.params.id, up.id]);
      await audit(c, req, 'students.passport_uploaded', { type: 'student', id: req.params.id });
      return { fileId: up.id };
    });
  });

  app.post('/cbt/images', { onRequest: [A, app.perm('cbt.create', 'cbt.update')], config: { rateLimit: { max: 60, timeWindow: '1 minute' } } }, async (req) => {
    const data = await req.file(); if (!data) throw E.bad('Attach an image.');
    const buffer = await data.toBuffer();
    return withTx(ctx(req), async (c) => ({ fileId: (await saveUpload(c, { schoolId: req.auth.schoolId, userId: req.auth.userId, purpose: 'cbt_image', buffer, originalName: data.filename })).id }));
  });

  // ── documents archive ──
  app.get('/documents', { onRequest: [A, app.perm('documents.view')], schema: { querystring: obj({ ownerType: { enum: ['student', 'staff', 'school'] }, ownerId: { type: 'string', format: 'uuid' } }) } }, async (req) =>
    withTx(ctx(req), async (c) => {
      const p = []; const w = [];
      if (req.query.ownerType) { p.push(req.query.ownerType); w.push(`d.owner_type = $${p.length}`); }
      if (req.query.ownerId) { p.push(req.query.ownerId); w.push(`d.owner_id = $${p.length}`); }
      return { items: (await c.query(`SELECT d.id, d.title, d.category, d.owner_type, d.owner_id, d.visibility, d.created_at, d.file_id, u.original_name, u.mime, u.size_bytes, u.scan_status
        FROM documents d JOIN uploads u ON u.id = d.file_id AND u.deleted_at IS NULL ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY d.created_at DESC LIMIT 300`, p)).rows };
    }));
  app.post('/documents', { onRequest: [A, app.perm('documents.upload')], config: { rateLimit: { max: 30, timeWindow: '1 minute' } } }, async (req) => {
    const data = await req.file(); if (!data) throw E.bad('Attach a file.');
    const title = field(data, 'title', 160); const ownerType = field(data, 'ownerType', 10) || 'school'; const ownerId = field(data, 'ownerId', 36) || null;
    const category = field(data, 'category', 40) || 'general'; const visibility = field(data, 'visibility', 20) || 'staff';
    if (!title) throw E.bad('title is required.');
    if (!['student', 'staff', 'school'].includes(ownerType) || !['staff', 'owner_and_staff'].includes(visibility) || (ownerId && !UUID.test(ownerId))) throw E.bad('Invalid document fields.');
    const buffer = await data.toBuffer();
    return withTx(ctx(req), async (c) => {
      if (ownerType !== 'school') {
        const t = ownerType === 'student' ? 'students' : 'staff';
        const ok = ownerId && (await c.query(`SELECT 1 FROM ${t} WHERE id = $1`, [ownerId])).rowCount;
        if (!ok) throw E.notFound(ownerType === 'student' ? 'Student' : 'Staff member');
      }
      const up = await saveUpload(c, { schoolId: req.auth.schoolId, userId: req.auth.userId, purpose: 'document', buffer, originalName: data.filename });
      const d = (await c.query(`INSERT INTO documents (school_id, owner_type, owner_id, category, title, file_id, visibility, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
        [req.auth.schoolId, ownerType, ownerType === 'school' ? null : ownerId, category, title, up.id, visibility, req.auth.userId])).rows[0];
      await audit(c, req, 'documents.uploaded', { type: 'document', id: d.id, meta: { title, ownerType, mime: up.mime, bytes: up.size_bytes } });
      return { id: d.id, fileId: up.id };
    });
  });
  app.delete('/documents/:id', { onRequest: [A, app.perm('documents.delete')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const d = (await c.query('DELETE FROM documents WHERE id = $1 RETURNING file_id, title', [req.params.id])).rows[0];
    if (!d) throw E.notFound('Document');
    await c.query('UPDATE uploads SET deleted_at = now() WHERE id = $1', [d.file_id]);
    await audit(c, req, 'documents.deleted', { type: 'document', id: req.params.id, meta: { title: d.title } });
    return { ok: true };
  }));
};
