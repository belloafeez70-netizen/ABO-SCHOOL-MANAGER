'use strict';
// Demo links (028) — the ONLY way to start a demo (owner's request, 12 Oct 2026). The A.B.O. platform owner makes a link
// in the platform console, opens it on a phone / laptop or sends it to a school. Only a hash of the code is stored; the
// full link is shown once, when it is made.
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, idParams } = require('../lib/schema');
const { platformCtx } = require('../auth/plugin');
const { audit } = require('../audit/audit');
const config = require('../config');
const demoSvc = () => require('../services/demo');

module.exports = async function demoLinkRoutes(app) {
  const P = [app.authenticate, app.platformOnly, app.perm('platform.billing.manage')];

  app.get('/platform/demo/links', { onRequest: P }, async (req) => withTx(platformCtx(req), async (c) => {
    const items = (await c.query(`SELECT d.id, d.label, d.school_key, d.max_uses, d.uses, d.expires_at, d.revoked_at, d.created_at, d.last_used_at, u.full_name AS created_by,
        CASE WHEN d.revoked_at IS NOT NULL THEN 'cancelled' WHEN d.uses >= d.max_uses THEN 'used up' WHEN d.expires_at <= now() THEN 'expired' ELSE 'active' END AS status
      FROM demo_passes d LEFT JOIN users u ON u.id = d.created_by ORDER BY d.created_at DESC LIMIT 100`)).rows;
    const st = (await c.query('SELECT demo_enabled, demo_minutes FROM platform_settings WHERE id')).rows[0] || {};
    return { items, demoEnabled: !!st.demo_enabled, minutes: st.demo_minutes || 5,
      schools: demoSvc().DEMOS.map((d) => ({ key: d.key, name: d.name, kind: d.type === 'secondary' ? 'Secondary (JSS 1 – SS 3)' : 'Creche, nursery and primary' })) };
  }));

  app.post('/platform/demo/links', {
    onRequest: P, config: { rateLimit: { max: 30, timeWindow: '1 minute' } },
    schema: { body: obj({ label: { type: ['string', 'null'], maxLength: 120 }, school: { type: ['string', 'null'], enum: [...demoSvc().DEMOS.map((d) => d.key), null] },
      hours: { type: 'integer', minimum: 1, maximum: 168 }, uses: { type: 'integer', minimum: 1, maximum: 50 } }) },
  }, async (req) => withTx(platformCtx(req), async (c) => {
    const b = req.body; const code = demoSvc().newPassCode();
    const r = (await c.query(`INSERT INTO demo_passes (code_hash, label, school_key, max_uses, expires_at, created_by) VALUES ($1,$2,$3,$4, now() + make_interval(hours => $5), $6)
      RETURNING id, label, school_key, max_uses, uses, expires_at, created_at`, [demoSvc().passHash(code), (b.label || '').trim() || null, b.school || null, b.uses || 1, b.hours || 24, req.auth.userId])).rows[0];
    await audit(c, req, 'demo.link_created', { type: 'demo_pass', id: r.id, meta: { label: r.label, school: r.school_key, uses: r.max_uses, expiresAt: r.expires_at } });
    return { ...r, code, link: `${config.publicOrigin}/#/demo?pass=${encodeURIComponent(code)}` };       // the code is never shown again
  }));

  app.post('/platform/demo/links/:id/cancel', { onRequest: P, schema: { params: idParams } }, async (req) => withTx(platformCtx(req), async (c) => {
    const r = (await c.query('UPDATE demo_passes SET revoked_at = now() WHERE id = $1 AND revoked_at IS NULL RETURNING id, label', [req.params.id])).rows[0];
    if (!r) throw E.notFound('Demo link');
    await audit(c, req, 'demo.link_cancelled', { type: 'demo_pass', id: r.id, meta: { label: r.label } });
    return { ok: true };
  }));
};
