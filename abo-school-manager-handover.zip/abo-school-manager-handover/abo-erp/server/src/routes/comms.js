'use strict';
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, str, uuid, idParams, listQuery, dateTime } = require('../lib/schema');
const { page, paged } = require('../lib/http');
const { ctx } = require('../auth/plugin');
const { audit } = require('../audit/audit');
const { notify, queueEmail } = require('../services/notify');
const config = require('../config');

// audience visibility rules for the current user (evaluated server-side)
function audienceSql(req, p) {
  const portal = req.auth.portal;
  const isTeacher = req.auth.roles.some((r) => /teacher/.test(r.key));
  const aud = ['all'];
  if (portal === 'staff' || portal === 'platform') aud.push('staff'); if (isTeacher) aud.push('teachers');
  if (portal === 'student') aud.push('students'); if (portal === 'parent') aud.push('parents');
  p.push(aud); const a = `$${p.length}`;
  p.push(req.auth.roles.map((r) => r.key)); const rk = `$${p.length}`;
  p.push([req.auth.studentId, ...req.auth.children].filter(Boolean)); const kids = `$${p.length}`;
  const managers = req.can('announcements.manage');
  return `(${managers ? 'true OR ' : ''}(NOT a.draft AND a.audience = ANY(${a}::text[]) AND (a.role_key IS NULL OR a.role_key = ANY(${rk}::text[]))
    AND (a.class_id IS NULL OR ${portal === 'staff' ? `cardinality(${kids}::uuid[]) >= 0` : `EXISTS (SELECT 1 FROM student_enrollments e JOIN academic_sessions s ON s.id = e.session_id AND s.is_current WHERE e.class_id = a.class_id AND e.student_id = ANY(${kids}::uuid[]))`})
    AND a.publish_at <= now() AND (a.expires_at IS NULL OR a.expires_at > now())))`;
}


// Nigerian phone number → WhatsApp format (2348012345678); null if it is not a usable number
function waNumber(raw) {
  let d = String(raw || '').replace(/\D/g, '');
  if (!d) return null;
  if (d.startsWith('00')) d = d.slice(2);
  if (/^0[789]\d{9}$/.test(d)) d = '234' + d.slice(1);
  else if (/^[789]\d{9}$/.test(d)) d = '234' + d;
  return /^\d{11,15}$/.test(d) ? d : null;
}

// who may message whom (server-side rule): staff → any active user in the school;
// students/parents → only teachers/form teachers of their (children's) class + school leadership.
async function allowedContacts(c, req) {
  if (req.auth.portal === 'staff') {
    return (await c.query(`SELECT u.id, u.full_name, string_agg(DISTINCT r.name, ', ') AS roles FROM active_members u JOIN user_roles ur ON ur.user_id = u.id JOIN roles r ON r.id = ur.role_id
      WHERE u.id <> $1 GROUP BY u.id, u.full_name ORDER BY u.full_name LIMIT 500`, [req.auth.userId])).rows;
  }
  const kids = [req.auth.studentId, ...req.auth.children].filter(Boolean);
  return (await c.query(`SELECT DISTINCT u.id, u.full_name, 'Teacher' AS roles FROM student_enrollments e JOIN academic_sessions s ON s.id = e.session_id AND s.is_current
      JOIN classes cl ON cl.id = e.class_id LEFT JOIN class_subjects cs ON cs.class_id = cl.id
      JOIN staff st ON st.id = cs.teacher_id OR st.id = cl.form_teacher_id JOIN active_members u ON u.id = st.user_id
      WHERE e.student_id = ANY($1::uuid[])
    UNION SELECT u.id, u.full_name, r.name FROM active_members u JOIN user_roles ur ON ur.user_id = u.id JOIN roles r ON r.id = ur.role_id
      WHERE r.key IN ('principal','head_of_school','administrator','school_owner') ORDER BY 2`, [kids])).rows;
}

module.exports = async function commsRoutes(app) {
  const A = app.authenticate;

  // ── announcements (school / class / role targeted) ──
  app.get('/announcements', { onRequest: [A, app.perm('announcements.view', 'announcements.manage')], schema: { querystring: listQuery() } }, async (req) => {
    const pg = page(req.query);
    return withTx(ctx(req), async (c) => {
      const p = []; const vis = audienceSql(req, p);
      const total = (await c.query(`SELECT count(*)::int AS n FROM announcements a WHERE ${vis}`, p)).rows[0].n;
      p.push(req.auth.userId);
      const rows = (await c.query(`SELECT a.id, a.title, a.body, a.audience, a.priority, a.pinned, a.publish_at, a.expires_at, a.role_key, a.class_id, cl.display_name AS class_name, u.full_name AS author,
        a.draft, a.source, ${req.can('announcements.manage') ? 'a.emailed_at, a.emailed_count,' : ''}
        EXISTS (SELECT 1 FROM announcement_reads r WHERE r.announcement_id = a.id AND r.user_id = $${p.length}) AS read
        FROM announcements a LEFT JOIN classes cl ON cl.id = a.class_id LEFT JOIN users u ON u.id = a.created_by WHERE ${vis}
        ORDER BY a.pinned DESC, a.publish_at DESC LIMIT ${pg.limit} OFFSET ${pg.offset}`, p)).rows;
      return paged(rows, total, pg);
    });
  });
  app.post('/announcements', {
    onRequest: [A, app.perm('announcements.manage')],
    schema: { body: obj({ title: str(160, 2), body: str(60000, 1), audience: { enum: ['all', 'staff', 'teachers', 'students', 'parents'] }, classId: { type: ['string', 'null'], format: 'uuid' },
      roleKey: { type: ['string', 'null'], pattern: '^[a-z][a-z0-9_]{1,40}$' }, priority: { enum: ['normal', 'important', 'urgent'] }, pinned: { type: 'boolean' }, publishAt: dateTime, expiresAt: dateTime,
      draft: { type: 'boolean' } }, ['title', 'body']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const b = req.body;
    if (b.classId && !(await c.query('SELECT 1 FROM classes WHERE id = $1', [b.classId])).rowCount) throw E.notFound('Class');
    const r = (await c.query(`INSERT INTO announcements (school_id, title, body, audience, class_id, role_key, priority, pinned, publish_at, expires_at, created_by, draft)
      VALUES ($1,$2,$3,COALESCE($4,'all'),$5,$6,COALESCE($7,'normal'),COALESCE($8,false),COALESCE($9, now()),$10,$11,COALESCE($12,false)) RETURNING id, title`,
    [req.auth.schoolId, b.title, b.body, b.audience, b.classId || null, b.roleKey || null, b.priority, b.pinned, b.publishAt || null, b.expiresAt || null, req.auth.userId, b.draft])).rows[0];
    if (b.priority === 'urgent' && !b.draft) {
      const users = (await c.query("SELECT id FROM active_members WHERE id <> $1 LIMIT 5000", [req.auth.userId])).rows.map((x) => x.id);
      await notify(c, req.auth.schoolId, users, { kind: 'announcement', title: `Urgent: ${b.title}`, link: '#/announcements' });
    }
    await audit(c, req, 'announcements.created', { type: 'announcement', id: r.id, meta: { audience: b.audience || 'all', classId: b.classId || null, priority: b.priority || 'normal' } });
    return r;
  }));
  // a draft (for example a letter brought over from the old Newsletters page) goes live
  app.post('/announcements/:id/publish', { onRequest: [A, app.perm('announcements.manage')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const r = await c.query('UPDATE announcements SET draft = false, publish_at = GREATEST(publish_at, now()) WHERE id = $1 AND draft RETURNING id, title', [req.params.id]);
    if (!r.rowCount) { if ((await c.query('SELECT 1 FROM announcements WHERE id = $1', [req.params.id])).rowCount) throw E.conflict('This announcement is already published.'); throw E.notFound('Announcement'); }
    await audit(c, req, 'announcements.published', { type: 'announcement', id: req.params.id, meta: { title: r.rows[0].title } });
    return { ok: true };
  }));

  // ── share with parents: WhatsApp text + list of parents, and email to every parent ──
  // Who gets it follows the announcement's audience: "everyone" or "parents" (optionally one class). Notices meant only
  // for staff or students are not sent to parents. Parents' phone numbers and emails need guardians.view.
  async function shareData(c, req, id) {
    const a = (await c.query(`SELECT a.id, a.title, a.body, a.audience, a.class_id, a.draft, a.publish_at, a.emailed_at, a.emailed_count, cl.display_name AS class_name
      FROM announcements a LEFT JOIN classes cl ON cl.id = a.class_id WHERE a.id = $1`, [id])).rows[0];
    if (!a) throw E.notFound('Announcement');
    const school = (await c.query('SELECT name, slug FROM schools LIMIT 1')).rows[0] || { name: 'School' };
    const link = `${config.publicOrigin}/#/announcements`;
    const max = 1500;
    const body = a.body.length > max ? `${a.body.slice(0, max).replace(/\s+\S*$/, '')}…` : a.body;
    const text = `*${school.name}*\n*${a.title}*\n\n${body}${a.body.length > max ? `\n\n(Read the full notice in the school portal.)` : ''}\n\nSchool portal: ${link}`;
    const forParents = ['all', 'parents'].includes(a.audience);
    let recipients = [];
    if (forParents && req.can('guardians.view')) {
      recipients = (await c.query(`SELECT g.id, g.full_name, g.phone, g.email,
          string_agg(DISTINCT s.first_name || ' ' || s.last_name, ', ') AS children, string_agg(DISTINCT cl.display_name, ', ') AS classes
        FROM guardians g JOIN student_guardians sg ON sg.guardian_id = g.id JOIN students s ON s.id = sg.student_id AND s.deleted_at IS NULL
        JOIN student_enrollments e ON e.student_id = s.id AND e.status <> 'withdrawn' JOIN academic_sessions se ON se.id = e.session_id AND se.is_current
        JOIN classes cl ON cl.id = e.class_id
        WHERE ($1::uuid IS NULL OR e.class_id = $1) GROUP BY g.id ORDER BY g.full_name LIMIT 5000`, [a.class_id])).rows
        .map((g) => ({ id: g.id, name: g.full_name, children: g.children, classes: g.classes, phone: g.phone, whatsapp: waNumber(g.phone), email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(g.email || '') ? g.email : null }));
    }
    return { a, school, link, text, forParents, recipients };
  }
  app.get('/announcements/:id/share', { onRequest: [A, app.perm('announcements.manage')], schema: { params: idParams } }, async (req) => withTx({ ...ctx(req), readOnly: false }, async (c) => {
    const d = await shareData(c, req, req.params.id);
    if (d.recipients.length) await audit(c, req, 'announcements.share_list_viewed', { type: 'announcement', id: d.a.id, meta: { parents: d.recipients.length } });
    return { id: d.a.id, title: d.a.title, draft: d.a.draft, audience: d.a.audience, className: d.a.class_name, forParents: d.forParents, canSeeContacts: req.can('guardians.view'),
      text: d.text, whatsappUrl: `https://wa.me/?text=${encodeURIComponent(d.text)}`, portalLink: d.link, emailedAt: d.a.emailed_at, emailedCount: d.a.emailed_count,
      recipients: d.recipients.map((r) => ({ ...r, whatsappUrl: r.whatsapp ? `https://wa.me/${r.whatsapp}?text=${encodeURIComponent(d.text)}` : null })),
      counts: { parents: d.recipients.length, withWhatsApp: d.recipients.filter((r) => r.whatsapp).length, withEmail: d.recipients.filter((r) => r.email).length } };
  }));
  app.post('/announcements/:id/email', {
    onRequest: [A, app.perm('announcements.manage')], config: { rateLimit: { max: 5, timeWindow: '1 minute' } },
    schema: { params: idParams, body: obj({ again: { type: 'boolean' } }) },
  }, async (req) => withTx(ctx(req), async (c) => {
    if (!req.can('guardians.view')) throw E.forbidden('Emailing parents needs permission to see parents’ contacts (guardians.view).');
    await c.query('SELECT pg_advisory_xact_lock(hashtextextended($1, 0))', [`ann-email:${req.params.id}`]);   // two clicks cannot send twice
    const d = await shareData(c, req, req.params.id);
    if (d.a.draft) throw E.conflict('Publish this announcement before sending it to parents.');
    if (!d.forParents) throw E.bad('This announcement is for staff or students only. Change the audience to “Everyone” or “Parents” to send it to parents.');
    if (d.a.emailed_at && !(req.body && req.body.again)) throw E.conflict(`Already emailed to ${d.a.emailed_count} parent(s) on ${new Date(d.a.emailed_at).toISOString().slice(0, 16).replace('T', ' ')}. Tick “send again” to send it once more.`);
    const emails = [...new Map(d.recipients.filter((r) => r.email).map((r) => [r.email.toLowerCase(), r])).values()];
    if (!emails.length) throw E.bad('None of these parents has an email address yet. Add emails under Students › Parents & Guardians, or share on WhatsApp.');
    const subject = `${d.school.name}: ${d.a.title}`.slice(0, 200);
    for (const r of emails) {
      await queueEmail(c, { schoolId: req.auth.schoolId, to: r.email, subject, template: 'announcement',
        body: `Dear ${r.name || 'Parent / Guardian'},\n\n${d.a.title}\n\n${d.a.body}\n\n— ${d.school.name}\nRead this notice in the school portal: ${d.link}\n\nYou receive this because you are a parent or guardian of ${r.children || 'a learner'} at ${d.school.name}.` });
    }
    await c.query('UPDATE announcements SET emailed_at = now(), emailed_count = $2, emailed_by = $3 WHERE id = $1', [d.a.id, emails.length, req.auth.userId]);
    await audit(c, req, 'announcements.emailed', { type: 'announcement', id: d.a.id, meta: { emails: emails.length, withoutEmail: d.recipients.length - emails.length, again: !!(req.body && req.body.again) } });
    return { queued: emails.length, withoutEmail: d.recipients.length - emails.length, parents: d.recipients.length };
  }));

  app.delete('/announcements/:id', { onRequest: [A, app.perm('announcements.manage')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const r = await c.query('DELETE FROM announcements WHERE id = $1 RETURNING title', [req.params.id]);
    if (!r.rowCount) throw E.notFound('Announcement');
    await audit(c, req, 'announcements.deleted', { type: 'announcement', id: req.params.id, meta: { title: r.rows[0].title } });
    return { ok: true };
  }));
  app.post('/announcements/:id/read', { onRequest: [A, app.perm('announcements.view')], schema: { params: idParams } }, async (req) => withTx({ ...ctx(req), readOnly: false }, async (c) => {
    const p = [req.params.id]; const vis = audienceSql(req, p);
    const ok = await c.query(`SELECT 1 FROM announcements a WHERE a.id = $1 AND ${vis}`, p);
    if (!ok.rowCount) throw E.notFound('Announcement');
    await c.query('INSERT INTO announcement_reads (school_id, announcement_id, user_id) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING', [req.auth.schoolId, req.params.id, req.auth.userId]);
    return { ok: true };
  }));

  // ── notifications ──
  app.get('/notifications', { onRequest: [A] }, async (req) => withTx({ schoolId: req.auth.homeSchoolId, userId: req.auth.userId, platform: !req.auth.homeSchoolId, readOnly: true }, async (c) => ({
    items: (await c.query('SELECT id, kind, title, body, link, read_at, created_at FROM notifications WHERE user_id = $1 ORDER BY created_at DESC LIMIT 100', [req.auth.userId])).rows,
  })));
  app.post('/notifications/read', { onRequest: [A], schema: { body: obj({ ids: { type: 'array', items: uuid, maxItems: 200 }, all: { type: 'boolean' } }) } }, async (req) =>
    withTx({ schoolId: req.auth.homeSchoolId, userId: req.auth.userId, platform: !req.auth.homeSchoolId }, async (c) => {
      if (req.body.all) await c.query('UPDATE notifications SET read_at = now() WHERE user_id = $1 AND read_at IS NULL', [req.auth.userId]);
      else await c.query('UPDATE notifications SET read_at = now() WHERE user_id = $1 AND id = ANY($2::uuid[]) AND read_at IS NULL', [req.auth.userId, req.body.ids || []]);
      return { ok: true };
    }));

  // ── messaging (who may message whom is decided server-side) ──
  app.get('/messages/contacts', { onRequest: [A, app.perm('messages.use')] }, async (req) => withTx(ctx(req), async (c) => ({ items: await allowedContacts(c, req) })));
  app.get('/messages/threads', { onRequest: [A, app.perm('messages.use')] }, async (req) => withTx(ctx(req), async (c) => ({
    items: (await c.query(`SELECT t.id, t.subject, t.last_message_at, (tp.last_read_at IS NULL OR tp.last_read_at < t.last_message_at) AS unread,
      (SELECT string_agg(u.full_name, ', ') FROM conversation_participants p2 JOIN users u ON u.id = p2.user_id WHERE p2.conversation_id = t.id AND p2.user_id <> $1) AS with_names,
      (SELECT left(m.body, 120) FROM messages m WHERE m.conversation_id = t.id ORDER BY m.created_at DESC LIMIT 1) AS preview
      FROM conversation_participants tp JOIN conversations t ON t.id = tp.conversation_id WHERE tp.user_id = $1 ORDER BY t.last_message_at DESC LIMIT 200`, [req.auth.userId])).rows,
  })));
  app.post('/messages/threads', {
    onRequest: [A, app.perm('messages.use')], config: { rateLimit: { max: 20, timeWindow: '1 minute' } },
    schema: { body: obj({ subject: str(160, 1), body: str(5000, 1), recipientIds: { type: 'array', items: uuid, minItems: 1, maxItems: 50 }, studentId: { type: ['string', 'null'], format: 'uuid' } }, ['subject', 'body', 'recipientIds']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const b = req.body;
    // recipients must be in this school (RLS) AND allowed contacts for non-staff
    const found = (await c.query("SELECT id FROM active_members WHERE id = ANY($1::uuid[])", [b.recipientIds])).rows.map((r) => r.id);
    if (found.length !== new Set(b.recipientIds).size) throw E.bad('One or more recipients are not available.');
    if (req.auth.portal !== 'staff') {
      const allowed = new Set((await allowedContacts(c, req)).map((x) => x.id));
      if (found.some((id) => !allowed.has(id))) throw E.forbidden('You can only message your teachers and school leadership.');
    }
    if (b.studentId && req.auth.portal !== 'staff' && ![req.auth.studentId, ...req.auth.children].includes(b.studentId)) throw E.forbidden();
    const t = (await c.query('INSERT INTO conversations (school_id, subject, student_id, created_by) VALUES ($1,$2,$3,$4) RETURNING id', [req.auth.schoolId, b.subject, b.studentId || null, req.auth.userId])).rows[0];
    for (const u of new Set([req.auth.userId, ...found])) await c.query('INSERT INTO conversation_participants (school_id, conversation_id, user_id, last_read_at) VALUES ($1,$2,$3,$4)', [req.auth.schoolId, t.id, u, u === req.auth.userId ? new Date() : null]);
    await c.query('INSERT INTO messages (school_id, conversation_id, sender_id, body) VALUES ($1,$2,$3,$4)', [req.auth.schoolId, t.id, req.auth.userId, b.body]);
    await notify(c, req.auth.schoolId, found, { kind: 'message', title: `New message: ${b.subject}`, link: `#/messages/${t.id}` });
    await audit(c, req, 'messages.thread_created', { type: 'message_thread', id: t.id, meta: { recipients: found.length } });
    return { id: t.id };
  }));
  app.get('/messages/threads/:id', { onRequest: [A, app.perm('messages.use')], schema: { params: idParams } }, async (req) => withTx({ ...ctx(req), readOnly: false }, async (c) => {
    const part = await c.query('SELECT 1 FROM conversation_participants WHERE conversation_id = $1 AND user_id = $2', [req.params.id, req.auth.userId]);
    if (!part.rowCount) throw E.notFound('Conversation');           // participants only
    const t = (await c.query('SELECT id, subject, created_at FROM conversations WHERE id = $1', [req.params.id])).rows[0];
    const msgs = (await c.query(`SELECT m.id, m.body, m.created_at, m.sender_id, u.full_name AS sender, (m.sender_id = $2) AS mine FROM messages m JOIN users u ON u.id = m.sender_id
      WHERE m.conversation_id = $1 ORDER BY m.created_at LIMIT 500`, [req.params.id, req.auth.userId])).rows;
    if (!req.auth.support) await c.query('UPDATE conversation_participants SET last_read_at = now() WHERE conversation_id = $1 AND user_id = $2', [req.params.id, req.auth.userId]);
    return { thread: t, messages: msgs };
  }));
  app.post('/messages/threads/:id', { onRequest: [A, app.perm('messages.use')], config: { rateLimit: { max: 60, timeWindow: '1 minute' } }, schema: { params: idParams, body: obj({ body: str(5000, 1) }, ['body']) } }, async (req) =>
    withTx(ctx(req), async (c) => {
      const parts = (await c.query('SELECT user_id FROM conversation_participants WHERE conversation_id = $1', [req.params.id])).rows.map((r) => r.user_id);
      if (!parts.includes(req.auth.userId)) throw E.notFound('Conversation');
      await c.query('INSERT INTO messages (school_id, conversation_id, sender_id, body) VALUES ($1,$2,$3,$4)', [req.auth.schoolId, req.params.id, req.auth.userId, req.body.body]);
      await c.query('UPDATE conversations SET last_message_at = now() WHERE id = $1', [req.params.id]);
      await c.query('UPDATE conversation_participants SET last_read_at = now() WHERE conversation_id = $1 AND user_id = $2', [req.params.id, req.auth.userId]);
      await notify(c, req.auth.schoolId, parts.filter((u) => u !== req.auth.userId), { kind: 'message', title: 'New reply', link: `#/messages/${req.params.id}` });
      return { ok: true };
    }));

  // Newsletters were merged into announcements on 11 Oct 2026 (migration 025). Old links answer 410 with the new place.
  app.get('/newsletters', { onRequest: [A, app.perm('announcements.view', 'announcements.manage')] }, async () => { throw new (require('../lib/errors').AppError)(410, 'GONE', 'Newsletters are now part of Announcements (/api/v1/announcements).'); });

};
