'use strict';
// Phase 6 (part 3) — study materials, live classes, bell times and the live class monitor.
//   • Teachers share files, links and videos with the classes they teach (teacher_class_access or form teacher);
//     heads (materials.manage) may share with any class and remove anything.
//   • Pupils and parents see only PUBLISHED materials and live classes of their own (children's) current classes.
//     The join link of a live class is only sent to them from 15 minutes before the start until it ends.
//   • Links must be https; files go through the normal upload checks (type sniffing, size, optional virus scan).
//   • The monitor shows, for every class, the lesson that should be on NOW (bell times or the timetable's own times)
//     and whether that teacher has clocked in today.
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, str, uuid, idParams } = require('../lib/schema');
const { ctx } = require('../auth/plugin');
const { audit } = require('../audit/audit');
const { saveUpload } = require('../storage');

const httpsUrl = { type: 'string', maxLength: 500, pattern: '^https://[^\\s<>"]+$' };
const optTxt = (n) => ({ type: ['string', 'null'], maxLength: n });
const JOIN_EARLY_MIN = 15;
const isLearner = (req) => req.auth.portal === 'student' || req.auth.portal === 'parent';
const learnerIds = (req) => [req.auth.studentId, ...(req.auth.children || [])].filter(Boolean);
async function learnerClasses(c, ids) {
  if (!ids.length) return [];
  return (await c.query(`SELECT DISTINCT e.class_id FROM student_enrollments e JOIN academic_sessions s ON s.id = e.session_id AND s.is_current
    WHERE e.student_id = ANY($1::uuid[]) AND e.status <> 'withdrawn'`, [ids])).rows.map((r) => r.class_id);
}
async function teachesClass(c, req, classId) {
  if (req.can('materials.manage')) return true;
  if (!req.can('materials.create') || !req.auth.staffId) return false;
  return (await c.query(`SELECT 1 FROM teacher_class_access WHERE staff_id = $1 AND class_id = $2
    UNION SELECT 1 FROM classes WHERE id = $2 AND form_teacher_id = $1 LIMIT 1`, [req.auth.staffId, classId])).rowCount > 0;
}
const STAFF_READ = (req) => req.can('materials.view') || req.can('materials.manage') || req.can('materials.create');
// what a video link is (for a friendly label); the link itself is opened on the provider's site
function videoHost(url) { try { const h = new URL(url).hostname.replace(/^www\./, ''); return /youtube\.com$|youtu\.be$/.test(h) ? 'YouTube' : /vimeo\.com$/.test(h) ? 'Vimeo' : h; } catch { return null; } }

module.exports = async function materialsRoutes(app) {
  const A = app.authenticate;
  const ANY = app.perm('materials.view', 'materials.create', 'materials.manage', 'materials.view_own', 'materials.view_children');
  const WRITE = app.perm('materials.create', 'materials.manage');

  // classes the caller may share with (teachers: theirs; heads: all)
  app.get('/materials/options', { onRequest: [A, WRITE] }, async (req) => withTx(ctx(req), async (c) => {
    const all = req.can('materials.manage');
    const classes = all ? (await c.query('SELECT id, display_name FROM classes ORDER BY sort_order, display_name')).rows
      : req.auth.staffId ? (await c.query(`SELECT DISTINCT cl.id, cl.display_name, cl.sort_order FROM classes cl LEFT JOIN teacher_class_access a ON a.class_id = cl.id AND a.staff_id = $1
          WHERE a.staff_id IS NOT NULL OR cl.form_teacher_id = $1 ORDER BY cl.sort_order, cl.display_name`, [req.auth.staffId])).rows.map(({ sort_order: _s, ...r }) => r) : [];
    const subjects = (await c.query('SELECT id, name FROM subjects ORDER BY name')).rows;
    return { classes, subjects, allClasses: all };
  }));

  // ───────────────────────── study materials ─────────────────────────
  app.get('/materials', { onRequest: [A, ANY], schema: { querystring: obj({ classId: uuid, subjectId: uuid }) } }, async (req) => withTx(ctx(req), async (c) => {
    const p = []; const w = ['m.deleted_at IS NULL'];
    if (isLearner(req)) { const cls = await learnerClasses(c, learnerIds(req)); p.push(cls); w.push(`m.class_id = ANY($${p.length}::uuid[]) AND m.published`); }
    else if (!STAFF_READ(req)) throw E.forbidden();
    if (req.query.classId) { p.push(req.query.classId); w.push(`m.class_id = $${p.length}`); }
    if (req.query.subjectId) { p.push(req.query.subjectId); w.push(`m.subject_id = $${p.length}`); }
    const rows = (await c.query(`SELECT m.id, m.class_id, cl.display_name AS class_name, m.subject_id, sb.name AS subject, m.title, m.description, m.kind, m.url, m.file_id,
        up.original_name AS file_name, up.mime AS file_mime, up.size_bytes AS file_size, m.published, m.created_at, m.created_by, u.full_name AS shared_by
      FROM study_materials m JOIN classes cl ON cl.id = m.class_id LEFT JOIN subjects sb ON sb.id = m.subject_id LEFT JOIN users u ON u.id = m.created_by
      LEFT JOIN uploads up ON up.id = m.file_id AND up.deleted_at IS NULL WHERE ${w.join(' AND ')} ORDER BY m.created_at DESC LIMIT 500`, p)).rows;
    const mine = (r) => r.created_by === req.auth.userId;
    return { items: rows.map(({ created_by: _cb, ...r }) => ({ ...r, video: r.kind === 'video' ? videoHost(r.url) : null, canDelete: !isLearner(req) && (req.can('materials.manage') || mine({ created_by: _cb })) })) };
  }));

  app.post('/materials', {
    onRequest: [A, WRITE],
    schema: { body: obj({ classId: uuid, subjectId: { ...uuid, type: ['string', 'null'] }, title: str(160, 2), description: optTxt(2000), kind: { enum: ['link', 'video'] }, url: httpsUrl, published: { type: 'boolean' } },
      ['classId', 'title', 'kind', 'url']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const b = req.body;
    if (!(await teachesClass(c, req, b.classId))) throw E.forbidden('You can only share with classes you teach.');
    try { new URL(b.url); } catch { throw E.bad('That link is not valid.', { field: 'url' }); }
    const r = (await c.query(`INSERT INTO study_materials (school_id, class_id, subject_id, title, description, kind, url, published, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`,
      [req.auth.schoolId, b.classId, b.subjectId || null, b.title.trim(), b.description || null, b.kind, b.url, b.published !== false, req.auth.userId])).rows[0];
    await audit(c, req, 'materials.shared', { type: 'study_material', id: r.id, meta: { kind: b.kind, classId: b.classId } });
    return { id: r.id };
  }));

  // a file: multipart with fields classId, subjectId, title, description and one file
  app.post('/materials/file', { onRequest: [A, WRITE], config: { rateLimit: { max: 30, timeWindow: '1 minute' } } }, async (req) => {
    const data = await req.file(); if (!data) throw E.bad('Attach a file.');
    const f = (n, max) => { const x = data.fields && data.fields[n]; const v = x && typeof x.value === 'string' ? x.value.trim() : ''; return v.slice(0, max); };
    const classId = f('classId', 40); const subjectId = f('subjectId', 40) || null; const title = f('title', 160); const description = f('description', 2000) || null;
    const U = /^[0-9a-f-]{36}$/i;
    if (!U.test(classId)) throw E.bad('Choose a class.', { field: 'classId' });
    if (subjectId && !U.test(subjectId)) throw E.bad('Choose a subject.', { field: 'subjectId' });
    if (title.length < 2) throw E.bad('Give the material a title.', { field: 'title' });
    const buffer = await data.toBuffer();
    return withTx(ctx(req), async (c) => {
      if (!(await teachesClass(c, req, classId))) throw E.forbidden('You can only share with classes you teach.');
      const up = await saveUpload(c, { schoolId: req.auth.schoolId, userId: req.auth.userId, purpose: 'study_material', buffer, originalName: data.filename });
      const r = (await c.query(`INSERT INTO study_materials (school_id, class_id, subject_id, title, description, kind, file_id, created_by) VALUES ($1,$2,$3,$4,$5,'file',$6,$7) RETURNING id`,
        [req.auth.schoolId, classId, subjectId, title, description, up.id, req.auth.userId])).rows[0];
      await audit(c, req, 'materials.shared', { type: 'study_material', id: r.id, meta: { kind: 'file', classId, mime: up.mime, bytes: up.size_bytes } });
      return { id: r.id, fileId: up.id };
    });
  });

  app.delete('/materials/:id', { onRequest: [A, WRITE], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const m = (await c.query('SELECT id, created_by, file_id, title FROM study_materials WHERE id = $1 AND deleted_at IS NULL FOR UPDATE', [req.params.id])).rows[0];
    if (!m) throw E.notFound('Material');
    if (!req.can('materials.manage') && m.created_by !== req.auth.userId) throw E.forbidden('Only the person who shared it (or a head) can remove it.');
    await c.query('UPDATE study_materials SET deleted_at = now() WHERE id = $1', [m.id]);
    if (m.file_id) await c.query('UPDATE uploads SET deleted_at = now() WHERE id = $1', [m.file_id]);
    await audit(c, req, 'materials.removed', { type: 'study_material', id: m.id, meta: { title: m.title } });
    return { ok: true };
  }));

  // ───────────────────────── live classes ─────────────────────────
  app.get('/live-classes', { onRequest: [A, ANY], schema: { querystring: obj({ classId: uuid, past: { type: 'boolean' } }) } }, async (req) => withTx(ctx(req), async (c) => {
    const p = []; const w = ['l.cancelled_at IS NULL'];
    const learner = isLearner(req);
    if (learner) { p.push(await learnerClasses(c, learnerIds(req))); w.push(`l.class_id = ANY($${p.length}::uuid[])`); }
    else if (!STAFF_READ(req)) throw E.forbidden();
    if (req.query.classId) { p.push(req.query.classId); w.push(`l.class_id = $${p.length}`); }
    w.push(req.query.past ? "l.starts_at + make_interval(mins => l.duration_min) < now()" : "l.starts_at + make_interval(mins => l.duration_min) >= now()");
    const rows = (await c.query(`SELECT l.id, l.class_id, cl.display_name AS class_name, sb.name AS subject, l.title, l.starts_at, l.duration_min, l.join_url, l.note, l.created_by, u.full_name AS teacher,
        (now() >= l.starts_at - make_interval(mins => ${JOIN_EARLY_MIN}) AND now() <= l.starts_at + make_interval(mins => l.duration_min)) AS joinable,
        (now() >= l.starts_at AND now() <= l.starts_at + make_interval(mins => l.duration_min)) AS live_now
      FROM live_classes l JOIN classes cl ON cl.id = l.class_id LEFT JOIN subjects sb ON sb.id = l.subject_id LEFT JOIN users u ON u.id = l.created_by
      WHERE ${w.join(' AND ')} ORDER BY l.starts_at ${req.query.past ? 'DESC' : 'ASC'} LIMIT 200`, p)).rows;
    return { items: rows.map(({ created_by: cb, ...r }) => ({ ...r, join_url: learner && !r.joinable ? null : r.join_url, canCancel: !learner && (req.can('materials.manage') || cb === req.auth.userId) })), joinEarlyMinutes: JOIN_EARLY_MIN };
  }));
  app.post('/live-classes', {
    onRequest: [A, WRITE],
    schema: { body: obj({ classId: uuid, subjectId: { ...uuid, type: ['string', 'null'] }, title: str(160, 2), startsAt: { type: 'string', format: 'date-time' }, durationMin: { type: 'integer', minimum: 5, maximum: 480 },
      joinUrl: httpsUrl, note: optTxt(1000) }, ['classId', 'title', 'startsAt', 'durationMin', 'joinUrl']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const b = req.body;
    if (!(await teachesClass(c, req, b.classId))) throw E.forbidden('You can only schedule live classes for classes you teach.');
    const start = new Date(b.startsAt);
    if (start.getTime() + b.durationMin * 60000 < Date.now()) throw E.bad('That time has already passed.', { field: 'startsAt' });
    if (start.getTime() > Date.now() + 366 * 864e5) throw E.bad('Choose a date within the next year.', { field: 'startsAt' });
    try { new URL(b.joinUrl); } catch { throw E.bad('That link is not valid.', { field: 'joinUrl' }); }
    const r = (await c.query(`INSERT INTO live_classes (school_id, class_id, subject_id, title, starts_at, duration_min, join_url, note, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`,
      [req.auth.schoolId, b.classId, b.subjectId || null, b.title.trim(), start, b.durationMin, b.joinUrl, b.note || null, req.auth.userId])).rows[0];
    await audit(c, req, 'live_class.scheduled', { type: 'live_class', id: r.id, meta: { classId: b.classId, startsAt: start.toISOString() } });
    return { id: r.id };
  }));
  app.post('/live-classes/:id/cancel', { onRequest: [A, WRITE], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const l = (await c.query('SELECT id, created_by, cancelled_at FROM live_classes WHERE id = $1 FOR UPDATE', [req.params.id])).rows[0];
    if (!l || l.cancelled_at) throw E.notFound('Live class');
    if (!req.can('materials.manage') && l.created_by !== req.auth.userId) throw E.forbidden('Only the teacher who scheduled it (or a head) can cancel it.');
    await c.query('UPDATE live_classes SET cancelled_at = now() WHERE id = $1', [l.id]);
    await audit(c, req, 'live_class.cancelled', { type: 'live_class', id: l.id });
    return { ok: true };
  }));

  // ───────────────────────── bell times + live class monitor ─────────────────────────
  app.get('/school/periods', { onRequest: [A, app.perm('academic.view', 'clock.view')] }, async (req) => withTx(ctx(req), async (c) => ({
    items: (await c.query("SELECT period, to_char(starts_at, 'HH24:MI') AS starts_at, to_char(ends_at, 'HH24:MI') AS ends_at, label FROM school_periods ORDER BY period")).rows,
  })));
  app.put('/school/periods', {
    onRequest: [A, app.perm('academic.manage')],
    schema: { body: obj({ items: { type: 'array', maxItems: 16, items: obj({ period: { type: 'integer', minimum: 1, maximum: 16 }, startsAt: { type: 'string', pattern: '^([01][0-9]|2[0-3]):[0-5][0-9]$' },
      endsAt: { type: 'string', pattern: '^([01][0-9]|2[0-3]):[0-5][0-9]$' }, label: optTxt(40) }, ['period', 'startsAt', 'endsAt']) } }, ['items']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const items = [...req.body.items].sort((a, b) => a.period - b.period);
    if (new Set(items.map((x) => x.period)).size !== items.length) throw E.bad('Each period can appear only once.');
    for (const [i, x] of items.entries()) {
      if (x.endsAt <= x.startsAt) throw E.bad(`Period ${x.period} must end after it starts.`);
      if (i && x.startsAt < items[i - 1].endsAt) throw E.bad(`Period ${x.period} starts before period ${items[i - 1].period} ends.`);
    }
    await c.query('DELETE FROM school_periods');
    for (const x of items) await c.query('INSERT INTO school_periods (school_id, period, starts_at, ends_at, label) VALUES ($1,$2,$3,$4,$5)', [req.auth.schoolId, x.period, x.startsAt, x.endsAt, x.label || null]);
    await audit(c, req, 'academic.bell_times_set', { type: 'school', id: req.auth.schoolId, meta: { periods: items.length } });
    return { ok: true };
  }));

  app.get('/monitor/now', { onRequest: [A, app.perm('clock.view')], schema: { querystring: obj({ at: { type: 'string', pattern: '^[1-7]T([01][0-9]|2[0-3]):[0-5][0-9]$' } }) } }, async (req) => withTx(ctx(req), async (c) => {
    // the school's local day of the week (1 = Monday) and time; ?at=3T10:15 lets the head preview another moment of the week
    const now = (await c.query(`SELECT extract(isodow FROM now() AT TIME ZONE timezone)::int AS dow, to_char(now() AT TIME ZONE timezone, 'HH24:MI') AS t,
      (now() AT TIME ZONE timezone)::date::text AS day FROM schools WHERE id = $1`, [req.auth.schoolId])).rows[0];
    const preview = req.query.at ? { dow: Number(req.query.at[0]), t: req.query.at.slice(2) } : null;
    const dow = preview ? preview.dow : now.dow; const t = preview ? preview.t : now.t;
    const periods = (await c.query("SELECT period, to_char(starts_at, 'HH24:MI') AS s, to_char(ends_at, 'HH24:MI') AS e, label FROM school_periods ORDER BY period")).rows;
    const rows = (await c.query(`SELECT cl.id AS class_id, cl.display_name, te.period, te.label, sb.name AS subject,
        coalesce(to_char(te.starts_at, 'HH24:MI'), to_char(sp.starts_at, 'HH24:MI')) AS s, coalesce(to_char(te.ends_at, 'HH24:MI'), to_char(sp.ends_at, 'HH24:MI')) AS e,
        coalesce(te.teacher_id, cs.teacher_id) AS teacher_id, st.full_name AS teacher
      FROM classes cl
      LEFT JOIN timetable_entries te ON te.class_id = cl.id AND te.day_of_week = $1
      LEFT JOIN school_periods sp ON sp.period = te.period
      LEFT JOIN subjects sb ON sb.id = te.subject_id
      LEFT JOIN class_subjects cs ON cs.class_id = cl.id AND cs.subject_id = te.subject_id
      LEFT JOIN staff st ON st.id = coalesce(te.teacher_id, cs.teacher_id)
      ORDER BY cl.sort_order, cl.display_name, te.period`, [dow])).rows;
    const clock = new Map((await c.query(`SELECT staff_id, max(at) FILTER (WHERE kind = 'in') AS in_at, max(at) FILTER (WHERE kind = 'out') AS out_at FROM staff_clock WHERE day = $1 GROUP BY staff_id`, [now.day])).rows.map((r) => [r.staff_id, r]));
    const live = (await c.query(`SELECT l.class_id, l.title FROM live_classes l WHERE l.cancelled_at IS NULL AND now() BETWEEN l.starts_at AND l.starts_at + make_interval(mins => l.duration_min)`)).rows;
    const byClass = new Map();
    for (const r of rows) { if (!byClass.has(r.class_id)) byClass.set(r.class_id, { classId: r.class_id, className: r.display_name, entries: [] }); if (r.period) byClass.get(r.class_id).entries.push(r); }
    const items = [...byClass.values()].map((k) => {
      const cur = k.entries.find((e) => e.s && e.e && e.s <= t && t < e.e);
      const next = k.entries.filter((e) => e.s && e.s > t).sort((a, b) => (a.s < b.s ? -1 : 1))[0];
      const liveNow = live.find((l) => l.class_id === k.classId);
      let status = 'free'; let teacherIn = null;
      if (!k.entries.length) status = 'no_timetable';
      else if (!k.entries.some((e) => e.s && e.e)) status = 'no_times';
      else if (cur && !cur.subject) status = 'break';
      else if (cur) {
        const ck = cur.teacher_id ? clock.get(cur.teacher_id) : null;
        teacherIn = !!(ck && ck.in_at && (!ck.out_at || ck.out_at < ck.in_at));
        status = preview ? 'scheduled' : cur.teacher_id ? (teacherIn ? 'in_session' : 'teacher_not_in') : 'no_teacher';
      }
      return { classId: k.classId, className: k.className, status, period: cur ? cur.period : null, subject: cur ? (cur.subject || cur.label) : null, teacher: cur ? cur.teacher : null,
        from: cur ? cur.s : null, to: cur ? cur.e : null, next: next ? { subject: next.subject || next.label, from: next.s, teacher: next.teacher } : null, liveClass: liveNow ? liveNow.title : null };
    });
    const count = (s) => items.filter((x) => x.status === s).length;
    return { dayOfWeek: dow, time: t, preview: !!preview, weekend: dow >= 6 && !rows.some((r) => r.period), hasBellTimes: periods.length > 0, items,
      summary: { classes: items.length, inSession: count('in_session'), teacherNotIn: count('teacher_not_in'), free: count('free') + count('break'), noTimetable: count('no_timetable') + count('no_times') } };
  }));
};

module.exports.canReadFile = async function canReadMaterialFile(c, req, fileId) {
  const m = (await c.query('SELECT class_id, published FROM study_materials WHERE file_id = $1 AND deleted_at IS NULL', [fileId])).rows[0];
  if (!m) return false;
  if (!isLearner(req)) return STAFF_READ(req);
  if (!m.published) return false;
  return (await learnerClasses(c, learnerIds(req))).includes(m.class_id);
};
