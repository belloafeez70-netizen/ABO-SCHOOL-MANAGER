'use strict';
// CBT question bank (search/filter/paginate, CRUD, duplicate, archive, import/export), CBT dashboard,
// examination & class analytics, and school-level CBT defaults.
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, str, uuid, idParams } = require('../lib/schema');
const { ctx } = require('../auth/plugin');
const { audit } = require('../audit/audit');
const { parseCsv, toCsv, toXlsx, readXlsx } = require('../lib/csv');
const { sniff } = require('../storage');
const G = require('../services/grading');
const { lifecycle } = require('../services/cbt');
const Q = require('../services/cbt_questions');
const { scopeSql, loadExam, bandsForExam, countedResults } = require('./cbt');
const { notify } = require('../services/notify');

const FULL = (req) => req.can('cbt.publish');
const like = (s) => `%${String(s).toLowerCase().replace(/[\\%_]/g, (m) => '\\' + m)}%`;
const round1 = (n) => (n === null || n === undefined ? null : Math.round(Number(n) * 10) / 10);
const MAX_IMPORT = 2000;

// "Questions from teachers" (027): with bank approval switched on, questions from people who cannot publish exams wait
// as 'pending' until the exam officer approves them; only 'active' questions can ever be used in an examination.
function bankFilter(q, p, me = null) {
  const w = ['q.exam_id IS NULL'];
  const st = q.status || 'active';
  w.push(st === 'all' ? "q.status IN ('active','archived')" : `q.status = '${['archived', 'pending', 'rejected'].includes(st) ? st : 'active'}'`);
  if (me && (st === 'pending' || st === 'rejected')) { p.push(me); w.push(`q.created_by = $${p.length}`); }   // teachers see only their own waiting / sent-back questions
  if (q.q) { p.push(like(q.q)); w.push(`(lower(q.text) LIKE $${p.length} OR lower(COALESCE(q.topic,'')) LIKE $${p.length} OR lower(COALESCE(q.subtopic,'')) LIKE $${p.length})`); }
  for (const [k, col] of [['subjectId', 'subject_id'], ['classId', 'class_id'], ['termId', 'term_id'], ['createdBy', 'created_by']]) if (q[k]) { p.push(q[k]); w.push(`q.${col} = $${p.length}`); }
  if (q.topic) { p.push(q.topic.trim().toLowerCase()); w.push(`lower(q.topic) = $${p.length}`); }
  if (q.difficulty) { p.push(q.difficulty); w.push(`q.difficulty = $${p.length}`); }
  if (q.type) { if (q.type === 'image') w.push('q.image_file_id IS NOT NULL'); else { p.push(q.type); w.push(`q.type = $${p.length}`); } }
  return w.join(' AND ');
}
const bankQuery = obj({ q: { type: 'string', maxLength: 120 }, subjectId: uuid, classId: uuid, termId: uuid, createdBy: uuid, topic: { type: 'string', maxLength: 120 },
  difficulty: { enum: ['easy', 'medium', 'hard'] }, type: { enum: [...Q.TYPES, 'image'] }, status: { enum: ['active', 'archived', 'all', 'pending', 'rejected'] },
  page: { type: 'integer', minimum: 1, maximum: 100000 }, pageSize: { type: 'integer', minimum: 1, maximum: 100 }, format: { enum: ['csv', 'xlsx'] } });

async function bankQuestion(c, req, id, { forEdit = false } = {}) {
  const q = (await Q.loadQuestions(c, 'q.id = $1 AND q.exam_id IS NULL', [id]))[0];
  if (!q) throw E.notFound('Question');
  if (forEdit && !FULL(req) && q.created_by_name !== undefined) {
    const owner = (await c.query('SELECT created_by FROM cbt_questions WHERE id = $1', [id])).rows[0].created_by;
    if (owner !== req.auth.userId) throw E.forbidden('You can only change questions you created. Ask the exam officer to edit this one.');
  }
  return q;
}
async function bankApproval(c) { const r = (await c.query('SELECT cbt FROM school_settings LIMIT 1')).rows[0]; return !!(r && r.cbt && r.cbt.bankApproval); }
// true ⇒ this person's new or changed bank questions must wait for the exam officer
async function mustWait(c, req) { return !FULL(req) && bankApproval(c); }
async function holdForReview(c, req, ids) {
  if (!ids.length || !(await mustWait(c, req))) return false;
  await c.query("UPDATE cbt_questions SET status = 'pending', reviewed_by = NULL, reviewed_at = NULL, review_note = NULL WHERE id = ANY($1::uuid[]) AND exam_id IS NULL", [ids]);
  return true;
}
const LETTERS = ['A', 'B', 'C', 'D', 'E', 'F'];
function answerText(q) {
  if (['mcq', 'multi_select', 'true_false'].includes(q.type)) return q.options.map((o, i) => (o.isCorrect ? (q.type === 'true_false' ? o.text : LETTERS[i]) : null)).filter(Boolean).join(',');
  const k = q.answer_key || {};
  if (k.accepted) return k.accepted.join('|');
  if (k.value !== undefined) return String(k.value) + (k.tolerance ? `±${k.tolerance}` : '');
  return '';
}

// ── bulk import: validate every row first; nothing corrupt is ever inserted ──
const HEAD = { subject: 'subject', class: 'class', topic: 'topic', subtopic: 'subtopic', type: 'type', questiontype: 'type', question: 'question', questiontext: 'question',
  optiona: 'a', optionb: 'b', optionc: 'c', optiond: 'd', optione: 'e', a: 'a', b: 'b', c: 'c', d: 'd', e: 'e', correctanswer: 'answer', answer: 'answer', correct: 'answer',
  mark: 'mark', marks: 'mark', difficulty: 'difficulty', explanation: 'explanation', tolerance: 'tolerance' };
const TYPE_ALIASES = { mcq: 'mcq', multiplechoice: 'mcq', objective: 'mcq', multipleselect: 'multi_select', multiselect: 'multi_select', truefalse: 'true_false', tf: 'true_false',
  shortanswer: 'short_answer', short: 'short_answer', numeric: 'numeric', numerical: 'numeric', number: 'numeric', fillintheblank: 'fill_blank', fillblank: 'fill_blank', blank: 'fill_blank',
  essay: 'theory', theory: 'theory', image: 'mcq', imagebased: 'mcq' };
const n = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
async function validateImport(c, rows) {
  const subjects = new Map((await c.query('SELECT id, name FROM subjects')).rows.map((r) => [r.name.toLowerCase().trim(), r.id]));
  const classes = new Map((await c.query('SELECT id, display_name FROM classes')).rows.map((r) => [n(r.display_name), r.id]));
  const valid = []; const errors = []; const seen = new Set();
  rows.forEach((r, i) => {
    const row = i + 2; const before = errors.length; const err = (field, message) => errors.push({ row, field, message });
    const text = String(r.question || '').trim();
    if (!text) err('question', 'is required'); else if (text.length > 4000) err('question', 'is longer than 4000 characters');
    const type = r.type ? TYPE_ALIASES[n(r.type)] : 'mcq';
    if (!type) err('type', `“${r.type}” is not a question type (use MCQ, Multiple Select, True/False, Short Answer, Numeric, Fill Blank, Essay)`);
    const subjectId = r.subject ? subjects.get(String(r.subject).toLowerCase().trim()) : null;
    if (!r.subject) err('subject', 'is required'); else if (!subjectId) err('subject', `“${r.subject}” does not exist in Academics › Subjects`);
    const classId = r.class ? classes.get(n(r.class)) : null;
    if (r.class && !classId) err('class', `“${r.class}” does not exist`);
    const marks = r.mark === undefined || r.mark === '' ? 1 : Number(r.mark);
    if (!(marks > 0 && marks <= 100)) err('mark', 'must be a number between 0.5 and 100');
    const difficulty = r.difficulty ? n(r.difficulty).replace('difficult', 'hard').replace('moderate', 'medium') : 'medium';
    if (!['easy', 'medium', 'hard'].includes(difficulty)) err('difficulty', 'must be Easy, Medium or Hard');
    const opts = ['a', 'b', 'c', 'd', 'e'].map((k) => String(r[k] || '').trim());
    const answer = String(r.answer || '').trim();
    const q = { type, text, marks, subjectId, classId, topic: r.topic ? String(r.topic).trim().slice(0, 120) : null, subtopic: r.subtopic ? String(r.subtopic).trim().slice(0, 120) : null, difficulty, explanation: r.explanation ? String(r.explanation).slice(0, 4000) : null };
    if (type === 'mcq' || type === 'multi_select') {
      const present = opts.map((t, k) => ({ t, L: LETTERS[k] })).filter((x) => x.t);
      if (present.length < 2) err('options', 'at least two options (Option A, Option B …) are required');
      const letters = answer.toUpperCase().split(/[\s,;/]+/).filter(Boolean);
      if (!letters.length) err('answer', 'is required (e.g. B, or A,C for multiple select)');
      else if (letters.some((L) => !present.find((x) => x.L === L))) err('answer', `“${answer}” does not match a filled option letter`);
      else if (type === 'mcq' && letters.length !== 1) err('answer', 'multiple-choice questions need exactly one correct letter');
      q.options = present.map((x) => ({ text: x.t, isCorrect: letters.includes(x.L) }));
    } else if (type === 'true_false') {
      const a = n(answer); if (!['true', 'false', 't', 'f'].includes(a)) err('answer', 'must be True or False'); q.correct = a === 'true' || a === 't';
    } else if (type === 'numeric') {
      const [v, tol] = answer.replace(/,/g, '').split(/±|\+-|\+\/-/); q.numericValue = Number(v); q.tolerance = Number(tol || r.tolerance || 0);
      if (!answer || !Number.isFinite(q.numericValue)) err('answer', 'must be a number (optionally with ± tolerance, e.g. 3.5±0.1)');
    } else if (type === 'fill_blank' || type === 'short_answer') {
      q.accepted = answer.split('|').map((x) => x.trim()).filter(Boolean);
      if (type === 'fill_blank' && !q.accepted.length) err('answer', 'give the accepted answer(s), separated by |');
    }
    const key = `${subjectId}|${text.toLowerCase()}`;
    if (text && seen.has(key)) err('question', 'is duplicated in this file'); seen.add(key);
    if (errors.length === before) { try { Q.normalise(q); valid.push({ n: row, ...q }); } catch (e) { err('question', e.message); } }
  });
  return { valid, errors };
}

module.exports = async function cbtBankRoutes(app) {
  const A = app.authenticate;

  // ── bank ──
  app.get('/cbt/bank', { onRequest: [A, app.perm('cbt.view')], schema: { querystring: bankQuery } }, async (req, reply) => withTx(ctx(req), async (c) => {
    const p = []; const where = bankFilter(req.query, p, FULL(req) ? null : req.auth.userId);
    const size = req.query.pageSize || 25; const pg = req.query.page || 1;
    const total = (await c.query(`SELECT count(*)::int AS n FROM cbt_questions q WHERE ${where}`, p)).rows[0].n;
    const items = await Q.loadQuestions(c, `${where} ORDER BY q.updated_at DESC, q.id LIMIT ${size} OFFSET ${(pg - 1) * size}`, p);
    for (const it of items) { it.used_in = (await c.query('SELECT count(DISTINCT exam_id)::int AS n FROM cbt_questions WHERE source_question_id = $1', [it.id])).rows[0].n; it.options_count = it.options.length; }
    void reply;
    return { items, total, page: pg, pages: Math.max(1, Math.ceil(total / size)) };
  }));
  app.get('/cbt/bank/topics', { onRequest: [A, app.perm('cbt.view')], schema: { querystring: obj({ subjectId: uuid }) } }, async (req) => withTx(ctx(req), async (c) => ({
    items: (await c.query(`SELECT topic, count(*)::int AS questions, count(*) FILTER (WHERE difficulty = 'easy')::int AS easy, count(*) FILTER (WHERE difficulty = 'medium')::int AS medium, count(*) FILTER (WHERE difficulty = 'hard')::int AS hard
      FROM cbt_questions WHERE exam_id IS NULL AND status = 'active' AND topic IS NOT NULL ${req.query.subjectId ? 'AND subject_id = $1' : ''} GROUP BY topic ORDER BY topic`, req.query.subjectId ? [req.query.subjectId] : [])).rows,
  })));
  app.get('/cbt/bank/export', { onRequest: [A, app.perm('cbt.view')], schema: { querystring: bankQuery } }, async (req, reply) => {
    const rows = await withTx({ ...ctx(req), readOnly: false }, async (c) => {          // not read-only: the export is audited
      const p = []; const where = bankFilter(req.query, p);
      const items = await Q.loadQuestions(c, `${where} ORDER BY s.name, q.topic, q.created_at LIMIT 20000`, p);
      await audit(c, req, 'data.exported', { type: 'export', id: 'cbt_questions', meta: { rows: items.length } });
      return items.map((q) => ({ subject: q.subject, class: q.class_name, topic: q.topic, subtopic: q.subtopic, type: q.type, question: q.text,
        a: q.type !== 'true_false' && q.options[0] ? q.options[0].text : '', b: q.type !== 'true_false' && q.options[1] ? q.options[1].text : '', c: q.options[2] ? q.options[2].text : '', d: q.options[3] ? q.options[3].text : '', e: q.options[4] ? q.options[4].text : '',
        answer: answerText(q), mark: Number(q.marks), difficulty: q.difficulty, explanation: q.explanation, status: q.status }));
    });
    const cols = [['subject', 'Subject'], ['class', 'Class'], ['topic', 'Topic'], ['subtopic', 'Subtopic'], ['type', 'Type'], ['question', 'Question'], ['a', 'Option A'], ['b', 'Option B'], ['c', 'Option C'], ['d', 'Option D'], ['e', 'Option E'],
      ['answer', 'Correct Answer'], ['mark', 'Mark'], ['difficulty', 'Difficulty'], ['explanation', 'Explanation'], ['status', 'Status']].map(([key, label]) => ({ key, label }));
    if (req.query.format === 'xlsx') { reply.header('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet').header('Content-Disposition', 'attachment; filename="question-bank.xlsx"'); return toXlsx('Question bank', cols, rows); }
    reply.header('Content-Type', 'text/csv; charset=utf-8').header('Content-Disposition', 'attachment; filename="question-bank.csv"');
    return toCsv(cols, rows);
  });
  app.get('/cbt/bank/import/template.csv', { onRequest: [A, app.perm('cbt.create')] }, async (req, reply) => {
    reply.header('Content-Type', 'text/csv; charset=utf-8').header('Content-Disposition', 'attachment; filename="question-bank-template.csv"');
    return ['Subject,Class,Topic,Type,Question,Option A,Option B,Option C,Option D,Correct Answer,Mark,Difficulty,Explanation',
      'Mathematics,JSS 1A,Algebra,MCQ,"If 2x + 5 = 15, find x.",3,5,7,10,B,1,Easy,Subtract 5 then divide by 2',
      'Mathematics,JSS 1A,Number Bases,Multiple Select,Which of these are even numbers?,2,3,4,5,"A,C",2,Medium,',
      'Mathematics,JSS 1A,Fractions,True/False,1/2 is greater than 1/3,,,,,True,1,Easy,',
      'Mathematics,JSS 1A,Indices,Numeric,Evaluate 2^{3},,,,,8,1,Easy,',
      'English Language,JSS 1A,Grammar,Fill Blank,The plural of child is ____.,,,,,children|Children,1,Easy,',
      'Basic Science,JSS 1A,Living Things,Essay,Explain two differences between plants and animals.,,,,,,5,Hard,'].join('\n') + '\n';
  });
  app.post('/cbt/bank/import/preview', { onRequest: [A, app.perm('cbt.create')], config: { rateLimit: { max: 20, timeWindow: '1 minute' } } }, async (req) => {
    const data = await req.file(); if (!data) throw E.bad('Attach a CSV or Excel file.');
    const buffer = await data.toBuffer();
    const type = sniff(buffer, data.filename);
    let table;
    if (type && type.ext === 'xlsx') table = await readXlsx(buffer, MAX_IMPORT + 1);
    else if (type && (type.ext === 'csv' || type.ext === 'txt')) table = parseCsv(buffer.toString('utf8'), MAX_IMPORT + 1);
    else throw E.bad('Upload a .csv or .xlsx file.');
    if (table.length < 2) throw E.bad('The file has no data rows.');
    if (table.length - 1 > MAX_IMPORT) throw E.bad(`Import at most ${MAX_IMPORT} questions per file.`);
    const header = table[0].map((h) => HEAD[n(h)] || null);
    const missing = ['subject', 'question', 'answer'].filter((f) => !header.includes(f));
    if (missing.length) throw E.bad(`Missing required column(s): ${missing.join(', ')}. Download the template to see the layout.`);
    const rows = table.slice(1).map((r) => { const o = {}; header.forEach((k, i) => { if (k) o[k] = r[i] !== undefined ? String(r[i]) : ''; }); return o; }).filter((o) => Object.values(o).some((v) => String(v).trim()));
    return withTx(ctx(req), async (c) => {
      const { valid, errors } = await validateImport(c, rows);
      const imp = (await c.query(`INSERT INTO imports (school_id, kind, file_name, total_rows, valid_rows, errors, rows, created_by) VALUES ($1,'cbt_questions',$2,$3,$4,$5,$6,$7) RETURNING id`,
        [req.auth.schoolId, String(data.filename).slice(0, 120), rows.length, valid.length, JSON.stringify(errors), JSON.stringify(valid), req.auth.userId])).rows[0];
      await audit(c, req, 'data.import_previewed', { type: 'import', id: imp.id, meta: { kind: 'cbt_questions', total: rows.length, valid: valid.length, errors: errors.length } });
      return { importId: imp.id, totalRows: rows.length, validRows: valid.length, errorCount: errors.length, errors: errors.slice(0, 300),
        sample: valid.slice(0, 10).map((x) => ({ row: x.n, type: x.type, question: x.text, topic: x.topic, difficulty: x.difficulty, marks: x.marks })) };
    });
  });
  app.post('/cbt/bank/import/:id/commit', { onRequest: [A, app.perm('cbt.create')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const imp = (await c.query("SELECT * FROM imports WHERE id = $1 AND kind = 'cbt_questions' FOR UPDATE", [req.params.id])).rows[0];
    if (!imp || imp.created_by !== req.auth.userId) throw E.notFound('Import');
    if (imp.status !== 'previewed') throw E.conflict('This import was already processed.');
    if (Date.now() - new Date(imp.created_at).getTime() > 60 * 60000) { await c.query("UPDATE imports SET status = 'expired' WHERE id = $1", [imp.id]); throw E.bad('This preview has expired. Upload the file again.'); }
    if (!imp.valid_rows) throw E.bad('There are no valid rows to import.');
    let count = 0; const ids = [];
    for (const q of imp.rows) { ids.push(await Q.insertQuestion(c, req.auth.schoolId, req.auth.userId, null, q, 0)); count++; }
    const waiting = await holdForReview(c, req, ids);
    await c.query("UPDATE imports SET status = 'committed', committed_at = now(), summary = $2 WHERE id = $1", [imp.id, { imported: count }]);
    await audit(c, req, 'cbt.questions_imported', { type: 'import', id: imp.id, meta: { imported: count, skippedInvalid: imp.total_rows - imp.valid_rows } });
    return { ok: true, imported: count, skipped: imp.total_rows - imp.valid_rows, waitingForApproval: waiting };
  }));
  app.get('/cbt/bank/:id', { onRequest: [A, app.perm('cbt.view')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => bankQuestion(c, req, req.params.id)));
  app.post('/cbt/bank', { onRequest: [A, app.perm('cbt.create')], schema: { body: Q.questionBody } }, async (req) => withTx(ctx(req), async (c) => {
    const id = await Q.insertQuestion(c, req.auth.schoolId, req.auth.userId, null, req.body, 0);
    const waiting = await holdForReview(c, req, [id]);
    await audit(c, req, 'cbt.bank_question_added', { type: 'cbt_question', id, meta: { type: req.body.type, waitingForApproval: waiting } });
    return { id, status: waiting ? 'pending' : 'active' };
  }));
  app.patch('/cbt/bank/:id', { onRequest: [A, app.perm('cbt.update', 'cbt.create')], schema: { params: idParams, body: Q.questionBody } }, async (req) => withTx(ctx(req), async (c) => {
    await bankQuestion(c, req, req.params.id, { forEdit: true });
    await Q.updateQuestion(c, req.auth.schoolId, req.auth.userId, req.params.id, req.body);
    const was = (await c.query('SELECT status FROM cbt_questions WHERE id = $1', [req.params.id])).rows[0].status;
    if (was === 'rejected' || (was === 'active' && await mustWait(c, req))) await holdForReview(c, req, [req.params.id]);   // changed ⇒ checked again
    await audit(c, req, 'cbt.question_edited', { type: 'cbt_question', id: req.params.id, meta: { bank: true } });
    return { ok: true };
  }));
  app.post('/cbt/bank/:id/duplicate', { onRequest: [A, app.perm('cbt.create')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const q = await bankQuestion(c, req, req.params.id);
    const b = Q.toBody(q); b.text = q.text.length <= 3990 ? `${q.text} (copy)` : q.text;
    const id = await Q.insertQuestion(c, req.auth.schoolId, req.auth.userId, null, b, 0);
    await holdForReview(c, req, [id]);
    await audit(c, req, 'cbt.bank_question_added', { type: 'cbt_question', id, meta: { duplicateOf: q.id } });
    return { id };
  }));
  app.post('/cbt/bank/:id/archive', { onRequest: [A, app.perm('cbt.update', 'cbt.create')], schema: { params: idParams, body: obj({ archived: { type: 'boolean' } }, ['archived']) } }, async (req) => withTx(ctx(req), async (c) => {
    await bankQuestion(c, req, req.params.id, { forEdit: true });
    // restoring never skips the approval step
    const to = req.body.archived ? 'archived' : ((await mustWait(c, req)) ? 'pending' : 'active');
    await c.query('UPDATE cbt_questions SET status = $2, updated_by = $3 WHERE id = $1', [req.params.id, to, req.auth.userId]);
    await audit(c, req, req.body.archived ? 'cbt.question_archived' : 'cbt.question_restored', { type: 'cbt_question', id: req.params.id });
    return { ok: true };
  }));
  app.delete('/cbt/bank/:id', { onRequest: [A, app.perm('cbt.update', 'cbt.create')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    await bankQuestion(c, req, req.params.id, { forEdit: true });
    await c.query('DELETE FROM cbt_questions WHERE id = $1 AND exam_id IS NULL', [req.params.id]);       // exams keep their own frozen copies
    await audit(c, req, 'cbt.question_deleted', { type: 'cbt_question', id: req.params.id, meta: { bank: true } });
    return { ok: true };
  }));

  // ── questions from teachers: the exam officer approves (→ bank) or sends back with a note ──
  app.get('/cbt/bank/review', { onRequest: [A, app.perm('cbt.publish')] }, async (req) => withTx(ctx(req), async (c) => {
    const items = await Q.loadQuestions(c, "q.exam_id IS NULL AND q.status = 'pending' ORDER BY q.created_at, q.id LIMIT 200", []);
    for (const it of items) it.submitted_by = it.created_by_name || null;
    const counts = (await c.query(`SELECT count(*) FILTER (WHERE status = 'pending')::int AS pending, count(*) FILTER (WHERE status = 'rejected')::int AS rejected
      FROM cbt_questions WHERE exam_id IS NULL`)).rows[0];
    return { items, counts, approvalOn: await bankApproval(c) };
  }));
  app.post('/cbt/bank/:id/review', { onRequest: [A, app.perm('cbt.publish')], schema: { params: idParams, body: obj({ approve: { type: 'boolean' }, note: { type: ['string', 'null'], maxLength: 300 } }, ['approve']) } }, async (req) => withTx(ctx(req), async (c) => {
    const q = (await c.query('SELECT id, status, created_by, text FROM cbt_questions WHERE id = $1 AND exam_id IS NULL FOR UPDATE', [req.params.id])).rows[0];
    if (!q) throw E.notFound('Question');
    if (q.status !== 'pending') throw E.conflict('This question is not waiting for approval.');
    if (q.created_by === req.auth.userId) throw E.forbidden('Another exam officer must check questions you wrote yourself.');
    const note = (req.body.note || '').trim() || null;
    if (!req.body.approve && !note) throw E.bad('Say what the teacher should fix.', { field: 'note' });
    await c.query('UPDATE cbt_questions SET status = $2, reviewed_by = $3, reviewed_at = now(), review_note = $4, updated_by = $3 WHERE id = $1',
      [q.id, req.body.approve ? 'active' : 'rejected', req.auth.userId, note]);
    await audit(c, req, req.body.approve ? 'cbt.question_approved' : 'cbt.question_sent_back', { type: 'cbt_question', id: q.id, meta: { note } });
    if (q.created_by) await notify(c, req.auth.schoolId, [q.created_by], { kind: 'cbt', title: req.body.approve ? 'Your question was added to the question bank' : 'Your question was sent back',
      body: `${String(q.text).slice(0, 120)}${note ? ` — ${note}` : ''}`, link: req.body.approve ? '#/cbt/bank' : '#/cbt/bank?status=rejected' });
    return { ok: true, status: req.body.approve ? 'active' : 'rejected' };
  }));

  // ── dashboard ──
  app.get('/cbt/dashboard', { onRequest: [A, app.perm('cbt.view')] }, async (req) => withTx(ctx(req), async (c) => {
    const p = []; const sc = scopeSql(req, p);
    const exams = (await c.query(`SELECT e.id, e.title, e.status, e.starts_at, e.ends_at, e.duration_minutes, e.created_at, s.name AS subject, cl.display_name AS class_name,
        COALESCE(NULLIF((SELECT count(*)::int FROM cbt_exam_candidates x WHERE x.exam_id = e.id), 0),
          (SELECT count(*)::int FROM student_enrollments en JOIN academic_sessions se ON se.id = en.session_id AND se.is_current WHERE en.class_id = e.class_id AND en.status = 'active')) AS candidates,
        (SELECT count(*)::int FROM cbt_attempts a WHERE a.exam_id = e.id AND a.status <> 'void') AS attempts
      FROM cbt_exams e LEFT JOIN subjects s ON s.id = e.subject_id LEFT JOIN classes cl ON cl.id = e.class_id WHERE ${sc} ORDER BY COALESCE(e.starts_at, e.created_at) DESC LIMIT 1000`, p)).rows;
    for (const e of exams) e.lifecycle = lifecycle(e);
    const count = (k) => exams.filter((e) => e.lifecycle === k).length;
    const ids = exams.map((e) => e.id);
    const res = (await c.query(`SELECT count(*)::int AS n, round(avg(r.percentage), 1) AS avg, count(*) FILTER (WHERE r.passed)::int AS passed, count(DISTINCT r.student_id)::int AS students
      FROM cbt_results r JOIN cbt_attempts a ON a.id = r.attempt_id AND a.status <> 'void' WHERE r.exam_id = ANY($1::uuid[])`, [ids])).rows[0];
    const cands = (await c.query(`SELECT count(DISTINCT sid)::int AS n FROM (SELECT student_id AS sid FROM cbt_exam_candidates WHERE exam_id = ANY($1::uuid[]) UNION SELECT student_id FROM cbt_attempts WHERE exam_id = ANY($1::uuid[])) x`, [ids])).rows[0].n;
    const questions = (await c.query("SELECT count(*)::int AS n FROM cbt_questions WHERE exam_id IS NULL AND status = 'active'")).rows[0].n;
    const now = Date.now();
    return {
      cards: { total: exams.length, draft: count('draft'), scheduled: count('scheduled'), active: count('active'), completed: count('completed'), questions, candidates: Math.max(cands, 0),
        averageScore: res.avg === null ? null : Number(res.avg), passRate: res.n ? Math.round(res.passed / res.n * 1000) / 10 : null, results: res.n },
      recent: exams.slice(0, 8),
      upcoming: exams.filter((e) => e.lifecycle === 'scheduled' || (e.lifecycle === 'active' && e.ends_at && new Date(e.ends_at).getTime() > now)).sort((a, b) => new Date(a.starts_at || 0) - new Date(b.starts_at || 0)).slice(0, 8),
    };
  }));

  // ── examination analytics ──
  app.get('/cbt/exams/:id/analytics', { onRequest: [A, app.perm('cbt.results')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const e = await loadExam(c, req, req.params.id);
    const bands = await bandsForExam(c, e);
    const counted = await countedResults(c, e);
    const pcts = counted.map((r) => Number(r.percentage));
    const attemptIds = counted.map((r) => r.attempt_id);
    const times = counted.filter((r) => r.submitted_at).map((r) => (new Date(r.submitted_at) - new Date(r.started_at)) / 1000);
    const perQ = (await c.query(`SELECT q.id, q.position, q.text, q.type, q.topic, q.difficulty, q.marks,
        count(an.question_id) FILTER (WHERE an.option_id IS NOT NULL OR array_length(an.option_ids, 1) > 0 OR NULLIF(trim(an.text_answer), '') IS NOT NULL)::int AS answered,
        count(*) FILTER (WHERE an.is_correct)::int AS correct, count(*) FILTER (WHERE an.is_correct = false)::int AS incorrect,
        round(avg(NULLIF(an.time_spent_seconds, 0)))::int AS avg_seconds, round(avg(an.marks_awarded), 2) AS avg_marks
      FROM cbt_questions q LEFT JOIN cbt_answers an ON an.question_id = q.id AND an.attempt_id = ANY($2::uuid[])
      WHERE q.exam_id = $1 GROUP BY q.id ORDER BY q.position, q.created_at`, [e.id, attemptIds])).rows;
    const total = counted.length;
    for (const q of perQ) {
      q.number = perQ.indexOf(q) + 1; q.unanswered = Math.max(0, total - q.answered);
      q.correct_rate = total ? round1(q.correct / total * 100) : null; q.incorrect_rate = total ? round1((total - q.correct) / total * 100) : null;
    }
    const auto = perQ.filter((q) => q.correct_rate !== null && !(q.type === 'theory'));
    const topics = {};
    for (const q of auto) { const k = q.topic || 'General'; topics[k] = topics[k] || { topic: k, questions: 0, correct: 0, total: 0 }; topics[k].questions++; topics[k].correct += q.correct; topics[k].total += total; }
    const grades = {}; for (const pct of pcts) { const g = G.gradeFor(pct, bands).grade; grades[g] = (grades[g] || 0) + 1; }
    const buckets = Array.from({ length: 10 }, (_, i) => ({ label: i === 9 ? '90–100' : `${i * 10}–${i * 10 + 9}`, value: pcts.filter((x) => Math.min(9, Math.floor(x / 10)) === i).length }));
    return {
      exam: { id: e.id, title: e.title, passMark: Number(e.pass_mark) },
      summary: { attempts: (await c.query("SELECT count(*)::int AS n FROM cbt_attempts WHERE exam_id = $1 AND status <> 'void'", [e.id])).rows[0].n, candidatesWithResults: total,
        average: pcts.length ? round1(pcts.reduce((a, b) => a + b, 0) / pcts.length) : null, highest: pcts.length ? Math.max(...pcts) : null, lowest: pcts.length ? Math.min(...pcts) : null,
        passRate: total ? round1(counted.filter((r) => r.passed).length / total * 100) : null, averageMinutes: times.length ? round1(times.reduce((a, b) => a + b, 0) / times.length / 60) : null },
      questions: perQ,
      mostMissed: [...auto].sort((a, b) => a.correct_rate - b.correct_rate).slice(0, 5),
      easiest: [...auto].sort((a, b) => b.correct_rate - a.correct_rate).slice(0, 5),
      topics: Object.values(topics).map((t) => ({ ...t, rate: t.total ? round1(t.correct / t.total * 100) : null })).sort((a, b) => a.rate - b.rate),
      grades: Object.entries(grades).map(([grade, count]) => ({ grade, count })).sort((a, b) => a.grade.localeCompare(b.grade)), distribution: buckets,
    };
  }));

  // ── class / subject / term performance across CBT exams ──
  app.get('/cbt/analytics', {
    onRequest: [A, app.perm('cbt.results')],
    schema: { querystring: obj({ classId: uuid, subjectId: uuid, termId: uuid, sessionId: uuid, examId: uuid }) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const p = []; const w = [scopeSql(req, p), "e.status <> 'draft'"]; const q = req.query;
    for (const [k, col] of [['classId', 'class_id'], ['subjectId', 'subject_id'], ['termId', 'term_id'], ['examId', 'id']]) if (q[k]) { p.push(q[k]); w.push(`e.${col} = $${p.length}`); }
    if (q.sessionId) { p.push(q.sessionId); w.push(`(e.session_id = $${p.length} OR e.term_id IN (SELECT id FROM terms WHERE session_id = $${p.length}))`); }
    const exams = (await c.query(`SELECT e.*, s.name AS subject, cl.display_name AS class_name FROM cbt_exams e LEFT JOIN subjects s ON s.id = e.subject_id LEFT JOIN classes cl ON cl.id = e.class_id
      WHERE ${w.join(' AND ')} ORDER BY COALESCE(e.starts_at, e.created_at) DESC LIMIT 200`, p)).rows;
    const perExam = []; const perStudent = new Map(); const topics = {}; const grades = {}; let all = [];
    const bandsCache = new Map();
    for (const e of exams) {
      const counted = await countedResults(c, e);
      const pcts = counted.map((r) => Number(r.percentage)); all = all.concat(pcts);
      const key = e.class_id || 'none'; if (!bandsCache.has(key)) bandsCache.set(key, await bandsForExam(c, e));
      for (const pct of pcts) { const g = G.gradeFor(pct, bandsCache.get(key)).grade; grades[g] = (grades[g] || 0) + 1; }
      perExam.push({ id: e.id, title: e.title, subject: e.subject, className: e.class_name, lifecycle: lifecycle(e), candidates: counted.length,
        average: pcts.length ? round1(pcts.reduce((a, b) => a + b, 0) / pcts.length) : null, passRate: counted.length ? round1(counted.filter((r) => r.passed).length / counted.length * 100) : null,
        highest: pcts.length ? Math.max(...pcts) : null, lowest: pcts.length ? Math.min(...pcts) : null });
      for (const r of counted) { const s = perStudent.get(r.student_id) || { studentId: r.student_id, exams: 0, sum: 0 }; s.exams++; s.sum += Number(r.percentage); perStudent.set(r.student_id, s); }
      const tq = (await c.query(`SELECT COALESCE(q.topic, 'General') AS topic, count(an.*) FILTER (WHERE an.is_correct)::int AS correct, count(an.*)::int AS answered
        FROM cbt_questions q JOIN cbt_answers an ON an.question_id = q.id AND an.attempt_id = ANY($2::uuid[]) WHERE q.exam_id = $1 AND q.type <> 'theory' GROUP BY 1`, [e.id, counted.map((r) => r.attempt_id)])).rows;
      for (const t of tq) { topics[t.topic] = topics[t.topic] || { topic: t.topic, correct: 0, answered: 0 }; topics[t.topic].correct += t.correct; topics[t.topic].answered += t.answered; }
    }
    const names = new Map((await c.query('SELECT id, first_name, last_name, admission_no FROM students WHERE id = ANY($1::uuid[])', [[...perStudent.keys()]])).rows.map((s) => [s.id, s]));
    const students = [...perStudent.values()].map((s) => { const st = names.get(s.studentId) || {}; return { studentId: s.studentId, name: `${st.last_name || ''} ${st.first_name || ''}`.trim(), admissionNo: st.admission_no, exams: s.exams, average: round1(s.sum / s.exams) }; })
      .sort((a, b) => b.average - a.average);
    return {
      summary: { exams: exams.length, results: all.length, average: all.length ? round1(all.reduce((a, b) => a + b, 0) / all.length) : null, highest: all.length ? Math.max(...all) : null, lowest: all.length ? Math.min(...all) : null,
        passRate: all.length ? round1(perExam.reduce((t, x) => t + (x.passRate || 0) * x.candidates, 0) / all.length) : null },
      exams: perExam, students: students.slice(0, 200),
      grades: Object.entries(grades).map(([grade, count]) => ({ grade, count })).sort((a, b) => a.grade.localeCompare(b.grade)),
      topics: Object.values(topics).map((t) => ({ ...t, rate: t.answered ? round1(t.correct / t.answered * 100) : null })).sort((a, b) => (a.rate ?? 0) - (b.rate ?? 0)),
    };
  }));

  // ── school CBT defaults ──
  const settingsBody = obj({ durationMinutes: { type: 'integer', minimum: 1, maximum: 600 }, passMark: { type: 'number', minimum: 0, maximum: 100 }, maxAttempts: { type: 'integer', minimum: 1, maximum: 20 },
    shuffleQuestions: { type: 'boolean' }, shuffleOptions: { type: 'boolean' }, showResult: { type: 'boolean' }, showAnswers: { type: 'boolean' }, allowBackNav: { type: 'boolean' },
    allowReview: { type: 'boolean' }, allowResume: { type: 'boolean' }, fullscreen: { type: 'boolean' }, autosave: { type: 'boolean' }, bankApproval: { type: 'boolean' }, scoreComponent: { type: ['string', 'null'], pattern: '^[a-z0-9_]{1,20}$' }, scorePolicy: { enum: ['best', 'latest'] } });
  app.get('/cbt/settings', { onRequest: [A, app.perm('cbt.view')] }, async (req) => withTx(ctx(req), async (c) => {
    const r = (await c.query('SELECT cbt FROM school_settings LIMIT 1')).rows[0];
    const comps = (await c.query('SELECT key, label, max_score AS max, is_exam FROM assessment_components WHERE active ORDER BY position, key')).rows;
    return { settings: (r && r.cbt) || {}, components: comps };
  }));
  app.put('/cbt/settings', { onRequest: [A, app.perm('settings.update', 'cbt.publish')], schema: { body: settingsBody } }, async (req) => withTx(ctx(req), async (c) => {
    if (req.body.scoreComponent && !(await c.query('SELECT 1 FROM assessment_components WHERE active AND key = $1', [req.body.scoreComponent])).rowCount) throw E.bad('That assessment component does not exist.', { field: 'scoreComponent' });
    const r = (await c.query('UPDATE school_settings SET cbt = cbt || $2::jsonb WHERE school_id = $1 RETURNING cbt', [req.auth.schoolId, JSON.stringify(req.body)])).rows[0];
    await audit(c, req, 'cbt.settings_updated', { type: 'school_settings', id: req.auth.schoolId, meta: { fields: Object.keys(req.body) } });
    return { settings: r.cbt };
  }));
  void str;
};
