'use strict';
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, str, optStr, uuid, date, idParams } = require('../lib/schema');
const { ctx } = require('../auth/plugin');
const { audit } = require('../audit/audit');

const CLASS_PRESETS = [
  { name: 'Creche', section: 'nursery', level: 'Creche' }, { name: 'Nursery 1', section: 'nursery', level: 'Nursery' }, { name: 'Nursery 2', section: 'nursery', level: 'Nursery' },
  { name: 'Kindergarten', section: 'nursery', level: 'Kindergarten' },
  ...[1, 2, 3, 4, 5, 6].map((n) => ({ name: `Primary ${n}`, section: 'primary', level: 'Primary' })),
  ...[1, 2, 3].map((n) => ({ name: `JSS ${n}`, section: 'secondary', level: 'JSS' })),
  ...[1, 2, 3].map((n) => ({ name: `SS ${n}`, section: 'secondary', level: 'SS' })),
];

module.exports = async function academicRoutes(app) {
  const A = app.authenticate;
  const VIEW = app.perm('academic.view', 'timetable.view_own');
  const MANAGE = app.perm('academic.manage');

  // ── overview (sessions+terms+classes+subjects in one call; small per-school datasets) ──
  app.get('/academic', { onRequest: [A, VIEW] }, async (req) => withTx(ctx(req), async (c) => {
    const sessions = (await c.query(`SELECT s.id, s.name, s.starts_on, s.ends_on, s.is_current,
      COALESCE((SELECT json_agg(json_build_object('id', t.id, 'name', t.name, 'is_current', t.is_current, 'starts_on', t.starts_on, 'ends_on', t.ends_on, 'days_open', t.days_open, 'next_term_begins', t.next_term_begins) ORDER BY t.name) FROM terms t WHERE t.session_id = s.id), '[]') AS terms
      FROM academic_sessions s ORDER BY s.name DESC`)).rows;
    const classes = (await c.query(`SELECT c.id, c.name, c.arm, c.display_name, c.section, c.capacity, c.form_teacher_id, st.full_name AS form_teacher, c.sort_order, c.branch_id, c.active, c.level,
      (SELECT count(*)::int FROM student_enrollments e JOIN academic_sessions s ON s.id = e.session_id AND s.is_current WHERE e.class_id = c.id AND e.status = 'active') AS students
      FROM classes c LEFT JOIN staff st ON st.id = c.form_teacher_id ORDER BY c.active DESC, c.sort_order, c.name, c.arm`)).rows;
    const subjects = (await c.query('SELECT id, name, code FROM subjects ORDER BY name')).rows;
    return { sessions, classes, subjects };
  }));

  app.post('/academic/sessions', { onRequest: [A, MANAGE], schema: { body: obj({ name: { type: 'string', pattern: '^[0-9]{4}/[0-9]{4}$' }, startsOn: date, endsOn: date, isCurrent: { type: 'boolean' }, createTerms: { type: 'boolean', default: true } }, ['name']) } }, async (req) =>
    withTx(ctx(req), async (c) => {
      const [y1, y2] = req.body.name.split('/').map(Number);
      if (y2 !== y1 + 1) throw E.bad('Session must span consecutive years, e.g. 2025/2026.');
      if (req.body.isCurrent) await c.query('UPDATE academic_sessions SET is_current = false WHERE is_current');
      const s = (await c.query('INSERT INTO academic_sessions (school_id, name, starts_on, ends_on, is_current) VALUES ($1,$2,$3,$4,$5) RETURNING *',
        [req.auth.schoolId, req.body.name, req.body.startsOn || null, req.body.endsOn || null, !!req.body.isCurrent])).rows[0];
      if (req.body.createTerms) for (const t of ['1ST', '2ND', '3RD']) await c.query('INSERT INTO terms (school_id, session_id, name) VALUES ($1,$2,$3)', [req.auth.schoolId, s.id, t]);
      await audit(c, req, 'academic.session_created', { type: 'academic_session', id: s.id, meta: { name: s.name } });
      return s;
    }));

  app.post('/academic/sessions/:id/current', { onRequest: [A, MANAGE], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    await c.query('UPDATE academic_sessions SET is_current = false WHERE is_current');
    const r = await c.query('UPDATE academic_sessions SET is_current = true WHERE id = $1 RETURNING id', [req.params.id]);
    if (!r.rowCount) throw E.notFound('Session');
    await audit(c, req, 'academic.session_set_current', { type: 'academic_session', id: req.params.id });
    return { ok: true };
  }));

  app.patch('/academic/terms/:id', {
    onRequest: [A, MANAGE],
    schema: { params: idParams, body: obj({ startsOn: date, endsOn: date, daysOpen: { type: ['integer', 'null'], minimum: 0, maximum: 366 }, nextTermBegins: date, isCurrent: { type: 'boolean' } }) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const b = req.body;
    if (b.isCurrent) {
      const t = (await c.query('SELECT session_id FROM terms WHERE id = $1', [req.params.id])).rows[0];
      if (!t) throw E.notFound('Term');
      await c.query('UPDATE terms SET is_current = false WHERE is_current');
      await c.query('UPDATE academic_sessions SET is_current = (id = $1)', [t.session_id]);
    }
    const r = await c.query(`UPDATE terms SET starts_on = CASE WHEN $2 THEN $3::date ELSE starts_on END, ends_on = CASE WHEN $4 THEN $5::date ELSE ends_on END,
      days_open = CASE WHEN $6 THEN $7::int ELSE days_open END, next_term_begins = CASE WHEN $8 THEN $9::date ELSE next_term_begins END,
      is_current = COALESCE($10, is_current) WHERE id = $1 RETURNING *`,
    [req.params.id, b.startsOn !== undefined, b.startsOn || null, b.endsOn !== undefined, b.endsOn || null, b.daysOpen !== undefined, b.daysOpen ?? null,
      b.nextTermBegins !== undefined, b.nextTermBegins || null, b.isCurrent ?? null]);
    if (!r.rowCount) throw E.notFound('Term');
    await audit(c, req, 'academic.term_updated', { type: 'term', id: req.params.id, meta: { fields: Object.keys(b) } });
    return r.rows[0];
  }));

  // ── classes & arms (BASIC 1A, BASIC 1B …) ──
  const classBody = obj({ name: str(40, 1), arm: { type: 'string', pattern: '^[A-Za-z0-9 ]{0,12}$' }, arms: { type: 'array', items: { type: 'string', pattern: '^[A-Za-z0-9 ]{1,12}$' }, maxItems: 12 },
    section: { enum: ['nursery', 'primary', 'secondary'] }, level: { type: ['string', 'null'], minLength: 1, maxLength: 40 }, active: { type: 'boolean' }, capacity: { type: ['integer', 'null'], minimum: 1, maximum: 500 }, formTeacherId: { type: ['string', 'null'], format: 'uuid' }, sortOrder: { type: 'integer', minimum: 0, maximum: 1000 }, branchId: { type: ['string', 'null'], format: 'uuid' } });
  app.post('/academic/classes', { onRequest: [A, MANAGE], schema: { body: { ...classBody, required: ['name', 'section'] } } }, async (req) => withTx(ctx(req), async (c) => {
    const b = req.body; const arms = b.arms && b.arms.length ? b.arms : [b.arm || ''];
    const out = [];
    for (const arm of arms) {
      const order = b.sortOrder ?? (await c.query('SELECT COALESCE(max(sort_order), 0) + 10 AS n FROM classes')).rows[0].n;   // new classes go to the end
      const r = await c.query(`INSERT INTO classes (school_id, name, arm, section, capacity, form_teacher_id, sort_order, branch_id, level) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id, display_name`,
        [req.auth.schoolId, b.name.trim().toUpperCase(), arm.trim().toUpperCase(), b.section, b.capacity || null, b.formTeacherId || null, order, req.auth.branchId || b.branchId || null, b.level || null]);
      if (arm.trim()) { const st = (await c.query('INSERT INTO streams (school_id, name) VALUES ($1,$2) ON CONFLICT (school_id, name) DO UPDATE SET name = EXCLUDED.name RETURNING id', [req.auth.schoolId, arm.trim().toUpperCase()])).rows[0]; await c.query('UPDATE classes SET stream_id = $2 WHERE id = $1', [r.rows[0].id, st.id]); }
      out.push(r.rows[0]);
    }
    await audit(c, req, 'academic.classes_created', { type: 'class', id: out.map((x) => x.id).join(','), meta: { classes: out.map((x) => x.display_name) } });
    return { items: out };
  }));
  // rename / change section, level, form teacher, order — or switch a class off / on. Every record points at the class
  // by its id, so a new name shows at once on registers, score sheets, broadsheets, report cards and old results.
  app.patch('/academic/classes/:id', { onRequest: [A, MANAGE], schema: { params: idParams, body: classBody } }, async (req) => withTx(ctx(req), async (c) => {
    const b = req.body;
    const cur = (await c.query('SELECT id, name, arm, active FROM classes WHERE id = $1', [req.params.id])).rows[0];
    if (!cur) throw E.notFound('Class');
    if (b.name || b.arm !== undefined) {
      const nn = b.name ? b.name.trim().toUpperCase() : cur.name; const na = b.arm !== undefined ? b.arm.trim().toUpperCase() : cur.arm;
      if ((await c.query('SELECT 1 FROM classes WHERE lower(name) = lower($1) AND lower(arm) = lower($2) AND id <> $3', [nn, na, cur.id])).rowCount) throw E.conflict(`There is already a class called ${(nn + na).trim()}.`);
    }
    if (b.active === false && cur.active) {
      const n = (await c.query(`SELECT count(*)::int AS n FROM student_enrollments e JOIN academic_sessions s ON s.id = e.session_id AND s.is_current WHERE e.class_id = $1 AND e.status = 'active'`, [cur.id])).rows[0].n;
      if (n) throw E.conflict(`${n} pupil(s) are in this class this session. Move them to another class first (Students › Promotion, or edit each pupil), then switch the class off. Nothing is deleted.`);
    }
    const r = await c.query(`UPDATE classes SET name = COALESCE($2, name), arm = COALESCE($3, arm), section = COALESCE($4, section), capacity = CASE WHEN $5 THEN $6::int ELSE capacity END,
      form_teacher_id = CASE WHEN $7 THEN $8::uuid ELSE form_teacher_id END, sort_order = COALESCE($9, sort_order),
      level = CASE WHEN $10 THEN $11 ELSE level END, active = COALESCE($12, active),
      deactivated_at = CASE WHEN $12 IS NULL THEN deactivated_at WHEN $12 THEN NULL ELSE COALESCE(deactivated_at, now()) END
      WHERE id = $1 RETURNING id, display_name, active`,
    [req.params.id, b.name ? b.name.trim().toUpperCase() : null, b.arm !== undefined ? b.arm.trim().toUpperCase() : null, b.section || null, b.capacity !== undefined, b.capacity ?? null,
      b.formTeacherId !== undefined, b.formTeacherId || null, b.sortOrder ?? null, b.level !== undefined, b.level || null, b.active ?? null]);
    await audit(c, req, 'academic.class_updated', { type: 'class', id: req.params.id, meta: { fields: Object.keys(b) } });
    return r.rows[0];
  }));
  // drag-free reordering: the full list of class ids in the wanted order
  app.put('/academic/classes/order', { onRequest: [A, MANAGE], schema: { body: obj({ ids: { type: 'array', items: uuid, minItems: 1, maxItems: 500, uniqueItems: true } }, ['ids']) } }, async (req) => withTx(ctx(req), async (c) => {
    const known = (await c.query('SELECT id FROM classes WHERE id = ANY($1::uuid[])', [req.body.ids])).rowCount;
    if (known !== req.body.ids.length) throw E.notFound('Class');
    await c.query('UPDATE classes c SET sort_order = x.ord * 10 FROM unnest($1::uuid[]) WITH ORDINALITY AS x(id, ord) WHERE c.id = x.id', [req.body.ids]);
    await audit(c, req, 'academic.classes_reordered', { type: 'class', id: 'order', meta: { count: req.body.ids.length } });
    return { ok: true };
  }));

  // standard Nigerian class list; a school ticks what it runs (and can still add its own classes and levels)
  app.get('/academic/class-presets', { onRequest: [A, VIEW] }, async () => ({ items: CLASS_PRESETS }));
  app.post('/academic/classes/presets', {
    onRequest: [A, MANAGE],
    schema: { body: obj({ names: { type: 'array', items: str(40, 1), minItems: 1, maxItems: 40, uniqueItems: true }, arms: { type: 'array', items: { type: 'string', pattern: '^[A-Za-z0-9 ]{1,12}$' }, maxItems: 8 } }, ['names']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const picks = req.body.names.map((n) => CLASS_PRESETS.find((p) => p.name.toLowerCase() === n.toLowerCase()));
    if (picks.some((p) => !p)) throw E.bad('Unknown standard class. Use “Add class” for your own class names.');
    const arms = req.body.arms && req.body.arms.length ? req.body.arms.map((a) => a.trim().toUpperCase()) : [''];
    let order = (await c.query('SELECT COALESCE(max(sort_order), 0) AS n FROM classes')).rows[0].n;
    const made = []; const skipped = [];
    for (const p of picks.sort((x, y) => CLASS_PRESETS.indexOf(x) - CLASS_PRESETS.indexOf(y))) {
      for (const arm of arms) {
        const name = p.name.toUpperCase();
        if ((await c.query('SELECT 1 FROM classes WHERE lower(name) = lower($1) AND lower(arm) = lower($2)', [name, arm])).rowCount) { skipped.push((name + arm).trim()); continue; }
        order += 10;
        const r = (await c.query('INSERT INTO classes (school_id, name, arm, section, level, sort_order, branch_id) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id, display_name',
          [req.auth.schoolId, name, arm, p.section, p.level, order, req.auth.branchId || null])).rows[0];
        made.push(r);
      }
    }
    await audit(c, req, 'academic.classes_created', { type: 'class', id: made.map((x) => x.id).join(',') || 'none', meta: { preset: true, classes: made.map((x) => x.display_name), skipped } });
    return { items: made, skipped };
  }));

  app.delete('/academic/classes/:id', { onRequest: [A, MANAGE], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const n = (await c.query('SELECT count(*)::int AS n FROM student_enrollments WHERE class_id = $1', [req.params.id])).rows[0].n;
    if (n) throw E.conflict('This class has enrolment history and cannot be deleted.');
    const r = await c.query('DELETE FROM classes WHERE id = $1 RETURNING display_name', [req.params.id]);
    if (!r.rowCount) throw E.notFound('Class');
    await audit(c, req, 'academic.class_deleted', { type: 'class', id: req.params.id, meta: { name: r.rows[0].display_name } });
    return { ok: true };
  }));

  // ── subjects & class-subject-teacher assignment ──
  app.post('/academic/subjects', { onRequest: [A, MANAGE], schema: { body: obj({ names: { type: 'array', items: str(80, 2), minItems: 1, maxItems: 60 }, code: optStr(20) }, ['names']) } }, async (req) => withTx(ctx(req), async (c) => {
    const out = [];
    for (const n of req.body.names) {
      const r = await c.query(`INSERT INTO subjects (school_id, name, code) VALUES ($1,$2,$3) ON CONFLICT (school_id, lower(name)) DO NOTHING RETURNING id, name`, [req.auth.schoolId, n.trim(), req.body.code || null]);
      if (r.rowCount) out.push(r.rows[0]);
    }
    await audit(c, req, 'academic.subjects_created', { type: 'subject', meta: { names: out.map((x) => x.name) } });
    return { items: out };
  }));
  app.delete('/academic/subjects/:id', { onRequest: [A, MANAGE], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const n = (await c.query('SELECT count(*)::int AS n FROM assessments WHERE subject_id = $1', [req.params.id])).rows[0].n;
    if (n) throw E.conflict('This subject has results and cannot be deleted.');
    const r = await c.query('DELETE FROM subjects WHERE id = $1 RETURNING name', [req.params.id]);
    if (!r.rowCount) throw E.notFound('Subject');
    await audit(c, req, 'academic.subject_deleted', { type: 'subject', id: req.params.id, meta: { name: r.rows[0].name } });
    return { ok: true };
  }));

  const classExists = async (c, id) => { if (!(await c.query('SELECT 1 FROM classes WHERE id = $1', [id])).rowCount) throw E.notFound('Class'); };
  app.get('/academic/classes/:id/subjects', { onRequest: [A, VIEW], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => ({
    items: (await classExists(c, req.params.id), await c.query(`SELECT cs.id, cs.subject_id, s.name AS subject, cs.teacher_id, st.full_name AS teacher FROM class_subjects cs
      JOIN subjects s ON s.id = cs.subject_id LEFT JOIN staff st ON st.id = cs.teacher_id WHERE cs.class_id = $1 ORDER BY s.name`, [req.params.id])).rows,
  })));
  app.put('/academic/classes/:id/subjects', {
    onRequest: [A, MANAGE],
    schema: { params: idParams, body: obj({ items: { type: 'array', maxItems: 40, items: obj({ subjectId: uuid, teacherId: { type: ['string', 'null'], format: 'uuid' } }, ['subjectId']) } }, ['items']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const cls = await c.query('SELECT id FROM classes WHERE id = $1', [req.params.id]);
    if (!cls.rowCount) throw E.notFound('Class');
    const keep = req.body.items.map((i) => i.subjectId);
    await c.query('DELETE FROM class_subjects WHERE class_id = $1 AND NOT (subject_id = ANY($2::uuid[]))', [req.params.id, keep]);
    for (const i of req.body.items) {
      await c.query(`INSERT INTO class_subjects (school_id, class_id, subject_id, teacher_id) VALUES ($1,$2,$3,$4)
        ON CONFLICT (class_id, subject_id) DO UPDATE SET teacher_id = EXCLUDED.teacher_id`, [req.auth.schoolId, req.params.id, i.subjectId, i.teacherId || null]);
    }
    await audit(c, req, 'academic.class_subjects_set', { type: 'class', id: req.params.id, meta: { subjects: keep.length } });
    return { ok: true };
  }));

  // ── timetable ──
  app.get('/academic/classes/:id/timetable', { onRequest: [A, VIEW], schema: { params: idParams } }, async (req) => {
    return withTx(ctx(req), async (c) => {
      await classExists(c, req.params.id);
      if (!req.can('academic.view')) {        // students/parents: only their own class
        const own = await c.query(`SELECT 1 FROM student_enrollments e JOIN academic_sessions s ON s.id = e.session_id AND s.is_current
          WHERE e.class_id = $1 AND e.student_id = ANY($2::uuid[])`, [req.params.id, [req.auth.studentId, ...req.auth.children].filter(Boolean)]);
        if (!own.rowCount) throw E.notFound('Class');
      }
      return { items: (await c.query(`SELECT t.id, t.day_of_week, t.period, t.starts_at, t.ends_at, t.label, t.subject_id, s.name AS subject, t.teacher_id, st.full_name AS teacher
        FROM timetable_entries t LEFT JOIN subjects s ON s.id = t.subject_id LEFT JOIN staff st ON st.id = t.teacher_id WHERE t.class_id = $1 ORDER BY t.day_of_week, t.period`, [req.params.id])).rows };
    });
  });
  app.put('/academic/classes/:id/timetable', {
    onRequest: [A, MANAGE],
    schema: { params: idParams, body: obj({ items: { type: 'array', maxItems: 80, items: obj({ dayOfWeek: { type: 'integer', minimum: 1, maximum: 7 }, period: { type: 'integer', minimum: 1, maximum: 16 },
      startsAt: { type: ['string', 'null'], pattern: '^[0-2][0-9]:[0-5][0-9]$' }, endsAt: { type: ['string', 'null'], pattern: '^[0-2][0-9]:[0-5][0-9]$' }, subjectId: { type: ['string', 'null'], format: 'uuid' },
      teacherId: { type: ['string', 'null'], format: 'uuid' }, label: optStr(60) }, ['dayOfWeek', 'period']) } }, ['items']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    await classExists(c, req.params.id);
    await c.query('DELETE FROM timetable_entries WHERE class_id = $1', [req.params.id]);
    for (const i of req.body.items) {
      await c.query(`INSERT INTO timetable_entries (school_id, class_id, day_of_week, period, starts_at, ends_at, subject_id, teacher_id, label) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
        [req.auth.schoolId, req.params.id, i.dayOfWeek, i.period, i.startsAt || null, i.endsAt || null, i.subjectId || null, i.teacherId || null, i.label || null]);
    }
    await audit(c, req, 'academic.timetable_set', { type: 'class', id: req.params.id, meta: { entries: req.body.items.length } });
    return { ok: true };
  }));

  // ── end-of-session promotion (preview → run → undo). Reads a snapshot of current enrolments; never cascades. ──
  const promoBody = obj({ fromSessionId: uuid, toSessionId: uuid, map: { type: 'array', maxItems: 200, items: obj({ fromClassId: uuid, toClassId: { type: ['string', 'null'], format: 'uuid' }, graduate: { type: 'boolean' } }, ['fromClassId']) },
    repeat: { type: 'array', items: uuid, maxItems: 5000 }, dryRun: { type: 'boolean', default: true } }, ['fromSessionId', 'toSessionId', 'map']);
  app.post('/academic/promotion', { onRequest: [A, app.perm('promotion.run')], schema: { body: promoBody } }, async (req) => withTx(ctx(req), async (c) => {
    const b = req.body;
    if (b.fromSessionId === b.toSessionId) throw E.bad('Choose a different target session.');
    const snap = (await c.query(`SELECT e.id, e.student_id, e.class_id FROM student_enrollments e JOIN students s ON s.id = e.student_id
      WHERE e.session_id = $1 AND e.status = 'active' AND s.status = 'active' AND s.deleted_at IS NULL`, [b.fromSessionId])).rows;
    const map = new Map(b.map.map((m) => [m.fromClassId, m]));
    const repeat = new Set(b.repeat || []);
    const moves = []; const summary = { promoted: 0, repeated: 0, graduated: 0, skipped: 0 };
    for (const e of snap) {
      const m = map.get(e.class_id);
      if (!m) { summary.skipped++; continue; }
      if (repeat.has(e.student_id)) { moves.push({ enrollmentId: e.id, studentId: e.student_id, action: 'repeated', toClassId: e.class_id }); summary.repeated++; continue; }
      if (m.graduate) { moves.push({ enrollmentId: e.id, studentId: e.student_id, action: 'graduated' }); summary.graduated++; continue; }
      if (!m.toClassId) { summary.skipped++; continue; }
      moves.push({ enrollmentId: e.id, studentId: e.student_id, action: 'promoted', toClassId: m.toClassId }); summary.promoted++;
    }
    if (b.dryRun) return { dryRun: true, summary };
    const clash = await c.query('SELECT count(*)::int AS n FROM student_enrollments WHERE session_id = $1 AND student_id = ANY($2::uuid[])', [b.toSessionId, moves.filter((m) => m.toClassId).map((m) => m.studentId)]);
    if (clash.rows[0].n) throw E.conflict(`${clash.rows[0].n} student(s) are already enrolled in the target session.`);
    for (const m of moves) {
      await c.query('UPDATE student_enrollments SET status = $2 WHERE id = $1', [m.enrollmentId, m.action]);
      if (m.toClassId) await c.query('INSERT INTO student_enrollments (school_id, student_id, class_id, session_id) VALUES ($1,$2,$3,$4)', [req.auth.schoolId, m.studentId, m.toClassId, b.toSessionId]);
      if (m.action === 'graduated') await c.query("UPDATE students SET status = 'graduated' WHERE id = $1", [m.studentId]);
    }
    const run = (await c.query('INSERT INTO promotion_runs (school_id, from_session, to_session, summary, moves, created_by) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id',
      [req.auth.schoolId, b.fromSessionId, b.toSessionId, summary, JSON.stringify(moves), req.auth.userId])).rows[0];
    await audit(c, req, 'academic.promotion_run', { type: 'promotion_run', id: run.id, meta: summary });
    return { dryRun: false, runId: run.id, summary };
  }));
  app.post('/academic/promotion/:id/undo', { onRequest: [A, app.perm('promotion.run')], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const run = (await c.query('SELECT * FROM promotion_runs WHERE id = $1 FOR UPDATE', [req.params.id])).rows[0];
    if (!run) throw E.notFound('Promotion run');
    if (run.undone_at) throw E.conflict('This promotion was already undone.');
    const last = (await c.query('SELECT id FROM promotion_runs WHERE undone_at IS NULL ORDER BY created_at DESC LIMIT 1')).rows[0];
    if (last.id !== run.id) throw E.conflict('Only the most recent promotion can be undone.');
    for (const m of run.moves) {
      if (m.toClassId) await c.query('DELETE FROM student_enrollments WHERE student_id = $1 AND session_id = $2', [m.studentId, run.to_session]);
      await c.query("UPDATE student_enrollments SET status = 'active' WHERE id = $1", [m.enrollmentId]);
      if (m.action === 'graduated') await c.query("UPDATE students SET status = 'active' WHERE id = $1", [m.studentId]);
    }
    await c.query('UPDATE promotion_runs SET undone_at = now() WHERE id = $1', [run.id]);
    await audit(c, req, 'academic.promotion_undone', { type: 'promotion_run', id: run.id });
    return { ok: true };
  }));
};
