'use strict';
// School store: items, stock and sales (the offline app's inventory + sales, now with server-side rules).
//   • the browser sends item + quantity only; the SERVER sets the price and the total;
//   • stock is changed only by store_moves (opening, restock, sale, sale_void, adjust) under a row lock, and it can
//     never go below zero (CHECK constraint), so two tills selling the last exercise book cannot both succeed;
//   • sales are voided (with a reason), never edited or deleted; voiding puts the stock back.
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, str, uuid, idParams, listQuery } = require('../lib/schema');
const { page, paged, likeEscape } = require('../lib/http');
const { ctx } = require('../auth/plugin');
const { audit } = require('../audit/audit');
const { withIdempotency } = require('../lib/idempotency');

const money = { type: 'integer', minimum: 0, maximum: 10000000000 };
const optTxt = (n) => ({ type: ['string', 'null'], maxLength: n });
async function nextReceipt(c, schoolId) {
  const y = new Date().getFullYear();
  const n = (await c.query(`INSERT INTO doc_counters (school_id, kind, year, last_no) VALUES ($1,'store_sale',$2,1)
    ON CONFLICT (school_id, kind, year) DO UPDATE SET last_no = doc_counters.last_no + 1 RETURNING last_no`, [schoolId, y])).rows[0].last_no;
  return `SAL-${y}-${String(n).padStart(6, '0')}`;
}
const ITEM = `SELECT i.id, i.name, i.category, i.sku, i.unit_price_kobo, i.cost_price_kobo, i.stock_qty, i.reorder_level, i.active, i.updated_at,
  (i.stock_qty <= i.reorder_level) AS low FROM store_items i`;
async function saleDetail(c, id) {
  const s = (await c.query(`SELECT s.id, s.receipt_no, s.student_id, s.buyer_name, s.total_kobo, s.method, s.reference, s.sold_at, s.voided_at, s.void_reason,
      u.full_name AS sold_by, v.full_name AS voided_by, trim(concat_ws(' ', st.first_name, st.last_name)) AS student_name, st.admission_no
    FROM store_sales s LEFT JOIN users u ON u.id = s.sold_by LEFT JOIN users v ON v.id = s.voided_by LEFT JOIN students st ON st.id = s.student_id WHERE s.id = $1`, [id])).rows[0];
  if (!s) throw E.notFound('Sale');
  s.lines = (await c.query('SELECT item_id, item_name, qty, unit_price_kobo, line_total_kobo FROM store_sale_lines WHERE sale_id = $1 ORDER BY item_name', [id])).rows;
  s.school = (await c.query('SELECT name, address, phone, motto FROM schools LIMIT 1')).rows[0];
  return s;
}

module.exports = async function storeRoutes(app) {
  const A = app.authenticate; const VIEW = app.perm('store.view', 'store.sell', 'store.manage'); const MANAGE = app.perm('store.manage');

  app.get('/store/items', { onRequest: [A, VIEW], schema: { querystring: obj({ q: { type: 'string', maxLength: 80 }, includeInactive: { type: 'boolean' }, low: { type: 'boolean' } }) } }, async (req) => withTx(ctx(req), async (c) => {
    const w = []; const p = [];
    if (!req.query.includeInactive) w.push('i.active');
    if (req.query.low) w.push('i.stock_qty <= i.reorder_level');
    if (req.query.q) { p.push(`%${likeEscape(req.query.q)}%`); w.push(`(i.name ILIKE $${p.length} OR i.sku ILIKE $${p.length} OR i.category ILIKE $${p.length})`); }
    const items = (await c.query(`${ITEM} ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY i.category NULLS LAST, i.name LIMIT 1000`, p)).rows;
    const showCost = req.can('store.manage');
    return { items: showCost ? items : items.map(({ cost_price_kobo: _c, ...x }) => x),
      totals: { items: items.length, low: items.filter((x) => x.low).length, stockValueKobo: showCost ? items.reduce((a, x) => a + x.stock_qty * Number(x.cost_price_kobo ?? x.unit_price_kobo), 0) : null } };
  }));

  app.post('/store/items', {
    onRequest: [A, MANAGE],
    schema: { body: obj({ name: str(120, 2), category: optTxt(60), sku: optTxt(40), unitPriceKobo: money, costPriceKobo: { ...money, type: ['integer', 'null'] },
      openingQty: { type: 'integer', minimum: 0, maximum: 1000000 }, reorderLevel: { type: 'integer', minimum: 0, maximum: 1000000 } }, ['name', 'unitPriceKobo']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const b = req.body;
    try {
      const it = (await c.query(`INSERT INTO store_items (school_id, name, category, sku, unit_price_kobo, cost_price_kobo, stock_qty, reorder_level, created_by)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`, [req.auth.schoolId, b.name.trim(), b.category || null, b.sku || null, b.unitPriceKobo, b.costPriceKobo ?? null, b.openingQty || 0, b.reorderLevel || 0, req.auth.userId])).rows[0];
      if (b.openingQty) await c.query("INSERT INTO store_moves (school_id, item_id, kind, qty, unit_cost_kobo, created_by) VALUES ($1,$2,'opening',$3,$4,$5)", [req.auth.schoolId, it.id, b.openingQty, b.costPriceKobo ?? null, req.auth.userId]);
      await audit(c, req, 'store.item_created', { type: 'store_item', id: it.id, meta: { name: b.name, unitPriceKobo: b.unitPriceKobo, openingQty: b.openingQty || 0 } });
      return (await c.query(`${ITEM} WHERE i.id = $1`, [it.id])).rows[0];
    } catch (e) { if (e.code === '23505') throw E.conflict('An item with that name or code already exists.'); throw e; }
  }));

  app.patch('/store/items/:id', {
    onRequest: [A, MANAGE],
    schema: { params: idParams, body: obj({ name: str(120, 2), category: optTxt(60), sku: optTxt(40), unitPriceKobo: money, costPriceKobo: { ...money, type: ['integer', 'null'] },
      reorderLevel: { type: 'integer', minimum: 0, maximum: 1000000 }, active: { type: 'boolean' } }) },   // stock is NOT editable here
  }, async (req) => withTx(ctx(req), async (c) => {
    const cur = (await c.query('SELECT * FROM store_items WHERE id = $1 FOR UPDATE', [req.params.id])).rows[0]; if (!cur) throw E.notFound('Item');
    const b = req.body;
    try {
      await c.query(`UPDATE store_items SET name = $2, category = $3, sku = $4, unit_price_kobo = $5, cost_price_kobo = $6, reorder_level = $7, active = $8 WHERE id = $1`,
        [cur.id, (b.name ?? cur.name).trim(), b.category !== undefined ? b.category : cur.category, b.sku !== undefined ? b.sku : cur.sku, b.unitPriceKobo ?? cur.unit_price_kobo,
          b.costPriceKobo !== undefined ? b.costPriceKobo : cur.cost_price_kobo, b.reorderLevel ?? cur.reorder_level, b.active ?? cur.active]);
    } catch (e) { if (e.code === '23505') throw E.conflict('An item with that name or code already exists.'); throw e; }
    await audit(c, req, 'store.item_updated', { type: 'store_item', id: cur.id, meta: { fields: Object.keys(b), oldPriceKobo: cur.unit_price_kobo, newPriceKobo: b.unitPriceKobo ?? cur.unit_price_kobo } });
    return (await c.query(`${ITEM} WHERE i.id = $1`, [cur.id])).rows[0];
  }));

  // receive stock (+) or correct a count (± with a reason)
  app.post('/store/items/:id/stock', {
    onRequest: [A, MANAGE],
    schema: { params: idParams, body: obj({ kind: { enum: ['restock', 'adjust'] }, qty: { type: 'integer', minimum: -1000000, maximum: 1000000 }, unitCostKobo: { ...money, type: ['integer', 'null'] }, reason: optTxt(300) }, ['kind', 'qty']) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const b = req.body;
    if (b.qty === 0) throw E.bad('Type a quantity.', { field: 'qty' });
    if (b.kind === 'restock' && b.qty < 0) throw E.bad('Received stock must be more than 0. Use "Correct count" to remove stock.', { field: 'qty' });
    if (b.kind === 'adjust' && !(b.reason && b.reason.trim().length >= 3)) throw E.bad('Say why the count is being corrected (e.g. "2 damaged").', { field: 'reason' });
    const it = (await c.query('SELECT id, name, stock_qty FROM store_items WHERE id = $1 FOR UPDATE', [req.params.id])).rows[0]; if (!it) throw E.notFound('Item');
    if (it.stock_qty + b.qty < 0) throw E.bad(`Only ${it.stock_qty} in stock, so you cannot remove ${-b.qty}.`, { field: 'qty' });
    await c.query('UPDATE store_items SET stock_qty = stock_qty + $2 WHERE id = $1', [it.id, b.qty]);
    await c.query('INSERT INTO store_moves (school_id, item_id, kind, qty, unit_cost_kobo, reason, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7)',
      [req.auth.schoolId, it.id, b.kind, b.qty, b.unitCostKobo ?? null, b.reason ? b.reason.trim() : null, req.auth.userId]);
    if (b.kind === 'restock' && b.unitCostKobo != null) await c.query('UPDATE store_items SET cost_price_kobo = $2 WHERE id = $1', [it.id, b.unitCostKobo]);
    await audit(c, req, `store.${b.kind}`, { type: 'store_item', id: it.id, meta: { name: it.name, qty: b.qty, reason: b.reason || null } });
    return (await c.query(`${ITEM} WHERE i.id = $1`, [it.id])).rows[0];
  }));

  app.get('/store/items/:id/moves', { onRequest: [A, VIEW], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => {
    const it = (await c.query(`${ITEM} WHERE i.id = $1`, [req.params.id])).rows[0]; if (!it) throw E.notFound('Item');
    const moves = (await c.query(`SELECT m.kind, m.qty, m.reason, m.created_at, u.full_name AS by, s.receipt_no FROM store_moves m LEFT JOIN users u ON u.id = m.created_by
      LEFT JOIN store_sales s ON s.id = m.sale_id WHERE m.item_id = $1 ORDER BY m.created_at DESC LIMIT 300`, [it.id])).rows;
    const sum = Number((await c.query('SELECT coalesce(sum(qty), 0)::int AS s FROM store_moves WHERE item_id = $1', [it.id])).rows[0].s);
    return { item: it, moves, movesAddUp: sum === it.stock_qty };
  }));

  app.post('/store/sales', {
    onRequest: [A, app.perm('store.sell')],
    schema: { body: obj({ lines: { type: 'array', minItems: 1, maxItems: 50, items: obj({ itemId: uuid, qty: { type: 'integer', minimum: 1, maximum: 10000 } }, ['itemId', 'qty']) },
      studentId: { ...uuid, type: ['string', 'null'] }, buyerName: optTxt(160), method: { enum: ['cash', 'transfer', 'pos'] }, reference: optTxt(80) }, ['lines', 'method']) },
  }, async (req, reply) => withTx(ctx(req), async (c) => withIdempotency(c, req, reply, 'store.sale', async () => {
    const b = req.body;
    const want = new Map(); for (const l of b.lines) want.set(l.itemId, (want.get(l.itemId) || 0) + l.qty);   // same item twice → one line
    const ids = [...want.keys()].sort();
    const items = (await c.query('SELECT id, name, unit_price_kobo, stock_qty, active FROM store_items WHERE id = ANY($1::uuid[]) ORDER BY id FOR UPDATE', [ids])).rows;   // lock in id order: no deadlocks
    if (items.length !== ids.length) throw E.bad('One of the items does not exist.');
    for (const it of items) {
      if (!it.active) throw E.bad(`"${it.name}" is not on sale.`);
      if (it.stock_qty < want.get(it.id)) throw E.conflict(it.stock_qty ? `Only ${it.stock_qty} "${it.name}" left in the store.` : `"${it.name}" is out of stock.`);
    }
    if (b.studentId && !(await c.query('SELECT 1 FROM students WHERE id = $1 AND deleted_at IS NULL', [b.studentId])).rowCount) throw E.bad('Pupil not found.', { field: 'studentId' });
    const total = items.reduce((a, it) => a + Number(it.unit_price_kobo) * want.get(it.id), 0);
    if (total <= 0) throw E.bad('The total must be more than ₦0.');
    const receiptNo = await nextReceipt(c, req.auth.schoolId);
    const s = (await c.query(`INSERT INTO store_sales (school_id, receipt_no, student_id, buyer_name, total_kobo, method, reference, sold_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
      [req.auth.schoolId, receiptNo, b.studentId || null, b.buyerName || null, total, b.method, b.reference || null, req.auth.userId])).rows[0];
    for (const it of items) {
      const q = want.get(it.id);
      await c.query('INSERT INTO store_sale_lines (school_id, sale_id, item_id, item_name, qty, unit_price_kobo, line_total_kobo) VALUES ($1,$2,$3,$4,$5,$6,$7)',
        [req.auth.schoolId, s.id, it.id, it.name, q, it.unit_price_kobo, Number(it.unit_price_kobo) * q]);
      await c.query('UPDATE store_items SET stock_qty = stock_qty - $2 WHERE id = $1', [it.id, q]);
      await c.query("INSERT INTO store_moves (school_id, item_id, kind, qty, sale_id, created_by) VALUES ($1,$2,'sale',$3,$4,$5)", [req.auth.schoolId, it.id, -q, s.id, req.auth.userId]);
    }
    await audit(c, req, 'store.sold', { type: 'store_sale', id: s.id, meta: { receiptNo, totalKobo: total, lines: items.length } });
    return saleDetail(c, s.id);
  })));

  app.get('/store/sales', { onRequest: [A, VIEW], schema: { querystring: listQuery({ from: { type: 'string', format: 'date' }, to: { type: 'string', format: 'date' }, includeVoided: { type: 'boolean' } }) } }, async (req) => withTx(ctx(req), async (c) => {
    const q = req.query; const pg = page(q); const p = []; const w = [];
    if (!q.includeVoided) w.push('s.voided_at IS NULL');
    if (q.from) { p.push(q.from); w.push(`(s.sold_at AT TIME ZONE sc.timezone)::date >= $${p.length}`); }
    if (q.to) { p.push(q.to); w.push(`(s.sold_at AT TIME ZONE sc.timezone)::date <= $${p.length}`); }
    if (q.q) { p.push(`%${likeEscape(q.q)}%`); w.push(`(s.receipt_no ILIKE $${p.length} OR s.buyer_name ILIKE $${p.length} OR st.last_name ILIKE $${p.length} OR st.first_name ILIKE $${p.length})`); }
    const where = `FROM store_sales s JOIN schools sc ON sc.id = s.school_id LEFT JOIN students st ON st.id = s.student_id ${w.length ? 'WHERE ' + w.join(' AND ') : ''}`;
    const agg = (await c.query(`SELECT count(*)::int AS n, coalesce(sum(s.total_kobo) FILTER (WHERE s.voided_at IS NULL), 0)::bigint AS t ${where}`, p)).rows[0];
    const rows = (await c.query(`SELECT s.id, s.receipt_no, s.total_kobo, s.method, s.sold_at, s.voided_at, s.void_reason, coalesce(trim(concat_ws(' ', st.first_name, st.last_name)), s.buyer_name) AS buyer,
        (SELECT string_agg(l.qty || ' × ' || l.item_name, ', ' ORDER BY l.item_name) FROM store_sale_lines l WHERE l.sale_id = s.id) AS items,
        (SELECT full_name FROM users WHERE id = s.sold_by) AS sold_by ${where} ORDER BY s.sold_at DESC LIMIT ${pg.limit} OFFSET ${pg.offset}`, p)).rows;
    return { ...paged(rows, agg.n, pg), totalKobo: Number(agg.t) };
  }));

  app.get('/store/sales/:id', { onRequest: [A, VIEW], schema: { params: idParams } }, async (req) => withTx(ctx(req), async (c) => saleDetail(c, req.params.id)));

  app.post('/store/sales/:id/void', { onRequest: [A, app.perm('store.void')], schema: { params: idParams, body: obj({ reason: str(300, 3) }, ['reason']) } }, async (req) => withTx(ctx(req), async (c) => {
    const s = (await c.query('SELECT id, receipt_no, voided_at, total_kobo FROM store_sales WHERE id = $1 FOR UPDATE', [req.params.id])).rows[0];
    if (!s) throw E.notFound('Sale');
    if (s.voided_at) throw E.conflict('This sale was already voided.');
    const lines = (await c.query('SELECT item_id, qty FROM store_sale_lines WHERE sale_id = $1 ORDER BY item_id', [s.id])).rows;
    await c.query('SELECT id FROM store_items WHERE id = ANY($1::uuid[]) ORDER BY id FOR UPDATE', [lines.map((l) => l.item_id)]);
    for (const l of lines) {
      await c.query('UPDATE store_items SET stock_qty = stock_qty + $2 WHERE id = $1', [l.item_id, l.qty]);
      await c.query("INSERT INTO store_moves (school_id, item_id, kind, qty, sale_id, reason, created_by) VALUES ($1,$2,'sale_void',$3,$4,$5,$6)", [req.auth.schoolId, l.item_id, l.qty, s.id, req.body.reason.trim(), req.auth.userId]);
    }
    await c.query('UPDATE store_sales SET voided_at = now(), voided_by = $2, void_reason = $3 WHERE id = $1', [s.id, req.auth.userId, req.body.reason.trim()]);
    await audit(c, req, 'store.sale_voided', { type: 'store_sale', id: s.id, meta: { receiptNo: s.receipt_no, totalKobo: s.total_kobo, reason: req.body.reason.trim() } });
    return { ok: true };
  }));
};
