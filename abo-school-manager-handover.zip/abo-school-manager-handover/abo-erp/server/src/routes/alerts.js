'use strict';
// Automatic reminders — the offline edition's "Automatic Reminders" page, on the server (027). One list of things that
// need attention, worked out from the real records every time it is opened (nothing to keep in step):
//   • fees overdue (a set number of days after the due date) — with a button that reminds the parents in the app and by
//     e-mail, never twice within a day for the same invoice;
//   • learners whose attendance this term is below the school's floor (at least 5 days marked);
//   • store items at or below their reorder level;
//   • things waiting for someone: petty cash requests, teachers' questions, discounts;
//   • the school's A.B.O. subscription ending soon.
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { obj, uuid } = require('../lib/schema');
const { ctx } = require('../auth/plugin');
const { audit } = require('../audit/audit');
const { notify, queueEmail } = require('../services/notify');

const DEFAULTS = { attendanceFloor: 75, feeOverdueDays: 7, lowStock: true };
const naira = (k) => `₦${(Number(k) / 100).toLocaleString('en-NG', { minimumFractionDigits: 2 })}`;
async function rules(c) { const r = (await c.query('SELECT alerts FROM school_settings LIMIT 1')).rows[0]; return { ...DEFAULTS, ...((r && r.alerts) || {}) }; }
async function overdue(c, days, ids = null) {
  const p = [days]; let extra = '';
  if (ids) { p.push(ids); extra = `AND i.id = ANY($${p.length}::uuid[])`; }
  return (await c.query(`SELECT i.id, i.invoice_no, i.kind, i.student_id, s.first_name, s.last_name, s.admission_no, (i.total_kobo - i.paid_kobo)::bigint AS balance_kobo,
      COALESCE(i.due_date, i.issued_at::date)::text AS due, (SELECT max(sent_at) FROM fee_reminders f WHERE f.invoice_id = i.id) AS last_reminded
    FROM invoices i JOIN students s ON s.id = i.student_id
    WHERE i.status IN ('unpaid','partial') AND i.total_kobo > i.paid_kobo AND s.deleted_at IS NULL
      AND COALESCE(i.due_date, i.issued_at::date) + $1::int <= (now() AT TIME ZONE (SELECT timezone FROM schools WHERE id = app.current_school()))::date ${extra}
    ORDER BY COALESCE(i.due_date, i.issued_at::date), s.last_name LIMIT 2000`, p)).rows;
}

module.exports = async function alertRoutes(app) {
  const A = app.authenticate;

  app.get('/alerts/rules', { onRequest: [A, app.perm('alerts.view')] }, async (req) => withTx(ctx(req), async (c) => ({ rules: await rules(c) })));
  app.put('/alerts/rules', { onRequest: [A, app.perm('alerts.manage')], schema: { body: obj({ attendanceFloor: { type: 'integer', minimum: 0, maximum: 100 },
    feeOverdueDays: { type: 'integer', minimum: 0, maximum: 365 }, lowStock: { type: 'boolean' } }) } }, async (req) => withTx(ctx(req), async (c) => {
    const r = (await c.query('UPDATE school_settings SET alerts = alerts || $2::jsonb WHERE school_id = $1 RETURNING alerts', [req.auth.schoolId, JSON.stringify(req.body)])).rows[0];
    await audit(c, req, 'alerts.rules_updated', { type: 'school_settings', id: req.auth.schoolId, meta: req.body });
    return { rules: { ...DEFAULTS, ...r.alerts } };
  }));

  app.get('/alerts', { onRequest: [A, app.perm('alerts.view')] }, async (req) => withTx(ctx(req), async (c) => {
    const R = await rules(c);
    const fees = req.can('fees.view') ? await overdue(c, R.feeOverdueDays) : null;
    const term = (await c.query('SELECT id, name FROM terms WHERE is_current LIMIT 1')).rows[0] || null;
    let attendance = null;
    if (term && (req.can('attendance.view') || req.can('students.view'))) {
      attendance = (await c.query(`SELECT s.id AS student_id, s.first_name, s.last_name, s.admission_no, cl.display_name AS class_name,
          count(a.*)::int AS days, count(a.*) FILTER (WHERE a.status IN ('present','late'))::int AS present,
          round(100.0 * count(a.*) FILTER (WHERE a.status IN ('present','late')) / NULLIF(count(a.*) FILTER (WHERE a.status <> 'excused'), 0), 1) AS rate
        FROM attendance_records a JOIN students s ON s.id = a.student_id AND s.deleted_at IS NULL LEFT JOIN classes cl ON cl.id = a.class_id
        WHERE a.term_id = $1 GROUP BY s.id, cl.display_name
        HAVING count(a.*) >= 5 AND 100.0 * count(a.*) FILTER (WHERE a.status IN ('present','late')) / NULLIF(count(a.*) FILTER (WHERE a.status <> 'excused'), 0) < $2
        ORDER BY rate, s.last_name LIMIT 500`, [term.id, R.attendanceFloor])).rows;
    }
    const stock = R.lowStock && (req.can('store.view') || req.can('store.manage')) ? (await c.query(`SELECT id, name, stock_qty, reorder_level FROM store_items
      WHERE active AND reorder_level > 0 AND stock_qty <= reorder_level ORDER BY stock_qty, name LIMIT 200`)).rows : null;
    const waiting = {
      pettyCash: req.can('pettycash.approve') ? (await c.query("SELECT count(*)::int AS n FROM petty_cash_requests WHERE status = 'pending' AND requested_by <> $1", [req.auth.userId])).rows[0].n : null,
      pettyCashToPay: req.can('cashbook.record') ? (await c.query("SELECT count(*)::int AS n FROM petty_cash_requests WHERE status IN ('approved','given')")).rows[0].n : null,
      questions: req.can('cbt.publish') ? (await c.query("SELECT count(*)::int AS n FROM cbt_questions WHERE exam_id IS NULL AND status = 'pending'")).rows[0].n : null,
      discounts: req.can('fees.approve') ? (await c.query("SELECT count(*)::int AS n FROM fee_discounts WHERE status = 'pending'")).rows[0].n : null,
    };
    const sub = (await c.query(`SELECT status, COALESCE(current_period_end, trial_ends_at) AS ends_at FROM school_subscriptions
      WHERE status IN ('trial','active','past_due') ORDER BY ends_at DESC NULLS LAST LIMIT 1`)).rows[0] || null;
    const subscription = sub && sub.ends_at && new Date(sub.ends_at).getTime() - Date.now() < 14 * 86400000
      ? { status: sub.status, endsAt: sub.ends_at, daysLeft: Math.max(0, Math.ceil((new Date(sub.ends_at).getTime() - Date.now()) / 86400000)) } : null;
    const total = (fees ? fees.length : 0) + (attendance ? attendance.length : 0) + (stock ? stock.length : 0)
      + Object.values(waiting).reduce((a, n) => a + (n || 0), 0) + (subscription ? 1 : 0);
    return { rules: R, term, total, subscription, waiting,
      fees: fees && { count: fees.length, totalKobo: fees.reduce((a, f) => a + Number(f.balance_kobo), 0), items: fees.slice(0, 300) },
      attendance: attendance && { count: attendance.length, items: attendance }, stock: stock && { count: stock.length, items: stock },
      can: { remind: req.can('alerts.manage') && req.can('fees.view'), manage: req.can('alerts.manage') } };
  }));

  // remind parents of overdue fees (in the app, and by e-mail when the parent has an address)
  app.post('/alerts/fee-reminders', {
    onRequest: [A, app.perm('alerts.manage'), app.perm('fees.view')], config: { rateLimit: { max: 10, timeWindow: '1 minute' } },
    schema: { body: obj({ invoiceIds: { type: 'array', items: uuid, minItems: 1, maxItems: 2000 } }) },
  }, async (req) => withTx(ctx(req), async (c) => {
    const R = await rules(c);
    const list = await overdue(c, R.feeOverdueDays, req.body.invoiceIds || null);       // only invoices that really are overdue
    const school = (await c.query('SELECT name FROM schools WHERE id = $1', [req.auth.schoolId])).rows[0].name;
    let sent = 0, recent = 0, noParent = 0, emails = 0;
    for (const inv of list) {
      if (inv.last_reminded && Date.now() - new Date(inv.last_reminded).getTime() < 20 * 3600000) { recent++; continue; }
      const parents = (await c.query(`SELECT g.user_id, g.email FROM student_guardians sg JOIN guardians g ON g.id = sg.guardian_id WHERE sg.student_id = $1`, [inv.student_id])).rows;
      const users = parents.map((g) => g.user_id).filter(Boolean);
      const mails = [...new Set(parents.map((g) => (g.email || '').trim().toLowerCase()).filter((m) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(m)))];
      if (!users.length && !mails.length) { noParent++; continue; }
      const name = `${inv.first_name} ${inv.last_name}`.trim();
      const title = `School fees reminder: ${naira(inv.balance_kobo)} for ${name}`;
      const body = `${school}: ${naira(inv.balance_kobo)} is still owed on ${inv.invoice_no}${inv.kind === 'brought_forward' ? ' (fees owed from before)' : ''}. Please pay or contact the school office. Thank you.`;
      await notify(c, req.auth.schoolId, users, { kind: 'fees', title, body, link: '#/my-fees' });
      for (const m of mails.slice(0, 3)) { await queueEmail(c, { schoolId: req.auth.schoolId, to: m, subject: title, body, template: 'fee_reminder' }); emails++; }
      await c.query('INSERT INTO fee_reminders (school_id, invoice_id, recipients, sent_by) VALUES ($1,$2,$3,$4)', [req.auth.schoolId, inv.id, users.length + mails.length, req.auth.userId]);
      sent++;
    }
    await audit(c, req, 'alerts.fee_reminders_sent', { type: 'school', id: req.auth.schoolId, meta: { sent, recent, noParent, emails } });
    return { sent, skippedRecent: recent, noParentContact: noParent, emails, checked: list.length };
  }));

  void E;
};
