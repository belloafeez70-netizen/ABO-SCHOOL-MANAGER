'use strict';
// Controlled migration from the legacy offline app (localStorage "💾 Backup" JSON) into the server.
// Preview → commit (atomic). Deliberately NOT imported: API keys (aiSettings), pricing/bank data,
// login accounts (legacy had no passwords — the school issues access codes instead), parent messages.
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const { idParams } = require('../lib/schema');
const { ctx } = require('../auth/plugin');
const { audit } = require('../audit/audit');
const R = require('../services/results');
const { saveUpload } = require('../storage');

const stripHtml = (h) => String(h || '').replace(/<(script|style)[\s\S]*?<\/\1>/gi, '').replace(/<br\s*\/?>/gi, '\n').replace(/<\/p>/gi, '\n\n').replace(/<[^>]+>/g, '')
  .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/\n{3,}/g, '\n\n').trim();
function splitClass(label) {
  const s = String(label || '').trim().toUpperCase().replace(/\s+/g, ' ');
  const m = /^(.*\d)\s*([A-Z])$/.exec(s);
  return m ? { name: m[1].trim(), arm: m[2] } : { name: s || 'CLASS 1', arm: '' };
}
function splitName(full) {
  const parts = String(full || '').trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return null;
  if (parts.length === 1) return { last: parts[0], first: parts[0], other: null };
  return { last: parts[0], first: parts[1], other: parts.slice(2).join(' ') || null };
}
// a photo kept by the offline app is a "data:image/...;base64," text; accept PNG/JPEG/WebP up to 1 MB (the passport limit)
const PHOTO_MAX = 1024 * 1024;
function photoOf(v) {
  const m = /^data:image\/(png|jpe?g|webp);base64,([A-Za-z0-9+/=\s]+)$/.exec(typeof v === 'string' ? v : '');
  if (!m) return null;
  const buf = Buffer.from(m[2].replace(/\s+/g, ''), 'base64');
  return buf.length > 0 && buf.length <= PHOTO_MAX ? { buf, ext: m[1] === 'png' ? 'png' : m[1] === 'webp' ? 'webp' : 'jpg' } : null;
}
// two score layouts are the same when they have the same parts with the same maximum (order does not matter)
const sameLayout = (a, b) => a.length === b.length && a.every((x) => b.some((y) => y.key === x.key && Math.abs(Number(y.max) - Number(x.max)) < 0.001));

function analyse(data) {
  if (!data || typeof data !== 'object' || (!Array.isArray(data.students) && !(data.schoolData && data.schoolData.erp))) throw E.bad('This does not look like an A.B.O. backup file.');
  const gs = data.globalSettings || {};
  const section = String(gs.educationLevel || 'primary').toLowerCase() === 'secondary' ? 'secondary' : 'primary';
  const session = /^\d{4}\/\d{4}$/.test(gs.session || '') ? gs.session : null;
  const term = ['1ST', '2ND', '3RD'].includes(String(gs.term || '').toUpperCase()) ? String(gs.term).toUpperCase() : '1ST';
  const subjects = (Array.isArray(data.subjects) ? data.subjects : []).map((s) => String(s).trim()).filter((s) => s.length >= 2).slice(0, 40);
  const registers = {};
  const learners = data.schoolData && data.schoolData.erp && data.schoolData.erp.learners;
  if (learners && typeof learners === 'object' && !Array.isArray(learners)) for (const [k, v] of Object.entries(learners)) if (Array.isArray(v)) registers[k] = v;
  if (Array.isArray(data.students) && data.students.length) registers[gs.className || 'BASIC 1'] = data.students;   // active register wins (freshest)
  const warnings = []; const classes = []; let students = 0; let scores = 0; let photos = 0; let capped = 0; let generatedNos = 0; let dupInFile = 0;
  // the offline app's score layout (Settings → Broadsheet): each part has its own maximum and weight.
  // On the server each part's maximum is its weight, so totals out of 100 come out exactly the same.
  const erp = (data.schoolData && data.schoolData.erp) || {};
  const rawComps = (erp.broadsheet && Array.isArray(erp.broadsheet.components) && erp.broadsheet.components.length) ? erp.broadsheet.components
    : [{ key: 'ca1', name: 'CA 1', max: 20, weight: 20 }, { key: 'ca2', name: 'CA 2', max: 20, weight: 20 }, { key: 'exam', name: 'Exam', max: 60, weight: 60 }];
  const comps = rawComps.slice(0, 6).map((c) => ({ key: String(c.key || '').toLowerCase(), label: String(c.name || c.key || '').slice(0, 30) || 'Score', max: Number(c.max) || 100, weight: Number(c.weight) || 0 }))
    .filter((c) => /^[a-z0-9_]{1,20}$/.test(c.key) && c.weight > 0);
  const layout = comps.map((c) => ({ key: c.key, label: c.label, max: c.weight, isExam: c.key === 'exam' }));
  const rawScore = (sub, key) => { const v = Number(['ca1', 'ca2', 'exam'].includes(key) ? sub[key] : (sub.extra || {})[key]); return Number.isFinite(v) && v > 0 ? v : 0; };
  const classSubjects = (erp.classSubjects && typeof erp.classSubjects === 'object') ? erp.classSubjects : {};
  const seenNos = new Set();
  for (const [label, list] of Object.entries(registers)) {
    const cls = { ...splitClass(label), label, section, students: [] };
    const own = Array.isArray(classSubjects[label]) ? classSubjects[label].filter((x) => subjects.includes(String(x).trim())) : [];
    cls.subjects = own.length ? own.map((x) => String(x).trim()) : subjects;
    const named = list.filter((s) => s && String(s.name || '').trim());
    const att = named.map((s) => String(s.attendanceNo ?? '').trim());
    named.forEach((s, i) => {
      const nm = splitName(s.name);
      // a real admission number if the school typed one; otherwise a stable one made from the class (BASIC1-3).
      // The offline register numbers (1, 2, 3 …) start again in every class, so they cannot identify a learner.
      let no = String(s.admissionNo || '').trim();
      if (!no && att[i] && !/^\d{1,4}$/.test(att[i])) no = att[i];
      let generated = false;
      if (!no) { const n = /^\d{1,4}$/.test(att[i]) && att.indexOf(att[i]) === i ? att[i] : String(i + 1); no = `${cls.name.replace(/\s+/g, '')}${cls.arm}-${n}`; generated = true; generatedNos++; }
      no = no.slice(0, 40);
      if (seenNos.has(no.toLowerCase())) {
        if (!generated) { dupInFile++; warnings.push(`Admission number ${no} appears more than once in the file (${s.name}); only the first is imported.`); cls.students.push({ duplicateInFile: true, admissionNo: no }); return; }
        let k = 2; while (seenNos.has(`${no}-${k}`.toLowerCase())) k++; no = `${no}-${k}`;
      }
      seenNos.add(no.toLowerCase());
      const st = { first: nm.first.slice(0, 80), last: nm.last.slice(0, 80), other: nm.other, gender: s.gender === 'Female' ? 'Female' : 'Male',
        admissionNo: no,
        dob: /^\d{4}-\d{2}-\d{2}$/.test(s.dob || '') ? s.dob : null, parentPhone: s.parentPhone || s.parentWhatsapp || null, parentEmail: s.parentEmail || null,
        teacherComment: s.teacherComment ? String(s.teacherComment).slice(0, 600) : null, headComment: s.headComment ? String(s.headComment).slice(0, 600) : null,
        present: Number.isInteger(s.present) ? s.present : null, absent: Number.isInteger(s.absent) ? s.absent : null, scores: {} };
      (Array.isArray(s.subjects) ? s.subjects : []).forEach((sub, j) => {
        if (!subjects[j] || !sub) return;
        if (!comps.some((c) => rawScore(sub, c.key) > 0)) return;          // nothing entered for this subject
        const sc = {};                                                       // once a subject has marks, a 0 is a real 0
        for (const c of comps) { const v = rawScore(sub, c.key); if (v > c.max) capped++; sc[c.key] = Math.round((Math.min(v, c.max) / c.max) * c.weight * 100) / 100; }
        st.scores[subjects[j]] = sc; scores++;
      });
      if (s.passport) { if (photoOf(s.passport)) { st.photo = true; photos++; } else warnings.push(`Passport photo for ${s.name} is not a usable picture (PNG/JPEG/WebP up to 1 MB) and was skipped.`); }
      cls.students.push(st); students++;
    });
    classes.push(cls);
  }
  if (generatedNos) warnings.push(`${generatedNos} learner(s) had no admission number in the offline app. Each was given one made from the class, like ${classes.find((k) => k.students.length) ? `${classes.find((k) => k.students.length).name.replace(/\s+/g, '')}${classes.find((k) => k.students.length).arm}-1` : 'BASIC1-1'}. You can change them later.`);
  if (capped) warnings.push(`${capped} score(s) were higher than the maximum and were counted at the maximum, exactly as the offline app does.`);
  const wsum = comps.reduce((a, c) => a + c.weight, 0);
  if (Math.abs(wsum - 100) > 0.001) warnings.push(`The offline score layout adds up to ${wsum}, not 100. Scores are imported as they are; check the totals.`);
  const cbt = (Array.isArray(data.cbtExams) ? data.cbtExams : []).slice(0, 200).map((e) => ({
    title: String(e.title || 'Imported CBT').slice(0, 160), duration: Math.max(1, Math.min(600, Number(e.durationMinutes) || 30)),
    questions: (Array.isArray(e.questions) ? e.questions : []).slice(0, 300).map((q) => ({
      type: q.type === 'theory' ? 'theory' : 'mcq', text: String(q.text || '').slice(0, 4000),
      options: (q.options || []).slice(0, 8).map((o) => ({ text: String(o.text || '').slice(0, 1000) || '—', isCorrect: !!o.correct })), theoryGuide: q.theoryGuide || null,
    })).filter((q) => q.text && (q.type === 'theory' || (q.options.length >= 2 && q.options.filter((o) => o.isCorrect).length === 1))),
  }));
  const newsletters = (Array.isArray(data.newsletters) ? data.newsletters : []).slice(0, 200).map((n) => ({ title: String(n.title || 'Newsletter').slice(0, 160), body: stripHtml(n.html).slice(0, 60000) || '(empty)' }));
  const teachers = ((data.userAccounts && data.userAccounts.teachers) || []).map((t) => ({ name: String(t.name || t.loginId || 'Teacher').slice(0, 160), email: t.email || null })).filter((t) => t.name.length >= 2);
  // legacy login IDs → candidate accounts (validated; imported only if the school opts in at commit, as PENDING + access code)
  const LOGIN = /^[A-Za-z0-9._@-]{3,64}$/; const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const ua = data.userAccounts || {};
  const accounts = [
    ...(ua.admins || []).map((x) => ({ kind: 'admin', role: 'administrator', loginId: x.loginId || x.id, name: x.name, email: x.email })),
    ...(ua.teachers || []).map((x) => ({ kind: 'teacher', role: 'teacher', loginId: x.loginId || x.id, name: x.name, email: x.email })),
    ...(ua.students || []).map((x) => ({ kind: 'student', role: 'student', loginId: x.loginId || x.id, name: x.name || x.linkedStudentName, email: x.email, admissionNo: x.admissionNo })),
  ].map((x) => ({ ...x, loginId: String(x.loginId || '').trim(), name: String(x.name || '').trim().slice(0, 160), email: x.email && EMAIL.test(x.email) ? String(x.email).toLowerCase() : null }))
    .filter((x) => LOGIN.test(x.loginId) && x.name.length >= 2).slice(0, 2000);
  const legacyAudit = (Array.isArray(ua.audit) ? ua.audit : []).slice(0, 2000).map((a) => ({ time: /^\d{4}-\d{2}-\d{2}T/.test(a.time || '') ? a.time : null, actor: String(a.actor || '').slice(0, 80), role: String(a.role || '').slice(0, 20), action: String(a.action || '').slice(0, 300) })).filter((a) => a.action);
  if (data.aiSettings && data.aiSettings.apiKey) warnings.push('An AI API key was found in the backup and was DISCARDED. Configure AI on the server instead.');
  if (data.userAccounts) warnings.push(`${accounts.length} valid legacy login ID(s) found. They are imported only if you tick "import accounts": each becomes a PENDING account that must be activated with a one-time access code (legacy accounts had no passwords).`);
  if (legacyAudit.length) warnings.push(`${legacyAudit.length} legacy audit entries can be imported as UNVERIFIED client-side history.`);
  if ((data.parentMessages || []).length) warnings.push(`${data.parentMessages.length} parent messages were not imported.`);
  return { school: { name: data.schoolData && data.schoolData.name, motto: data.schoolData && data.schoolData.motto, address: data.schoolData && data.schoolData.address, phone: data.schoolData && data.schoolData.phone, email: data.schoolData && data.schoolData.email },
    session, term, section, subjects, classes, cbt, newsletters, teachers, accounts, legacyAudit, layout, warnings: [...new Set(warnings)].slice(0, 100),
    counts: { classes: classes.length, students: students + dupInFile, duplicatesInFile: dupInFile, photos, logo: !!photoOf(data.schoolData && data.schoolData.logo), scoreRows: scores, subjects: subjects.length, cbtExams: cbt.length, newsletters: newsletters.length, teachers: teachers.length, accounts: accounts.length, auditEntries: legacyAudit.length } };
}

module.exports = async function migrationRoutes(app) {
  const guard = [app.authenticate, app.perm('imports.run')];
  const need = (req) => { for (const p of ['students.create', 'academic.manage', 'results.enter_any']) if (!req.can(p)) throw E.forbidden(`Legacy migration requires ${p}.`); };

  app.post('/migration/legacy/preview', { onRequest: guard, bodyLimit: 20 * 1024 * 1024, config: { rateLimit: { max: 10, timeWindow: '1 minute' } } }, async (req) => {
    need(req);
    const file = await req.file(); if (!file) throw E.bad('Attach the backup .json file.');
    const buf = await file.toBuffer();
    let data; try { data = JSON.parse(buf.toString('utf8')); } catch { throw E.bad('The file is not valid JSON.'); }
    const plan = analyse(data);
    plan.fileSha = require('node:crypto').createHash('sha256').update(buf).digest('hex');   // commit may send the same file again for the photos
    return withTx(ctx(req), async (c) => {
      const clash = (await c.query('SELECT lower(admission_no) AS a FROM students WHERE lower(admission_no) = ANY($1::text[])', [plan.classes.flatMap((k) => k.students.filter((s) => !s.duplicateInFile).map((s) => s.admissionNo.toLowerCase()))])).rows.map((r) => r.a);
      if (clash.length) plan.warnings.push(`${clash.length} admission number(s) already exist and those students will be skipped.`);
      const server = (await R.settings(c)).assessment_components.map((x) => ({ key: x.key, label: x.label, max: Number(x.max) }));
      const layoutSame = sameLayout(plan.layout, server);
      if (!layoutSame) plan.warnings.push(`Score layout is different. Offline app: ${plan.layout.map((x) => `${x.label} ${x.max}`).join(' + ')}. This school: ${server.map((x) => `${x.label} ${x.max}`).join(' + ')}. Tick "Use the offline score layout" to bring all scores in; otherwise only the matching parts are imported.`);
      const imp = (await c.query("INSERT INTO imports (school_id, kind, file_name, total_rows, valid_rows, rows, errors, created_by) VALUES ($1,'legacy',$2,$3,$4,$5,$6,$7) RETURNING id",
        [req.auth.schoolId, String(file.filename).slice(0, 120), plan.counts.students, plan.counts.students - clash.length, JSON.stringify([plan]), JSON.stringify(plan.warnings.map((m) => ({ message: m }))), req.auth.userId])).rows[0];
      await audit(c, req, 'data.legacy_previewed', { type: 'import', id: imp.id, meta: plan.counts });
      return { importId: imp.id, counts: plan.counts, warnings: plan.warnings, session: plan.session, term: plan.term, layout: { offline: plan.layout, server, same: layoutSame }, classes: plan.classes.map((k) => ({ label: `${k.name}${k.arm}`, students: k.students.length })) };
    });
  });

  app.post('/migration/legacy/:id/commit', { onRequest: guard, bodyLimit: 20 * 1024 * 1024, config: { rateLimit: { max: 10, timeWindow: '1 minute' } },
    schema: { params: idParams, body: { type: ['object', 'null'], additionalProperties: false, properties: { importAccounts: { type: 'boolean' }, importAudit: { type: 'boolean' }, adoptLayout: { type: 'boolean' } } } } }, async (req) => {
    // Photos: the browser may send the SAME backup file again (multipart). It must be byte-for-byte the previewed file.
    let opts = req.body || {}; let photoData = null;
    if (req.isMultipart && req.isMultipart()) {
      const file = await req.file(); if (!file) throw E.bad('Attach the same backup file you previewed.');
      const buf = await file.toBuffer();
      const f = (n) => file.fields && file.fields[n] && file.fields[n].value === 'true';
      opts = { importAccounts: f('importAccounts'), importAudit: f('importAudit'), adoptLayout: f('adoptLayout') };
      let parsed; try { parsed = JSON.parse(buf.toString('utf8')); } catch { throw E.bad('The file is not valid JSON.'); }
      photoData = { sha: require('node:crypto').createHash('sha256').update(buf).digest('hex'), data: parsed };
    }
    if (opts.importAccounts && !(req.can('users.create') && req.can('users.assign_role'))) throw E.forbidden('Importing accounts requires users.create and users.assign_role.');
    need(req);
    return withTx(ctx(req), async (c) => {
      const imp = (await c.query("SELECT * FROM imports WHERE id = $1 AND kind = 'legacy' FOR UPDATE", [req.params.id])).rows[0];
      if (!imp) throw E.notFound('Import');
      if (imp.status !== 'previewed') throw E.conflict('This migration was already processed.');
      const plan = imp.rows[0]; const sch = req.auth.schoolId;
      const photos = new Map(); let logo = null;
      if (photoData) {
        if (!plan.fileSha || plan.fileSha !== photoData.sha) throw E.bad('This is not the same file you previewed. Preview it again.');
        const again = analyse(photoData.data);                         // same file → same admission numbers
        const raw = {}; const L = (photoData.data.schoolData && photoData.data.schoolData.erp && photoData.data.schoolData.erp.learners) || {};
        for (const [k, v] of Object.entries(L)) if (Array.isArray(v)) raw[k] = v;
        if (Array.isArray(photoData.data.students) && photoData.data.students.length) raw[(photoData.data.globalSettings || {}).className || 'BASIC 1'] = photoData.data.students;
        for (const k of again.classes) {
          const list = (raw[k.label] || []).filter((x) => x && String(x.name || '').trim());
          k.students.forEach((st, i) => { if (st.photo && !st.duplicateInFile && list[i]) { const p = photoOf(list[i].passport); if (p) photos.set(st.admissionNo.toLowerCase(), p); } });
        }
        logo = photoOf(photoData.data.schoolData && photoData.data.schoolData.logo);
      }
      const out = { classes: 0, students: 0, skipped: 0, skippedExisting: 0, skippedDuplicateInFile: 0, subjects: 0, scores: 0, scoreParts: 0, scorePartsNotImported: 0, cbtExams: 0, cbtSkipped: 0, newsletters: 0, newslettersSkipped: 0, teachers: 0, teachersSkipped: 0, layoutAdopted: false };
      const layout = plan.layout || [{ key: 'ca1', label: 'CA 1', max: 20 }, { key: 'ca2', label: 'CA 2', max: 20 }, { key: 'exam', label: 'Exam', max: 60 }];
      if (opts.adoptLayout && !sameLayout(layout, (await R.settings(c)).assessment_components)) {
        if (!req.can('settings.update')) throw E.forbidden('Changing the score layout requires settings.update.');
        const err = require('../services/grading').validateComponents(layout); if (err) throw E.bad(`The offline score layout cannot be used: ${err}`);
        await c.query('UPDATE assessment_components SET active = false');          // existing sheets keep their own frozen copy
        for (const [i, x] of layout.entries()) await c.query(`INSERT INTO assessment_components (school_id, key, label, max_score, is_exam, position, active) VALUES ($1,$2,$3,$4,$5,$6,true)
          ON CONFLICT (school_id, key) DO UPDATE SET label = EXCLUDED.label, max_score = EXCLUDED.max_score, is_exam = EXCLUDED.is_exam, position = EXCLUDED.position, active = true`, [sch, x.key, x.label, x.max, !!x.isExam, i]);
        out.layoutAdopted = true;
      }
      // session + term
      let sess = (await c.query('SELECT id FROM academic_sessions WHERE is_current LIMIT 1')).rows[0];
      if (plan.session) sess = (await c.query('SELECT id FROM academic_sessions WHERE name = $1', [plan.session])).rows[0] || sess;
      if (!sess) {
        const name = plan.session || `${new Date().getFullYear()}/${new Date().getFullYear() + 1}`;
        const hasCurrent = (await c.query('SELECT 1 FROM academic_sessions WHERE is_current')).rowCount > 0;
        sess = (await c.query('INSERT INTO academic_sessions (school_id, name, is_current) VALUES ($1,$2,$3) RETURNING id', [sch, name, !hasCurrent])).rows[0];
        for (const t of ['1ST', '2ND', '3RD']) await c.query('INSERT INTO terms (school_id, session_id, name, is_current) VALUES ($1,$2,$3,$4)', [sch, sess.id, t, !hasCurrent && t === plan.term]);
      }
      const term = (await c.query('SELECT id FROM terms WHERE session_id = $1 AND name = $2', [sess.id, plan.term])).rows[0];
      // subjects
      const subj = new Map((await c.query('SELECT id, lower(name) AS n FROM subjects')).rows.map((r) => [r.n, r.id]));
      for (const s of plan.subjects) if (!subj.has(s.toLowerCase())) { subj.set(s.toLowerCase(), (await c.query('INSERT INTO subjects (school_id, name) VALUES ($1,$2) RETURNING id', [sch, s])).rows[0].id); out.subjects++; }
      const st = await R.settings(c); const touched = new Set();
      for (const k of plan.classes) {
        let cl = (await c.query('SELECT id FROM classes WHERE name = $1 AND arm = $2', [k.name, k.arm])).rows[0];
        if (!cl) { cl = (await c.query('INSERT INTO classes (school_id, name, arm, section) VALUES ($1,$2,$3,$4) RETURNING id', [sch, k.name, k.arm, k.section])).rows[0]; out.classes++; }
        for (const s of (k.subjects || plan.subjects)) await c.query('INSERT INTO class_subjects (school_id, class_id, subject_id) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING', [sch, cl.id, subj.get(s.toLowerCase())]);
        for (const s of k.students) {
          if (s.duplicateInFile) { out.skipped++; out.skippedDuplicateInFile++; continue; }
          const exists = await c.query('SELECT 1 FROM students WHERE lower(admission_no) = lower($1)', [s.admissionNo]);
          if (exists.rowCount) { out.skipped++; out.skippedExisting++; continue; }
          const row = (await c.query('INSERT INTO students (school_id, admission_no, first_name, last_name, other_names, gender, date_of_birth) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id',
            [sch, s.admissionNo, s.first, s.last, s.other, s.gender, s.dob])).rows[0];
          await c.query('INSERT INTO student_enrollments (school_id, student_id, class_id, session_id) VALUES ($1,$2,$3,$4) ON CONFLICT DO NOTHING', [sch, row.id, cl.id, sess.id]);
          if (s.parentPhone || s.parentEmail) {
            const g = (await c.query('INSERT INTO guardians (school_id, full_name, relationship, phone, email) VALUES ($1,$2,$3,$4,$5) RETURNING id', [sch, `Parent of ${s.first} ${s.last}`, 'Parent', String(s.parentPhone || '').slice(0, 20) || null, s.parentEmail])).rows[0];
            await c.query('INSERT INTO student_guardians (school_id, student_id, guardian_id, is_primary) VALUES ($1,$2,$3,true)', [sch, row.id, g.id]);
          }
          if (s.teacherComment || s.headComment || s.present !== null) await c.query('INSERT INTO report_cards (school_id, term_id, student_id, teacher_comment, head_comment, days_present, days_absent) VALUES ($1,$2,$3,$4,$5,$6,$7) ON CONFLICT DO NOTHING',
            [sch, term.id, row.id, s.teacherComment, s.headComment, s.present, s.absent]);
          for (const [subject, sc] of Object.entries(s.scores)) {
            const sh = (await c.query(`INSERT INTO assessments (school_id, term_id, class_id, subject_id, components, created_by) VALUES ($1,$2,$3,$4,$5,$6)
              ON CONFLICT (term_id, class_id, subject_id) DO UPDATE SET updated_at = assessments.updated_at RETURNING id, status`, [sch, term.id, cl.id, subj.get(subject.toLowerCase()), JSON.stringify(st.assessment_components), req.auth.userId])).rows[0];
            if (sh.status !== 'draft') continue;
            for (const [key, val] of Object.entries(sc)) {
              const comp = st.assessment_components.find((x) => x.key === key);
              const want = layout.find((x) => x.key === key);   // same part, same maximum — otherwise the number would mean something else
              if (val === null || val === undefined || !comp || !want || Math.abs(Number(comp.max) - Number(want.max)) > 0.001 || Number(val) > Number(comp.max)) { out.scorePartsNotImported++; continue; }
              out.scoreParts++;
              await c.query(`INSERT INTO assessment_scores (school_id, sheet_id, student_id, component_key, score, entered_by) VALUES ($1,$2,$3,$4,$5,$6) ON CONFLICT (sheet_id, student_id, component_key) DO UPDATE SET score = EXCLUDED.score`,
                [sch, sh.id, row.id, key, val, req.auth.userId]);
            }
            touched.add(sh.id); out.scores++;
          }
          const ph = photos.get(s.admissionNo.toLowerCase());
          if (ph) {
            const up = await saveUpload(c, { schoolId: sch, userId: req.auth.userId, purpose: 'passport', buffer: ph.buf, originalName: `${s.admissionNo.replace(/[^A-Za-z0-9-]/g, '_')}.${ph.ext}` }).catch(() => null);
            if (up) { await c.query('UPDATE students SET passport_file_id = $2 WHERE id = $1', [row.id, up.id]); out.photos = (out.photos || 0) + 1; } else out.photosSkipped = (out.photosSkipped || 0) + 1;
          }
          out.students++;
        }
      }
      for (const id of touched) await R.recomputeSheet(c, id);
      for (const e of plan.cbt) {
        if ((await c.query('SELECT 1 FROM cbt_exams WHERE lower(title) = lower($1)', [e.title])).rowCount) { out.cbtSkipped++; continue; }   // already brought in
        const ex = (await c.query("INSERT INTO cbt_exams (school_id, title, duration_minutes, created_by) VALUES ($1,$2,$3,$4) RETURNING id", [sch, e.title, e.duration, req.auth.userId])).rows[0];
        for (const [i, q] of e.questions.entries()) {
          const qq = (await c.query('INSERT INTO cbt_questions (school_id, exam_id, type, text, position, theory_guide, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id', [sch, ex.id, q.type, q.text, i + 1, q.theoryGuide, req.auth.userId])).rows[0];
          for (const [j, o] of q.options.entries()) await c.query('INSERT INTO cbt_options (school_id, question_id, text, is_correct, position) VALUES ($1,$2,$3,$4,$5)', [sch, qq.id, o.text, o.isCorrect, j]);
        }
        out.cbtExams++;
      }
      // old-app newsletters arrive as DRAFT announcements (Newsletters were merged into Announcements, migration 025)
      for (const n of plan.newsletters) { if ((await c.query('SELECT 1 FROM announcements WHERE lower(title) = lower($1) AND body = $2', [n.title, n.body])).rowCount) { out.newslettersSkipped++; continue; } await c.query("INSERT INTO announcements (school_id, title, body, audience, draft, source, created_by) VALUES ($1,$2,$3,'parents',true,'newsletter',$4)", [sch, n.title, n.body, req.auth.userId]); out.newsletters++; }
      for (const t of plan.teachers) { if ((await c.query('SELECT 1 FROM staff WHERE lower(full_name) = lower($1)', [t.name])).rowCount) { out.teachersSkipped++; continue; } await c.query('INSERT INTO staff (school_id, full_name, email, is_teacher) VALUES ($1,$2,$3,true)', [sch, t.name, t.email && /^[^\s@]+@[^\s@]+$/.test(t.email) ? t.email : null]); out.teachers++; }
      // accounts: PENDING identities + membership + mapped role + one-time access code (never password-less)
      const slips = [];
      if (opts.importAccounts) {
        const roleIds = Object.fromEntries((await c.query("SELECT key, id FROM roles WHERE key IN ('administrator','teacher','student')")).rows.map((r) => [r.key, r.id]));
        out.accounts = 0; out.accountsSkipped = 0;
        for (const a of plan.accounts || []) {
          const taken = (await c.query('SELECT app.login_id_taken($1) AS t', [a.loginId])).rows[0].t || (a.email && (await c.query('SELECT app.email_taken($1) AS t', [a.email])).rows[0].t);
          if (taken) { out.accountsSkipped++; continue; }
          const u = (await c.query("INSERT INTO users (school_id, login_id, full_name, email, status) VALUES ($1,$2,$3,$4,'pending') RETURNING id", [sch, a.loginId, a.name, a.email])).rows[0];
          await c.query("INSERT INTO school_memberships (user_id, school_id, status, is_default) VALUES ($1,$2,'active',true)", [u.id, sch]);
          await c.query('INSERT INTO user_roles (school_id, user_id, role_id, granted_by) VALUES ($1,$2,$3,$4)', [sch, u.id, roleIds[a.role], req.auth.userId]);
          if (a.kind === 'student' && a.admissionNo) await c.query('UPDATE students SET user_id = $2 WHERE lower(admission_no) = lower($1) AND user_id IS NULL', [String(a.admissionNo), u.id]);
          if (a.kind === 'teacher') await c.query('UPDATE staff SET user_id = $2 WHERE id = (SELECT id FROM staff WHERE user_id IS NULL AND lower(full_name) = lower($1) LIMIT 1)', [a.name, u.id]);
          const code = require('../security/crypto').humanCode(10);
          await c.query("UPDATE users SET access_code_hash = $2, access_code_expires_at = now() + interval '7 days' WHERE id = $1", [u.id, require('../security/crypto').sha256(code)]);
          slips.push({ loginId: a.loginId, fullName: a.name, role: a.role, accessCode: `${code.slice(0, 5)}-${code.slice(5)}`, expiresInDays: 7 });
          out.accounts++;
        }
      }
      // legacy audit trail → hash-chained log, explicitly marked as UNVERIFIED client-side history
      if (opts.importAudit) {
        out.auditEntries = 0;
        for (const a of plan.legacyAudit || []) {
          await audit(c, req, 'legacy.audit_imported', { type: 'legacy_audit', meta: { unverified: true, source: 'localStorage', originalTime: a.time, originalActor: a.actor, originalRole: a.role, originalAction: a.action } });
          out.auditEntries++;
        }
      }
      // school logo, only if the school has none yet and the importer may change school settings
      if (logo && req.can('settings.update') && !(await c.query('SELECT logo_file_id FROM schools WHERE id = $1', [sch])).rows[0].logo_file_id) {
        const up = await saveUpload(c, { schoolId: sch, userId: req.auth.userId, purpose: 'logo', buffer: logo.buf, originalName: `logo.${logo.ext}` }).catch(() => null);
        if (up) { await c.query('UPDATE schools SET logo_file_id = $2 WHERE id = $1', [sch, up.id]); out.logo = true; }
      }
      // reconciliation: every learner in the file is either imported or skipped for a stated reason
      const inFile = plan.counts.students;
      out.reconciliation = { learnersInFile: inFile, imported: out.students, skippedExisting: out.skippedExisting, skippedDuplicateInFile: out.skippedDuplicateInFile,
        balanced: inFile === out.students + out.skippedExisting + out.skippedDuplicateInFile, scoreRowsInFile: plan.counts.scoreRows };
      if (!out.reconciliation.balanced) throw E.conflict('Import stopped: the learner counts do not add up, so nothing was saved.');
      await c.query("UPDATE imports SET status = 'committed', committed_at = now(), summary = $2 WHERE id = $1", [imp.id, out]);
      await audit(c, req, 'data.legacy_imported', { type: 'import', id: imp.id, meta: out });
      return { ok: true, ...out, accessSlips: slips };
    });
  });
};
module.exports.analyse = analyse;
