-- grants.sql — re-applied after every migration run (idempotent). Least privilege for the runtime role.
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT USAGE ON SCHEMA public, app TO abo_app;

GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO abo_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO abo_app;

-- append-only / read-only surfaces
REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON audit_logs FROM abo_app;            -- writes only via app.audit_append()
REVOKE UPDATE, DELETE, TRUNCATE ON login_events, security_events, assessment_score_history FROM abo_app;
REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON permissions, schema_migrations FROM abo_app;
REVOKE TRUNCATE ON ALL TABLES IN SCHEMA public FROM abo_app;
REVOKE INSERT, UPDATE, DELETE ON newsletters FROM abo_app;                     -- retired 025: merged into announcements (history only)

-- functions: definer functions are callable only by the runtime role
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA app FROM PUBLIC;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA app TO abo_app;
