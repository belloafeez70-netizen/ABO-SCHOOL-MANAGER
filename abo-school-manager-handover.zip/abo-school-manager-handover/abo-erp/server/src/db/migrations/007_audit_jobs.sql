-- 007_audit_jobs.sql — tamper-evident audit log (hash chain), login/security events, job queue,
-- imports, promotion runs.

CREATE TABLE audit_logs (
  id            bigserial PRIMARY KEY,
  school_id     uuid,                       -- NULL ⇒ platform-level event (no FK: logs outlive tenants)
  chain_key     text NOT NULL,              -- school uuid or 'platform'
  seq           bigint NOT NULL,
  actor_user_id uuid,
  actor_login   text,
  actor_roles   text[],
  action        text NOT NULL CHECK (action ~ '^[a-z_]+(\.[a-z_]+)+$'),
  resource_type text,
  resource_id   text,
  success       boolean NOT NULL,
  ip            inet,
  user_agent    text,
  metadata      jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at    timestamptz NOT NULL,
  prev_hash     text NOT NULL,
  hash          text NOT NULL,
  UNIQUE (chain_key, seq)
);
CREATE INDEX audit_logs_school_time_idx ON audit_logs (school_id, created_at DESC);
CREATE INDEX audit_logs_action_idx ON audit_logs (school_id, action);
CREATE INDEX audit_logs_actor_idx ON audit_logs (actor_user_id, created_at DESC);

CREATE OR REPLACE FUNCTION app.audit_row_hash(
  p_prev text, p_seq bigint, p_school uuid, p_actor uuid, p_login text, p_roles text[], p_action text,
  p_rtype text, p_rid text, p_success boolean, p_ip inet, p_ua text, p_meta jsonb, p_created timestamptz
) RETURNS text LANGUAGE sql IMMUTABLE AS $$
  SELECT encode(sha256(convert_to(concat_ws('|',
    p_prev, p_seq::text, coalesce(p_school::text,'-'), coalesce(p_actor::text,'-'), coalesce(p_login,'-'),
    coalesce(array_to_string(p_roles, ','),'-'), p_action, coalesce(p_rtype,'-'), coalesce(p_rid,'-'),
    p_success::text, coalesce(host(p_ip),'-'), coalesce(p_ua,'-'), coalesce(p_meta::text,'{}'),
    to_char(p_created AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US')
  ), 'UTF8')), 'hex')
$$;

-- The ONLY way the application can write an audit row. SECURITY DEFINER + no INSERT grant on the table.
CREATE OR REPLACE FUNCTION app.audit_append(
  p_school uuid, p_actor uuid, p_login text, p_roles text[], p_action text, p_rtype text, p_rid text,
  p_success boolean, p_ip inet, p_ua text, p_meta jsonb
) RETURNS bigint LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
DECLARE
  v_key text := COALESCE(p_school::text, 'platform');
  v_prev text; v_seq bigint; v_created timestamptz := date_trunc('microseconds', clock_timestamp());
  v_id bigint; v_meta jsonb := COALESCE(p_meta, '{}'::jsonb);
BEGIN
  -- a tenant request can only append to its own chain (or the platform chain for pre-auth events)
  IF p_school IS NOT NULL AND p_school IS DISTINCT FROM app.current_school() AND NOT app.is_platform() THEN
    RAISE EXCEPTION 'AUDIT_TENANT_MISMATCH' USING ERRCODE = '42501';
  END IF;
  PERFORM pg_advisory_xact_lock(hashtextextended('audit:' || v_key, 0));
  SELECT seq, hash INTO v_seq, v_prev FROM audit_logs WHERE chain_key = v_key ORDER BY seq DESC LIMIT 1;
  v_seq := COALESCE(v_seq, 0) + 1;
  v_prev := COALESCE(v_prev, repeat('0', 64));
  INSERT INTO audit_logs (school_id, chain_key, seq, actor_user_id, actor_login, actor_roles, action, resource_type,
                          resource_id, success, ip, user_agent, metadata, created_at, prev_hash, hash)
  VALUES (p_school, v_key, v_seq, p_actor, p_login, p_roles, p_action, p_rtype, p_rid, p_success, p_ip,
          left(p_ua, 300), v_meta, v_created, v_prev,
          app.audit_row_hash(v_prev, v_seq, p_school, p_actor, p_login, p_roles, p_action, p_rtype, p_rid,
                             p_success, p_ip, left(p_ua, 300), v_meta, v_created))
  RETURNING id INTO v_id;
  RETURN v_id;
END $$;

CREATE OR REPLACE FUNCTION app.audit_verify(p_school uuid)
RETURNS TABLE (ok boolean, checked bigint, first_bad_seq bigint)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
DECLARE
  r record; v_prev text := repeat('0', 64); v_n bigint := 0; v_expect bigint := 1;
  v_key text := COALESCE(p_school::text, 'platform');
BEGIN
  IF p_school IS DISTINCT FROM app.current_school() AND NOT app.is_platform() THEN
    RAISE EXCEPTION 'AUDIT_TENANT_MISMATCH' USING ERRCODE = '42501';
  END IF;
  FOR r IN SELECT * FROM audit_logs WHERE chain_key = v_key ORDER BY seq LOOP
    IF r.seq <> v_expect OR r.prev_hash <> v_prev OR r.hash <> app.audit_row_hash(
         r.prev_hash, r.seq, r.school_id, r.actor_user_id, r.actor_login, r.actor_roles, r.action,
         r.resource_type, r.resource_id, r.success, r.ip, r.user_agent, r.metadata, r.created_at) THEN
      ok := false; checked := v_n; first_bad_seq := r.seq; RETURN NEXT; RETURN;
    END IF;
    v_prev := r.hash; v_n := v_n + 1; v_expect := v_expect + 1;
  END LOOP;
  ok := true; checked := v_n; first_bad_seq := NULL; RETURN NEXT;
END $$;

CREATE OR REPLACE FUNCTION app.deny_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'APPEND_ONLY: % on % is not allowed', TG_OP, TG_TABLE_NAME USING ERRCODE = '42501'; END $$;

CREATE TRIGGER audit_logs_no_update BEFORE UPDATE OR DELETE ON audit_logs FOR EACH ROW EXECUTE FUNCTION app.deny_mutation();
CREATE TRIGGER audit_logs_no_truncate BEFORE TRUNCATE ON audit_logs FOR EACH STATEMENT EXECUTE FUNCTION app.deny_mutation();

CREATE TABLE login_events (
  id            bigserial PRIMARY KEY,
  school_id     uuid,
  user_id       uuid,
  login_attempt text,
  success       boolean NOT NULL,
  reason        text NOT NULL,
  ip            inet,
  user_agent    text,
  created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX login_events_user_idx ON login_events (user_id, created_at DESC);
CREATE INDEX login_events_school_idx ON login_events (school_id, created_at DESC);
CREATE INDEX login_events_ip_idx ON login_events (ip, created_at DESC);
CREATE TRIGGER login_events_append_only BEFORE UPDATE OR DELETE ON login_events FOR EACH ROW EXECUTE FUNCTION app.deny_mutation();

CREATE TABLE security_events (
  id         bigserial PRIMARY KEY,
  school_id  uuid,
  user_id    uuid,
  kind       text NOT NULL,
  severity   text NOT NULL CHECK (severity IN ('info','low','medium','high','critical')),
  detail     jsonb NOT NULL DEFAULT '{}'::jsonb,
  ip         inet,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX security_events_school_idx ON security_events (school_id, created_at DESC);
CREATE INDEX security_events_sev_idx ON security_events (severity, created_at DESC);
CREATE TRIGGER security_events_append_only BEFORE UPDATE OR DELETE ON security_events FOR EACH ROW EXECUTE FUNCTION app.deny_mutation();

CREATE TABLE jobs (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id    uuid REFERENCES schools(id) ON DELETE CASCADE,
  kind         text NOT NULL,
  payload      jsonb NOT NULL DEFAULT '{}'::jsonb,
  status       text NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','running','done','failed')),
  run_at       timestamptz NOT NULL DEFAULT now(),
  attempts     integer NOT NULL DEFAULT 0,
  max_attempts integer NOT NULL DEFAULT 5,
  locked_at    timestamptz,
  locked_by    text,
  last_error   text,
  result       jsonb,
  created_by   uuid,
  created_at   timestamptz NOT NULL DEFAULT now(),
  finished_at  timestamptz
);
CREATE INDEX jobs_ready_idx ON jobs (run_at) WHERE status = 'queued';

CREATE TABLE imports (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id    uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  kind         text NOT NULL CHECK (kind IN ('students','staff','guardians','subjects','classes','scores','legacy')),
  status       text NOT NULL DEFAULT 'previewed' CHECK (status IN ('previewed','committed','failed','expired')),
  file_name    text,
  options      jsonb NOT NULL DEFAULT '{}'::jsonb,
  total_rows   integer NOT NULL DEFAULT 0,
  valid_rows   integer NOT NULL DEFAULT 0,
  errors       jsonb NOT NULL DEFAULT '[]'::jsonb,
  rows         jsonb NOT NULL DEFAULT '[]'::jsonb,
  summary      jsonb,
  created_by   uuid,
  created_at   timestamptz NOT NULL DEFAULT now(),
  committed_at timestamptz
);

CREATE TABLE promotion_runs (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id    uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  from_session uuid NOT NULL,
  to_session   uuid NOT NULL,
  summary      jsonb NOT NULL,
  moves        jsonb NOT NULL,
  created_by   uuid,
  created_at   timestamptz NOT NULL DEFAULT now(),
  undone_at    timestamptz
);
