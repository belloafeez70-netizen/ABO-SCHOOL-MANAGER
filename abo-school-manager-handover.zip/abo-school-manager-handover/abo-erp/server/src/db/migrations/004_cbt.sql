-- 004_cbt.sql — computer-based tests. Correct answers never leave the server; timing and grading
-- are server-authoritative (deadline_at is fixed at attempt start from server clock).

CREATE TABLE cbt_exams (
  id                     uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id              uuid NOT NULL,
  title                  text NOT NULL CHECK (length(title) BETWEEN 2 AND 160),
  instructions           text,
  category               text NOT NULL DEFAULT 'test' CHECK (category IN ('test','exam','practice','assignment')),
  subject_id             uuid,
  class_id               uuid,
  term_id                uuid,
  duration_minutes       integer NOT NULL CHECK (duration_minutes BETWEEN 1 AND 600),
  starts_at              timestamptz,
  ends_at                timestamptz,
  max_attempts           integer NOT NULL DEFAULT 1 CHECK (max_attempts BETWEEN 1 AND 20),
  shuffle_questions      boolean NOT NULL DEFAULT true,
  shuffle_options        boolean NOT NULL DEFAULT true,
  show_result            boolean NOT NULL DEFAULT true,
  pass_mark              numeric(5,2) NOT NULL DEFAULT 50,
  status                 text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','closed')),
  created_by             uuid,
  published_by           uuid,
  published_at           timestamptz,
  created_at             timestamptz NOT NULL DEFAULT now(),
  updated_at             timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id),
  CHECK (ends_at IS NULL OR starts_at IS NULL OR ends_at > starts_at),
  FOREIGN KEY (school_id, subject_id) REFERENCES subjects (school_id, id) ON DELETE SET NULL (subject_id),
  FOREIGN KEY (school_id, class_id)   REFERENCES classes (school_id, id) ON DELETE SET NULL (class_id),
  FOREIGN KEY (school_id, term_id)    REFERENCES terms (school_id, id) ON DELETE SET NULL (term_id)
);
CREATE INDEX cbt_exams_class_idx ON cbt_exams (school_id, class_id, status);
CREATE TRIGGER cbt_exams_touch BEFORE UPDATE ON cbt_exams FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();

CREATE TABLE cbt_questions (            -- exam_id NULL ⇒ lives in the question bank
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id     uuid NOT NULL,
  exam_id       uuid,
  subject_id    uuid,
  type          text NOT NULL CHECK (type IN ('mcq','true_false','theory')),
  text          text NOT NULL CHECK (length(text) BETWEEN 1 AND 4000),
  image_file_id uuid,
  marks         numeric(5,2) NOT NULL DEFAULT 1 CHECK (marks > 0 AND marks <= 100),
  position      integer NOT NULL DEFAULT 0,
  theory_guide  text,
  created_by    uuid,
  created_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id),
  FOREIGN KEY (school_id, exam_id)    REFERENCES cbt_exams (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, subject_id) REFERENCES subjects (school_id, id) ON DELETE SET NULL (subject_id)
);
CREATE INDEX cbt_questions_exam_idx ON cbt_questions (school_id, exam_id, position);
CREATE INDEX cbt_questions_bank_idx ON cbt_questions (school_id, subject_id) WHERE exam_id IS NULL;

CREATE TABLE cbt_options (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id   uuid NOT NULL,
  question_id uuid NOT NULL,
  text        text NOT NULL CHECK (length(text) BETWEEN 1 AND 1000),
  image_file_id uuid,
  is_correct  boolean NOT NULL DEFAULT false,
  position    integer NOT NULL DEFAULT 0,
  UNIQUE (school_id, id),
  FOREIGN KEY (school_id, question_id) REFERENCES cbt_questions (school_id, id) ON DELETE CASCADE
);
CREATE INDEX cbt_options_question_idx ON cbt_options (question_id, position);

CREATE TABLE cbt_attempts (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id        uuid NOT NULL,
  exam_id          uuid NOT NULL,
  student_id       uuid NOT NULL,
  attempt_no       integer NOT NULL DEFAULT 1,
  started_at       timestamptz NOT NULL DEFAULT now(),
  deadline_at      timestamptz NOT NULL,
  submitted_at     timestamptz,
  status           text NOT NULL DEFAULT 'in_progress' CHECK (status IN ('in_progress','submitted','auto_submitted','graded')),
  question_order   uuid[] NOT NULL,
  option_order     jsonb NOT NULL DEFAULT '{}'::jsonb,
  objective_score  numeric(7,2),
  theory_score     numeric(7,2),
  score            numeric(7,2),
  max_score        numeric(7,2),
  needs_manual_grading boolean NOT NULL DEFAULT false,
  graded_by        uuid,
  graded_at        timestamptz,
  ip               inet,
  user_agent       text,
  focus_losses     integer NOT NULL DEFAULT 0,
  UNIQUE (school_id, id),
  UNIQUE (exam_id, student_id, attempt_no),
  FOREIGN KEY (school_id, exam_id)    REFERENCES cbt_exams (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, student_id) REFERENCES students (school_id, id) ON DELETE CASCADE
);
-- only one live attempt per student per exam
CREATE UNIQUE INDEX cbt_attempts_one_live ON cbt_attempts (exam_id, student_id) WHERE status = 'in_progress';
CREATE INDEX cbt_attempts_deadline_idx ON cbt_attempts (deadline_at) WHERE status = 'in_progress';

CREATE TABLE cbt_answers (
  school_id     uuid NOT NULL,
  attempt_id    uuid NOT NULL,
  question_id   uuid NOT NULL,
  option_id     uuid,
  text_answer   text CHECK (text_answer IS NULL OR length(text_answer) <= 10000),
  is_correct    boolean,
  marks_awarded numeric(5,2),
  saved_at      timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (attempt_id, question_id),
  FOREIGN KEY (school_id, attempt_id)  REFERENCES cbt_attempts (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, question_id) REFERENCES cbt_questions (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, option_id)   REFERENCES cbt_options (school_id, id) ON DELETE SET NULL (option_id)
);
