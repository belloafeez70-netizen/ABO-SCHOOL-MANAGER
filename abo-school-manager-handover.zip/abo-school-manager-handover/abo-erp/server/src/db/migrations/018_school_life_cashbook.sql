-- 018_school_life_cashbook.sql — Phase 6 (part 1): features of the offline app moved into the server edition.
--   1. Staff clock-in / clock-out with an optional school-gate location check (distance worked out on the server)
--   2. School calendar (holidays, exams, events, meetings)
--   3. Birthdays (pupils and staff) — staff get a date of birth
--   4. Cashbook: other income, expenses and petty cash, with categories. Entries are never deleted, only voided
--      with a reason, so the book always balances and can be audited.
-- Every table carries school_id with row-level security, like the rest of the schema.

-- ───────── 0. staff date of birth (for birthdays) ─────────
ALTER TABLE staff ADD COLUMN IF NOT EXISTS date_of_birth date CHECK (date_of_birth IS NULL OR date_of_birth BETWEEN '1900-01-01' AND '2100-01-01');

-- ───────── 1. staff clock-in ─────────
CREATE TABLE clock_settings (
  school_id        uuid PRIMARY KEY REFERENCES schools(id) ON DELETE CASCADE,
  require_location boolean NOT NULL DEFAULT false,
  site_lat         double precision CHECK (site_lat IS NULL OR site_lat BETWEEN -90 AND 90),
  site_lng         double precision CHECK (site_lng IS NULL OR site_lng BETWEEN -180 AND 180),
  radius_m         integer NOT NULL DEFAULT 150 CHECK (radius_m BETWEEN 20 AND 5000),
  late_after       time NOT NULL DEFAULT '08:00',
  updated_by       uuid REFERENCES users(id),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  CHECK (NOT require_location OR (site_lat IS NOT NULL AND site_lng IS NOT NULL))
);
CREATE TRIGGER clock_settings_touch BEFORE UPDATE ON clock_settings FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();

CREATE TABLE staff_clock (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id   uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  staff_id    uuid NOT NULL,
  user_id     uuid REFERENCES users(id) ON DELETE SET NULL,
  day         date NOT NULL,                       -- the school's local date (schools.timezone)
  kind        text NOT NULL CHECK (kind IN ('in','out')),
  at          timestamptz NOT NULL DEFAULT now(),
  late        boolean NOT NULL DEFAULT false,
  lat         double precision CHECK (lat IS NULL OR lat BETWEEN -90 AND 90),
  lng         double precision CHECK (lng IS NULL OR lng BETWEEN -180 AND 180),
  accuracy_m  integer CHECK (accuracy_m IS NULL OR accuracy_m BETWEEN 0 AND 100000),
  distance_m  integer CHECK (distance_m IS NULL OR distance_m >= 0),
  device      text CHECK (device IS NULL OR length(device) <= 120),
  note        text CHECK (note IS NULL OR length(note) <= 300),
  UNIQUE (school_id, id),
  UNIQUE (school_id, staff_id, day, kind),         -- one clock-in and one clock-out per person per day
  FOREIGN KEY (school_id, staff_id) REFERENCES staff (school_id, id) ON DELETE CASCADE
);
CREATE INDEX staff_clock_day_idx ON staff_clock (school_id, day);
CREATE INDEX staff_clock_staff_idx ON staff_clock (school_id, staff_id, day DESC);

-- ───────── 2. school calendar ─────────
CREATE TABLE calendar_events (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id   uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  title       text NOT NULL CHECK (length(title) BETWEEN 2 AND 160),
  description text CHECK (description IS NULL OR length(description) <= 2000),
  kind        text NOT NULL DEFAULT 'event' CHECK (kind IN ('holiday','exam','event','meeting','other')),
  audience    text NOT NULL DEFAULT 'all' CHECK (audience IN ('all','staff')),
  starts_on   date NOT NULL,
  ends_on     date NOT NULL,
  created_by  uuid REFERENCES users(id),
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now(),
  deleted_at  timestamptz,
  UNIQUE (school_id, id),
  CHECK (ends_on >= starts_on AND ends_on - starts_on <= 366)
);
CREATE INDEX calendar_events_range_idx ON calendar_events (school_id, starts_on, ends_on) WHERE deleted_at IS NULL;
CREATE TRIGGER calendar_events_touch BEFORE UPDATE ON calendar_events FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();

-- ───────── 3. cashbook ─────────
CREATE TABLE cash_categories (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id   uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  kind        text NOT NULL CHECK (kind IN ('income','expense')),
  name        text NOT NULL CHECK (length(name) BETWEEN 2 AND 80),
  active      boolean NOT NULL DEFAULT true,
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id)
);
CREATE UNIQUE INDEX cash_categories_name_uq ON cash_categories (school_id, kind, lower(name));

CREATE TABLE cash_entries (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id    uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  kind         text NOT NULL CHECK (kind IN ('income','expense')),
  category_id  uuid NOT NULL,
  amount_kobo  bigint NOT NULL CHECK (amount_kobo > 0 AND amount_kobo <= 100000000000),
  entry_date   date NOT NULL,
  method       text NOT NULL CHECK (method IN ('cash','transfer','pos','cheque','petty_cash')),
  reference    text CHECK (reference IS NULL OR length(reference) <= 80),
  party        text CHECK (party IS NULL OR length(party) <= 160),          -- paid to / received from
  description  text NOT NULL CHECK (length(description) BETWEEN 2 AND 300),
  created_by   uuid REFERENCES users(id),
  created_at   timestamptz NOT NULL DEFAULT now(),
  voided_at    timestamptz,
  voided_by    uuid REFERENCES users(id),
  void_reason  text CHECK (void_reason IS NULL OR length(void_reason) BETWEEN 3 AND 300),
  UNIQUE (school_id, id),
  CHECK ((voided_at IS NULL) = (void_reason IS NULL)),
  FOREIGN KEY (school_id, category_id) REFERENCES cash_categories (school_id, id)
);
CREATE INDEX cash_entries_date_idx ON cash_entries (school_id, entry_date DESC) WHERE voided_at IS NULL;
CREATE INDEX cash_entries_cat_idx ON cash_entries (school_id, category_id);
-- an entry may be voided once; its money fields can never be edited afterwards (correct by voiding + re-entering)
CREATE OR REPLACE FUNCTION app.cash_entries_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF OLD.voided_at IS NOT NULL THEN RAISE EXCEPTION 'voided cashbook entries cannot be changed' USING ERRCODE = 'check_violation'; END IF;
  IF (NEW.kind, NEW.category_id, NEW.amount_kobo, NEW.entry_date, NEW.method, NEW.school_id, NEW.created_by, NEW.created_at)
     IS DISTINCT FROM (OLD.kind, OLD.category_id, OLD.amount_kobo, OLD.entry_date, OLD.method, OLD.school_id, OLD.created_by, OLD.created_at)
  THEN RAISE EXCEPTION 'cashbook amounts are never edited; void the entry and record it again' USING ERRCODE = 'check_violation'; END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER cash_entries_guard BEFORE UPDATE ON cash_entries FOR EACH ROW EXECUTE FUNCTION app.cash_entries_guard();

-- starter categories for existing schools (new schools get the same list from services/provision.js)
INSERT INTO cash_categories (school_id, kind, name)
SELECT s.id, x.kind, x.name FROM schools s CROSS JOIN (VALUES
  ('income','PTA levy'), ('income','Uniform sales'), ('income','Book sales'), ('income','Donations'), ('income','Money into petty cash'), ('income','Other income'),
  ('expense','Salaries'), ('expense','Electricity & fuel'), ('expense','Repairs & maintenance'), ('expense','Stationery & printing'), ('expense','Transport'),
  ('expense','Food & refreshments'), ('expense','Other expenses')) AS x(kind, name)
ON CONFLICT DO NOTHING;

-- ───────── row-level security ─────────
DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['clock_settings','staff_clock','calendar_events','cash_categories','cash_entries'] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY tenant_isolation ON %I USING (school_id = app.current_school()) WITH CHECK (school_id = app.current_school())', t);
  END LOOP;
END $$;

-- ───────── permissions (the catalogue sync after migrate also upserts these) + grants for existing schools ─────────
INSERT INTO permissions (key, module, description) VALUES
  ('clock.use', 'staff', 'Clock in and out (own record)'),
  ('clock.view', 'staff', 'See the staff clock-in register'),
  ('clock.manage', 'staff', 'Set the school location, distance and late time for clock-in'),
  ('calendar.view', 'academic', 'See the school calendar'),
  ('calendar.manage', 'academic', 'Add, change and remove calendar events'),
  ('birthdays.view', 'people', 'See upcoming pupil and staff birthdays'),
  ('cashbook.view', 'finance', 'See the cashbook: other income, expenses and petty cash'),
  ('cashbook.record', 'finance', 'Record income and expenses in the cashbook'),
  ('cashbook.void', 'finance', 'Void a cashbook entry (with a reason)')
ON CONFLICT (key) DO NOTHING;

INSERT INTO role_permissions (school_id, role_id, permission_key)
SELECT r.school_id, r.id, p.key
FROM roles r JOIN (
  SELECT k AS role_key, x AS key FROM unnest(ARRAY['school_owner','principal','administrator']) k,
    unnest(ARRAY['clock.use','clock.view','clock.manage','calendar.view','calendar.manage','birthdays.view','cashbook.view','cashbook.record','cashbook.void']) x
  UNION ALL
  SELECT k, x FROM unnest(ARRAY['vice_principal','head_of_school']) k, unnest(ARRAY['clock.use','clock.view','calendar.view','calendar.manage','birthdays.view']) x
  UNION ALL
  SELECT k, x FROM unnest(ARRAY['teacher','form_teacher','exam_officer','ict_officer','librarian']) k, unnest(ARRAY['clock.use','calendar.view','birthdays.view']) x
  UNION ALL
  SELECT 'accountant', x FROM unnest(ARRAY['clock.use','calendar.view','birthdays.view','cashbook.view','cashbook.record']) x
  UNION ALL
  SELECT 'bursar', x FROM unnest(ARRAY['clock.use','calendar.view','birthdays.view','cashbook.view','cashbook.record','cashbook.void']) x
  UNION ALL
  SELECT k, 'calendar.view' FROM unnest(ARRAY['parent','student']) k
) p ON p.role_key = r.key
WHERE r.is_system
ON CONFLICT DO NOTHING;
