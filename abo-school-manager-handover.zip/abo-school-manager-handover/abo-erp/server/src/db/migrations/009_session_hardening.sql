-- 009_session_hardening.sql — rotation grace window + MFA attempt counter
ALTER TABLE sessions ADD COLUMN prev_token_hash text;
ALTER TABLE sessions ADD COLUMN prev_valid_until timestamptz;
ALTER TABLE sessions ADD COLUMN mfa_failures integer NOT NULL DEFAULT 0;
CREATE INDEX sessions_prev_token_idx ON sessions (prev_token_hash) WHERE prev_token_hash IS NOT NULL;

DROP FUNCTION app.auth_session(text);
CREATE FUNCTION app.auth_session(p_token_hash text)
RETURNS TABLE (session_id uuid, user_id uuid, school_id uuid, mfa_state text, support_school_id uuid,
               support_expires_at timestamptz, idle_expires_at timestamptz, expires_at timestamptz, rotated_at timestamptz,
               user_status text, is_platform_admin boolean, school_status text, login_id text, full_name text,
               must_change_password boolean, mfa_enabled boolean, email text, via_prev boolean)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT s.id, s.user_id, s.school_id, s.mfa_state, s.support_school_id, s.support_expires_at, s.idle_expires_at,
         s.expires_at, s.rotated_at, u.status, u.is_platform_admin, sc.status, u.login_id, u.full_name,
         u.must_change_password, u.mfa_enabled, u.email, (s.token_hash <> p_token_hash)
  FROM sessions s JOIN users u ON u.id = s.user_id LEFT JOIN schools sc ON sc.id = u.school_id
  WHERE s.revoked_at IS NULL
    AND (s.token_hash = p_token_hash OR (s.prev_token_hash = p_token_hash AND s.prev_valid_until > now()))
  LIMIT 1
$$;
REVOKE ALL ON FUNCTION app.auth_session(text) FROM PUBLIC;
