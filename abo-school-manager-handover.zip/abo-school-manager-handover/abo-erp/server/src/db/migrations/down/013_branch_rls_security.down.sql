-- down for 013: removes branch policies and security helper functions (no data loss)
DROP VIEW IF EXISTS active_members;
DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['classes','students','staff','student_enrollments','attendance_records','attendance_sessions','assessments','class_subjects','timetable_entries',
    'teacher_assignments','invoices','report_cards','result_summaries','fee_discounts','cbt_attempts','cbt_results','cbt_exams'] LOOP
    EXECUTE format('DROP POLICY IF EXISTS branch_scope ON %I', t);
  END LOOP;
END $$;
DROP FUNCTION IF EXISTS app.uuid_foreign_school(uuid, uuid);
DROP FUNCTION IF EXISTS app.recent_exports(uuid);
DROP FUNCTION IF EXISTS app.respond_membership(uuid, uuid, boolean);
DROP FUNCTION IF EXISTS app.touch_membership(uuid, uuid);
DROP FUNCTION IF EXISTS app.other_memberships(uuid, uuid);
DROP FUNCTION IF EXISTS app.current_branch();
