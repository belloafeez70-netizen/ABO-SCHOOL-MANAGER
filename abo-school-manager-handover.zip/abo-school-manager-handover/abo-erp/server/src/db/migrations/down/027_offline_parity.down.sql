-- Reverse of 027 (petty cash requests, fee reminder log and the device list are removed — export them first if they
-- matter; "brought forward" invoices are kept as ordinary invoices, pending/rejected bank questions become archived).
DELETE FROM role_permissions WHERE permission_key IN ('pettycash.request','pettycash.approve','alerts.view','alerts.manage','devices.view','devices.manage');
DELETE FROM permissions WHERE key IN ('pettycash.request','pettycash.approve','alerts.view','alerts.manage','devices.view','devices.manage');
DROP TABLE IF EXISTS school_devices;
DROP TABLE IF EXISTS fee_reminders;
DROP TABLE IF EXISTS petty_cash_requests;
ALTER TABLE school_settings DROP COLUMN IF EXISTS broadsheet_layout, DROP COLUMN IF EXISTS alerts;
DROP INDEX IF EXISTS cbt_questions_pending_idx;
UPDATE cbt_questions SET status = 'archived' WHERE status IN ('pending','rejected');
ALTER TABLE cbt_questions DROP CONSTRAINT IF EXISTS cbt_questions_status_check;
ALTER TABLE cbt_questions ADD CONSTRAINT cbt_questions_status_check CHECK (status IN ('active','archived'));
ALTER TABLE cbt_questions DROP COLUMN IF EXISTS review_note, DROP COLUMN IF EXISTS reviewed_at, DROP COLUMN IF EXISTS reviewed_by;
DROP INDEX IF EXISTS invoices_one_bf_uq;
ALTER TABLE invoices DROP COLUMN IF EXISTS note, DROP COLUMN IF EXISTS kind;
UPDATE invoice_items SET kind = 'student_charge' WHERE kind = 'brought_forward';
ALTER TABLE invoice_items DROP CONSTRAINT IF EXISTS invoice_items_kind_check;
ALTER TABLE invoice_items ADD CONSTRAINT invoice_items_kind_check CHECK (kind IN ('structure','student_charge'));
