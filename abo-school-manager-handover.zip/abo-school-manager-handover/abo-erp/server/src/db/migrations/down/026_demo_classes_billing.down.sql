-- Reverse of 026 (subscription records are removed — export them first if they matter).
DROP TRIGGER IF EXISTS enrollment_class_active ON student_enrollments;
DROP FUNCTION IF EXISTS app.enrollment_class_active();
DROP FUNCTION IF EXISTS app.subscription_payment_school(text);
DROP FUNCTION IF EXISTS app.demo_school_ids();
DROP FUNCTION IF EXISTS app.demo_settings();
DROP FUNCTION IF EXISTS app.platform_trial_days();
DROP FUNCTION IF EXISTS app.platform_bank_details();
DROP TABLE IF EXISTS subscription_payments;
DROP TABLE IF EXISTS school_subscriptions;
DROP TABLE IF EXISTS subscription_plans;
DROP TABLE IF EXISTS platform_settings;
DROP INDEX IF EXISTS classes_active_idx;
ALTER TABLE classes DROP COLUMN IF EXISTS deactivated_at, DROP COLUMN IF EXISTS level, DROP COLUMN IF EXISTS active;
ALTER TABLE sessions DROP COLUMN IF EXISTS demo;
ALTER TABLE schools DROP COLUMN IF EXISTS demo_reset_at, DROP COLUMN IF EXISTS demo_dirty_at, DROP COLUMN IF EXISTS is_demo;
CREATE OR REPLACE FUNCTION app.scores_after_delete() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  PERFORM app.scores_locked(ARRAY(SELECT DISTINCT sheet_id FROM old_rows));
  INSERT INTO assessment_score_history (school_id, sheet_id, student_id, component_key, old_score, new_score, changed_by, via_correction)
    SELECT school_id, sheet_id, student_id, component_key, score, NULL, app.current_user_id(), NULLIF(current_setting('app.correction_sheet', true), '')::uuid FROM old_rows;
  RETURN NULL;
END $$;
