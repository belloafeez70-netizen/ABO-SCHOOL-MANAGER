-- Reverse of 021: removes "sign in as" and the web-address history (old addresses stop working).
UPDATE sessions SET acting_user_id = NULL, acting_expires_at = NULL, acting_reason = NULL, acting_started_at = NULL;
DELETE FROM role_permissions WHERE permission_key = 'users.impersonate';
DELETE FROM permissions WHERE key = 'users.impersonate';
DROP FUNCTION app.public_school_profile(text);
CREATE FUNCTION app.public_school_profile(p_slug text)
RETURNS TABLE (id uuid, slug text, name text, motto text, school_type text, brand_color text, has_logo boolean)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT s.id, s.slug, s.name, s.motto, s.school_type, s.brand_color,
         EXISTS (SELECT 1 FROM uploads u WHERE u.id = s.logo_file_id AND u.school_id = s.id AND u.deleted_at IS NULL AND u.scan_status <> 'infected')
  FROM schools s WHERE lower(s.slug) = lower(p_slug) AND s.status = 'active'
$$;
CREATE OR REPLACE FUNCTION app.school_slug_taken(p_slug text) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$ SELECT EXISTS (SELECT 1 FROM schools WHERE lower(slug) = lower(p_slug)) $$;
DROP TABLE IF EXISTS school_slug_history;
-- auth_session keeps the extra (unused) columns; the acting columns are dropped:
DROP FUNCTION app.auth_session(text);
ALTER TABLE sessions DROP CONSTRAINT IF EXISTS sessions_acting_complete;
ALTER TABLE sessions DROP COLUMN acting_user_id, DROP COLUMN acting_expires_at, DROP COLUMN acting_reason, DROP COLUMN acting_started_at;
CREATE FUNCTION app.auth_session(p_token_hash text)
RETURNS TABLE (session_id uuid, user_id uuid, school_id uuid, mfa_state text, support_school_id uuid,
               support_expires_at timestamptz, idle_expires_at timestamptz, expires_at timestamptz, rotated_at timestamptz,
               user_status text, is_platform_admin boolean, school_status text, membership_status text, branch_id uuid,
               login_id text, full_name text, must_change_password boolean, mfa_enabled boolean, email text, via_prev boolean)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT s.id, s.user_id, s.school_id, s.mfa_state, s.support_school_id, s.support_expires_at, s.idle_expires_at,
         s.expires_at, s.rotated_at, u.status, u.is_platform_admin, sc.status, m.status, m.branch_id, u.login_id, u.full_name,
         u.must_change_password, u.mfa_enabled, u.email, (s.token_hash <> p_token_hash)
  FROM sessions s JOIN users u ON u.id = s.user_id
  LEFT JOIN schools sc ON sc.id = s.school_id
  LEFT JOIN school_memberships m ON m.user_id = s.user_id AND m.school_id = s.school_id
  WHERE s.revoked_at IS NULL
    AND (s.token_hash = p_token_hash OR (s.prev_token_hash = p_token_hash AND s.prev_valid_until > now()))
  LIMIT 1
$$;
