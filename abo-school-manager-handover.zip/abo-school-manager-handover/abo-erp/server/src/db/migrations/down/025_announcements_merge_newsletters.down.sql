-- Reverse of 025: newsletters become writable again; the copies made in announcements are removed (the originals were never
-- changed). Announcements longer than 8,000 characters are cut back to fit the old limit.
-- (grants.sql keeps newsletters read-only for the runtime role; restore the pre-025 grants.sql together with the old code)
DELETE FROM announcements WHERE source = 'newsletter';
DROP INDEX IF EXISTS announcements_from_newsletter_uq;
UPDATE announcements SET body = left(body, 8000) WHERE length(body) > 8000;
ALTER TABLE announcements DROP COLUMN IF EXISTS draft, DROP COLUMN IF EXISTS source, DROP COLUMN IF EXISTS source_id,
  DROP COLUMN IF EXISTS emailed_at, DROP COLUMN IF EXISTS emailed_count, DROP COLUMN IF EXISTS emailed_by;
ALTER TABLE announcements DROP CONSTRAINT IF EXISTS announcements_body_check;
ALTER TABLE announcements ADD CONSTRAINT announcements_body_check CHECK (length(body) BETWEEN 1 AND 8000);
COMMENT ON TABLE newsletters IS NULL;
