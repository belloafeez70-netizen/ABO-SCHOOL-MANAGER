-- Reverse of 020 (study materials, live classes, bell times are removed — take a backup first).
DELETE FROM role_permissions WHERE permission_key LIKE 'materials.%';
DELETE FROM permissions WHERE key LIKE 'materials.%';
DROP TABLE IF EXISTS study_materials;
DROP TABLE IF EXISTS live_classes;
DROP TABLE IF EXISTS school_periods;
UPDATE uploads SET deleted_at = COALESCE(deleted_at, now()), purpose = 'document' WHERE purpose = 'study_material';
ALTER TABLE uploads DROP CONSTRAINT uploads_purpose_check;
ALTER TABLE uploads ADD CONSTRAINT uploads_purpose_check
  CHECK (purpose IN ('logo','passport','document','cbt_image','import','export','signature','lesson_note'));
