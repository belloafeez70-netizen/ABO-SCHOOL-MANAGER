-- Reverse of 018_school_life_cashbook.sql (drops the Phase 6 part-1 tables; their data is lost — take a backup first).
DELETE FROM role_permissions WHERE permission_key IN ('clock.use','clock.view','clock.manage','calendar.view','calendar.manage','birthdays.view','cashbook.view','cashbook.record','cashbook.void');
DELETE FROM permissions WHERE key IN ('clock.use','clock.view','clock.manage','calendar.view','calendar.manage','birthdays.view','cashbook.view','cashbook.record','cashbook.void');
DROP TABLE IF EXISTS cash_entries;
DROP FUNCTION IF EXISTS app.cash_entries_guard();
DROP TABLE IF EXISTS cash_categories;
DROP TABLE IF EXISTS calendar_events;
DROP TABLE IF EXISTS staff_clock;
DROP TABLE IF EXISTS clock_settings;
ALTER TABLE staff DROP COLUMN IF EXISTS date_of_birth;
