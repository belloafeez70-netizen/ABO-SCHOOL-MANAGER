-- Reverse of 028 (demo links are removed; the public demo page would need a link again only after re-applying 028).
DROP FUNCTION IF EXISTS app.demo_pass_refund(uuid);
DROP FUNCTION IF EXISTS app.demo_pass_use(text, text);
DROP FUNCTION IF EXISTS app.demo_pass_check(text);
DROP TABLE IF EXISTS demo_passes;
