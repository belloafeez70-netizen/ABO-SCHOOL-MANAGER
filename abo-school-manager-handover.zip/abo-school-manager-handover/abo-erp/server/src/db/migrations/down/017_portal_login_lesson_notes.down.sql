-- Rolls back 017. Lesson notes (and their attachments' links) are removed.
DELETE FROM role_permissions WHERE permission_key LIKE 'lesson_notes.%';
DELETE FROM permissions WHERE key LIKE 'lesson_notes.%';
DROP TABLE IF EXISTS lesson_notes;
UPDATE uploads SET deleted_at = COALESCE(deleted_at, now()), purpose = 'document' WHERE purpose = 'lesson_note';
ALTER TABLE uploads DROP CONSTRAINT uploads_purpose_check;
ALTER TABLE uploads ADD CONSTRAINT uploads_purpose_check
  CHECK (purpose IN ('logo','passport','document','cbt_image','import','export','signature'));
DROP FUNCTION IF EXISTS app.platform_admin_count();
DROP FUNCTION IF EXISTS app.auth_resolve_login(text, uuid, text);
DROP INDEX IF EXISTS students_admno_lower_idx;
DROP INDEX IF EXISTS guardians_whatsapp_norm_idx;
DROP INDEX IF EXISTS guardians_phone_norm_idx;
DROP FUNCTION IF EXISTS app.norm_phone(text);
