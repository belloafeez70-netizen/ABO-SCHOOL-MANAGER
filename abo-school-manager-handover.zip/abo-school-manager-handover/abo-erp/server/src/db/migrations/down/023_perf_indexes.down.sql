-- Reverse of 023.
DROP INDEX IF EXISTS students_name_sort_idx;
