DROP TRIGGER assessment_scores_ins ON assessment_scores; DROP TRIGGER assessment_scores_upd ON assessment_scores;
DROP TRIGGER assessment_scores_del ON assessment_scores; DROP TRIGGER assessment_scores_touch ON assessment_scores;
CREATE TRIGGER assessment_scores_guard BEFORE INSERT OR UPDATE OR DELETE ON assessment_scores FOR EACH ROW EXECUTE FUNCTION app.guard_assessment_scores();
DROP INDEX IF EXISTS invoice_items_invoice_idx; DROP INDEX IF EXISTS students_admno_trgm; DROP INDEX IF EXISTS payments_student_idx;
