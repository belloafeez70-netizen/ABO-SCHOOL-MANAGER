-- Reverse of 024 (fingerprint/face keys are removed; staff set them up again if 024 is re-applied).
ALTER TABLE staff_clock DROP COLUMN IF EXISTS verified_by;
ALTER TABLE clock_settings DROP COLUMN IF EXISTS require_biometric;
DROP TABLE IF EXISTS webauthn_challenges;
DROP TABLE IF EXISTS webauthn_credentials;
