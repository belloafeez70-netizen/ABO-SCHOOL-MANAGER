-- Rolls back 016 schema additions. Rows using the new question types / void attempts must be removed first.
DROP TRIGGER IF EXISTS cbt_questions_touch ON cbt_questions;
DELETE FROM imports WHERE kind = 'cbt_questions';
ALTER TABLE imports DROP CONSTRAINT imports_kind_check;
ALTER TABLE imports ADD CONSTRAINT imports_kind_check CHECK (kind IN ('students','staff','guardians','subjects','classes','scores','legacy'));
DELETE FROM cbt_attempts WHERE status = 'void';
DELETE FROM cbt_questions WHERE type IN ('multi_select','short_answer','numeric','fill_blank');
UPDATE cbt_exams SET category = 'test' WHERE category IN ('ca','mock');
ALTER TABLE school_settings DROP COLUMN IF EXISTS cbt;
ALTER TABLE cbt_results DROP COLUMN IF EXISTS released, DROP COLUMN IF EXISTS released_at, DROP COLUMN IF EXISTS released_by, DROP COLUMN IF EXISTS withheld_reason;
DROP INDEX IF EXISTS cbt_answers_question_idx;
ALTER TABLE cbt_answers DROP COLUMN IF EXISTS option_ids, DROP COLUMN IF EXISTS flagged, DROP COLUMN IF EXISTS time_spent_seconds;
DROP INDEX IF EXISTS cbt_attempts_exam_idx;
ALTER TABLE cbt_attempts DROP COLUMN IF EXISTS furthest_index, DROP COLUMN IF EXISTS void_reason, DROP COLUMN IF EXISTS voided_by, DROP COLUMN IF EXISTS voided_at;
ALTER TABLE cbt_attempts DROP CONSTRAINT cbt_attempts_status_check;
ALTER TABLE cbt_attempts ADD CONSTRAINT cbt_attempts_status_check CHECK (status IN ('in_progress','submitted','auto_submitted','graded'));
DROP TABLE IF EXISTS cbt_exam_candidates;
DROP INDEX IF EXISTS cbt_exams_window_idx; DROP INDEX IF EXISTS cbt_exams_subject_idx;
ALTER TABLE cbt_exams DROP CONSTRAINT IF EXISTS cbt_exams_session_fk;
ALTER TABLE cbt_exams DROP COLUMN IF EXISTS session_id, DROP COLUMN IF EXISTS allow_back_nav, DROP COLUMN IF EXISTS allow_review, DROP COLUMN IF EXISTS show_answers,
  DROP COLUMN IF EXISTS allow_resume, DROP COLUMN IF EXISTS fullscreen, DROP COLUMN IF EXISTS autosave, DROP COLUMN IF EXISTS access_code_hash,
  DROP COLUMN IF EXISTS score_component, DROP COLUMN IF EXISTS score_policy, DROP COLUMN IF EXISTS scores_pushed_at, DROP COLUMN IF EXISTS scores_pushed_by;
ALTER TABLE cbt_exams DROP CONSTRAINT cbt_exams_category_check;
ALTER TABLE cbt_exams ADD CONSTRAINT cbt_exams_category_check CHECK (category IN ('test','exam','practice','assignment'));
DROP INDEX IF EXISTS cbt_questions_source_idx; DROP INDEX IF EXISTS cbt_questions_text_trgm; DROP INDEX IF EXISTS cbt_questions_topic_idx; DROP INDEX IF EXISTS cbt_questions_bank_idx;
CREATE INDEX cbt_questions_bank_idx ON cbt_questions (school_id, subject_id) WHERE exam_id IS NULL;
ALTER TABLE cbt_questions DROP CONSTRAINT IF EXISTS cbt_questions_class_fk, DROP CONSTRAINT IF EXISTS cbt_questions_session_fk, DROP CONSTRAINT IF EXISTS cbt_questions_term_fk;
ALTER TABLE cbt_questions DROP COLUMN IF EXISTS class_id, DROP COLUMN IF EXISTS session_id, DROP COLUMN IF EXISTS term_id, DROP COLUMN IF EXISTS topic, DROP COLUMN IF EXISTS subtopic,
  DROP COLUMN IF EXISTS difficulty, DROP COLUMN IF EXISTS explanation, DROP COLUMN IF EXISTS answer_key, DROP COLUMN IF EXISTS status, DROP COLUMN IF EXISTS source_question_id,
  DROP COLUMN IF EXISTS updated_at, DROP COLUMN IF EXISTS updated_by;
ALTER TABLE cbt_questions DROP CONSTRAINT cbt_questions_type_check;
ALTER TABLE cbt_questions ADD CONSTRAINT cbt_questions_type_check CHECK (type IN ('mcq','true_false','theory'));
