-- Reverse of 019_store_sales.sql (drops the store tables and their history — take a backup first).
DELETE FROM role_permissions WHERE permission_key LIKE 'store.%';
DELETE FROM permissions WHERE key LIKE 'store.%';
DROP TABLE IF EXISTS store_moves;
DROP TABLE IF EXISTS store_sale_lines;
DROP TABLE IF EXISTS store_sales;
DROP TABLE IF EXISTS store_items;
DROP FUNCTION IF EXISTS app.store_sales_guard();
DROP FUNCTION IF EXISTS app.no_change();
