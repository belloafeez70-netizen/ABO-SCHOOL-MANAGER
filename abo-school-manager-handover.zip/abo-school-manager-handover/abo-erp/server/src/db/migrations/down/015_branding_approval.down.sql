DROP FUNCTION IF EXISTS app.school_email_verified(uuid);
DROP FUNCTION IF EXISTS app.platform_school_owners(uuid);
DROP FUNCTION IF EXISTS app.public_school_logo(text);
DROP FUNCTION IF EXISTS app.public_school_profile(text);
ALTER TABLE schools DROP CONSTRAINT IF EXISTS schools_head_signature_fk;
ALTER TABLE schools DROP COLUMN IF EXISTS brand_color, DROP COLUMN IF EXISTS head_name, DROP COLUMN IF EXISTS head_title,
  DROP COLUMN IF EXISTS head_phone, DROP COLUMN IF EXISTS head_email, DROP COLUMN IF EXISTS head_signature_file_id,
  DROP COLUMN IF EXISTS approved_at, DROP COLUMN IF EXISTS approved_by;
