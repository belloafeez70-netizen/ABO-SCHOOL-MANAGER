-- 017_portal_login_lesson_notes.sql — website parity:
--   1. Student sign-in with ADMISSION NUMBER and parent sign-in with PHONE NUMBER (school-scoped, unambiguous only).
--   2. Lesson Notes module: teachers write weekly notes for their assigned class/subject, heads review them,
--      approved notes can be shared with the class (students and parents read-only).

-- ───────── 1. alternative sign-in identifiers ─────────
-- Nigerian phone normalisation: "+234 803 000 0001", "2348030000001", "0803-000-0001", "8030000001" → "08030000001"
CREATE OR REPLACE FUNCTION app.norm_phone(p text) RETURNS text
LANGUAGE sql IMMUTABLE PARALLEL SAFE AS $$
  SELECT CASE WHEN d ~ '^234[0-9]{10}$' THEN '0' || substr(d, 4)
              WHEN d ~ '^[1-9][0-9]{9}$' THEN '0' || d
              ELSE d END
  FROM (SELECT regexp_replace(coalesce(p, ''), '[^0-9]', '', 'g') AS d) x
$$;

CREATE INDEX IF NOT EXISTS guardians_phone_norm_idx ON guardians (app.norm_phone(phone)) WHERE user_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS guardians_whatsapp_norm_idx ON guardians (app.norm_phone(whatsapp)) WHERE user_id IS NOT NULL AND whatsapp IS NOT NULL;
CREATE INDEX IF NOT EXISTS students_admno_lower_idx ON students (lower(admission_no)) WHERE user_id IS NOT NULL AND deleted_at IS NULL;

-- Resolve an admission number (kind 'admission') or phone number (kind 'phone') to the account's Login ID.
-- Scoped to one school when p_school is given (the school's own sign-in page). Returns NULL unless EXACTLY one
-- account matches, so a phone shared by two parents (or reused across schools) can never sign in the wrong person.
-- SECURITY DEFINER because it runs before a session/tenant exists; it returns only a login_id.
CREATE OR REPLACE FUNCTION app.auth_resolve_login(p_ident text, p_school uuid, p_kind text) RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  WITH m AS (
    SELECT u.login_id FROM students s
      JOIN users u ON u.id = s.user_id
      JOIN schools sc ON sc.id = s.school_id AND sc.status = 'active'
     WHERE p_kind = 'admission' AND s.user_id IS NOT NULL AND s.deleted_at IS NULL
       AND lower(s.admission_no) = lower(btrim(p_ident))
       AND (p_school IS NULL OR s.school_id = p_school)
    UNION
    SELECT u.login_id FROM guardians g
      JOIN users u ON u.id = g.user_id
      JOIN schools sc ON sc.id = g.school_id AND sc.status = 'active'
     WHERE p_kind = 'phone' AND g.user_id IS NOT NULL AND length(app.norm_phone(p_ident)) BETWEEN 10 AND 14
       AND (app.norm_phone(g.phone) = app.norm_phone(p_ident) OR app.norm_phone(g.whatsapp) = app.norm_phone(p_ident))
       AND (p_school IS NULL OR g.school_id = p_school)
  )
  SELECT CASE WHEN count(*) = 1 THEN min(login_id) END FROM m
$$;

-- go-live preflight: number of active platform administrators (no identities returned)
CREATE OR REPLACE FUNCTION app.platform_admin_count() RETURNS integer
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT count(*)::int FROM users WHERE is_platform_admin AND status = 'active'
$$;

-- ───────── 2. lesson notes ─────────
ALTER TABLE uploads DROP CONSTRAINT uploads_purpose_check;
ALTER TABLE uploads ADD CONSTRAINT uploads_purpose_check
  CHECK (purpose IN ('logo','passport','document','cbt_image','import','export','signature','lesson_note'));

CREATE TABLE lesson_notes (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id      uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  term_id        uuid NOT NULL,
  class_id       uuid NOT NULL,
  subject_id     uuid NOT NULL,
  staff_id       uuid,                                   -- the teacher's staff record (NULL for non-teaching authors)
  author_id      uuid NOT NULL REFERENCES users(id),
  week           smallint NOT NULL CHECK (week BETWEEN 1 AND 16),
  lesson_date    date,
  duration       text CHECK (duration IS NULL OR length(duration) <= 40),
  topic          text NOT NULL CHECK (length(topic) BETWEEN 2 AND 200),
  subtopic       text CHECK (subtopic IS NULL OR length(subtopic) <= 200),
  objectives     text CHECK (objectives IS NULL OR length(objectives) <= 4000),
  materials      text CHECK (materials IS NULL OR length(materials) <= 2000),
  prior_knowledge text CHECK (prior_knowledge IS NULL OR length(prior_knowledge) <= 2000),
  content        text NOT NULL CHECK (length(content) BETWEEN 1 AND 60000),
  evaluation     text CHECK (evaluation IS NULL OR length(evaluation) <= 4000),
  assignment     text CHECK (assignment IS NULL OR length(assignment) <= 4000),
  file_id        uuid,
  share_with_class boolean NOT NULL DEFAULT true,       -- only APPROVED notes are ever visible to learners
  status         text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','submitted','approved','returned')),
  version        integer NOT NULL DEFAULT 1,
  submitted_at   timestamptz,
  reviewed_by    uuid REFERENCES users(id),
  reviewed_at    timestamptz,
  review_note    text CHECK (review_note IS NULL OR length(review_note) <= 2000),
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now(),
  deleted_at     timestamptz,
  UNIQUE (school_id, id),
  FOREIGN KEY (school_id, term_id)    REFERENCES terms (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, class_id)   REFERENCES classes (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, subject_id) REFERENCES subjects (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, staff_id)   REFERENCES staff (school_id, id) ON DELETE SET NULL (staff_id),
  FOREIGN KEY (school_id, file_id)    REFERENCES uploads (school_id, id) ON DELETE SET NULL (file_id)
);
CREATE INDEX lesson_notes_list_idx ON lesson_notes (school_id, term_id, class_id, subject_id, week) WHERE deleted_at IS NULL;
CREATE INDEX lesson_notes_author_idx ON lesson_notes (school_id, author_id, updated_at DESC) WHERE deleted_at IS NULL;
CREATE INDEX lesson_notes_queue_idx ON lesson_notes (school_id, status, submitted_at) WHERE deleted_at IS NULL;
CREATE TRIGGER lesson_notes_touch BEFORE UPDATE ON lesson_notes FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();

ALTER TABLE lesson_notes ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON lesson_notes USING (school_id = app.current_school()) WITH CHECK (school_id = app.current_school());
CREATE POLICY branch_scope ON lesson_notes AS RESTRICTIVE
  USING (app.current_branch() IS NULL OR EXISTS (SELECT 1 FROM classes c WHERE c.id = lesson_notes.class_id));

-- ───────── permissions (the catalogue sync after migrate also upserts these) + grants for existing schools ─────────
INSERT INTO permissions (key, module, description) VALUES
  ('lesson_notes.create', 'academic', 'Write lesson notes for classes/subjects assigned to you'),
  ('lesson_notes.view', 'academic', 'View every lesson note in the school'),
  ('lesson_notes.review', 'academic', 'Approve or return submitted lesson notes'),
  ('lesson_notes.view_own', 'academic', 'Student: read approved lesson notes for own class'),
  ('lesson_notes.view_children', 'academic', 'Parent: read approved lesson notes for children’s classes')
ON CONFLICT (key) DO NOTHING;

INSERT INTO role_permissions (school_id, role_id, permission_key)
SELECT r.school_id, r.id, p.key
FROM roles r JOIN (VALUES
    ('teacher','lesson_notes.create'), ('form_teacher','lesson_notes.create'),
    ('vice_principal','lesson_notes.create'), ('vice_principal','lesson_notes.view'), ('vice_principal','lesson_notes.review'),
    ('head_of_school','lesson_notes.create'), ('head_of_school','lesson_notes.view'), ('head_of_school','lesson_notes.review'),
    ('exam_officer','lesson_notes.create'), ('exam_officer','lesson_notes.view'),
    ('principal','lesson_notes.create'), ('principal','lesson_notes.view'), ('principal','lesson_notes.review'),
    ('school_owner','lesson_notes.create'), ('school_owner','lesson_notes.view'), ('school_owner','lesson_notes.review'),
    ('administrator','lesson_notes.create'), ('administrator','lesson_notes.view'), ('administrator','lesson_notes.review'),
    ('student','lesson_notes.view_own'), ('parent','lesson_notes.view_children')
  ) AS p(role_key, key) ON p.role_key = r.key
WHERE r.is_system
ON CONFLICT DO NOTHING;
