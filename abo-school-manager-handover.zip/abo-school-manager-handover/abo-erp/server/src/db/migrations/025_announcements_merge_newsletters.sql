-- 025_announcements_merge_newsletters.sql — Newsletters are retired: one place for school news (Announcements).
-- • Every newsletter (published and draft) is copied into announcements, keeping its date, author and audience.
--   Drafts stay drafts (announcements gain a `draft` flag — drafts are only visible to people who manage notices).
-- • Announcements can now hold a long letter (up to 60,000 characters, like newsletters did).
-- • Sharing to parents by email is recorded on the announcement (when, how many, by whom) so it is not sent twice by mistake.
-- • The newsletters table is kept, read-only, for history and for rollback (down migration).
ALTER TABLE announcements DROP CONSTRAINT IF EXISTS announcements_body_check;
ALTER TABLE announcements ADD CONSTRAINT announcements_body_check CHECK (length(body) BETWEEN 1 AND 60000);
ALTER TABLE announcements
  ADD COLUMN draft         boolean NOT NULL DEFAULT false,
  ADD COLUMN source        text NOT NULL DEFAULT 'announcement' CHECK (source IN ('announcement','newsletter')),
  ADD COLUMN source_id     uuid,
  ADD COLUMN emailed_at    timestamptz,
  ADD COLUMN emailed_count integer NOT NULL DEFAULT 0 CHECK (emailed_count >= 0),
  ADD COLUMN emailed_by    uuid;
CREATE UNIQUE INDEX announcements_from_newsletter_uq ON announcements (source_id) WHERE source = 'newsletter';

INSERT INTO announcements (school_id, title, body, audience, priority, pinned, publish_at, created_by, created_at, draft, source, source_id)
SELECT n.school_id, n.title, CASE WHEN length(btrim(n.body)) = 0 THEN '(empty)' ELSE n.body END, n.audience, 'normal', false,
       COALESCE(n.published_at, n.created_at), n.created_by, n.created_at, n.status <> 'published', 'newsletter', n.id
FROM newsletters n
WHERE NOT EXISTS (SELECT 1 FROM announcements a WHERE a.source = 'newsletter' AND a.source_id = n.id);

COMMENT ON TABLE newsletters IS 'Retired 11 Oct 2026: merged into announcements (source = newsletter). Read-only history; kept for rollback.';
-- the runtime role can no longer write newsletters: see grants.sql (re-applied after every migration run)
