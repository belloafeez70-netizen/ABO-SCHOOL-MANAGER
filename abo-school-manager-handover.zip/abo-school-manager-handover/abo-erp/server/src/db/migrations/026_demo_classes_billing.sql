-- 026_demo_classes_billing.sql
-- 1) Demo schools: two advertising schools, strictly separate tenants (RLS as usual), flagged is_demo. Visitors get a
--    5-minute session (server-enforced expiry); the sample data is restored after the last demo session ends.
-- 2) Flexible classes: a class can be switched off (kept with all its records) and given a level label
--    (Creche, Nursery, Kindergarten, Primary, JSS, SS or a school's own level).
-- 3) Subscriptions & payments (platform owner): plans, platform payment settings (gateway secret stored ENCRYPTED by
--    the API, never returned), each school's subscription and every payment attempt. A payment is "success" only after
--    the server verified it with the gateway.
ALTER TABLE schools ADD COLUMN is_demo boolean NOT NULL DEFAULT false,
                    ADD COLUMN demo_dirty_at timestamptz,
                    ADD COLUMN demo_reset_at timestamptz;
ALTER TABLE sessions ADD COLUMN demo boolean NOT NULL DEFAULT false;

ALTER TABLE classes ADD COLUMN active boolean NOT NULL DEFAULT true,
                    ADD COLUMN level text CHECK (level IS NULL OR length(level) BETWEEN 1 AND 40),
                    ADD COLUMN deactivated_at timestamptz;
CREATE INDEX classes_active_idx ON classes (school_id, active, sort_order);

-- platform-wide settings (one row). Secrets are AES-256-GCM ciphertext produced by the API (DATA_ENCRYPTION_KEY).
CREATE TABLE platform_settings (
  id                   boolean PRIMARY KEY DEFAULT true CHECK (id),
  demo_enabled         boolean NOT NULL DEFAULT true,
  demo_minutes         integer NOT NULL DEFAULT 5 CHECK (demo_minutes BETWEEN 1 AND 5),
  trial_days           integer NOT NULL DEFAULT 14 CHECK (trial_days BETWEEN 0 AND 90),
  currency             text NOT NULL DEFAULT 'NGN' CHECK (currency IN ('NGN','GHS','KES','ZAR','USD')),
  gateway              text NOT NULL DEFAULT 'paystack' CHECK (gateway IN ('paystack')),
  paystack_public_key  text CHECK (paystack_public_key IS NULL OR paystack_public_key ~ '^pk_(test|live)_[A-Za-z0-9]{8,80}$'),
  paystack_secret_enc  text,
  paystack_secret_hint text,                     -- e.g. sk_live_…a1b2 (shown to the owner instead of the key)
  bank_details         text CHECK (bank_details IS NULL OR length(bank_details) <= 500),
  updated_by           uuid,
  updated_at           timestamptz NOT NULL DEFAULT now()
);
INSERT INTO platform_settings (id) VALUES (true);

CREATE TABLE subscription_plans (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code         text NOT NULL UNIQUE CHECK (code ~ '^[a-z0-9_-]{2,30}$'),
  name         text NOT NULL CHECK (length(name) BETWEEN 2 AND 60),
  description  text CHECK (description IS NULL OR length(description) <= 300),
  price_kobo   bigint NOT NULL CHECK (price_kobo >= 0 AND price_kobo <= 100000000000),
  period       text NOT NULL CHECK (period IN ('month','term','year')),
  period_days  integer NOT NULL CHECK (period_days BETWEEN 1 AND 400),
  active       boolean NOT NULL DEFAULT true,
  sort_order   integer NOT NULL DEFAULT 0,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);
INSERT INTO subscription_plans (code, name, description, price_kobo, period, period_days, sort_order) VALUES
  ('termly', 'Term plan', 'Everything for one school term.', 1500000, 'term', 120, 1),
  ('yearly', 'Yearly plan', 'Three terms — best value.', 5000000, 'year', 365, 2);

CREATE TABLE school_subscriptions (
  school_id          uuid PRIMARY KEY REFERENCES schools(id) ON DELETE CASCADE,
  plan_id            uuid REFERENCES subscription_plans(id),
  status             text NOT NULL DEFAULT 'trial' CHECK (status IN ('trial','active','past_due','expired','cancelled')),
  trial_ends_at      timestamptz,
  current_period_end timestamptz,
  note               text CHECK (note IS NULL OR length(note) <= 300),
  updated_by         uuid,
  updated_at         timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE subscription_payments (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id    uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  plan_id      uuid NOT NULL REFERENCES subscription_plans(id),
  reference    text NOT NULL UNIQUE CHECK (reference ~ '^SUB-[A-Za-z0-9-]{8,60}$'),
  amount_kobo  bigint NOT NULL CHECK (amount_kobo >= 0),
  currency     text NOT NULL DEFAULT 'NGN',
  status       text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','success','failed','abandoned','manual')),
  provider     text NOT NULL DEFAULT 'paystack',
  verified_at  timestamptz,
  gateway_status text,
  period_end_after timestamptz,
  created_by   uuid,
  created_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id)
);
CREATE INDEX subscription_payments_school_idx ON subscription_payments (school_id, created_at DESC);

-- every existing (non-demo) school starts on a trial that ends 14 days from now (the owner can change it)
INSERT INTO school_subscriptions (school_id, status, trial_ends_at)
SELECT id, 'trial', now() + interval '14 days' FROM schools ON CONFLICT DO NOTHING;

-- RLS: a school sees only its own subscription and payments; platform mode sees all. Plans are readable by everyone
-- signed in (prices are public); platform settings only in platform mode (and the secret is ciphertext anyway).
ALTER TABLE school_subscriptions ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_or_platform ON school_subscriptions USING (school_id = app.current_school() OR app.is_platform()) WITH CHECK (app.is_platform());
-- a newly registered school may create ITS OWN trial row (nothing else); only the platform can activate or extend it
CREATE POLICY own_trial_insert ON school_subscriptions FOR INSERT WITH CHECK (school_id = app.current_school() AND status = 'trial' AND plan_id IS NULL AND current_period_end IS NULL);
ALTER TABLE subscription_payments ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_or_platform ON subscription_payments USING (school_id = app.current_school() OR app.is_platform()) WITH CHECK (school_id = app.current_school() OR app.is_platform());
ALTER TABLE subscription_plans ENABLE ROW LEVEL SECURITY;
CREATE POLICY plans_read ON subscription_plans FOR SELECT USING (true);
CREATE POLICY plans_platform_write ON subscription_plans FOR ALL USING (app.is_platform()) WITH CHECK (app.is_platform());
ALTER TABLE platform_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY platform_only ON platform_settings USING (app.is_platform()) WITH CHECK (app.is_platform());

-- the few lookups needed before a tenant/platform context exists (demo start, payment webhook)
CREATE OR REPLACE FUNCTION app.demo_settings()
RETURNS TABLE (demo_enabled boolean, demo_minutes integer)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT demo_enabled, demo_minutes FROM platform_settings WHERE id
$$;
CREATE OR REPLACE FUNCTION app.demo_school_ids()
RETURNS TABLE (id uuid, slug text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT id, slug FROM schools WHERE is_demo AND status = 'active'
$$;
CREATE OR REPLACE FUNCTION app.platform_trial_days()
RETURNS integer LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT trial_days FROM platform_settings WHERE id
$$;
CREATE OR REPLACE FUNCTION app.platform_bank_details()
RETURNS text LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT bank_details FROM platform_settings WHERE id
$$;
CREATE OR REPLACE FUNCTION app.subscription_payment_school(p_reference text)
RETURNS uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT school_id FROM subscription_payments WHERE reference = p_reference
$$;

-- a switched-off class takes no new pupils (its old records stay); switch it on again to use it
CREATE OR REPLACE FUNCTION app.enrollment_class_active() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NOT COALESCE((SELECT active FROM classes WHERE id = NEW.class_id), true) THEN
    RAISE EXCEPTION 'CLASS_INACTIVE: this class is switched off — switch it on under Classes & Arms first' USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER enrollment_class_active BEFORE INSERT OR UPDATE OF class_id ON student_enrollments FOR EACH ROW EXECUTE FUNCTION app.enrollment_class_active();

-- restoring a demo school deletes it and builds it again: its published score sheets must not block that, and the
-- deleted demo scores are not "changes" worth keeping in the score history. Only the demo reset sets app.demo_reset.
CREATE OR REPLACE FUNCTION app.scores_after_delete() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF current_setting('app.demo_reset', true) = 'on' THEN RETURN NULL; END IF;
  PERFORM app.scores_locked(ARRAY(SELECT DISTINCT sheet_id FROM old_rows));
  INSERT INTO assessment_score_history (school_id, sheet_id, student_id, component_key, old_score, new_score, changed_by, via_correction)
    SELECT school_id, sheet_id, student_id, component_key, score, NULL, app.current_user_id(), NULLIF(current_setting('app.correction_sheet', true), '')::uuid FROM old_rows;
  RETURN NULL;
END $$;
