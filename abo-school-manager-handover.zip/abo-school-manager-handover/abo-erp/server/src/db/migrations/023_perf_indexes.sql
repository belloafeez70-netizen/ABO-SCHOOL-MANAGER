-- 023_perf_indexes.sql — Phase 7 (load test at 1,000 schools / 200,000 users).
-- The pupil list is ordered by "surname first name"; with this index the database reads the 25 pupils of a page in
-- order instead of sorting the whole school (matters for schools with thousands of pupils).
CREATE INDEX IF NOT EXISTS students_name_sort_idx ON students (school_id, status, ((last_name || ' ') || first_name)) WHERE deleted_at IS NULL;
