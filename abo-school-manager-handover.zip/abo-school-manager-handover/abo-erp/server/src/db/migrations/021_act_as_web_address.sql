-- 021_act_as_web_address.sql — Phase 6 (part 4)
--   1. "Sign in as" (act as) for the school owner: the owner's OWN session temporarily carries another member of the
--      same school. Time-limited, with a written reason, audited, and blocked from security settings (see auth plugin).
--   2. School web address: the school can change its address (slug); old addresses keep working (history).

-- ───────── 1. act as ─────────
ALTER TABLE sessions ADD COLUMN acting_user_id uuid REFERENCES users(id) ON DELETE SET NULL;
ALTER TABLE sessions ADD COLUMN acting_expires_at timestamptz;
ALTER TABLE sessions ADD COLUMN acting_reason text CHECK (acting_reason IS NULL OR length(acting_reason) BETWEEN 5 AND 300);
ALTER TABLE sessions ADD COLUMN acting_started_at timestamptz;
ALTER TABLE sessions ADD CONSTRAINT sessions_acting_complete CHECK ((acting_user_id IS NULL) = (acting_expires_at IS NULL) AND acting_user_id IS DISTINCT FROM user_id);

DROP FUNCTION app.auth_session(text);
CREATE FUNCTION app.auth_session(p_token_hash text)
RETURNS TABLE (session_id uuid, user_id uuid, school_id uuid, mfa_state text, support_school_id uuid,
               support_expires_at timestamptz, idle_expires_at timestamptz, expires_at timestamptz, rotated_at timestamptz,
               user_status text, is_platform_admin boolean, school_status text, membership_status text, branch_id uuid,
               login_id text, full_name text, must_change_password boolean, mfa_enabled boolean, email text, via_prev boolean,
               acting_user_id uuid, acting_expires_at timestamptz, acting_reason text, acting_started_at timestamptz,
               acting_login_id text, acting_full_name text, acting_user_status text, acting_is_platform boolean,
               acting_membership_status text, acting_branch_id uuid)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT s.id, s.user_id, s.school_id, s.mfa_state, s.support_school_id, s.support_expires_at, s.idle_expires_at,
         s.expires_at, s.rotated_at, u.status, u.is_platform_admin, sc.status, m.status, m.branch_id, u.login_id, u.full_name,
         u.must_change_password, u.mfa_enabled, u.email, (s.token_hash <> p_token_hash),
         s.acting_user_id, s.acting_expires_at, s.acting_reason, s.acting_started_at,
         t.login_id, t.full_name, t.status, t.is_platform_admin, tm.status, tm.branch_id
  FROM sessions s JOIN users u ON u.id = s.user_id
  LEFT JOIN schools sc ON sc.id = s.school_id
  LEFT JOIN school_memberships m ON m.user_id = s.user_id AND m.school_id = s.school_id
  LEFT JOIN users t ON t.id = s.acting_user_id
  LEFT JOIN school_memberships tm ON tm.user_id = s.acting_user_id AND tm.school_id = s.school_id
  WHERE s.revoked_at IS NULL
    AND (s.token_hash = p_token_hash OR (s.prev_token_hash = p_token_hash AND s.prev_valid_until > now()))
  LIMIT 1
$$;

INSERT INTO permissions (key, module, description) VALUES
  ('users.impersonate', 'users', 'Sign in as another member of the school for a short, recorded time (owner only by default)')
ON CONFLICT (key) DO NOTHING;
INSERT INTO role_permissions (school_id, role_id, permission_key)
SELECT r.school_id, r.id, 'users.impersonate' FROM roles r WHERE r.is_system AND r.key = 'school_owner'
ON CONFLICT DO NOTHING;

-- ───────── 2. school web address history ─────────
CREATE TABLE school_slug_history (
  slug        text PRIMARY KEY CHECK (slug ~ '^[a-z0-9-]{3,40}$'),
  school_id   uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  replaced_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX school_slug_history_lower_uq ON school_slug_history (lower(slug));
ALTER TABLE school_slug_history ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_or_platform ON school_slug_history USING (school_id = app.current_school() OR app.is_platform()) WITH CHECK (school_id = app.current_school() OR app.is_platform());

-- an address is taken if any school uses it now or used it before (old printed links must never point elsewhere)
CREATE OR REPLACE FUNCTION app.school_slug_taken(p_slug text) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT EXISTS (SELECT 1 FROM schools WHERE lower(slug) = lower(p_slug)) OR EXISTS (SELECT 1 FROM school_slug_history WHERE lower(slug) = lower(p_slug))
$$;

-- public profile: an old address finds the school too (the reply carries the CURRENT address, so the page can move on)
DROP FUNCTION app.public_school_profile(text);
CREATE FUNCTION app.public_school_profile(p_slug text)
RETURNS TABLE (id uuid, slug text, name text, motto text, school_type text, brand_color text, has_logo boolean)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT s.id, s.slug, s.name, s.motto, s.school_type, s.brand_color,
         EXISTS (SELECT 1 FROM uploads u WHERE u.id = s.logo_file_id AND u.school_id = s.id AND u.deleted_at IS NULL AND u.scan_status <> 'infected')
  FROM schools s
  WHERE s.status = 'active' AND (lower(s.slug) = lower(p_slug) OR s.id = (SELECT h.school_id FROM school_slug_history h WHERE lower(h.slug) = lower(p_slug)))
  LIMIT 1
$$;
