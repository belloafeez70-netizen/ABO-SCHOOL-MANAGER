-- 013_branch_rls_security.sql — branch-level isolation (RESTRICTIVE policies AND-ed with tenant policies)
-- and helpers for security-event detection.
CREATE OR REPLACE FUNCTION app.current_branch() RETURNS uuid
  LANGUAGE sql STABLE AS $$ SELECT NULLIF(current_setting('app.branch_id', true), '')::uuid $$;

-- A branch-restricted member (school_memberships.branch_id set) only sees rows of that branch.
-- Whole-school members (branch NULL) are unaffected. Rows without a branch are hidden from branch-restricted users.
CREATE POLICY branch_scope ON classes AS RESTRICTIVE
  USING (app.current_branch() IS NULL OR branch_id = app.current_branch());
CREATE POLICY branch_scope ON students AS RESTRICTIVE
  USING (app.current_branch() IS NULL OR branch_id = app.current_branch());
CREATE POLICY branch_scope ON staff AS RESTRICTIVE
  USING (app.current_branch() IS NULL OR branch_id = app.current_branch());
DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['student_enrollments','attendance_records','attendance_sessions','assessments','class_subjects','timetable_entries','teacher_assignments'] LOOP
    EXECUTE format('CREATE POLICY branch_scope ON %I AS RESTRICTIVE USING (app.current_branch() IS NULL OR EXISTS (SELECT 1 FROM classes c WHERE c.id = %I.class_id))', t, t);
  END LOOP;
  FOREACH t IN ARRAY ARRAY['invoices','report_cards','result_summaries','fee_discounts','cbt_attempts','cbt_results'] LOOP
    EXECUTE format('CREATE POLICY branch_scope ON %I AS RESTRICTIVE USING (app.current_branch() IS NULL OR EXISTS (SELECT 1 FROM students s WHERE s.id = %I.student_id))', t, t);
  END LOOP;
END $$;
CREATE POLICY branch_scope ON cbt_exams AS RESTRICTIVE
  USING (app.current_branch() IS NULL OR class_id IS NULL OR EXISTS (SELECT 1 FROM classes c WHERE c.id = cbt_exams.class_id));
-- (the EXISTS sub-queries are themselves filtered by the classes/students branch policies above)

-- Cross-tenant probe detection: given an id that was NOT found in the caller's school, report whether it
-- exists in another school (only the boolean + owning school id are returned, never data; platform-only callers
-- see the school id — the API only uses the boolean to raise a security event).
CREATE OR REPLACE FUNCTION app.uuid_foreign_school(p_id uuid, p_school uuid) RETURNS uuid
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
DECLARE r uuid;
BEGIN
  SELECT school_id INTO r FROM (
    SELECT school_id FROM students WHERE id = p_id UNION ALL SELECT school_id FROM staff WHERE id = p_id
    UNION ALL SELECT school_id FROM classes WHERE id = p_id UNION ALL SELECT school_id FROM assessments WHERE id = p_id
    UNION ALL SELECT school_id FROM invoices WHERE id = p_id UNION ALL SELECT school_id FROM payments WHERE id = p_id
    UNION ALL SELECT school_id FROM cbt_exams WHERE id = p_id UNION ALL SELECT school_id FROM cbt_attempts WHERE id = p_id
    UNION ALL SELECT school_id FROM documents WHERE id = p_id UNION ALL SELECT school_id FROM uploads WHERE id = p_id
    UNION ALL SELECT school_id FROM conversations WHERE id = p_id UNION ALL SELECT school_id FROM guardians WHERE id = p_id
    UNION ALL SELECT school_id FROM announcements WHERE id = p_id UNION ALL SELECT school_id FROM roles WHERE id = p_id
    UNION ALL SELECT school_id FROM school_memberships WHERE user_id = p_id AND school_id <> p_school
  ) x WHERE school_id IS DISTINCT FROM p_school LIMIT 1;
  RETURN r;
END $$;

-- abnormal export activity: exports by a user in the last hour
CREATE OR REPLACE FUNCTION app.recent_exports(p_user uuid) RETURNS integer
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT count(*)::int FROM audit_logs WHERE actor_user_id = p_user AND action = 'data.exported' AND created_at > now() - interval '1 hour'
$$;

-- invited users accept/decline their own membership (they are signed in to a different school at that moment)
CREATE OR REPLACE FUNCTION app.respond_membership(p_membership uuid, p_user uuid, p_accept boolean) RETURNS uuid
LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  UPDATE school_memberships SET status = CASE WHEN p_accept THEN 'active' ELSE 'left' END
  WHERE id = p_membership AND user_id = p_user AND status = 'invited' RETURNING school_id
$$;
CREATE OR REPLACE FUNCTION app.touch_membership(p_user uuid, p_school uuid) RETURNS void
LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  UPDATE school_memberships SET last_used_at = now() WHERE user_id = p_user AND school_id = p_school
$$;
-- how many ACTIVE memberships does this identity have in OTHER schools? (identity-level changes such as
-- credential resets are only allowed to a school that exclusively "owns" the identity)
CREATE OR REPLACE FUNCTION app.other_memberships(p_user uuid, p_school uuid) RETURNS integer
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT count(*)::int FROM school_memberships WHERE user_id = p_user AND school_id <> p_school AND status IN ('active','invited')
$$;
-- users with an ACTIVE membership in the current school (used for recipient lists, approver notifications…)
CREATE VIEW active_members WITH (security_invoker = true) AS
  SELECT u.id, u.login_id, u.full_name, u.email, u.phone, m.branch_id
  FROM users u JOIN school_memberships m ON m.user_id = u.id AND m.school_id = app.current_school()
  WHERE m.status = 'active' AND u.status = 'active';
