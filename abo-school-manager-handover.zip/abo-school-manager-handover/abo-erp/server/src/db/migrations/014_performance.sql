-- 014_performance.sql — findings from the load test (pg_stat_statements):
-- 1) score saves spent most time in a ROW-level trigger (status lookup + history insert per cell).
--    Replaced by STATEMENT-level triggers with transition tables: one lock check + one bulk history insert per save.
-- 2) invoice_items had no index on invoice_id (only the composite FK) → 4.9 ms per invoice view.
-- 3) student search ORs a name pattern with admission_no → add a trigram index on admission_no too.
DROP TRIGGER assessment_scores_guard ON assessment_scores;

CREATE OR REPLACE FUNCTION app.scores_locked(p_sheets uuid[]) RETURNS void LANGUAGE plpgsql AS $$
DECLARE v_corr text := NULLIF(current_setting('app.correction_sheet', true), ''); v_bad record;
BEGIN
  SELECT id, status INTO v_bad FROM assessments WHERE id = ANY(p_sheets) AND status <> 'draft' AND (v_corr IS NULL OR v_corr::uuid <> id) LIMIT 1;
  IF FOUND THEN RAISE EXCEPTION 'RESULT_LOCKED: sheet % is %', v_bad.id, v_bad.status USING ERRCODE = 'P0001'; END IF;
END $$;

CREATE OR REPLACE FUNCTION app.scores_after_insert() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  PERFORM app.scores_locked(ARRAY(SELECT DISTINCT sheet_id FROM new_rows));
  INSERT INTO assessment_score_history (school_id, sheet_id, student_id, component_key, old_score, new_score, changed_by, via_correction)
    SELECT school_id, sheet_id, student_id, component_key, NULL, score, app.current_user_id(), NULLIF(current_setting('app.correction_sheet', true), '')::uuid FROM new_rows;
  RETURN NULL;
END $$;
CREATE OR REPLACE FUNCTION app.scores_after_update() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  PERFORM app.scores_locked(ARRAY(SELECT DISTINCT sheet_id FROM new_rows));
  INSERT INTO assessment_score_history (school_id, sheet_id, student_id, component_key, old_score, new_score, changed_by, via_correction)
    SELECT n.school_id, n.sheet_id, n.student_id, n.component_key, o.score, n.score, app.current_user_id(), NULLIF(current_setting('app.correction_sheet', true), '')::uuid
    FROM new_rows n JOIN old_rows o USING (sheet_id, student_id, component_key) WHERE o.score IS DISTINCT FROM n.score;
  RETURN NULL;
END $$;
CREATE OR REPLACE FUNCTION app.scores_after_delete() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  PERFORM app.scores_locked(ARRAY(SELECT DISTINCT sheet_id FROM old_rows));
  INSERT INTO assessment_score_history (school_id, sheet_id, student_id, component_key, old_score, new_score, changed_by, via_correction)
    SELECT school_id, sheet_id, student_id, component_key, score, NULL, app.current_user_id(), NULLIF(current_setting('app.correction_sheet', true), '')::uuid FROM old_rows;
  RETURN NULL;
END $$;
CREATE TRIGGER assessment_scores_ins AFTER INSERT ON assessment_scores REFERENCING NEW TABLE AS new_rows FOR EACH STATEMENT EXECUTE FUNCTION app.scores_after_insert();
CREATE TRIGGER assessment_scores_upd AFTER UPDATE ON assessment_scores REFERENCING OLD TABLE AS old_rows NEW TABLE AS new_rows FOR EACH STATEMENT EXECUTE FUNCTION app.scores_after_update();
CREATE TRIGGER assessment_scores_del AFTER DELETE ON assessment_scores REFERENCING OLD TABLE AS old_rows FOR EACH STATEMENT EXECUTE FUNCTION app.scores_after_delete();
CREATE TRIGGER assessment_scores_touch BEFORE UPDATE ON assessment_scores FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();

CREATE INDEX invoice_items_invoice_idx ON invoice_items (invoice_id);
CREATE INDEX students_admno_trgm ON students USING gin (lower(admission_no) gin_trgm_ops);
CREATE INDEX payments_student_idx ON payments (school_id, student_id);
