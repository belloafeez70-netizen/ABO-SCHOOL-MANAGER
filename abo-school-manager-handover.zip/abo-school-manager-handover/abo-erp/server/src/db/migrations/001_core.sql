-- 001_core.sql — tenancy, identity, RBAC, sessions
-- Conventions:
--   * every school-owned table has school_id uuid NOT NULL and UNIQUE (school_id, id)
--     so child tables can use COMPOSITE foreign keys (school_id, x_id) — the
--     database itself refuses to link a record to another school's record.
--   * Row-Level Security is enabled in 008_rls.sql for every tenant table.
--   * money is stored as integer kobo (bigint); never floats.

CREATE SCHEMA IF NOT EXISTS app;

-- Request context set by the API with set_config(..., true) (transaction-local).
CREATE OR REPLACE FUNCTION app.current_school() RETURNS uuid
  LANGUAGE sql STABLE AS $$ SELECT NULLIF(current_setting('app.school_id', true), '')::uuid $$;
CREATE OR REPLACE FUNCTION app.current_user_id() RETURNS uuid
  LANGUAGE sql STABLE AS $$ SELECT NULLIF(current_setting('app.user_id', true), '')::uuid $$;
CREATE OR REPLACE FUNCTION app.is_platform() RETURNS boolean
  LANGUAGE sql STABLE AS $$ SELECT COALESCE(current_setting('app.platform', true), '') = 'on' $$;

CREATE OR REPLACE FUNCTION app.touch_updated_at() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at := now(); RETURN NEW; END $$;

-- ───────────────────────── schools / tenants ─────────────────────────
CREATE TABLE schools (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code            text NOT NULL,
  name            text NOT NULL CHECK (length(name) BETWEEN 2 AND 160),
  school_type     text NOT NULL DEFAULT 'mixed' CHECK (school_type IN ('primary','secondary','mixed')),
  motto           text,
  address         text,
  phone           text,
  email           text,
  website         text,
  logo_file_id    uuid,
  country         text NOT NULL DEFAULT 'NG',
  timezone        text NOT NULL DEFAULT 'Africa/Lagos',
  currency        text NOT NULL DEFAULT 'NGN',
  status          text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','active','suspended')),
  plan            text NOT NULL DEFAULT 'standard',
  max_students    integer NOT NULL DEFAULT 2000 CHECK (max_students > 0),
  email_verified_at timestamptz,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX schools_code_uq ON schools (lower(code));
CREATE TRIGGER schools_touch BEFORE UPDATE ON schools FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();

CREATE TABLE school_branches (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id  uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  name       text NOT NULL,
  address    text,
  phone      text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id),
  UNIQUE (school_id, name)
);

CREATE TABLE school_settings (
  school_id             uuid PRIMARY KEY REFERENCES schools(id) ON DELETE CASCADE,
  grading               jsonb NOT NULL DEFAULT '{}'::jsonb,
  assessment_components jsonb NOT NULL DEFAULT '[]'::jsonb,
  pass_mark             numeric(5,2) NOT NULL DEFAULT 40 CHECK (pass_mark BETWEEN 0 AND 100),
  report_card           jsonb NOT NULL DEFAULT '{}'::jsonb,
  onboarding            jsonb NOT NULL DEFAULT '{}'::jsonb,
  ai_enabled            boolean NOT NULL DEFAULT false,
  mfa_required_roles    text[] NOT NULL DEFAULT ARRAY['school_owner','bursar','accountant']::text[],
  updated_at            timestamptz NOT NULL DEFAULT now()
);
CREATE TRIGGER school_settings_touch BEFORE UPDATE ON school_settings FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();

CREATE TABLE system_settings (
  key        text PRIMARY KEY,
  value      jsonb NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- ───────────────────────── users / identity ─────────────────────────
CREATE TABLE users (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id             uuid REFERENCES schools(id) ON DELETE CASCADE,   -- NULL only for platform admins
  login_id              text NOT NULL CHECK (login_id ~ '^[A-Za-z0-9._@-]{3,64}$'),
  email                 text,
  email_verified_at     timestamptz,
  full_name             text NOT NULL CHECK (length(full_name) BETWEEN 1 AND 160),
  phone                 text,
  password_hash         text,                 -- Argon2id PHC string; NULL until activated
  must_change_password  boolean NOT NULL DEFAULT false,
  password_changed_at   timestamptz,
  access_code_hash      text,                 -- one-time activation code (sha256), students/parents/staff invites
  access_code_expires_at timestamptz,
  status                text NOT NULL DEFAULT 'active' CHECK (status IN ('active','disabled','pending')),
  is_platform_admin     boolean NOT NULL DEFAULT false,
  failed_attempts       integer NOT NULL DEFAULT 0,
  locked_until          timestamptz,
  last_login_at         timestamptz,
  last_login_ip         inet,
  mfa_enabled           boolean NOT NULL DEFAULT false,
  mfa_secret_enc        text,                 -- AES-256-GCM encrypted TOTP secret
  mfa_last_step         bigint,               -- TOTP replay protection
  mfa_enrolled_at       timestamptz,
  created_at            timestamptz NOT NULL DEFAULT now(),
  updated_at            timestamptz NOT NULL DEFAULT now(),
  CHECK ((school_id IS NULL) = is_platform_admin),
  UNIQUE (school_id, id)
);
CREATE UNIQUE INDEX users_login_uq ON users (lower(login_id));
CREATE UNIQUE INDEX users_school_email_uq ON users (school_id, lower(email)) WHERE email IS NOT NULL;
CREATE INDEX users_school_idx ON users (school_id, status);
CREATE TRIGGER users_touch BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();

CREATE TABLE mfa_recovery_codes (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  school_id  uuid REFERENCES schools(id) ON DELETE CASCADE,
  code_hash  text NOT NULL,
  used_at    timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX mfa_recovery_user_idx ON mfa_recovery_codes (user_id) WHERE used_at IS NULL;

CREATE TABLE user_tokens (             -- password reset + email verification
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  school_id   uuid REFERENCES schools(id) ON DELETE CASCADE,
  kind        text NOT NULL CHECK (kind IN ('password_reset','email_verify')),
  token_hash  text NOT NULL UNIQUE,
  expires_at  timestamptz NOT NULL,
  used_at     timestamptz,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE sessions (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id          uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  school_id        uuid REFERENCES schools(id) ON DELETE CASCADE,
  token_hash       text NOT NULL UNIQUE,     -- sha256 of the opaque cookie token; raw token never stored
  mfa_state        text NOT NULL DEFAULT 'none' CHECK (mfa_state IN ('none','pending','verified','enroll_required')),
  support_school_id uuid REFERENCES schools(id) ON DELETE SET NULL,   -- platform read-only support mode
  support_reason   text,
  support_expires_at timestamptz,
  ip               inet,
  user_agent       text,
  device_label     text,
  created_at       timestamptz NOT NULL DEFAULT now(),
  last_seen_at     timestamptz NOT NULL DEFAULT now(),
  rotated_at       timestamptz NOT NULL DEFAULT now(),
  idle_expires_at  timestamptz NOT NULL,
  expires_at       timestamptz NOT NULL,
  revoked_at       timestamptz,
  revoked_reason   text
);
CREATE INDEX sessions_user_idx ON sessions (user_id) WHERE revoked_at IS NULL;
CREATE INDEX sessions_expiry_idx ON sessions (expires_at);

CREATE TABLE known_devices (          -- suspicious-login detection (new device / new network)
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  school_id   uuid REFERENCES schools(id) ON DELETE CASCADE,
  fingerprint text NOT NULL,          -- sha256(user-agent family + /24 network)
  first_seen  timestamptz NOT NULL DEFAULT now(),
  last_seen   timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, fingerprint)
);

-- ───────────────────────── RBAC ─────────────────────────
CREATE TABLE permissions (             -- global catalogue (seeded, read-only to the app)
  key         text PRIMARY KEY CHECK (key ~ '^[a-z_]+(\.[a-z_]+)+$'),
  module      text NOT NULL,
  description text NOT NULL,
  scope       text NOT NULL DEFAULT 'school' CHECK (scope IN ('school','platform'))
);

CREATE TABLE roles (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id    uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  key          text NOT NULL CHECK (key ~ '^[a-z][a-z0-9_]{1,40}$'),
  name         text NOT NULL,
  description  text,
  is_system    boolean NOT NULL DEFAULT false,   -- seeded template; can't be deleted
  mfa_required boolean NOT NULL DEFAULT false,
  portal       text NOT NULL DEFAULT 'staff' CHECK (portal IN ('staff','student','parent')),
  created_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id),
  UNIQUE (school_id, key)
);

CREATE TABLE role_permissions (
  school_id      uuid NOT NULL,
  role_id        uuid NOT NULL,
  permission_key text NOT NULL REFERENCES permissions(key) ON DELETE CASCADE,
  PRIMARY KEY (role_id, permission_key),
  FOREIGN KEY (school_id, role_id) REFERENCES roles (school_id, id) ON DELETE CASCADE
);

CREATE TABLE user_roles (
  school_id  uuid NOT NULL,
  user_id    uuid NOT NULL,
  role_id    uuid NOT NULL,
  granted_by uuid,
  granted_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, role_id),
  FOREIGN KEY (school_id, user_id) REFERENCES users (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, role_id) REFERENCES roles (school_id, id) ON DELETE CASCADE
);
CREATE INDEX user_roles_role_idx ON user_roles (role_id);
