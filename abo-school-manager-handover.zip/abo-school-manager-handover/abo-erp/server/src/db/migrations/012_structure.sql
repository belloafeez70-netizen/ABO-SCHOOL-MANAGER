-- 012_structure.sql — domain model aligned with the specification's entity names + new entities:
-- teachers, teacher_assignments, streams, assessment_components, attendance_sessions, fee_categories,
-- payment_allocations, receipts, cbt_results, idempotency_keys; REVIEWED result state; permission renames.

-- ───────── renames (RLS policies, indexes and FKs follow the table automatically) ─────────
DROP VIEW assessments;                                   -- was an alias view; the table takes the name
ALTER TABLE assessment_sheets RENAME TO assessments;
ALTER TABLE term_results RENAME TO result_summaries;
ALTER TABLE fee_items RENAME TO fee_structures;
DROP VIEW fee_invoice_items;
ALTER TABLE invoice_lines RENAME TO invoice_items;
ALTER TABLE invoice_items RENAME COLUMN fee_item_id TO fee_structure_id;
ALTER TABLE message_threads RENAME TO conversations;
ALTER TABLE thread_participants RENAME TO conversation_participants;
ALTER TABLE conversation_participants RENAME COLUMN thread_id TO conversation_id;
ALTER TABLE messages RENAME COLUMN thread_id TO conversation_id;
ALTER TABLE enrollments RENAME TO student_enrollments;
CREATE VIEW enrollments WITH (security_invoker = true) AS SELECT * FROM student_enrollments;   -- short alias
DROP VIEW class_members;
CREATE VIEW class_members WITH (security_invoker = true) AS SELECT * FROM student_enrollments WHERE status = 'active';

-- ───────── result workflow: DRAFT → SUBMITTED → REVIEWED → APPROVED → PUBLISHED ─────────
ALTER TABLE assessments DROP CONSTRAINT assessment_sheets_status_check;
ALTER TABLE assessments ADD CONSTRAINT assessments_status_check CHECK (status IN ('draft','submitted','reviewed','approved','published'));
ALTER TABLE assessments ADD COLUMN reviewed_by uuid, ADD COLUMN reviewed_at timestamptz;
ALTER TABLE school_settings ADD COLUMN results_require_review boolean NOT NULL DEFAULT true;
-- lock: ANY non-draft sheet is read-only in the database; only an approved correction (which sets
-- app.correction_sheet for that one sheet inside its transaction) may change a locked score.
CREATE OR REPLACE FUNCTION app.guard_assessment_scores() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE v_status text; v_sheet uuid; v_corr text;
BEGIN
  v_sheet := COALESCE(NEW.sheet_id, OLD.sheet_id);
  SELECT status INTO v_status FROM assessments WHERE id = v_sheet;
  v_corr := NULLIF(current_setting('app.correction_sheet', true), '');
  IF v_status <> 'draft' AND (v_corr IS NULL OR v_corr::uuid <> v_sheet) THEN
    RAISE EXCEPTION 'RESULT_LOCKED: sheet % is %', v_sheet, v_status USING ERRCODE = 'P0001';
  END IF;
  IF TG_OP = 'DELETE' THEN
    INSERT INTO assessment_score_history (school_id, sheet_id, student_id, component_key, old_score, new_score, changed_by, via_correction)
    VALUES (OLD.school_id, OLD.sheet_id, OLD.student_id, OLD.component_key, OLD.score, NULL, app.current_user_id(), v_corr::uuid);
    RETURN OLD;
  END IF;
  IF TG_OP = 'INSERT' OR OLD.score IS DISTINCT FROM NEW.score THEN
    INSERT INTO assessment_score_history (school_id, sheet_id, student_id, component_key, old_score, new_score, changed_by, via_correction)
    VALUES (NEW.school_id, NEW.sheet_id, NEW.student_id, NEW.component_key, CASE WHEN TG_OP = 'UPDATE' THEN OLD.score END, NEW.score, app.current_user_id(), v_corr::uuid);
  END IF;
  NEW.updated_at := now();
  RETURN NEW;
END $$;

-- ───────── assessment components (school-configurable; sheets freeze a copy when created) ─────────
CREATE TABLE assessment_components (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id  uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  key        text NOT NULL CHECK (key ~ '^[a-z0-9_]{1,20}$'),
  label      text NOT NULL CHECK (length(label) BETWEEN 1 AND 30),
  max_score  numeric(5,2) NOT NULL CHECK (max_score > 0 AND max_score <= 100),
  is_exam    boolean NOT NULL DEFAULT false,
  position   integer NOT NULL DEFAULT 0,
  active     boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, key)
);
CREATE TRIGGER assessment_components_touch BEFORE UPDATE ON assessment_components FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();
INSERT INTO assessment_components (school_id, key, label, max_score, is_exam, position)
  SELECT ss.school_id, c->>'key', c->>'label', (c->>'max')::numeric, (c->>'key') = 'exam', ord
  FROM school_settings ss, jsonb_array_elements(ss.assessment_components) WITH ORDINALITY AS x(c, ord);
-- exam-component scores = "examination scores"
ALTER TABLE school_settings DROP COLUMN assessment_components;   -- the table above is now the single source
CREATE VIEW examination_scores WITH (security_invoker = true) AS
  SELECT s.* FROM assessment_scores s JOIN assessments a ON a.id = s.sheet_id
  WHERE EXISTS (SELECT 1 FROM jsonb_array_elements(a.components) c WHERE c->>'key' = s.component_key AND COALESCE((c->>'is_exam')::boolean, c->>'key' = 'exam'));
DROP VIEW examinations;
CREATE VIEW examinations WITH (security_invoker = true) AS SELECT * FROM assessments;

-- ───────── teachers, assignments, streams ─────────
DROP VIEW teachers;
CREATE TABLE teachers (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id      uuid NOT NULL,
  staff_id       uuid NOT NULL,
  trcn_number    text,                         -- Teachers Registration Council of Nigeria
  qualification  text,
  specialization text,
  status         text NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive')),
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id),
  UNIQUE (school_id, staff_id),
  FOREIGN KEY (school_id, staff_id) REFERENCES staff (school_id, id) ON DELETE CASCADE
);
CREATE TRIGGER teachers_touch BEFORE UPDATE ON teachers FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();
INSERT INTO teachers (school_id, staff_id) SELECT school_id, id FROM staff WHERE is_teacher;
-- keep teachers in step with staff.is_teacher
CREATE OR REPLACE FUNCTION app.sync_teacher() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.is_teacher THEN
    INSERT INTO teachers (school_id, staff_id) VALUES (NEW.school_id, NEW.id) ON CONFLICT (school_id, staff_id) DO UPDATE SET status = 'active';
  ELSE
    UPDATE teachers SET status = 'inactive' WHERE school_id = NEW.school_id AND staff_id = NEW.id;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER staff_sync_teacher AFTER INSERT OR UPDATE OF is_teacher ON staff FOR EACH ROW EXECUTE FUNCTION app.sync_teacher();

CREATE TABLE teacher_assignments (       -- additional/co-teaching assignments (primary ones live on class_subjects / classes)
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id  uuid NOT NULL,
  staff_id   uuid NOT NULL,
  class_id   uuid NOT NULL,
  subject_id uuid,                        -- NULL ⇒ class-level (e.g. assistant form teacher)
  session_id uuid,                        -- NULL ⇒ every session
  role       text NOT NULL DEFAULT 'subject_teacher' CHECK (role IN ('subject_teacher','form_teacher','assistant')),
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE NULLS NOT DISTINCT (staff_id, class_id, subject_id, session_id, role),
  FOREIGN KEY (school_id, staff_id)   REFERENCES staff (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, class_id)   REFERENCES classes (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, subject_id) REFERENCES subjects (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, session_id) REFERENCES academic_sessions (school_id, id) ON DELETE CASCADE
);
CREATE INDEX teacher_assignments_staff_idx ON teacher_assignments (school_id, staff_id);
-- single authorisation source for "may this teacher act on this class/subject?"
CREATE VIEW teacher_class_access WITH (security_invoker = true) AS
  SELECT school_id, teacher_id AS staff_id, class_id, subject_id, 'subject_teacher'::text AS role FROM class_subjects WHERE teacher_id IS NOT NULL
  UNION ALL SELECT school_id, form_teacher_id, id, NULL, 'form_teacher' FROM classes WHERE form_teacher_id IS NOT NULL
  UNION ALL SELECT ta.school_id, ta.staff_id, ta.class_id, ta.subject_id, ta.role FROM teacher_assignments ta
    LEFT JOIN academic_sessions s ON s.id = ta.session_id WHERE ta.session_id IS NULL OR s.is_current;

CREATE TABLE streams (                    -- the school's catalogue of arms/streams (A, B, Gold, Science…)
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id  uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  name       text NOT NULL CHECK (name ~ '^[A-Za-z0-9 ]{1,12}$'),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id),
  UNIQUE (school_id, name)
);
INSERT INTO streams (school_id, name) SELECT DISTINCT school_id, arm FROM classes WHERE arm <> '';
ALTER TABLE classes ADD COLUMN stream_id uuid;
ALTER TABLE classes ADD FOREIGN KEY (school_id, stream_id) REFERENCES streams (school_id, id) ON DELETE SET NULL (stream_id);
UPDATE classes c SET stream_id = s.id FROM streams s WHERE s.school_id = c.school_id AND s.name = c.arm;

-- ───────── attendance sessions (one register per class per day) ─────────
CREATE TABLE attendance_sessions (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id  uuid NOT NULL,
  class_id   uuid NOT NULL,
  term_id    uuid,
  date       date NOT NULL,
  taken_by   uuid,
  remarks    text CHECK (remarks IS NULL OR length(remarks) <= 500),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id),
  UNIQUE (class_id, date),
  FOREIGN KEY (school_id, class_id) REFERENCES classes (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, term_id)  REFERENCES terms (school_id, id) ON DELETE SET NULL (term_id)
);
CREATE INDEX attendance_sessions_date_idx ON attendance_sessions (school_id, date);
CREATE TRIGGER attendance_sessions_touch BEFORE UPDATE ON attendance_sessions FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();
INSERT INTO attendance_sessions (school_id, class_id, term_id, date)
  SELECT DISTINCT ON (class_id, date) school_id, class_id, term_id, date FROM attendance ORDER BY class_id, date;
ALTER TABLE attendance ADD COLUMN session_id uuid;
UPDATE attendance a SET session_id = s.id FROM attendance_sessions s WHERE s.class_id = a.class_id AND s.date = a.date;
ALTER TABLE attendance ADD FOREIGN KEY (school_id, session_id) REFERENCES attendance_sessions (school_id, id) ON DELETE CASCADE;
ALTER TABLE attendance RENAME TO attendance_records;
CREATE VIEW attendance WITH (security_invoker = true) AS SELECT * FROM attendance_records;

-- ───────── fees: categories, structures, allocations, receipts ─────────
CREATE TABLE fee_categories (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id  uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  code       text NOT NULL CHECK (code ~ '^[a-z0-9_]{2,30}$'),
  name       text NOT NULL CHECK (length(name) BETWEEN 2 AND 80),
  active     boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id),
  UNIQUE (school_id, code)
);
INSERT INTO fee_categories (school_id, code, name)
  SELECT s.id, c.code, c.name FROM schools s, (VALUES ('tuition','Tuition'),('development','Development levy'),('uniform','Uniform'),('books','Books'),('transport','Transport'),
    ('exam','Examination'),('ict','ICT / Computer'),('feeding','Feeding'),('boarding','Boarding'),('other','Other')) AS c(code, name);
ALTER TABLE fee_structures ADD COLUMN category_id uuid;
UPDATE fee_structures f SET category_id = c.id FROM fee_categories c WHERE c.school_id = f.school_id AND c.code = f.category;
ALTER TABLE fee_structures ALTER COLUMN category_id SET NOT NULL;
ALTER TABLE fee_structures ADD FOREIGN KEY (school_id, category_id) REFERENCES fee_categories (school_id, id) ON DELETE RESTRICT;
ALTER TABLE fee_structures DROP COLUMN category CASCADE;           -- drops the old `fees` alias view too
CREATE VIEW fee_items WITH (security_invoker = true) AS SELECT * FROM fee_structures;
ALTER TABLE invoice_items ADD COLUMN kind text NOT NULL DEFAULT 'structure' CHECK (kind IN ('structure','student_charge'));
ALTER TABLE invoice_items ADD COLUMN created_by uuid;
ALTER TABLE invoice_items ADD COLUMN created_at timestamptz NOT NULL DEFAULT now();

CREATE TABLE payment_allocations (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id   uuid NOT NULL,
  payment_id  uuid NOT NULL,
  invoice_id  uuid NOT NULL,
  amount_kobo bigint NOT NULL CHECK (amount_kobo > 0),
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (payment_id, invoice_id),
  FOREIGN KEY (school_id, payment_id) REFERENCES payments (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, invoice_id) REFERENCES invoices (school_id, id) ON DELETE RESTRICT
);
CREATE INDEX payment_allocations_invoice_idx ON payment_allocations (school_id, invoice_id);
INSERT INTO payment_allocations (school_id, payment_id, invoice_id, amount_kobo) SELECT school_id, id, invoice_id, amount_kobo FROM payments WHERE invoice_id IS NOT NULL;
-- allocations can never exceed the payment amount (checked at commit so multi-row inserts work)
CREATE OR REPLACE FUNCTION app.check_allocations() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE v_total bigint; v_amount bigint;
BEGIN
  SELECT COALESCE(sum(amount_kobo), 0) INTO v_total FROM payment_allocations WHERE payment_id = NEW.payment_id;
  SELECT amount_kobo INTO v_amount FROM payments WHERE id = NEW.payment_id;
  IF v_total > v_amount THEN RAISE EXCEPTION 'ALLOCATION_EXCEEDS_PAYMENT' USING ERRCODE = '23514'; END IF;
  RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER payment_allocations_sum AFTER INSERT OR UPDATE ON payment_allocations DEFERRABLE INITIALLY DEFERRED
  FOR EACH ROW EXECUTE FUNCTION app.check_allocations();

CREATE TABLE receipts (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id   uuid NOT NULL,
  payment_id  uuid NOT NULL UNIQUE,
  receipt_no  text NOT NULL,
  issued_by   uuid,
  issued_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, receipt_no),
  FOREIGN KEY (school_id, payment_id) REFERENCES payments (school_id, id) ON DELETE RESTRICT
);
INSERT INTO receipts (school_id, payment_id, receipt_no, issued_by, issued_at)
  SELECT school_id, id, receipt_no, received_by, paid_at FROM payments WHERE receipt_no IS NOT NULL;
DROP INDEX payments_receipt_uq;
ALTER TABLE payments DROP COLUMN receipt_no;
ALTER TABLE payments ALTER COLUMN invoice_id DROP NOT NULL;         -- payments may span several invoices (see allocations)
ALTER TABLE payments ALTER COLUMN student_id DROP NOT NULL;
ALTER TABLE payments ADD COLUMN payer_guardian_id uuid;
ALTER TABLE payments ADD FOREIGN KEY (school_id, payer_guardian_id) REFERENCES guardians (school_id, id) ON DELETE SET NULL (payer_guardian_id);

-- ───────── CBT results (final, server-computed; one per finished attempt) ─────────
CREATE TABLE cbt_results (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id    uuid NOT NULL,
  attempt_id   uuid NOT NULL UNIQUE,
  exam_id      uuid NOT NULL,
  student_id   uuid NOT NULL,
  score        numeric(7,2) NOT NULL,
  max_score    numeric(7,2) NOT NULL CHECK (max_score >= 0),
  percentage   numeric(5,2) NOT NULL,
  passed       boolean NOT NULL,
  finalized_at timestamptz NOT NULL DEFAULT now(),
  CHECK (score >= 0 AND score <= max_score),
  FOREIGN KEY (school_id, attempt_id) REFERENCES cbt_attempts (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, exam_id)    REFERENCES cbt_exams (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, student_id) REFERENCES students (school_id, id) ON DELETE CASCADE
);
CREATE INDEX cbt_results_student_idx ON cbt_results (school_id, student_id);
CREATE INDEX cbt_results_exam_idx ON cbt_results (school_id, exam_id);

-- ───────── idempotency keys (duplicate-submission protection for payments, CBT submit…) ─────────
CREATE TABLE idempotency_keys (
  school_id   uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  user_id     uuid NOT NULL,
  key         text NOT NULL CHECK (key ~ '^[A-Za-z0-9_-]{8,80}$'),
  route       text NOT NULL,
  request_hash text NOT NULL,
  status_code integer,
  response    jsonb,
  created_at  timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (school_id, user_id, key)
);

-- ───────── RLS for the new tenant tables ─────────
DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['assessment_components','teachers','teacher_assignments','streams','attendance_sessions','fee_categories','payment_allocations','receipts','cbt_results','idempotency_keys'] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY tenant_isolation ON %I USING (school_id = app.current_school()) WITH CHECK (school_id = app.current_school())', t);
  END LOOP;
END $$;

-- ───────── permission renames (keys aligned with the specification) ─────────
INSERT INTO permissions (key, module, description) VALUES
  ('students.update','students','Edit student records'), ('staff.update','staff','Edit staff'), ('users.update','users','Edit user accounts, reset access'),
  ('results.update','results','Request corrections to locked results'), ('fees.update','finance','Edit fee structures; void invoices; add charges'),
  ('cbt.update','cbt','Edit CBT exams and questions'), ('cbt.results','cbt','View CBT attempts and scores'), ('audit_logs.view','security','View the school audit log'),
  ('settings.view','school','View school profile & settings'), ('settings.update','school','Edit school settings'), ('settings.branding','school','Upload logo and edit branding'),
  ('attendance.create','attendance','Take registers for your assigned classes'), ('attendance.update','attendance','Take or amend registers for any class')
ON CONFLICT (key) DO NOTHING;
UPDATE role_permissions SET permission_key = m.new FROM (VALUES
  ('students.edit','students.update'), ('staff.edit','staff.update'), ('users.edit','users.update'), ('results.edit','results.update'), ('fees.edit','fees.update'),
  ('cbt.edit','cbt.update'), ('cbt.view_results','cbt.results'), ('audit.view','audit_logs.view'), ('school.settings.view','settings.view'),
  ('school.settings.edit','settings.update'), ('school.branding.edit','settings.branding'), ('attendance.mark','attendance.create'), ('attendance.mark_any','attendance.update')
) AS m(old, new) WHERE role_permissions.permission_key = m.old;
DELETE FROM permissions WHERE key IN ('students.edit','staff.edit','users.edit','results.edit','fees.edit','cbt.edit','cbt.view_results','audit.view',
  'school.settings.view','school.settings.edit','school.branding.edit','attendance.mark','attendance.mark_any');
