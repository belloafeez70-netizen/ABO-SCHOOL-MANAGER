-- 015_branding_approval.sql — school branding, head-of-school details, platform approval, public school portal.
--
-- * schools.brand_color            accent colour used in the school's portal and login page
-- * schools.head_*                 principal / head teacher shown on report cards (name, title, contact, signature)
-- * schools.approved_at/_by        platform approval of a newly registered school (pending → active)
-- * app.public_school_profile()    the ONLY data exposed about a school before sign-in (name, motto, logo flag, colour)
-- * app.public_school_logo()       storage pointer for an ACTIVE school's logo (public login page)

ALTER TABLE schools
  ADD COLUMN brand_color text CHECK (brand_color ~ '^#[0-9a-fA-F]{6}$'),
  ADD COLUMN head_name text CHECK (length(head_name) BETWEEN 2 AND 120),
  ADD COLUMN head_title text CHECK (length(head_title) BETWEEN 2 AND 60),
  ADD COLUMN head_phone text CHECK (head_phone ~ '^[+0-9 ()-]{7,20}$'),
  ADD COLUMN head_email text CHECK (length(head_email) <= 160 AND head_email ~ '^[^\s@]+@[^\s@]+\.[^\s@]+$'),
  ADD COLUMN head_signature_file_id uuid,
  ADD COLUMN approved_at timestamptz,
  ADD COLUMN approved_by uuid;

ALTER TABLE schools ADD CONSTRAINT schools_head_signature_fk
  FOREIGN KEY (id, head_signature_file_id) REFERENCES uploads (school_id, id) ON DELETE SET NULL (head_signature_file_id);

-- schools that were already active before approval existed count as approved
UPDATE schools SET approved_at = COALESCE(email_verified_at, created_at) WHERE status = 'active' AND approved_at IS NULL;

-- Public, pre-authentication profile of an ACTIVE school, looked up by its web address (slug).
-- Pending / suspended / unknown schools are indistinguishable (no rows) — nothing to enumerate.
CREATE FUNCTION app.public_school_profile(p_slug text)
RETURNS TABLE (id uuid, slug text, name text, motto text, school_type text, brand_color text, has_logo boolean)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT s.id, s.slug, s.name, s.motto, s.school_type, s.brand_color,
         EXISTS (SELECT 1 FROM uploads u WHERE u.id = s.logo_file_id AND u.school_id = s.id AND u.deleted_at IS NULL AND u.scan_status <> 'infected')
  FROM schools s WHERE lower(s.slug) = lower(p_slug) AND s.status = 'active'
$$;

CREATE FUNCTION app.public_school_logo(p_slug text)
RETURNS TABLE (storage_key text, mime text, size_bytes bigint, sha256 text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT u.storage_key, u.mime, u.size_bytes, u.sha256
  FROM schools s JOIN uploads u ON u.id = s.logo_file_id AND u.school_id = s.id
  WHERE lower(s.slug) = lower(p_slug) AND s.status = 'active' AND u.purpose = 'logo' AND u.deleted_at IS NULL AND u.scan_status <> 'infected'
$$;

-- owners of a school (for the approval e-mail); platform-only
CREATE FUNCTION app.platform_school_owners(p_school uuid)
RETURNS TABLE (user_id uuid, email text, full_name text)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
BEGIN
  IF NOT app.is_platform() THEN RAISE EXCEPTION 'PLATFORM_ONLY' USING ERRCODE = '42501'; END IF;
  RETURN QUERY SELECT u.id, u.email, u.full_name FROM users u
    JOIN school_memberships m ON m.user_id = u.id AND m.school_id = p_school AND m.status = 'active'
    JOIN user_roles ur ON ur.user_id = u.id AND ur.school_id = p_school
    JOIN roles r ON r.id = ur.role_id AND r.key = 'school_owner'
    WHERE u.status = 'active';
END $$;

-- pre-auth: lets sign-in tell "verify your e-mail" apart from "awaiting platform approval" (boolean only)
CREATE FUNCTION app.school_email_verified(p_school uuid) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$ SELECT COALESCE((SELECT email_verified_at IS NOT NULL FROM schools WHERE id = p_school), false) $$;
