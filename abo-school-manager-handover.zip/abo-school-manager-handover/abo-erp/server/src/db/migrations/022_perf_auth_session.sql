-- 022_perf_auth_session.sql — Phase 7 (load test at 1,000 schools / 200,000 users).
-- app.auth_session runs on EVERY request. As a SECURITY DEFINER *SQL* function it is never inlined and is planned
-- again on every call: the load test measured 1.65–1.9 ms per call, ~15× more database time than any other query
-- (18,010 calls = 33.8 s in a 60-second run). The same query in PL/pgSQL keeps its plan for the connection's lifetime.
-- Same name, arguments, result columns and rules — only the language changes.
CREATE OR REPLACE FUNCTION app.auth_session(p_token_hash text)
RETURNS TABLE (session_id uuid, user_id uuid, school_id uuid, mfa_state text, support_school_id uuid,
               support_expires_at timestamptz, idle_expires_at timestamptz, expires_at timestamptz, rotated_at timestamptz,
               user_status text, is_platform_admin boolean, school_status text, membership_status text, branch_id uuid,
               login_id text, full_name text, must_change_password boolean, mfa_enabled boolean, email text, via_prev boolean,
               acting_user_id uuid, acting_expires_at timestamptz, acting_reason text, acting_started_at timestamptz,
               acting_login_id text, acting_full_name text, acting_user_status text, acting_is_platform boolean,
               acting_membership_status text, acting_branch_id uuid)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
#variable_conflict use_column
BEGIN
  RETURN QUERY
  SELECT s.id, s.user_id, s.school_id, s.mfa_state, s.support_school_id, s.support_expires_at, s.idle_expires_at,
         s.expires_at, s.rotated_at, u.status, u.is_platform_admin, sc.status, m.status, m.branch_id, u.login_id, u.full_name,
         u.must_change_password, u.mfa_enabled, u.email, (s.token_hash <> p_token_hash),
         s.acting_user_id, s.acting_expires_at, s.acting_reason, s.acting_started_at,
         t.login_id, t.full_name, t.status, t.is_platform_admin, tm.status, tm.branch_id
  FROM sessions s JOIN users u ON u.id = s.user_id
  LEFT JOIN schools sc ON sc.id = s.school_id
  LEFT JOIN school_memberships m ON m.user_id = s.user_id AND m.school_id = s.school_id
  LEFT JOIN users t ON t.id = s.acting_user_id
  LEFT JOIN school_memberships tm ON tm.user_id = s.acting_user_id AND tm.school_id = s.school_id
  WHERE s.revoked_at IS NULL
    AND (s.token_hash = p_token_hash OR (s.prev_token_hash = p_token_hash AND s.prev_valid_until > now()))
  LIMIT 1;
END $$;
