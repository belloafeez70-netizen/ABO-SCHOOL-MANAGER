-- 008_rls.sql — Row-Level Security for tenant isolation + narrowly-scoped SECURITY DEFINER helpers.
-- The application connects as role abo_app (NOT owner, NOBYPASSRLS), so every query it issues is
-- filtered by these policies even if application code forgets a WHERE school_id = … clause.
-- Tables are owned by abo_owner (migrations); RLS is ENABLED but not FORCED so the owner's
-- SECURITY DEFINER functions below can perform the few cross-tenant lookups that must happen
-- before a tenant is known (login, session resolution, platform statistics).

DO $$
DECLARE t text;
BEGIN
  -- strictly tenant-scoped tables
  FOREACH t IN ARRAY ARRAY[
    'school_branches','school_settings','roles','role_permissions','user_roles','academic_sessions','terms',
    'staff','classes','subjects','class_subjects','students','guardians','student_guardians','enrollments',
    'attendance','timetable_entries','assessment_sheets','assessment_scores','assessment_score_history',
    'examination_results','term_results','broadsheets','report_cards','result_corrections','cbt_exams',
    'cbt_questions','cbt_options','cbt_attempts','cbt_answers','fee_items','fee_discounts','invoices',
    'invoice_lines','payments','doc_counters','documents','announcements','announcement_reads',
    'message_threads','thread_participants','messages','newsletters','imports','promotion_runs'
  ] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY tenant_isolation ON %I USING (school_id = app.current_school()) WITH CHECK (school_id = app.current_school())', t);
  END LOOP;

  -- tables that can hold platform-level rows (school_id NULL): visible to the owning tenant, or in platform mode
  FOREACH t IN ARRAY ARRAY[
    'users','sessions','mfa_recovery_codes','user_tokens','known_devices','uploads','notifications',
    'outbox_emails','payment_records','login_events','security_events','audit_logs','jobs'
  ] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY tenant_or_platform ON %I USING (school_id = app.current_school() OR app.is_platform()) WITH CHECK (school_id = app.current_school() OR app.is_platform())', t);
  END LOOP;
END $$;

ALTER TABLE schools ENABLE ROW LEVEL SECURITY;
CREATE POLICY school_self_or_platform ON schools
  USING (id = app.current_school() OR app.is_platform())
  WITH CHECK (id = app.current_school() OR app.is_platform());

-- ───────── pre-tenant lookups (definer functions return the minimum columns needed) ─────────
CREATE OR REPLACE FUNCTION app.auth_find_user(p_login text)
RETURNS TABLE (id uuid, school_id uuid, full_name text, password_hash text, status text, is_platform_admin boolean,
               failed_attempts integer, locked_until timestamptz, mfa_enabled boolean, must_change_password boolean,
               access_code_hash text, access_code_expires_at timestamptz, school_status text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT u.id, u.school_id, u.full_name, u.password_hash, u.status, u.is_platform_admin, u.failed_attempts,
         u.locked_until, u.mfa_enabled, u.must_change_password, u.access_code_hash, u.access_code_expires_at, s.status
  FROM users u LEFT JOIN schools s ON s.id = u.school_id
  WHERE lower(u.login_id) = lower(p_login)
  LIMIT 1
$$;

CREATE OR REPLACE FUNCTION app.auth_find_user_by_email(p_email text)
RETURNS TABLE (id uuid, school_id uuid, full_name text, email text, status text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT u.id, u.school_id, u.full_name, u.email, u.status FROM users u
  WHERE u.email IS NOT NULL AND lower(u.email) = lower(p_email) AND u.status = 'active'
  LIMIT 5
$$;

CREATE OR REPLACE FUNCTION app.auth_session(p_token_hash text)
RETURNS TABLE (session_id uuid, user_id uuid, school_id uuid, mfa_state text, support_school_id uuid,
               support_expires_at timestamptz, idle_expires_at timestamptz, expires_at timestamptz, rotated_at timestamptz,
               user_status text, is_platform_admin boolean, school_status text, login_id text, full_name text,
               must_change_password boolean, mfa_enabled boolean, email text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT s.id, s.user_id, s.school_id, s.mfa_state, s.support_school_id, s.support_expires_at, s.idle_expires_at,
         s.expires_at, s.rotated_at, u.status, u.is_platform_admin, sc.status, u.login_id, u.full_name,
         u.must_change_password, u.mfa_enabled, u.email
  FROM sessions s JOIN users u ON u.id = s.user_id LEFT JOIN schools sc ON sc.id = u.school_id
  WHERE s.token_hash = p_token_hash AND s.revoked_at IS NULL
  LIMIT 1
$$;

CREATE OR REPLACE FUNCTION app.auth_find_token(p_token_hash text, p_kind text)
RETURNS TABLE (token_id uuid, user_id uuid, school_id uuid, expires_at timestamptz, used_at timestamptz)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT t.id, t.user_id, t.school_id, t.expires_at, t.used_at FROM user_tokens t
  WHERE t.token_hash = p_token_hash AND t.kind = p_kind LIMIT 1
$$;

CREATE OR REPLACE FUNCTION app.school_code_taken(p_code text) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT EXISTS (SELECT 1 FROM schools WHERE lower(code) = lower(p_code))
$$;

CREATE OR REPLACE FUNCTION app.login_id_taken(p_login text) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT EXISTS (SELECT 1 FROM users WHERE lower(login_id) = lower(p_login))
$$;

-- platform statistics without granting platform mode read access to tenant data tables
CREATE OR REPLACE FUNCTION app.platform_school_stats()
RETURNS TABLE (school_id uuid, students bigint, staff bigint, users bigint, active_sessions bigint)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
BEGIN
  IF NOT app.is_platform() THEN RAISE EXCEPTION 'PLATFORM_ONLY' USING ERRCODE = '42501'; END IF;
  RETURN QUERY
    SELECT s.id,
      (SELECT count(*) FROM students st WHERE st.school_id = s.id AND st.deleted_at IS NULL AND st.status = 'active'),
      (SELECT count(*) FROM staff sf WHERE sf.school_id = s.id AND sf.employment_status <> 'exited'),
      (SELECT count(*) FROM users u WHERE u.school_id = s.id),
      (SELECT count(*) FROM sessions se WHERE se.school_id = s.id AND se.revoked_at IS NULL AND se.expires_at > now())
    FROM schools s;
END $$;

-- job claiming for the worker (cross-tenant by nature)
CREATE OR REPLACE FUNCTION app.claim_job(p_worker text)
RETURNS SETOF jobs LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
BEGIN
  RETURN QUERY
  UPDATE jobs j SET status = 'running', locked_at = now(), locked_by = p_worker, attempts = j.attempts + 1
  WHERE j.id = (SELECT id FROM jobs WHERE status = 'queued' AND run_at <= now()
                ORDER BY run_at FOR UPDATE SKIP LOCKED LIMIT 1)
  RETURNING j.*;
END $$;

CREATE OR REPLACE FUNCTION app.expired_cbt_attempts(p_limit integer)
RETURNS TABLE (attempt_id uuid, school_id uuid)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT id, school_id FROM cbt_attempts WHERE status = 'in_progress' AND deadline_at < now() - interval '30 seconds'
  ORDER BY deadline_at LIMIT p_limit
$$;
