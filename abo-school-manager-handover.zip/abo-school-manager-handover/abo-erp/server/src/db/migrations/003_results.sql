-- 003_results.sql — assessments (score sheets), scores, results, broadsheets, report cards, corrections
-- Workflow: draft → submitted → approved → published. approved/published sheets are LOCKED at the
-- database level (trigger below); the only way to change a locked score is an approved correction,
-- which the API applies inside a transaction that sets app.correction_sheet.

CREATE TABLE assessment_sheets (         -- one per (term, class, subject); the "assessment"/"examination"
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id     uuid NOT NULL,
  term_id       uuid NOT NULL,
  class_id      uuid NOT NULL,
  subject_id    uuid NOT NULL,
  components    jsonb NOT NULL,          -- frozen copy of [{key,label,max}] at creation
  status        text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','submitted','approved','published')),
  version       integer NOT NULL DEFAULT 1,
  review_note   text,
  submitted_by  uuid, submitted_at timestamptz,
  approved_by   uuid, approved_at  timestamptz,
  published_by  uuid, published_at timestamptz,
  created_by    uuid,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id),
  UNIQUE (term_id, class_id, subject_id),
  FOREIGN KEY (school_id, term_id)    REFERENCES terms (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, class_id)   REFERENCES classes (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, subject_id) REFERENCES subjects (school_id, id) ON DELETE CASCADE
);
CREATE INDEX assessment_sheets_class_term_idx ON assessment_sheets (school_id, class_id, term_id);
CREATE TRIGGER assessment_sheets_touch BEFORE UPDATE ON assessment_sheets FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();
CREATE VIEW assessments  WITH (security_invoker = true) AS SELECT * FROM assessment_sheets;
CREATE VIEW examinations WITH (security_invoker = true) AS SELECT * FROM assessment_sheets;

CREATE TABLE assessment_scores (
  school_id     uuid NOT NULL,
  sheet_id      uuid NOT NULL,
  student_id    uuid NOT NULL,
  component_key text NOT NULL CHECK (component_key ~ '^[a-z0-9_]{1,20}$'),
  score         numeric(6,2) CHECK (score IS NULL OR score >= 0),
  entered_by    uuid,
  updated_at    timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (sheet_id, student_id, component_key),
  FOREIGN KEY (school_id, sheet_id)   REFERENCES assessment_sheets (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, student_id) REFERENCES students (school_id, id) ON DELETE CASCADE
);
CREATE INDEX assessment_scores_student_idx ON assessment_scores (school_id, student_id);

CREATE TABLE assessment_score_history (   -- every change to a score, append-only
  id            bigserial PRIMARY KEY,
  school_id     uuid NOT NULL,
  sheet_id      uuid NOT NULL,
  student_id    uuid NOT NULL,
  component_key text NOT NULL,
  old_score     numeric(6,2),
  new_score     numeric(6,2),
  changed_by    uuid,
  via_correction uuid,
  changed_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX assessment_score_history_sheet_idx ON assessment_score_history (school_id, sheet_id);

-- Lock + history trigger
CREATE OR REPLACE FUNCTION app.guard_assessment_scores() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  v_status text; v_sheet uuid; v_corr text;
BEGIN
  v_sheet := COALESCE(NEW.sheet_id, OLD.sheet_id);
  SELECT status INTO v_status FROM assessment_sheets WHERE id = v_sheet;
  v_corr := NULLIF(current_setting('app.correction_sheet', true), '');
  IF v_status IN ('approved','published') AND (v_corr IS NULL OR v_corr::uuid <> v_sheet) THEN
    RAISE EXCEPTION 'RESULT_LOCKED: sheet % is %', v_sheet, v_status USING ERRCODE = 'P0001';
  END IF;
  IF TG_OP = 'DELETE' THEN
    INSERT INTO assessment_score_history (school_id, sheet_id, student_id, component_key, old_score, new_score, changed_by, via_correction)
    VALUES (OLD.school_id, OLD.sheet_id, OLD.student_id, OLD.component_key, OLD.score, NULL, app.current_user_id(), v_corr::uuid);
    RETURN OLD;
  END IF;
  IF TG_OP = 'INSERT' OR OLD.score IS DISTINCT FROM NEW.score THEN
    INSERT INTO assessment_score_history (school_id, sheet_id, student_id, component_key, old_score, new_score, changed_by, via_correction)
    VALUES (NEW.school_id, NEW.sheet_id, NEW.student_id, NEW.component_key,
            CASE WHEN TG_OP = 'UPDATE' THEN OLD.score END, NEW.score, app.current_user_id(), v_corr::uuid);
  END IF;
  NEW.updated_at := now();
  RETURN NEW;
END $$;
CREATE TRIGGER assessment_scores_guard BEFORE INSERT OR UPDATE OR DELETE ON assessment_scores
  FOR EACH ROW EXECUTE FUNCTION app.guard_assessment_scores();

CREATE TABLE examination_results (        -- computed per subject per student (server-side)
  school_id  uuid NOT NULL,
  sheet_id   uuid NOT NULL,
  student_id uuid NOT NULL,
  total      numeric(6,2) NOT NULL,
  grade      text NOT NULL,
  remark     text,
  subject_position integer,
  computed_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (sheet_id, student_id),
  FOREIGN KEY (school_id, sheet_id)   REFERENCES assessment_sheets (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, student_id) REFERENCES students (school_id, id) ON DELETE CASCADE
);

CREATE TABLE term_results (               -- one broadsheet row: per student per term
  school_id      uuid NOT NULL,
  term_id        uuid NOT NULL,
  class_id       uuid NOT NULL,
  student_id     uuid NOT NULL,
  subjects_count integer NOT NULL,
  total          numeric(8,2) NOT NULL,
  average        numeric(6,2) NOT NULL,
  highest        numeric(6,2),
  lowest         numeric(6,2),
  grade          text,
  position       integer,
  class_size     integer,
  status         text NOT NULL CHECK (status IN ('Pass','Fail','Pending')),
  published      boolean NOT NULL DEFAULT false,
  computed_at    timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (term_id, student_id),
  FOREIGN KEY (school_id, term_id)    REFERENCES terms (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, class_id)   REFERENCES classes (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, student_id) REFERENCES students (school_id, id) ON DELETE CASCADE
);
CREATE INDEX term_results_class_idx ON term_results (school_id, class_id, term_id);

CREATE TABLE broadsheets (                -- frozen, published snapshot (results archive)
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id    uuid NOT NULL,
  term_id      uuid NOT NULL,
  class_id     uuid NOT NULL,
  version      integer NOT NULL DEFAULT 1,
  snapshot     jsonb NOT NULL,
  published_by uuid,
  published_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (term_id, class_id, version),
  FOREIGN KEY (school_id, term_id)  REFERENCES terms (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, class_id) REFERENCES classes (school_id, id) ON DELETE CASCADE
);

CREATE TABLE report_cards (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id       uuid NOT NULL,
  term_id         uuid NOT NULL,
  student_id      uuid NOT NULL,
  teacher_comment text CHECK (teacher_comment IS NULL OR length(teacher_comment) <= 600),
  head_comment    text CHECK (head_comment IS NULL OR length(head_comment) <= 600),
  domains         jsonb NOT NULL DEFAULT '{}'::jsonb,      -- affective & psychomotor ratings 1..5
  days_present    integer,
  days_absent     integer,
  updated_by      uuid,
  updated_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (term_id, student_id),
  FOREIGN KEY (school_id, term_id)    REFERENCES terms (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, student_id) REFERENCES students (school_id, id) ON DELETE CASCADE
);

CREATE TABLE result_corrections (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id     uuid NOT NULL,
  sheet_id      uuid NOT NULL,
  student_id    uuid NOT NULL,
  component_key text NOT NULL,
  old_score     numeric(6,2),
  new_score     numeric(6,2) NOT NULL CHECK (new_score >= 0),
  reason        text NOT NULL CHECK (length(reason) BETWEEN 5 AND 500),
  status        text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  requested_by  uuid NOT NULL,
  requested_at  timestamptz NOT NULL DEFAULT now(),
  reviewed_by   uuid,
  reviewed_at   timestamptz,
  review_note   text,
  CHECK (reviewed_by IS NULL OR reviewed_by <> requested_by),     -- four-eyes principle
  FOREIGN KEY (school_id, sheet_id)   REFERENCES assessment_sheets (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, student_id) REFERENCES students (school_id, id) ON DELETE CASCADE
);
CREATE INDEX result_corrections_status_idx ON result_corrections (school_id, status);
