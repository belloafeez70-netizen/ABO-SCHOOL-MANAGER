-- 019_store_sales.sql — Phase 6 (part 2): the offline app's store / inventory and sales, with server-side rules.
--   • the server sets every price (the browser only sends item + quantity);
--   • stock can never go below zero (CHECK + row locks);
--   • every change of stock is a row in store_moves, so stock = sum of moves and can always be checked;
--   • a sale is never edited or deleted — it is voided with a reason and its stock is put back.
-- (ID cards and the comment helper in part 2 need no new tables.)

CREATE TABLE store_items (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id        uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  name             text NOT NULL CHECK (length(name) BETWEEN 2 AND 120),
  category         text CHECK (category IS NULL OR length(category) <= 60),
  sku              text CHECK (sku IS NULL OR length(sku) <= 40),
  unit_price_kobo  bigint NOT NULL CHECK (unit_price_kobo >= 0 AND unit_price_kobo <= 10000000000),
  cost_price_kobo  bigint CHECK (cost_price_kobo IS NULL OR (cost_price_kobo >= 0 AND cost_price_kobo <= 10000000000)),
  stock_qty        integer NOT NULL DEFAULT 0 CHECK (stock_qty >= 0),
  reorder_level    integer NOT NULL DEFAULT 0 CHECK (reorder_level >= 0),
  active           boolean NOT NULL DEFAULT true,
  created_by       uuid REFERENCES users(id),
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id)
);
CREATE UNIQUE INDEX store_items_name_uq ON store_items (school_id, lower(name));
CREATE UNIQUE INDEX store_items_sku_uq ON store_items (school_id, lower(sku)) WHERE sku IS NOT NULL;
CREATE TRIGGER store_items_touch BEFORE UPDATE ON store_items FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();

CREATE TABLE store_sales (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id    uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  receipt_no   text NOT NULL,
  student_id   uuid,
  buyer_name   text CHECK (buyer_name IS NULL OR length(buyer_name) <= 160),
  total_kobo   bigint NOT NULL CHECK (total_kobo > 0),
  method       text NOT NULL CHECK (method IN ('cash','transfer','pos')),
  reference    text CHECK (reference IS NULL OR length(reference) <= 80),
  sold_by      uuid REFERENCES users(id),
  sold_at      timestamptz NOT NULL DEFAULT now(),
  voided_at    timestamptz,
  voided_by    uuid REFERENCES users(id),
  void_reason  text CHECK (void_reason IS NULL OR length(void_reason) BETWEEN 3 AND 300),
  UNIQUE (school_id, id),
  UNIQUE (school_id, receipt_no),
  CHECK ((voided_at IS NULL) = (void_reason IS NULL)),
  FOREIGN KEY (school_id, student_id) REFERENCES students (school_id, id) ON DELETE SET NULL (student_id)
);
CREATE INDEX store_sales_date_idx ON store_sales (school_id, sold_at DESC);

CREATE TABLE store_sale_lines (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id        uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  sale_id          uuid NOT NULL,
  item_id          uuid NOT NULL,
  item_name        text NOT NULL,                 -- the name at the time of sale (receipts never change)
  qty              integer NOT NULL CHECK (qty BETWEEN 1 AND 10000),
  unit_price_kobo  bigint NOT NULL CHECK (unit_price_kobo >= 0),
  line_total_kobo  bigint NOT NULL CHECK (line_total_kobo = qty * unit_price_kobo),
  FOREIGN KEY (school_id, sale_id) REFERENCES store_sales (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, item_id) REFERENCES store_items (school_id, id)
);
CREATE INDEX store_sale_lines_sale_idx ON store_sale_lines (school_id, sale_id);

CREATE TABLE store_moves (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id   uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  item_id     uuid NOT NULL,
  kind        text NOT NULL CHECK (kind IN ('opening','restock','sale','sale_void','adjust')),
  qty         integer NOT NULL CHECK (qty <> 0),   -- + into the store, − out of the store
  unit_cost_kobo bigint CHECK (unit_cost_kobo IS NULL OR unit_cost_kobo >= 0),
  sale_id     uuid,
  reason      text CHECK (reason IS NULL OR length(reason) <= 300),
  created_by  uuid REFERENCES users(id),
  created_at  timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (school_id, item_id) REFERENCES store_items (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, sale_id) REFERENCES store_sales (school_id, id) ON DELETE SET NULL (sale_id),
  CHECK (kind <> 'adjust' OR reason IS NOT NULL)
);
CREATE INDEX store_moves_item_idx ON store_moves (school_id, item_id, created_at DESC);

-- sales and stock moves are a permanent record: only the void fields of a sale may ever change
CREATE OR REPLACE FUNCTION app.store_sales_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF OLD.voided_at IS NOT NULL THEN RAISE EXCEPTION 'a voided sale cannot be changed' USING ERRCODE = 'check_violation'; END IF;
  IF (NEW.receipt_no, NEW.total_kobo, NEW.method, NEW.sold_at, NEW.school_id, NEW.sold_by) IS DISTINCT FROM (OLD.receipt_no, OLD.total_kobo, OLD.method, OLD.sold_at, OLD.school_id, OLD.sold_by)
  THEN RAISE EXCEPTION 'sales are never edited; void the sale instead' USING ERRCODE = 'check_violation'; END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER store_sales_guard BEFORE UPDATE ON store_sales FOR EACH ROW EXECUTE FUNCTION app.store_sales_guard();
CREATE OR REPLACE FUNCTION app.no_change() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION '% rows are a permanent record and cannot be changed or deleted', TG_TABLE_NAME USING ERRCODE = 'check_violation'; END $$;
CREATE TRIGGER store_moves_frozen BEFORE UPDATE OR DELETE ON store_moves FOR EACH ROW WHEN (pg_trigger_depth() = 0) EXECUTE FUNCTION app.no_change();
CREATE TRIGGER store_sale_lines_frozen BEFORE UPDATE OR DELETE ON store_sale_lines FOR EACH ROW WHEN (pg_trigger_depth() = 0) EXECUTE FUNCTION app.no_change();

DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['store_items','store_sales','store_sale_lines','store_moves'] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY tenant_isolation ON %I USING (school_id = app.current_school()) WITH CHECK (school_id = app.current_school())', t);
  END LOOP;
END $$;

INSERT INTO permissions (key, module, description) VALUES
  ('store.view', 'store', 'See store items, stock and sales'),
  ('store.manage', 'store', 'Add store items, set prices, receive stock and correct stock counts'),
  ('store.sell', 'store', 'Sell items from the store and issue receipts'),
  ('store.void', 'store', 'Void a store sale (stock goes back)')
ON CONFLICT (key) DO NOTHING;

INSERT INTO role_permissions (school_id, role_id, permission_key)
SELECT r.school_id, r.id, p.key
FROM roles r JOIN (
  SELECT k AS role_key, x AS key FROM unnest(ARRAY['school_owner','principal','administrator','bursar']) k, unnest(ARRAY['store.view','store.manage','store.sell','store.void']) x
  UNION ALL
  SELECT 'accountant', x FROM unnest(ARRAY['store.view','store.sell']) x
  UNION ALL
  SELECT 'librarian', 'store.view'
) p ON p.role_key = r.key
WHERE r.is_system
ON CONFLICT DO NOTHING;
