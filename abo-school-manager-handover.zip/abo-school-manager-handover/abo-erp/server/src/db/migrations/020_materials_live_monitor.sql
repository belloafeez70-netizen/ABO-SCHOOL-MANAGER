-- 020_materials_live_monitor.sql — Phase 6 (part 3): study materials (files, links, videos), live classes and the
-- bell times the class monitor uses. Every table carries school_id with row-level security.

ALTER TABLE uploads DROP CONSTRAINT uploads_purpose_check;
ALTER TABLE uploads ADD CONSTRAINT uploads_purpose_check
  CHECK (purpose IN ('logo','passport','document','cbt_image','import','export','signature','lesson_note','study_material'));

CREATE TABLE study_materials (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id    uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  class_id     uuid NOT NULL,
  subject_id   uuid,
  title        text NOT NULL CHECK (length(title) BETWEEN 2 AND 160),
  description  text CHECK (description IS NULL OR length(description) <= 2000),
  kind         text NOT NULL CHECK (kind IN ('file','link','video')),
  url          text CHECK (url IS NULL OR (url ~ '^https://' AND length(url) <= 500)),
  file_id      uuid,
  published    boolean NOT NULL DEFAULT true,
  created_by   uuid REFERENCES users(id),
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now(),
  deleted_at   timestamptz,
  UNIQUE (school_id, id),
  CHECK ((kind = 'file') = (file_id IS NOT NULL) AND (kind = 'file') = (url IS NULL)),
  FOREIGN KEY (school_id, class_id)   REFERENCES classes (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, subject_id) REFERENCES subjects (school_id, id) ON DELETE SET NULL (subject_id),
  FOREIGN KEY (school_id, file_id)    REFERENCES uploads (school_id, id)
);
CREATE INDEX study_materials_class_idx ON study_materials (school_id, class_id, created_at DESC) WHERE deleted_at IS NULL;
CREATE INDEX study_materials_file_idx ON study_materials (file_id) WHERE file_id IS NOT NULL;
CREATE TRIGGER study_materials_touch BEFORE UPDATE ON study_materials FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();

CREATE TABLE live_classes (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id     uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  class_id      uuid NOT NULL,
  subject_id    uuid,
  title         text NOT NULL CHECK (length(title) BETWEEN 2 AND 160),
  starts_at     timestamptz NOT NULL,
  duration_min  integer NOT NULL CHECK (duration_min BETWEEN 5 AND 480),
  join_url      text NOT NULL CHECK (join_url ~ '^https://' AND length(join_url) <= 500),
  note          text CHECK (note IS NULL OR length(note) <= 1000),
  created_by    uuid REFERENCES users(id),
  created_at    timestamptz NOT NULL DEFAULT now(),
  cancelled_at  timestamptz,
  UNIQUE (school_id, id),
  FOREIGN KEY (school_id, class_id)   REFERENCES classes (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, subject_id) REFERENCES subjects (school_id, id) ON DELETE SET NULL (subject_id)
);
CREATE INDEX live_classes_time_idx ON live_classes (school_id, starts_at) WHERE cancelled_at IS NULL;

-- the school's bell times (period → start/end); a timetable entry's own times win when they are set
CREATE TABLE school_periods (
  school_id  uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  period     smallint NOT NULL CHECK (period BETWEEN 1 AND 16),
  starts_at  time NOT NULL,
  ends_at    time NOT NULL,
  label      text CHECK (label IS NULL OR length(label) <= 40),
  PRIMARY KEY (school_id, period),
  CHECK (ends_at > starts_at)
);

DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['study_materials','live_classes','school_periods'] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY tenant_isolation ON %I USING (school_id = app.current_school()) WITH CHECK (school_id = app.current_school())', t);
  END LOOP;
END $$;

INSERT INTO permissions (key, module, description) VALUES
  ('materials.create', 'academic', 'Share study materials and live classes with classes you teach'),
  ('materials.manage', 'academic', 'Share with any class and remove anyone''s study materials and live classes'),
  ('materials.view', 'academic', 'See all study materials and live classes'),
  ('materials.view_own', 'academic', 'Student: study materials and live classes for own class'),
  ('materials.view_children', 'academic', 'Parent: study materials and live classes for children’s classes')
ON CONFLICT (key) DO NOTHING;

INSERT INTO role_permissions (school_id, role_id, permission_key)
SELECT r.school_id, r.id, p.key
FROM roles r JOIN (
  SELECT k AS role_key, x AS key FROM unnest(ARRAY['school_owner','principal','administrator','vice_principal','head_of_school']) k, unnest(ARRAY['materials.create','materials.manage','materials.view']) x
  UNION ALL
  SELECT k, x FROM unnest(ARRAY['teacher','form_teacher','exam_officer']) k, unnest(ARRAY['materials.create','materials.view']) x
  UNION ALL SELECT 'student', 'materials.view_own'
  UNION ALL SELECT 'parent', 'materials.view_children'
) p ON p.role_key = r.key
WHERE r.is_system
ON CONFLICT DO NOTHING;
