-- 006_comms_files.sql — files/uploads, documents, announcements, messages, notifications, newsletters

CREATE TABLE uploads (                   -- "files": metadata only; bytes live in object storage
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id     uuid REFERENCES schools(id) ON DELETE CASCADE,
  storage_key   text NOT NULL UNIQUE,
  original_name text NOT NULL,
  mime          text NOT NULL,
  size_bytes    bigint NOT NULL CHECK (size_bytes > 0),
  sha256        text NOT NULL,
  purpose       text NOT NULL CHECK (purpose IN ('logo','passport','document','cbt_image','import','export','signature')),
  scan_status   text NOT NULL DEFAULT 'pending' CHECK (scan_status IN ('pending','clean','infected','skipped','error')),
  uploaded_by   uuid,
  created_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz,
  UNIQUE (school_id, id)
);
CREATE VIEW files WITH (security_invoker = true) AS SELECT * FROM uploads WHERE deleted_at IS NULL;

CREATE TABLE documents (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id   uuid NOT NULL,
  owner_type  text NOT NULL CHECK (owner_type IN ('student','staff','school')),
  owner_id    uuid,
  category    text NOT NULL DEFAULT 'general',
  title       text NOT NULL CHECK (length(title) BETWEEN 1 AND 160),
  file_id     uuid NOT NULL,
  visibility  text NOT NULL DEFAULT 'staff' CHECK (visibility IN ('staff','owner_and_staff')),
  created_by  uuid,
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id),
  FOREIGN KEY (school_id, file_id) REFERENCES uploads (school_id, id) ON DELETE CASCADE
);
CREATE INDEX documents_owner_idx ON documents (school_id, owner_type, owner_id);

CREATE TABLE announcements (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id  uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  title      text NOT NULL CHECK (length(title) BETWEEN 2 AND 160),
  body       text NOT NULL CHECK (length(body) BETWEEN 1 AND 8000),
  audience   text NOT NULL DEFAULT 'all' CHECK (audience IN ('all','staff','teachers','students','parents')),
  class_id   uuid,
  role_key   text,
  priority   text NOT NULL DEFAULT 'normal' CHECK (priority IN ('normal','important','urgent')),
  pinned     boolean NOT NULL DEFAULT false,
  publish_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id),
  FOREIGN KEY (school_id, class_id) REFERENCES classes (school_id, id) ON DELETE CASCADE
);
CREATE INDEX announcements_pub_idx ON announcements (school_id, publish_at DESC);

CREATE TABLE announcement_reads (
  school_id       uuid NOT NULL,
  announcement_id uuid NOT NULL,
  user_id         uuid NOT NULL,
  read_at         timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (announcement_id, user_id),
  FOREIGN KEY (school_id, announcement_id) REFERENCES announcements (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, user_id) REFERENCES users (school_id, id) ON DELETE CASCADE
);

CREATE TABLE message_threads (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id   uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  subject     text NOT NULL CHECK (length(subject) BETWEEN 1 AND 160),
  student_id  uuid,                        -- optional context (e.g. parent ↔ teacher about a child)
  created_by  uuid NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now(),
  last_message_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id),
  FOREIGN KEY (school_id, student_id) REFERENCES students (school_id, id) ON DELETE SET NULL (student_id)
);

CREATE TABLE thread_participants (
  school_id    uuid NOT NULL,
  thread_id    uuid NOT NULL,
  user_id      uuid NOT NULL,
  last_read_at timestamptz,
  PRIMARY KEY (thread_id, user_id),
  FOREIGN KEY (school_id, thread_id) REFERENCES message_threads (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, user_id)   REFERENCES users (school_id, id) ON DELETE CASCADE
);
CREATE INDEX thread_participants_user_idx ON thread_participants (school_id, user_id);

CREATE TABLE messages (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id  uuid NOT NULL,
  thread_id  uuid NOT NULL,
  sender_id  uuid NOT NULL,
  body       text NOT NULL CHECK (length(body) BETWEEN 1 AND 5000),
  created_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (school_id, thread_id) REFERENCES message_threads (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, sender_id) REFERENCES users (school_id, id) ON DELETE CASCADE
);
CREATE INDEX messages_thread_idx ON messages (thread_id, created_at);

CREATE TABLE notifications (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id  uuid REFERENCES schools(id) ON DELETE CASCADE,
  user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind       text NOT NULL,
  title      text NOT NULL,
  body       text,
  link       text CHECK (link IS NULL OR link ~ '^#/[A-Za-z0-9/_?=&.-]*$'),   -- internal hash links only
  read_at    timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX notifications_user_idx ON notifications (user_id, read_at, created_at DESC);

CREATE TABLE newsletters (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id    uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  title        text NOT NULL CHECK (length(title) BETWEEN 2 AND 160),
  body         text NOT NULL CHECK (length(body) <= 60000),     -- plain text / light markdown, rendered as text (no raw HTML)
  audience     text NOT NULL DEFAULT 'parents' CHECK (audience IN ('all','parents','students','staff')),
  status       text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published')),
  published_at timestamptz,
  created_by   uuid,
  created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE outbox_emails (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id   uuid REFERENCES schools(id) ON DELETE CASCADE,
  to_address  text NOT NULL,
  subject     text NOT NULL,
  body_text   text NOT NULL,
  template    text,
  status      text NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','sent','failed','dev_logged')),
  attempts    integer NOT NULL DEFAULT 0,
  last_error  text,
  created_at  timestamptz NOT NULL DEFAULT now(),
  sent_at     timestamptz
);
