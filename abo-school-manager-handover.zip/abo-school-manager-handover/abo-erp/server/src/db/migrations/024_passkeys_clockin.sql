-- 024_passkeys_clockin.sql — fingerprint / face confirmation for staff clock-in (WebAuthn passkeys), checked on the SERVER.
-- The phone's fingerprint or face never leaves the phone: the phone signs a one-time challenge with a key that was
-- created on that phone; the server keeps only the PUBLIC key and checks the signature (and the signature counter).
CREATE TABLE webauthn_credentials (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id      uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  user_id        uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  credential_id  text NOT NULL CHECK (length(credential_id) BETWEEN 16 AND 1400),   -- base64url, as sent by the phone
  public_key     bytea NOT NULL,
  counter        bigint NOT NULL DEFAULT 0 CHECK (counter >= 0),
  transports     text[] NOT NULL DEFAULT '{}',
  device_label   text CHECK (device_label IS NULL OR length(device_label) <= 80),
  created_at     timestamptz NOT NULL DEFAULT now(),
  last_used_at   timestamptz,
  revoked_at     timestamptz,
  UNIQUE (school_id, id)
);
CREATE UNIQUE INDEX webauthn_credentials_cred_uq ON webauthn_credentials (credential_id);
CREATE INDEX webauthn_credentials_user_idx ON webauthn_credentials (school_id, user_id) WHERE revoked_at IS NULL;

-- one-time challenges (5 minutes, used once)
CREATE TABLE webauthn_challenges (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id   uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  purpose     text NOT NULL CHECK (purpose IN ('register','clock')),
  challenge   text NOT NULL,
  expires_at  timestamptz NOT NULL DEFAULT now() + interval '5 minutes',
  used_at     timestamptz,
  UNIQUE (school_id, id)
);
CREATE INDEX webauthn_challenges_user_idx ON webauthn_challenges (school_id, user_id, purpose, expires_at DESC);

ALTER TABLE clock_settings ADD COLUMN require_biometric boolean NOT NULL DEFAULT false;
ALTER TABLE staff_clock ADD COLUMN verified_by text CHECK (verified_by IS NULL OR verified_by IN ('passkey'));

DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['webauthn_credentials','webauthn_challenges'] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY tenant_isolation ON %I USING (school_id = app.current_school()) WITH CHECK (school_id = app.current_school())', t);
  END LOOP;
END $$;
