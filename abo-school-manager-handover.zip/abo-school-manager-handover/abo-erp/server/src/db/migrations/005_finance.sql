-- 005_finance.sql — fees, invoices, payments, receipts, discounts. All amounts are integer kobo.
-- Invoice totals and balances are computed by the server from fee items; clients never send totals.

CREATE TABLE fee_items (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id   uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  name        text NOT NULL CHECK (length(name) BETWEEN 2 AND 120),
  category    text NOT NULL DEFAULT 'tuition' CHECK (category IN ('tuition','development','uniform','books','transport','exam','ict','feeding','boarding','other')),
  amount_kobo bigint NOT NULL CHECK (amount_kobo >= 0 AND amount_kobo <= 100000000000),
  term_id     uuid,
  class_id    uuid,          -- NULL ⇒ applies to every class
  mandatory   boolean NOT NULL DEFAULT true,
  active      boolean NOT NULL DEFAULT true,
  created_by  uuid,
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id),
  FOREIGN KEY (school_id, term_id)  REFERENCES terms (school_id, id) ON DELETE SET NULL (term_id),
  FOREIGN KEY (school_id, class_id) REFERENCES classes (school_id, id) ON DELETE SET NULL (class_id)
);
CREATE VIEW fees WITH (security_invoker = true) AS SELECT * FROM fee_items WHERE active;

CREATE TABLE fee_discounts (             -- discounts & scholarships (approved by fees.approve)
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id     uuid NOT NULL,
  student_id    uuid NOT NULL,
  term_id       uuid,
  kind          text NOT NULL CHECK (kind IN ('discount','scholarship','sibling','staff_child')),
  percent       numeric(5,2) CHECK (percent IS NULL OR (percent > 0 AND percent <= 100)),
  amount_kobo   bigint CHECK (amount_kobo IS NULL OR amount_kobo > 0),
  reason        text NOT NULL,
  status        text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  requested_by  uuid, approved_by uuid, approved_at timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now(),
  CHECK ((percent IS NULL) <> (amount_kobo IS NULL)),
  CHECK (approved_by IS NULL OR approved_by <> requested_by),
  UNIQUE (school_id, id),
  FOREIGN KEY (school_id, student_id) REFERENCES students (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, term_id)    REFERENCES terms (school_id, id) ON DELETE CASCADE
);

CREATE TABLE invoices (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id       uuid NOT NULL,
  invoice_no      text NOT NULL,
  student_id      uuid NOT NULL,
  term_id         uuid,
  status          text NOT NULL DEFAULT 'unpaid' CHECK (status IN ('unpaid','partial','paid','void')),
  subtotal_kobo   bigint NOT NULL CHECK (subtotal_kobo >= 0),
  discount_kobo   bigint NOT NULL DEFAULT 0 CHECK (discount_kobo >= 0),
  total_kobo      bigint NOT NULL CHECK (total_kobo >= 0),
  paid_kobo       bigint NOT NULL DEFAULT 0 CHECK (paid_kobo >= 0),
  due_date        date,
  issued_by       uuid,
  issued_at       timestamptz NOT NULL DEFAULT now(),
  voided_by       uuid, voided_at timestamptz, void_reason text,
  CHECK (total_kobo = subtotal_kobo - discount_kobo),
  CHECK (paid_kobo <= total_kobo),
  UNIQUE (school_id, id),
  UNIQUE (school_id, invoice_no),
  FOREIGN KEY (school_id, student_id) REFERENCES students (school_id, id) ON DELETE RESTRICT,
  FOREIGN KEY (school_id, term_id)    REFERENCES terms (school_id, id) ON DELETE RESTRICT
);
CREATE UNIQUE INDEX invoices_one_per_term ON invoices (student_id, term_id) WHERE status <> 'void';
CREATE INDEX invoices_status_idx ON invoices (school_id, status, term_id);

CREATE TABLE invoice_lines (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id    uuid NOT NULL,
  invoice_id   uuid NOT NULL,
  fee_item_id  uuid,
  description  text NOT NULL,
  amount_kobo  bigint NOT NULL CHECK (amount_kobo >= 0),
  FOREIGN KEY (school_id, invoice_id)  REFERENCES invoices (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, fee_item_id) REFERENCES fee_items (school_id, id) ON DELETE SET NULL (fee_item_id)
);
CREATE VIEW fee_invoice_items WITH (security_invoker = true) AS SELECT * FROM invoice_lines;

CREATE TABLE payments (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id     uuid NOT NULL,
  invoice_id    uuid NOT NULL,
  student_id    uuid NOT NULL,
  amount_kobo   bigint NOT NULL CHECK (amount_kobo > 0),
  method        text NOT NULL CHECK (method IN ('cash','transfer','pos','cheque','online')),
  reference     text NOT NULL,
  receipt_no    text,
  status        text NOT NULL DEFAULT 'confirmed' CHECK (status IN ('pending','confirmed','reversed','failed')),
  provider      text,               -- e.g. paystack
  provider_ref  text,
  verified_at   timestamptz,
  note          text,
  received_by   uuid,
  paid_at       timestamptz NOT NULL DEFAULT now(),
  reversed_by   uuid, reversed_at timestamptz, reversal_reason text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id),
  UNIQUE (school_id, reference),
  FOREIGN KEY (school_id, invoice_id) REFERENCES invoices (school_id, id) ON DELETE RESTRICT,
  FOREIGN KEY (school_id, student_id) REFERENCES students (school_id, id) ON DELETE RESTRICT
);
CREATE UNIQUE INDEX payments_receipt_uq ON payments (school_id, receipt_no) WHERE receipt_no IS NOT NULL;
CREATE INDEX payments_invoice_idx ON payments (school_id, invoice_id);
CREATE INDEX payments_paid_at_idx ON payments (school_id, paid_at);

CREATE TABLE payment_records (           -- raw gateway events/webhooks (idempotency + evidence)
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id       uuid REFERENCES schools(id) ON DELETE CASCADE,
  provider        text NOT NULL,
  event           text NOT NULL,
  reference       text NOT NULL,
  signature_valid boolean NOT NULL,
  verified        boolean NOT NULL DEFAULT false,
  payload         jsonb NOT NULL,
  received_at     timestamptz NOT NULL DEFAULT now(),
  UNIQUE (provider, reference, event)
);

CREATE TABLE doc_counters (              -- gap-free per-school numbering for invoices/receipts
  school_id uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  kind      text NOT NULL,
  year      integer NOT NULL,
  last_no   integer NOT NULL DEFAULT 0,
  PRIMARY KEY (school_id, kind, year)
);
