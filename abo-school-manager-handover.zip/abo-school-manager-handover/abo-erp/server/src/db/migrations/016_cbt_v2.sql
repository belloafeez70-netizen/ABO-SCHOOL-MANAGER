-- 016_cbt_v2.sql — CBT / Online Examination v2, built ON the existing CBT tables (no parallel system).
--
-- Question bank = cbt_questions with exam_id IS NULL (unchanged). Exam questions stay frozen COPIES of bank
-- questions (source_question_id keeps the link for analytics) so editing the bank never alters a live exam.
-- Results still flow through cbt_attempts → cbt_results; a validated push writes the CBT score into the EXISTING
-- assessment_scores of the matching (term, class, subject) sheet, so the school's own components, weighting,
-- grading, positions and approval workflow apply unchanged.

-- ── question bank metadata + new question types ──
ALTER TABLE cbt_questions DROP CONSTRAINT cbt_questions_type_check;
ALTER TABLE cbt_questions ADD CONSTRAINT cbt_questions_type_check
  CHECK (type IN ('mcq','multi_select','true_false','short_answer','numeric','fill_blank','theory'));
ALTER TABLE cbt_questions
  ADD COLUMN class_id uuid,
  ADD COLUMN session_id uuid,
  ADD COLUMN term_id uuid,
  ADD COLUMN topic text CHECK (topic IS NULL OR length(topic) BETWEEN 1 AND 120),
  ADD COLUMN subtopic text CHECK (subtopic IS NULL OR length(subtopic) BETWEEN 1 AND 120),
  ADD COLUMN difficulty text NOT NULL DEFAULT 'medium' CHECK (difficulty IN ('easy','medium','hard')),
  ADD COLUMN explanation text CHECK (explanation IS NULL OR length(explanation) <= 4000),
  -- text-answer keys (never sent to candidates): {"accepted":["7","seven"],"caseSensitive":false} | {"value":3.5,"tolerance":0.01}
  ADD COLUMN answer_key jsonb,
  ADD COLUMN status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','archived')),
  ADD COLUMN source_question_id uuid,
  ADD COLUMN updated_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN updated_by uuid;
ALTER TABLE cbt_questions
  ADD CONSTRAINT cbt_questions_class_fk FOREIGN KEY (school_id, class_id) REFERENCES classes (school_id, id) ON DELETE SET NULL (class_id),
  ADD CONSTRAINT cbt_questions_session_fk FOREIGN KEY (school_id, session_id) REFERENCES academic_sessions (school_id, id) ON DELETE SET NULL (session_id),
  ADD CONSTRAINT cbt_questions_term_fk FOREIGN KEY (school_id, term_id) REFERENCES terms (school_id, id) ON DELETE SET NULL (term_id);
DROP INDEX IF EXISTS cbt_questions_bank_idx;
CREATE INDEX cbt_questions_bank_idx ON cbt_questions (school_id, subject_id, class_id, status, difficulty) WHERE exam_id IS NULL;
CREATE INDEX cbt_questions_topic_idx ON cbt_questions (school_id, lower(topic)) WHERE exam_id IS NULL;
CREATE INDEX cbt_questions_text_trgm ON cbt_questions USING gin (lower(text) gin_trgm_ops) WHERE exam_id IS NULL;
CREATE INDEX cbt_questions_source_idx ON cbt_questions (school_id, source_question_id) WHERE source_question_id IS NOT NULL;

-- ── examination settings ──
ALTER TABLE cbt_exams DROP CONSTRAINT cbt_exams_category_check;
ALTER TABLE cbt_exams ADD CONSTRAINT cbt_exams_category_check CHECK (category IN ('test','exam','practice','assignment','ca','mock'));
ALTER TABLE cbt_exams
  ADD COLUMN session_id uuid,
  ADD COLUMN allow_back_nav boolean NOT NULL DEFAULT true,
  ADD COLUMN allow_review boolean NOT NULL DEFAULT true,
  ADD COLUMN show_answers boolean NOT NULL DEFAULT false,
  ADD COLUMN allow_resume boolean NOT NULL DEFAULT true,
  ADD COLUMN fullscreen boolean NOT NULL DEFAULT false,
  ADD COLUMN autosave boolean NOT NULL DEFAULT true,
  ADD COLUMN access_code_hash text,
  -- contribution to the EXISTING result sheet: assessment component key (e.g. 'exam', 'ca1'); NULL = stand-alone CBT
  ADD COLUMN score_component text CHECK (score_component IS NULL OR score_component ~ '^[a-z0-9_]{1,20}$'),
  ADD COLUMN score_policy text NOT NULL DEFAULT 'best' CHECK (score_policy IN ('best','latest')),
  ADD COLUMN scores_pushed_at timestamptz,
  ADD COLUMN scores_pushed_by uuid;
ALTER TABLE cbt_exams ADD CONSTRAINT cbt_exams_session_fk FOREIGN KEY (school_id, session_id) REFERENCES academic_sessions (school_id, id) ON DELETE SET NULL (session_id);
CREATE INDEX cbt_exams_window_idx ON cbt_exams (school_id, status, starts_at, ends_at);
CREATE INDEX cbt_exams_subject_idx ON cbt_exams (school_id, subject_id, term_id);

-- ── candidates (when rows exist they replace the class-wide default; old exams keep working by class) ──
CREATE TABLE cbt_exam_candidates (
  school_id  uuid NOT NULL,
  exam_id    uuid NOT NULL,
  student_id uuid NOT NULL,
  added_by   uuid,
  added_at   timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (exam_id, student_id),
  FOREIGN KEY (school_id, exam_id)    REFERENCES cbt_exams (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, student_id) REFERENCES students (school_id, id) ON DELETE CASCADE
);
CREATE INDEX cbt_exam_candidates_student_idx ON cbt_exam_candidates (school_id, student_id);
ALTER TABLE cbt_exam_candidates ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON cbt_exam_candidates USING (school_id = app.current_school()) WITH CHECK (school_id = app.current_school());

-- ── attempts: void (reset), navigation high-water mark ──
ALTER TABLE cbt_attempts DROP CONSTRAINT cbt_attempts_status_check;
ALTER TABLE cbt_attempts ADD CONSTRAINT cbt_attempts_status_check CHECK (status IN ('in_progress','submitted','auto_submitted','graded','void'));
ALTER TABLE cbt_attempts
  ADD COLUMN furthest_index integer NOT NULL DEFAULT 0,
  ADD COLUMN void_reason text,
  ADD COLUMN voided_by uuid,
  ADD COLUMN voided_at timestamptz;
CREATE INDEX cbt_attempts_exam_idx ON cbt_attempts (school_id, exam_id, student_id);

-- ── answers: multiple-select, mark-for-review, time on question ──
ALTER TABLE cbt_answers
  ADD COLUMN option_ids uuid[],
  ADD COLUMN flagged boolean NOT NULL DEFAULT false,
  ADD COLUMN time_spent_seconds integer NOT NULL DEFAULT 0 CHECK (time_spent_seconds BETWEEN 0 AND 86400);
CREATE INDEX cbt_answers_question_idx ON cbt_answers (school_id, question_id);

-- ── results: release / withhold ──
ALTER TABLE cbt_results
  ADD COLUMN released boolean NOT NULL DEFAULT false,
  ADD COLUMN released_at timestamptz,
  ADD COLUMN released_by uuid,
  ADD COLUMN withheld_reason text CHECK (withheld_reason IS NULL OR length(withheld_reason) <= 300);
UPDATE cbt_results r SET released = e.show_result, released_at = CASE WHEN e.show_result THEN r.finalized_at END FROM cbt_exams e WHERE e.id = r.exam_id;

-- ── school-level CBT defaults ──
ALTER TABLE school_settings ADD COLUMN cbt jsonb NOT NULL DEFAULT '{}'::jsonb;

-- the auto-submit sweep must also cover attempts whose exam closed; unchanged function keeps working (status filter)
CREATE TRIGGER cbt_questions_touch BEFORE UPDATE ON cbt_questions FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();
-- bulk question import reuses the existing validated imports pipeline (preview → commit)
ALTER TABLE imports DROP CONSTRAINT imports_kind_check;
ALTER TABLE imports ADD CONSTRAINT imports_kind_check CHECK (kind IN ('students','staff','guardians','subjects','classes','scores','legacy','cbt_questions'));
