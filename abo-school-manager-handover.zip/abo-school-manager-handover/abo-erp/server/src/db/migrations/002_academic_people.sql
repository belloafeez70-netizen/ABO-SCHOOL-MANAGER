-- 002_academic_people.sql — academic structure, people, enrolment, attendance, timetable

CREATE TABLE academic_sessions (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id  uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  name       text NOT NULL CHECK (name ~ '^[0-9]{4}/[0-9]{4}$'),
  starts_on  date,
  ends_on    date,
  is_current boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id),
  UNIQUE (school_id, name),
  CHECK (ends_on IS NULL OR starts_on IS NULL OR ends_on > starts_on)
);
CREATE UNIQUE INDEX academic_sessions_one_current ON academic_sessions (school_id) WHERE is_current;

CREATE TABLE terms (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id        uuid NOT NULL,
  session_id       uuid NOT NULL,
  name             text NOT NULL CHECK (name IN ('1ST','2ND','3RD')),
  starts_on        date,
  ends_on          date,
  days_open        integer CHECK (days_open IS NULL OR days_open BETWEEN 0 AND 366),
  next_term_begins date,
  is_current       boolean NOT NULL DEFAULT false,
  created_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id),
  UNIQUE (session_id, name),
  FOREIGN KEY (school_id, session_id) REFERENCES academic_sessions (school_id, id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX terms_one_current ON terms (school_id) WHERE is_current;

CREATE TABLE staff (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id         uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  user_id           uuid,
  staff_no          text,
  full_name         text NOT NULL CHECK (length(full_name) BETWEEN 2 AND 160),
  gender            text CHECK (gender IN ('Male','Female')),
  phone             text,
  email             text,
  designation       text,
  is_teacher        boolean NOT NULL DEFAULT true,
  employment_status text NOT NULL DEFAULT 'active' CHECK (employment_status IN ('active','on_leave','exited')),
  date_joined       date,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id),
  FOREIGN KEY (school_id, user_id) REFERENCES users (school_id, id) ON DELETE SET NULL (user_id)
);
CREATE UNIQUE INDEX staff_user_uq ON staff (user_id) WHERE user_id IS NOT NULL;
CREATE UNIQUE INDEX staff_no_uq ON staff (school_id, lower(staff_no)) WHERE staff_no IS NOT NULL;
CREATE INDEX staff_name_trgm ON staff USING gin (lower(full_name) gin_trgm_ops);
CREATE TRIGGER staff_touch BEFORE UPDATE ON staff FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();
-- "teachers" is exposed as a view over staff so the teaching list is always consistent.
CREATE VIEW teachers WITH (security_invoker = true) AS
  SELECT * FROM staff WHERE is_teacher AND employment_status <> 'exited';

CREATE TABLE classes (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id       uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  branch_id       uuid,
  name            text NOT NULL CHECK (length(name) BETWEEN 1 AND 40),   -- e.g. BASIC 1, JSS 2
  arm             text NOT NULL DEFAULT '' CHECK (arm ~ '^[A-Za-z0-9 ]{0,12}$'),  -- e.g. A, B, Gold
  section         text NOT NULL DEFAULT 'primary' CHECK (section IN ('nursery','primary','secondary')),
  display_name    text GENERATED ALWAYS AS (btrim(name || CASE WHEN arm = '' THEN '' ELSE arm END)) STORED,
  form_teacher_id uuid,
  capacity        integer CHECK (capacity IS NULL OR capacity BETWEEN 1 AND 500),
  sort_order      integer NOT NULL DEFAULT 0,
  created_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id),
  UNIQUE (school_id, name, arm),
  FOREIGN KEY (school_id, branch_id) REFERENCES school_branches (school_id, id) ON DELETE SET NULL (branch_id),
  FOREIGN KEY (school_id, form_teacher_id) REFERENCES staff (school_id, id) ON DELETE SET NULL (form_teacher_id)
);

CREATE TABLE subjects (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id  uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  name       text NOT NULL CHECK (length(name) BETWEEN 2 AND 80),
  code       text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id)
);
CREATE UNIQUE INDEX subjects_name_uq ON subjects (school_id, lower(name));

CREATE TABLE class_subjects (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id  uuid NOT NULL,
  class_id   uuid NOT NULL,
  subject_id uuid NOT NULL,
  teacher_id uuid,
  UNIQUE (school_id, id),
  UNIQUE (class_id, subject_id),
  FOREIGN KEY (school_id, class_id)   REFERENCES classes  (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, subject_id) REFERENCES subjects (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, teacher_id) REFERENCES staff    (school_id, id) ON DELETE SET NULL (teacher_id)
);
CREATE INDEX class_subjects_teacher_idx ON class_subjects (school_id, teacher_id);

CREATE TABLE students (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id        uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  user_id          uuid,
  admission_no     text NOT NULL CHECK (length(admission_no) BETWEEN 1 AND 40),
  first_name       text NOT NULL CHECK (length(first_name) BETWEEN 1 AND 80),
  last_name        text NOT NULL CHECK (length(last_name) BETWEEN 1 AND 80),
  other_names      text,
  gender           text NOT NULL CHECK (gender IN ('Male','Female')),
  date_of_birth    date,
  status           text NOT NULL DEFAULT 'active' CHECK (status IN ('active','graduated','transferred','withdrawn')),
  passport_file_id uuid,
  address          text,
  medical_notes    text,
  deleted_at       timestamptz,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id),
  FOREIGN KEY (school_id, user_id) REFERENCES users (school_id, id) ON DELETE SET NULL (user_id)
);
CREATE UNIQUE INDEX students_admno_uq ON students (school_id, lower(admission_no));
CREATE UNIQUE INDEX students_user_uq ON students (user_id) WHERE user_id IS NOT NULL;
CREATE INDEX students_school_status_idx ON students (school_id, status) WHERE deleted_at IS NULL;
CREATE INDEX students_name_trgm ON students USING gin ((lower(last_name || ' ' || first_name || ' ' || coalesce(other_names,''))) gin_trgm_ops);
CREATE TRIGGER students_touch BEFORE UPDATE ON students FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();

CREATE TABLE guardians (                -- "parents" and other guardians
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id    uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  user_id      uuid,
  full_name    text NOT NULL CHECK (length(full_name) BETWEEN 2 AND 160),
  relationship text NOT NULL DEFAULT 'Parent',
  phone        text,
  whatsapp     text,
  email        text,
  address      text,
  occupation   text,
  created_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id),
  FOREIGN KEY (school_id, user_id) REFERENCES users (school_id, id) ON DELETE SET NULL (user_id)
);
CREATE UNIQUE INDEX guardians_user_uq ON guardians (user_id) WHERE user_id IS NOT NULL;
CREATE INDEX guardians_phone_idx ON guardians (school_id, phone);
CREATE VIEW parents WITH (security_invoker = true) AS SELECT * FROM guardians;

CREATE TABLE student_guardians (
  school_id   uuid NOT NULL,
  student_id  uuid NOT NULL,
  guardian_id uuid NOT NULL,
  is_primary  boolean NOT NULL DEFAULT false,
  PRIMARY KEY (student_id, guardian_id),
  FOREIGN KEY (school_id, student_id)  REFERENCES students  (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, guardian_id) REFERENCES guardians (school_id, id) ON DELETE CASCADE
);
CREATE INDEX student_guardians_guardian_idx ON student_guardians (guardian_id);

CREATE TABLE enrollments (              -- class membership per academic session ("class_members")
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id  uuid NOT NULL,
  student_id uuid NOT NULL,
  class_id   uuid NOT NULL,
  session_id uuid NOT NULL,
  status     text NOT NULL DEFAULT 'active' CHECK (status IN ('active','promoted','repeated','graduated','transferred','withdrawn')),
  roll_no    integer,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id),
  UNIQUE (student_id, session_id),
  FOREIGN KEY (school_id, student_id) REFERENCES students (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, class_id)   REFERENCES classes (school_id, id) ON DELETE RESTRICT,
  FOREIGN KEY (school_id, session_id) REFERENCES academic_sessions (school_id, id) ON DELETE CASCADE
);
CREATE INDEX enrollments_class_idx ON enrollments (school_id, class_id, session_id, status);
CREATE VIEW class_members WITH (security_invoker = true) AS SELECT * FROM enrollments WHERE status = 'active';

CREATE TABLE attendance (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id  uuid NOT NULL,
  student_id uuid NOT NULL,
  class_id   uuid NOT NULL,
  term_id    uuid,
  date       date NOT NULL,
  status     text NOT NULL CHECK (status IN ('present','absent','late','excused')),
  note       text,
  marked_by  uuid,
  marked_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (student_id, date),
  FOREIGN KEY (school_id, student_id) REFERENCES students (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, class_id)   REFERENCES classes (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, term_id)    REFERENCES terms (school_id, id) ON DELETE SET NULL (term_id)
);
CREATE INDEX attendance_class_date_idx ON attendance (school_id, class_id, date);
CREATE INDEX attendance_term_idx ON attendance (school_id, term_id, student_id);

CREATE TABLE timetable_entries (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id   uuid NOT NULL,
  class_id    uuid NOT NULL,
  subject_id  uuid,
  teacher_id  uuid,
  day_of_week smallint NOT NULL CHECK (day_of_week BETWEEN 1 AND 7),
  period      smallint NOT NULL CHECK (period BETWEEN 1 AND 16),
  starts_at   time,
  ends_at     time,
  label       text,
  UNIQUE (class_id, day_of_week, period),
  FOREIGN KEY (school_id, class_id)   REFERENCES classes (school_id, id) ON DELETE CASCADE,
  FOREIGN KEY (school_id, subject_id) REFERENCES subjects (school_id, id) ON DELETE SET NULL (subject_id),
  FOREIGN KEY (school_id, teacher_id) REFERENCES staff (school_id, id) ON DELETE SET NULL (teacher_id)
);
