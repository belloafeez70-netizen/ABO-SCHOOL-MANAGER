-- 011_memberships.sql — users become GLOBAL identities; access to a school is granted through
-- school_memberships (optionally scoped to a branch). A user can belong to several schools.
-- Also: name parts, school registration/subscription fields, branch code/status, student contact fields.

-- ── schools / branches ──
ALTER TABLE schools ADD COLUMN registration_number text;
ALTER TABLE schools ADD COLUMN subscription_status text NOT NULL DEFAULT 'trial' CHECK (subscription_status IN ('trial','active','past_due','cancelled'));
ALTER TABLE schools ADD COLUMN subscription_expires_at timestamptz;
ALTER TABLE schools RENAME COLUMN code TO slug;
ALTER INDEX schools_code_uq RENAME TO schools_slug_uq;

ALTER TABLE school_branches ADD COLUMN code text;
ALTER TABLE school_branches ADD COLUMN status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','closed'));
ALTER TABLE school_branches ADD COLUMN updated_at timestamptz NOT NULL DEFAULT now();
CREATE UNIQUE INDEX school_branches_code_uq ON school_branches (school_id, lower(code)) WHERE code IS NOT NULL;
CREATE TRIGGER school_branches_touch BEFORE UPDATE ON school_branches FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();

-- ── users: name parts (full_name kept in sync by trigger) ──
ALTER TABLE users ADD COLUMN first_name text;
ALTER TABLE users ADD COLUMN middle_name text;
ALTER TABLE users ADD COLUMN last_name text;
CREATE OR REPLACE FUNCTION app.user_names() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE parts text[];
BEGIN
  IF NEW.first_name IS NOT NULL AND NEW.last_name IS NOT NULL
     AND (TG_OP = 'INSERT' OR NEW.first_name IS DISTINCT FROM OLD.first_name OR NEW.last_name IS DISTINCT FROM OLD.last_name OR NEW.middle_name IS DISTINCT FROM OLD.middle_name) THEN
    NEW.full_name := btrim(concat_ws(' ', NEW.first_name, NULLIF(NEW.middle_name, ''), NEW.last_name));
  ELSIF NEW.full_name IS NOT NULL AND (TG_OP = 'INSERT' OR NEW.full_name IS DISTINCT FROM OLD.full_name) THEN
    parts := regexp_split_to_array(btrim(NEW.full_name), '\s+');
    NEW.first_name := parts[1];
    NEW.last_name := CASE WHEN array_length(parts, 1) > 1 THEN parts[array_length(parts, 1)] ELSE parts[1] END;
    NEW.middle_name := CASE WHEN array_length(parts, 1) > 2 THEN array_to_string(parts[2:array_length(parts, 1) - 1], ' ') END;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER users_names BEFORE INSERT OR UPDATE ON users FOR EACH ROW EXECUTE FUNCTION app.user_names();
UPDATE users SET full_name = full_name;          -- backfill name parts

-- email is a global identity attribute now
DROP INDEX users_school_email_uq;
CREATE UNIQUE INDEX users_email_uq ON users (lower(email)) WHERE email IS NOT NULL;

-- ── memberships ──
CREATE TABLE school_memberships (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  school_id  uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  branch_id  uuid,                          -- NULL ⇒ whole school; set ⇒ branch-restricted (enforced by RLS, see 013)
  status     text NOT NULL DEFAULT 'active' CHECK (status IN ('invited','active','suspended','left')),
  is_default boolean NOT NULL DEFAULT false,
  invited_by uuid,
  last_used_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id),
  UNIQUE (school_id, user_id),
  FOREIGN KEY (school_id, branch_id) REFERENCES school_branches (school_id, id) ON DELETE SET NULL (branch_id)
);
CREATE INDEX school_memberships_user_idx ON school_memberships (user_id, status);
CREATE INDEX school_memberships_school_idx ON school_memberships (school_id, status);
CREATE TRIGGER school_memberships_touch BEFORE UPDATE ON school_memberships FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();
INSERT INTO school_memberships (user_id, school_id, status, is_default)
  SELECT id, school_id, CASE WHEN status = 'disabled' THEN 'suspended' ELSE 'active' END, true FROM users WHERE school_id IS NOT NULL;

-- re-point tenant-scoped user references from users(school_id,id) to memberships(school_id,user_id)
ALTER TABLE user_roles DROP CONSTRAINT user_roles_school_id_user_id_fkey;
ALTER TABLE user_roles ADD FOREIGN KEY (school_id, user_id) REFERENCES school_memberships (school_id, user_id) ON DELETE CASCADE;
ALTER TABLE staff DROP CONSTRAINT staff_school_id_user_id_fkey;
ALTER TABLE staff ADD FOREIGN KEY (school_id, user_id) REFERENCES school_memberships (school_id, user_id) ON DELETE SET NULL (user_id);
ALTER TABLE students DROP CONSTRAINT students_school_id_user_id_fkey;
ALTER TABLE students ADD FOREIGN KEY (school_id, user_id) REFERENCES school_memberships (school_id, user_id) ON DELETE SET NULL (user_id);
ALTER TABLE guardians DROP CONSTRAINT guardians_school_id_user_id_fkey;
ALTER TABLE guardians ADD FOREIGN KEY (school_id, user_id) REFERENCES school_memberships (school_id, user_id) ON DELETE SET NULL (user_id);
ALTER TABLE announcement_reads DROP CONSTRAINT announcement_reads_school_id_user_id_fkey;
ALTER TABLE announcement_reads ADD FOREIGN KEY (school_id, user_id) REFERENCES school_memberships (school_id, user_id) ON DELETE CASCADE;
ALTER TABLE thread_participants DROP CONSTRAINT thread_participants_school_id_user_id_fkey;
ALTER TABLE thread_participants ADD FOREIGN KEY (school_id, user_id) REFERENCES school_memberships (school_id, user_id) ON DELETE CASCADE;
ALTER TABLE messages DROP CONSTRAINT messages_school_id_sender_id_fkey;
ALTER TABLE messages ADD FOREIGN KEY (school_id, sender_id) REFERENCES school_memberships (school_id, user_id) ON DELETE CASCADE;
-- (staff/students/guardians keep their per-school "user_id is unique" indexes: one record per person per school)
DROP INDEX staff_user_uq;    CREATE UNIQUE INDEX staff_user_uq ON staff (school_id, user_id) WHERE user_id IS NOT NULL;
DROP INDEX students_user_uq; CREATE UNIQUE INDEX students_user_uq ON students (school_id, user_id) WHERE user_id IS NOT NULL;
DROP INDEX guardians_user_uq; CREATE UNIQUE INDEX guardians_user_uq ON guardians (school_id, user_id) WHERE user_id IS NOT NULL;

-- users.school_id now means "home school that created the identity" (kept for provenance/inserts)
ALTER TABLE users DROP CONSTRAINT users_check;
ALTER TABLE users ADD CONSTRAINT users_platform_no_home CHECK (NOT is_platform_admin OR school_id IS NULL);

-- ── RLS: identities are visible to (a) themselves, (b) schools they are a member of, (c) platform mode ──
ALTER TABLE school_memberships ENABLE ROW LEVEL SECURITY;
CREATE POLICY membership_visibility ON school_memberships
  USING (school_id = app.current_school() OR user_id = app.current_user_id() OR app.is_platform())
  WITH CHECK (school_id = app.current_school() OR app.is_platform());
DROP POLICY tenant_or_platform ON users;
CREATE POLICY users_select ON users FOR SELECT
  USING (id = app.current_user_id() OR app.is_platform() OR school_id = app.current_school()     -- home school that created it
         OR EXISTS (SELECT 1 FROM school_memberships m WHERE m.user_id = users.id AND m.school_id = app.current_school()));
CREATE POLICY users_insert ON users FOR INSERT WITH CHECK (school_id = app.current_school() OR app.is_platform());
CREATE POLICY users_update ON users FOR UPDATE
  USING (id = app.current_user_id() OR app.is_platform()
         OR EXISTS (SELECT 1 FROM school_memberships m WHERE m.user_id = users.id AND m.school_id = app.current_school()))
  WITH CHECK (true);
CREATE POLICY users_delete ON users FOR DELETE USING (app.is_platform());

-- per-user security tables: the user themself, the school they're signed into, or platform
DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['sessions','mfa_recovery_codes','user_tokens','known_devices','notifications'] LOOP
    EXECUTE format('DROP POLICY tenant_or_platform ON %I', t);
    EXECUTE format('CREATE POLICY own_tenant_or_platform ON %I USING (user_id = app.current_user_id() OR school_id = app.current_school() OR app.is_platform()) WITH CHECK (user_id = app.current_user_id() OR school_id = app.current_school() OR app.is_platform())', t);
  END LOOP;
END $$;

-- ── definer helpers for pre-tenant auth ──
DROP FUNCTION app.auth_find_user(text);
CREATE FUNCTION app.auth_find_user(p_login text)
RETURNS TABLE (id uuid, full_name text, password_hash text, status text, is_platform_admin boolean, failed_attempts integer,
               locked_until timestamptz, mfa_enabled boolean, must_change_password boolean, access_code_hash text,
               access_code_expires_at timestamptz, email text, login_id text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT u.id, u.full_name, u.password_hash, u.status, u.is_platform_admin, u.failed_attempts, u.locked_until, u.mfa_enabled,
         u.must_change_password, u.access_code_hash, u.access_code_expires_at, u.email, u.login_id
  FROM users u
  WHERE lower(u.login_id) = lower(p_login) OR (u.email IS NOT NULL AND lower(u.email) = lower(p_login))
  ORDER BY (lower(u.login_id) = lower(p_login)) DESC
  LIMIT 1
$$;

CREATE FUNCTION app.auth_user_memberships(p_user uuid)
RETURNS TABLE (membership_id uuid, school_id uuid, school_name text, school_status text, branch_id uuid, status text, is_default boolean, last_used_at timestamptz)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT m.id, m.school_id, s.name, s.status, m.branch_id, m.status, m.is_default, m.last_used_at
  FROM school_memberships m JOIN schools s ON s.id = m.school_id
  WHERE m.user_id = p_user
  ORDER BY m.is_default DESC, m.last_used_at DESC NULLS LAST, m.created_at
$$;

DROP FUNCTION app.auth_session(text);
CREATE FUNCTION app.auth_session(p_token_hash text)
RETURNS TABLE (session_id uuid, user_id uuid, school_id uuid, mfa_state text, support_school_id uuid,
               support_expires_at timestamptz, idle_expires_at timestamptz, expires_at timestamptz, rotated_at timestamptz,
               user_status text, is_platform_admin boolean, school_status text, membership_status text, branch_id uuid,
               login_id text, full_name text, must_change_password boolean, mfa_enabled boolean, email text, via_prev boolean)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT s.id, s.user_id, s.school_id, s.mfa_state, s.support_school_id, s.support_expires_at, s.idle_expires_at,
         s.expires_at, s.rotated_at, u.status, u.is_platform_admin, sc.status, m.status, m.branch_id, u.login_id, u.full_name,
         u.must_change_password, u.mfa_enabled, u.email, (s.token_hash <> p_token_hash)
  FROM sessions s JOIN users u ON u.id = s.user_id
  LEFT JOIN schools sc ON sc.id = s.school_id
  LEFT JOIN school_memberships m ON m.user_id = s.user_id AND m.school_id = s.school_id
  WHERE s.revoked_at IS NULL
    AND (s.token_hash = p_token_hash OR (s.prev_token_hash = p_token_hash AND s.prev_valid_until > now()))
  LIMIT 1
$$;

-- refresh-token REUSE detection: a rotated-out token presented after its grace window means the token was
-- copied (theft). The whole session is revoked and the caller records a high-severity security event.
CREATE FUNCTION app.auth_detect_reuse(p_token_hash text)
RETURNS TABLE (session_id uuid, user_id uuid, school_id uuid)
LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  UPDATE sessions SET revoked_at = now(), revoked_reason = 'token_reuse_detected'
  WHERE prev_token_hash = p_token_hash AND prev_valid_until <= now() AND revoked_at IS NULL
  RETURNING id, user_id, school_id
$$;

CREATE OR REPLACE FUNCTION app.login_id_taken(p_login text) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT EXISTS (SELECT 1 FROM users WHERE lower(login_id) = lower(p_login) OR (email IS NOT NULL AND lower(email) = lower(p_login)))
$$;
CREATE FUNCTION app.email_taken(p_email text) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT EXISTS (SELECT 1 FROM users WHERE email IS NOT NULL AND lower(email) = lower(p_email))
$$;
-- invite an EXISTING identity: returns only the id (no profile data leaks across schools)
CREATE FUNCTION app.find_user_id(p_login text) RETURNS uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT id FROM users WHERE (lower(login_id) = lower(p_login) OR (email IS NOT NULL AND lower(email) = lower(p_login))) AND NOT is_platform_admin LIMIT 1
$$;
DROP FUNCTION app.school_code_taken(text);
CREATE FUNCTION app.school_slug_taken(p_slug text) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$ SELECT EXISTS (SELECT 1 FROM schools WHERE lower(slug) = lower(p_slug)) $$;

-- platform stats now count memberships
CREATE OR REPLACE FUNCTION app.platform_school_stats()
RETURNS TABLE (school_id uuid, students bigint, staff bigint, users bigint, active_sessions bigint)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
BEGIN
  IF NOT app.is_platform() THEN RAISE EXCEPTION 'PLATFORM_ONLY' USING ERRCODE = '42501'; END IF;
  RETURN QUERY
    SELECT s.id,
      (SELECT count(*) FROM students st WHERE st.school_id = s.id AND st.deleted_at IS NULL AND st.status = 'active'),
      (SELECT count(*) FROM staff sf WHERE sf.school_id = s.id AND sf.employment_status <> 'exited'),
      (SELECT count(*) FROM school_memberships m WHERE m.school_id = s.id AND m.status = 'active'),
      (SELECT count(*) FROM sessions se WHERE se.school_id = s.id AND se.revoked_at IS NULL AND se.expires_at > now())
    FROM schools s;
END $$;

-- ── students / staff extra fields ──
ALTER TABLE students ADD COLUMN branch_id uuid;
ALTER TABLE students ADD FOREIGN KEY (school_id, branch_id) REFERENCES school_branches (school_id, id) ON DELETE SET NULL (branch_id);
ALTER TABLE students ADD COLUMN admission_date date;
ALTER TABLE students ADD COLUMN phone text;
ALTER TABLE students ADD COLUMN email text;
CREATE INDEX students_branch_idx ON students (school_id, branch_id) WHERE branch_id IS NOT NULL;
ALTER TABLE staff ADD COLUMN branch_id uuid;
ALTER TABLE staff ADD FOREIGN KEY (school_id, branch_id) REFERENCES school_branches (school_id, id) ON DELETE SET NULL (branch_id);
ALTER TABLE staff RENAME COLUMN staff_no TO employee_id;
ALTER INDEX staff_no_uq RENAME TO staff_employee_id_uq;
