-- 028_demo_passes.sql — demos only through the A.B.O. platform owner (owner's request, 12 Oct 2026).
-- The public "Try the demo" button is gone. The platform owner makes a DEMO LINK in the platform console and opens it
-- (own phone / laptop) or sends it to a school (WhatsApp). A demo can only start with a valid link:
--   • only a SHA-256 hash of the code is stored (the code is shown once, when the link is made);
--   • each link has an expiry time and a number of uses, and can be cancelled;
--   • using a link is atomic (two visitors cannot both take its last use); a failed start gives the use back.

CREATE TABLE demo_passes (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code_hash     text NOT NULL UNIQUE CHECK (code_hash ~ '^[0-9a-f]{64}$'),
  label         text CHECK (label IS NULL OR length(label) <= 120),            -- e.g. "Greenfield Academy — Mrs Ade"
  school_key    text CHECK (school_key IS NULL OR school_key ~ '^[a-z0-9-]{1,40}$'), -- one demo school, or NULL = visitor chooses
  max_uses      integer NOT NULL CHECK (max_uses BETWEEN 1 AND 50),
  uses          integer NOT NULL DEFAULT 0 CHECK (uses >= 0 AND uses <= max_uses),
  expires_at    timestamptz NOT NULL,
  revoked_at    timestamptz,
  created_by    uuid REFERENCES users(id),
  created_at    timestamptz NOT NULL DEFAULT now(),
  last_used_at  timestamptz,
  CHECK (expires_at > created_at)
);
CREATE INDEX demo_passes_recent_idx ON demo_passes (created_at DESC);
ALTER TABLE demo_passes ENABLE ROW LEVEL SECURITY;
CREATE POLICY platform_only ON demo_passes USING (app.is_platform()) WITH CHECK (app.is_platform());

-- is this link valid right now? (the demo page shows the choices only for a valid link; nothing is used up)
CREATE OR REPLACE FUNCTION app.demo_pass_check(p_hash text)
RETURNS TABLE (school_key text, uses_left integer, expires_at timestamptz)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT d.school_key, d.max_uses - d.uses, d.expires_at FROM demo_passes d
  WHERE d.code_hash = p_hash AND d.revoked_at IS NULL AND d.expires_at > now() AND d.uses < d.max_uses
$$;
-- take one use of a link for this demo school (NULL = not valid)
CREATE OR REPLACE FUNCTION app.demo_pass_use(p_hash text, p_school text)
RETURNS uuid LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = public, pg_temp AS $$
DECLARE v uuid;
BEGIN
  UPDATE demo_passes SET uses = uses + 1, last_used_at = now()
   WHERE code_hash = p_hash AND revoked_at IS NULL AND expires_at > now() AND uses < max_uses AND (school_key IS NULL OR school_key = p_school)
   RETURNING id INTO v;
  RETURN v;
END $$;
-- a demo that could not start gives its use back
CREATE OR REPLACE FUNCTION app.demo_pass_refund(p_id uuid)
RETURNS void LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  UPDATE demo_passes SET uses = greatest(uses - 1, 0) WHERE id = p_id
$$;
