-- 010_payment_lookup.sql — webhook tenant resolution. `payments` is strictly tenant-scoped (no platform
-- bypass), so the provider webhook resolves the owning school through this narrow definer function
-- which returns ONLY the school id of a pending online payment for a given reference.
CREATE OR REPLACE FUNCTION app.payment_school_by_reference(p_provider text, p_reference text)
RETURNS uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT school_id FROM payments WHERE provider = p_provider AND reference = p_reference LIMIT 1
$$;
REVOKE ALL ON FUNCTION app.payment_school_by_reference(text, text) FROM PUBLIC;
