-- 027_offline_parity.sql — the last features of the offline edition, now on the server (12 Oct 2026, owner's request:
-- "all offline features should be converted to online"). Same rules as everywhere else: every table is fenced to its
-- school by Row Level Security, money is never edited (only reversed), and every action is audited by the API.
--   1. Old debts: fees still owed from before → an invoice with a "brought forward" line (parents see it and can pay)
--   2. Petty cash requests: ask → another person approves → money handed out → change returned
--   3. Questions from teachers: optional approval of question-bank questions by the exam officer
--   4. Automatic reminders: alert rules + a log of fee reminders (never twice in one day for the same invoice)
--   5. Score sheet layout: which columns print on the class score sheet, its title and footer
--   6. Devices: the school's fingerprint readers, card scanners, tablets…

-- ── 1. old debts ──
DO $$ DECLARE cn text; BEGIN
  SELECT conname INTO cn FROM pg_constraint WHERE conrelid = 'invoice_items'::regclass AND contype = 'c' AND pg_get_constraintdef(oid) LIKE '%student_charge%';
  IF cn IS NOT NULL THEN EXECUTE format('ALTER TABLE invoice_items DROP CONSTRAINT %I', cn); END IF;
END $$;
ALTER TABLE invoice_items ADD CONSTRAINT invoice_items_kind_check CHECK (kind IN ('structure','student_charge','brought_forward'));
ALTER TABLE invoices ADD COLUMN kind text NOT NULL DEFAULT 'term' CHECK (kind IN ('term','brought_forward'));
ALTER TABLE invoices ADD COLUMN note text CHECK (note IS NULL OR length(note) <= 300);
-- one open "brought forward" invoice per learner (a second import cannot bill the same old debt twice)
CREATE UNIQUE INDEX invoices_one_bf_uq ON invoices (school_id, student_id) WHERE kind = 'brought_forward' AND status <> 'void';

-- ── 2. petty cash requests ──
CREATE TABLE petty_cash_requests (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id         uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  ref_no            text NOT NULL,
  requested_by      uuid NOT NULL REFERENCES users(id),
  purpose           text NOT NULL CHECK (length(purpose) BETWEEN 3 AND 300),
  amount_kobo       bigint NOT NULL CHECK (amount_kobo > 0 AND amount_kobo <= 100000000000),
  status            text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','given','settled','cancelled')),
  decided_by        uuid REFERENCES users(id),
  decided_at        timestamptz,
  decision_note     text CHECK (decision_note IS NULL OR length(decision_note) <= 300),
  given_by          uuid REFERENCES users(id),
  given_at          timestamptz,
  given_entry_id    uuid,                                   -- the cashbook entry "spent from petty cash"
  spent_kobo        bigint CHECK (spent_kobo IS NULL OR spent_kobo >= 0),
  returned_kobo     bigint CHECK (returned_kobo IS NULL OR returned_kobo >= 0),
  spent_entry_id    uuid,                                   -- on settling: the hand-out entry is voided and replaced by the amount really spent
  settled_by        uuid REFERENCES users(id),
  settled_at        timestamptz,
  settle_note       text CHECK (settle_note IS NULL OR length(settle_note) <= 300),
  created_at        timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id),
  UNIQUE (school_id, ref_no),
  CHECK (decided_by IS NULL OR decided_by <> requested_by),                       -- nobody approves their own request
  CHECK (spent_kobo IS NULL OR spent_kobo + coalesce(returned_kobo, 0) = amount_kobo),
  CHECK (status NOT IN ('given','settled') OR given_entry_id IS NOT NULL),
  CHECK (status <> 'settled' OR spent_kobo IS NOT NULL)
);
CREATE INDEX petty_cash_requests_status_idx ON petty_cash_requests (school_id, status, created_at DESC);

-- ── 3. questions from teachers (bank approval) ──
DO $$ DECLARE cn text; BEGIN
  SELECT conname INTO cn FROM pg_constraint WHERE conrelid = 'cbt_questions'::regclass AND contype = 'c' AND pg_get_constraintdef(oid) LIKE '%archived%';
  IF cn IS NOT NULL THEN EXECUTE format('ALTER TABLE cbt_questions DROP CONSTRAINT %I', cn); END IF;
END $$;
ALTER TABLE cbt_questions ADD CONSTRAINT cbt_questions_status_check CHECK (status IN ('active','archived','pending','rejected'));
ALTER TABLE cbt_questions ADD COLUMN reviewed_by uuid, ADD COLUMN reviewed_at timestamptz,
  ADD COLUMN review_note text CHECK (review_note IS NULL OR length(review_note) <= 300);
CREATE INDEX cbt_questions_pending_idx ON cbt_questions (school_id, created_at) WHERE status = 'pending';

-- ── 4. automatic reminders ──
ALTER TABLE school_settings ADD COLUMN alerts jsonb NOT NULL DEFAULT '{}'::jsonb;
CREATE TABLE fee_reminders (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id   uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  invoice_id  uuid NOT NULL,
  recipients  integer NOT NULL CHECK (recipients >= 0),
  sent_by     uuid REFERENCES users(id),
  sent_at     timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (school_id, invoice_id) REFERENCES invoices (school_id, id) ON DELETE CASCADE
);
CREATE INDEX fee_reminders_invoice_idx ON fee_reminders (school_id, invoice_id, sent_at DESC);

-- ── 5. score sheet layout ──
ALTER TABLE school_settings ADD COLUMN broadsheet_layout jsonb NOT NULL DEFAULT '{}'::jsonb;

-- ── 6. devices ──
CREATE TABLE school_devices (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id   uuid NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  name        text NOT NULL CHECK (length(name) BETWEEN 2 AND 80),
  kind        text NOT NULL CHECK (kind IN ('fingerprint','card','tablet','phone','computer','camera','other')),
  serial      text CHECK (serial IS NULL OR length(serial) <= 80),
  location    text CHECK (location IS NULL OR length(location) <= 120),
  status      text NOT NULL DEFAULT 'active' CHECK (status IN ('active','repair','retired')),
  notes       text CHECK (notes IS NULL OR length(notes) <= 300),
  created_by  uuid REFERENCES users(id),
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, id)
);
CREATE UNIQUE INDEX school_devices_serial_uq ON school_devices (school_id, lower(serial)) WHERE serial IS NOT NULL;
CREATE TRIGGER school_devices_touch BEFORE UPDATE ON school_devices FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();

DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['petty_cash_requests','fee_reminders','school_devices'] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY tenant_isolation ON %I USING (school_id = app.current_school()) WITH CHECK (school_id = app.current_school())', t);
  END LOOP;
END $$;

INSERT INTO permissions (key, module, description) VALUES
  ('pettycash.request', 'cashbook', 'Ask for petty cash for school spending'),
  ('pettycash.approve', 'cashbook', 'Approve or refuse petty cash requests (never your own)'),
  ('alerts.view', 'school', 'See automatic alerts: unpaid fees, low attendance, low stock'),
  ('alerts.manage', 'school', 'Set the alert rules and send fee reminders to parents'),
  ('devices.view', 'school', 'See the list of school devices'),
  ('devices.manage', 'school', 'Add, edit and retire school devices')
ON CONFLICT (key) DO NOTHING;

-- existing schools: the same grants the role templates give new schools (server/src/rbac/catalog.js)
INSERT INTO role_permissions (school_id, role_id, permission_key)
SELECT r.school_id, r.id, p.key
FROM roles r JOIN (
  SELECT k AS role_key, x AS key FROM unnest(ARRAY['school_owner','principal','administrator']) k,
    unnest(ARRAY['pettycash.request','pettycash.approve','alerts.view','alerts.manage','devices.view','devices.manage']) x
  UNION ALL SELECT 'bursar', x FROM unnest(ARRAY['pettycash.request','pettycash.approve','alerts.view','alerts.manage']) x
  UNION ALL SELECT 'accountant', x FROM unnest(ARRAY['pettycash.request','alerts.view']) x
  UNION ALL SELECT 'ict_officer', x FROM unnest(ARRAY['pettycash.request','devices.view','devices.manage']) x
  UNION ALL SELECT k, x FROM unnest(ARRAY['vice_principal','head_of_school']) k, unnest(ARRAY['pettycash.request','alerts.view','devices.view']) x
  UNION ALL SELECT k, 'pettycash.request' FROM unnest(ARRAY['teacher','form_teacher','exam_officer','librarian']) k
) p ON p.role_key = r.key
WHERE r.is_system
ON CONFLICT DO NOTHING;
