'use strict';
// PostgreSQL access. The runtime pool connects as abo_app (RLS enforced). Every request that touches
// tenant data runs inside withTx(), which sets transaction-local context used by RLS policies:
//   app.school_id  – the tenant resolved SERVER-SIDE from the authenticated session (never from the client)
//   app.user_id    – the acting user (used by triggers for score history)
//   app.platform   – 'on' only for verified platform administrators on platform endpoints
//   app.branch_id  – set for branch-restricted memberships (RESTRICTIVE RLS policies, migration 013)
const { Pool, types } = require('pg');
const fs = require('node:fs');
const config = require('../config');

types.setTypeParser(20, (v) => { const n = Number(v); return Number.isSafeInteger(n) ? n : v; }); // int8 → number when safe
types.setTypeParser(1700, (v) => Number(v));                                                       // numeric → number
types.setTypeParser(1082, (v) => v);                                                               // date → 'YYYY-MM-DD'

const { sslFor } = require('./ssl');
function sslOpts() { return sslFor(config.db.url, config.db.ssl); }

const pool = new Pool({
  connectionString: config.db.url,
  max: config.db.poolMax,
  ssl: sslOpts(),
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
  statement_timeout: config.db.statementTimeoutMs,
  application_name: 'abo-api',
});
pool.on('error', (e) => { process.stderr.write(`[db] idle client error: ${e.message}\n`); });

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

async function withTx(ctx, fn) {
  const client = await pool.connect();
  try {
    await client.query(ctx && ctx.readOnly ? 'BEGIN READ ONLY' : 'BEGIN');
    const school = ctx && ctx.schoolId ? String(ctx.schoolId) : '';
    const user = ctx && ctx.userId ? String(ctx.userId) : '';
    const branch = ctx && ctx.branchId ? String(ctx.branchId) : '';
    if (school && !UUID_RE.test(school)) throw new Error('invalid tenant context');
    if (user && !UUID_RE.test(user)) throw new Error('invalid user context');
    if (branch && !UUID_RE.test(branch)) throw new Error('invalid branch context');
    await client.query(
      "SELECT set_config('app.school_id', $1, true), set_config('app.user_id', $2, true), set_config('app.platform', $3, true), set_config('app.branch_id', $4, true)",
      [school, user, ctx && ctx.platform ? 'on' : '', branch]
    );
    const out = await fn(client);
    await client.query('COMMIT');
    return out;
  } catch (e) {
    try { await client.query('ROLLBACK'); } catch (_) { /* connection may be broken */ }
    throw e;
  } finally {
    client.release();
  }
}

// Context-free queries (only for definer functions / health checks)
const raw = (sql, params) => pool.query(sql, params);

module.exports = { pool, withTx, raw, UUID_RE };
