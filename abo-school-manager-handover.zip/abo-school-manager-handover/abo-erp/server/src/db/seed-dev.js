'use strict';
// DEVELOPMENT/TEST ONLY demo data. Refuses to run in staging/production.
const crypto = require('node:crypto');
const config = require('../config');
const { withTx, pool } = require('./pool');
const pw = require('../security/passwords');
const { createSchool } = require('../services/provision');
const R = require('../services/results');

if (config.isProdLike) { console.error('seed-dev refuses to run in staging/production'); process.exit(1); }

const DEMO_PASSWORD = process.env.DEMO_PASSWORD || 'Demo#School2026';
const SUBJECTS = ['English Language', 'Mathematics', 'Basic Science', 'Social Studies', 'Civic Education', 'Computer Studies', 'Yoruba', 'Agricultural Science'];
const FIRST = ['Ada', 'Tunde', 'Chioma', 'Emeka', 'Fatima', 'Ibrahim', 'Kemi', 'Segun', 'Ngozi', 'Bola', 'Zainab', 'David', 'Amaka', 'Yusuf', 'Funmi', 'Obinna', 'Halima', 'Tobi', 'Grace', 'Musa'];
const LAST = ['Okafor', 'Bello', 'Adeyemi', 'Eze', 'Abubakar', 'Ogunleye', 'Nwosu', 'Ibrahim', 'Balogun', 'Okeke', 'Afolabi', 'Danjuma'];

async function makeUser(c, schoolId, { login, name, email, roles, roleIds, branchId }) {
  const u = (await c.query(`INSERT INTO users (school_id, login_id, full_name, email, password_hash, password_changed_at, email_verified_at) VALUES ($1,$2,$3,$4,$5, now(), now()) RETURNING id`,
    [schoolId, login, name, email || null, await pw.hash(DEMO_PASSWORD)])).rows[0];
  await c.query("INSERT INTO school_memberships (user_id, school_id, branch_id, status, is_default) VALUES ($1,$2,$3,'active',true)", [u.id, schoolId, branchId || null]);
  for (const r of roles) await c.query('INSERT INTO user_roles (school_id, user_id, role_id) VALUES ($1,$2,$3)', [schoolId, u.id, roleIds[r]]);
  return u.id;
}

async function seedSchool({ code, name, type, prefix, studentsPerClass = 12, results = false }) {
  const schoolId = crypto.randomUUID();
  return withTx({ schoolId }, async (c) => {
    const roleIds = await createSchool(c, { id: schoolId, slug: code, name, schoolType: type, address: '12 Olaniyan Street, Ibadan, Oyo State', phone: '0800 000 0000', email: `info@${code}.example`, motto: 'Knowledge, Discipline, Excellence', status: 'active' });
    await c.query('UPDATE schools SET email_verified_at = now() WHERE id = $1', [schoolId]);
    const ids = {};
    ids.owner = await makeUser(c, schoolId, { login: `${prefix}.owner`, name: 'Mrs Funke Adewale', email: `owner@${code}.example`, roles: ['school_owner'], roleIds });
    ids.admin = await makeUser(c, schoolId, { login: `${prefix}.admin`, name: 'Mr Kunle Adebayo', email: `admin@${code}.example`, roles: ['administrator'], roleIds });
    ids.exam = await makeUser(c, schoolId, { login: `${prefix}.exams`, name: 'Mrs Grace Eze', roles: ['exam_officer'], roleIds });
    ids.bursar = await makeUser(c, schoolId, { login: `${prefix}.bursar`, name: 'Mr Musa Danjuma', roles: ['bursar'], roleIds });
    ids.accountant = await makeUser(c, schoolId, { login: `${prefix}.accounts`, name: 'Miss Halima Sani', roles: ['accountant'], roleIds });
    const t1 = await makeUser(c, schoolId, { login: `${prefix}.teacher1`, name: 'Mr Tunde Bello', roles: ['teacher', 'form_teacher'], roleIds });
    const t2 = await makeUser(c, schoolId, { login: `${prefix}.teacher2`, name: 'Mrs Ngozi Okeke', roles: ['teacher'], roleIds });
    ids.teacher1 = t1; ids.teacher2 = t2;
    const staff1 = (await c.query("INSERT INTO staff (school_id, user_id, full_name, employee_id, gender, designation) VALUES ($1,$2,'Mr Tunde Bello','ST001','Male','Class Teacher') RETURNING id", [schoolId, t1])).rows[0].id;
    const staff2 = (await c.query("INSERT INTO staff (school_id, user_id, full_name, employee_id, gender, designation) VALUES ($1,$2,'Mrs Ngozi Okeke','ST002','Female','Subject Teacher') RETURNING id", [schoolId, t2])).rows[0].id;
    await c.query("INSERT INTO staff (school_id, user_id, full_name, employee_id, gender, designation, is_teacher) VALUES ($1,$2,'Mrs Grace Eze','ST003','Female','Exam Officer', true)", [schoolId, ids.exam]);
    const sess = (await c.query("INSERT INTO academic_sessions (school_id, name, starts_on, ends_on, is_current) VALUES ($1,'2025/2026','2025-09-08','2026-07-24',true) RETURNING id", [schoolId])).rows[0].id;
    let termId; const termIds = {};
    for (const t of ['1ST', '2ND', '3RD']) {
      const r = (await c.query('INSERT INTO terms (school_id, session_id, name, is_current, days_open, next_term_begins) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id', [schoolId, sess, t, t === '1ST', 62, t === '1ST' ? '2026-01-05' : null])).rows[0];
      if (t === '1ST') termId = r.id;
      termIds[t] = r.id;
    }
    const subj = {};
    for (const s of SUBJECTS) subj[s] = (await c.query('INSERT INTO subjects (school_id, name) VALUES ($1,$2) RETURNING id', [schoolId, s])).rows[0].id;
    const main = (await c.query("INSERT INTO school_branches (school_id, name, code, address) VALUES ($1,'Main Campus','MAIN','12 Olaniyan Street') RETURNING id", [schoolId])).rows[0].id;
    const annex = (await c.query("INSERT INTO school_branches (school_id, name, code, address) VALUES ($1,'Annex','ANNEX','3 Ring Road') RETURNING id", [schoolId])).rows[0].id;
    ids.branches = { main, annex };
    const classes = [];
    const defs = type === 'secondary' ? [['JSS 1', 'A', 'secondary'], ['JSS 1', 'B', 'secondary'], ['SSS 1', 'A', 'secondary']] : [['BASIC 1', 'A', 'primary'], ['BASIC 1', 'B', 'primary'], ['JSS 1', 'A', 'secondary']];
    for (const [i, [n, arm, section]] of defs.entries()) {
      const st = (await c.query('INSERT INTO streams (school_id, name) VALUES ($1,$2) ON CONFLICT (school_id, name) DO UPDATE SET name = EXCLUDED.name RETURNING id', [schoolId, arm])).rows[0].id;
      const cl = (await c.query('INSERT INTO classes (school_id, name, arm, stream_id, section, form_teacher_id, sort_order, branch_id) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id, display_name, branch_id',
        [schoolId, n, arm, st, section, i === 0 ? staff1 : null, i, i === 2 ? annex : main])).rows[0];
      classes.push(cl);
      for (const [j, s] of SUBJECTS.entries()) await c.query('INSERT INTO class_subjects (school_id, class_id, subject_id, teacher_id) VALUES ($1,$2,$3,$4)', [schoolId, cl.id, subj[s], j % 2 === 0 ? staff1 : staff2]);
    }
    let n = 0; const students = [];
    for (const cl of classes) {
      for (let i = 0; i < studentsPerClass; i++) {
        n++;
        const s = (await c.query(`INSERT INTO students (school_id, admission_no, first_name, last_name, gender, date_of_birth, branch_id, admission_date) VALUES ($1,$2,$3,$4,$5,$6,$7,'2025-09-08') RETURNING id, first_name, last_name`,
          [schoolId, `${prefix.toUpperCase()}/${String(n).padStart(4, '0')}`, FIRST[n % FIRST.length], LAST[(n * 7) % LAST.length], n % 2 ? 'Female' : 'Male', `2015-0${(n % 9) + 1}-1${n % 9}`, cl.branch_id])).rows[0];
        await c.query('INSERT INTO student_enrollments (school_id, student_id, class_id, session_id, roll_no) VALUES ($1,$2,$3,$4,$5)', [schoolId, s.id, cl.id, sess, i + 1]);
        students.push({ ...s, classId: cl.id });
      }
    }
    // one student + parent with portal accounts
    const st0 = students[0];
    ids.student = await makeUser(c, schoolId, { login: `${prefix}.student`, name: `${st0.first_name} ${st0.last_name}`, roles: ['student'], roleIds });
    await c.query('UPDATE students SET user_id = $2 WHERE id = $1', [st0.id, ids.student]);
    ids.parent = await makeUser(c, schoolId, { login: `${prefix}.parent`, name: `Mrs ${st0.last_name}`, email: `parent@${code}.example`, roles: ['parent'], roleIds });
    const g = (await c.query("INSERT INTO guardians (school_id, user_id, full_name, relationship, phone, email) VALUES ($1,$2,$3,'Mother','08030000001',$4) RETURNING id", [schoolId, ids.parent, `Mrs ${st0.last_name}`, `parent@${code}.example`])).rows[0];
    await c.query('INSERT INTO student_guardians (school_id, student_id, guardian_id, is_primary) VALUES ($1,$2,$3,true)', [schoolId, st0.id, g.id]);
    await c.query('INSERT INTO student_guardians (school_id, student_id, guardian_id) VALUES ($1,$2,$3)', [schoolId, students[1].id, g.id]);
    // fees
    const cat = async (code) => (await c.query('SELECT id FROM fee_categories WHERE code = $1', [code])).rows[0].id;
    await c.query("INSERT INTO fee_structures (school_id, name, category_id, amount_kobo, term_id) VALUES ($1,'Tuition — 1st Term',$3,8500000,$2), ($1,'Development Levy',$4,1500000,NULL), ($1,'ICT / Computer',$5,500000,$2)",
      [schoolId, termId, await cat('tuition'), await cat('development'), await cat('ict')]);
    // branch-restricted administrator for the Annex (administrator role → MFA enrolment required)
    ids.annex = await makeUser(c, schoolId, { login: `${prefix}.annex`, name: 'Mr Annex Coordinator', roles: ['administrator'], roleIds, branchId: annex });
    await c.query("UPDATE staff SET branch_id = $2 WHERE school_id = $1 AND branch_id IS NULL", [schoolId, main]);
    if (results) {
      // demo results: every subject of the first class fully scored, reviewed, approved and PUBLISHED
      const cls0 = classes[0]; const st = await R.settings(c);
      const roster = await R.roster(c, termId, cls0.id);
      const subs = (await c.query('SELECT subject_id FROM class_subjects WHERE class_id = $1', [cls0.id])).rows;
      // demo: 1st term AND 2nd term are scored and published, so Cumulative Results and the 2nd-term report card
      // ("results so far this session") have something to add up. 1st term stays the current term.
      for (const [ti, tid] of [termId, termIds['2ND']].entries()) for (const [si, sb] of subs.entries()) {
        const sh = (await c.query(`INSERT INTO assessments (school_id, term_id, class_id, subject_id, components, created_by) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`,
          [schoolId, tid, cls0.id, sb.subject_id, JSON.stringify(st.assessment_components), ids.teacher1])).rows[0].id;
        for (const [ri, r] of roster.entries()) {
          // varied but repeatable demo scores (the old formula repeated every 3 learners → everyone tied)
          const hv = (ri * 31 + si * 17 + ti * 11 + ri * si * 3 + ri * ri * 5) % 97;
          for (const [k, v] of [['ca1', 8 + (hv % 13)], ['ca2', 7 + ((hv * 7) % 14)], ['exam', 22 + ((hv * 11 + ri * 3) % 39)]]) {
            await c.query('INSERT INTO assessment_scores (school_id, sheet_id, student_id, component_key, score, entered_by) VALUES ($1,$2,$3,$4,$5,$6)', [schoolId, sh, r.id, k, v, ids.teacher1]);
          }
        }
        await R.recomputeSheet(c, sh);
        await c.query(`UPDATE assessments SET status = 'published', submitted_by = $2, submitted_at = now(), reviewed_by = $3, reviewed_at = now(), approved_by = $3, approved_at = now(), published_by = $3, published_at = now() WHERE id = $1`, [sh, ids.teacher1, ids.exam]);
      }
      await R.computeClassTerm(c, termIds['2ND'], cls0.id, { publish: true });
      await R.computeClassTerm(c, termId, cls0.id, { publish: true });
      await c.query('INSERT INTO broadsheets (school_id, term_id, class_id, version, snapshot, published_by) VALUES ($1,$2,$3,1,$4,$5)', [schoolId, termId, cls0.id, await R.broadsheet(c, termId, cls0.id), ids.exam]);
      await c.query('INSERT INTO report_cards (school_id, term_id, student_id, teacher_comment) SELECT $1, $2, s.id, $3 FROM unnest($4::uuid[]) AS s(id)', [schoolId, termId, 'A good term. Keep working hard.', roster.map((r) => r.id)]);
      await c.query('INSERT INTO report_cards (school_id, term_id, student_id, teacher_comment) SELECT $1, $2, s.id, $3 FROM unnest($4::uuid[]) AS s(id)', [schoolId, termIds['2ND'], 'Steady progress this term. Keep it up.', roster.map((r) => r.id)]);
    }
    await c.query("INSERT INTO announcements (school_id, title, body, audience, priority, pinned, created_by) VALUES ($1,'Welcome to the new term','Resumption is Monday 8:00am. Pupils should come in full uniform with their books.','all','important',true,$2)", [schoolId, ids.owner]);
    // demo lesson notes (one per workflow state) for the first class
    const note = (staffId, author, subject, week, topic, status, extra = {}) => c.query(`INSERT INTO lesson_notes (school_id, term_id, class_id, subject_id, staff_id, author_id, week, duration,
        topic, subtopic, objectives, materials, content, evaluation, assignment, status, submitted_at, reviewed_by, reviewed_at, review_note)
      VALUES ($1,$2,$3,$4,$5,$6,$7,'40 minutes',$8,$9,$10,$11,$12,$13,$14,$15::text, CASE WHEN $15::text <> 'draft' THEN now() END, $16::uuid, CASE WHEN $16::uuid IS NOT NULL THEN now() END, $17) RETURNING id`,
    [schoolId, termId, classes[0].id, subj[subject], staffId, author, week, topic, extra.subtopic || null, extra.objectives || null, extra.materials || null, extra.content,
      extra.evaluation || null, extra.assignment || null, status, ['approved', 'returned'].includes(status) ? ids.admin : null, extra.reviewNote || null]);
    await note(staff1, t1, 'English Language', 1, 'Parts of Speech: Nouns', 'approved', { subtopic: 'Common and proper nouns',
      objectives: 'By the end of the lesson pupils should be able to:\n1. Define a noun.\n2. Identify common and proper nouns in sentences.\n3. Give five examples of each.',
      materials: 'Flash cards, charts of objects, the class textbook (page 12).',
      content: 'Introduction: the teacher points at objects in the classroom and asks pupils to name them.\n\nStep 1: A noun is the name of a person, animal, place or thing.\nStep 2: Common nouns name general things (girl, city, book). Proper nouns name particular people or places and begin with a capital letter (Aisha, Lagos, Bariga).\nStep 3: Pupils sort flash cards into two groups.',
      evaluation: '1. What is a noun?\n2. Underline the proper nouns: "Tunde lives in Ibadan with his dog Bingo."', assignment: 'Write ten nouns you can find in your home and mark the proper nouns.' });
    await note(staff1, t1, 'Basic Science', 1, 'Living and Non-living Things', 'submitted', { objectives: 'Pupils should be able to list the characteristics of living things.',
      content: 'Living things feed, breathe, grow, move, reproduce, respond to stimuli and excrete. Non-living things do not.\nActivity: pupils classify pictures into living and non-living.', evaluation: 'Mention four characteristics of living things.' });
    await note(staff2, t2, 'Mathematics', 1, 'Addition of Whole Numbers', 'draft', { content: 'Addition of 2-digit numbers without and with regrouping, using bundles of sticks.' });
    await note(staff2, t2, 'Social Studies', 1, 'The Family', 'returned', { content: 'Types of family: nuclear and extended.', reviewNote: 'Please add the lesson objectives and an evaluation exercise.' });
    return { schoolId, termId, classes, ids };
  });
}

async function seedPlatformAdmin() {
  return withTx({ platform: true }, async (c) => {
    const r = await c.query(`INSERT INTO users (school_id, login_id, full_name, email, password_hash, is_platform_admin, password_changed_at) VALUES (NULL,'abo.platform','A.B.O. Platform Admin','platform-admin@example.com',$1,true, now())
      ON CONFLICT DO NOTHING RETURNING id`, [await pw.hash(DEMO_PASSWORD)]);
    return r.rows[0] && r.rows[0].id;
  });
}

async function main() {
  await seedPlatformAdmin();
  const a = await seedSchool({ code: 'bopc-demo', name: 'Bola Olat Private College (Demo)', type: 'mixed', prefix: 'bopc', results: true });
  const b = await seedSchool({ code: 'greenfield-demo', name: 'Greenfield Academy (Demo)', type: 'secondary', prefix: 'gfa', studentsPerClass: 6 });
  // a proprietor who runs BOTH demo schools (multi-school membership)
  await withTx({ schoolId: a.schoolId }, async (c) => {
    const u = (await c.query(`INSERT INTO users (school_id, login_id, full_name, email, password_hash, password_changed_at) VALUES ($1,'demo.proprietor','Chief Demo Proprietor','proprietor@demo.example',$2, now()) RETURNING id`, [a.schoolId, await pw.hash(DEMO_PASSWORD)])).rows[0];
    await c.query("INSERT INTO school_memberships (user_id, school_id, status, is_default) VALUES ($1,$2,'active',true)", [u.id, a.schoolId]);
    await c.query("INSERT INTO user_roles (school_id, user_id, role_id) SELECT $1, $2, id FROM roles WHERE key = 'head_of_school'", [a.schoolId, u.id]);
    a.proprietor = u.id;
  });
  await withTx({ schoolId: b.schoolId }, async (c) => {
    await c.query("INSERT INTO school_memberships (user_id, school_id, status) VALUES ($1,$2,'active')", [a.proprietor, b.schoolId]);
    await c.query("INSERT INTO user_roles (school_id, user_id, role_id) SELECT $1, $2, id FROM roles WHERE key = 'head_of_school'", [b.schoolId, a.proprietor]);
  });
  console.log(`Seeded demo data. Password for every demo account: ${DEMO_PASSWORD}
  platform: abo.platform
  multi-school: demo.proprietor (both schools) · branch-restricted: bopc.annex, gfa.annex
  school A (${a.schoolId}): bopc.owner bopc.admin bopc.exams bopc.bursar bopc.accounts bopc.teacher1 bopc.teacher2 bopc.student bopc.parent
  school B (${b.schoolId}): gfa.owner gfa.admin gfa.teacher1 gfa.student gfa.parent …`);
}
if (require.main === module) main().then(() => pool.end()).catch((e) => { console.error(e); process.exit(1); });
module.exports = { seedSchool, seedPlatformAdmin, DEMO_PASSWORD };
