'use strict';
// One place that decides how the server encrypts its database connections (pool, migrations, bootstrap, preflight).
//  DB_SSL=off            → no TLS (local development only)
//  DB_SSL=require        → TLS with full certificate verification (default outside development)
//  CA certificate        → DB_SSL_CA_PEM (the PEM text itself — handy on Render), or DB_SSL_CA (a file path);
//                          for Supabase hosts the bundled "Supabase Root 2021 CA" is used automatically.
const fs = require('node:fs');
const path = require('node:path');
const SUPABASE_CA = path.join(__dirname, '../../../deploy/certs/supabase-prod-ca-2021.crt');

function hostOf(url) { try { return new URL(url).hostname; } catch (e) { return ''; } }
function sslFor(url, mode = process.env.DB_SSL) {
  const m = mode || (process.env.NODE_ENV === 'production' ? 'require' : 'off');
  if (m === 'off') return false;
  let ca;
  if (process.env.DB_SSL_CA_PEM) ca = process.env.DB_SSL_CA_PEM.replace(/\\n/g, '\n');
  else if (process.env.DB_SSL_CA) ca = fs.readFileSync(process.env.DB_SSL_CA, 'utf8');
  else if (/\.supabase\.(co|com)$/i.test(hostOf(url)) && fs.existsSync(SUPABASE_CA)) ca = fs.readFileSync(SUPABASE_CA, 'utf8');
  return { rejectUnauthorized: true, ca };
}
module.exports = { sslFor, SUPABASE_CA };
