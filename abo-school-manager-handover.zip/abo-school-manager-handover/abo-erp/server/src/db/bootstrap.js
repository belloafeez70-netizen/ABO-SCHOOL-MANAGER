'use strict';
// One-time database bootstrap, run by a DBA/superuser (DATABASE_ADMIN_URL).
// Creates: owner role (runs migrations, owns tables), runtime role abo_app (NOBYPASSRLS), database, extensions.
// Works on managed Postgres too (Supabase, RDS, Neon): a non-superuser admin with CREATEROLE + CREATEDB is enough.
const { Client } = require('pg');
const { escapeLiteral, escapeIdentifier } = require('pg');

async function main() {
  const adminUrl = process.env.DATABASE_ADMIN_URL;
  const dbName = process.env.DB_NAME || 'abo_erp';
  const ownerPw = process.env.DB_OWNER_PASSWORD;
  const appPw = process.env.DB_APP_PASSWORD;
  if (!adminUrl || !ownerPw || !appPw) throw new Error('DATABASE_ADMIN_URL, DB_OWNER_PASSWORD and DB_APP_PASSWORD are required');
  if (ownerPw.length < 16 || appPw.length < 16) throw new Error('DB passwords must be at least 16 characters');
  const { sslFor } = require('./ssl');
  const c = new Client({ connectionString: adminUrl, ssl: sslFor(adminUrl) });
  await c.connect();
  const role = async (name, attrs, pw) => {
    const r = await c.query('SELECT 1 FROM pg_roles WHERE rolname=$1', [name]);
    // re-runs only update the password and safe attributes: a non-superuser admin may not touch SUPERUSER at all
    const a = r.rowCount ? attrs.replace(/\bNOSUPERUSER\b\s*/, '') : attrs;
    await c.query(`${r.rowCount ? 'ALTER' : 'CREATE'} ROLE ${escapeIdentifier(name)} ${a} PASSWORD ${escapeLiteral(pw)}`);
  };
  await role('abo_owner', 'LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE', ownerPw);
  await role('abo_app', 'LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOBYPASSRLS NOINHERIT', appPw);
  // Managed Postgres (Supabase, RDS…): the admin is NOT a superuser. It may create roles but must be granted
  // membership before it can create a database owned by abo_owner (PostgreSQL 16+: "must be able to SET ROLE").
  const su = (await c.query('SELECT rolsuper FROM pg_roles WHERE rolname = current_user')).rows[0].rolsuper;
  if (!su) {
    try { await c.query('GRANT abo_owner TO CURRENT_USER WITH SET TRUE, INHERIT TRUE'); }   // PostgreSQL 16+
    catch (e) { await c.query('GRANT abo_owner TO CURRENT_USER'); }                           // PostgreSQL 15
  }
  const db = await c.query('SELECT 1 FROM pg_database WHERE datname=$1', [dbName]);
  if (!db.rowCount) await c.query(`CREATE DATABASE ${escapeIdentifier(dbName)} OWNER abo_owner ENCODING 'UTF8'`);
  await c.query(`REVOKE ALL ON DATABASE ${escapeIdentifier(dbName)} FROM PUBLIC`);
  await c.query(`GRANT CONNECT ON DATABASE ${escapeIdentifier(dbName)} TO abo_app`);
  await c.end();
  const u = new URL(adminUrl); u.pathname = '/' + dbName;
  const d = new Client({ connectionString: u.toString(), ssl: sslFor(u.toString()) });
  await d.connect();
  await d.query('CREATE EXTENSION IF NOT EXISTS pg_trgm');
  await d.query('ALTER SCHEMA public OWNER TO abo_owner');
  await d.query('REVOKE CREATE ON SCHEMA public FROM PUBLIC');
  await d.end();
  console.log(`bootstrap ok: database ${dbName}, roles abo_owner / abo_app`);
}
main().catch((e) => { console.error('bootstrap failed:', e.message); process.exit(1); });
