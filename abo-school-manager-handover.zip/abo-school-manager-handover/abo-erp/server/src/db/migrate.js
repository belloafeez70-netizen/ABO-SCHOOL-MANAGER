'use strict';
// Migration runner: applies numbered SQL files once each (checksummed — edited migrations are refused),
// re-applies grants, and syncs the permission catalogue. Runs as the schema OWNER role, never as abo_app.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { Client } = require('pg');
const config = require('../config');
const { PERMISSIONS } = require('../rbac/catalog');

const DIR = path.join(__dirname, 'migrations');

async function migrate({ url = config.db.migrationUrl, log = console.log } = {}) {
  const c = new Client({ connectionString: url, ssl: require('./ssl').sslFor(url, config.db.ssl) });
  await c.connect();
  try {
    await c.query('SELECT pg_advisory_lock(727274)');           // one migrator at a time
    await c.query(`CREATE TABLE IF NOT EXISTS schema_migrations (
      version text PRIMARY KEY, name text NOT NULL, checksum text NOT NULL, applied_at timestamptz NOT NULL DEFAULT now())`);
    const done = new Map((await c.query('SELECT version, checksum FROM schema_migrations')).rows.map((r) => [r.version, r.checksum]));
    const files = fs.readdirSync(DIR).filter((f) => /^\d{3}_.+\.sql$/.test(f)).sort();
    let applied = 0;
    for (const f of files) {
      const version = f.slice(0, 3);
      const sql = fs.readFileSync(path.join(DIR, f), 'utf8');
      const sum = crypto.createHash('sha256').update(sql).digest('hex');
      if (done.has(version)) {
        if (done.get(version) !== sum) throw new Error(`migration ${f} was modified after being applied (checksum mismatch)`);
        continue;
      }
      await c.query('BEGIN');
      try {
        await c.query(sql);
        await c.query('INSERT INTO schema_migrations (version, name, checksum) VALUES ($1,$2,$3)', [version, f, sum]);
        await c.query('COMMIT');
        applied++;
        log(`  applied ${f}`);
      } catch (e) {
        await c.query('ROLLBACK');
        throw new Error(`migration ${f} failed: ${e.message}`);
      }
    }
    // permission catalogue
    await c.query('BEGIN');
    for (const [key, [module, description, scope]] of Object.entries(PERMISSIONS)) {
      await c.query(`INSERT INTO permissions (key, module, description, scope) VALUES ($1,$2,$3,$4)
        ON CONFLICT (key) DO UPDATE SET module = EXCLUDED.module, description = EXCLUDED.description, scope = EXCLUDED.scope`,
      [key, module, description, scope || 'school']);
    }
    // retire keys that are no longer in the catalogue (role grants cascade)
    await c.query('DELETE FROM permissions WHERE NOT (key = ANY($1::text[]))', [Object.keys(PERMISSIONS)]);
    await c.query('COMMIT');
    await c.query(fs.readFileSync(path.join(__dirname, 'grants.sql'), 'utf8'));
    log(`migrations ok (${applied} applied, ${files.length} total); grants + ${Object.keys(PERMISSIONS).length} permissions synced`);
  } finally {
    await c.query('SELECT pg_advisory_unlock(727274)').catch(() => {});
    await c.end();
  }
}

// Rollback of the LATEST migration where a down script exists (migrations/down/NNN_*.down.sql).
// Migrations that transform data (e.g. 011/012) are rolled back by PITR restore / forward fix — see docs/DEPLOYMENT.md.
async function down({ url = config.db.migrationUrl, version, log = console.log } = {}) {
  const c = new Client({ connectionString: url, ssl: require('./ssl').sslFor(url, config.db.ssl) });
  await c.connect();
  try {
    await c.query('SELECT pg_advisory_lock(727274)');
    const last = (await c.query('SELECT version, name FROM schema_migrations ORDER BY version DESC LIMIT 1')).rows[0];
    if (!last) throw new Error('nothing to roll back');
    if (version && version !== last.version) throw new Error(`only the latest migration (${last.version}) can be rolled back`);
    const file = path.join(DIR, 'down', last.name.replace(/\.sql$/, '.down.sql'));
    if (!fs.existsSync(file)) throw new Error(`${last.name} has no down script — restore from PITR or write a forward fix`);
    await c.query('BEGIN');
    await c.query(fs.readFileSync(file, 'utf8'));
    await c.query('DELETE FROM schema_migrations WHERE version = $1', [last.version]);
    await c.query('COMMIT');
    log(`rolled back ${last.name}`);
  } catch (e) { await c.query('ROLLBACK').catch(() => {}); throw e; } finally {
    await c.query('SELECT pg_advisory_unlock(727274)').catch(() => {});
    await c.end();
  }
}
if (require.main === module) {
  const i = process.argv.indexOf('--down');
  (i > -1 ? down({ version: process.argv[i + 1] }) : migrate()).catch((e) => { console.error(e.message); process.exit(1); });
}
module.exports = { migrate, down };
