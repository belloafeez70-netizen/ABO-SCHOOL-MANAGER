'use strict';
const path = require('node:path');
const crypto = require('node:crypto');
const Fastify = require('fastify');
const config = require('./config');
const { AppError, fromPg } = require('./lib/errors');
const metrics = require('./lib/metrics');
const BUSY = () => new AppError(503, 'BUSY', 'The school system is very busy right now. Please try again in a few seconds.');
const { pool } = require('./db/pool');

function buildApp(opts = {}) {
  const app = Fastify({
    logger: opts.logger !== undefined ? opts.logger : {
      level: config.logLevel,
      redact: { paths: ['req.headers.cookie', 'req.headers.authorization', 'req.headers["x-csrf-token"]', 'res.headers["set-cookie"]', '*.password', '*.newPassword', '*.currentPassword', '*.token', '*.code'], censor: '[redacted]' },
    },
    trustProxy: config.trustProxy === 'true' ? true : config.trustProxy.split(',').map((s) => s.trim()),
    bodyLimit: 1024 * 1024,                // 1 MB JSON; uploads use multipart limits below
    genReqId: () => crypto.randomUUID(),
    requestIdHeader: false,                // never trust a client-supplied request id
    ajv: { customOptions: { removeAdditional: false, useDefaults: true, coerceTypes: true, allErrors: false } },
    routerOptions: { maxParamLength: 120 },
    // Router-level failures (malformed %-encoding, over-long path params) happen before routing, so they never reach
    // setErrorHandler. Answer them with the standard envelope and WITHOUT echoing the attacker-supplied URL.
    frameworkErrors: (err, req, reply) => {
      const map = { FST_ERR_BAD_URL: [400, 'BAD_REQUEST', 'The request URL is malformed.'],
        FST_ERR_MAX_PARAM_LENGTH: [414, 'URI_TOO_LONG', 'The request URL is too long.'] };
      const [status, code, message] = map[err.code] || [400, 'BAD_REQUEST', 'The request is malformed or uses an unsupported format.'];
      reply.code(status).header('cache-control', 'no-store').header('x-content-type-options', 'nosniff')
        .send({ error: { code, message, requestId: req.id } });
    },
  });

  // registry of every route (used by the BOLA sweep test and the generated API reference)
  const routeList = [];
  app.decorate('routeList', routeList);
  app.addHook('onRoute', (r) => {
    const hooks = [].concat(r.onRequest || []);
    routeList.push({ method: r.method, url: r.url, schema: r.schema, auth: hooks.some((f) => f && f.name === 'authenticate'), platform: hooks.some((f) => f && f.platform), perms: hooks.flatMap((f) => (f && f.perms) || []),
      rateLimit: r.config && r.config.rateLimit ? `${r.config.rateLimit.max}/${r.config.rateLimit.timeWindow}` : null });
  });

  // ── load shedding (Phase 7): when too many requests are already waiting for a database connection, answer at once
  //    with "busy, try again" instead of letting everyone wait up to 5 s and then fail ──
  const dbPool = require('./db/pool').pool;
  app.addHook('onRequest', async (req, reply) => {
    if (!req.url.startsWith('/api/') || dbPool.waitingCount < config.db.queueMax) return;
    metrics.inc('http_shed_total', { route: 'all' });
    reply.header('Retry-After', '3');
    throw BUSY();
  });

  // ── trusted edge proxy (Netlify): verify the shared secret FIRST, then take the real client IP from it ──
  app.addHook('onRequest', require('./lib/proxy').proxyHook);

  // ── security headers (Helmet) ──
  app.register(require('@fastify/helmet'), {
    contentSecurityPolicy: {
      useDefaults: false,
      directives: {
        defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'"], imgSrc: ["'self'", 'data:', 'blob:'],
        fontSrc: ["'self'", 'data:'], connectSrc: ["'self'"], objectSrc: ["'none'"], frameSrc: ["'none'"],
        frameAncestors: ["'none'"], baseUri: ["'none'"], formAction: ["'self'"], workerSrc: ["'self'"],
        manifestSrc: ["'self'"], ...(config.isProdLike ? { upgradeInsecureRequests: [] } : {}),
      },
    },
    strictTransportSecurity: config.isProdLike ? { maxAge: 63072000, includeSubDomains: true, preload: true } : false,
    frameguard: { action: 'deny' },
    referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
    crossOriginOpenerPolicy: { policy: 'same-origin' },
    crossOriginResourcePolicy: { policy: config.corp },
    crossOriginEmbedderPolicy: false,
    xContentTypeOptions: true,
    xPermittedCrossDomainPolicies: { permittedPolicies: 'none' },
    hidePoweredBy: true,
  });
  app.addHook('onSend', async (req, reply, payload) => {
    reply.header('X-Robots-Tag', 'noindex, nofollow, noarchive');   // private school data: never in search results
    if (req.url.startsWith('/api/') && require('./lib/dto').leaks(payload)) {       // DTO safety net
      req.log.error({ route: req.routeOptions && req.routeOptions.url }, 'BLOCKED response containing a secret-bearing field');
      metrics.inc('dto_blocked_total', {});
      reply.code(500).type('application/json');
      return JSON.stringify({ error: { code: 'INTERNAL', message: 'Something went wrong on our side. Please try again.', requestId: req.id } });
    }
    reply.header('Permissions-Policy', 'camera=(), microphone=(), geolocation=(self), payment=(), usb=(), interest-cohort=()');
    if (req.url.startsWith('/api/')) reply.header('Cache-Control', 'no-store');
    reply.header('X-Request-Id', req.id);
    return payload;
  });

  // ── CORS: strict allow-list (never "*"); credentials only for trusted frontend origins ──
  app.register(require('@fastify/cors'), {
    origin: (origin, cb) => cb(null, config.isAllowedOrigin(origin) ? origin : false),
    credentials: true, methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'], allowedHeaders: ['content-type', 'x-csrf-token', 'idempotency-key'],
    exposedHeaders: ['x-request-id', 'idempotent-replayed'], maxAge: 600, strictPreflight: true,
  });
  app.register(require('@fastify/cookie'));
  app.register(require('@fastify/multipart'), {
    limits: { fileSize: config.storage.maxUploadBytes, files: 1, fields: 10, fieldSize: 10000, parts: 12 },
  });
  // ── rate limiting (in-memory per instance; set RATE_LIMIT_REDIS_URL for a shared store across instances) ──
  // per-network ceiling (a whole school behind one IP gets 40× the per-session budget; blocks cookie-spraying)
  const { sessionKey, ipCeiling } = require('./lib/ratekey');
  app.addHook('onRequest', ipCeiling({ perMinute: config.rateLimit.ipCeilingPerMinute }));
  app.register(require('@fastify/rate-limit'), {
    global: true,
    max: config.rateLimit.globalPerMinute,
    timeWindow: '1 minute',
    keyGenerator: sessionKey,           // signed-in users are limited per session, anonymous traffic per IP
    ...(config.rateLimit.redisUrl ? { redis: new (require('ioredis'))(config.rateLimit.redisUrl) } : {}),
    errorResponseBuilder: (req, ctx) => { const e = new AppError(429, 'RATE_LIMITED', `Too many requests. Try again in ${Math.ceil(ctx.ttl / 1000)}s.`); e.statusCode = 429; return e; },
    onExceeded: (req) => { metrics.inc('rate_limited_total', { route: req.routeOptions ? req.routeOptions.url : 'unknown' }); require('./lib/secmon').onRateLimited(req); },
  });

  app.register(require('./auth/plugin').authPlugin);

  // ── request metrics ──
  app.addHook('onResponse', require('./lib/secmon').onResponse);
  app.addHook('onResponse', async (req, reply) => {
    const route = (req.routeOptions && req.routeOptions.url) || 'unmatched';
    metrics.inc('http_requests_total', { method: req.method, route, status: reply.statusCode });
    metrics.observe('http_request_duration_seconds', { method: req.method }, reply.elapsedTime / 1000);
  });

  // ── safe error handling: never leak stack traces, SQL, or internals ──
  app.setErrorHandler((err, req, reply) => {
    let e = err instanceof AppError ? err : fromPg(err);
    if (!e && err.validation) {
      const first = err.validation[0] || {};
      const field = (first.instancePath || '').replace(/^\//, '').replace(/\//g, '.') || (first.params && (first.params.missingProperty || first.params.additionalProperty)) || 'request';
      const why = first.keyword === 'additionalProperties' ? 'is not an allowed field' : first.keyword === 'required' ? 'is required' : (first.message || 'is invalid');
      e = new AppError(400, 'VALIDATION_FAILED', `${field} ${why}.`, { field });
    }
    if (!e && err.statusCode === 429) e = new AppError(429, 'RATE_LIMITED', err.message || 'Too many requests.');
    if (!e && err.code === 'FST_REQ_FILE_TOO_LARGE') e = new AppError(413, 'FILE_TOO_LARGE', 'The file is too large.');
    if (!e && err.statusCode === 413) e = new AppError(413, 'PAYLOAD_TOO_LARGE', 'The request is too large.');
    if (!e && err.statusCode === 415) e = new AppError(415, 'UNSUPPORTED_MEDIA_TYPE', 'Unsupported content type.');
    // overload (Phase 7): every database connection is busy for too long → a clear "busy, try again" (503 + Retry-After),
    // never a generic 500. The web app shows the message; nothing was half-saved (the transaction never started).
    if (!e && /timeout exceeded when trying to connect/.test(err.message || '')) { metrics.inc('http_busy_total', { route: (req.routeOptions && req.routeOptions.url) || 'unmatched' }); reply.header('Retry-After', '3'); e = BUSY(); }
    if (!e && err.code === 'FST_INVALID_MULTIPART_CONTENT_TYPE') e = new AppError(415, 'UNSUPPORTED_MEDIA_TYPE', 'Send the file as multipart/form-data.');
    if (!e && err.statusCode >= 400 && err.statusCode < 500 && String(err.code || '').startsWith('FST_')) e = new AppError(err.statusCode === 406 ? 415 : err.statusCode, 'BAD_REQUEST', 'The request is malformed or uses an unsupported format.');
    if (!e) {
      req.log.error({ err }, 'unhandled error');
      metrics.inc('http_errors_total', { route: (req.routeOptions && req.routeOptions.url) || 'unmatched' });
      require('./lib/alerts').alert('server_error', { message: `${err.name || 'Error'}: ${err.message}`, route: (req.routeOptions && req.routeOptions.url) || 'unmatched', requestId: req.id, code: err.code });
      e = new AppError(500, 'INTERNAL', 'Something went wrong on our side. Please try again.');
    } else if (e.status >= 500) {
      req.log.error({ err }, 'server error');
    }
    reply.code(e.status).send({ error: { code: e.code, message: e.message, ...(e.details ? { details: e.details } : {}), requestId: req.id } });
  });
  app.setNotFoundHandler((req, reply) => {
    if (req.url.startsWith('/api/') || !config.serveFrontend) return reply.code(404).send({ error: { code: 'NOT_FOUND', message: 'Endpoint not found.', requestId: req.id } });
    return reply.type('text/html').sendFile('index.html');      // SPA fallback
  });

  // ── health / readiness / metrics ──
  app.get('/healthz', { config: { rateLimit: false } }, async () => ({ ok: true }));
  app.get('/readyz', { config: { rateLimit: false } }, async (req, reply) => {
    try { await pool.query('SELECT 1'); return { ok: true, db: 'up' }; } catch { return reply.code(503).send({ ok: false, db: 'down' }); }
  });
  app.get('/metrics', { config: { rateLimit: false } }, async (req, reply) => {
    const tok = config.metricsToken;
    const sent = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    if (!tok || !require('./security/crypto').safeEqual(sent, tok)) return reply.code(404).send({ error: { code: 'NOT_FOUND', message: 'Endpoint not found.', requestId: req.id } });
    reply.type('text/plain; version=0.0.4');
    return metrics.render({ db_pool_total: pool.totalCount, db_pool_idle: pool.idleCount, db_pool_waiting: pool.waitingCount, process_uptime_seconds: Math.round(process.uptime()) });
  });

  // ── API v1 ──
  app.register(async (api) => {
    // OpenAPI 3.1 (generated from the live schemas). API_DOCS=public|authenticated|off (default: public in dev, authenticated otherwise)
    const docsMode = process.env.API_DOCS || (config.isProdLike ? 'authenticated' : 'public');
    if (docsMode !== 'off') {
      api.get('/openapi.json', { onRequest: docsMode === 'public' ? [] : [app.authenticate] }, async () =>
        require('./lib/openapi').toOpenApi(app.routeList, { version: require('../../package.json').version }));
    }
    for (const r of ['auth', 'onboarding', 'me', 'platform', 'school', 'users', 'academic', 'people', 'attendance',
      'results', 'analytics', 'cbt', 'cbt_bank', 'lesson_notes', 'school_life', 'cashbook', 'store', 'comments_idcards', 'materials', 'act_as', 'web_address', 'finance', 'arrears', 'petty_cash', 'alerts', 'school_tools', 'billing', 'demo_links', 'comms', 'files', 'audit', 'data', 'ai', 'jobs', 'dashboard', 'migration', 'public', 'system', 'telemetry']) {
      api.register(require(`./routes/${r}`));
    }
  }, { prefix: '/api/v1' });

  // ── static frontend (no inline scripts; strict CSP). SERVE_FRONTEND=false when the web app is hosted on Netlify ──
  if (config.serveFrontend) app.register(require('@fastify/static'), {
    root: path.resolve(__dirname, '../../web'), prefix: '/', index: ['index.html'], decorateReply: true,
    setHeaders: (res, p) => {
      const set = (k, v) => (typeof res.setHeader === 'function' ? res.setHeader(k, v) : typeof res.header === 'function' ? res.header(k, v) : res.raw && res.raw.setHeader(k, v));
      if (/\.(js|css|svg|png|woff2)$/.test(p)) set('Cache-Control', 'public, max-age=300');
      if (p.endsWith('index.html')) set('Cache-Control', 'no-cache');
    },
  });
  return app;
}
module.exports = { buildApp };
