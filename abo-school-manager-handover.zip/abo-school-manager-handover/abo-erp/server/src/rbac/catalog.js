'use strict';
// Permission catalogue (synced into the `permissions` table on every migrate) and system role templates
// (copied into each school on registration; schools may then create custom roles).

const P = {
  // platform (A.B.O. operator / super-admin) — never granted to school roles
  'platform.schools.view': ['platform', 'View all schools on the platform', 'platform'],
  'platform.schools.manage': ['platform', 'Activate / suspend schools, change plans', 'platform'],
  'platform.security.view': ['platform', 'View platform security & login events', 'platform'],
  'platform.health.view': ['platform', 'View system health, jobs and metrics', 'platform'],
  'platform.support': ['platform', 'Open a time-limited, read-only, audited support view of a school', 'platform'],
  'platform.billing.manage': ['platform', 'Subscription plans, prices, payment gateway settings, demo timer and school subscriptions', 'platform'],

  'settings.view': ['school', 'View school profile & settings'],
  'settings.update': ['school', 'Edit school profile, branches, grading, report card and security settings'],
  'settings.branding': ['school', 'Upload logo and edit branding'],

  'users.view': ['users', 'View user accounts'],
  'users.create': ['users', 'Create user accounts / issue access codes'],
  'users.update': ['users', 'Edit user accounts, memberships, reset access'],
  'users.disable': ['users', 'Disable / enable accounts and revoke sessions'],
  'users.assign_role': ['users', 'Assign or remove roles'],
  'roles.view': ['users', 'View roles & permissions'],
  'roles.manage': ['users', 'Create / edit custom roles'],

  'students.view': ['students', 'View student records'],
  'students.create': ['students', 'Admit / create students'],
  'students.update': ['students', 'Edit student records'],
  'students.delete': ['students', 'Delete (archive) students'],
  'guardians.view': ['students', 'View parents / guardians'],
  'guardians.manage': ['students', 'Create / edit parents and link them to students'],
  'staff.view': ['staff', 'View staff'],
  'staff.create': ['staff', 'Create staff'],
  'staff.update': ['staff', 'Edit staff'],
  'teachers.view': ['staff', 'View teacher profiles and assignments'],
  'teachers.create': ['staff', 'Register teachers (TRCN, qualification)'],
  'teachers.update': ['staff', 'Edit teacher profiles and class/subject assignments'],
  'teachers.delete': ['staff', 'Remove teacher assignments / deactivate teachers'],
  'staff.delete': ['staff', 'Remove staff'],

  'academic.view': ['academic', 'View sessions, terms, classes, subjects, timetable'],
  'academic.manage': ['academic', 'Manage sessions, terms, classes, arms, subjects, assignments, timetable'],
  'promotion.run': ['academic', 'Run end-of-session promotion'],
  'lesson_notes.create': ['academic', 'Write lesson notes for classes/subjects assigned to you'],
  'lesson_notes.view': ['academic', 'View every lesson note in the school'],
  'lesson_notes.review': ['academic', 'Approve or return submitted lesson notes'],
  'lesson_notes.view_own': ['academic', 'Student: read approved lesson notes for own class'],
  'lesson_notes.view_children': ['academic', 'Parent: read approved lesson notes for children’s classes'],

  'attendance.view': ['attendance', 'View attendance'],
  'attendance.create': ['attendance', 'Take registers for classes assigned to you'],
  'attendance.update': ['attendance', 'Take or amend registers for any class'],

  'results.view': ['results', 'View score sheets, broadsheets and results (staff)'],
  'results.enter': ['results', 'Enter scores for subjects assigned to you'],
  'results.enter_any': ['results', 'Enter scores for any class/subject'],
  'results.update': ['results', 'Request corrections to locked results'],
  'results.review': ['results', 'Review submitted score sheets (step before approval)'],
  'results.approve': ['results', 'Review, approve or return score sheets; approve corrections'],
  'results.publish': ['results', 'Publish results to students and parents'],
  'results.view_own': ['results', 'Student: view own published results'],
  'results.view_children': ['results', 'Parent: view linked children’s published results'],
  'reports.view': ['reports', 'View report cards and analytics'],
  'reports.export': ['reports', 'Export data (CSV / Excel)'],

  'cbt.view': ['cbt', 'View CBT exams and question bank'],
  'cbt.create': ['cbt', 'Create CBT exams and questions'],
  'cbt.update': ['cbt', 'Edit CBT exams and questions'],
  'cbt.publish': ['cbt', 'Publish / close CBT exams'],
  'cbt.grade': ['cbt', 'Grade theory answers'],
  'cbt.results': ['cbt', 'View CBT attempts and scores'],
  'cbt.take': ['cbt', 'Student: take CBT exams'],

  'fees.view': ['finance', 'View fee items, invoices and payments'],
  'fees.create': ['finance', 'Create fee items and generate invoices'],
  'fees.update': ['finance', 'Edit fee structures & categories; void invoices; add student charges'],
  'fees.approve': ['finance', 'Approve discounts / scholarships'],
  'payments.record': ['finance', 'Record payments and issue receipts'],
  'payments.reverse': ['finance', 'Reverse payments'],
  'fees.view_own': ['finance', 'Student: view own invoices and receipts'],
  'fees.view_children': ['finance', 'Parent: view children’s invoices and receipts'],

  'announcements.view': ['communication', 'Read announcements'],
  'announcements.manage': ['communication', 'Post school / class / role announcements'],
  'messages.use': ['communication', 'Send and receive messages'],
  'timetable.view_own': ['academic', 'Student/parent: view class timetable'],

  'documents.view': ['documents', 'View documents'],
  'documents.upload': ['documents', 'Upload documents'],
  'documents.delete': ['documents', 'Delete documents'],

  'audit_logs.view': ['security', 'View the school audit log'],
  'security.view': ['security', 'View school security & login events'],
  'imports.run': ['data', 'Import CSV / Excel data'],
  'ai.use': ['ai', 'Use AI remark suggestions (never auto-applied)'],

  'clock.use': ['staff', 'Clock in and out (own record)'],
  'clock.view': ['staff', 'See the staff clock-in register'],
  'clock.manage': ['staff', 'Set the school location, distance and late time for clock-in'],
  'calendar.view': ['academic', 'See the school calendar'],
  'calendar.manage': ['academic', 'Add, change and remove calendar events'],
  'birthdays.view': ['people', 'See upcoming pupil and staff birthdays'],
  'cashbook.view': ['finance', 'See the cashbook: other income, expenses and petty cash'],
  'cashbook.record': ['finance', 'Record income and expenses in the cashbook'],
  'cashbook.void': ['finance', 'Void a cashbook entry (with a reason)'],
  'store.view': ['store', 'See store items, stock and sales'],
  'store.manage': ['store', 'Add store items, set prices, receive stock and correct stock counts'],
  'store.sell': ['store', 'Sell items from the store and issue receipts'],
  'store.void': ['store', 'Void a store sale (stock goes back)'],
  'materials.create': ['academic', 'Share study materials and live classes with classes you teach'],
  'materials.manage': ['academic', 'Share with any class and remove anyone\'s study materials and live classes'],
  'materials.view': ['academic', 'See all study materials and live classes'],
  'materials.view_own': ['academic', 'Student: study materials and live classes for own class'],
  'materials.view_children': ['academic', 'Parent: study materials and live classes for children’s classes'],
  'users.impersonate': ['users', 'Sign in as another member of the school for a short, recorded time (owner only by default)'],
  // 027 (12 Oct 2026): the last offline-edition features, now on the server
  'pettycash.request': ['cashbook', 'Ask for petty cash for school spending'],
  'pettycash.approve': ['cashbook', 'Approve or refuse petty cash requests (never your own)'],
  'alerts.view': ['school', 'See automatic alerts: unpaid fees, low attendance, low stock'],
  'alerts.manage': ['school', 'Set the alert rules and send fee reminders to parents'],
  'devices.view': ['school', 'See the list of school devices'],
  'devices.manage': ['school', 'Add, edit and retire school devices'],
};

const ALL_SCHOOL = Object.keys(P).filter((k) => P[k][2] !== 'platform');
const PLATFORM = Object.keys(P).filter((k) => P[k][2] === 'platform');
const VIEW_ONLY = ALL_SCHOOL.filter((k) => /\.view$/.test(k) || k === 'reports.view');
const minus = (list, ...drop) => list.filter((k) => !drop.includes(k));

const STAFF_BASE = ['announcements.view', 'messages.use', 'academic.view', 'documents.view', 'clock.use', 'calendar.view', 'birthdays.view', 'pettycash.request'];
const TEACHER = [...STAFF_BASE, 'students.view', 'guardians.view', 'teachers.view', 'attendance.view', 'attendance.create', 'results.view',
  'results.enter', 'results.update', 'reports.view', 'cbt.view', 'cbt.create', 'cbt.update', 'cbt.grade', 'cbt.results', 'ai.use', 'lesson_notes.create', 'materials.create', 'materials.view'];

const ROLE_TEMPLATES = [
  { key: 'school_owner', name: 'School Owner / Proprietor', mfa: true, perms: ALL_SCHOOL.filter((k) => !/_own$|_children$|cbt\.take/.test(k)) },
  { key: 'principal', name: 'Principal', mfa: true, perms: minus(ALL_SCHOOL.filter((k) => !/_own$|_children$|cbt\.take/.test(k)), 'roles.manage', 'payments.reverse', 'users.impersonate') },
  { key: 'vice_principal', name: 'Vice Principal', perms: ['alerts.view', 'devices.view', ...TEACHER, 'clock.view', 'calendar.manage', 'materials.manage', 'lesson_notes.view', 'lesson_notes.review', 'attendance.update', 'results.review', 'results.approve', 'staff.view', 'students.update', 'announcements.manage', 'audit_logs.view', 'reports.export', 'cbt.publish'] },
  { key: 'head_of_school', name: 'Head of School', perms: ['alerts.view', 'devices.view', ...TEACHER, 'clock.view', 'calendar.manage', 'materials.manage', 'lesson_notes.view', 'lesson_notes.review', 'attendance.update', 'results.review', 'results.approve', 'results.publish', 'staff.view', 'students.update', 'announcements.manage', 'reports.export', 'cbt.publish'] },
  { key: 'administrator', name: 'School Administrator', mfa: true, perms: minus(ALL_SCHOOL.filter((k) => !/_own$|_children$|cbt\.take/.test(k)), 'payments.reverse', 'fees.approve', 'roles.manage', 'users.impersonate') },
  { key: 'teacher', name: 'Teacher', perms: TEACHER },
  { key: 'form_teacher', name: 'Form Teacher', perms: [...TEACHER, 'guardians.manage', 'students.update'] },
  { key: 'accountant', name: 'Accountant', mfa: true, perms: ['alerts.view', ...STAFF_BASE, 'students.view', 'guardians.view', 'fees.view', 'fees.create', 'fees.update', 'payments.record', 'reports.view', 'reports.export', 'cashbook.view', 'cashbook.record', 'store.view', 'store.sell'] },
  { key: 'bursar', name: 'Bursar', mfa: true, perms: ['pettycash.approve', 'alerts.view', 'alerts.manage', ...STAFF_BASE, 'students.view', 'guardians.view', 'fees.view', 'fees.create', 'fees.update', 'fees.approve', 'payments.record', 'payments.reverse', 'reports.view', 'reports.export', 'audit_logs.view', 'cashbook.view', 'cashbook.record', 'cashbook.void', 'store.view', 'store.manage', 'store.sell', 'store.void'] },
  { key: 'exam_officer', name: 'Exam Officer', perms: [...TEACHER, 'lesson_notes.view', 'results.enter_any', 'results.review', 'results.approve', 'results.publish', 'cbt.publish', 'reports.export', 'imports.run'] },
  { key: 'ict_officer', name: 'ICT / Admin Officer', mfa: true, perms: ['devices.view', 'devices.manage', ...STAFF_BASE, 'teachers.view', 'users.view', 'users.create', 'users.update', 'users.disable', 'users.assign_role', 'roles.view', 'students.view', 'staff.view', 'guardians.view', 'imports.run', 'security.view', 'settings.view'] },
  { key: 'librarian', name: 'Librarian', perms: [...STAFF_BASE, 'students.view', 'documents.upload', 'store.view'] },
  { key: 'parent', name: 'Parent / Guardian', portal: 'parent', perms: ['announcements.view', 'messages.use', 'results.view_children', 'fees.view_children', 'timetable.view_own', 'lesson_notes.view_children', 'calendar.view', 'materials.view_children'] },
  { key: 'student', name: 'Student', portal: 'student', perms: ['announcements.view', 'messages.use', 'results.view_own', 'fees.view_own', 'cbt.take', 'timetable.view_own', 'lesson_notes.view_own', 'calendar.view', 'materials.view_own'] },
];

for (const t of ROLE_TEMPLATES) for (const p of t.perms) if (!P[p]) throw new Error(`role ${t.key} references unknown permission ${p}`);

// Self-scoped permissions only ever expose the holder's OWN (or own children's) records, so granting them
// is not privilege escalation (e.g. an administrator creating a student or parent account).
const SELF_SCOPED = new Set(['results.view_own', 'results.view_children', 'fees.view_own', 'fees.view_children', 'cbt.take', 'timetable.view_own', 'lesson_notes.view_own', 'lesson_notes.view_children', 'materials.view_own', 'materials.view_children']);
module.exports = { SELF_SCOPED, PERMISSIONS: P, ALL_SCHOOL, PLATFORM, VIEW_ONLY, ROLE_TEMPLATES };
