'use strict';
const config = require('./config');
const { buildApp } = require('./app');
const { pool } = require('./db/pool');

// Tenant isolation depends on the runtime DB role being subject to RLS: refuse to start in staging/production if it is a
// superuser, has BYPASSRLS, or OWNS the tables (owners bypass RLS). An unreachable DB is only a warning (see /readyz).
async function assertRuntimeRole() {
  if (!config.isProdLike) return;
  let r;
  try { r = (await pool.query(`SELECT r.rolsuper, r.rolbypassrls, (SELECT count(*)::int FROM pg_tables WHERE schemaname = 'public' AND tableowner = current_user) AS owns
    FROM pg_roles r WHERE r.rolname = current_user`)).rows[0]; } catch (e) { console.error('warning: database not reachable at startup:', e.message); return; }
  if (r && (r.rolsuper || r.rolbypassrls || r.owns > 0)) throw new Error('DATABASE_URL must use the NOBYPASSRLS runtime role (abo_app), not a superuser or the table owner — tenant isolation would not be enforced');
}

async function main() {
  await assertRuntimeRole();
  const app = buildApp();
  await app.listen({ host: config.host, port: config.port });
  let worker = null;
  if (config.runWorkerInProcess) { worker = require('./jobs/worker').start(); app.log.info('in-process worker started'); }
  const shutdown = async (sig) => {
    app.log.info({ sig }, 'shutting down');
    if (worker) worker.stop();
    await app.close();
    await pool.end();
    process.exit(0);
  };
  // crashes are logged, alerted (ERROR_WEBHOOK_URL) and — for uncaught exceptions — the process exits so the platform restarts it
  const { alert } = require('./lib/alerts');
  process.on('unhandledRejection', (e) => { app.log.error({ err: e }, 'unhandled promise rejection'); alert('crash', { message: `unhandledRejection: ${e && e.message}` }); });
  process.on('uncaughtException', (e) => { app.log.fatal({ err: e }, 'uncaught exception'); alert('crash', { message: `uncaughtException: ${e && e.message}` }); setTimeout(() => process.exit(1), 1500).unref(); });
  app.log.info({ env: config.env, publicOrigin: config.publicOrigin, serveFrontend: config.serveFrontend, proxyRequired: config.proxy.require }, 'api listening');
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}
main().catch((e) => { console.error('startup failed:', e.message); process.exit(1); });
