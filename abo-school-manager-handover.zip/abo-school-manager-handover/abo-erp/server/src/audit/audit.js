'use strict';
// Server-side audit trail. Rows are appended through app.audit_append() (SECURITY DEFINER) which
// hash-chains each school's log; the runtime DB role has no INSERT/UPDATE/DELETE on audit_logs and
// triggers block UPDATE/DELETE/TRUNCATE even for the owner. app.audit_verify() detects tampering.
const { withTx } = require('../db/pool');

const REDACT = /pass(word)?|token|secret|code|otp|cookie|authorization/i;
function scrub(meta) {
  if (!meta || typeof meta !== 'object') return {};
  const out = {};
  for (const [k, v] of Object.entries(meta)) {
    if (REDACT.test(k)) { out[k] = '[redacted]'; continue; }
    if (v && typeof v === 'object' && !Array.isArray(v)) out[k] = scrub(v);
    else if (typeof v === 'string') out[k] = v.slice(0, 500);
    else out[k] = v;
  }
  return out;
}
function actorOf(req) {
  const a = req && req.auth;
  return {
    school: a ? a.schoolId || null : null,
    // "sign in as": the audit log names the REAL person (the owner) and who they were acting as
    user: a ? (a.actingBy ? a.actingBy.userId : a.userId) : null,
    login: a ? (a.actingBy ? `${a.actingBy.loginId} (as ${a.loginId})`.slice(0, 120) : a.loginId) : null,
    roles: a ? (a.roles || []).map((r) => r.key || String(r)).concat(a.support ? ['platform_support'] : []) : null,
    ip: req ? req.ip : null,
    ua: req && req.headers ? String(req.headers['user-agent'] || '').slice(0, 300) : null,
  };
}
// Append inside the caller's transaction (call it LAST in a handler so the per-school chain lock is short).
async function audit(client, req, action, { type = null, id = null, success = true, meta = {}, schoolId } = {}) {
  const a = actorOf(req);
  await client.query('SELECT app.audit_append($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)', [
    schoolId !== undefined ? schoolId : a.school, a.user, a.login, a.roles, action, type, id == null ? null : String(id),
    success, a.ip, a.ua, scrub(meta),
  ]);
}
// Stand-alone (own transaction) — for denials/failures whose business transaction rolled back.
async function auditAlone(req, action, opts = {}) {
  const a = actorOf(req);
  const school = opts.schoolId !== undefined ? opts.schoolId : a.school;
  try {
    await withTx({ schoolId: school, userId: a.user, platform: !school }, (c) => audit(c, req, action, { ...opts, schoolId: school }));
  } catch (e) { if (req && req.log) req.log.error({ err: e }, 'audit write failed'); }
}
async function securityEvent({ schoolId = null, userId = null, kind, severity = 'info', detail = {}, ip = null }) {
  try {
    await withTx({ schoolId, platform: !schoolId }, (c) => c.query(
      'INSERT INTO security_events (school_id, user_id, kind, severity, detail, ip) VALUES ($1,$2,$3,$4,$5,$6)',
      [schoolId, userId, kind, severity, scrub(detail), ip]));
  } catch (e) { process.stderr.write(`[security_event] write failed: ${e.message}\n`); }
}
async function loginEvent({ schoolId = null, userId = null, attempt, success, reason, ip, ua }) {
  await withTx({ schoolId, platform: !schoolId }, (c) => c.query(
    'INSERT INTO login_events (school_id, user_id, login_attempt, success, reason, ip, user_agent) VALUES ($1,$2,$3,$4,$5,$6,$7)',
    [schoolId, userId, String(attempt || '').slice(0, 80), success, reason, ip, String(ua || '').slice(0, 300)]));
}
module.exports = { audit, auditAlone, securityEvent, loginEvent, scrub };
