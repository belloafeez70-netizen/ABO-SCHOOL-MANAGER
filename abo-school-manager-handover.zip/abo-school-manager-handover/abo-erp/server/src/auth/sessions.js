'use strict';
// Opaque server-side sessions. The browser holds only a random 256-bit token in an HttpOnly, Secure,
// SameSite=Strict cookie; the database stores sha256(token). Tokens rotate every SESSION_ROTATE_MINUTES
// and on every privilege change (login, MFA verification, password change), with a 60 s grace window
// for in-flight requests carrying the previous token.
const config = require('../config');
const { withTx, raw } = require('../db/pool');
const { randomToken, sha256, hmac } = require('../security/crypto');

const COOKIE = config.cookie.secure ? '__Host-abo_sid' : 'abo_sid';
const cookieOpts = (maxAgeSec) => ({
  path: '/', httpOnly: true, secure: config.cookie.secure, sameSite: 'strict',
  ...(maxAgeSec !== undefined ? { maxAge: maxAgeSec } : {}),
});

function setCookie(reply, token) {
  reply.setCookie(COOKIE, token, cookieOpts(config.session.absoluteHours * 3600));
}
function clearCookie(reply) { reply.clearCookie(COOKIE, cookieOpts()); }

function uaLabel(ua = '') {
  const b = /Edg\//.test(ua) ? 'Edge' : /OPR\//.test(ua) ? 'Opera' : /Chrome\//.test(ua) ? 'Chrome' : /Firefox\//.test(ua) ? 'Firefox' : /Safari\//.test(ua) ? 'Safari' : 'Browser';
  const os = /Android/.test(ua) ? 'Android' : /iPhone|iPad/.test(ua) ? 'iOS' : /Windows/.test(ua) ? 'Windows' : /Mac OS X/.test(ua) ? 'macOS' : /Linux/.test(ua) ? 'Linux' : 'Unknown OS';
  return `${b} on ${os}`;
}

async function createSession(client, { userId, schoolId, mfaState, ip, ua }) {
  const token = randomToken(32);
  const now = Date.now();
  // cap concurrent sessions per user (revoke the oldest)
  await client.query(`UPDATE sessions SET revoked_at = now(), revoked_reason = 'session_limit'
    WHERE id IN (SELECT id FROM sessions WHERE user_id = $1 AND revoked_at IS NULL ORDER BY last_seen_at DESC OFFSET $2)`,
  [userId, config.session.maxPerUser - 1]);
  const r = await client.query(`INSERT INTO sessions (user_id, school_id, token_hash, mfa_state, ip, user_agent, device_label, idle_expires_at, expires_at)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`, [
    userId, schoolId, sha256(token), mfaState, ip, String(ua || '').slice(0, 300), uaLabel(ua),
    new Date(now + config.session.idleMinutes * 60000), new Date(now + config.session.absoluteHours * 3600000),
  ]);
  return { token, sessionId: r.rows[0].id };
}

async function rotate(client, sessionId) {
  const token = randomToken(32);
  await client.query(`UPDATE sessions SET prev_token_hash = token_hash, prev_valid_until = now() + interval '60 seconds',
    token_hash = $2, rotated_at = now() WHERE id = $1`, [sessionId, sha256(token)]);
  return token;
}

async function resolve(token) {
  if (!token || typeof token !== 'string' || token.length > 100) return null;
  const r = await raw('SELECT * FROM app.auth_session($1)', [sha256(token)]);
  return r.rows[0] || null;
}

async function detectReuse(token) {
  if (!token || typeof token !== 'string' || token.length > 100) return null;
  const r = await raw('SELECT * FROM app.auth_detect_reuse($1)', [sha256(token)]);
  return r.rows[0] || null;
}
const csrfFor = (sessionId) => hmac(config.secrets.csrf, `csrf:${sessionId}`);

async function revoke(ctx, sessionId, reason) {
  await withTx(ctx, (c) => c.query("UPDATE sessions SET revoked_at = now(), revoked_reason = $2 WHERE id = $1 AND revoked_at IS NULL", [sessionId, reason]));
}

module.exports = { COOKIE, setCookie, clearCookie, createSession, rotate, resolve, detectReuse, csrfFor, revoke, uaLabel };
