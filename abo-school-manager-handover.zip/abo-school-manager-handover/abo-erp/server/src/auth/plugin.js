'use strict';
// Authentication + authorization for every request. NOTHING here trusts client-supplied roles, school IDs
// or permissions: the tenant and permission set are derived from the server-side session on each request.
const config = require('../config');
const { withTx } = require('../db/pool');
const { E } = require('../lib/errors');
const S = require('./sessions');
const { PLATFORM, VIEW_ONLY } = require('../rbac/catalog');
const { safeEqual } = require('../security/crypto');
const { securityEvent } = require('../audit/audit');
// lazy: services/demo → provision → routes → auth/plugin would be a require cycle
const demoSvc = () => require('../services/demo');

// short-lived permission cache (per session); session validity itself is checked on EVERY request
const permCache = new Map();
const PERM_TTL_MS = 30000;
function invalidateUser(userId) { for (const [k, v] of permCache) if (v.userId === userId) permCache.delete(k); }
function invalidateSchool(schoolId) { for (const [k, v] of permCache) if (v.schoolId === schoolId) permCache.delete(k); }

async function loadGrants(userId, schoolId) {
  return withTx({ schoolId, userId, readOnly: true }, async (c) => {
    const roles = (await c.query(`SELECT r.id, r.key, r.name, r.portal, r.mfa_required FROM user_roles ur
      JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = $1 ORDER BY r.name`, [userId])).rows;
    const perms = (await c.query(`SELECT DISTINCT rp.permission_key FROM user_roles ur
      JOIN role_permissions rp ON rp.role_id = ur.role_id WHERE ur.user_id = $1`, [userId])).rows.map((r) => r.permission_key);
    const st = (await c.query('SELECT id FROM students WHERE user_id = $1 AND deleted_at IS NULL', [userId])).rows[0];
    const gd = (await c.query('SELECT id FROM guardians WHERE user_id = $1', [userId])).rows[0];
    const sf = (await c.query('SELECT id FROM staff WHERE user_id = $1', [userId])).rows[0];
    const children = gd ? (await c.query('SELECT student_id FROM student_guardians WHERE guardian_id = $1', [gd.id])).rows.map((r) => r.student_id) : [];
    return { roles, perms, studentId: st ? st.id : null, guardianId: gd ? gd.id : null, staffId: sf ? sf.id : null, children };
  });
}

function portalOf(roles, isPlatform) {
  if (isPlatform) return 'platform';
  if (roles.some((r) => r.portal === 'staff')) return 'staff';
  if (roles.some((r) => r.portal === 'parent')) return 'parent';
  if (roles.some((r) => r.portal === 'student')) return 'student';
  return 'staff';
}

const UNSAFE = new Set(['POST', 'PUT', 'PATCH', 'DELETE']);
// demo sessions: these API areas are refused (signing out of the demo itself stays allowed)
const DEMO_URL_BLOCKED = (req) => demoSvc().DEMO_BLOCKED_URL.test(req.url) && !/^\/api\/v1\/auth\/(logout|me)(\?|$)/.test(req.url);
// while signed in as someone else: no security settings, no other school, no private messages, no account management
const ACTING_BLOCKED = /^\/api\/v1\/(auth\/(mfa|password|switch-school|logout-all|sessions|memberships)|auth\/act-as(\?|$)|auth\/act-as\/candidates|messages|users|roles|platform)(\/|\?|$)/;

async function authPlugin(app) {
  app.decorateRequest('auth', null);

  // Origin / Fetch-Metadata check for every state-changing API request (CSRF defence layer 1)
  app.addHook('onRequest', async (req) => {
    if (!UNSAFE.has(req.method) || !req.url.startsWith('/api/')) return;
    if (req.routeOptions && req.routeOptions.config && req.routeOptions.config.webhook) return;
    const origin = req.headers.origin;
    if (origin && !config.isAllowedOrigin(origin)) throw E.forbidden('Cross-origin request blocked.');
    if (!origin && req.headers['sec-fetch-site'] === 'cross-site') throw E.forbidden('Cross-site request blocked.');
  });

  // a demo visitor changed something → the demo school is restored after the last visitor's session ends
  app.addHook('onResponse', async (req, reply) => {
    if (req.auth && req.auth.demo && UNSAFE.has(req.method) && reply.statusCode < 400) demoSvc().markDirty(req.auth.schoolId).catch(() => {});
  });

  // authenticate: resolves the session → user → tenant → roles/permissions
  app.decorate('authenticate', async function authenticate(req, reply) {
    const token = req.cookies && req.cookies[S.COOKIE];
    const s = await S.resolve(token);
    if (!s) {
      // rotated-out token replayed after its grace window ⇒ likely theft: revoke the session family
      const reused = token ? await S.detectReuse(token) : null;
      if (reused) await securityEvent({ schoolId: reused.school_id, userId: reused.user_id, kind: 'session_token_reuse', severity: 'high', detail: { session: reused.session_id }, ip: req.ip });   // awaited: the alert is stored before we answer (never throws)
      throw E.unauth();
    }
    const now = Date.now();
    if (new Date(s.expires_at).getTime() < now || new Date(s.idle_expires_at).getTime() < now) {
      await S.revoke({ schoolId: s.school_id, userId: s.user_id, platform: !s.school_id }, s.session_id, 'expired');
      S.clearCookie(reply);
      throw E.unauth('Your session has expired. Please sign in again.');
    }
    if (s.user_status !== 'active' || (!s.is_platform_admin && (s.school_status !== 'active' || s.membership_status !== 'active'))) {
      await S.revoke({ schoolId: s.school_id, userId: s.user_id, platform: !s.school_id }, s.session_id, 'account_inactive');
      S.clearCookie(reply);
      throw E.unauth('This account is not active.');
    }
    const cfg = (req.routeOptions && req.routeOptions.config) || {};
    if (s.mfa_state === 'pending' && !cfg.allowMfaPending) throw new (require('../lib/errors').AppError)(401, 'MFA_REQUIRED', 'Enter your authenticator code to continue.');
    if (s.mfa_state === 'enroll_required' && !cfg.allowMfaEnroll) throw new (require('../lib/errors').AppError)(403, 'MFA_ENROLL_REQUIRED', 'Your role requires two-factor authentication. Set it up to continue.');
    if (s.must_change_password && !cfg.allowPasswordChange && s.mfa_state !== 'pending') throw new (require('../lib/errors').AppError)(403, 'PASSWORD_CHANGE_REQUIRED', 'Please set a new password to continue.');

    // CSRF defence layer 2: per-session token (double-submit, HMAC-bound to the session id)
    if (UNSAFE.has(req.method)) {
      const sent = req.headers['x-csrf-token'];
      if (!sent || !safeEqual(sent, S.csrfFor(s.session_id))) {
        securityEvent({ schoolId: s.school_id, userId: s.user_id, kind: 'csrf_rejected', severity: 'medium', detail: { path: req.routeOptions && req.routeOptions.url }, ip: req.ip });
        throw E.forbidden('Security token missing or invalid. Refresh the page and try again.');
      }
    }

    const support = s.is_platform_admin && s.support_school_id && s.support_expires_at && new Date(s.support_expires_at).getTime() > now;
    const schoolId = support ? s.support_school_id : s.school_id;
    // "sign in as": only while the time has not run out and the other person is still an active member of THIS school
    const acting = !support && !s.is_platform_admin && s.acting_user_id && s.acting_expires_at && new Date(s.acting_expires_at).getTime() > now
      && s.acting_user_status === 'active' && s.acting_membership_status === 'active' && !s.acting_is_platform;
    if (acting && ACTING_BLOCKED.test(req.url)) throw E.forbidden('This is not allowed while you are signed in as someone else. Go back to your own account first.');
    // demo schools: owner controls, logins, settings, exports… are never part of a demo (server-enforced)
    const demo = !s.is_platform_admin && await demoSvc().isDemoSchool(s.school_id);
    if (demo && DEMO_URL_BLOCKED(req)) throw E.forbidden('This is switched off in the demo. Sign up to use it for your own school.');
    const effUser = acting ? s.acting_user_id : s.user_id;
    const cacheKey = `${s.session_id}:${schoolId || '-'}:${effUser}`;
    let g = permCache.get(cacheKey);
    if (!g || g.at + PERM_TTL_MS < now) {
      if (s.is_platform_admin) {
        g = { roles: [{ key: 'platform_admin', name: 'Platform Administrator', portal: 'platform' }], perms: [...PLATFORM, ...(support ? VIEW_ONLY : [])], studentId: null, guardianId: null, staffId: null, children: [] };
      } else {
        g = await loadGrants(effUser, schoolId);
        g.branchId = (acting ? s.acting_branch_id : s.branch_id) || null;
      }
      g.at = now; g.userId = effUser; g.schoolId = schoolId;
      permCache.set(cacheKey, g);
    }
    req.auth = {
      sessionId: s.session_id, userId: effUser, loginId: acting ? s.acting_login_id : s.login_id, fullName: acting ? s.acting_full_name : s.full_name, email: acting ? null : s.email,
      realUserId: s.user_id,
      actingBy: acting ? { userId: s.user_id, loginId: s.login_id, fullName: s.full_name, expiresAt: s.acting_expires_at, startedAt: s.acting_started_at, reason: s.acting_reason } : null,
      schoolId, homeSchoolId: s.school_id, isPlatform: s.is_platform_admin, support: !!support,
      mfaState: s.mfa_state, mfaEnabled: s.mfa_enabled, mustChangePassword: s.must_change_password,
      roles: g.roles, perms: new Set(g.perms), portal: portalOf(g.roles, s.is_platform_admin && !support),
      studentId: g.studentId, guardianId: g.guardianId, staffId: g.staffId, children: g.children, branchId: support ? null : (g.branchId || null),
      demo: demo ? { expiresAt: s.expires_at } : null,
    };
    if (demo) for (const k of demoSvc().DEMO_BLOCKED_PERMS) req.auth.perms.delete(k);
    // platform support mode is strictly read-only on school data
    if (support && UNSAFE.has(req.method) && !req.url.startsWith('/api/v1/platform/') && !req.url.startsWith('/api/v1/auth/')) {
      throw E.forbidden('Support mode is read-only.');
    }

    // sliding idle expiry + periodic token rotation (at most one write per minute per session)
    const lastSeenStale = now - new Date(s.idle_expires_at).getTime() + config.session.idleMinutes * 60000 > 60000;
    const rotateDue = !s.via_prev && now - new Date(s.rotated_at).getTime() > config.session.rotateMinutes * 60000;
    if (lastSeenStale || rotateDue) {
      await withTx({ schoolId: s.school_id, userId: s.user_id, platform: !s.school_id }, async (c) => {
        await c.query(`UPDATE sessions SET last_seen_at = now(), idle_expires_at = LEAST(expires_at, now() + make_interval(mins => $2)) WHERE id = $1`,
          [s.session_id, config.session.idleMinutes]);
        if (rotateDue) S.setCookie(reply, await S.rotate(c, s.session_id));
      });
    }
  });

  // helpers used by routes
  app.decorateRequest('can', function can(p) { return !!(this.auth && this.auth.perms.has(p)); });
  app.decorate('perm', (...keys) => {
    const guard = async (req) => {
      if (!req.auth) throw E.unauth();
      if (!keys.some((k) => req.auth.perms.has(k))) throw E.forbidden();
    };
    guard.perms = keys;                       // introspection for the generated API reference
    return guard;
  });
  app.decorate('platformOnly', Object.assign(async (req) => {
    if (!req.auth || !req.auth.isPlatform) throw E.forbidden();
    if (config.isProdLike && req.auth.mfaState !== 'verified') throw E.forbidden('Platform actions require two-factor authentication.');
  }, { platform: true }));
}

// tenant transaction context for a request (tenant ALWAYS from the session, never from the client)
function ctx(req, extra = {}) {
  if (!req.auth || !req.auth.schoolId) throw E.forbidden('No school context for this account.');
  return { schoolId: req.auth.schoolId, userId: req.auth.userId, branchId: req.auth.branchId, readOnly: req.auth.support || req.method === 'GET', ...extra };
}
const platformCtx = (req) => ({ platform: true, userId: req.auth.userId });

authPlugin[Symbol.for('skip-override')] = true;
module.exports = { authPlugin, ctx, platformCtx, invalidateUser, invalidateSchool, loadGrants };
