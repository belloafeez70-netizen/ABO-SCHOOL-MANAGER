'use strict';
// Environment-specific configuration. Secrets come ONLY from environment variables / a secrets manager
// (never from the frontend, never committed). In staging/production, missing or weak secrets abort startup.
const crypto = require('node:crypto');

const ENVS = ['development', 'test', 'staging', 'production'];
const env = process.env.NODE_ENV || 'development';
if (!ENVS.includes(env)) throw new Error(`NODE_ENV must be one of ${ENVS.join(', ')}`);
const isProdLike = env === 'production' || env === 'staging';

function str(name, def) {
  const v = process.env[name];
  return v === undefined || v === '' ? def : v;
}
function int(name, def, min = -Infinity, max = Infinity) {
  const raw = str(name, undefined);
  if (raw === undefined) return def;
  const n = Number.parseInt(raw, 10);
  if (!Number.isFinite(n) || n < min || n > max) throw new Error(`${name} must be an integer in [${min}, ${max}]`);
  return n;
}
function bool(name, def) {
  const v = str(name, undefined);
  if (v === undefined) return def;
  return ['1', 'true', 'yes', 'on'].includes(v.toLowerCase());
}
// Secrets: required in prod-like envs; in dev/test a deterministic *clearly-labelled* dev value is derived
// so local runs work without setup. Dev values are rejected if NODE_ENV is staging/production.
function secret(name, bytes = 32) {
  const v = str(name, undefined);
  if (v) {
    const buf = /^[A-Za-z0-9+/=]+$/.test(v) && v.length >= 43 ? Buffer.from(v, 'base64') : Buffer.from(v, 'utf8');
    if (buf.length < bytes) throw new Error(`${name} must be at least ${bytes} bytes of entropy (base64-encoded)`);
    // placeholder words only — a random base64 value may legitimately contain e.g. "dev" by chance
    if (isProdLike && /change[_-]?me|example|placeholder|dev[_-]?(only|secret|password)|^(dev|test|secret|password)$/i.test(v)) throw new Error(`${name} looks like a placeholder`);
    return buf.subarray(0, Math.max(bytes, buf.length));
  }
  if (isProdLike) throw new Error(`Missing required secret ${name}`);
  return crypto.createHash('sha256').update(`abo-dev-only:${name}`).digest();
}

// optional shared secret compared as a string: absent → null; present → same strength rules as secret()
const optionalSecretString = (name, bytes = 32) => { const v = str(name, undefined); if (!v) return null; secret(name, bytes); return v; };
const originOf = (u, name) => {
  if (!u) return u;
  let url; try { url = new URL(u); } catch { throw new Error(`${name} must be a full URL such as https://your-site.netlify.app`); }
  if (url.pathname !== '/' || url.search || url.hash) throw new Error(`${name} must be an origin only (no path), e.g. https://your-site.netlify.app`);
  return url.origin;
};

const config = {
  env,
  isProdLike,
  isTest: env === 'test',
  host: str('HOST', '0.0.0.0'),
  port: int('PORT', 8080, 1, 65535),
  logLevel: str('LOG_LEVEL', env === 'test' ? 'silent' : 'info'),
  // PUBLIC_ORIGIN = the address people type (today https://<site>.netlify.app; later your custom domain). Used for links
  // in e-mails and as the default allowed origin. ALLOWED_ORIGINS may list extra origins (e.g. old + new domain while
  // switching). ALLOWED_ORIGIN_REGEX optionally allows a pattern (e.g. Netlify deploy previews → a STAGING API only).
  publicOrigin: originOf(str('PUBLIC_ORIGIN', 'http://localhost:8080'), 'PUBLIC_ORIGIN'),
  allowedOrigins: [...new Set([originOf(str('PUBLIC_ORIGIN', 'http://localhost:8080'), 'PUBLIC_ORIGIN'),
    ...str('ALLOWED_ORIGINS', '').split(',').map((s) => s.trim()).filter(Boolean).map((o) => originOf(o, 'ALLOWED_ORIGINS'))])],
  allowedOriginRegex: (() => { const r = str('ALLOWED_ORIGIN_REGEX', undefined); if (!r) return null; if (!r.startsWith('^') || !r.endsWith('$')) throw new Error('ALLOWED_ORIGIN_REGEX must be anchored with ^ and $'); return new RegExp(r); })(),
  // Separate frontend host (Netlify): the API does not serve the web app and only accepts traffic that carries the
  // shared secret added by the Netlify edge proxy (health checks, metrics and payment webhooks excepted).
  serveFrontend: bool('SERVE_FRONTEND', true),
  // same-origin (default, Netlify proxy) | same-site (own-domain direct mode: portal.x.ng loads images from api.x.ng)
  corp: (() => { const v = str('CROSS_ORIGIN_RESOURCE_POLICY', 'same-origin'); if (!['same-origin', 'same-site'].includes(v)) throw new Error('CROSS_ORIGIN_RESOURCE_POLICY must be same-origin or same-site'); return v; })(),
  proxy: {
    sharedSecret: optionalSecretString('PROXY_SHARED_SECRET'),
    require: bool('REQUIRE_PROXY_SECRET', false),
  },
  monitoring: {
    errorWebhookUrl: str('ERROR_WEBHOOK_URL', undefined),     // Slack / Discord / Teams / any JSON webhook for 5xx + crash alerts
    errorWebhookFormat: (() => { const v = str('ERROR_WEBHOOK_FORMAT', 'json'); if (!['json', 'slack', 'discord'].includes(v)) throw new Error('ERROR_WEBHOOK_FORMAT must be json, slack or discord'); return v; })(),
    serviceName: str('SERVICE_NAME', 'abo-api'),
    release: str('RELEASE', str('RENDER_GIT_COMMIT', str('COMMIT_REF', undefined))),
  },
  trustProxy: str('TRUST_PROXY', isProdLike ? 'loopback' : 'loopback'),
  db: {
    url: str('DATABASE_URL', 'postgres://abo_app:abo_app_dev_password@127.0.0.1:5432/abo_erp'),
    migrationUrl: str('MIGRATION_DATABASE_URL', 'postgres://abo_owner:abo_owner_dev_password@127.0.0.1:5432/abo_erp'),
    poolMax: int('DB_POOL_MAX', 20, 1, 500),
    queueMax: int('DB_QUEUE_MAX', 500, 10, 100000),        // requests allowed to wait for a connection before "busy" (503)
    statementTimeoutMs: int('DB_STATEMENT_TIMEOUT_MS', 15000, 100, 600000),
    ssl: str('DB_SSL', isProdLike ? 'require' : 'off'),
    sslCa: str('DB_SSL_CA', undefined),
  },
  cookie: {
    secure: bool('COOKIE_SECURE', isProdLike),
    domain: str('COOKIE_DOMAIN', undefined),
  },
  session: {
    idleMinutes: int('SESSION_IDLE_MINUTES', 120, 5, 7 * 24 * 60),
    absoluteHours: int('SESSION_ABSOLUTE_HOURS', 72, 1, 24 * 30),
    rotateMinutes: int('SESSION_ROTATE_MINUTES', 15, 1, 24 * 60),
    maxPerUser: int('SESSION_MAX_PER_USER', 10, 1, 100),
  },
  lockout: {
    threshold: int('LOCKOUT_THRESHOLD', 5, 3, 50),         // failures before temporary lock
    baseMinutes: int('LOCKOUT_BASE_MINUTES', 5, 1, 60),    // doubles for every further failure
    maxMinutes: int('LOCKOUT_MAX_MINUTES', 60, 5, 24 * 60),
  },
  argon2: {
    memoryCost: int('ARGON2_MEMORY_KIB', 19456, 8192, 1048576),   // OWASP minimum: 19 MiB, t=2, p=1
    timeCost: int('ARGON2_TIME', 2, 1, 10),
    parallelism: int('ARGON2_PARALLELISM', 1, 1, 16),
  },
  rateLimit: {
    globalPerMinute: int('RATE_LIMIT_GLOBAL_PER_MIN', 600, 10, 100000),
    ipCeilingPerMinute: int('RATE_LIMIT_IP_CEILING_PER_MIN', Math.max(24000, int('RATE_LIMIT_GLOBAL_PER_MIN', 600, 10, 100000) * 40), 100, 10000000),
    loginPerMinute: int('RATE_LIMIT_LOGIN_PER_MIN', 10, 1, 1000),              // per account per IP
    authIpPerMinute: int('RATE_LIMIT_AUTH_IP_PER_MIN', 300, 5, 100000),          // all sign-in attempts from one IP
    registerPerHour: int('RATE_LIMIT_REGISTER_PER_HOUR', 5, 1, 1000),
    redisUrl: str('RATE_LIMIT_REDIS_URL', undefined),
  },
  secrets: {
    csrf: secret('CSRF_SECRET'),
    dataKey: secret('DATA_ENCRYPTION_KEY'),     // AES-256-GCM for MFA secrets
    fileUrl: secret('FILE_URL_SECRET'),
  },
  storage: {
    driver: str('STORAGE_DRIVER', 'local'),
    dir: str('STORAGE_DIR', require('node:path').resolve(__dirname, '../../../var/storage')),
    s3: {
      endpoint: str('S3_ENDPOINT', undefined),
      region: str('S3_REGION', 'us-east-1'),
      bucket: str('S3_BUCKET', undefined),
      accessKeyId: str('S3_ACCESS_KEY_ID', undefined),
      secretAccessKey: str('S3_SECRET_ACCESS_KEY', undefined),
      forcePathStyle: bool('S3_FORCE_PATH_STYLE', true),
      // stream = files pass through the API (works with the Netlify proxy, no bucket CORS); redirect = 60-second signed URL
      downloadMode: (() => { const v = str('S3_DOWNLOAD_MODE', 'stream'); if (!['stream', 'redirect'].includes(v)) throw new Error('S3_DOWNLOAD_MODE must be stream or redirect'); return v; })(),
    },
    maxUploadBytes: int('MAX_UPLOAD_BYTES', 5 * 1024 * 1024, 1024, 100 * 1024 * 1024),
    clamav: { host: str('CLAMAV_HOST', undefined), port: int('CLAMAV_PORT', 3310, 1, 65535) },
  },
  mail: {
    smtpUrl: str('SMTP_URL', undefined),
    from: str('MAIL_FROM', 'A.B.O. School Manager <no-reply@example.com>'),
  },
  ai: {
    providerUrl: str('AI_PROVIDER_URL', undefined),   // OpenAI-compatible /v1/chat/completions
    apiKey: str('AI_API_KEY', undefined),
    model: str('AI_MODEL', 'gpt-4o-mini'),
    timeoutMs: int('AI_TIMEOUT_MS', 15000, 1000, 120000),
  },
  payments: {
    paystackSecret: str('PAYSTACK_SECRET_KEY', undefined),
    paystackBaseUrl: str('PAYSTACK_BASE_URL', 'https://api.paystack.co'),
  },
  metricsToken: str('METRICS_TOKEN', undefined),
  runWorkerInProcess: bool('RUN_WORKER_IN_PROCESS', !isProdLike),
  mfaIssuer: str('MFA_ISSUER', 'A.B.O. School Manager'),
  // New schools: 'manual' = verified schools wait for a platform admin to approve them (default);
  // 'auto' = e-mail verification activates the school immediately.
  schoolApproval: (() => { const v = str('SCHOOL_APPROVAL', 'manual'); if (!['manual', 'auto'].includes(v)) throw new Error('SCHOOL_APPROVAL must be manual or auto'); return v; })(),
  support: { email: str('SUPPORT_EMAIL', undefined), phone: str('SUPPORT_PHONE', undefined), hours: str('SUPPORT_HOURS', 'Mon–Fri, 8am–5pm WAT') },
};

// development/test convenience: accept the loopback aliases of the dev server (production uses ONLY the explicit list)
if (!isProdLike) {
  for (const h of ['localhost', '127.0.0.1']) { const o = `http://${h}:${config.port}`; if (!config.allowedOrigins.includes(o)) config.allowedOrigins.push(o); }
}
config.isAllowedOrigin = (origin) => !!origin && (config.allowedOrigins.includes(origin) || !!(config.allowedOriginRegex && config.allowedOriginRegex.test(origin)));
if (config.proxy.require && !config.proxy.sharedSecret) throw new Error('REQUIRE_PROXY_SECRET=true needs PROXY_SHARED_SECRET');
if (config.monitoring.errorWebhookUrl && !/^https:\/\//.test(config.monitoring.errorWebhookUrl) && isProdLike) throw new Error('ERROR_WEBHOOK_URL must be https://');
if (isProdLike) {
  if (config.allowedOrigins.some((o) => !o.startsWith('https://'))) throw new Error('every allowed origin must be https:// in staging/production');
  if (!config.cookie.secure) throw new Error('COOKIE_SECURE must be true in staging/production');
  if (!config.publicOrigin.startsWith('https://')) throw new Error('PUBLIC_ORIGIN must be https:// in staging/production');
  if (/dev_password/.test(config.db.url)) throw new Error('DATABASE_URL uses the development password');
  if (config.storage.driver === 's3' && !(config.storage.s3.bucket && config.storage.s3.accessKeyId && config.storage.s3.secretAccessKey)) {
    throw new Error('S3 storage selected but S3_BUCKET / credentials missing');
  }
}

module.exports = Object.freeze(config);
