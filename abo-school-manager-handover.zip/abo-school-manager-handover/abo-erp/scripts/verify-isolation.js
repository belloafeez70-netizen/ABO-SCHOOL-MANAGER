#!/usr/bin/env node
'use strict';
// Proves school isolation directly in the database the API will use (works on Supabase or any PostgreSQL).
// It creates two clearly named TEST schools as the schema owner, then connects as the runtime role (abo_app,
// NOBYPASSRLS) and tries to read/change/insert across schools and to weaken the database. Afterwards the two test
// schools are deleted again (cascade). Nothing else is touched.
//
//   MIGRATION_DATABASE_URL=postgres://abo_owner.<ref>:…@aws-0-eu-west-1.pooler.supabase.com:5432/abo_erp \
//   DATABASE_URL=postgres://abo_app.<ref>:…@aws-0-eu-west-1.pooler.supabase.com:6543/abo_erp \
//   DB_SSL=require node scripts/verify-isolation.js
const { Client } = require('pg');
const { sslFor } = require('../server/src/db/ssl');

const ownerUrl = process.env.MIGRATION_DATABASE_URL, appUrl = process.env.DATABASE_URL;
if (!ownerUrl || !appUrl) { console.error('Set MIGRATION_DATABASE_URL (owner) and DATABASE_URL (abo_app).'); process.exit(2); }
const results = []; let failed = 0;
const check = (name, ok, detail = '') => { results.push({ name, ok }); if (!ok) failed++; console.log((ok ? '✔ ' : '✖ ') + name + (detail ? ' — ' + detail : '')); };

(async () => {
  const tag = 'zz-isolation-' + Date.now().toString(36);
  const own = new Client({ connectionString: ownerUrl, ssl: sslFor(ownerUrl) }); await own.connect();
  const app = new Client({ connectionString: appUrl, ssl: sslFor(appUrl) }); await app.connect();
  let A, B;
  try {
    A = (await own.query('INSERT INTO schools (slug, name) VALUES ($1, $2) RETURNING id', [tag + '-a', 'ZZ Isolation Test A'])).rows[0].id;
    B = (await own.query('INSERT INTO schools (slug, name) VALUES ($1, $2) RETURNING id', [tag + '-b', 'ZZ Isolation Test B'])).rows[0].id;
    for (const [sid, n] of [[A, 3], [B, 2]]) for (let i = 0; i < n; i++)
      await own.query("INSERT INTO students (school_id, admission_no, first_name, last_name, gender) VALUES ($1, $2, 'Test', $3, 'Female')", [sid, `${tag}-${i}`, 'Pupil' + i]);

    const role = (await app.query('SELECT rolsuper, rolbypassrls FROM pg_roles WHERE rolname = current_user')).rows[0];
    check('runtime role is not superuser and cannot bypass RLS', !role.rolsuper && !role.rolbypassrls, JSON.stringify(role));
    const tables = (await own.query(`SELECT c.relname, c.relrowsecurity FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
      WHERE n.nspname = 'public' AND c.relkind = 'r' AND EXISTS (SELECT 1 FROM information_schema.columns k WHERE k.table_schema = 'public' AND k.table_name = c.relname AND k.column_name = 'school_id')`)).rows;
    const open = tables.filter((t) => !t.relrowsecurity).map((t) => t.relname);
    check(`every table with school_id has RLS on (${tables.length} tables)`, open.length === 0, open.join(', '));

    const inTx = async (sid, fn) => { await app.query('BEGIN'); try { if (sid) await app.query("SELECT set_config('app.school_id', $1, true)", [sid]); return await fn(); } finally { await app.query('ROLLBACK'); } };
    const n = async (sid, where) => inTx(sid, async () => (await app.query(`SELECT count(*)::int AS n FROM students WHERE admission_no LIKE $1 ${where || ''}`, [tag + '%'])).rows[0].n);
    check('no school set → sees 0 test pupils', (await n(null)) === 0);
    check('as school A → sees only A’s 3 pupils', (await n(A)) === 3);
    check('as school B → sees only B’s 2 pupils', (await n(B)) === 2);
    check('as school A, asking for B’s pupils by id → 0', (await inTx(A, async () => (await app.query('SELECT count(*)::int AS n FROM students WHERE school_id = $1', [B])).rows[0].n)) === 0);
    check('as school A, changing B’s pupils → 0 rows changed', (await inTx(A, async () => (await app.query("UPDATE students SET first_name = 'X' WHERE school_id = $1", [B])).rowCount)) === 0);
    check('as school A, deleting B’s pupils → 0 rows deleted', (await inTx(A, async () => (await app.query('DELETE FROM students WHERE school_id = $1', [B])).rowCount)) === 0);
    const refused = async (sid, q, p) => { try { await inTx(sid, () => app.query(q, p)); return false; } catch (e) { return true; } };
    check('as school A, adding a pupil to B → refused', await refused(A, "INSERT INTO students (school_id, admission_no, first_name, last_name, gender) VALUES ($1, $2, 'Evil', 'Insert', 'Male')", [B, tag + '-evil']));
    check('runtime role cannot switch RLS off', await refused(null, 'ALTER TABLE students DISABLE ROW LEVEL SECURITY'));
    check('runtime role cannot drop tables', await refused(null, 'DROP TABLE students'));
    check('runtime role cannot create tables', await refused(null, 'CREATE TABLE zz_hack (x int)'));
  } finally {
    if (A || B) await own.query('DELETE FROM schools WHERE slug LIKE $1', [tag + '%']).catch((e) => console.error('cleanup:', e.message));
    await app.end(); await own.end();
  }
  console.log(`\n${results.length - failed}/${results.length} passed`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.error('isolation check failed to run:', e.message); process.exit(2); });
