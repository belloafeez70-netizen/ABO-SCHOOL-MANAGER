#!/usr/bin/env node
'use strict';
// Local stand-in for Netlify, used to prove the production layout BEFORE deploying:
//   • serves the built site (dist/web) with the generated _headers (CSP, HSTS, caching)
//   • runs the REAL edge function file netlify/edge-functions/api-proxy.js for /api/* (Netlify.env + context emulated)
//   • HTTPS with a throw-away self-signed certificate, so Secure/__Host- cookies behave as on https://<site>.netlify.app
// Usage:  API_ORIGIN=http://127.0.0.1:8080 PROXY_SHARED_SECRET=... PORT=8888 node scripts/netlify-local.js
// (Netlify itself, not this script, runs the site in production. `netlify dev` from the Netlify CLI is an alternative.)
const fs = require('node:fs');
const path = require('node:path');
const https = require('node:https');
const http = require('node:http');
const os = require('node:os');
const crypto = require('node:crypto');
const { execFileSync } = require('node:child_process');
const { Readable } = require('node:stream');
const { pathToFileURL } = require('node:url');

const ROOT = path.resolve(__dirname, '..');
const SITE = process.env.SITE_DIR ? path.resolve(process.env.SITE_DIR) : path.join(ROOT, 'dist', 'web');
const PORT = Number(process.env.PORT || 8888);
const TLS = process.env.LOCAL_TLS !== 'false';
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.txt': 'text/plain; charset=utf-8', '.png': 'image/png', '.map': 'application/json', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.ico': 'image/x-icon', '.woff2': 'font/woff2' };

// parse Netlify _headers: "path\n  Name: value" blocks; "*" is a wildcard
function loadHeaders() {
  const rules = []; let cur = null;
  for (const line of fs.readFileSync(path.join(SITE, '_headers'), 'utf8').split('\n')) {
    if (!line.trim()) continue;
    if (!/^\s/.test(line)) { cur = { re: new RegExp('^' + line.trim().replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*') + '$'), headers: [] }; rules.push(cur); }
    else { const i = line.indexOf(':'); cur.headers.push([line.slice(0, i).trim(), line.slice(i + 1).trim()]); }
  }
  return rules;
}

async function main() {
  if (!fs.existsSync(path.join(SITE, 'index.html'))) throw new Error('dist/web missing — run npm run build:web first');
  const rules = loadHeaders();
  globalThis.Netlify = { env: { get: (k) => process.env[k] } };
  // Netlify runs edge functions as ES modules (Deno); this repo's package.json is CommonJS, so load a .mjs copy of the SAME file
  const tmp = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'abo-edge-')), 'api-proxy.mjs');
  fs.copyFileSync(path.join(ROOT, 'netlify/edge-functions/api-proxy.js'), tmp);
  const edge = (await import(pathToFileURL(tmp).href)).default;

  const handler = async (req, res) => {
    const url = new URL(req.url, `https://${req.headers.host}`);
    try {
      if (url.pathname.startsWith('/api/')) {
        const hasBody = !['GET', 'HEAD'].includes(req.method);
        const headers = new Headers(); for (const [k, v] of Object.entries(req.headers)) if (!k.startsWith(':')) headers.set(k, Array.isArray(v) ? v.join(', ') : v);
        const request = new Request(url, { method: req.method, headers, body: hasBody ? Readable.toWeb(req) : undefined, duplex: 'half' });
        const ip = String(req.socket.remoteAddress || '').replace(/^::ffff:/, '');
        const r = await edge(request, { ip, requestId: crypto.randomUUID(), deploy: { context: process.env.NETLIFY_CONTEXT || 'production' }, site: { url: `https://${req.headers.host}` } });
        const out = {}; for (const [k, v] of r.headers) if (k !== 'set-cookie') out[k] = v;
        const cookies = r.headers.getSetCookie ? r.headers.getSetCookie() : [];
        if (cookies.length) out['set-cookie'] = cookies;
        res.writeHead(r.status, out);
        if (r.body) Readable.fromWeb(r.body).pipe(res); else res.end();
        return;
      }
      let p = decodeURIComponent(url.pathname); if (p === '/') p = '/index.html';
      let file = path.join(SITE, path.normalize(p));
      // Netlify serves folder/index.html for /folder/ (pretty URLs)
      if (file.startsWith(SITE) && fs.existsSync(file) && fs.statSync(file).isDirectory() && fs.existsSync(path.join(file, 'index.html'))) file = path.join(file, 'index.html');
      if (!file.startsWith(SITE) || !fs.existsSync(file) || fs.statSync(file).isDirectory() || path.basename(file) === '_headers') { res.writeHead(404, { 'content-type': 'text/plain' }); res.end('Not found'); return; }
      const h = { 'content-type': TYPES[path.extname(file)] || 'application/octet-stream' };
      // like Netlify: when several rules match, the same header is JOINED with ", " (not replaced)
      const seen = {};
      for (const rule of rules) if (rule.re.test(url.pathname)) for (const [k, v] of rule.headers) { const lk = k.toLowerCase(); if (seen[lk]) h[seen[lk]] += ', ' + v; else { seen[lk] = k; h[k] = v; } }
      res.writeHead(200, h); fs.createReadStream(file).pipe(res);
    } catch (e) { res.writeHead(500, { 'content-type': 'text/plain' }); res.end('emulator error: ' + e.message); }
  };

  let server;
  if (TLS) {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'abo-tls-'));
    execFileSync('openssl', ['req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-days', '2', '-subj', '/CN=localhost', '-addext', 'subjectAltName=DNS:localhost,IP:127.0.0.1',
      '-keyout', path.join(dir, 'k.pem'), '-out', path.join(dir, 'c.pem')], { stdio: 'ignore' });
    server = https.createServer({ key: fs.readFileSync(path.join(dir, 'k.pem')), cert: fs.readFileSync(path.join(dir, 'c.pem')) }, handler);
  } else server = http.createServer(handler);
  server.listen(PORT, '127.0.0.1', () => console.log(`netlify-local: ${TLS ? 'https' : 'http'}://localhost:${PORT} → site ${path.relative(ROOT, SITE)}, /api/* → edge proxy → ${process.env.API_ORIGIN || '(API_ORIGIN not set)'}`));
}
main().catch((e) => { console.error(e.message); process.exit(1); });
