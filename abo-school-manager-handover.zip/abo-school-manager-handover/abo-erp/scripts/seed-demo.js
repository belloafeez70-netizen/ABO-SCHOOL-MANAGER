#!/usr/bin/env node
'use strict';
// Creates the two DEMO schools (Sunrise Nursery & Primary, Unity College) if they are missing. Safe in production:
// demo accounts have no password, demo data is fictional, and only schools flagged is_demo are ever reset.
// Usage: node scripts/seed-demo.js            (create missing demo schools)
//        node scripts/seed-demo.js --reset    (rebuild both now, if nobody is using them)
const D = require('../server/src/services/demo');
const { pool } = require('../server/src/db/pool');
(async () => {
  if (process.argv.includes('--reset')) { for (const d of D.DEMOS) console.log(d.slug, (await D.resetDemoSchool(d.slug)) ? 'restored' : 'in use — try again later'); }
  const made = await D.ensureDemoSchools();
  console.log(made.length ? `created: ${made.map((m) => m.slug).join(', ')}` : 'demo schools already present');
})().then(() => pool.end()).catch((e) => { console.error(e.message); process.exit(1); });
