// Phase 6 QA: our Code 128 encoder (web/assets/js/core/barcode.js) must give exactly the same bars as the independent JsBarcode library.
// Run: npm i --no-save jsbarcode && cp web/assets/js/core/barcode.js /tmp/barcode.mjs && (edit the import below) && node scripts/qa-barcode-check.mjs
// Result on 9 Oct 2026: 8/8 samples identical.
import { code128Modules, PATTERNS } from './barcode.mjs';
import { createRequire } from 'module'; const require = createRequire(import.meta.url);
const B = require('jsbarcode/bin/barcodes/CODE128/CODE128B.js').default;
let ok = 0, bad = 0;
const samples = ['SA/0001', 'BASIC1-3', 'JSS/2026/001', 'ST001', 'A', 'abc xyz ~!@#$%^&*()_+{}|:"<>?', 'sb/0042', '0123456789'];
for (const s of samples) {
  const theirs = new B(s, {}).encode().data;
  const mine = code128Modules(s);
  if (theirs === mine || theirs === mine + '11') ok++; else { bad++; console.log('DIFF', s, '\n', theirs, '\n', mine); }
}
console.log('pattern widths ok:', PATTERNS.slice(0, 106).every((p) => [...p].reduce((a, b) => a + +b, 0) === 11) && [...PATTERNS[106]].reduce((a, b) => a + +b, 0) === 13);
console.log(`${ok}/${samples.length} match jsbarcode`);
