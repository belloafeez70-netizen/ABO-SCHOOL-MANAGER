'use strict';
// Generates docs/API.md from the live route registry (method, path, auth, permissions, rate limits).
process.env.NODE_ENV = process.env.NODE_ENV || 'development'; process.env.LOG_LEVEL = 'silent';
const fs = require('node:fs'); const path = require('node:path');
const ERROR_TABLE = `## Error codes\n\n| HTTP | code | Meaning / client action |\n|---|---|---|\n` + [
  [400, 'VALIDATION_FAILED', 'Body/query failed the schema; `details.field` names the field.'],
  [400, 'BAD_REQUEST', 'Malformed request (bad JSON, bad URL encoding, unsupported format).'],
  [400, 'BAD_IDEMPOTENCY_KEY', 'Idempotency-Key must be 8–80 chars of letters, digits, _ or -.'],
  [400, 'MFA_INVALID', 'Wrong/expired authenticator or recovery code (during enrolment).'],
  [401, 'UNAUTHENTICATED', 'No/expired session — sign in again.'],
  [401, 'INVALID_CREDENTIALS', 'Generic sign-in failure (never says which part was wrong).'],
  [401, 'MFA_INVALID', 'Wrong authenticator code at sign-in.'],
  [403, 'FORBIDDEN', 'Signed in but lacks the permission / ownership.'],
  [403, 'NO_ACTIVE_MEMBERSHIP', 'Account has no active membership in the selected school.'],
  [403, 'SCHOOL_INACTIVE', 'School is pending or suspended by the platform.'],
  [404, 'NOT_FOUND', 'Unknown id, or an id belonging to another school (deliberately indistinguishable).'],
  [409, 'CONFLICT', 'Duplicate, stale version (reload and retry), or invalid state transition.'],
  [409, 'NOT_CONFIGURED', 'Feature not set up for this school/server yet (e.g. online payments). Not an outage.'],
  [413, 'PAYLOAD_TOO_LARGE / FILE_TOO_LARGE', 'Body or upload over the limit.'],
  [414, 'URI_TOO_LONG', 'A path parameter is longer than any valid id.'],
  [415, 'UNSUPPORTED_MEDIA_TYPE', 'Wrong Content-Type (JSON or multipart only).'],
  [422, 'IDEMPOTENCY_KEY_REUSED', 'Same Idempotency-Key sent with a different body.'],
  [423, 'LOCKED', 'Record is locked (approved/published results, closed exam, locked account).'],
  [429, 'RATE_LIMITED', 'Slow down; respect Retry-After.'],
  [500, 'INTERNAL', 'Unexpected server error — quote the requestId to support.'],
  [502, 'UPSTREAM_UNAVAILABLE', 'A third-party provider (e.g. Paystack) failed; safe to retry later.'],
  [503, 'TIMEOUT', 'Database statement timeout; retry.'],
].map(([h, c, m]) => `| ${h} | \`${c}\` | ${m} |`).join('\n') + '\n\n';
(async () => {
  const app = require('../server/src/app').buildApp({ logger: false }); await app.ready();
  const rows = app.routeList.filter((r) => r.url.startsWith('/api/') && r.method !== 'HEAD').sort((a, b) => a.url.localeCompare(b.url));
  const groups = {};
  for (const r of rows) { const g = r.url.split('/')[3]; (groups[g] ||= []).push(r); }
  let md = `# A.B.O. School Manager — REST API v1\n\nGenerated from the running route registry (\`node scripts/gen-api-doc.js\`). ${rows.length} endpoints.\n\n` +
    `* Base path \`/api/v1\`, JSON only (uploads: multipart/form-data). Every body schema rejects unknown fields.\n* Auth: HttpOnly session cookie + \`X-CSRF-Token\` header on POST/PUT/PATCH/DELETE (token from \`GET /auth/me\`).\n` +
    `* Tenant = the signed-in user's school, resolved on the server. Permission column = user needs ANY of the listed permissions; ownership checks (own class/subject/child) are applied inside handlers.\n* Errors: \`{ "error": { "code", "message", "details?", "requestId" } }\` — never stack traces, SQL or echoed input. Foreign/unknown ids answer a non-revealing 404.\n\n` + ERROR_TABLE;
  for (const [g, list] of Object.entries(groups)) {
    md += `## ${g}\n\n| Method | Path | Auth | Permission (any of) | Rate limit |\n|---|---|---|---|---|\n`;
    for (const r of list) md += `| ${[].concat(r.method).join(', ')} | \`${r.url.replace('/api/v1', '')}\` | ${r.platform ? 'platform admin' : r.auth ? 'session' : r.url.includes('webhook') ? 'HMAC signature' : 'public'} | ${r.perms.length ? r.perms.map((p) => `\`${p}\``).join(' ') : r.auth ? '(any signed-in user; ownership checked)' : '—'} | ${r.rateLimit || 'global'} |\n`;
    md += '\n';
  }
  fs.writeFileSync(path.join(__dirname, '../docs/API.md'), md);
  console.log(`docs/API.md written (${rows.length} endpoints)`);
  await app.close(); await require('../server/src/db/pool').pool.end();
})();
