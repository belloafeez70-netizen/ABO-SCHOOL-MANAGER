#!/usr/bin/env bash
# Builds the separate upload packages for GitHub, Supabase, Netlify (and Render) under /home/user/upload + zips.
set -euo pipefail
ROOT=/home/user; SRC=$ROOT/abo-erp; OUT=$ROOT/upload
rm -rf "$OUT"; mkdir -p "$OUT"/{1-github,2-supabase/server-database,2-supabase/offline-cloud-sync,3-netlify/online-edition,4-render}
# 1 · GitHub: the whole project, without installed packages, build output, local data or secrets
mkdir -p "$OUT/1-github/abo-erp"
tar -C "$SRC" --exclude=./node_modules --exclude=./dist --exclude=./var --exclude=./legacy/qa --exclude=./docs/screenshots --exclude='./.env' -cf - . | tar -C "$OUT/1-github/abo-erp" -xf -
find "$OUT/1-github/abo-erp" -maxdepth 1 -name '.env.*' ! -name '.env.example' -delete
cp "$ROOT/upload-docs/1-github.md" "$OUT/1-github/README_UPLOAD.md"
# 12 Oct 2026: online only — the offline edition is no longer deployed (schools bring its data in with
# Backup & Data › From the Old App, which reads it straight from the same browser on the same web address)
rm -rf "$OUT/1-github/abo-erp/offline-site"
# 2 · Supabase
cp "$ROOT/upload-docs/2-supabase.md" "$OUT/2-supabase/README_UPLOAD.md"
{ echo "-- A.B.O. School Manager — server database, all migrations 001–028 in order (REFERENCE COPY)."
  echo "-- Recommended: run scripts/supabase-db-setup.sh instead (creates the roles, a separate database, the permission list and checks isolation)."
  for f in "$SRC"/server/src/db/migrations/0*.sql; do echo; echo "-- ===== $(basename "$f") ====="; cat "$f"; done
  echo; echo "-- ===== grants.sql ====="; cat "$SRC/server/src/db/grants.sql"; } > "$OUT/2-supabase/server-database/abo_server_schema_reference.sql"
cp "$SRC/scripts/supabase-db-setup.sh" "$OUT/2-supabase/server-database/"
cp "$ROOT/abo_supabase_setup.sql" "$OUT/2-supabase/offline-cloud-sync/"
# 3 · Netlify
cp "$ROOT/upload-docs/3-netlify.md" "$OUT/3-netlify/README_UPLOAD.md"
cp "$SRC/netlify.toml" "$OUT/3-netlify/online-edition/"; mkdir -p "$OUT/3-netlify/online-edition/netlify/edge-functions"; cp "$SRC"/netlify/edge-functions/*.js "$OUT/3-netlify/online-edition/netlify/edge-functions/"
# 4 · Render (the API server — Supabase stores data, Netlify shows pages, Render runs the server in between)
cp "$ROOT/upload-docs/4-render.md" "$OUT/4-render/README_UPLOAD.md"; cp "$SRC/render.supabase.yaml" "$OUT/4-render/"
cp "$ROOT/upload-docs/UPLOAD_GUIDE.md" "$OUT/UPLOAD_GUIDE.md"
cd "$OUT"; for d in 1-github 2-supabase 3-netlify 4-render; do rm -f "$ROOT/upload-$d.zip"; zip -rq "$ROOT/upload-$d.zip" "$d" UPLOAD_GUIDE.md; done
echo "packages in $OUT"; ls -la "$ROOT"/upload-*.zip
