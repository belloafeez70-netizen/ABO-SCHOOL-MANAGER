#!/usr/bin/env bash
# Development only: drop + recreate the local database, migrate, and seed demo schools.
set -euo pipefail
ADMIN_URL=${DATABASE_ADMIN_URL:-postgres://postgres@127.0.0.1:5432/postgres}
cd "$(dirname "$0")/.."
node -e "
const {Client}=require('pg');(async()=>{const c=new Client({connectionString:'$ADMIN_URL'});await c.connect();
await c.query('DROP DATABASE IF EXISTS abo_erp WITH (FORCE)');await c.end();})().catch(e=>{console.error(e.message);process.exit(1)})"
DATABASE_ADMIN_URL=$ADMIN_URL DB_OWNER_PASSWORD=${DB_OWNER_PASSWORD:-abo_owner_dev_password} DB_APP_PASSWORD=${DB_APP_PASSWORD:-abo_app_dev_password} node server/src/db/bootstrap.js
node server/src/db/migrate.js
NODE_ENV=development node server/src/db/seed-dev.js
