#!/usr/bin/env bash
# Sets up the ABO database on Supabase (or any PostgreSQL) and proves school isolation.
#
#   SUPABASE_ADMIN_URL='postgres://postgres.<ref>:<db-password>@aws-0-eu-west-1.pooler.supabase.com:5432/postgres' \
#     bash scripts/supabase-db-setup.sh
#
# What it does (safe to re-run):
#   1. creates two roles: abo_owner (owns the tables, used only for migrations) and abo_app (runtime, NOBYPASSRLS)
#      with long random passwords (or DB_OWNER_PASSWORD / DB_APP_PASSWORD if you set them);
#   2. creates a separate database "abo_erp" — Supabase's public Data API only serves the "postgres" database, so
#      these tables are never reachable with the publishable key;
#   3. runs all migrations (28 as of 12 Oct 2026) (tables, constraints, indexes, Row Level Security, permission catalogue);
#   4. runs scripts/verify-isolation.js against it;
#   5. prints the two connection strings to paste into Render (secret environment variables).
set -euo pipefail
cd "$(dirname "$0")/.."
: "${SUPABASE_ADMIN_URL:?Set SUPABASE_ADMIN_URL (session pooler, port 5432, user postgres.<project-ref>)}"
read -r REF HOST PORT < <(node -e "const u=new URL(process.env.SUPABASE_ADMIN_URL);const p=u.username.split('.');console.log((p[1]||'-')+' '+u.hostname+' '+(u.port||5432))")
SUFFIX=""; [ "$REF" != "-" ] && SUFFIX=".$REF"
gen() { node -e "console.log(require('crypto').randomBytes(24).toString('base64url'))"; }
OWNER_PW="${DB_OWNER_PASSWORD:-$(gen)}"; APP_PW="${DB_APP_PASSWORD:-$(gen)}"
APP_PORT="${APP_PORT:-$([[ "$HOST" == *pooler.supabase.com ]] && echo 6543 || echo "$PORT")}"
export DB_SSL="${DB_SSL:-require}"
echo "1/4 roles + database"
DATABASE_ADMIN_URL="$SUPABASE_ADMIN_URL" DB_NAME=abo_erp DB_OWNER_PASSWORD="$OWNER_PW" DB_APP_PASSWORD="$APP_PW" node server/src/db/bootstrap.js
MIG="postgres://abo_owner${SUFFIX}:${OWNER_PW}@${HOST}:${PORT}/abo_erp"
APP="postgres://abo_app${SUFFIX}:${APP_PW}@${HOST}:${APP_PORT}/abo_erp"
echo "2/4 migrations"
MIGRATION_DATABASE_URL="$MIG" node server/src/db/migrate.js
echo "3/4 isolation check"
MIGRATION_DATABASE_URL="$MIG" DATABASE_URL="$APP" node scripts/verify-isolation.js
if [ "${SEED_DEMO:-yes}" = "yes" ]; then
  echo "3b/4 demo schools (two DEMO schools for visitors; no passwords; set SEED_DEMO=no to skip)"
  NODE_ENV=production DATABASE_URL="$APP" MIGRATION_DATABASE_URL="$MIG" CSRF_SECRET=x$(gen)$(gen) DATA_ENCRYPTION_KEY=$(gen)$(gen) FILE_URL_SECRET=$(gen)$(gen) PUBLIC_ORIGIN=https://example.netlify.app node scripts/seed-demo.js || echo "   (demo seeding skipped: $?) — the API creates them on the first demo visit"
fi
echo "4/4 done. Put these two values in Render → abo-api → Environment (keep them secret):"
echo "   MIGRATION_DATABASE_URL=$MIG"
echo "   DATABASE_URL=$APP"
