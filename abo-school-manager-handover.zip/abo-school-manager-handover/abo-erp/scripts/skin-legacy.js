#!/usr/bin/env node
'use strict';
// Applies (or re-applies) the professional skin to the offline HTML editions. Idempotent: the injected blocks sit
// between markers and are replaced on every run. Usage: node scripts/skin-legacy.js <file.html> [...]
const fs = require('node:fs');
const path = require('node:path');
const css = fs.readFileSync(path.join(__dirname, '../legacy/offline-pro-skin.css'), 'utf8');
const js = fs.readFileSync(path.join(__dirname, '../legacy/offline-pro-skin.js'), 'utf8');
const features = fs.readFileSync(path.join(__dirname, '../legacy/offline-features.js'), 'utf8');
const guard = fs.readFileSync(path.join(__dirname, '../legacy/offline-data-guard.js'), 'utf8');
// Phase 3 security (all editions): XSS-safe text fields, owner password + sealed owner sessions where login is code-only
const secJs = fs.readFileSync(path.join(__dirname, '../legacy/offline-security.js'), 'utf8');
const D0 = '<!-- ABO-DATA-GUARD:JS -->', D1 = '<!-- /ABO-DATA-GUARD:JS -->';
// cloud sync + biometrics (main edition); the Supabase setup script is embedded so it can be copied offline
const sql = fs.readFileSync(path.join(__dirname, '../legacy/supabase/setup.sql'), 'utf8');
const cloud = fs.readFileSync(path.join(__dirname, '../legacy/offline-cloud.js'), 'utf8').replace("/*__SUPABASE_SQL__*/''", () => JSON.stringify(sql).replace(/<\/(script)/gi, '<\\/$1'));
const C0 = '<!-- ABO-CLOUD:JS -->', C1 = '<!-- /ABO-CLOUD:JS -->';
// school web address + simple words (main edition); simple words run last so they rename every page
const siteJs = fs.readFileSync(path.join(__dirname, '../legacy/offline-site.js'), 'utf8');
const plainJs = fs.readFileSync(path.join(__dirname, '../legacy/offline-plain.js'), 'utf8');
const rolesJs = fs.readFileSync(path.join(__dirname, '../legacy/offline-roles.js'), 'utf8');
// cumulative results (results so far this session) — main edition; before simple words so the page is renamed too
const cumJs = fs.readFileSync(path.join(__dirname, '../legacy/offline-cumulative.js'), 'utf8');
// one place for each job (newsletters → announcements, repeated menu entries) + announcement sharing + owner payment settings
const mergeJs = fs.readFileSync(path.join(__dirname, '../legacy/offline-merge.js'), 'utf8');
const W0 = '<!-- ABO-SITE-PLAIN:JS -->', W1 = '<!-- /ABO-SITE-PLAIN:JS -->';
const F0 = '<!-- ABO-FEATURES:JS -->', F1 = '<!-- /ABO-FEATURES:JS -->';
// "This device" (screen layout lock, install app, phone pop-up fixes) — runs in <head>, before the page is drawn
const deviceJs = fs.readFileSync(path.join(__dirname, '../legacy/offline-device.js'), 'utf8');
const V0 = '<!-- ABO-DEVICE:JS -->', V1 = '<!-- /ABO-DEVICE:JS -->';
const S0 = '<!-- ABO-PRO-SKIN:CSS -->', S1 = '<!-- /ABO-PRO-SKIN:CSS -->', J0 = '<!-- ABO-PRO-SKIN:JS -->', J1 = '<!-- /ABO-PRO-SKIN:JS -->';
for (const f of process.argv.slice(2)) {
  let s = fs.readFileSync(f, 'utf8');
  const strip = (a, b) => { const i = s.indexOf(a); const j = s.indexOf(b); if (i >= 0 && j > i) s = s.slice(0, i) + s.slice(j + b.length); };
  strip(S0, S1); strip(J0, J1); strip(F0, F1); strip(D0, D1); strip(C0, C1); strip(W0, W1); strip(V0, V1);
  const head = s.indexOf('</head>');
  if (head < 0 || !/^<\/head>\s*<body/.test(s.slice(head, head + 40))) throw new Error(`${f}: document </head> not found`);
  s = s.slice(0, head) + `${S0}\n<style id="abo-pro-skin">\n${css}</style>\n${S1}\n${V0}\n<script id="abo-device-js">\n${deviceJs}</script>\n${V1}\n` + s.slice(head);
  const body = s.lastIndexOf('</body>');
  // the feature pack needs the module registry of the main edition; it runs before the skin so the menu sees it
  const feat = s.includes('ABO.registry') ? `${F0}\n<script id="abo-features-js">\n${features}</script>\n${F1}\n${C0}\n<script id="abo-cloud-js">\n${cloud}</script>\n${C1}\n${W0}\n<script id="abo-site-js">\n${siteJs}</script>\n<script id="abo-roles-js">\n${rolesJs}</script>\n<script id="abo-cumulative-js">\n${cumJs}</script>\n<script id="abo-merge-js">\n${mergeJs}</script>\n<script id="abo-plain-js">\n${plainJs}</script>\n${W1}\n` : '';
  // the data guard goes into every edition: it stops sign-in from overwriting saved school data
  const dg = `${D0}\n<script id="abo-data-guard-js">\n${guard}</script>\n<script id="abo-security-js">\n${secJs}</script>\n${D1}\n`;
  s = s.slice(0, body) + dg + feat + `${J0}\n<script id="abo-pro-skin-js">\n${js}</script>\n${J1}\n` + s.slice(body);
  fs.writeFileSync(f, s);
  console.log(`skinned ${path.basename(f)} (${(Buffer.byteLength(s) / 1024).toFixed(0)} kB)`);
}
