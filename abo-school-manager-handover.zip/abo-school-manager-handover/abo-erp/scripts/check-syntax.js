'use strict';
// Syntax gate for EVERY JavaScript file (server, scripts, tests, browser modules). Browser files under web/
// are ES modules and are checked as such. Exits non-zero on the first set of failures. Used by CI + `npm run lint`.
const { execFileSync } = require('node:child_process');
const fs = require('node:fs'); const path = require('node:path'); const os = require('node:os');
const root = path.join(__dirname, '..');
const skip = new Set(['node_modules', 'var', '.git', 'coverage', 'dist']);   // dist = generated build output
const files = [];
(function walk(d) { for (const e of fs.readdirSync(d, { withFileTypes: true })) {
  if (skip.has(e.name)) continue; const p = path.join(d, e.name);
  if (e.isDirectory()) walk(p); else if (/\.(c|m)?js$/.test(e.name)) files.push(p);
} })(root);
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'abo-syntax-'));
const failed = [];
for (const f of files) {
  const rel = path.relative(root, f); let target = f;
  if ((rel.startsWith('web' + path.sep) || rel.startsWith('netlify' + path.sep)) && f.endsWith('.js')) { target = path.join(tmp, rel.replace(/[\\/]/g, '_') + '.mjs'); fs.copyFileSync(f, target); }
  try { execFileSync(process.execPath, ['--check', target], { stdio: 'pipe' }); }
  catch (e) { failed.push(`${rel}\n${String(e.stderr).split('\n').slice(0, 5).join('\n')}`); }
}
fs.rmSync(tmp, { recursive: true, force: true });
if (failed.length) { console.error(`Syntax errors in ${failed.length} file(s):\n\n${failed.join('\n\n')}`); process.exit(1); }
console.log(`syntax ok (${files.length} files)`);
