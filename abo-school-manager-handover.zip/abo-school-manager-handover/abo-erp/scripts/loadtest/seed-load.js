'use strict';
// LOAD-TEST data generator (development/staging only). Provisions N schools through the real provisioning code
// (roles, permissions, settings) and bulk-inserts students, staff, user accounts, classes, subjects, assignments,
// invoices and a published CBT per school. All accounts share one precomputed Argon2id hash (hashing thousands of
// passwords individually would only measure the generator).
//   LOAD_SCHOOLS=100 LOAD_STUDENTS=500 LOAD_TEACHERS=20 LOAD_STUDENT_ACCOUNTS=30 node scripts/loadtest/seed-load.js
const crypto = require('node:crypto');
const config = require('../../server/src/config');
if (config.isProdLike) { console.error('refusing to run in staging/production'); process.exit(1); }
const { withTx, pool } = require('../../server/src/db/pool');
const pw = require('../../server/src/security/passwords');
const { createSchool } = require('../../server/src/services/provision');

const START = Number(process.env.LOAD_START || 1);   // resume a big run: LOAD_START=401
const N = Number(process.env.LOAD_SCHOOLS || 100), STUD = Number(process.env.LOAD_STUDENTS || 500), TEACH = Number(process.env.LOAD_TEACHERS || 20), SACC = Number(process.env.LOAD_STUDENT_ACCOUNTS || 30);
const PASSWORD = process.env.LOAD_PASSWORD || 'Load#Test2026';
const SUBJECTS = ['English Language', 'Mathematics', 'Basic Science', 'Social Studies', 'Civic Education', 'Computer Studies', 'Yoruba', 'Agricultural Science'];

(async () => {
  const hash = await pw.hash(PASSWORD); const t0 = Date.now(); let users = 0;
  for (let n = START; n <= N; n++) {
    const sid = crypto.randomUUID();
    await withTx({ schoolId: sid }, async (c) => {
      const roles = await createSchool(c, { id: sid, slug: `load-${n}`, name: `Load Test School ${n}`, schoolType: 'mixed', status: 'active' });
      const sess = (await c.query("INSERT INTO academic_sessions (school_id, name, is_current) VALUES ($1,'2025/2026',true) RETURNING id", [sid])).rows[0].id;
      const term = (await c.query("INSERT INTO terms (school_id, session_id, name, is_current) VALUES ($1,$2,'1ST',true) RETURNING id", [sid, sess])).rows[0].id;
      await c.query("INSERT INTO terms (school_id, session_id, name) VALUES ($1,$2,'2ND'), ($1,$2,'3RD')", [sid, sess]);
      // users: admin, bursar, teachers, student accounts
      const mk = async (login, name, role) => {
        const u = crypto.randomUUID();
        await c.query('INSERT INTO users (id, school_id, login_id, full_name, password_hash, password_changed_at) VALUES ($1,$2,$3,$4,$5, now())', [u, sid, login, name, hash]);
        await c.query("INSERT INTO school_memberships (user_id, school_id, status, is_default) VALUES ($1,$2,'active',true)", [u, sid]);
        await c.query('INSERT INTO user_roles (school_id, user_id, role_id) VALUES ($1,$2,$3)', [sid, u, roles[role]]);
        users++; return u;
      };
      await mk(`l${n}.head`, `Head ${n}`, 'head_of_school');
      await mk(`l${n}.exams`, `Exams ${n}`, 'exam_officer');
      if (process.env.LOAD_BURSAR !== '0') await mk(`l${n}.bursar`, `Bursar ${n}`, 'bursar');
      const teachers = [];
      for (let t = 1; t <= TEACH; t++) {
        const u = await mk(`l${n}.t${t}`, `Teacher ${t} of ${n}`, 'teacher');
        teachers.push((await c.query("INSERT INTO staff (school_id, user_id, full_name, employee_id, is_teacher) VALUES ($1,$2,$3,$4,true) RETURNING id", [sid, u, `Teacher ${t} of ${n}`, `T${t}`])).rows[0].id);
      }
      const classes = (await c.query(`INSERT INTO classes (school_id, name, arm, section, sort_order) SELECT $1, 'JSS ' || g, a, 'secondary', g FROM generate_series(1,3) g, unnest(ARRAY['A','B','C']) a RETURNING id`, [sid])).rows.map((r) => r.id);
      const subjects = (await c.query('INSERT INTO subjects (school_id, name) SELECT $1, unnest($2::text[]) RETURNING id', [sid, SUBJECTS])).rows.map((r) => r.id);
      let k = 0;
      for (const cl of classes) for (const sb of subjects) await c.query('INSERT INTO class_subjects (school_id, class_id, subject_id, teacher_id) VALUES ($1,$2,$3,$4)', [sid, cl, sb, teachers[k++ % teachers.length]]);
      for (const [i, cl] of classes.entries()) await c.query('UPDATE classes SET form_teacher_id = $2 WHERE id = $1', [cl, teachers[i % teachers.length]]);
      await c.query(`INSERT INTO students (school_id, admission_no, first_name, last_name, gender) SELECT $1, 'L' || g, (ARRAY['Ada','Tunde','Chioma','Emeka','Fatima','Musa','Kemi','Segun'])[1 + g % 8],
        (ARRAY['Okafor','Bello','Eze','Adeyemi','Ibrahim','Balogun'])[1 + g % 6] || g, CASE WHEN g % 2 = 0 THEN 'Male' ELSE 'Female' END FROM generate_series(1, $2) g`, [sid, STUD]);
      await c.query(`INSERT INTO student_enrollments (school_id, student_id, class_id, session_id)
        SELECT s.school_id, s.id, ($1::uuid[])[1 + (row_number() OVER (ORDER BY s.id) % 9)::int], $2 FROM students s`, [classes, sess]);
      // pupil portal accounts in bulk (one statement each instead of 3 per pupil — needed for 200,000 users)
      await c.query(`INSERT INTO users (school_id, login_id, full_name, password_hash, password_changed_at)
        SELECT $1, 'l' || $3::text || '.s' || g, 'Student ' || g || ' of ' || $3::text, $4, now() FROM generate_series(1, $2) g`, [sid, SACC, String(n), hash]);
      await c.query(`INSERT INTO school_memberships (user_id, school_id, status, is_default) SELECT u.id, $1, 'active', true FROM users u WHERE u.school_id = $1 AND u.login_id LIKE $2`, [sid, `l${n}.s%`]);
      await c.query(`INSERT INTO user_roles (school_id, user_id, role_id) SELECT $1, u.id, $3 FROM users u WHERE u.school_id = $1 AND u.login_id LIKE $2`, [sid, `l${n}.s%`, roles.student]);
      await c.query(`WITH acc AS (SELECT s.id AS student_id, row_number() OVER (ORDER BY s.admission_no) AS i FROM students s ORDER BY s.admission_no LIMIT $2)
        UPDATE students st SET user_id = u.id FROM acc JOIN users u ON u.school_id = $1 AND u.login_id = 'l' || $3::text || '.s' || acc.i WHERE st.id = acc.student_id`, [sid, SACC, String(n)]);
      users += SACC;
      // fees + invoices
      const cat = (await c.query("SELECT id FROM fee_categories WHERE code = 'tuition'")).rows[0].id;
      const fs = (await c.query("INSERT INTO fee_structures (school_id, name, category_id, amount_kobo, term_id) VALUES ($1,'Tuition',$2,8500000,$3) RETURNING id", [sid, cat, term])).rows[0].id;
      await c.query(`INSERT INTO invoices (school_id, invoice_no, student_id, term_id, subtotal_kobo, discount_kobo, total_kobo, status)
        SELECT $1, 'INV-L-' || row_number() OVER (), id, $2, 8500000, 0, 8500000, 'unpaid' FROM students`, [sid, term]);
      await c.query("INSERT INTO invoice_items (school_id, invoice_id, fee_structure_id, description, amount_kobo) SELECT $1, id, $2, 'Tuition', 8500000 FROM invoices", [sid, fs]);
      // published CBT (10 MCQs) for every class
      const ex = (await c.query("INSERT INTO cbt_exams (school_id, title, duration_minutes, status, max_attempts) VALUES ($1,'Load CBT',30,'published',20) RETURNING id", [sid])).rows[0].id;
      for (let q = 1; q <= 10; q++) {
        const qid = (await c.query("INSERT INTO cbt_questions (school_id, exam_id, type, text, position) VALUES ($1,$2,'mcq',$3,$4) RETURNING id", [sid, ex, `Question ${q}: ${q} + ${q} = ?`, q])).rows[0].id;
        await c.query('INSERT INTO cbt_options (school_id, question_id, text, is_correct, position) VALUES ($1,$2,$3,true,0), ($1,$2,$4,false,1), ($1,$2,$5,false,2)', [sid, qid, String(2 * q), String(2 * q + 1), String(2 * q - 1)]);
      }
    });
    if (n % 10 === 0 || n === N) process.stdout.write(`  ${n}/${N} schools, ${users} users (${Math.round((Date.now() - t0) / 1000)}s)\n`);
  }
  await withTx({ platform: true }, (c) => c.query('ANALYZE'));
  console.log(`load data ready: ${N} schools · ${N * STUD} students · ${users} user accounts (password ${PASSWORD})`);
  await pool.end();
})().catch((e) => { console.error(e); process.exit(1); });
