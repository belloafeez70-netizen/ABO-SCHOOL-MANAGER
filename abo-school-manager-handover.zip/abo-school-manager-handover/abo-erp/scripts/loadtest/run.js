'use strict';
// Load test driver (run against a dev/staging server started with TRUST_PROXY=loopback so each virtual user can
// present its own client IP via X-Forwarded-For, like real users behind distinct networks).
//   Phase 1: concurrent logins (Argon2id-bound)
//   Phase 2: mixed workload for DURATION seconds —
//     teachers: open & save full score sheets (simultaneous result entry, optimistic locking)
//     heads:    student search / paging, broadsheet generation (report), dashboards
//     students: CBT start → 10 answers → submit; fee/invoice queries
// Env: BASE_URL, LOGIN_CONCURRENCY, SCHOOLS, TEACHERS_PER_SCHOOL, STUDENTS_PER_SCHOOL, DURATION
const BASE = process.env.BASE_URL || 'http://127.0.0.1:8080';
const PW = process.env.LOAD_PASSWORD || 'Load#Test2026';
const SCHOOLS = Number(process.env.SCHOOLS || 100), TPS = Number(process.env.TEACHERS_PER_SCHOOL || 4), SPS = Number(process.env.STUDENTS_PER_SCHOOL || 3);
const DURATION = Number(process.env.DURATION || 60), LOGIN_C = Number(process.env.LOGIN_CONCURRENCY || 40);
const STEP = Number(process.env.SCHOOL_STEP || 1);   // spread the active users over many schools: SCHOOLS=200 SCHOOL_STEP=5 → schools 1, 6, 11 … 996
const stats = new Map();
function rec(op, ms, status) {
  let s = stats.get(op); if (!s) { s = { lat: [], codes: {} }; stats.set(op, s); }
  s.lat.push(ms); s.codes[status] = (s.codes[status] || 0) + 1;
}
let ipN = 0; const nextIp = () => { ipN++; return `10.${(ipN >> 16) & 255}.${(ipN >> 8) & 255}.${ipN & 255}`; };
async function call(u, op, method, path, body, headers = {}) {
  const t = performance.now();
  const r = await fetch(BASE + '/api/v1' + path, { method, headers: { cookie: u.cookie || '', 'x-forwarded-for': u.ip, ...(method !== 'GET' ? { 'x-csrf-token': u.csrf, 'content-type': 'application/json' } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined });
  const txt = await r.text(); rec(op, performance.now() - t, r.status);
  // like the web app: a "busy" answer (503 + Retry-After) means wait before the next request
  if (r.status === 503) await new Promise((res) => setTimeout(res, Math.min(5, Number(r.headers.get('retry-after')) || 2) * 1000 * (0.75 + Math.random() * 0.5)));
  let j = null; try { j = JSON.parse(txt); } catch { /* */ }
  return { status: r.status, body: j };
}
async function login(loginId) {
  const u = { loginId, ip: nextIp() };
  const t = performance.now();
  const r = await fetch(BASE + '/api/v1/auth/login', { method: 'POST', headers: { 'content-type': 'application/json', origin: BASE, 'x-forwarded-for': u.ip }, body: JSON.stringify({ loginId, password: PW }) });
  const j = await r.json(); rec('auth.login', performance.now() - t, r.status);
  if (r.status !== 200) return null;
  u.cookie = r.headers.get('set-cookie').split(';')[0]; u.csrf = j.csrf; return u;
}
async function pool(items, c, fn) { let i = 0; await Promise.all(Array.from({ length: c }, async () => { while (i < items.length) { const x = items[i++]; await fn(x); } })); }
const pick = (a) => a[Math.floor(Math.random() * a.length)];
const pct = (a, p) => (a.length ? a[Math.min(a.length - 1, Math.floor(a.length * p))].toFixed(1) : '-');

(async () => {
  const ids = [];
  for (let k = 0, n = 1; k < SCHOOLS; k++, n = 1 + k * STEP) {
    ids.push({ id: `l${n}.head`, kind: 'head' });
    for (let t = 1; t <= TPS; t++) ids.push({ id: `l${n}.t${t}`, kind: 'teacher' });
    for (let s = 1; s <= SPS; s++) ids.push({ id: `l${n}.s${s}`, kind: 'student' });
  }
  console.log(`Phase 1: ${ids.length} concurrent logins (concurrency ${LOGIN_C})`);
  const users = []; const t1 = Date.now();
  await pool(ids, LOGIN_C, async (x) => { const u = await login(x.id); if (u) users.push({ ...u, kind: x.kind }); });
  const loginSecs = (Date.now() - t1) / 1000;
  console.log(`  ${users.length}/${ids.length} signed in in ${loginSecs.toFixed(1)}s (${(users.length / loginSecs).toFixed(1)} logins/s)`);

  // prepare per-user context
  await pool(users, 40, async (u) => {
    if (u.kind === 'head') { const a = await call(u, 'academic.overview', 'GET', '/academic'); u.term = a.body.sessions[0].terms.find((t) => t.is_current).id; u.classes = a.body.classes.map((c) => c.id); }
    if (u.kind === 'teacher') {
      const d = await call(u, 'dashboard', 'GET', '/dashboard'); u.term = d.body.term.id; u.subjects = d.body.mySubjects || [];
    }
  });
  console.log(`Phase 2: mixed workload for ${DURATION}s — ${users.filter((u) => u.kind === 'teacher').length} teachers, ${users.filter((u) => u.kind === 'head').length} heads, ${users.filter((u) => u.kind === 'student').length} students`);
  const stopAt = Date.now() + DURATION * 1000; const think = () => new Promise((r) => setTimeout(r, 200 + Math.random() * 600));
  const loops = {
    async teacher(u) {
      while (Date.now() < stopAt) {
        const s = pick(u.subjects); if (!s) return;
        const sh = await call(u, 'results.sheet_open', 'POST', '/results/sheets', { termId: u.term, classId: s.class_id, subjectId: s.subject_id });
        if (sh.status !== 200) { await think(); continue; }
        const d = await call(u, 'results.sheet_get', 'GET', `/results/sheets/${sh.body.id}`);
        if (!d.body || !d.body.canEdit) { await think(); continue; }
        const entries = d.body.rows.map((r) => ({ studentId: r.studentId, scores: { ca1: Math.floor(Math.random() * 21), ca2: Math.floor(Math.random() * 21), exam: Math.floor(Math.random() * 61) } }));
        await call(u, 'results.scores_save', 'PUT', `/results/sheets/${sh.body.id}/scores`, { entries, expectedVersion: d.body.sheet.version });
        await call(u, 'dashboard', 'GET', '/dashboard');
        await call(u, 'materials.list', 'GET', '/materials');
        await call(u, 'clock.me', 'GET', '/clock/me');
        await think();
      }
    },
    async head(u) {
      const names = ['okafor', 'bello', 'eze', 'ada', 'tunde', 'kemi', 'L12', 'musa'];
      while (Date.now() < stopAt) {
        await call(u, 'students.search', 'GET', `/students?q=${pick(names)}&pageSize=25`);
        await call(u, 'students.page', 'GET', `/students?page=${1 + Math.floor(Math.random() * 20)}&pageSize=25&sort=name`);
        await call(u, 'results.broadsheet', 'GET', `/results/broadsheet?termId=${u.term}&classId=${pick(u.classes)}`);
        await call(u, 'dashboard', 'GET', '/dashboard');
        await call(u, 'monitor.now', 'GET', '/monitor/now');
        await call(u, 'clock.register', 'GET', '/clock/register');
        await think();
      }
    },
    async student(u) {
      while (Date.now() < stopAt) {
        const av = await call(u, 'cbt.available', 'GET', '/cbt/available');
        const ex = av.body && av.body.items && av.body.items[0];
        if (ex && ex.attempts_used < ex.max_attempts) {
          const p = await call(u, 'cbt.start', 'POST', `/cbt/exams/${ex.id}/start`, {});
          if (p.status === 200) {
            for (const q of p.body.questions) await call(u, 'cbt.answer', 'PUT', `/cbt/attempts/${p.body.attemptId}/answers`, { answers: [{ questionId: q.id, optionId: pick(q.options).id }] });
            await call(u, 'cbt.submit', 'POST', `/cbt/attempts/${p.body.attemptId}/submit`, {});
          }
        }
        await call(u, 'calendar', 'GET', '/calendar');
        await call(u, 'materials.mine', 'GET', '/materials');
        const f = await call(u, 'fees.my', 'GET', '/fees/my');
        if (f.body && f.body.items && f.body.items[0]) await call(u, 'fees.invoice', 'GET', `/fees/invoices/${f.body.items[0].id}`);
        await think();
      }
    },
  };
  const t2 = Date.now();
  await Promise.all(users.map((u) => loops[u.kind](u)));
  const secs = (Date.now() - t2) / 1000;
  let total = 0, e5 = 0; const rows = [];
  for (const [op, s] of [...stats].sort()) {
    s.lat.sort((a, b) => a - b); total += s.lat.length;
    const five = Object.entries(s.codes).filter(([c]) => Number(c) >= 500).reduce((a, [, n]) => a + n, 0); e5 += five;
    rows.push({ op, n: s.lat.length, p50: pct(s.lat, 0.5), p95: pct(s.lat, 0.95), p99: pct(s.lat, 0.99), codes: s.codes });
  }
  console.log('\n| operation | requests | p50 ms | p95 ms | p99 ms | status codes |\n|---|---|---|---|---|---|');
  for (const r of rows) console.log(`| ${r.op} | ${r.n} | ${r.p50} | ${r.p95} | ${r.p99} | ${Object.entries(r.codes).map(([c, n]) => `${c}×${n}`).join(' ')} |`);
  console.log(`\nTOTAL ${total} requests · phase-2 throughput ${Math.round((total - (stats.get('auth.login') || { lat: [] }).lat.length) / secs)} req/s · 5xx = ${e5}`);
  console.log(JSON.stringify({ users: users.length, loginSecs, phase2Secs: secs, total, e5 }));
})().catch((e) => { console.error(e); process.exit(1); });
