#!/usr/bin/env node
'use strict';
// Go-live preflight: checks the production environment BEFORE the school is switched over.
// Usage (on the server, with the production .env loaded):   npm run preflight   [--env-file .env]
// Exit code 1 if any FAIL. It never prints secret values.
const fs = require('node:fs');
const path = require('node:path');

const envArg = process.argv.indexOf('--env-file');
if (envArg > 0) {
  for (const line of fs.readFileSync(process.argv[envArg + 1], 'utf8').split(/\r?\n/)) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/.exec(line); if (!m || line.trim().startsWith('#')) continue;
    if (process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^['"]|['"]$/g, '');
  }
}
const rows = [];
const add = (level, check, detail = '') => rows.push({ level, check, detail });
const pass = (c, d) => add('PASS', c, d); const warn = (c, d) => add('WARN', c, d); const fail = (c, d) => add('FAIL', c, d);

(async () => {
  const env = process.env.NODE_ENV;
  if (env === 'production') pass('NODE_ENV', 'production'); else fail('NODE_ENV', `is "${env || 'unset'}" — must be production`);
  let config;
  try { config = require('../server/src/config'); pass('Secrets & config', 'CSRF / data-encryption / file-URL secrets present and strong'); }
  catch (e) { fail('Secrets & config', e.message); }
  if (config) {
    const origin = config.publicOrigin;
    if (/^https:\/\//.test(origin) && !/localhost|127\.0\.0\.1|example/.test(origin)) pass('PUBLIC_ORIGIN', origin); else fail('PUBLIC_ORIGIN', `${origin} — must be your real https:// address`);
    if (/\.netlify\.app$/.test(new URL(origin).hostname)) pass('Domain', `Netlify address in use — to move to your own domain later just change PUBLIC_ORIGIN (and add the old one to ALLOWED_ORIGINS while switching)`);
    if (!config.serveFrontend) {
      if (config.proxy.require && config.proxy.sharedSecret) pass('Netlify split (web on Netlify, API separate)', 'SERVE_FRONTEND=false, REQUIRE_PROXY_SECRET=true, shared secret set');
      else fail('Netlify split (web on Netlify, API separate)', 'set PROXY_SHARED_SECRET (same value in Netlify) and REQUIRE_PROXY_SECRET=true so the API cannot be called directly');
    } else warn('Netlify split (web on Netlify, API separate)', 'SERVE_FRONTEND is on — single-host mode. For Netlify set SERVE_FRONTEND=false');
    if (config.monitoring.errorWebhookUrl) pass('Error alerts', `webhook configured (${config.monitoring.errorWebhookFormat})`); else warn('Error alerts', 'ERROR_WEBHOOK_URL not set — 5xx errors, crashes and failed jobs are only in the logs');
    if (config.cookie.secure) pass('Secure cookies', 'on'); else fail('Secure cookies', 'COOKIE_SECURE must be on in production');
    if (config.db.ssl !== 'off') pass('Database TLS', config.db.ssl); else fail('Database TLS', 'DB_SSL=off — use require (+ DB_SSL_CA)');
    if (config.storage.driver === 's3' && config.storage.s3.bucket) pass('File storage', `S3-compatible bucket "${config.storage.s3.bucket}"`);
    else warn('File storage', 'local disk — fine for ONE server with backups of var/storage; use S3/R2 for more than one server');
    if (config.mail.smtpUrl) pass('E-mail (SMTP)', 'configured'); else fail('E-mail (SMTP)', 'SMTP_URL missing — password resets, verification and receipts will not be delivered');
    if (/example\.com/.test(config.mail.from)) warn('MAIL_FROM', 'still uses example.com'); else pass('MAIL_FROM', config.mail.from.replace(/<.*>/, '').trim() || 'set');
    if (config.rateLimit.redisUrl) {
      try {
        const R = require('ioredis'); const r = new R(config.rateLimit.redisUrl, { lazyConnect: true, connectTimeout: 5000, maxRetriesPerRequest: 1 });
        await r.connect(); await r.ping(); r.disconnect(); pass('Shared rate limits (Redis)', 'reachable');
      } catch (e) { fail('Shared rate limits (Redis)', `RATE_LIMIT_REDIS_URL set but not reachable: ${e.message}`); }
    } else warn('Shared rate limits (Redis)', 'not set — OK for a single API instance only');
    const pk = config.payments.paystackSecret || '';
    if (/^sk_live_/.test(pk)) pass('Paystack', 'live key'); else if (/^sk_test_/.test(pk)) warn('Paystack', 'TEST key — parents cannot pay real money yet'); else warn('Paystack', 'not configured — online fee payment disabled (manual receipts still work)');
    if (config.storage.clamav.host) pass('Malware scanning', 'ClamAV configured'); else warn('Malware scanning', 'CLAMAV_HOST not set — uploads are type-checked but not virus-scanned');
    if (config.metricsToken && config.metricsToken.length >= 24) pass('Metrics token', 'set'); else warn('Metrics token', 'METRICS_TOKEN missing/short — /metrics disabled');
    if (config.schoolApproval === 'manual') pass('School approval', 'manual (new schools wait for platform approval)'); else warn('School approval', 'auto — anyone can open a school');
    // database checks
    const { Client } = require('pg');
    const c = new Client({ connectionString: config.db.url, ssl: config.db.ssl === 'off' ? false : { rejectUnauthorized: config.db.ssl !== 'no-verify', ca: config.db.sslCa } });
    try {
      await c.connect();
      pass('Database connection', 'runtime role connects');
      const r = (await c.query("SELECT rolbypassrls, rolsuper FROM pg_roles WHERE rolname = current_user")).rows[0];
      const owns = (await c.query("SELECT count(*)::int AS n FROM pg_tables WHERE schemaname = 'public' AND tableowner = current_user")).rows[0].n;
      if (r && !r.rolbypassrls && !r.rolsuper && owns === 0) pass('Row-level security', 'runtime role cannot bypass RLS and owns no tables');
      else fail('Row-level security', owns ? `DATABASE_URL uses the table OWNER (owners bypass RLS) — use the abo_app role; keep the owner only in MIGRATION_DATABASE_URL` : 'runtime DB role is superuser or BYPASSRLS — tenant isolation would not be enforced');
      const files = fs.readdirSync(path.join(__dirname, '../server/src/db/migrations')).filter((f) => /^\d{3}_.+\.sql$/.test(f)).length;
      const applied = (await c.query('SELECT count(*)::int AS n FROM schema_migrations')).rows[0].n;
      if (applied === files) pass('Migrations', `${applied}/${files} applied`); else fail('Migrations', `${applied}/${files} applied — run npm run migrate`);
      const admins = (await c.query('SELECT app.platform_admin_count() AS n')).rows[0].n;
      if (admins > 0) pass('Platform admin', `${admins} account(s)`); else fail('Platform admin', 'none — run scripts/create-platform-admin.js');
      const demo = (await c.query("SELECT app.login_id_taken('bopc.owner') AS t")).rows[0].t;
      if (demo) fail('Demo data', 'demo accounts exist in this database — never seed demo data in production'); else pass('Demo data', 'none');
    } catch (e) { fail('Database connection', e.message); } finally { await c.end().catch(() => {}); }
  }
  warn('Backups (manual check)', 'confirm automated daily backups + point-in-time recovery on the DB provider, and run npm run restore:drill once');
  warn('Domain & HTTPS (manual check)', 'DNS → Cloudflare/HTTPS proxy, origin firewalled, HSTS on (see docs/DEPLOYMENT.md §4)');

  const w = Math.max(...rows.map((r) => r.check.length));
  for (const r of rows) console.log(`${r.level === 'PASS' ? '✔' : r.level === 'WARN' ? '!' : '✖'} ${r.level.padEnd(4)}  ${r.check.padEnd(w)}  ${r.detail}`);
  const f = rows.filter((r) => r.level === 'FAIL').length; const wn = rows.filter((r) => r.level === 'WARN').length;
  console.log(`\n${rows.length - f - wn} pass · ${wn} warning(s) · ${f} failure(s) — ${f ? 'NOT ready to go live' : 'ready to go live (review warnings)'}`);
  process.exit(f ? 1 : 0);
})();
