#!/usr/bin/env node
'use strict';
// Core fixes inside the offline HTML editions (idempotent; run before skin-legacy.js):
//  1. The owner's login code is no longer written in the file. Only a salted, iterated SHA-256 hash is kept; the code
//     becomes known to the page only after the owner types it (then the owner password set on that device is asked).
//  2. The "Early Access" countdown for schools that have not paid: 5 minutes by default (owner sets 1–5 in Payment
//     Settings), shown as m:ss with a warning at 1 minute — instead of 30 seconds.
//  3. Visible copy: Newsletters → Announcements (newsletters were merged into announcements).
// Usage: OWNER_CODE='…' node scripts/patch-offline-core.js <file.html> [...]   (OWNER_CODE only needed the first time)
const fs = require('node:fs');
const crypto = require('node:crypto');
const ITER = 2000; const SALT = 'abo-owner-v1:';
const sha = (s) => crypto.createHash('sha256').update(s, 'utf8').digest('hex');
const hashOf = (code) => { let h = sha(SALT + code); for (let i = 1; i < ITER; i++) h = sha(h + ':' + code); return h; };
// compact synchronous SHA-256 (the login check must be synchronous in the old code)
const SHA_JS = `function aboSha256(m){function r(n,x){return(x>>>n)|(x<<(32-n));}var K=[1116352408,1899447441,3049323471,3921009573,961987163,1508970993,2453635748,2870763221,3624381080,310598401,607225278,1426881987,1925078388,2162078206,2614888103,3248222580,3835390401,4022224774,264347078,604807628,770255983,1249150122,1555081692,1996064986,2554220882,2821834349,2952996808,3210313671,3336571891,3584528711,113926993,338241895,666307205,773529912,1294757372,1396182291,1695183700,1986661051,2177026350,2456956037,2730485921,2820302411,3259730800,3345764771,3516065817,3600352804,4094571909,275423344,430227734,506948616,659060556,883997877,958139571,1322822218,1537002063,1747873779,1955562222,2024104815,2227730452,2361852424,2428436474,2756734187,3204031479,3329325298];var H=[1779033703,3144134277,1013904242,2773480762,1359893119,2600822924,528734635,1541459225];var b=unescape(encodeURIComponent(m)),l=b.length,w=[],i,j;for(i=0;i<l;i++)w[i>>2]|=b.charCodeAt(i)<<(24-(i%4)*8);w[l>>2]|=0x80<<(24-(l%4)*8);w[((l+8>>6)<<4)+15]=l*8;for(i=0;i<w.length;i+=16){var a=H.slice(0),W=[];for(j=0;j<64;j++){if(j<16)W[j]=w[i+j]|0;else{var s0=r(7,W[j-15])^r(18,W[j-15])^(W[j-15]>>>3),s1=r(17,W[j-2])^r(19,W[j-2])^(W[j-2]>>>10);W[j]=(W[j-16]+s0+W[j-7]+s1)|0;}var S1=r(6,a[4])^r(11,a[4])^r(25,a[4]),ch=(a[4]&a[5])^(~a[4]&a[6]),t1=(a[7]+S1+ch+K[j]+W[j])|0,S0=r(2,a[0])^r(13,a[0])^r(22,a[0]),mj=(a[0]&a[1])^(a[0]&a[2])^(a[1]&a[2]),t2=(S0+mj)|0;a=[(t1+t2)|0,a[0],a[1],a[2],(a[3]+t1)|0,a[4],a[5],a[6]];}for(j=0;j<8;j++)H[j]=(H[j]+a[j])|0;}var o='';for(i=0;i<8;i++)o+=('00000000'+(H[i]>>>0).toString(16)).slice(-8);return o;}`;
const path = require('node:path');
const VENDOR = JSON.parse(fs.readFileSync(path.join(__dirname, '../legacy/vendor/manifest.json'), 'utf8'));
const KEY = { 'html2canvas.min.js': ['html2canvas', '!!window.html2canvas'], 'jspdf.umd.min.js': ['jspdf', '!!window.jspdf'], 'html-docx.js': ['htmlDocx', '!!window.htmlDocx'],
  'firebase-app-compat.js': ['firebaseApp', '!!window.firebase'], 'firebase-database-compat.js': ['firebaseDb', '!!(window.firebase && window.firebase.database)'],
  'mammoth.browser.min.js': ['mammoth', '!!window.mammoth'], 'pdf.min.js': ['pdfjs', '!!window.pdfjsLib'], 'jszip.min.js': ['jszip', '!!window.JSZip'] };
const WRAP = [['exportCBTScoresToPDF', ['html2canvas', 'jspdf']], ['exportCBTScoresToImage', ['html2canvas']], ['exportElementAsImage', ['html2canvas']], ['exportElementAsPDF', ['html2canvas', 'jspdf']],
  ['exportElementAsDOCX', ['htmlDocx']], ['startCloudSync', ['firebaseApp', 'firebaseDb']], ['importNewsletterDocument', ['mammoth', 'pdfjs', 'jszip']]];
function libsLoader(s) {
  const L0 = '<!-- ABO-LIBS -->', L1 = '<!-- /ABO-LIBS -->';
  const libs = {};
  for (const [url, v] of Object.entries(VENDOR)) {
    const k = KEY[url.split('/').pop()]; if (!k) continue;
    libs[k[0]] = { test: k[1], local: 'vendor/' + v.file, cdn: url, sri: v.sri, deps: k[0] === 'firebaseDb' ? ['firebaseApp'] : [] };
    // remove the blocking <script src> tag for this library (with or without SRI attributes)
    s = s.replace(new RegExp('<script[^>]*src="' + url.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '"[^>]*>\\s*</script>\\n?'), '');
  }
  if (!Object.keys(libs).length) return s;
  const entries = Object.entries(libs).map(([k, v]) => `${JSON.stringify(k)}:{t:function(){return ${v.test};},l:${JSON.stringify(v.local)},c:${JSON.stringify(v.cdn)},i:${JSON.stringify(v.sri)},d:${JSON.stringify(v.deps)}}`).join(',');
  const loader = `${L0}
<script id="abo-libs">
/* Export / import libraries (PDF, picture, Word, Office import, legacy Firebase) load ONLY when needed — first load is
   about 2.2 MB lighter on slow phones. Same files and SRI hashes as before: this site's own copy (vendor/) first, then
   the CDN (for the file opened from the phone's storage). When the phone is idle on a good connection they are fetched
   in the background so exports also work offline. */
window.ABO_LIBS = (function () {
  var L = {${entries}};
  var busy = {};
  function add(src, sri) { return new Promise(function (ok, no) { var s = document.createElement('script'); s.src = src; if (sri) { s.integrity = sri; s.crossOrigin = 'anonymous'; } s.onload = function () { ok(); }; s.onerror = function () { s.remove(); no(new Error('load failed')); }; document.head.appendChild(s); }); }
  function load(k) {
    var x = L[k]; if (!x) return Promise.reject(new Error('Unknown library ' + k));
    if (x.t()) return Promise.resolve(); if (busy[k]) return busy[k];
    busy[k] = Promise.all((x.d || []).map(load)).then(function () {
      // this site's own copy only on a real web address; a sandboxed preview frame has origin "null" (CORS blocks SRI loads)
      var local = (location.protocol === 'https:' || location.protocol === 'http:') && String(self.origin) !== 'null';
      return (local ? add(x.l, x.i).catch(function () { return add(x.c, x.i); }) : add(x.c, x.i));
    }).catch(function () { delete busy[k]; throw new Error('This export needs a one-time download. Connect to the internet and try again.'); });
    return busy[k];
  }
  function need(keys) { return Promise.all([].concat(keys).map(load)); }
  function warm() {
    var c = navigator.connection || {}; if (c.saveData || /(^|-)2g$/.test(c.effectiveType || '')) return;   // respect data saver / 2G
    if (!(location.protocol === 'https:' || location.protocol === 'http:') || String(self.origin) === 'null') return;
    var order = ['html2canvas', 'jspdf', 'htmlDocx']; var i = 0;
    (function next() { if (i >= order.length) return; var k = order[i++]; load(k).then(next, next); })();
  }
  window.addEventListener('load', function () { (window.requestIdleCallback || function (f) { setTimeout(f, 4000); })(warm, { timeout: 15000 }); });
  return { need: need, load: load, list: function () { return Object.keys(L); } };
}());
</script>
${L1}`;
  // already there (earlier build): replace it in place, so loader fixes reach files that were patched before
  const i0 = s.indexOf(L0), i1 = s.indexOf(L1);
  if (i0 >= 0 && i1 > i0) return s.slice(0, i0) + loader + s.slice(i1 + L1.length);
  const at = s.indexOf('<!-- Export helpers');
  return at >= 0 ? s.slice(0, at) + loader + '\n' + s.slice(at) : s.replace('</head>', loader + '\n</head>');
}
function wrapEntries(s) {
  const W0 = '<!-- ABO-LIBS-WRAP -->', W1 = '<!-- /ABO-LIBS-WRAP -->';
  const i = s.indexOf(W0), j = s.indexOf(W1); if (i >= 0 && j > i) { let e = j + W1.length; if (s[e] === '\n') e++; s = s.slice(0, i) + s.slice(e); }   // block + its own line end
  const code = `${W0}
<script id="abo-libs-wrap">
/* the export / import functions wait for their library first (they already return promises or nothing) */
(function () {
  if (!window.ABO_LIBS) return;
  ${JSON.stringify(WRAP)}.forEach(function (w) {
    var name = w[0], keys = w[1], orig = window[name]; if (typeof orig !== 'function' || orig.__libs) return;
    var f = function () { var self = this, args = arguments; return window.ABO_LIBS.need(keys).then(function () { return orig.apply(self, args); }, function (e) { try { window.showToast ? window.showToast(e.message) : alert(e.message); } catch (x) { /* */ } }); };
    f.__libs = true; window[name] = f;
  });
}());
</script>
${W1}
`;
  const b = s.lastIndexOf('</body>'); return s.slice(0, b) + code + s.slice(b);
}
function globalsAccessor(s) {
  const G0 = '<!-- ABO-GLOBALS -->', G1 = '<!-- /ABO-GLOBALS -->';
  const i = s.indexOf(G0), j = s.indexOf(G1); if (i >= 0 && j > i) { let a = i, e = j + G1.length; if (s[a - 1] === '\n') a--; if (s[e] === '\n') e++; s = s.slice(0, a) + s.slice(e); }   // block + the line ends added with it
  const names = [...new Set([...s.matchAll(/^(let|var|const) ([A-Za-z_$][\w$]*)/gm)].map((m) => m[2]))].filter((n) => !/^__/.test(n));
  const consts = new Set([...s.matchAll(/^const ([A-Za-z_$][\w$]*)/gm)].map((m) => m[1]));
  const get = names.map((n) => `case '${n}': return typeof ${n} !== 'undefined' ? ${n} : undefined;`).join(' ');
  const set = names.filter((n) => !consts.has(n)).map((n) => `case '${n}': ${n} = v; return true;`).join(' ');
  const code = `${G0}
<script id="abo-globals">
/* Read / write the app's global variables by name WITHOUT eval or new Function (so the site's Content-Security-Policy
   can forbid 'unsafe-eval'). Generated from the page's own top-level declarations. */
function aboGlobalGet(n) { try { switch (n) { ${get} default: return window[n]; } } catch (e) { return undefined; } }
function aboGlobalSet(n, v) { try { switch (n) { ${set} default: window[n] = v; return true; } } catch (e) { return false; } }
aboGlobalGet.known = ${JSON.stringify(Object.fromEntries(names.map((n) => [n, 1])))};
window.aboGlobalGet = aboGlobalGet; window.aboGlobalSet = aboGlobalSet;
</script>
${G1}
`;
  s = s.replace(`fn = new Function('try{ return typeof ' + name + ' !== "undefined" ? ' + name + ' : undefined; }catch(e){ return undefined; }');`,
    `fn = window.aboGlobalGet ? function () { return window.aboGlobalGet(name); } : new Function('try{ return typeof ' + name + ' !== "undefined" ? ' + name + ' : undefined; }catch(e){ return undefined; }');`);
  s = s.replace("fn = (window.aboGlobalGet && window.aboGlobalGet.known[name]) ? function () { return window.aboGlobalGet(name); } :", 'fn = window.aboGlobalGet ? function () { return window.aboGlobalGet(name); } :');
  s = s.replace('if (window.aboGlobalSet && window.aboGlobalGet.known[name]) return window.aboGlobalSet(name, value);', 'if (window.aboGlobalSet) return window.aboGlobalSet(name, value);');
  if (!s.includes('if (window.aboGlobalSet) return window.aboGlobalSet(name, value);')) s = s.replace(`return new Function('v', name + ' = v; return true;')(value);`, `if (window.aboGlobalSet) return window.aboGlobalSet(name, value);\n      return new Function('v', name + ' = v; return true;')(value);`);
  const h = s.indexOf('<meta name="viewport"'); const he = s.indexOf('>', h) + 1;
  return s.slice(0, he) + '\n' + code + s.slice(he);
}
for (const f of process.argv.slice(2)) {
  let s = fs.readFileSync(f, 'utf8'); const before = s;
  // 1. owner login code → hash
  const m = /const OWNER_LOGIN_ID = '([^']+)';/.exec(s);
  if (m) {
    const code = process.env.OWNER_CODE || m[1];
    s = s.replace(m[0], `/* 11 Oct 2026: the owner's login code is not stored in this file — only a salted, iterated hash of it. */
const OWNER_CODE_HASH = '${hashOf(code)}';
let OWNER_LOGIN_ID = null;            // known only after the owner typed the right code on this device
${SHA_JS}
var __aboOwnerChecks = {};
function isOwnerCode(v) { v = String(v || ''); if (!v || v.length > 64) return false; if (Object.prototype.hasOwnProperty.call(__aboOwnerChecks, v)) return __aboOwnerChecks[v];
  var h = aboSha256('${SALT}' + v); for (var i = 1; i < ${ITER}; i++) h = aboSha256(h + ':' + v); var ok = h === OWNER_CODE_HASH; __aboOwnerChecks[v] = ok; if (ok) OWNER_LOGIN_ID = v; return ok; }
window.isOwnerCode = isOwnerCode;`);
    s = s.replace("if (loginId === OWNER_LOGIN_ID) return { role: 'owner', id: OWNER_LOGIN_ID,", "if (isOwnerCode(loginId)) return { role: 'owner', id: OWNER_LOGIN_ID,");
    s = s.replace('if(loginId!==OWNER_LOGIN_ID||password!==OWNER_LOGIN_ID)return false;', 'if(!isOwnerCode(loginId)||password!==loginId)return false;');
    if (s.includes(`'${code}'`)) throw new Error(`${f}: the owner code is still written somewhere in the file`);
  } else if (process.env.OWNER_CODE) {
    // CHANGE the owner code of an already-protected file (the old code was public on the old website, so change it).
    const nc = process.env.OWNER_CODE;
    if (nc.length < 12 || !/[a-z]/i.test(nc) || !/[0-9]/.test(nc)) throw new Error('OWNER_CODE must be at least 12 characters with letters and numbers');
    const re = /const OWNER_CODE_HASH = '[0-9a-f]{64}';/;
    if (!re.test(s)) throw new Error(`${f}: owner code hash not found`);
    s = s.replace(re, `const OWNER_CODE_HASH = '${hashOf(nc)}';`);
    if (s.includes(nc)) throw new Error(`${f}: the new owner code is written in the file`);
    console.log(`  ${path.basename(f)}: owner code changed`);
  }
  // 2. early access: 5 minutes (owner: 1–5), m:ss, warning at 1 minute
  s = s.replace("  earlyAccessSeconds = 30;\n  pricingOverlayShown = false;", "  earlyAccessSeconds = earlyAccessTotal();\n  pricingOverlayShown = false;");
  if (!s.includes('function earlyAccessTotal()')) {
    s = s.replace('function startEarlyAccessCountdown() {', `function earlyAccessTotal() { var m = Math.round(Number(pricingData && pricingData.previewMinutes) || 5); return Math.min(5, Math.max(1, m)) * 60; }
function startEarlyAccessCountdown() {`);
  }
  s = s.replace(`  const s = earlyAccessSeconds;
  const pct = Math.round((s / 30) * 100);
  banner.innerHTML = '<span class="ea-icon">⚡</span> <span>Early Access — Full access requires subscription</span> <span class="timer">' + String(s).padStart(2,'0') + 's</span> <span class="ea-label">' + pct + '% remaining</span>';`,
  `  const s = Math.max(0, earlyAccessSeconds);
  const pct = Math.round((s / earlyAccessTotal()) * 100);
  banner.classList.toggle('ending', s <= 60);
  if (s === 60) { try { showToast('Preview ends in 1 minute. Subscribe to keep using the app.'); } catch (e) {} }
  banner.innerHTML = '<span class="ea-icon">⚡</span> <span>Preview — full access needs a subscription</span> <span class="timer">' + Math.floor(s / 60) + ':' + String(s % 60).padStart(2,'0') + '</span> <span class="ea-label">' + pct + '% left</span>';`);
  // 3. visible copy
  s = s.replace('<h4>Newsletter Studio</h4>', '<h4>Announcements</h4>')
    .replace('Word-style newsletter editor with rich formatting, images, tables. Send to parents via WhatsApp or email in bulk.', 'Post notices and letters to everyone, a class or parents — then share them with parents on WhatsApp or email.')
    .replace('results, CBT exams, AI comments, newsletters and parent communication', 'results, CBT exams, AI comments, announcements and parent communication')
    .replace('and receive newsletters through child login', 'and receive announcements through child login');
  // 4. export / import libraries: no longer 8 blocking downloads (≈2.2 MB) on every visit — loaded only when someone
  //    exports or imports, from this site's own copy (vendor/, same SRI hashes), else from the CDN (file opened from disk)
  s = libsLoader(s);
  s = wrapEntries(s);
  // 5. CSP-safe access to the app's global variables (no eval / new Function needed — lets the site drop 'unsafe-eval')
  s = globalsAccessor(s);
  // 6. web font no longer blocks the first paint (system font shows at once; Inter swaps in when it arrives)
  s = s.replace("@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap');", '/* Inter is loaded without blocking the first paint (see <head>) */');
  if (!s.includes('id="abo-font"')) s = s.replace('<meta name="theme-color"', '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n<link id="abo-font" rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" media="print" onload="this.media=\'all\'">\n<meta name="theme-color"');
  // 7. private school app: ask search engines not to list it (the website copy also sends X-Robots-Tag)
  if (!s.includes('name="robots"')) s = s.replace('<meta name="theme-color"', '<meta name="robots" content="noindex, nofollow">\n<meta name="theme-color"');
  if (s !== before) { fs.writeFileSync(f, s); console.log('patched', f); } else console.log('already patched', f);
}
