#!/usr/bin/env bash
# Prints fresh random secrets for .env (store them in your secrets manager).
for k in CSRF_SECRET DATA_ENCRYPTION_KEY FILE_URL_SECRET METRICS_TOKEN; do echo "$k=$(openssl rand -base64 32)"; done
for k in DB_OWNER_PASSWORD DB_APP_PASSWORD POSTGRES_SUPERUSER_PASSWORD; do echo "$k=$(openssl rand -base64 30 | tr -d '/+=' | cut -c1-32)"; done
