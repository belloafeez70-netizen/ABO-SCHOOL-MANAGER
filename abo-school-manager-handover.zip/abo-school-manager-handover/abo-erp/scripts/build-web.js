#!/usr/bin/env node
'use strict';
// Production build of the web app for Netlify (or any static host):  npm run build:web  →  dist/web
//   • JS: one minified ES-module entry + lazily loaded, content-hashed chunks per page (esbuild code splitting)
//   • CSS: tokens + app bundled and minified into one hashed file
//   • index.html rewritten to the hashed files; <html data-release> for error reports
//   • _headers: strict CSP and security headers for every page, immutable caching for hashed assets
//   • Fails the build if anything that looks like a secret ends up in the output
// Optional build env: CSP_IMG_SRC (extra image origins), HSTS_INCLUDE_SUBDOMAINS=true (custom domain you fully control),
// WEB_SOURCEMAP=true (ship source maps), COMMIT_REF (set by Netlify; used as the release id).
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const esbuild = require('esbuild');

const ROOT = path.resolve(__dirname, '..');
const SRC = path.join(ROOT, 'web');
const OUT = process.env.WEB_OUT ? path.resolve(process.env.WEB_OUT) : path.join(ROOT, 'dist', 'web');
const hash = (buf) => crypto.createHash('sha256').update(buf).digest('hex').slice(0, 10);

async function main() {
  const t0 = Date.now();
  // optional direct API mode (own domain only) — a PUBLIC URL, never a secret
  const apiBase = (process.env.PUBLIC_API_BASE || '').replace(/\/+$/, '');
  if (apiBase && !/^https:\/\/[a-z0-9.-]+(:\d+)?$/i.test(apiBase)) throw new Error('PUBLIC_API_BASE must be an https:// origin such as https://api.yourschool.com.ng');
  if (/\.(netlify\.app|onrender\.com|fly\.dev|up\.railway\.app|herokuapp\.com)$/i.test(apiBase)) {
    throw new Error('PUBLIC_API_BASE on a shared platform domain would make the session cookie third-party. Leave it empty (use the Netlify proxy) until the API has a subdomain of your own domain.');
  }

  fs.rmSync(OUT, { recursive: true, force: true });
  fs.mkdirSync(path.join(OUT, 'assets', 'css'), { recursive: true });
  fs.mkdirSync(path.join(OUT, 'assets', 'img'), { recursive: true });

  // ── JavaScript: code-split bundle (pages become lazy chunks via the import(`./pages/${mod}.js`) glob) ──
  const js = await esbuild.build({
    entryPoints: [path.join(SRC, 'assets/js/main.js')], bundle: true, splitting: true, format: 'esm', platform: 'browser',
    target: ['es2020', 'chrome90', 'firefox90', 'safari14'], minify: true, legalComments: 'none', charset: 'utf8',
    outdir: path.join(OUT, 'assets/js'), entryNames: '[name]-[hash]', chunkNames: 'c/[name]-[hash]', metafile: true,
    sourcemap: process.env.WEB_SOURCEMAP === 'true' ? 'linked' : false, logLevel: 'warning',
    define: { __ABO_API_BASE__: JSON.stringify(apiBase), __ABO_SITE_URL__: JSON.stringify(/^https:\/\/[a-z0-9.-]+$/i.test(process.env.PUBLIC_SITE_URL || '') ? process.env.PUBLIC_SITE_URL : '') },
  });
  const entry = Object.entries(js.metafile.outputs).find(([, o]) => o.entryPoint && o.entryPoint.endsWith('main.js'));
  const entryPath = path.resolve(process.cwd(), entry[0]);
  const entryUrl = '/' + path.relative(OUT, entryPath).split(path.sep).join('/');

  // ── CSS: tokens + app in one minified, hashed file ──
  const css = await esbuild.build({
    stdin: { contents: '@import "./tokens.css";\n@import "./app.css";\n', resolveDir: path.join(SRC, 'assets/css'), loader: 'css', sourcefile: 'bundle.css' },
    bundle: true, minify: true, write: false, loader: { '.svg': 'dataurl', '.png': 'dataurl' }, target: ['chrome90', 'firefox90', 'safari14'], logLevel: 'warning',
  });
  const cssText = css.outputFiles[0].contents;
  const cssName = `app-${hash(cssText)}.css`;
  fs.writeFileSync(path.join(OUT, 'assets/css', cssName), cssText);

  // ── static images ──
  fs.cpSync(path.join(SRC, 'assets/img'), path.join(OUT, 'assets/img'), { recursive: true });
  // ── install as an app: manifest at the root + the early layout/install script (plain script, runs before drawing) ──
  fs.copyFileSync(path.join(SRC, 'manifest.webmanifest'), path.join(OUT, 'manifest.webmanifest'));
  const layoutJs = esbuild.transformSync(fs.readFileSync(path.join(SRC, 'assets/js/layout.js'), 'utf8'), { minify: true, target: 'es2015' }).code;
  const layoutName = `layout-${hash(layoutJs)}.js`;
  fs.writeFileSync(path.join(OUT, 'assets/js', layoutName), layoutJs);

  // ── offline support: the service worker must live at the site root (scope /) and never be cached long ──
  // the service-worker cache name carries the release, so every deploy replaces the saved copies cleanly
  fs.writeFileSync(path.join(OUT, 'sw.js'), fs.readFileSync(path.join(SRC, 'sw.js'), 'utf8').replace(/const VERSION = '[^']*';/, `const VERSION = 'abo-sw-${(process.env.COMMIT_REF || '').slice(0, 12) || hash(fs.readFileSync(entryPath))}';`));
  // branded page for unknown addresses (Netlify serves 404.html automatically)
  const NF_STYLE = 'body{margin:0;min-height:100vh;display:grid;place-items:center;background:#10263f;color:#fff;font-family:system-ui,Segoe UI,Roboto,Arial,sans-serif;padding:24px}div{max-width:420px;text-align:center}img{width:72px;height:72px}p{color:#cdd8e5;line-height:1.55}a{display:inline-block;background:#0fa37f;color:#fff;text-decoration:none;font-weight:600;padding:12px 18px;border-radius:10px}';
  var nfStyleHash = crypto.createHash('sha256').update(NF_STYLE, 'utf8').digest('base64');   // allowed by exact hash in the CSP
  fs.writeFileSync(path.join(OUT, '404.html'), '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex"><title>Page not found · A.B.O. School Manager</title><link rel="icon" href="/assets/img/favicon.svg"><style>' + NF_STYLE + '</style></head><body><div><img src="/assets/img/icons/icon-192.png" alt="A.B.O."><h1>Page not found</h1><p>This address is not part of your school portal.</p><a href="/">Go to the sign-in page</a></div></body></html>');

  // ── index.html ──
  const release = (process.env.COMMIT_REF || '').slice(0, 12) || hash(fs.readFileSync(entryPath));
  let html = fs.readFileSync(path.join(SRC, 'index.html'), 'utf8');
  html = html.replace('<html lang="en">', `<html lang="en" data-release="${release}">`)
    .replace(/\s*<link rel="stylesheet" href="\/assets\/css\/tokens\.css">/, '')
    .replace('<link rel="stylesheet" href="/assets/css/app.css">', `<link rel="stylesheet" href="/assets/css/${cssName}">`)
    .replace('<script type="module" src="/assets/js/main.js"></script>', `<script type="module" src="${entryUrl}"></script>`)
    .replace('<script src="/assets/js/layout.js"></script>', `<script src="/assets/js/${layoutName}"></script>`);
  if (!html.includes(cssName) || !html.includes(entryUrl) || !html.includes(layoutName)) throw new Error('index.html rewrite failed — the <link>/<script> tags changed');
  fs.writeFileSync(path.join(OUT, 'index.html'), html);

  // ── security + cache headers (Netlify _headers). API responses carry the backend's own headers. ──
  const imgExtra = (process.env.CSP_IMG_SRC || '').split(/[\s,]+/).filter((o) => /^https:\/\/[a-z0-9.-]+(:\d+)?$/i.test(o));
  const csp = ["default-src 'self'", "script-src 'self'", `style-src 'self' 'sha256-${nfStyleHash}'`, `img-src 'self' data: blob:${[apiBase, ...imgExtra].filter(Boolean).map((o) => ' ' + o).join('')}`,
    "font-src 'self' data:", `connect-src 'self'${apiBase ? ' ' + apiBase : ''}`, "object-src 'none'", "frame-src 'none'", "frame-ancestors 'none'", "base-uri 'none'",
    "form-action 'self'", "worker-src 'self'", "manifest-src 'self'", 'upgrade-insecure-requests'].join('; ');
  const hsts = `max-age=63072000${process.env.HSTS_INCLUDE_SUBDOMAINS === 'true' ? '; includeSubDomains' : ''}`;
  const headers = `/*
  Content-Security-Policy: ${csp}
  Strict-Transport-Security: ${hsts}
  X-Content-Type-Options: nosniff
  X-Frame-Options: DENY
  Referrer-Policy: strict-origin-when-cross-origin
  Permissions-Policy: camera=(), microphone=(), geolocation=(self), payment=(), usb=(), interest-cohort=(), publickey-credentials-get=(self), publickey-credentials-create=(self)
  Cross-Origin-Opener-Policy: same-origin
  Cross-Origin-Resource-Policy: same-origin
  X-Permitted-Cross-Domain-Policies: none
  X-Robots-Tag: noindex, nofollow, noarchive
/
  Cache-Control: no-cache
/index.html
  Cache-Control: no-cache
/sw.js
  Cache-Control: no-cache
/manifest.webmanifest
  Content-Type: application/manifest+json
  Cache-Control: public, max-age=3600
/assets/js/*
  Cache-Control: public, max-age=31536000, immutable
/assets/css/*
  Cache-Control: public, max-age=31536000, immutable
/assets/img/*
  Cache-Control: public, max-age=86400
`;
  let finalHeaders = headers;
  // OPTIONAL: the offline edition at /offline/ on the same site (OFFLINE_SITE_DIR=../abo-school-site). Same address ⇒
  // same browser storage, so schools keep their offline data and fingerprints. Each app gets its own CSP: the online
  // app's strict policy is moved from "/*" to its own paths, because Netlify would otherwise apply both policies.
  // Permissions-Policy stays ONLY on "/*" (GPS + fingerprint allowed for this site): Netlify joins repeated headers,
  // so a second copy under /offline/* would be merged, not replace it.
  // Found automatically when the project has an offline-site/ folder (the upload package adds it); OFFLINE_SITE_DIR=none
  // switches it off, OFFLINE_SITE_DIR=<folder> picks another folder.
  const offEnv = process.env.OFFLINE_SITE_DIR;
  const offAuto = path.join(ROOT, 'offline-site');
  const offPick = offEnv === 'none' ? null : offEnv ? path.resolve(offEnv) : (fs.existsSync(path.join(offAuto, 'index.html')) ? offAuto : null);
  if (offPick) {
    const offDir = offPick;
    if (!fs.existsSync(path.join(offDir, 'index.html')) || !fs.existsSync(path.join(offDir, '_headers'))) throw new Error(`offline site folder ${offDir} is incomplete (index.html and _headers needed)`);
    fs.cpSync(offDir, path.join(OUT, 'offline'), { recursive: true });
    for (const f of ['_headers', 'netlify.toml', 'robots.txt']) fs.rmSync(path.join(OUT, 'offline', f), { force: true });
    const offHeaders = fs.readFileSync(path.join(offDir, '_headers'), 'utf8');
    const offCsp = (offHeaders.match(/Content-Security-Policy: (.*)/) || [])[1];
    const cspLine = `  Content-Security-Policy: ${csp}\n`;
    finalHeaders = headers.replace(cspLine, '')
      + ['/', '/index.html', '/404.html', '/assets/*', '/sw.js', '/manifest.webmanifest'].map((pth) => `${pth}\n${cspLine}`).join('')
      + `/offline/*\n  Content-Security-Policy: ${offCsp}\n/offline/vendor/*\n  Cache-Control: public, max-age=31536000, immutable\n/offline/sw.js\n  Cache-Control: no-cache, no-store\n`;
    console.log('  offline edition included at /offline/');
  }
  fs.writeFileSync(path.join(OUT, '_headers'), finalHeaders);
  fs.writeFileSync(path.join(OUT, 'robots.txt'), 'User-agent: *\nDisallow: /\n');   // a private school portal: keep it out of search engines

  // ── guard: no secrets in the published bundle ──
  const SECRET = [/sk_(live|test)_[0-9a-zA-Z]{10,}/, /AKIA[0-9A-Z]{16}/, /-----BEGIN [A-Z ]*PRIVATE KEY-----/, /postgres(ql)?:\/\/[^\s'"]+:[^\s'"@]+@/,
    /PROXY_SHARED_SECRET\s*[=:]\s*['"][^'"]{8,}/, /(CSRF_SECRET|DATA_ENCRYPTION_KEY|FILE_URL_SECRET|JWT_SECRET)\s*[=:]\s*['"][^'"]{8,}/, /xox[bap]-[0-9A-Za-z-]{10,}/];
  const files = []; const walk = (d) => { for (const f of fs.readdirSync(d)) { const p = path.join(d, f); if (fs.statSync(p).isDirectory()) walk(p); else files.push(p); } };
  walk(OUT);
  for (const f of files) { const t = fs.readFileSync(f, 'utf8'); const hit = SECRET.find((re) => re.test(t)); if (hit) throw new Error(`possible secret in ${path.relative(ROOT, f)} (${hit})`); }

  // ── report ──
  const size = (p) => fs.statSync(p).size; const zipped = (p) => require('node:zlib').gzipSync(fs.readFileSync(p)).length;
  const jsFiles = files.filter((f) => f.endsWith('.js'));
  const kb = (n) => `${(n / 1024).toFixed(1)} kB`;
  console.log(`web build ok in ${Date.now() - t0} ms → ${path.relative(ROOT, OUT)} (release ${release})`);
  console.log(`  entry ${entryUrl}: ${kb(size(entryPath))} (${kb(zipped(entryPath))} gzip)`);
  console.log(`  ${jsFiles.length} JS files: ${kb(jsFiles.reduce((a, f) => a + size(f), 0))} total (${kb(jsFiles.reduce((a, f) => a + zipped(f), 0))} gzip), pages load on demand`);
  console.log(`  css /assets/css/${cssName}: ${kb(cssText.length)} (${kb(require('node:zlib').gzipSync(cssText).length)} gzip)`);
  console.log(`  secret scan: ${files.length} files clean`);
  console.log(`  API: ${apiBase ? `direct → ${apiBase} (own-domain mode)` : 'same origin /api/* (Netlify edge proxy)'}`);
}
main().catch((e) => { console.error('web build FAILED:', e.message); process.exit(1); });
