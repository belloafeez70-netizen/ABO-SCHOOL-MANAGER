'use strict';
// Simple concurrency benchmark against a running server (dev/staging only). Not a substitute for a proper
// load test (k6/Locust) on production-sized infrastructure.
const BASE = process.env.BASE_URL || 'http://127.0.0.1:8080';
const N = Number(process.env.N || 3000); const C = Number(process.env.C || 50);
async function login(id) {
  const r = await fetch(`${BASE}/api/v1/auth/login`, { method: 'POST', headers: { 'content-type': 'application/json', origin: BASE }, body: JSON.stringify({ loginId: id, password: process.env.DEMO_PASSWORD || 'Demo#School2026' }) });
  return r.headers.get('set-cookie').split(';')[0];
}
(async () => {
  const cookie = await login(process.env.LOGIN || 'bopc.teacher1');
  const urls = ['/api/v1/students?pageSize=25', '/api/v1/students?q=okafor', '/api/v1/dashboard', '/api/v1/announcements', '/api/v1/auth/me'];
  const lat = []; let errors = 0; let i = 0; const t0 = Date.now();
  await Promise.all(Array.from({ length: C }, async () => {
    while (i < N) { const u = urls[i++ % urls.length]; const s = performance.now(); const r = await fetch(BASE + u, { headers: { cookie } }); await r.arrayBuffer(); lat.push(performance.now() - s); if (!r.ok) errors++; }
  }));
  lat.sort((a, b) => a - b); const q = (p) => lat[Math.floor(lat.length * p)].toFixed(1);
  const secs = (Date.now() - t0) / 1000;
  console.log(JSON.stringify({ requests: lat.length, concurrency: C, seconds: secs, rps: Math.round(lat.length / secs), p50_ms: q(0.5), p95_ms: q(0.95), p99_ms: q(0.99), errors }));
})();
