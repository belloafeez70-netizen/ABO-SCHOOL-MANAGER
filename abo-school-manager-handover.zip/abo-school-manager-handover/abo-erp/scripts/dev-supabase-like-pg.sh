#!/usr/bin/env bash
# Local PostgreSQL 17 that mimics Supabase's roles: real superuser "supabase_admin" (hidden on Supabase) and
# "postgres" = NOSUPERUSER CREATEDB CREATEROLE REPLICATION BYPASSRLS LOGIN, which is what the project owner gets.
set -e
export LD_LIBRARY_PATH=/var/tmp/pg/root/usr/lib/x86_64-linux-gnu; B=/var/tmp/pg/root/usr/lib/postgresql/17/bin
if [ ! -x $B/postgres ]; then bash /home/user/.qa/supa-stack.sh > /var/tmp/supa-stack.log 2>&1 || true; fi
D=/var/tmp/sbpg
if [ ! -d $D ]; then
  $B/initdb -D $D -U supabase_admin --auth=trust -E UTF8 --locale=C.UTF-8 > /dev/null
  printf "listen_addresses='127.0.0.1'\nport=5433\nmax_connections=200\npassword_encryption=scram-sha-256\n" >> $D/postgresql.conf
  printf "local all all trust\nhost all supabase_admin 127.0.0.1/32 trust\nhost all all 127.0.0.1/32 scram-sha-256\n" > $D/pg_hba.conf
fi
$B/pg_ctl -D $D -o "-k /tmp" -l /var/tmp/sbpg.log status >/dev/null 2>&1 || $B/pg_ctl -D $D -o "-k /tmp" -l /var/tmp/sbpg.log start >/dev/null
sleep 2
$B/psql -h /tmp -p 5433 -U supabase_admin -d postgres -q -c "do \$\$ begin
  if not exists (select 1 from pg_roles where rolname='postgres') then create role postgres login nosuperuser createdb createrole replication bypassrls password 'sb-local-postgres-pw'; end if;
end \$\$;" -c "alter database postgres owner to supabase_admin" 
$B/psql -h /tmp -p 5433 -U supabase_admin -d postgres -tA -c "select rolname, rolsuper, rolcreaterole, rolcreatedb, rolbypassrls from pg_roles where rolname in ('postgres','supabase_admin') order by 1"
