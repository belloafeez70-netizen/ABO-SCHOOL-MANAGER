#!/usr/bin/env node
'use strict';
// Verifies a LIVE deployment from anywhere (your laptop is fine) — run it after every Netlify/API deploy:
//   npm run verify:deploy -- https://<your-site>.netlify.app [https://<your-api-host>]
// Checks: HTTPS + security headers on the site, hashed assets cached immutably, the /api proxy reaches the API,
// the API accepts the site's origin and rejects foreign origins, and (with the API URL) that direct access
// bypassing Netlify is blocked while health checks work. Sends one harmless failed sign-in ("preflight.check").
const site = (process.argv[2] || '').replace(/\/+$/, '');
const api = (process.argv[3] || '').replace(/\/+$/, '');
if (!/^https?:\/\//.test(site)) { console.error('usage: npm run verify:deploy -- https://<site>.netlify.app [https://<api-host>]'); process.exit(2); }

const rows = []; const add = (ok, check, detail = '') => rows.push({ ok, check, detail });
const get = (url, init = {}) => fetch(url, { redirect: 'manual', ...init, signal: AbortSignal.timeout(20000) });
const json = async (r) => { try { return await r.json(); } catch { return null; } };

(async () => {
  try {
    if (/^https:\/\/(localhost|127\.0\.0\.1)[:/]/.test(site + '/')) add(true, 'HTTP redirects to HTTPS', 'skipped for a local emulator');
    else if (site.startsWith('https://')) {
      const plain = await get(site.replace('https://', 'http://') + '/').catch(() => null);
      add(!!plain && [301, 302, 307, 308].includes(plain.status) && /^https:/.test(plain.headers.get('location') || ''), 'HTTP redirects to HTTPS', plain ? `${plain.status} → ${plain.headers.get('location')}` : 'no answer on http');
    } else add(false, 'Site uses HTTPS', `${site} is not https`);

    const home = await get(site + '/');
    const html = await home.text();
    add(home.status === 200, 'Site home page', `HTTP ${home.status}`);
    const h = (k) => home.headers.get(k) || '';
    const cspv = h('content-security-policy');
    add(/script-src ('self'|'sha256-[A-Za-z0-9+/=]+')/.test(cspv) && !/unsafe-inline/.test(cspv) && /frame-ancestors 'none'/.test(cspv), 'Content-Security-Policy', cspv.slice(0, 80) || 'missing');
    add(/max-age=\d{7,}/.test(h('strict-transport-security')), 'HSTS', h('strict-transport-security') || 'missing');
    add(h('x-frame-options') === 'DENY' && h('x-content-type-options') === 'nosniff', 'Frame / MIME protection', `${h('x-frame-options')} · ${h('x-content-type-options')}`);
    add(/no-cache/.test(h('cache-control')), 'index.html revalidates on every visit', h('cache-control'));
    const js = (html.match(/src="(\/assets\/js\/main-[^"]+\.js)"/) || [])[1];
    const single = /data-build="single"/.test(html) && /<script type="module">/.test(html);
    add(!!js || single, 'Production build deployed', js || (single ? 'single-file edition (everything inline)' : 'index.html still points at unbuilt /assets/js/main.js — check the Netlify build command/publish dir'));
    if (js) {
      const a = await get(site + js);
      add(a.status === 200 && /immutable/.test(a.headers.get('cache-control') || ''), 'Hashed assets cached for a year', `${a.status} · ${a.headers.get('cache-control')}`);
    }

    const me = await get(site + '/api/v1/auth/me');
    const meBody = await json(me);
    const meCode = meBody && meBody.error && meBody.error.code;
    add(me.status === 401 && meCode === 'UNAUTHENTICATED', 'Netlify /api proxy reaches the API', me.status === 503 ? `503 ${meCode} — set API_ORIGIN and PROXY_SHARED_SECRET in Netlify (scope: Functions) and redeploy`
      : me.status === 502 || me.status === 504 ? `${me.status} — API not reachable from Netlify (is it running? is API_ORIGIN right?)`
        : me.status === 403 ? `403 ${meCode} — PROXY_SHARED_SECRET differs between Netlify and the API` : `${me.status} ${meCode || ''}`);
    add((me.headers.get('cache-control') || '').includes('no-store') && !!me.headers.get('x-request-id') && !me.headers.get('x-powered-by'), 'API response headers (no-store, request id, no banner)');

    const login = (origin) => get(site + '/api/v1/auth/login', { method: 'POST', headers: { 'content-type': 'application/json', origin }, body: JSON.stringify({ loginId: 'preflight.check', password: 'not-a-real-password' }) });
    const ok = await login(site); const okBody = await json(ok);
    add(ok.status === 401 && okBody && okBody.error.code === 'INVALID_CREDENTIALS', 'API accepts sign-in requests from this site', ok.status === 403 ? `403 — set PUBLIC_ORIGIN (or ALLOWED_ORIGINS) on the API to ${site}` : `HTTP ${ok.status}`);
    const evil = await login('https://evil.example');
    add(evil.status === 403, 'API rejects requests from other websites', `HTTP ${evil.status}`);

    if (api) {
      const hz = await get(api + '/healthz'); add(hz.status === 200, 'API health check (direct)', `HTTP ${hz.status}`);
      const rz = await get(api + '/readyz'); const rb = await json(rz); add(rz.status === 200 && rb && rb.db === 'up', 'API database connection', rb ? `db ${rb.db}` : `HTTP ${rz.status}`);
      const direct = await get(api + '/api/v1/auth/me'); const db = await json(direct);
      add(direct.status === 403 && db && db.error.code === 'DIRECT_ACCESS_BLOCKED', 'Direct API access (bypassing Netlify) is blocked', `HTTP ${direct.status}${direct.status !== 403 ? ' — set REQUIRE_PROXY_SECRET=true on the API' : ''}`);
      const root = await get(api + '/'); add(root.status === 404 || root.status === 403, 'API does not serve the web app', `HTTP ${root.status}${root.status === 200 ? ' — set SERVE_FRONTEND=false' : ''}`);
    }
  } catch (e) { add(false, 'Network', e.message); }
  const w = Math.max(...rows.map((r) => r.check.length));
  for (const r of rows) console.log(`${r.ok ? '✔' : '✖'} ${r.check.padEnd(w)}  ${r.detail}`);
  const bad = rows.filter((r) => !r.ok).length;
  console.log(`\n${rows.length - bad}/${rows.length} checks passed — ${bad ? 'fix the ✖ items above' : `${site} is correctly deployed`}`);
  process.exit(bad ? 1 : 0);
})();
