'use strict';
// Creates the first platform (super) administrator in any environment.
// Usage: PLATFORM_ADMIN_LOGIN=abo.admin PLATFORM_ADMIN_EMAIL=you@example.com node scripts/create-platform-admin.js
// A strong random password is generated and printed ONCE; MFA enrolment is forced at first sign-in (staging/production).
const crypto = require('node:crypto');
const { withTx, pool } = require('../server/src/db/pool');
const pw = require('../server/src/security/passwords');

const LOGIN_RE = /^[A-Za-z0-9._@-]{3,64}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

async function createPlatformAdmin({ login, email }) {
  if (!login || !email) throw new Error('PLATFORM_ADMIN_LOGIN and PLATFORM_ADMIN_EMAIL are required');
  if (!LOGIN_RE.test(login)) throw new Error('PLATFORM_ADMIN_LOGIN must be 3-64 chars: letters, digits, . _ @ -');
  if (!EMAIL_RE.test(email)) throw new Error('PLATFORM_ADMIN_EMAIL is not a valid email address');
  const password = crypto.randomBytes(18).toString('base64url');
  const hash = await pw.hash(password); // hash BEFORE opening the transaction (keeps the tx short)
  try {
    const r = await withTx({ platform: true }, (c) => c.query(
      `INSERT INTO users (school_id, login_id, full_name, email, password_hash, is_platform_admin, must_change_password)
       VALUES (NULL, $1, 'Platform Administrator', $2, $3, true, true) RETURNING id`, [login, email, hash]));
    return { id: r.rows[0].id, login, password };
  } catch (e) {
    if (e.code === '23505') throw new Error(`A user with login "${login}" or email "${email}" already exists — nothing changed.`);
    throw e;
  }
}

if (require.main === module) {
  createPlatformAdmin({ login: process.env.PLATFORM_ADMIN_LOGIN, email: process.env.PLATFORM_ADMIN_EMAIL })
    .then(({ login, password }) => {
      console.log(`Platform admin "${login}" created.\nOne-time password (change at first sign-in): ${password}`);
      return pool.end();
    })
    .catch(async (e) => { console.error(e.message); await pool.end().catch(() => {}); process.exit(1); });
}
module.exports = { createPlatformAdmin };
