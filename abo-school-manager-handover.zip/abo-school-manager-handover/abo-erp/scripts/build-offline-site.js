#!/usr/bin/env node
'use strict';
// Packs the offline edition as a static website (fingerprint/face, GPS and "install as app" need https://).
// Output: <out>/index.html, vendor/ (export libraries, same SRI hashes as the CDN), icons/, manifest.webmanifest,
//         sw.js (versioned by content hash), offline.html, 404.html, robots.txt, _headers, netlify.toml, README.txt
// Usage: node scripts/build-offline-site.js <bopc.html> <outDir>
//
// Security headers (12 Oct 2026, after inspecting every inline script, CDN library and integration):
//  • Content-Security-Policy WITHOUT 'unsafe-eval' (the app reads its globals through aboGlobalGet, not eval).
//    'unsafe-inline' stays for scripts and styles because the app has ~1,000 inline onclick= handlers and inline
//    <script> blocks; removing it would mean rewriting the whole app. Scripts may only come from this site and the three
//    CDNs that host the export libraries (fallback when vendor/ is unreachable). connect-src allows https:/wss: because
//    the school's own Supabase project URL and the optional online-AI endpoint are chosen by the school.
//  • X-Robots-Tag: noindex — a private school app should never appear in search results.
//  • HSTS, nosniff, Referrer-Policy, frame protection and the fingerprint/GPS Permissions-Policy are kept.
const fs = require('node:fs'); const path = require('node:path'); const crypto = require('node:crypto');
const [src, out] = process.argv.slice(2);
if (!src || !out) { console.error('usage: build-offline-site.js <school_broadsheet_manager_bopc_erp.html> <outDir>'); process.exit(1); }
const ROOT = path.join(__dirname, '..');
fs.rmSync(out, { recursive: true, force: true }); fs.mkdirSync(out, { recursive: true });

// ── index.html: link the manifest/icons right after the viewport tag ──
let html = fs.readFileSync(src, 'utf8');
const HEAD_LINKS = '<!-- ABO-SITE-APP -->\n<link rel="manifest" href="manifest.webmanifest">\n<link rel="apple-touch-icon" href="icons/apple-touch-icon.png">\n<link rel="icon" href="icons/favicon-32.png" sizes="32x32" type="image/png">\n' +
  '<meta name="mobile-web-app-capable" content="yes">\n<meta name="apple-mobile-web-app-capable" content="yes">\n<meta name="apple-mobile-web-app-title" content="ABO School">\n<!-- /ABO-SITE-APP -->\n';
html = html.replace(/<!-- ABO-SITE-APP -->[\s\S]*?<!-- \/ABO-SITE-APP -->\n?/, '');
const vp = html.indexOf('<meta name="viewport"'); if (vp < 0) throw new Error('viewport meta not found in ' + src);
const vpEnd = html.indexOf('>', vp) + 1;
html = html.slice(0, vpEnd) + '\n' + HEAD_LINKS + html.slice(vpEnd);
// smaller first download on slow phones: inline <script> and <style> blocks are minified (whitespace + syntax only —
// names are kept, because the blocks share globals). Set OFFLINE_SITE_MINIFY=0 to ship the readable file.
if (process.env.OFFLINE_SITE_MINIFY !== '0') {
  let esbuild = null; try { esbuild = require('esbuild'); } catch { console.warn('esbuild not installed — index.html is not minified (run npm ci first)'); }
  if (esbuild) {
    const raw = html.length; let kept = 0; const scripts = [];
    // 1. take the <script> blocks out (their strings may contain "<style>" text that must not be touched)
    html = html.replace(/<script(\s[^>]*)?>([\s\S]*?)<\/script>/g, (m, attrs = '', code) => {
      let outCode = code;
      if (!/\bsrc=/.test(attrs) && !/type="(?!text\/javascript)[^"]*"/.test(attrs) && code.trim()) {
        try { const o = esbuild.transformSync(code, { loader: 'js', minifyWhitespace: true, minifySyntax: true, minifyIdentifiers: false, target: 'es2017', legalComments: 'none' }).code; if (/<\/script/i.test(o)) kept++; else outCode = o; } catch { kept++; }
      }
      scripts.push(`<script${attrs}>${outCode}</script>`); return `\u0000ABO_SCRIPT_${scripts.length - 1}\u0000`;
    });
    // 2. minify the real <style> blocks of the page
    html = html.replace(/<style(\s[^>]*)?>([\s\S]*?)<\/style>/g, (m, attrs = '', css) => { try { return `<style${attrs}>${esbuild.transformSync(css, { loader: 'css', minify: true }).code}</style>`; } catch { kept++; return m; } });
    // 3. put the scripts back
    html = html.replace(/\u0000ABO_SCRIPT_(\d+)\u0000/g, (m, i) => scripts[Number(i)]);
    console.log(`index.html minified: ${(raw / 1024).toFixed(0)} kB → ${(html.length / 1024).toFixed(0)} kB${kept ? ` (${kept} block(s) kept as they were)` : ''}`);
  }
}
fs.writeFileSync(path.join(out, 'index.html'), html);

// ── vendor libraries (loaded on demand by ABO_LIBS; verified against their SRI hashes here) ──
const vendorDir = path.join(ROOT, 'legacy/vendor'); const manifest = JSON.parse(fs.readFileSync(path.join(vendorDir, 'manifest.json'), 'utf8'));
fs.mkdirSync(path.join(out, 'vendor'), { recursive: true });
const vendorFiles = [];
for (const v of Object.values(manifest)) {
  const buf = fs.readFileSync(path.join(vendorDir, v.file)); const [algo, b64] = v.sri.split('-');
  if (crypto.createHash(algo).update(buf).digest('base64') !== b64) throw new Error(`vendor/${v.file} does not match its SRI hash`);
  fs.writeFileSync(path.join(out, 'vendor', v.file), buf); vendorFiles.push('vendor/' + v.file);
}
// ── icons + manifest ──
const iconSrc = path.join(ROOT, 'web/assets/img/icons');
fs.mkdirSync(path.join(out, 'icons'), { recursive: true });
for (const f of fs.readdirSync(iconSrc)) fs.copyFileSync(path.join(iconSrc, f), path.join(out, 'icons', f));
fs.writeFileSync(path.join(out, 'manifest.webmanifest'), JSON.stringify({
  id: './', name: 'A.B.O. School Manager (offline)', short_name: 'ABO School', description: 'Scores, report cards, cumulative results and school records — works without internet.',
  lang: 'en-NG', start_url: './', scope: './', display: 'standalone', display_override: ['standalone', 'minimal-ui'], orientation: 'any', background_color: '#10263f', theme_color: '#1a365d',
  categories: ['education', 'productivity'],
  icons: [{ src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any' }, { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' }, { src: 'icons/maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' }],
}, null, 2));

// ── branded offline page and 404 page (no scripts, inline styles only) ──
const page = (title, msg, extra = '') => `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex, nofollow">
<title>${title} · A.B.O. School Manager</title><link rel="icon" href="icons/favicon-32.png">
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#10263f;color:#fff;font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;padding:24px;box-sizing:border-box}
.b{max-width:420px;text-align:center}.m{width:72px;height:72px;margin:0 auto 18px;display:block}h1{font-size:22px;margin:0 0 10px}p{color:#cdd8e5;line-height:1.55;margin:0 0 18px}
a{display:inline-block;background:#0fa37f;color:#fff;text-decoration:none;font-weight:600;padding:12px 18px;border-radius:10px}small{display:block;margin-top:20px;color:#8ea3ba}</style></head>
<body><div class="b"><img class="m" src="icons/icon-192.png" alt="A.B.O."><h1>${title}</h1><p>${msg}</p>${extra}<small>A.B.O. Edu Consultant · 0805 144 6681</small></div></body></html>`;
fs.writeFileSync(path.join(out, 'offline.html'), page('You are offline', 'This page has not been saved on this device yet. Your school data is safe on this phone — open the app again when you are back online, or go to the home screen of the app.', '<a href="./">Open the app</a>'));
fs.writeFileSync(path.join(out, '404.html'), page('Page not found', 'This address is not part of the school app. Everything lives on the main page.', '<a href="/">Go to the app</a>'));
fs.writeFileSync(path.join(out, 'robots.txt'), 'User-agent: *\nDisallow: /\n');

// ── service worker, versioned by the content of everything it caches ──
const ver = crypto.createHash('sha256').update(html).update(vendorFiles.join(',')).update(fs.readFileSync(path.join(out, 'offline.html'))).update(fs.readFileSync(__filename)).digest('hex').slice(0, 12);   // this file holds the worker code too
fs.writeFileSync(path.join(out, 'sw.js'), `/* A.B.O. offline edition — website copy service worker (version ${ver}).
   • The app (index.html) is network-first, so a new release arrives as soon as the phone is online; the saved copy opens it offline.
   • Export libraries (vendor/) and icons are cache-first (they never change for a given version).
   • School data is NOT cached here — it lives in the browser storage of the app itself.
   • A new version waits until the page says "Update now" (message 'skip-waiting'), then old caches are deleted.
   Cache update procedure: publish the new site; phones get the "A new version of the app is ready" bar; tap Update now. */
const VERSION = 'abo-site-${ver}';
const SCOPE = new URL(self.registration ? self.registration.scope : './', self.location.href).pathname;
const CORE = ['./', 'index.html', 'offline.html', 'manifest.webmanifest', 'icons/icon-192.png', 'icons/icon-512.png'];
self.addEventListener('install', (e) => { e.waitUntil(caches.open(VERSION).then((c) => c.addAll(CORE)).catch(() => {})); });
self.addEventListener('message', (e) => { if (e.data && e.data.type === 'skip-waiting') self.skipWaiting(); });
self.addEventListener('activate', (e) => { e.waitUntil(caches.keys().then((k) => Promise.all(k.filter((x) => x.startsWith('abo-site') && x !== VERSION).map((x) => caches.delete(x)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', (e) => {
  const r = e.request; const u = new URL(r.url);
  if (r.method !== 'GET' || u.origin !== self.location.origin) return;
  if (r.mode === 'navigate') {
    // the app's own address: the folder this worker lives in ("/" on abosch today, "/offline/" in the combined site)
    const isApp = u.pathname === SCOPE || u.pathname === SCOPE + 'index.html';
    e.respondWith(fetch(r).then((res) => { if (res.ok && isApp) { const cp = res.clone(); caches.open(VERSION).then((c) => c.put('index.html', cp)); } return res; })
      .catch(() => caches.match(isApp ? 'index.html' : 'offline.html').then((x) => x || caches.match('index.html')).then((x) => x || caches.match('offline.html'))));
    return;
  }
  if (/\\/(vendor|icons)\\//.test(u.pathname) || u.pathname.endsWith('manifest.webmanifest')) {
    e.respondWith(caches.match(r).then((hit) => hit || fetch(r).then((res) => { if (res.ok) { const cp = res.clone(); caches.open(VERSION).then((c) => c.put(r, cp)); } return res; })));
  }
});
`);

// ── headers ──
const CSP = ["default-src 'self'", "script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com https://unpkg.com https://www.gstatic.com",
  "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com", "font-src 'self' data: https://fonts.gstatic.com", "img-src 'self' data: blob: https:",
  "connect-src 'self' https: wss:", "media-src 'self' data: blob: https:", "worker-src 'self' blob: https://cdnjs.cloudflare.com", "frame-src 'self' blob:",
  "object-src 'none'", "base-uri 'self'", "form-action 'self'", "frame-ancestors 'self'", "manifest-src 'self'", 'upgrade-insecure-requests'].join('; ');
fs.writeFileSync(path.join(out, '_headers'), [
  '/*',
  `  Content-Security-Policy: ${CSP}`,
  '  X-Robots-Tag: noindex, nofollow, noarchive',
  '  Permissions-Policy: geolocation=(self), publickey-credentials-get=(self), publickey-credentials-create=(self), camera=(), microphone=(), payment=()',
  '  X-Content-Type-Options: nosniff',
  '  Referrer-Policy: strict-origin-when-cross-origin',
  '  X-Frame-Options: SAMEORIGIN',
  '  Strict-Transport-Security: max-age=31536000; includeSubDomains; preload',
  '  Cross-Origin-Opener-Policy: same-origin-allow-popups',
  '  Cache-Control: no-cache',
  '/sw.js',
  '  Cache-Control: no-cache, no-store',
  '/manifest.webmanifest',
  '  Content-Type: application/manifest+json',
  '/vendor/*',
  '  Cache-Control: public, max-age=31536000, immutable',
  '/icons/*',
  '  Cache-Control: public, max-age=86400',
  ''].join('\n'));
fs.writeFileSync(path.join(out, 'netlify.toml'), '[build]\n  publish = "."\n');
fs.writeFileSync(path.join(out, 'README.txt'), [
  'A.B.O. School Manager — offline edition as a website (version ' + ver + ')',
  '',
  'Publish / update https://abosch.netlify.app (about 2 minutes):',
  '  1. Go to https://app.netlify.com → your site (abosch) → Deploys.',
  '  2. Drag THIS FOLDER onto the "Drag and drop your site output folder here" box. Same address, no settings to change.',
  '  3. Phones that already installed the app see "A new version of the app is ready — Update now".',
  '',
  'What is inside: index.html (the app), vendor/ (PDF/picture/Word export libraries — loaded only when you export),',
  'icons/, manifest.webmanifest + sw.js (install as an app, opens offline), offline.html, 404.html, robots.txt,',
  '_headers (security headers: CSP, HSTS, noindex, fingerprint/GPS permissions).',
  '',
  'Keep ONE address: fingerprints are tied to the website address.',
  'Data on a device stays on that device; use Cloud Sync (Supabase) so all devices share the school.',
  ''].join('\n'));
console.log(`site written to ${out} (version ${ver})`);
