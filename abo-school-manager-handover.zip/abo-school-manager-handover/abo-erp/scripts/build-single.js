#!/usr/bin/env node
'use strict';
// Single-file build of the FULL online app: every page, all JavaScript and CSS and the icon inside ONE index.html.
//   npm run build:single                      → dist/single/{index.html,_headers,robots.txt}
//   npm run build:single -- --copy-to <file>  → also writes a copy (e.g. ../abo-school-manager.html)
// Use it when you want a single file: drag the dist/single folder onto Netlify, or replace index.html on a site
// that already has the edge proxy. It still needs the API; opened from disk it explains how to reach the portal.
// The inline script and style are allowed by exact SHA-256 hashes in the Content-Security-Policy (no 'unsafe-inline').
// Build env (all optional, public values only): PUBLIC_SITE_URL, PUBLIC_API_BASE, CSP_IMG_SRC, HSTS_INCLUDE_SUBDOMAINS.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const zlib = require('node:zlib');
const esbuild = require('esbuild');

const ROOT = path.resolve(__dirname, '..');
const SRC = path.join(ROOT, 'web');
const OUT = process.env.WEB_OUT ? path.resolve(process.env.WEB_OUT) : path.join(ROOT, 'dist', 'single');
const copyIdx = process.argv.indexOf('--copy-to');
const COPY_TO = copyIdx > 0 ? path.resolve(process.argv[copyIdx + 1]) : null;
const sha = (t) => `'sha256-${crypto.createHash('sha256').update(t, 'utf8').digest('base64')}'`;
const origin = (v, name) => { if (!v) return ''; if (!/^https:\/\/[a-z0-9.-]+(:\d+)?$/i.test(v)) throw new Error(`${name} must be an https:// origin`); return v.replace(/\/+$/, ''); };

async function main() {
  const t0 = Date.now();
  const siteUrl = origin(process.env.PUBLIC_SITE_URL || '', 'PUBLIC_SITE_URL');
  const apiBase = origin(process.env.PUBLIC_API_BASE || '', 'PUBLIC_API_BASE');
  if (/\.(netlify\.app|onrender\.com|fly\.dev|up\.railway\.app|herokuapp\.com)$/i.test(apiBase)) throw new Error('PUBLIC_API_BASE on a shared platform domain would make the session cookie third-party — leave it empty (Netlify proxy)');

  // one bundle, no code splitting: the lazy page imports are folded into the same file
  const js = await esbuild.build({
    entryPoints: [path.join(SRC, 'assets/js/main.js')], bundle: true, splitting: false, format: 'esm', platform: 'browser',
    target: ['es2020', 'chrome90', 'firefox90', 'safari14'], minify: true, legalComments: 'none', charset: 'utf8', write: false, logLevel: 'warning',
    define: { __ABO_API_BASE__: JSON.stringify(apiBase), __ABO_SITE_URL__: JSON.stringify(siteUrl) },
  });
  let script = js.outputFiles[0].text.trim();
  if (/\bimport\s*\(\s*["'`]\.\.?\//.test(script)) throw new Error('a relative dynamic import survived bundling — the single file would try to load missing files');
  // keep the HTML parser from ending the script early (safe inside JS strings, regexes and templates)
  script = script.replace(/<\/(script)/gi, '<\\/$1').replace(/<!--/g, '<\\!--');

  const css = await esbuild.build({
    stdin: { contents: '@import "./tokens.css";\n@import "./app.css";\n', resolveDir: path.join(SRC, 'assets/css'), loader: 'css', sourcefile: 'bundle.css' },
    bundle: true, minify: true, write: false, loader: { '.svg': 'dataurl', '.png': 'dataurl' }, target: ['chrome90', 'firefox90', 'safari14'], logLevel: 'warning',
  });
  const style = css.outputFiles[0].text.trim().replace(/<\/(style)/gi, '<\\/$1');
  const icon = 'data:image/svg+xml;base64,' + fs.readFileSync(path.join(SRC, 'assets/img/favicon.svg')).toString('base64');
  const release = (process.env.COMMIT_REF || '').slice(0, 12) || crypto.createHash('sha256').update(script).digest('hex').slice(0, 10);

  // screen-layout lock + early install hook: a small classic script that must run before the page is drawn
  const layout = esbuild.transformSync(fs.readFileSync(path.join(SRC, 'assets/js/layout.js'), 'utf8'), { minify: true, target: 'es2015' }).code.trim().replace(/<\/(script)/gi, '<\\/$1');
  const imgExtra = (process.env.CSP_IMG_SRC || '').split(/[\s,]+/).filter((o) => /^https:\/\/[a-z0-9.-]+(:\d+)?$/i.test(o));
  const common = [`script-src ${sha(script)} ${sha(layout)}`, `style-src 'self' ${sha(style)}`, `img-src 'self' data: blob:${[apiBase, ...imgExtra].filter(Boolean).map((o) => ' ' + o).join('')}`,
    "font-src 'self' data:", `connect-src 'self'${apiBase ? ' ' + apiBase : ''}`, "object-src 'none'", "base-uri 'none'", "form-action 'self'"];
  const metaCsp = ["default-src 'self'", ...common].join('; ');                    // travels with the file itself
  const headerCsp = ["default-src 'self'", ...common, "frame-src 'none'", "frame-ancestors 'none'", "worker-src 'self'", "manifest-src 'self'", 'upgrade-insecure-requests'].join('; ');

  const html = `<!doctype html>
<html lang="en" data-release="${release}" data-build="single">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="color-scheme" content="light dark">
<meta name="referrer" content="strict-origin-when-cross-origin">
<meta http-equiv="Content-Security-Policy" content="${metaCsp}">
<meta name="robots" content="noindex, nofollow">
<meta name="description" content="A.B.O. School Manager — results, CBT, lesson notes, fees, attendance and parent portal.">
<title>A.B.O. School Manager</title>
<meta name="theme-color" content="#10263f">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="ABO School">
<link rel="icon" href="${icon}" type="image/svg+xml">
<link rel="manifest" href="/manifest.webmanifest">
<script>${layout}</script>
<style>${style}</style>
<script type="module">${script}</script>
</head>
<body>
<noscript>A.B.O. School Manager needs JavaScript enabled.</noscript>
<div id="app" class="boot"><div class="boot-mark">A.B.O.</div></div>
</body>
</html>
`;
  fs.rmSync(OUT, { recursive: true, force: true }); fs.mkdirSync(OUT, { recursive: true });
  fs.writeFileSync(path.join(OUT, 'index.html'), html);
  fs.writeFileSync(path.join(OUT, '_headers'), `/*
  Content-Security-Policy: ${headerCsp}
  Strict-Transport-Security: max-age=63072000${process.env.HSTS_INCLUDE_SUBDOMAINS === 'true' ? '; includeSubDomains' : ''}
  X-Content-Type-Options: nosniff
  X-Frame-Options: DENY
  Referrer-Policy: strict-origin-when-cross-origin
  Permissions-Policy: camera=(), microphone=(), geolocation=(self), payment=(), usb=(), interest-cohort=()
  Cross-Origin-Opener-Policy: same-origin
  Cross-Origin-Resource-Policy: same-origin
  X-Permitted-Cross-Domain-Policies: none
  X-Robots-Tag: noindex, nofollow, noarchive
  Cache-Control: no-cache
`);
  fs.writeFileSync(path.join(OUT, 'robots.txt'), 'User-agent: *\nDisallow: /\n');
  // install as an app when the folder is published: manifest, icons and the offline service worker sit next to index.html
  fs.copyFileSync(path.join(SRC, 'manifest.webmanifest'), path.join(OUT, 'manifest.webmanifest'));
  fs.cpSync(path.join(SRC, 'assets/img/icons'), path.join(OUT, 'assets/img/icons'), { recursive: true });
  fs.copyFileSync(path.join(SRC, 'sw.js'), path.join(OUT, 'sw.js'));

  // no secrets may ever be inside the file
  const SECRET = [/sk_(live|test)_[0-9a-zA-Z]{10,}/, /AKIA[0-9A-Z]{16}/, /-----BEGIN [A-Z ]*PRIVATE KEY-----/, /postgres(ql)?:\/\/[^\s'"]+:[^\s'"@]+@/, /xox[bap]-[0-9A-Za-z-]{10,}/,
    /(PROXY_SHARED_SECRET|CSRF_SECRET|DATA_ENCRYPTION_KEY|FILE_URL_SECRET|JWT_SECRET|PAYSTACK_SECRET_KEY)\s*[=:]\s*['"][^'"]{8,}/, /abo_(app|owner)_dev_password/];
  const hit = SECRET.find((re) => re.test(html)); if (hit) throw new Error(`possible secret in the single file (${hit})`);
  if (COPY_TO) { fs.mkdirSync(path.dirname(COPY_TO), { recursive: true }); fs.copyFileSync(path.join(OUT, 'index.html'), COPY_TO); }
  const kb = (n) => `${(n / 1024).toFixed(1)} kB`;
  console.log(`single-file build ok in ${Date.now() - t0} ms → ${path.relative(ROOT, path.join(OUT, 'index.html'))} (release ${release})`);
  console.log(`  size ${kb(Buffer.byteLength(html))} (${kb(zlib.gzipSync(html).length)} gzip) · JS ${kb(script.length)} · CSS ${kb(style.length)}`);
  console.log(`  CSP: inline script/style allowed by SHA-256 hash only · secret scan clean · API: ${apiBase || 'same origin /api/* (Netlify edge proxy)'}`);
  if (COPY_TO) console.log(`  copy → ${COPY_TO}`);
}
main().catch((e) => { console.error('single-file build FAILED:', e.message); process.exit(1); });
