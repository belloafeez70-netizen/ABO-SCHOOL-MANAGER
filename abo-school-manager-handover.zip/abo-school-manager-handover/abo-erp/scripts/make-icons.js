#!/usr/bin/env node
'use strict';
// Developer tool: draws the app icons (PNG) used by "Install app" on phones and computers, from the A.B.O. mark.
// Needs puppeteer (QA install): NODE_PATH=/tmp/qa/node_modules node scripts/make-icons.js [outDir]
// Output: icon-192.png, icon-512.png (rounded, "any"), maskable-512.png (full-bleed safe zone), apple-touch-icon.png (180), favicon-32.png
const fs = require('node:fs'); const path = require('node:path');
const puppeteer = require('puppeteer');
const OUT = path.resolve(process.argv[2] || path.join(__dirname, '../web/assets/img/icons'));
fs.mkdirSync(OUT, { recursive: true });
const mark = (scale) => `<g transform="translate(${32 - 32 * scale} ${32 - 32 * scale}) scale(${scale})"><path d="M16 44L32 16l16 28" fill="none" stroke="#d99a16" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/><path d="M22 36h20" stroke="#0fa37f" stroke-width="6" stroke-linecap="round"/></g>`;
const svg = (kind) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">${kind === 'any' ? '<rect width="64" height="64" rx="14" fill="#10263f"/>' : '<rect width="64" height="64" fill="#10263f"/>'}${mark(kind === 'maskable' ? 0.72 : kind === 'apple' ? 0.86 : 1)}</svg>`;
const jobs = [['icon-192.png', 192, 'any'], ['icon-512.png', 512, 'any'], ['maskable-512.png', 512, 'maskable'], ['apple-touch-icon.png', 180, 'apple'], ['favicon-32.png', 32, 'any']];
(async () => {
  const b = await puppeteer.launch({ headless: 'shell', args: ['--no-sandbox'] }); const p = await b.newPage();
  for (const [name, size, kind] of jobs) {
    await p.setViewport({ width: size, height: size, deviceScaleFactor: 1 });
    await p.setContent(`<html><body style="margin:0;background:transparent">${svg(kind).replace('<svg ', `<svg width="${size}" height="${size}" `)}</body></html>`);
    await p.screenshot({ path: path.join(OUT, name), omitBackground: true, clip: { x: 0, y: 0, width: size, height: size } });
    console.log('wrote', name);
  }
  await b.close();
})();
