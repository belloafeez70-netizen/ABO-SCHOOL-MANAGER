# Website parity — app.bolaolatprivatecollege.org.ng vs A.B.O. School Manager (v5.4, 30 Sep 2026)

This compares the app with the school's current portal, using only the website's **public** pages (login screens). Inner pages
of the website were not visible without an account.

| # | Limitation reported in v5.3 | Status in v5.4 | How it works now |
|---|---|---|---|
| 1 | Not deployed / not live | **Still open (needs you)** — tooling added | Hosting, domain, SMTP and Paystack live keys need the owner's accounts. New `npm run preflight` checks a production server before switch-over: NODE_ENV, https origin, secure cookies, DB TLS, RLS role, migrations, platform admin, no demo data, SMTP, storage, Paystack live/test, Redis, ClamAV. See `docs/DEPLOYMENT.md`. |
| 2 | No student sign-in with admission number | **Done** | Student tab accepts the admission number (case-insensitive, e.g. `BOPC/0001`). On the school's own page (`/#/s/<school>`) it is looked up inside that school only; on the general page it works only if exactly one account on the platform matches. |
| 3 | No parent sign-in with phone number | **Done** | Parent tab accepts the phone number in any Nigerian format (`0803…`, `+234 803…`, `234803…`, with spaces/dashes) from the guardian record (phone or WhatsApp). A number shared by two accounts is **refused** rather than guessed. |
| 4 | No Lesson Notes module | **Done** | Academics › Lesson Notes: write (assigned class/subject only), attach PDF/Word/PowerPoint/image, submit, review queue, approve / return with comment / reopen, coverage report with "not started" gaps, printable note with school header. Approved + shared notes appear for the class's students and parents. |
| 5 | One sign-in form instead of portal tabs | **Done** | Staff · Student · Parent tabs (Admin and Teacher are both "Staff" — same sign-in). Deep links for the school website: `/#/s/<school>?portal=student`, `?portal=parent`. The last tab used is remembered on the device. |
| 6 | Access code only via a separate "Activate" page | **Done** | Students/parents type the access code **in the password box** (like the website). The app then asks them to create a personal password and signs them straight in. The code works once; the website appears to let parents keep using a code — the app deliberately does not (a reusable code is a shared password). |

## Security notes for the new sign-in identifiers
* Identifier resolution runs in a `SECURITY DEFINER` function that returns only a Login ID — no data leaves before the password check.
* Same generic error for unknown account, wrong password, ambiguous phone, suspended membership (no account enumeration).
* Lockout, per-account-per-IP rate limits and the per-IP ceiling apply exactly as for Login ID sign-in.
* A valid access code never creates a session by itself; suspended/disabled accounts cannot activate with an old code.
* Tests: `server/test/portal_lesson_notes.test.js` (API) and `server/test/e2e/portal_lessons.qa.js` (real browser).

## Lesson Notes — rules enforced by the server
| Who | Can |
|---|---|
| Teacher (`lesson_notes.create`) | Write notes only for class/subjects assigned to them; edit/delete own draft or returned notes; submit |
| Head / Principal / VP / Owner / Administrator (`lesson_notes.review`) | Everything above for any class; review queue; approve; return (comment required); reopen approved notes; coverage report. **Cannot approve their own note.** |
| Exam officer (`lesson_notes.view`) | Read all notes and the coverage report |
| Student / Parent | Read **approved** notes marked "share with class" for their (children's) current class only; reviewer comments are never shown |

Notes are locked while under review and after approval; edits use optimistic versioning (two open windows cannot overwrite each other).
Every create / update / submit / approve / return / reopen / attachment / delete is written to the audit log.
