# Navigation menu (12 October 2026)

**Owner's request:** "three lines to open the menu on desktop, merge repeated menus, no Collapse, no small menu, professional."

## How it works

- **One three-line button (☰)** in the top bar shows or hides the **whole** menu.
  - **Computer:** the page then uses the full width, and the choice is remembered on that device.
  - **Phone:** the menu slides in. It closes with the **X** in its header, by tapping outside, or by choosing a page.
- **No icon-only "small menu" and no collapse arrow** any more.
- **Pages that belong together are one menu entry.** Their pages are shown as tabs at the top of the page (`web/assets/js/core/hubs.js`).
  - The entry opens the first tab the person may see.
  - The entry stays highlighted on every tab.
  - The chosen term and class are kept when switching tabs.
  - If a person may see only one tab, the entry carries that tab's name. Example: a teacher's Cashbook entry is called **Petty Cash**.
- **Other features:**
  - Search the menu with `Ctrl` + `/`. **Enter** opens the first match.
  - A breadcrumb shows in the top bar.
  - Phones get a bottom bar with four shortcuts plus **Menu**.
- **"Show full terms"** (office words instead of simple words) is now in the account menu, top right.
- **Permissions:** entries only appear when the person holds a permission for one of their pages. This is display only; the server checks every request again.

## Staff menu

| Category | Menu entry | Its pages (tabs) |
|---|---|---|
| Overview | Dashboard | — |
| | Reminders & Alerts | — |
| People | Students | Student List · Parents & Guardians · Promotion · Import · ID Cards |
| | Staff & Teachers | Teachers · Staff Records · Who Teaches What · Activity · Sign-in Accounts |
| | Calendar & Birthdays | School Calendar · Birthdays |
| Academics | Classes & Subjects | Classes & Arms · Subjects · Subject Allocation · School Years · Terms · Timetable |
| | Lessons & Materials | My Lesson Notes · Review Queue · All Lesson Notes · Coverage · Study Materials · Live Classes |
| | Attendance | Pupil Attendance · Staff Clock-in · Classes Right Now · Devices |
| Assessment | CBT Examinations | Overview · Examinations · Question Bank · Teachers' Questions · Candidates · Results · Analytics · Settings |
| | Scores & Results ▾ | Score Entry (CA / Exam) · Score Sheets · Result Workflow (3 steps) · Corrections · Comment Helper |
| | Reports ▾ | Class Broadsheet (5 tabs incl. Sheet Layout) · Cumulative Results · Report Cards (One Learner / Class / Print / PDF) · Analytics · Report Templates · Print Centre |
| Finance | Fees & Payments | Overview · Invoices · Payments & Receipts · Old Debts · Fee Setup |
| | Cashbook | Income & Expenses · Petty Cash · Categories |
| | School Store | Items & Stock · Sell Items · Sales & Receipts |
| Communication | Messages & Notices | Announcements · Messages |
| | School Documents | — |
| Settings | School Settings | Profile · Logo & Colours · Principal / Head · Grading & Rules · Web Address · Subscription |
| | Users & Roles | Users · Roles & Permissions · Sign In As Someone |
| | Activity & Security | Audit Logs · Security Events |
| | Backup & Data | Backup & Restore · Import & Export · From the Old App |
| Footer | Getting Started · Help & Support · System Information · current term | |

"Add Student", "Write Lesson Note" and "Create Examination" are buttons on their list pages, not menu entries. The Students list also has a **Full admission form** button.

Student and parent portals keep their own short menu (Dashboard, Results, CBT, Fees, Learning, Timetable & Calendar, Notices, Messages).
