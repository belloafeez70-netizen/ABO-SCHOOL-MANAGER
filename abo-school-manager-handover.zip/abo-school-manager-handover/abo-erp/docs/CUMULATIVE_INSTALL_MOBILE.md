# A.B.O. School Manager — Cumulative Results, Install as App, Phone Fixes

**Date:** 11 October 2026
**Applies to:** the server edition (`abo-erp`, the main product) and the offline edition (`school_broadsheet_manager_bopc_erp.html` and its website copy, `abo-school-site`).
**Backups made before any change:** `backups/2026-10-09-before-master-upgrade/*.before-cumulative-device`

This report covers the three things you asked for:

1. Cumulative results for the term and the session, for each subject and overall.
2. Installing the app on Chrome, Edge, Firefox, Safari and other browsers.
3. Phone problems:
   - Buttons and drop-downs that did not work well.
   - The page going back to the phone layout after you chose "Desktop site".

Everything listed under "Verified" was tested on this computer with real browsers. Anything not tested says so.

---

## 1. Cumulative results ("results so far this session")

### How it works (both editions)

| Term chosen | What is added up |
|---|---|
| 1st term | 1st term only. This is the same as the term result. |
| 2nd term | 1st term + 2nd term. This is the term cumulative. |
| 3rd term | 1st + 2nd + 3rd term. This is the whole-session (annual) result. |

**For each subject, the sheet shows:**
- The total for each term.
- The total marks so far.
- The cumulative average, grade and remark.
- The learner's cumulative position in that subject.
- The class average for each term and for the cumulative.

**Overall, the sheet shows:**
- Each term's average.
- The cumulative average and grade.
- The cumulative position. Ties share a place, so the order runs 1st, 2nd, 2nd, 4th.
- This term's position.
- How much the average went up or down since last term.
- Pass or fail.
- Total marks so far out of marks obtainable.

**One short, plain-English summary per learner.** It does not use "he" or "she", because the app does not guess gender. Example:

> "After the second term, Amaka's cumulative average is 68.88% (B), which is good. This term's average is 1.25 points lower than last term. Amaka is 1st of 12 in the class so far this session. Best subject so far: Yoruba (85.5%). Needs more attention: Agricultural Science (51.5%)."

**When a learner missed a term**, each school chooses one of two rules:
- **Divide by the terms the learner took.** This is the default and is fair to new pupils: 60 and 70 give 65.
- **Divide by every term the subject was taught.** The missed term counts as 0: 60 and 70 give 43.33.

The overall cumulative average is the average of the learner's subject cumulative averages. This is the same rule the Annual Broadsheet already used.

### Server edition — what was added

**New page:** *Broadsheets & Reports › Cumulative Results*. In simple words it is called "Results So Far (All Terms)".
- Choose the term and the class.
- Three views:
  - **Whole class**, with a switch between *Every term* and *Cumulative only*.
  - **One subject.**
  - **One learner.** This shows the facts, the summary, a term-average chart and a button to open the report card.
- Print (A4 landscape) and Excel (.xlsx) buttons.
- A badge shows when unpublished results are included.

**Report cards.** 2nd and 3rd term report cards now have a **"Results so far this session"** section, placed after the subject table:
- A subject table showing each term, total so far, cumulative average, grade, position and class average.
- Term averages.
- Cumulative average and position.
- The change since last term.
- The summary sentence.
- On 3rd term the title reads "Whole-session result".

**Parents and pupils:**
- They only ever see **published** terms and subjects, both in the cumulative section and on the report card.
- The *My results* page now has a **term picker**, so parents can open earlier report cards. Before this change it only showed the current term.

**Report Templates (settings)** has two new options:
- "Show results so far on 2nd and 3rd term report cards".
- The missed-term rule.
- The live preview shows the new section.

**API:**
- New: `GET /results/cumulative?termId&classId`. Needs `results.view`; the rate limit is 30 per minute.
- Changed: `/results/student/:id` now returns `cumulative` and `resultTerms`.
- Excel/CSV export: `/exports/cumulative`.
- A background export job now re-checks permission for the dataset itself, not only the export permission.

**Demo data:** BASIC 1A now has published 1st *and* 2nd term scores, and the scores vary between learners. Before, every third learner had identical scores, which made all the positions tie.

**Code:** the calculation is in `server/src/services/cumulative.js`, and it all runs on the server inside the school's own data (RLS). Results follow the learner, so a pupil who changed arm mid-session keeps their earlier scores.

### Offline edition — what was added

**New page:** *Assessment › Cumulative Results* ("Results So Far (All Terms)"). It has the same three views, plus Print and Excel (CSV).

The offline app keeps one term at a time. Earlier terms come from any of these:
1. **Old Results.** Press "Archive current term" at the end of each term. This is the easiest way.
2. **"Bring in from a backup file".** Use last term's normal backup (.json). The app checks that the session matches and that the term is earlier.
3. **"Type past term totals".** A grid of pupils and subjects. Totals must be between 0 and 100; wrong boxes turn red.

**Pupils are matched across terms** by admission number first, then by name. If a pupil is not found in an earlier term, the page says how many.

**Report cards:** 2nd and 3rd term report cards get the same "Results so far" section. It can be switched off on the page.

**Quick fix:** "Archive current term" now also saves the subject names. Before, if subjects changed between terms, archived scores could land on the wrong subject. Older archives are matched by subject order, and the page says so.

---

## 2. Install as an app

### Server edition

- Added:
  - A real app manifest.
  - App icons: 192, 512, a maskable icon and an Apple touch icon.
  - A theme colour.
  - Shortcuts: Cumulative, Type scores, My results.
- The existing offline support (service worker) was updated.
- **"Install app on this device"** is in the account menu and on the sign-in page.
  - **Chrome, Edge, Samsung Internet and Opera:** the button opens the browser's own install box.
  - **Safari and Firefox:** these browsers do not allow a button to install, so the app shows the exact steps for the browser being used, plus steps for the other common browsers.
- The menu item hides itself once the app is running installed.

### Offline website copy (`abo-school-site`)

- Now ships with:
  - `manifest.webmanifest`
  - `icons/`
  - `sw.js`, so the installed app **opens with no internet**.
- The new **"This device"** button in the top bar has "Install app on this device".
- A file opened from the phone's storage (`file://`) cannot be installed by any browser. The box explains this and points to the website copy.

### What each browser can do (checked October 2026)

| Browser | Install? |
|---|---|
| Chrome / Edge / Opera (Windows, Mac, Linux, Chromebook) | Yes, with the install box from our button. |
| Chrome / Edge / Samsung Internet (Android) | Yes, with the install box from our button. |
| Firefox (Android) | Yes, through the browser menu: "Add app to Home screen". The app shows the steps. |
| Safari (iPhone/iPad) and every iPhone browser | Yes: Share › "Add to Home Screen". The app shows the steps. |
| Safari 17+ (Mac) | Yes: File › "Add to Dock". |
| Firefox (Windows/Mac/Linux computers) | **No full install.** Firefox on Windows has an experimental "Add to taskbar" in Firefox Labs. The app tells the user this and suggests Chrome or Edge. |

---

## 3. Phone problems fixed

### a) "I switch to desktop mode and after a while it goes back to mobile mode"

**The cause.** Both apps choose their layout from the screen width. On a phone, the browser's "Desktop site" switch mostly changes the browser name the site sees, so the page kept drawing (or went back to) the phone layout. This happened after reloads, returning to the tab, turning the phone and sync refreshes.

**The fix, in both editions:**
- The layout choice is **remembered on the device** and applied *before the page is drawn*.
- It is re-applied after:
  - a reload,
  - going back,
  - returning to the tab,
  - turning the phone,
  - opening a new tab.
- **Automatic:**
  - On phones you get the phone layout and on computers the computer layout.
  - If the browser's "Desktop site" is on, the app notices (computer browser name on a small touch screen) and **uses the computer layout every time**.
- **Computer layout:** the page is drawn 1280 px wide with the full menu; pinch to zoom. It stays on until you change it.
- **Phone layout:** for tablets.
- **Where to change it:**
  - Server edition: account menu › "Screen: …".
  - Offline edition: the "This device" button in the top bar.

### b) Buttons and drop-downs on phones

- A new **phone tap test** opens every menu page on a 390×844 touch screen. On each page it checks:
  - The page does not slide sideways.
  - Every button, drop-down and input can be reached and is not hidden under another layer.
  - The "Add / New" dialogs fit the screen and close again.
  - The top-bar pop-ups fit the screen.
- **Offline edition — real defects found and fixed:**
  - The **class switcher** drop-down opened 188 px off the left edge of the phone, so half of it could not be tapped.
  - The **"Switch interface"** drop-down opened 51 px off the left edge.
  - Both now open inside the screen and scroll if they are long. The alerts pop-up is covered too.
- **Server edition:** the test found no blocked control on any page for six roles. Dialogs were still improved on phones:
  - They now use the visible screen height, so the browser bar can no longer hide the buttons.
  - They open from the bottom.
  - Their buttons wrap instead of running off the side.
  - Their buttons are taller and easier to tap.

---

## Test results (all run on this computer, 11 Oct 2026)

| Suite | Result |
|---|---|
| Server automated suite (`npm test`, 176 tests) | **175 passed, 0 failed.** 1 Redis test needs `TEST_REDIS_URL`; it was run separately: `deploy.test.js` **10/10**. |
| ↳ new `cumulative.test.js` (maths, ties, missed-term rule, parents see published only, report card on/off, Excel/CSV, permissions, other school blocked) | **7/7** |
| Server browser suites, each on a fresh demo database | menu **294/294** · menu clicks **253/253** · UI **71/71** · CBT **34/34** · portal **28/28** · school life **19/19** · shop/comments/ID cards **16/16** · materials/monitor **17/17** · migrate **8/8** · owner tools **14/14** · passkeys **9/9** |
| New server browser test: cumulative page, report card, parent term picker, template preview, phone | **25/25** |
| New server browser test: install + layout lock (Chrome reports *installable*; computer layout stays after reload, tab return, turning the phone, a new tab; "Desktop site" detected; a real laptop is unaffected) | **23/23** |
| New phone tap audit, server edition, 6 roles, every menu page, dialogs and pop-ups | **972/972** |
| Server errors in the log during all browser runs | **0** |
| Offline full regression (3 editions, 37 runs) | **37 runs, 0 failures** |
| New offline cumulative test (archive, backup import, typed totals with 0–100 check, report card, missed-term rule, CSV, phone) | **24/24** |
| New phone tap audit, offline edition, every menu page | **576/576** (it found the two off-screen drop-downs, which are now fixed) |
| New offline website-copy test (installable, opens with no internet, layout lock, "Desktop site") | **18/18** |
| Web build (`npm run build:web`) and single-file build | OK; secret scan clean; the manifest and layout script are included |

## Honest limits

- **Not tested on real phones.** Installing and "Desktop site" were checked in Chrome with phone emulation and Chrome's own installability check. iPhone/Safari and Firefox were not run; their steps come from current documentation.
- **Firefox on computers cannot install apps** (a browser limit, not ours).
- **The offline file opened from phone storage cannot be installed.** Use the website copy.
- **The offline cumulative depends on earlier terms being archived, imported or typed.** If none is there, the page explains the three ways.
- **The server demo now has published 2nd-term scores** while 1st term stays the current term. This is only so the demo shows cumulative results.
- **Still not live.** Deployment still needs your GitHub, Supabase, Render and Netlify accounts, as in the earlier handover.
