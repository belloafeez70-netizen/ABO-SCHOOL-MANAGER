# Phase 6, part 2: store, comment helper, ID cards (+ a quick fix in the offline app)

**Date:** 10 Oct 2026
**Status:** built and tested on this computer (sandbox). It is **not yet** on your real Supabase or live on the internet.

## In simple words

Three more features from the offline app now work in the **secure server edition**:

| Feature | Who can use it | Rules the server enforces |
|---|---|---|
| **School store** (items, stock, selling, receipts) | **Bursar, owner, principal, admin:** add items, set prices, receive stock, correct counts, void sales. **Accountant:** see and sell (cannot see cost prices). **Librarian:** see only. **Teachers:** no access. | <ul><li>The **browser only sends "which item, how many"**. The server sets the price and the total, and refuses any price sent by the browser.</li><li>**Stock can never go below 0.** When two tills sold the last 2 books at the same moment, one sale went through and the other was refused.</li><li>Every stock change (opening, received, sold, voided, corrected) is kept, and the **history always adds up to the stock count**. The database refuses to delete or change it.</li><li>Sales are **voided, never edited or deleted**. Voiding puts the items back in stock.</li><li>Receipts are numbered like `SAL-2026-000001`.</li><li>Pressing "Complete sale" twice still sells only once.</li><li>Store money is added to the Cashbook totals.</li></ul> |
| **Comment helper** for report cards | **Class teacher comments:** the class's form teacher, or anyone with `results.enter_any`. **Head comments:** reviewers only. | <ul><li>Suggested comments for the **whole class** at once, based on each pupil's average, best and weakest subject, and attendance. The wording comes from the offline app.</li><li>Pupils without a computed result get **no made-up comment**; they are flagged instead.</li><li>"Fill empty boxes" only fills **empty** boxes. Nothing is saved until you press **Save all**, and only changed comments are saved.</li><li>A pupil from another class cannot be slipped in.</li></ul> |
| **ID cards** (pupils and staff) | Pupil cards: anyone who can see pupil records. Staff cards: anyone who can see staff records. | <ul><li>Printable cards (bank-card size, 2 per row on A4) with the school logo, photo (or initials), class, parent's phone and session.</li><li>Each card has a **real Code-128 barcode** of the admission or staff number. I checked it against an independent barcode library: **8 of 8 samples are identical**, bar for bar. So gate scanners and phone scanner apps can read it.</li><li>Every print run is written in the audit log.</li></ul> |

**Offline app, quick fix:** the browser's grey **alert** pop-up is replaced by the app's own message box in all 3 versions. It looks professional, works with the keyboard, screen readers are told it is an alert, and attack text inside a message is shown as plain text. All 16 alerts in the app are final messages, so this is safe. The **confirm** and **prompt** boxes are unchanged, because the app waits for their answer; changing those needs the code around each one rewritten.

## Problem found and fixed while testing
- My first browser test of the comment helper **passed without really testing anything**: the demo pupils already had comments, so "Fill" and "Save" did nothing.
- I rewrote the test so it empties two boxes, fills them, edits one and saves. It then reloads the page and checks the exact saved words.
- It now really checks the feature and passes.

## Tests (all run on this computer)

| Test | Result |
|---|---|
| New server tests (`store_comments_idcards.test.js`) | **3/3** (about 70 checks: prices, stock, two tills at once, void, frozen history, roles, school-to-school isolation, comment rules, ID-card permissions) |
| Full server suite | **156 passed, 0 failed, 1 skipped** (that one needs Redis) |
| Browser test, store + comment helper + ID cards (`store_comments_idcards.qa.js`) | **16/16** |
| Menu test, every link for every role | **278/278** |
| Earlier server browser tests, run again | UI **71/71**, menu clicks **240/240**, CBT **34/34**, portal **28/28**, migration **7/7**, clock-in/calendar/cashbook **19/19** |
| Offline app: message box (`alert_box.js`), all 3 versions | **9/9** in each |
| Offline app: full regression, all 3 versions (37 runs) | **34 passed first time.** 3 failed because of the **tests**, not the app:<ul><li>`backup_guard` used a temporary folder the sandbox had wiped.</li><li>`alert_box` on the 2 classic versions signed in the wrong way (those versions use a password).</li></ul>All 3 tests were fixed and run again: **18/18, 9/9, 9/9**. Highlights: cloud 45/45, cloud2 36/36, roles 57/57, sign-in-as 25/25, security 19/19, two-device sync 11/11. "features" shows 36 checks instead of 37 because today is Saturday: the class monitor shows "Weekend" and makes 1 check instead of 2 |
| Barcode vs independent library (JsBarcode) | **8/8 identical** |

Screenshots are in `abo-erp/docs/screenshots/`:
- `phase6-store-items.png`
- `phase6-store-receipt.png`
- `phase6-comment-helper.png`
- `phase6-idcards.png`

## Files
- **Database:** `server/src/db/migrations/019_store_sales.sql`, plus a reverse script in `migrations/down/`. It only adds new tables; existing data is not touched.
- **API:**
  - `server/src/routes/store.js`
  - `server/src/routes/comments_idcards.js`
  - `server/src/services/comments.js`
  - Store sales were added to `/cashbook/summary`.
  - Permissions `store.view`, `store.manage`, `store.sell` and `store.void` were added and granted to the roles above.
- **Screens:**
  - `web/assets/js/pages/store.js`
  - `web/assets/js/pages/comments_idcards.js`
  - `web/assets/js/core/barcode.js`
  - Menu entries added: Students → ID Cards, Scores & Results → Comment Helper, Finance → School Store.
- **Offline app:**
  - `abo-erp/legacy/offline-pro-skin.js` and `.css` (message box), applied again to the 3 HTML files.
  - The old version is backed up in `backups/…/offline-pro-skin.js.before-phase6`.
- **Tests:**
  - `server/test/store_comments_idcards.test.js`
  - `server/test/e2e/store_comments_idcards.qa.js`
  - `.qa/alert_box.js`
  - `scripts/qa-barcode-check.mjs`

## Still to do in Phase 6 (part 3)
- **Still to move into the server edition:**
  - study materials, videos and live classes
  - class monitor
  - the "simple words" switch
  - school web address
  - Control Centre / sign-in-as (the server already has the platform team's audited, time-limited support view; an owner "sign in as" is still to do)
- **Server screens offline:** reading saved pages and queuing scores while offline.
- **Offline app:** turn the 45 confirm/prompt boxes into in-app dialogs (needs care with each call), and remove repeated functions.
