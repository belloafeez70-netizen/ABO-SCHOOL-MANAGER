# Audit of the existing application (`school_broadsheet_manager_bopc_erp.html`)

Audited before any change. The file is a single 1.16 MB HTML document (≈783 named functions, 102 `innerHTML` sinks,
3 `new Function` calls) built from the layered sources in `/home/user/app/` by `build.py`.

## 1. Inventory

| Area | What exists (legacy) | Where |
|---|---|---|
| Roles | owner, admin, teacher, student, parent (+ owner "view-as" all interfaces) | `currentUser.role` checks (≈70 places) |
| Login | **Login ID only, no password**; 10-day session in `localStorage.broadsheetSession` | login screen, `TEN_DAY_SESSION_MS` |
| School isolation | `localStorage` key `broadsheetData_<schoolName>` chosen from `currentUser.schoolName` | `getSchoolDataKey()` |
| Broadsheet / results | CA1 (20) + CA2 (20) + Exam (60), WAEC & primary grade scales, competition ranking, custom broadsheet designer, results archive, score-correction approvals | `computeGrade`, `recalculateAll`, `broadsheet-studio`, parity module |
| Students | per-class registers (`erp.learners{"BASIC 1A":[…]}`), max 100 per register, passports as data-URLs | `createStudent`, multiclass module |
| Classes | arms (BASIC 1A/1B), promotion map with undo, transfers | modules 93/94 |
| CBT | objective + theory questions, images (data-URLs), timer in the browser, **grading in the browser**, answer key in the page | `saveCBTExam`, `submit…` |
| Fees | fee charges, pricing/bank details, payment requests (manual) | parity module, `pricingData` |
| Communication | parent comments, newsletters (DOCX/PDF/PPTX import, stored as raw HTML), announcements with audience targeting | `parentMessages`, `newsletters` |
| Audit | `userAccounts.audit[]` array inside the same localStorage blob | `logAudit()` |
| AI | offline rule-based remarks; optional "online AI" with **user-entered API key stored in localStorage** | `aiSettings.apiKey` |
| Reports / export | Print Centre (13 documents), JSON backup/restore, CSV score import, ID cards | Print Centre, `exportBackup()` |
| Cloud sync | optional Firebase Realtime DB with pasted client config | `aboEdu/v1/schools/{id}/state` |
| UI | premium shell, five role workspaces, sub-dashboards, dark mode, Ctrl+K search | ui layer |

## 2. Where data lives (legacy)

**Everything is in the browser.** `localStorage` keys: `broadsheetData_<school>` (students, scores, accounts, CBT exams
*including answer keys*, submissions, messages, newsletters, audit log, AI key, pricing), `broadsheetData_pricing`,
`broadsheetSession`, `ownerSelectedSchool`, `aboViewAs`, `aboOverride`, `aboLoginGuard_<id>`, plus UI prefs.
No sessionStorage. Authorisation state (`currentUser`) lives in a JavaScript variable.

## 3. Security weaknesses found

| # | Weakness | Impact |
|---|---|---|
| S1 | No authentication secret at all (Login ID only); IDs are guessable | Anyone who knows/guesses an ID becomes that user |
| S2 | All authorisation in client JS (`currentUser.role === 'admin'`) | DevTools edit ⇒ full admin; owner ID hard-coded in source (`OWNER_LOGIN_ID`) |
| S3 | "School isolation" = which localStorage key is read, derived from `currentUser.schoolName` | Changing a variable exposes another school's blob on the same device; no isolation at all with Firebase sync unless rules are written |
| S4 | CBT answer keys shipped to students' browsers; score computed client-side | Trivial cheating / score forging |
| S5 | Results editable by anyone who can open DevTools; "approval" is a flag in the same blob | Silent result tampering |
| S6 | Audit log stored in the same editable blob | Tampering is undetectable |
| S7 | API key for online AI stored in localStorage and sent from the browser | Key theft; student data sent to third party without controls |
| S8 | 102 `innerHTML` sinks; newsletters stored and rendered as raw HTML | Stored XSS risk |
| S9 | Firebase config + path layout in the page; security depends on externally written DB rules | Mis-configured rules ⇒ public data |
| S10 | Passports/logos as data-URLs in the blob, SVG logos accepted | Script-capable SVG, storage bloat |
| S11 | No CSP, no security headers (file:// or static hosting) | No defence-in-depth against XSS/clickjacking |
| S12 | Payment details / approvals client-side | Fake "paid" status |

## 4. Scalability bottlenecks

* One JSON blob per school per device; whole school loaded into memory and re-serialised on every save.
* `localStorage` quota (~5–10 MB) → hard ceiling (hence `MAX_STUDENTS = 100` per register).
* No concurrency control: two teachers editing ⇒ last-write-wins on the entire blob.
* No server-side search, pagination or reporting; everything is O(school size) in the browser.

## 5. Migration plan (executed)

1. Keep the legacy file as the **offline edition** (unchanged) so no school loses access during migration.
2. Build a server-authoritative system: PostgreSQL + RLS (tenant isolation), Fastify API with server-side
   authN/authZ, Argon2id passwords, TOTP MFA, hash-chained audit log, object storage, background jobs.
3. Re-implement business logic on the server **with identical grading/ranking rules** (unit-tested for parity).
4. New modular frontend (no inline scripts, strict CSP) that preserves the visual identity and role workspaces.
5. Controlled import path: legacy "💾 Backup" JSON → preview → atomic commit (`/migration/legacy/*`), which
   deliberately drops API keys, pricing data and password-less accounts (schools issue access codes instead).
6. Prove it with automated tests (tenant isolation, RBAC, workflows, security) and browser QA.

See `FEATURE_MAP.md` for the per-feature outcome and `SECURITY.md` for how each weakness above is closed.
