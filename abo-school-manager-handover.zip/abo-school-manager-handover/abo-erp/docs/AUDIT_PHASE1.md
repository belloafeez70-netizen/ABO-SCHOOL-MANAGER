# Phase 1 — Code & architecture audit (9 Oct 2026)

Everything below was **measured or tested in this session**, unless it is marked *(assessment)*.

**Backup:** `backups/2026-10-09-before-master-upgrade/` contains the 4 app files, the setup SQL, the untouched
originals and the server source, with `SHA256SUMS`. Nothing was overwritten.

## A. What exists today
| Part | Technology | Where data lives | Who enforces permissions |
|---|---|---|---|
| **Main offline app** `school_broadsheet_manager_bopc_erp.html` | One 1.53 MB HTML file, 21,586 lines, 18 script blocks, 1,111 functions, 8 internet libraries | The browser (localStorage) on each device, plus an optional copy of the whole school in Supabase (one JSON record per school) | **The browser only** (JavaScript) |
| **Server edition** `abo-erp/` (v5.5) | Node/Fastify API + PostgreSQL (17 migrations) + web UI + Netlify config | PostgreSQL, normalised tables | **The server and the database**: Row Level Security per school, runtime DB role `abo_app` with NOBYPASSRLS, password hashing, lockout, rate limits, CSRF, audit |
| **Supabase project** `fehpqiqqxgqugioowepu` | Supabase (PostgreSQL) | Tables `abo_*` created by the setup script (older version) | Locked tables + secret-checked functions |

## B. Security findings: main offline app
| # | Finding | How it was tested | Severity |
|---|---|---|---|
| S1 | **Anyone can sign in as the owner** with the code shown in the page source (`OWNER_LOGIN_ID = '<owner login code — removed from the file on 11 Oct 2026>'`) | Fresh browser, typed the code → owner | **Critical** |
| S2 | **Editing the saved session in the browser gives owner access** | Wrote `broadsheetSession = {id: owner}` → reload → owner | **Critical** |
| S3 | **Roles are enforced only in JavaScript**; any user can change their role from the console | `currentUser.role = 'owner'` → accepted | **Critical** *(by design of an offline app)* |
| S4 | **Stored XSS through pupil names**: attack text in a pupil's name ran **19 times on 5 pages** (Report Cards, dashboard, CBT, Newsletters, Parent page). Staff, announcements, lesson notes, messages, finance and account fields were safe. | `qa/audit_xss.js` opened 94 owner pages plus all 4 role screens | **High** |
| S5 | **Every linked device holds the whole school**, including fees and staff details, and the phone-link code carries the school secret (full read/write of the school record in Supabase) | Code review + the earlier cloud tests | **High** |
| S6 | **8 of 8 internet libraries load without an integrity check (SRI)**: supply-chain risk | Static scan | Medium |
| S7 | **803 inline event handlers + 120 `innerHTML` writes**, so a strict Content-Security-Policy is not possible without refactoring | Static scan | Medium |
| S8 | **Login is by code only**: no password for staff, pupils or parents | Code review / tests | **High** |
| S9 | **Supabase secret-checked functions have no rate limit** beyond a 0.5 s delay on a wrong secret. The secret is 20 random characters, so guessing is impractical, but nothing stops parallel attempts. | Code review | Low |

**Conclusion (S1–S3, S5, S8):** these cannot be fixed inside a browser-only app. Whoever controls the device
controls the data. Real security needs the permission checks on a server or in the database. That is exactly
what the server edition already does.

## C. Scalability findings: main offline app
| Measurement | Result |
|---|---|
| Size of one learner with 17 subjects | about **3.4 KB** |
| Largest roster that fits in one browser's storage | **about 2,000 learners**; 4,000 failed with "quota exceeded" |
| The owner's device keeps every school locally (Online Backup) | The device fills up at about 2,000 learners **in total**, so this architecture **cannot reach 1,000 schools** |
| Whole-school record syncs as one JSON document | Fine for one school; large or busy schools mean big uploads and more merges *(assessment)* |
| Start-up | 0.4 s to the sign-in screen (good) |

## D. Code-quality findings: main offline app
- **Redefinitions:** some functions are defined 4–6 times (`save`, `applyRoleAccess`, `renderRoleDashboard`,
  `showPage`…). Later copies silently override earlier ones, so fixes land in the wrong copy unless traced. *(It works
  today; this is a maintainability risk.)*
- **Dialogs:** 60 `confirm/prompt/alert` calls. They are blocked in sandboxed previews and look unprofessional.
- **Online-only features:** 8 libraries come from internet CDNs, so PDF/Word/picture exports need internet the first time.
- **Fixed earlier in this project, with tests:**
  - data wipe on sign-in
  - phone menu
  - blank record pages
  - phone login layout
  - access leaks (Print Centre etc.)
  - preview faithfulness
  - fake activity-log changes

## E. Server edition: verified now
- `npm test`: **146 passed, 0 failed, 1 skipped** (the skipped one needs Redis), run in this session against
  PostgreSQL 17.
- It includes the tests `tenant.test.js` (school isolation), `security.test.js`, `rbac.test.js` and `auth.test.js`.
- **Supabase compatibility (code review):** tenant context is set per transaction with `set_config(..., true)`, and
  locks are transaction-scoped, so it works with Supabase's transaction pooler. Migrations use a session lock, so they
  must run over the direct connection.
- **Missing compared with the main app:**
  - staff clock-in with fingerprint/GPS, the live class monitor, birthdays, the live calendar
  - ID cards
  - petty cash, store, sales, chart of accounts, income/expenses/cashbook
  - study materials, videos, online classes
  - the comment helper
  - offline mode
  - simple words, school web address, Control Centre / sign-in-as
- It already has an import from the main app's backup file (`/migration/legacy`).

## F. Supabase project: verified live (read-only)
- Reachable. Tables are locked from the public key.
- The setup functions up to the activity log exist; the web-address functions are missing (the newest script was not
  run).
- **No production data was written by these checks.**
