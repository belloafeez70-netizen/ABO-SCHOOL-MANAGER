# Phase 2 — Backup & prioritised remediation plan (9 Oct 2026)

**Backup done:** `backups/2026-10-09-before-master-upgrade/` with SHA-256 checksums. The originals stay untouched in
`legacy-originals/`.

## Decisions (approved by the owner, 9 Oct 2026)
- **Architecture:** server edition + the owner's Supabase PostgreSQL + Netlify front end. The offline file stays as
  an offline tool and gets the quick safety fixes.
- **API host:** Render.
- **Verifying against the real Supabase database:** the owner shares a temporary database password once and resets
  it afterwards.

## The architecture decision
The master prompt asks for server-side authorisation, school-level isolation in the database, secure sessions, and
1,000+ schools / 200,000+ users. The audit shows:
- **The main offline file cannot meet these requirements.** Whoever holds the device holds the data (S1–S3, S5), and
  browser storage fills up at about 2,000 learners.
- **The server edition already implements the secure foundation** and passes 146 tests: PostgreSQL with Row Level
  Security per school, permissions checked on the server, password hashing, lockout, rate limiting, CSRF, audit, and a
  legacy-data import.

**Recommended target:**

```
Phones / computers ──https──► Netlify (web app + security headers, edge proxy /api → API)
                                   │
                                   ▼
                       ABO API (Node/Fastify, the server edition) on Render / Railway / Fly
                       – sign-in, sessions, permissions, validation, rate limits, audit
                                   │  DATABASE_URL (secret, server only)
                                   ▼
                       Supabase PostgreSQL (your project) – tables, RLS per school, backups
```

- **Supabase** is the database: managed PostgreSQL with backups. The API connects with a restricted role
  (`abo_app`, NOBYPASSRLS).
- **No database password or secret key is ever sent to browsers.**
- **The main offline file stays** as the offline/single-device tool. It is clearly labelled as not secure for
  multi-user use, keeps its "Export backup → Import into server" path, and gets the quick safety fixes below.
- **The main app's extra features are moved into the server edition** in Phase 6, each with server-side permissions and
  tests.

The alternatives were considered and rejected:
- **Rewrite the 1.5 MB offline file on Supabase Auth with per-table RLS:** the largest effort and the highest risk to
  existing features, and it would duplicate rules the server already enforces.
- **Only harden the offline file:** it can never meet "enforce permissions on the server".

## Prioritised plan
| Priority | Work | Phase | Verification |
|---|---|---|---|
| **P0** | Fix stored XSS in pupil names (S4) in the offline file | 3 | XSS probe → 0 runs |
| **P0** | Offline file: remove the owner code from the source; owner sign-in needs a password (hashed, PBKDF2); a forged session can no longer become owner without that password | 3 | Escalation tests S1/S2 fail to escalate *(raises the bar only; a device owner can still edit local data)* |
| **P0** | Server edition on **your Supabase**: bootstrap roles, run 17 migrations, check RLS isolation **against the real Supabase database** | 4 | Isolation tests against Supabase (two schools, cross-reads refused) |
| **P1** | Deploy the API (Render, `render.yaml` exists) with `DATABASE_URL` in the host's secret settings; Netlify front end with edge proxy and security headers | 8 | Live checks: `/api/v1/public/status`, sign-in, headers, HTTPS |
| **P1** | Import the existing school data from the offline file into the server (`/migration/legacy`) and check counts | 5 | Learners, scores, payments etc. counted before vs after |
| **P1** | Add SRI hashes or bundle the 8 libraries locally (offline file + server UI) | 6 | Static scan shows 0 unpinned libraries |
| **P2** | Move the offline file's extra modules into the server edition, each with API permissions and tests: clock-in (fingerprint/GPS), class monitor, birthdays, calendar, ID cards, petty cash/store/sales/accounts, study materials, comment helper, simple words, school web address, Control Centre | 6 | API tests + browser tests per module |
| **P2** | Offline support for the server UI: a service worker for reading cached pages and a queued score/attendance entry | 5–6 | Offline → online browser test |
| **P2** | Load test with synthetic data (1,000 schools, 200,000 users) on PostgreSQL, measuring p50/p95 latency and throughput | 7 | Report with measured numbers. Production capacity depends on the Supabase/host plan and will not be claimed beyond the test. |
| **P3** | Replace `alert/confirm/prompt` with in-app dialogs; remove duplicate function definitions; accessibility pass | 6 | Browser tests + automated accessibility check |

## What the owner must do (manual actions)
1. **Approve the architecture above** (or choose an alternative).
2. **Choose and create the API host account** (Render recommended; a free plan sleeps when idle, so a paid plan
   avoids slow first loads).
3. **Database connection strings:** in Supabase → Connect, copy the **direct** connection string (port 5432, for
   migrations) and the **transaction pooler** string (port 6543, for the API).
   - Paste them **only into the host's secret environment settings**, never into chat or the app.
   - If you want me to verify migrations and isolation against your real database from here, create a temporary
     database password, share it once, then rotate it afterwards.
4. **Run the newest `abo_supabase_setup.sql`** (only needed while the offline file's Online Backup is still in use).
5. Later, for live features: an SMTP account (e-mail), Paystack keys (payments), and a domain (optional).
