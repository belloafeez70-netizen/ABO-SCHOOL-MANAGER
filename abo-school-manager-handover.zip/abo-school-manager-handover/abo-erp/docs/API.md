# A.B.O. School Manager — REST API v1

Generated from the running route registry (`node scripts/gen-api-doc.js`). 312 endpoints.

* Base path `/api/v1`, JSON only (uploads: multipart/form-data). Every body schema rejects unknown fields.
* Auth: HttpOnly session cookie + `X-CSRF-Token` header on POST/PUT/PATCH/DELETE (token from `GET /auth/me`).
* Tenant = the signed-in user's school, resolved on the server. Permission column = user needs ANY of the listed permissions; ownership checks (own class/subject/child) are applied inside handlers.
* Errors: `{ "error": { "code", "message", "details?", "requestId" } }` — never stack traces, SQL or echoed input. Foreign/unknown ids answer a non-revealing 404.

## Error codes

| HTTP | code | Meaning / client action |
|---|---|---|
| 400 | `VALIDATION_FAILED` | Body/query failed the schema; `details.field` names the field. |
| 400 | `BAD_REQUEST` | Malformed request (bad JSON, bad URL encoding, unsupported format). |
| 400 | `BAD_IDEMPOTENCY_KEY` | Idempotency-Key must be 8–80 chars of letters, digits, _ or -. |
| 400 | `MFA_INVALID` | Wrong/expired authenticator or recovery code (during enrolment). |
| 401 | `UNAUTHENTICATED` | No/expired session — sign in again. |
| 401 | `INVALID_CREDENTIALS` | Generic sign-in failure (never says which part was wrong). |
| 401 | `MFA_INVALID` | Wrong authenticator code at sign-in. |
| 403 | `FORBIDDEN` | Signed in but lacks the permission / ownership. |
| 403 | `NO_ACTIVE_MEMBERSHIP` | Account has no active membership in the selected school. |
| 403 | `SCHOOL_INACTIVE` | School is pending or suspended by the platform. |
| 404 | `NOT_FOUND` | Unknown id, or an id belonging to another school (deliberately indistinguishable). |
| 409 | `CONFLICT` | Duplicate, stale version (reload and retry), or invalid state transition. |
| 409 | `NOT_CONFIGURED` | Feature not set up for this school/server yet (e.g. online payments). Not an outage. |
| 413 | `PAYLOAD_TOO_LARGE / FILE_TOO_LARGE` | Body or upload over the limit. |
| 414 | `URI_TOO_LONG` | A path parameter is longer than any valid id. |
| 415 | `UNSUPPORTED_MEDIA_TYPE` | Wrong Content-Type (JSON or multipart only). |
| 422 | `IDEMPOTENCY_KEY_REUSED` | Same Idempotency-Key sent with a different body. |
| 423 | `LOCKED` | Record is locked (approved/published results, closed exam, locked account). |
| 429 | `RATE_LIMITED` | Slow down; respect Retry-After. |
| 500 | `INTERNAL` | Unexpected server error — quote the requestId to support. |
| 502 | `UPSTREAM_UNAVAILABLE` | A third-party provider (e.g. Paystack) failed; safe to retry later. |
| 503 | `TIMEOUT` | Database statement timeout; retry. |

## academic

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/academic` | session | `academic.view` `timetable.view_own` | global |
| GET | `/academic/class-presets` | session | `academic.view` `timetable.view_own` | global |
| POST | `/academic/classes` | session | `academic.manage` | global |
| PATCH | `/academic/classes/:id` | session | `academic.manage` | global |
| DELETE | `/academic/classes/:id` | session | `academic.manage` | global |
| GET | `/academic/classes/:id/subjects` | session | `academic.view` `timetable.view_own` | global |
| PUT | `/academic/classes/:id/subjects` | session | `academic.manage` | global |
| GET | `/academic/classes/:id/timetable` | session | `academic.view` `timetable.view_own` | global |
| PUT | `/academic/classes/:id/timetable` | session | `academic.manage` | global |
| PUT | `/academic/classes/order` | session | `academic.manage` | global |
| POST | `/academic/classes/presets` | session | `academic.manage` | global |
| POST | `/academic/promotion` | session | `promotion.run` | global |
| POST | `/academic/promotion/:id/undo` | session | `promotion.run` | global |
| POST | `/academic/sessions` | session | `academic.manage` | global |
| POST | `/academic/sessions/:id/current` | session | `academic.manage` | global |
| POST | `/academic/subjects` | session | `academic.manage` | global |
| DELETE | `/academic/subjects/:id` | session | `academic.manage` | global |
| PATCH | `/academic/terms/:id` | session | `academic.manage` | global |

## ai

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| POST | `/ai/remark-suggestion` | session | `ai.use` | 30/1 minute |

## announcements

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/announcements` | session | `announcements.view` `announcements.manage` | global |
| POST | `/announcements` | session | `announcements.manage` | global |
| DELETE | `/announcements/:id` | session | `announcements.manage` | global |
| POST | `/announcements/:id/email` | session | `announcements.manage` | 5/1 minute |
| POST | `/announcements/:id/publish` | session | `announcements.manage` | global |
| POST | `/announcements/:id/read` | session | `announcements.view` | global |
| GET | `/announcements/:id/share` | session | `announcements.manage` | global |

## attendance

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/attendance/class/:id` | session | `attendance.view` `attendance.create` `attendance.update` | global |
| PUT | `/attendance/class/:id` | session | `attendance.create` `attendance.update` | global |
| GET | `/attendance/student/:id` | session | `attendance.view` `results.view_own` `results.view_children` | global |
| GET | `/attendance/summary` | session | `attendance.view` `attendance.create` `attendance.update` | global |

## audit

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/audit` | session | `audit_logs.view` | global |
| GET | `/audit/verify` | session | `audit_logs.view` | global |

## auth

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| POST | `/auth/act-as` | session | `users.impersonate` | 10/10 minutes |
| GET | `/auth/act-as/candidates` | session | `users.impersonate` | global |
| POST | `/auth/act-as/stop` | session | (any signed-in user; ownership checked) | global |
| POST | `/auth/activate` | public | — | 10/1 minute |
| POST | `/auth/login` | public | — | 10/1 minute |
| POST | `/auth/logout` | session | (any signed-in user; ownership checked) | global |
| POST | `/auth/logout-all` | session | (any signed-in user; ownership checked) | global |
| GET | `/auth/me` | session | (any signed-in user; ownership checked) | global |
| GET | `/auth/memberships` | session | (any signed-in user; ownership checked) | global |
| POST | `/auth/memberships/:id/respond` | session | (any signed-in user; ownership checked) | global |
| POST | `/auth/mfa/disable` | session | (any signed-in user; ownership checked) | 10/1 minute |
| POST | `/auth/mfa/enable` | session | (any signed-in user; ownership checked) | 10/1 minute |
| POST | `/auth/mfa/setup` | session | (any signed-in user; ownership checked) | global |
| POST | `/auth/mfa/verify` | session | (any signed-in user; ownership checked) | 10/1 minute |
| POST | `/auth/password/change` | session | (any signed-in user; ownership checked) | 10/1 minute |
| POST | `/auth/password/forgot` | public | — | 5/15 minutes |
| POST | `/auth/password/reset` | public | — | 10/1 minute |
| GET | `/auth/sessions` | session | (any signed-in user; ownership checked) | global |
| DELETE | `/auth/sessions/:id` | session | (any signed-in user; ownership checked) | global |
| POST | `/auth/switch-school` | session | (any signed-in user; ownership checked) | 30/1 minute |
| POST | `/auth/verify-email` | public | — | 10/15 minutes |

## billing

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/billing` | session | `settings.view` | global |
| POST | `/billing/checkout` | session | `settings.update` | 10/1 minute |
| POST | `/billing/verify` | session | `settings.view` | 20/1 minute |
| POST | `/billing/webhook/paystack` | HMAC signature | — | 300/1 minute |

## birthdays

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/birthdays` | session | `birthdays.view` | global |

## calendar

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/calendar` | session | `calendar.view` | global |
| POST | `/calendar` | session | `calendar.manage` | global |
| PATCH | `/calendar/:id` | session | `calendar.manage` | global |
| DELETE | `/calendar/:id` | session | `calendar.manage` | global |

## cashbook

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/cashbook/categories` | session | `cashbook.view` | global |
| POST | `/cashbook/categories` | session | `cashbook.record` | global |
| PATCH | `/cashbook/categories/:id` | session | `cashbook.record` | global |
| GET | `/cashbook/entries` | session | `cashbook.view` | global |
| POST | `/cashbook/entries` | session | `cashbook.record` | global |
| POST | `/cashbook/entries/:id/void` | session | `cashbook.void` | global |
| GET | `/cashbook/summary` | session | `cashbook.view` | global |

## cbt

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/cbt/analytics` | session | `cbt.results` | global |
| PUT | `/cbt/attempts/:id/answers` | session | `cbt.take` | 240/1 minute |
| POST | `/cbt/attempts/:id/focus-loss` | session | `cbt.take` | 60/1 minute |
| POST | `/cbt/attempts/:id/grade` | session | `cbt.grade` | global |
| GET | `/cbt/attempts/:id/paper` | session | `cbt.take` | 60/1 minute |
| POST | `/cbt/attempts/:id/reset` | session | `cbt.publish` | global |
| GET | `/cbt/attempts/:id/result` | session | `cbt.take` | global |
| GET | `/cbt/attempts/:id/review` | session | `cbt.grade` `cbt.results` | global |
| POST | `/cbt/attempts/:id/submit` | session | `cbt.take` | 20/1 minute |
| GET | `/cbt/available` | session | `cbt.take` | 120/1 minute |
| GET | `/cbt/bank` | session | `cbt.view` | global |
| POST | `/cbt/bank` | session | `cbt.create` | global |
| GET | `/cbt/bank/:id` | session | `cbt.view` | global |
| PATCH | `/cbt/bank/:id` | session | `cbt.update` `cbt.create` | global |
| DELETE | `/cbt/bank/:id` | session | `cbt.update` `cbt.create` | global |
| POST | `/cbt/bank/:id/archive` | session | `cbt.update` `cbt.create` | global |
| POST | `/cbt/bank/:id/duplicate` | session | `cbt.create` | global |
| GET | `/cbt/bank/export` | session | `cbt.view` | global |
| POST | `/cbt/bank/import/:id/commit` | session | `cbt.create` | global |
| POST | `/cbt/bank/import/preview` | session | `cbt.create` | 20/1 minute |
| GET | `/cbt/bank/import/template.csv` | session | `cbt.create` | global |
| GET | `/cbt/bank/topics` | session | `cbt.view` | global |
| GET | `/cbt/dashboard` | session | `cbt.view` | global |
| GET | `/cbt/exams` | session | `cbt.view` | global |
| POST | `/cbt/exams` | session | `cbt.create` | global |
| GET | `/cbt/exams/:id` | session | `cbt.view` | global |
| PATCH | `/cbt/exams/:id` | session | `cbt.update` | global |
| DELETE | `/cbt/exams/:id` | session | `cbt.update` | global |
| GET | `/cbt/exams/:id/analytics` | session | `cbt.results` | global |
| GET | `/cbt/exams/:id/attempts` | session | `cbt.results` | global |
| GET | `/cbt/exams/:id/candidates` | session | `cbt.view` | global |
| POST | `/cbt/exams/:id/candidates` | session | `cbt.update` | global |
| DELETE | `/cbt/exams/:id/candidates` | session | `cbt.update` | global |
| POST | `/cbt/exams/:id/close` | session | `cbt.publish` | global |
| POST | `/cbt/exams/:id/from-bank` | session | `cbt.update` | global |
| POST | `/cbt/exams/:id/generate` | session | `cbt.update` | global |
| PUT | `/cbt/exams/:id/order` | session | `cbt.update` | global |
| POST | `/cbt/exams/:id/publish` | session | `cbt.publish` | global |
| POST | `/cbt/exams/:id/push-scores` | session | `cbt.publish` | global |
| POST | `/cbt/exams/:id/questions` | session | `cbt.update` `cbt.create` | global |
| POST | `/cbt/exams/:id/release` | session | `cbt.publish` | global |
| GET | `/cbt/exams/:id/results` | session | `cbt.results` | global |
| POST | `/cbt/exams/:id/start` | session | `cbt.take` | 20/1 minute |
| POST | `/cbt/images` | session | `cbt.create` `cbt.update` | 60/1 minute |
| GET | `/cbt/my-results` | session | `cbt.take` | global |
| PATCH | `/cbt/questions/:id` | session | `cbt.update` | global |
| DELETE | `/cbt/questions/:id` | session | `cbt.update` | global |
| POST | `/cbt/results/:id/release` | session | `cbt.publish` | global |
| POST | `/cbt/results/:id/withhold` | session | `cbt.publish` | global |
| GET | `/cbt/settings` | session | `cbt.view` | global |
| PUT | `/cbt/settings` | session | `settings.update` `cbt.publish` | global |

## client-errors

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| POST | `/client-errors` | public | — | 20/1 minute |

## clock

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| POST | `/clock/in` | session | `clock.use` | 20/1 minute |
| GET | `/clock/me` | session | `clock.use` | global |
| POST | `/clock/out` | session | `clock.use` | 20/1 minute |
| POST | `/clock/passkeys` | session | `clock.use` | global |
| DELETE | `/clock/passkeys/:id` | session | `clock.use` `clock.manage` | global |
| POST | `/clock/passkeys/clock-options` | session | `clock.use` | 30/1 minute |
| POST | `/clock/passkeys/register-options` | session | `clock.use` | 20/10 minutes |
| GET | `/clock/register` | session | `clock.view` | global |
| GET | `/clock/settings` | session | `clock.manage` `clock.view` | global |
| PUT | `/clock/settings` | session | `clock.manage` | global |

## dashboard

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/dashboard` | session | (any signed-in user; ownership checked) | global |

## documents

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/documents` | session | `documents.view` | global |
| POST | `/documents` | session | `documents.upload` | 30/1 minute |
| DELETE | `/documents/:id` | session | `documents.delete` | global |

## exports

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/exports/:dataset` | session | `reports.export` | 30/1 minute |

## fees

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/fees/categories` | session | `fees.view` | global |
| POST | `/fees/categories` | session | `fees.create` | global |
| PATCH | `/fees/categories/:id` | session | `fees.update` | global |
| GET | `/fees/discounts` | session | `fees.view` | global |
| POST | `/fees/discounts` | session | `fees.create` | global |
| POST | `/fees/discounts/:id/review` | session | `fees.approve` | global |
| DELETE | `/fees/invoice-items/:id` | session | `fees.update` | global |
| GET | `/fees/invoices` | session | `fees.view` | global |
| GET | `/fees/invoices/:id` | session | `fees.view` `fees.view_own` `fees.view_children` | global |
| POST | `/fees/invoices/:id/items` | session | `fees.update` | global |
| POST | `/fees/invoices/:id/pay-online` | session | `fees.view_own` `fees.view_children` `payments.record` | 10/1 minute |
| POST | `/fees/invoices/:id/void` | session | `fees.update` | global |
| POST | `/fees/invoices/generate` | session | `fees.create` | 10/1 minute |
| GET | `/fees/my` | session | `fees.view_own` `fees.view_children` | global |
| POST | `/fees/payments` | session | `payments.record` | 60/1 minute |
| GET | `/fees/payments` | session | `fees.view` | global |
| POST | `/fees/payments/:id/reverse` | session | `payments.reverse` | global |
| GET | `/fees/receipts/:id` | session | `fees.view` `fees.view_own` `fees.view_children` | global |
| GET | `/fees/structures` | session | `fees.view` | global |
| POST | `/fees/structures` | session | `fees.create` | global |
| PATCH | `/fees/structures/:id` | session | `fees.update` | global |
| GET | `/fees/summary` | session | `fees.view` | 30/1 minute |

## files

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/files/:id` | session | (any signed-in user; ownership checked) | global |

## guardians

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/guardians` | session | `guardians.view` | global |
| POST | `/guardians` | session | `guardians.manage` | global |
| PATCH | `/guardians/:id` | session | `guardians.manage` | global |
| PUT | `/guardians/:id/students` | session | `guardians.manage` | global |

## id-cards

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/id-cards/staff` | session | `staff.view` | global |
| GET | `/id-cards/students` | session | `students.view` | global |

## imports

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| POST | `/imports/:id/commit` | session | `imports.run` | global |
| GET | `/imports/:id/errors.csv` | session | `imports.run` | global |
| POST | `/imports/:kind/preview` | session | `imports.run` | 20/1 minute |
| GET | `/imports/templates/:kind.csv` | session | `imports.run` | global |

## jobs

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/jobs/:id` | session | (any signed-in user; ownership checked) | global |

## lesson-notes

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/lesson-notes` | session | `lesson_notes.create` `lesson_notes.view` `lesson_notes.review` | global |
| POST | `/lesson-notes` | session | `lesson_notes.create` `lesson_notes.review` | 60/1 minute |
| GET | `/lesson-notes/:id` | session | `lesson_notes.create` `lesson_notes.view` `lesson_notes.review` `lesson_notes.view_own` `lesson_notes.view_children` | global |
| PATCH | `/lesson-notes/:id` | session | `lesson_notes.create` `lesson_notes.review` | global |
| DELETE | `/lesson-notes/:id` | session | `lesson_notes.create` `lesson_notes.review` | global |
| POST | `/lesson-notes/:id/attachment` | session | `lesson_notes.create` `lesson_notes.review` | 30/1 minute |
| POST | `/lesson-notes/:id/reopen` | session | `lesson_notes.review` | global |
| POST | `/lesson-notes/:id/review` | session | `lesson_notes.review` | global |
| POST | `/lesson-notes/:id/submit` | session | `lesson_notes.create` `lesson_notes.review` | global |
| GET | `/lesson-notes/options` | session | `lesson_notes.create` `lesson_notes.review` | global |
| GET | `/lesson-notes/summary` | session | `lesson_notes.view` `lesson_notes.review` | global |

## live-classes

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/live-classes` | session | `materials.view` `materials.create` `materials.manage` `materials.view_own` `materials.view_children` | global |
| POST | `/live-classes` | session | `materials.create` `materials.manage` | global |
| POST | `/live-classes/:id/cancel` | session | `materials.create` `materials.manage` | global |

## materials

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/materials` | session | `materials.view` `materials.create` `materials.manage` `materials.view_own` `materials.view_children` | global |
| POST | `/materials` | session | `materials.create` `materials.manage` | global |
| DELETE | `/materials/:id` | session | `materials.create` `materials.manage` | global |
| POST | `/materials/file` | session | `materials.create` `materials.manage` | 30/1 minute |
| GET | `/materials/options` | session | `materials.create` `materials.manage` | global |

## messages

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/messages/contacts` | session | `messages.use` | global |
| GET | `/messages/threads` | session | `messages.use` | global |
| POST | `/messages/threads` | session | `messages.use` | 20/1 minute |
| GET | `/messages/threads/:id` | session | `messages.use` | global |
| POST | `/messages/threads/:id` | session | `messages.use` | 60/1 minute |

## migration

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| POST | `/migration/legacy/:id/commit` | session | `imports.run` | 10/1 minute |
| POST | `/migration/legacy/preview` | session | `imports.run` | 10/1 minute |

## monitor

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/monitor/now` | session | `clock.view` | global |

## my

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/my/lesson-notes` | session | `lesson_notes.view_own` `lesson_notes.view_children` | global |

## newsletters

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/newsletters` | session | `announcements.view` `announcements.manage` | global |

## notifications

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/notifications` | session | (any signed-in user; ownership checked) | global |
| POST | `/notifications/read` | session | (any signed-in user; ownership checked) | global |

## onboarding

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| POST | `/onboarding/register` | public | — | 5/1 hour |
| GET | `/onboarding/status` | session | `settings.view` | global |

## openapi.json

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/openapi.json` | public | — | global |

## payments

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| POST | `/payments/webhook/paystack` | HMAC signature | — | 300/1 minute |

## permissions

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/permissions` | session | `roles.view` | global |

## platform

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/platform/billing/payments` | platform admin | `platform.billing.manage` | global |
| POST | `/platform/billing/payments/:id/verify` | platform admin | `platform.billing.manage` | global |
| GET | `/platform/billing/plans` | platform admin | `platform.billing.manage` | global |
| POST | `/platform/billing/plans` | platform admin | `platform.billing.manage` | global |
| PATCH | `/platform/billing/plans/:id` | platform admin | `platform.billing.manage` | global |
| GET | `/platform/billing/settings` | platform admin | `platform.billing.manage` | global |
| PUT | `/platform/billing/settings` | platform admin | `platform.billing.manage` | global |
| GET | `/platform/billing/subscriptions` | platform admin | `platform.billing.manage` | global |
| PATCH | `/platform/billing/subscriptions/:id` | platform admin | `platform.billing.manage` | global |
| GET | `/platform/health` | platform admin | `platform.health.view` | global |
| GET | `/platform/schools` | platform admin | (any signed-in user; ownership checked) | global |
| PATCH | `/platform/schools/:id` | platform admin | `platform.schools.manage` | global |
| GET | `/platform/security-events` | platform admin | `platform.security.view` | global |
| POST | `/platform/support` | platform admin | `platform.support` | global |
| DELETE | `/platform/support` | platform admin | (any signed-in user; ownership checked) | global |

## public

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/public/demo` | public | — | 60/1 minute |
| POST | `/public/demo/start` | public | — | 10/1 minute |
| GET | `/public/schools/:slug` | public | — | 60/1 minute |
| GET | `/public/schools/:slug/logo` | public | — | 60/1 minute |
| GET | `/public/status` | public | — | 120/1 minute |

## results

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/results/analytics` | session | `results.view` `reports.view` | 30/1 minute |
| GET | `/results/analytics/student/:id` | session | `results.view` | global |
| GET | `/results/annual` | session | `results.view` | 30/1 minute |
| GET | `/results/broadsheet` | session | `results.view` | 30/1 minute |
| GET | `/results/broadsheets/archive` | session | `results.view` | global |
| GET | `/results/comment-helper` | session | `results.enter` `results.enter_any` `results.approve` | global |
| POST | `/results/corrections` | session | `results.update` | global |
| GET | `/results/corrections` | session | `results.update` `results.approve` | global |
| POST | `/results/corrections/:id/review` | session | `results.approve` | global |
| GET | `/results/cumulative` | session | `results.view` | 30/1 minute |
| GET | `/results/overview` | session | `results.view` | global |
| POST | `/results/process` | session | `results.approve` `results.publish` `results.enter_any` | global |
| POST | `/results/publish` | session | `results.publish` | global |
| GET | `/results/queue` | session | `results.review` `results.approve` `results.publish` | global |
| PUT | `/results/report-cards/:id` | session | `results.enter` `results.enter_any` `results.approve` | global |
| PUT | `/results/report-cards/bulk` | session | `results.enter` `results.enter_any` `results.approve` | global |
| GET | `/results/sheets` | session | `results.view` `results.enter` `results.enter_any` | global |
| POST | `/results/sheets` | session | `results.enter` `results.enter_any` | global |
| GET | `/results/sheets/:id` | session | `results.view` `results.enter` `results.enter_any` | global |
| GET | `/results/sheets/:id/history` | session | `results.approve` `audit_logs.view` | global |
| POST | `/results/sheets/:id/review` | session | `results.review` `results.approve` | global |
| PUT | `/results/sheets/:id/scores` | session | `results.enter` `results.enter_any` | global |
| POST | `/results/sheets/:id/submit` | session | `results.enter` `results.enter_any` | global |
| GET | `/results/student/:id` | session | `results.view` `results.view_own` `results.view_children` | global |

## roles

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/roles` | session | `roles.view` `users.create` | global |
| POST | `/roles` | session | `roles.manage` | global |
| PATCH | `/roles/:id` | session | `roles.manage` | global |
| DELETE | `/roles/:id` | session | `roles.manage` | global |

## school

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/school` | session | `settings.view` | global |
| PATCH | `/school` | session | `settings.update` | global |
| POST | `/school/backup` | session | `reports.export` | 3/10 minutes |
| GET | `/school/branches` | session | `settings.view` `academic.view` | global |
| POST | `/school/branches` | session | `settings.update` | global |
| PATCH | `/school/branches/:id` | session | `settings.update` | global |
| PATCH | `/school/branding` | session | `settings.branding` | global |
| PATCH | `/school/head` | session | `settings.update` | global |
| POST | `/school/head/signature` | session | `settings.update` | 10/1 minute |
| DELETE | `/school/head/signature` | session | `settings.update` | global |
| POST | `/school/logo` | session | `settings.branding` | 10/1 minute |
| DELETE | `/school/logo` | session | `settings.branding` | global |
| GET | `/school/periods` | session | `academic.view` `clock.view` | global |
| PUT | `/school/periods` | session | `academic.manage` | global |
| PUT | `/school/settings` | session | `settings.update` | global |
| GET | `/school/web-address` | session | `settings.view` | global |
| PUT | `/school/web-address` | session | `settings.update` | 20/1 hour |
| GET | `/school/web-address/check` | session | `settings.update` | global |

## security

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/security/events` | session | `security.view` `audit_logs.view` | global |
| GET | `/security/login-events` | session | `security.view` `audit_logs.view` | global |

## staff

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/staff` | session | `staff.view` `academic.manage` | global |
| POST | `/staff` | session | `staff.create` | global |
| PATCH | `/staff/:id` | session | `staff.update` | global |
| DELETE | `/staff/:id` | session | `staff.delete` | global |

## store

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/store/items` | session | `store.view` `store.sell` `store.manage` | global |
| POST | `/store/items` | session | `store.manage` | global |
| PATCH | `/store/items/:id` | session | `store.manage` | global |
| GET | `/store/items/:id/moves` | session | `store.view` `store.sell` `store.manage` | global |
| POST | `/store/items/:id/stock` | session | `store.manage` | global |
| POST | `/store/sales` | session | `store.sell` | global |
| GET | `/store/sales` | session | `store.view` `store.sell` `store.manage` | global |
| GET | `/store/sales/:id` | session | `store.view` `store.sell` `store.manage` | global |
| POST | `/store/sales/:id/void` | session | `store.void` | global |

## students

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/students` | session | `students.view` | global |
| POST | `/students` | session | `students.create` | global |
| GET | `/students/:id` | session | `students.view` `results.view_own` `results.view_children` | global |
| PATCH | `/students/:id` | session | `students.update` | global |
| DELETE | `/students/:id` | session | `students.delete` | global |
| POST | `/students/:id/passport` | session | `students.update` | 30/1 minute |
| POST | `/students/:id/status` | session | `students.update` | global |

## system

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/system/info` | session | `settings.view` | global |
| GET | `/system/support` | session | (any signed-in user; ownership checked) | global |

## teachers

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/teachers` | session | `teachers.view` `staff.view` | global |
| PATCH | `/teachers/:id` | session | `teachers.update` | global |
| POST | `/teachers/:id/assignments` | session | `teachers.update` | global |
| GET | `/teachers/activity` | session | `teachers.view` | global |
| DELETE | `/teachers/assignments/:id` | session | `teachers.update` `teachers.delete` | global |

## users

| Method | Path | Auth | Permission (any of) | Rate limit |
|---|---|---|---|---|
| GET | `/users` | session | `users.view` | global |
| POST | `/users` | session | `users.create` | global |
| PATCH | `/users/:id` | session | `users.update` | global |
| POST | `/users/:id/access-code` | session | `users.update` | global |
| PUT | `/users/:id/membership` | session | `users.update` | global |
| POST | `/users/:id/mfa-reset` | session | `users.update` | global |
| POST | `/users/:id/revoke-sessions` | session | `users.disable` | global |
| PUT | `/users/:id/roles` | session | `users.assign_role` | global |
| POST | `/users/:id/status` | session | `users.disable` | global |
| POST | `/users/:id/unlock` | session | `users.update` | global |
| POST | `/users/invite` | session | `users.create` | global |

