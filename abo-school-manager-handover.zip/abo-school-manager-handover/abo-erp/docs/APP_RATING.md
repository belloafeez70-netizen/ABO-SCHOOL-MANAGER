# A.B.O. School Manager: honest rating, strengths and limitations

**Date:** 11 October 2026

**What was rated:**
- **The online edition** (`abo-erp`), the secure multi-school product.
- **The offline edition** (`school_broadsheet_manager_bopc_erp.html`), which is what **https://abosch.netlify.app** runs today.

**How it was rated:** from tests run on this computer and from reading the code. Nothing here was tested on a live server, real phones or real payments.

## Overall scores (out of 10)

| Area | Online edition | Offline edition | Why |
|---|---|---|---|
| Features for Nigerian schools | **9** | **8.5** | Covers almost everything a school needs (list below). The online edition does it with proper approvals and audit records. |
| Security | **8.5** | **4** | Online: checked by the server, Row Level Security, two-factor sign-in for owners, encrypted secrets, audit trail. Offline: everything runs in the browser, so anyone with the file and the device can get round it. |
| Data safety / storage | **8.5** (when deployed) | **5** | Online: PostgreSQL database with backups and isolation checks. Offline: browser storage on each device; Cloud Sync helps but the last save wins. |
| Ease of use | **8** | **7** | Simple words option, page groups with tabs, works on phones, install as an app. The offline menu is still very long. |
| Phone / tablet use | **8.5** | **8** | Both tested on a phone-sized screen; the computer layout stays when chosen. Not tested on real handsets. |
| Speed at scale | **8** | n/a | Load-tested on this computer: 1,000 schools, 200,000 users, about 350 requests per second, no crashes. Not measured from Nigeria to a live server. |
| Readiness to sell | **7** | **5** | Online: everything is built and tested, but it is **not live yet**. It needs your GitHub, Supabase, Render, Netlify, an email provider and Paystack. |
| Code quality / tests | **8.5** | **6** | Online: 184 automated server tests and about 1,700 browser checks. Offline: one very large file with old and new code mixed. |
| **Overall** | **8.4 / 10** | **6 / 10** | |

## Strengths

1. **A whole school in one system.** It covers:
   - pupils and parents
   - classes (standard Nigerian list or the school's own classes)
   - attendance and staff clock-in (fingerprint or face on the online edition)
   - lesson notes with approval
   - computer tests (CBT)
   - CA and exam scores with a four-eyes approval process (one person enters, a different person checks)
   - broadsheets, cumulative and annual results, and report cards with "results so far"
   - fees with online payment, cashbook and school shop
   - announcements with sharing to parents on WhatsApp and email
   - messages, calendar, birthdays, ID cards and analytics
2. **Security done on the server** (online edition):
   - Every request is checked.
   - Each school's data is separated by the database itself: 88 tables have Row Level Security, and the 12/12 isolation check passed.
   - Owners and administrators must use two-factor sign-in.
   - Secrets are encrypted.
   - The audit trail cannot be edited.
   - Payments count only after the server has confirmed them with Paystack.
3. **Built for Nigerian reality:**
   - Naira, Nigerian class names and WAEC or primary grading.
   - Nigerian phone numbers are turned into WhatsApp links automatically.
   - It works on cheap phones, installs as an app and opens offline.
   - A "simple words" mode makes it easy to read.
4. **Honest results:** totals, grades, positions and cumulative averages are all calculated on the server.
5. **Selling tools:**
   - Two separate DEMO schools with a 5-minute timer and automatic reset.
   - Subscription plans with online payment.
   - Each school gets its own web address.
6. **Well tested:**
   - Automated server tests, browser tests for every menu page and role, and a phone tap test.
   - A load test with 1,000 schools.
   - Backups were taken before every change.

## Limitations (please read)

1. **Not live yet.** The online edition runs only on this computer. Going live needs your GitHub, Supabase, Render, Netlify, an email provider (SMTP) and a Paystack account. Until then, abosch.netlify.app is still the offline edition.
2. **The offline edition cannot be truly secure.**
   - It runs completely inside the browser.
   - The owner's login code is no longer written in the file (only a slow hash of it is kept), and each device has an owner password.
   - But someone who controls the device can still read or change the browser's data.
   - The "preview" countdown and the bank-transfer approvals are reminders, not real locks.
   - The two demo schools with automatic reset and Paystack payments **exist only in the online edition**.
3. **Not tested on real phones, iPhone/Safari or Firefox.** Testing used Chrome on this computer pretending to be a phone.
4. **Emails:** the online edition sends emails only after an email provider is set up. The offline edition opens your email app instead.
5. **WhatsApp:** messages open WhatsApp with the text ready, but a person still presses send. Automatic bulk WhatsApp needs the paid WhatsApp Business API.
6. **Payments:** tested with a pretend Paystack server. A real test payment is needed after going live.
7. **Speed from Nigeria:** not measured. Render and Supabase in Europe add about 100–200 ms per request from Lagos.
8. **Offline menu:** it is still long (about 90 entries for an owner), although repeated items were folded together. The online edition's menu is much shorter.
9. **Offline sync:** if two devices change the same score while offline, the last one to sync wins.
10. **Docker image build:** not tested here (Docker is not available on this computer).

## My recommendation

1. **Put the online edition live** (see `UPLOAD_GUIDE.md`) and point abosch.netlify.app at it. That is the only way to get secure logins, real payments, the two DEMO schools with automatic reset, and one shared database for all devices.
2. **Keep the offline edition** for schools with poor internet, as a companion app.
3. **Before advertising:**
   - test on 2–3 real Android phones and one iPhone;
   - make one real Paystack payment of ₦100 in live mode;
   - send one test email to a parent.
