# Phase 6, part 1: features moved into the server edition

**Date:** 9 Oct 2026
**Status:** built and tested on this computer (sandbox). This is **not yet** on your real Supabase or live on the internet.

## In simple words

Before, these features lived **only** in the offline app, where each phone had its own copy and anyone with the phone
could change the rules. Now 4 of them also work in the **secure server edition**: the server decides who may do what,
and every school sees only its own data.

| Feature | Who can use it | Rules the server enforces |
|---|---|---|
| **Staff clock-in / clock-out** | Every staff member clocks in for **themselves**. The owner, principal, admin and heads see the register. The owner, principal and admin set the rules. | <ul><li>The school sets its gate location (with a "Use my location" button), the allowed distance and the late time.</li><li>The **server** works out the distance from the phone's position. A phone saying "I am at school" is not believed: unknown fields are refused.</li><li>One clock-in and one clock-out per person per day, protected by the database.</li><li>You cannot clock out without clocking in first.</li><li>Every refused attempt (too far away) is written in the audit log.</li></ul> |
| **School calendar** | Everyone can read it. The owner, principal, admin and heads can add, change or remove events. | Pupils and parents **never** see events marked "staff only". |
| **Birthdays** | All staff. Pupils and parents cannot open it. | <ul><li>Shows pupils and staff for today, the next 7 days or the next 31 days.</li><li>Shows the age each person is turning.</li><li>Someone born on 29 February is celebrated on 28 February in other years.</li><li>Staff records now have a date of birth.</li></ul> |
| **Cashbook** (other income, expenses, petty cash) | The owner, principal and admin do everything. The accountant can see and record. The bursar can also void entries. Teachers cannot see it. | <ul><li>Amounts are stored in whole kobo.</li><li>An entry is **never edited or deleted**. A wrong entry is voided with a reason, and the database itself refuses any change to an amount.</li><li>Petty cash **can never go below ₦0**, even if two people spend at the same moment.</li><li>Pressing Save twice records the entry only once.</li><li>No future dates are allowed.</li><li>The totals include school-fee payments, so you see all money in and out.</li><li>Topping up petty cash is not counted as new income.</li></ul> |

Every school starts with ready-made cashbook categories (PTA levy, Salaries, Electricity & fuel and others). You can add, rename or switch them off.

## Tests (all run on this computer)

| Test | Result |
|---|---|
| New server tests, `school_life.test.js`: clock-in distance and rules, calendar audience, birthdays (incl. 29 Feb), cashbook rules, roles, and school-to-school isolation | **4/4** (about 90 checks) |
| Full server suite | **153 passed, 0 failed, 1 skipped** (that one needs Redis) |
| Browser test, `school_life.qa.js` (real Chrome, phone position emulated) | **19/19**: the owner sets the gate; a teacher 28 m away clocks in; a teacher 9 km away is refused with the distance; the register is correct; calendar for staff vs pupils; birthdays; cashbook received, petty-cash refusal, top-up, categories; cashbook closed to teachers; no errors |
| Menu test: every menu link opened for every role | **265/265**. On the first run it caught the word "null" on the cashbook page; that was fixed and checked again |
| The other browser suites, run again | UI **71/71**, menu clicks **232/232**, CBT **34/34**, pupil/parent portal **28/28**, migration page **7/7** |
| School isolation check (`verify-isolation.js`) | **12/12**. All **76** tables that hold school data have row-level security |

Screenshots are in `abo-erp/docs/screenshots/`:
- `phase6-clock-owner.png`
- `phase6-clock-teacher.png`
- `phase6-calendar.png`
- `phase6-cashbook.png`

## Files
- **Database:** `server/src/db/migrations/018_school_life_cashbook.sql`, plus a reverse script in `migrations/down/`. Existing data is not touched; it only adds new tables and one new column (staff date of birth).
- **API:**
  - `server/src/routes/school_life.js`: `/clock/*`, `/calendar`, `/birthdays`
  - `server/src/routes/cashbook.js`: `/cashbook/*`
  - Permissions added in `server/src/rbac/catalog.js`, and granted to the existing roles of every school.
- **Screens:**
  - `web/assets/js/pages/schoollife.js`
  - `web/assets/js/pages/cashbook.js`
  - Menu entries added: Staff & Teachers → Staff Clock-in, Calendar & Birthdays, Finance → Cashbook, and the pupil/parent calendar.
  - Staff form: date of birth field.
- **Location permission:** the site now allows location for itself only (`geolocation=(self)`), which clock-in needs. Camera, microphone and payment stay blocked.
- **Tests:**
  - `server/test/school_life.test.js`
  - `server/test/e2e/school_life.qa.js` (`npm run test:school-life`)

## Honest limits
- **Phone GPS can be faked** with special apps. The server checks the reported position, but it cannot prove the phone is really there. Fingerprint/face confirmation exists in the offline app only. In the server edition it will come in a later part, using WebAuthn checked on the server.
- **The time comes from the server clock**, not the phone, so a phone's wrong clock cannot make someone "on time".

## Still to do in Phase 6 (next parts)
- **Still to move into the server edition:**
  - ID cards
  - store/inventory and sales
  - study materials, videos and live classes
  - class monitor
  - comment helper
  - the "simple words" switch
  - school web address
  - Control Centre / sign-in-as
- **Server screens offline:** reading saved pages and queuing scores while offline (service worker).
- **Offline file, quick fixes:** replace pop-up `alert/confirm/prompt` boxes with in-app dialogs, and remove duplicated functions.
