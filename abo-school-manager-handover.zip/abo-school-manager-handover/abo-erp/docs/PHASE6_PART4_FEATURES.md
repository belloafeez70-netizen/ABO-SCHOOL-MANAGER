# Phase 6, part 4 (last part): sign in as, school web address, offline mode

**Date:** 10 Oct 2026
**Status:** built and tested on this computer (sandbox). It is **not yet** on your real Supabase or live on the internet.

## In simple words

### 1. Owner "Sign in as" (server edition)
The owner can use the app **exactly as a teacher, office worker, pupil or parent** of the school sees it, to help them or check their work.

| Rule | How it is enforced |
|---|---|
| Only the **owner** can do it (not the principal or admin, unless the owner gives that right in a custom role) | Permission `users.impersonate`, checked on the server |
| A **reason** (5+ letters) and a **time limit** (5–60 minutes) | Checked on the server. When the time is up, the account goes back to the owner by itself |
| Never as yourself, another owner, someone who can also "sign in as", a platform admin, or anyone from **another school** | Checked on the server |
| A **red bar** shows the whole time, with the time left and a "Back to my account" button | Web app |
| Closed while acting: **passwords, two-step sign-in, private messages, user accounts and roles, switching school**, and starting another "sign in as" | Blocked in the server's sign-in check |
| **Everything is recorded under the owner's name**, e.g. "sa.owner (as sa.teacher1)". The person gets a message: "The school owner signed in as you", with the reason. A safety alert is saved | Audit log, notification and security event |
| If the person's account is switched off, acting stops at once | Checked on every request |

### 2. School web address (server edition)
- New page **Settings → School → School Web Address**. It shows the school's own sign-in link, with **Copy** and **Share on WhatsApp** buttons.
- The owner or admin can change the address, for example `bright-oak-academy`. A live check says whether the name is free.
- **Old addresses keep working.** An old printed letter or WhatsApp link still opens the right school and moves to the new address.
- An old address is **never given to another school**.
- Some names are kept for the system (`admin`, `api`, `www` …), and badly formed names are refused.

### 3. Offline mode (server edition)
- If the internet or the server is gone, **the app still opens**. Pages you opened before show their **last saved copy**, and a yellow bar says *"You are offline. This page shows the copy saved on … Saving needs the internet."*
- **Saving anything still needs the internet.** The app says so plainly, so nothing is lost silently. Saving offline and sending later (e.g. scores and attendance) is **not** built yet.
- **Privacy:**
  - Each person's saved copy is kept apart.
  - **Signing out deletes it**, and so does an expired session.
  - Only everyday read-only screens are saved (dashboard, timetable, calendar, notices, materials, own results). Money, security screens, files and exports are never saved.
- On a **shared computer**, people should sign out when they finish.

## Tests (all run on this computer)

| Test | Result |
|---|---|
| New server tests (`act_as_web_address.test.js`) | **3/3**, covering:<ul><li>"sign in as": who may, reason and time limit, other school, another owner, sees exactly the teacher's menu and powers, writes a lesson note as the teacher, 6 blocked areas, audit log names the owner, teacher notified, safety alert, stop, auto-end when time is up, auto-end when the account is switched off</li><li>web address: bad names, reserved names, taken names, old address still finds the school, old address never given away, going back to an old address</li></ul> |
| Browser test (`owner_tools.qa.js`) | **14/14**, covering:<ul><li>red bar with name and time left</li><li>teacher's menu while acting; messages closed</li><li>back to the owner account</li><li>the teacher sees the notice</li><li>web address change, and an old link moving to the new one</li><li>**server switched off → the app still opens with the saved copy and the yellow bar**</li><li>sign-out deletes the saved copy</li></ul> |
| Full server suite | **162 passed, 0 failed, 1 skipped** (it needs Redis) |
| Older browser tests, run again | Menu **291/291** (every link, every role), UI **71/71**, menu clicks **251/251**, CBT **34/34**, portal **28/28**, migration page **7/7**, clock-in/calendar/cashbook **19/19**, store/comments/ID cards **16/16**, materials/monitor/simple words **17/17** |
| School isolation check | **12/12**. All **84** school tables are locked per school |

**Caught by an older security test:** the "list of every endpoint" test flagged the new "Back to my account" button's endpoint because it has no permission guard. That is on purpose: it only changes your own session, and it must work while you are acting as a teacher, who has no owner rights. I added it to the test's list of "own data only" endpoints, with that reason written beside it. All 11 security tests pass.

Screenshots are in `abo-erp/docs/screenshots/`:
- `phase6-act-as.png`
- `phase6-web-address.png`
- `phase6-offline.png`

## Files
- **Database:** `server/src/db/migrations/021_act_as_web_address.sql`, plus a reverse script. It adds session columns and the address history; existing data is not touched.
- **Server:**
  - `server/src/auth/plugin.js` (acting + blocked areas)
  - `server/src/audit/audit.js` (real person in the log)
  - `server/src/routes/act_as.js`
  - `server/src/routes/web_address.js`
  - `/auth/me` now tells the app when you are acting
- **Web app:**
  - `web/sw.js` (offline worker)
  - `web/assets/js/core/offline.js`
  - `web/assets/js/pages/owner_tools.js`
  - the red bar in `core/shell.js`
  - old-address forwarding in `pages/auth.js`
  - `scripts/build-web.js` now copies `sw.js` to the site and marks it "do not keep old copies"
- **Tests:**
  - `server/test/act_as_web_address.test.js`
  - `server/test/e2e/owner_tools.qa.js`

## Not done (honest)
- **Offline app:** the 26 `confirm` and 19 `prompt` pop-ups are still the browser's own boxes. Replacing them means rewriting the code around each one in the 1.5 MB file. You chose "quick fixes only" for the offline file, so I left them. The 16 `alert` boxes were replaced in part 2.
- **Server edition offline:** saving while offline and sending later is not built.
- **Fingerprint/face confirmation for clock-in** in the server edition (WebAuthn) is not built. GPS is checked, but it can be faked.
