# Plain language: the standing rule for A.B.O. School Manager

The owner's instruction (9 Oct 2026), to apply to **every** screen from now on:

> "Make the app friendly for users, using simple terms that a 10-year-old can navigate. Remember."

## The rules
1. **Short, everyday words.** Use "Money In", not "Income Ledger". Use "Petty Cash", not "Imprest". Use "Class Score Sheet",
   not "Broadsheet".
2. **One idea per sentence.** Keep explanations under about 20 words: say what the page is for, not how it is built.
3. **Say what to do.** "Press **Add** to add the first one." "Type the login code your school gave you."
4. **Friendly error messages** that explain how to fix the problem. For example: "Use small letters only (a–z)."
   Avoid messages like "Invalid input".
5. **Keep school words people know:** CA, exam, term, arm, report card. Explain them on first use, for example "Class Test
   Scores (CA)".
6. **Full office terms stay available.** The **Show full terms** switch (bottom of the menu) brings them back for bursars
   and accountants. Search finds a page by either name.
7. **Never change what users type:** names, notes, comments.

## Where it lives
`legacy/offline-plain.js`, injected into the main edition by `scripts/skin-legacy.js`. It holds:
- `PAGES`: page id → [simple name, one-line explanation]
- `SECTIONS`: menu group headings
- `PHRASES`: short button, column and label texts
- `SENTENCES`: "nothing here yet" messages
- the sign-in screen texts

**When adding a new page:** give it a simple name and explanation in `PAGES`, and use simple words in its buttons and
messages.

## Word list (simple ← full)

| Simple | Full term |
|---|---|
| Home | Dashboard |
| Summaries | Dashboards / Boards |
| People | School Records |
| Teaching | Academics |
| Tests & Results | Assessment |
| Money | Finance |
| Logins | Portal Management |
| Settings | System |
| Messages & Calendar | Communication |
| Class Score Sheet | Broadsheet |
| Class Test Scores (CA) | CA Scores |
| Computer Tests (CBT) | CBT Assessments |
| Move to Next Class | Promotion & Transfers |
| School Year & Terms | Sessions & Terms |
| Classes & Arms | Academic Structure |
| Who Teaches What | Teacher Subjects |
| Petty Cash | Imprest |
| Money Categories | Chart of Accounts |
| Store Items | Inventory |
| Money In / Money Out | Income / Expenses |
| All Money In & Out | Transactions |
| Old Debts | Outstanding Import |
| Not paid yet | Outstanding |
| Login Codes | Portal Access |
| Add Many at Once | Bulk Import |
| Who Did What | Activity Log |
| Important Actions | Audit Logs |
| App Health Check | Diagnostics |
| Online Backup | Cloud Sync |
| School Web Address | Subdomain |
| Staff Arrival (Clock-in) | Staff Clock-in |
| Attendance (Who Came) | Attendance |
| Comment Helper | AI Assistant |
| See as Another User | Act As User |
| Who Can See What | Roles & Permissions |

## Server edition (web app)
Since 10 Oct 2026 the server web app follows the same rule: `web/assets/js/core/words.js` maps menu names, page titles and the breadcrumb to simple words by default; the **Show full terms** switch at the bottom of the menu brings back the office terms, and the menu search accepts both. **When adding a page**, give its title a simple name in `SIMPLE` if the office word is jargon.
