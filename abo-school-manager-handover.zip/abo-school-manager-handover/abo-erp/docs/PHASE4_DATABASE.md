# Phase 4 — Database design & Supabase integration (9 Oct 2026)

**Architecture (approved):** the API (server edition) runs on Render. Data lives in the school's Supabase PostgreSQL,
in a separate database `abo_erp`; files go in Supabase Storage. The web app is on Netlify.

**Status:** everything that does **not** need the database password is done and verified. Running it on the real
project waits for the owner's temporary database password.

## What changed
| Change | Why | File |
|---|---|---|
| Bootstrap works with a **non-superuser admin** (Supabase's `postgres`): grants itself membership of `abo_owner` before creating the database (PostgreSQL 16+ "must be able to SET ROLE"); re-runs no longer touch the SUPERUSER attribute | Supabase does not give out superuser. The original script failed here (2 errors reproduced, then fixed) | `server/src/db/bootstrap.js` |
| **One TLS helper** for pool, migrations and bootstrap. It verifies certificates; `DB_SSL_CA_PEM` / `DB_SSL_CA` are supported; the **Supabase Root 2021 CA is bundled** and used automatically for `*.supabase.com/.co` | The migration tool verified without a CA, which would fail against Supabase; the bootstrap tool did not use TLS at all | `server/src/db/ssl.js`, `deploy/certs/supabase-prod-ca-2021.crt` (sha256 `700723…f3b7`) |
| **S3 storage keeps an endpoint path**, so Supabase Storage's `…/storage/v1/s3` works | The path was being dropped | `server/src/storage/index.js` |
| **One-command database set-up:** roles with random passwords → database → 17 migrations → isolation check → prints the Render values. Safe to re-run. | Repeatable, no manual SQL | `scripts/supabase-db-setup.sh` |
| **Isolation proof script** (creates 2 test schools, attacks across them, cleans up) | Run against Supabase itself, not just locally | `scripts/verify-isolation.js` |
| **Render blueprint for Supabase:** 1 instance, worker in-process, pooler connection strings, Supabase Storage | Matches the chosen architecture; every key checked against the server code | `render.supabase.yaml` |

## Verified in this session
| Check | Where | Result |
|---|---|---|
| Server bootstrap + 17 migrations as a **Supabase-like non-superuser** (`postgres`: NOSUPERUSER, CREATEROLE, CREATEDB, BYPASSRLS) | local PostgreSQL 17 | ✅ (after the 2 fixes) |
| **Full server suite with the Supabase-like admin** | same | ✅ **146 passed, 0 failed, 1 skipped (Redis)**, run 3 times, including after each change |
| Isolation, run as `abo_app`: no school → 0 rows; A sees only A; A reading, changing or deleting B → 0; A inserting into B → refused; switching RLS off, dropping or creating tables → refused; 71 school tables all have RLS | same | ✅ **12/12** (`verify-isolation.js`, clean-up leaves 0 rows) |
| `supabase-db-setup.sh` from an empty database, and a re-run | same | ✅ (re-run: 0 migrations re-applied, passwords rotated) |
| **Your Supabase project's pooler:** host `aws-0-eu-west-1.pooler.supabase.com`, ports 5432 + 6543, reaches the password step with **TLS verified by the bundled Supabase CA** | **real Supabase** (wrong password on purpose) | ✅ |
| Pooler accepts the server's connection settings (`statement_timeout`, `application_name`) up to the user lookup ("user not found", because the roles don't exist there yet) | **real Supabase** | ✅ partially (full check after the roles exist) |
| Supabase supports extra databases and pooler access to them | Supabase docs (Supavisor FAQ) | ✅ documented |
| Direct database host is IPv6-only, so the pooler must be used from Render | DNS lookup | ✅ |

## Not yet verified (needs the owner)
- **Running `scripts/supabase-db-setup.sh` on the real project**, so that the migrations and 12/12 isolation are checked **there**.
  It needs the temporary admin password.
- **The runtime role through the transaction pooler** (`abo_app.<ref>@…:6543`) with real queries: login, a request, RLS.
- **Supabase Storage S3 upload/download.** It needs an S3 access key, created in the dashboard.
- **Latency between Render (Frankfurt) and Supabase (Ireland).** It will be measured in Phase 7/8.

## How the owner unblocks this
Send once, then reset the password afterwards:

```
postgres://postgres.fehpqiqqxgqugioowepu:<TEMPORARY-PASSWORD>@aws-0-eu-west-1.pooler.supabase.com:5432/postgres
```

This is the **Session pooler** string from Supabase → **Connect**. Only the session-pooler string is needed: the
setup script derives everything else.
