# A.B.O. School Manager — Master Prompt report

**Date:** 11 October 2026

**Rule followed:** **Verified** means it was run and checked on this computer, with the results below. **Not verified** means it needs your accounts, the live servers or real devices. Nothing is called "complete" without a test.

**Backups made first:**
- `backups/2026-10-11-before-arena-master/` — the 3 offline HTML files, the website copy, the full server source (`abo-erp-source.tgz`) and SHA-256 checksums.
- `*.before-core-patch` copies of the HTML files.

## What I found first (audit)

1. **Your live site https://abosch.netlify.app is the OFFLINE edition** (byte-for-byte the same as `abo-school-site/index.html`). It runs only inside the browser. Several requests in the master prompt cannot be done safely in a browser-only file:
   - server-checked login and permissions;
   - Row Level Security;
   - Paystack verification and webhooks;
   - demo schools that the server resets.

   They are built into the **online edition** (`abo-erp`), which is ready but **not live yet**.
2. **Real security problems found on the live site:**
   - The owner's login code was written in plain text in the page source, and the same text was the first-time password.
   - The "Early Access" countdown was 30 seconds and then signed the user out.
3. **Repeated items:**
   - Newsletters and Announcements did the same job.
   - The online menu had many look-alike entries (5 broadsheet pages, 4 analytics pages, 3 result-workflow pages, etc.).
   - The offline menu repeated Notices, Audit Logs (twice), Staff Accounts / Login Accounts, and Academic Periods / Sessions & Terms.

## Phase by phase

### 1. Security and login

**Online edition** (already had, re-checked):
- Login ID or email plus password (Argon2id).
- Password reset by email link, email verification for new schools.
- Two-factor sign-in for owners and administrators.
- Sessions with idle and absolute expiry, token rotation, CSRF protection, lockout.
- Permissions checked on the server for every request (route inventory test).
- Nothing secret in the frontend (bundle scan test).

**New:**
- Demo accounts have **no password** and are refused by the normal sign-in form.
- The Paystack secret key is **write-only**: stored encrypted, never returned to the page and never written to the audit log.

**Offline edition (live site):**
- The owner code is **removed from the file**. Only a salted, slow hash is kept (2,000 rounds of SHA-256). The owner still signs in by typing the code, and then the owner password set on that device.
- The old owner code no longer appears anywhere in the three HTML files (only a salted hash).

### 2. Flexible classes (online edition)

- **Standard list:** "Add standard classes" offers Creche, Nursery 1, Nursery 2, Kindergarten, Primary 1–6, JSS 1–3 and SS 1–3, with optional arms. Existing classes are skipped.
- **Own classes:** a school can add any name with its own level label (e.g. Pre-Nursery / Playgroup, Grade 7, Year 9).
- **Rename / edit:** the new name shows everywhere at once, because every record points to the class by its ID. This covers registration, subjects, attendance, results, broadsheets and report cards. Two classes cannot get the same name.
- **Reorder:** move up and down.
- **Switch off / on:** the class's records are kept. A class with pupils this session cannot be switched off until they are moved. A switched-off class takes no new pupils (checked by the database). Old results stay reachable, labelled "(switched off)".

### 3. Two demo schools + five-minute countdown (online edition)

- **Two schools**, each a separate tenant with the same Row Level Security as real schools, labelled **DEMO**:
  - **Sunrise Nursery & Primary School** — Creche to Primary 6.
  - **Unity College** — JSS 1 to SS 3.
- **Sample data in each:**
  - pupils with parents, staff and classes;
  - 1st and 2nd term results published, with cumulative results and report cards;
  - fees, notices and a lesson note.
- **Starting a demo:** since 12 Oct 2026 (migration 028) only through a **demo link** made by the A.B.O. platform owner in the platform console (Demo Links). The public sign-in page has no demo button. The visitor opens the link, picks a school (if the link allows) and a role.
- **The server ends the session after at most 5 minutes.** The platform owner can set 1–5 minutes or switch demos off. The page shows a red DEMO banner with an m:ss countdown, a warning at 1 minute, and an "End demo" button.
- **Owner controls are removed from demo sessions:** logins, roles, settings, exports and imports, sign-in-as, payments, audit and security, deleting. The server refuses those areas.
- **Restore:** when visitors have changed a demo school and nobody is using it, the worker deletes that demo school and builds it again from the sample data. The delete is guarded by `is_demo`, so a real school can never be reset (tested).

### 4. Payment settings (online edition, platform owner only)

- **Payments & Plans** (platform console). Only the platform owner can open it; two-factor sign-in is required in production.
  - **Settings:** demo timer (1–5 minutes), free-trial days, currency, Paystack public key, secret key (write-only, encrypted), bank details.
  - **Plans & prices:** term / year / month, with days of access.
  - **Schools:** each school's status (trial / active / past due / expired / cancelled) and expiry. Manual changes need a reason and are audited.
  - **Payments:** every payment attempt.
- **School side:** School Profile › Subscription shows the plan, status and days left, with "Pay with Paystack" or bank details, plus payment history.
- **Paystack:**
  - The amount is taken from the plan on the server.
  - A payment counts **only after** the server has checked it with Paystack: status success, same amount and currency.
  - The webhook needs a valid HMAC-SHA512 signature and is idempotent.
  - A wrong amount is marked failed and raises a security alert.
  - Subscriptions expire automatically.
- **Offline edition:** new owner-only **Payment Settings** page for:
  - prices and bank details;
  - the preview countdown, now **5 minutes** by default (1–5, shown as m:ss with a 1-minute warning) instead of 30 seconds;
  - the list of payment requests.

  It says honestly that card payments need the online edition.

### 5. Interface cleanup

**Newsletters removed; Announcements is the one place for news.**
- Online: newsletters were copied into announcements (database migration 025 — drafts stay drafts, long letters allowed). The old address answers "moved". Announcements can be drafts.
- Offline: the Newsletter Studio is hidden, old links open Announcements, and old newsletters are kept at the bottom of Announcements.

**Share an announcement with parents:**
- **WhatsApp:**
  - one message to a group or broadcast list;
  - parent-by-parent buttons with numbers turned into 234 format.
- **Email:**
  - Online: one email per parent, sent by the server, never sent twice by mistake, audited. Notices for staff or students only are not sent to parents.
  - Offline: opens your email app with parents in BCC.

**Repeated menu items merged into one entry with tabs (online):**

| Menu entry | Tabs |
|---|---|
| Class Broadsheet | Totals / CA & Exam / One Subject / Positions |
| Cumulative Results | includes the old Annual Broadsheet (3rd term) |
| Class Reports | Class list / Print all / Save as PDF |
| Score Entry | CA / Exam |
| Result Workflow | Work out / Check & approve / Publish |
| Analytics | 4 tabs |
| CBT Results & Analytics | |
| Teachers | List / Who teaches what / Activity / Sign-in accounts |
| Sessions & Terms | |
| School Profile | Profile / Logo / Head / Web address / Subscription |
| Backup & Data | Backup / Import & export / From the old app |
| Learning (parents and pupils) | |
| Timetable & Calendar (parents and pupils) | |

Old addresses still work.

**Offline:** Notices, the duplicate Audit Logs, Staff Accounts, Academic Periods and Design System were folded into their main pages.

### 6. Database & security checks

- 26 migrations; 88 school tables with Row Level Security.
- Isolation check **12/12**.
- Demo, billing and class rules are enforced in the database where it matters:
  - switched-off class trigger;
  - subscription rows that only the platform can activate;
  - plans readable, platform settings platform-only.

## Acceptance test results (actual, final run on this computer)

| Check | Result |
|---|---|
| Server automated suite (`npm test`, with Redis) | **184 / 184 passed**, 0 failed |
| ↳ new demo / classes / payments tests | 6/6 (part of the 184) |
| ↳ new announcements-replace-newsletters, sharing, migration 025 + rollback tests | pass (part of the 184) |
| Browser: final acceptance (`master.qa.js`) | **23/23**. Covers: demo link, DEMO labels, countdown ≤ 5:00 and running, no owner controls, demo results, End demo, second demo school, standard classes, rename, switch off, subscription page, Payments & Plans (secret shown only as a hint), plans, schools list, phone. |
| Browser: menu merges + sharing (`nav_share.qa.js`) | **60/60** |
| Browser, all other server suites (each on a fresh demo database) | menu 225/225 · menu clicks 207/207 · UI 71/71 · CBT 34/34 · portal 28/28 · school life 19/19 · shop/comments/ID cards 16/16 · materials/monitor 18/18 · migrate 8/8 · owner tools 14/14 · passkeys 9/9 · cumulative 25/25 · install & layout 23/23 · phone tap audit 738/738 |
| Server errors in the log during all browser runs | **0** |
| Offline acceptance (`master_off.js`) | **24/24**. Covers: no owner code in the file, owner sign-in by hash, 5:00 preview with warning, merged menu, Newsletter → Announcements, share (WhatsApp group + per parent in 234 format + email BCC), Payment Settings (1–5 minutes enforced). |
| Offline full regression (3 editions) | All 41 runs pass. 6 runs failed on the first pass and passed when re-run: 5 because the local cloud test server was not running yet, 1 (`roles`) after its newsletter check was updated. Results: roles 57/57, cloud 45/45, cloud2 36/36, site 20/20, linked 8/8, sync_register 11/11, cumulative 24/24, phone taps 546/546, install/offline 18/18. |
| School isolation (`verify-isolation`) | **12/12** (88 tables with Row Level Security) |

Old browser tests were updated where the menu deliberately changed:
- "CA Score Entry" is now "Score Entry".
- The pupil's "Lesson Notes", "Notes & Videos" and "Live Classes" are now tabs of "Learning".
- The CBT test uses 3rd term because the demo now publishes 2nd term.

## Not verified / unresolved (honest)

1. **Nothing is live yet.** abosch.netlify.app still serves the offline edition until it is switched (see `UPLOAD_GUIDE.md`).
2. **Real Paystack, real emails (SMTP), Render ↔ Supabase speed from Nigeria, real phones / iPhone / Firefox:** not tested.
3. **The offline edition stays browser-only.** Its countdown and approvals are reminders, not security. Its demo is the "Demo Data" button, not two server-reset schools.
4. **"Email verification" for staff accounts:** schools are verified by email. Staff, pupils and parents activate with a one-time access code from the school (by design, because many parents have no email).
5. **Bulk WhatsApp** without pressing send needs the paid WhatsApp Business API (not included).

## Files

**Reports:**
- `ABO_MASTER_PROMPT_REPORT.md` (this file)
- `ABO_APP_RATING.md`
- `ABO_CUMULATIVE_INSTALL_MOBILE.md`

**Upload packages:**
- `upload-1-github.zip`
- `upload-2-supabase.zip`
- `upload-3-netlify.zip`
- `upload-4-render.zip`
- the `upload/` folder, with `UPLOAD_GUIDE.md`

**Apps:**
- `abo-erp-server.zip`
- `school_broadsheet_manager_bopc_erp.html` (+ premium / connected editions)
- `abo-school-site.zip`

**New code (online edition):**
- `server/src/services/demo.js`
- `server/src/routes/billing.js`
- migrations `025_announcements_merge_newsletters.sql`, `026_demo_classes_billing.sql` (with down scripts)
- `web/assets/js/core/hubs.js`
- `web/assets/js/pages/billing.js`
- tests `demo_billing_classes.test.js`, `e2e/nav_share.qa.js`, `e2e/master.qa.js`

**New code (offline edition):**
- `legacy/offline-merge.js`
- `scripts/patch-offline-core.js`
