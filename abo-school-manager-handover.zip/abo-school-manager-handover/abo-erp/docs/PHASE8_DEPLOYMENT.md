# Phase 8: deployment (going live)

**Date:** 10 Oct 2026

## In simple words
Everything is **ready and rehearsed**, but nothing is **live yet**. To put it on the internet I need **your** accounts, and
you are the only one who should own them:
- Supabase (database)
- Render (the app's engine)
- Netlify (the website)

I can't log in to them from here; there is no connection to these services from this workspace.

So I did the next-best thing: a **full dress rehearsal on this computer**, using the exact same setup the live system will use. The rehearsal found **1 problem that would have stopped the live system from working**, and I fixed it.

## The rehearsal (what was really tested here)

| Piece | How it was rehearsed | Result |
|---|---|---|
| **Database setup script** (`scripts/supabase-db-setup.sh`) | Run against a copy of PostgreSQL set up with the **same limits Supabase gives you** (no superuser). Run twice, as you will do | ✅ Roles created, all **23** updates applied, school isolation **12/12**. The second run changed nothing |
| **API in production mode** (`NODE_ENV=staging`, the same strict checks as production) | Started with real-style secrets, "only accept traffic from the website", secure cookies, and a database user that **cannot** skip school isolation | ✅ Starts; going around the website straight to the API is **refused (403)** |
| **Website build** (`npm run build:web`) | The real production build: 48 code files, 150 KB compressed | ✅ Secret scan: **53 files clean** |
| **Website + API link** | The real Netlify "edge proxy" file, run locally over HTTPS (`scripts/netlify-local.js`) | ✅ |
| **Deployment checker** (`npm run verify:deploy`) | Against the rehearsal site | ✅ **16/16** (HTTPS headers, security policy, caching, proxy, other websites refused, direct access blocked, database up) |
| **Full browser tests through the rehearsal site** | All 10 server browser suites, over HTTPS through the proxy, database = the Supabase-like copy | ✅ UI **72/72**, menu **291/291**, menu clicks **251/251**, CBT **34/34**, portal **28/28**, clock-in/calendar/cashbook **19/19**, store/comments/ID cards **16/16**, materials/simple words **17/17**, migration **7/7**, sign in as / web address / offline **14/14** |
| **Go-live checklist** (`npm run preflight`) | Against the rehearsal | It correctly says **"NOT ready to go live"** and names what is missing in a rehearsal: real web address, database encryption (TLS), e-mail account, demo data present. These are exactly the things you will set up for real |
| **Your Supabase project, live and read-only** (public key only) | Checked which offline-app functions exist | Same as before: the **newest `abo_supabase_setup.sql` has not been run yet**. The site/subdomain functions are still missing. Tables stay locked from the public key ✅ |

### Problem found and fixed
- **The server's container recipe (Dockerfile) left out the Supabase security certificate.** On Render, the API would have **failed to connect to your Supabase database**: the connection is checked against that certificate, and it would have been missing.
- It also left out the admin scripts you need in the Render shell (go-live checklist, first platform admin).
- Both are now included. I also added a `.dockerignore` so local files and secrets can never go into the container, and a new automatic test that fails if this ever happens again.

**The rehearsal also caught a real offline-mode gap, now fixed:**
- In the real layout the website stays up while the school server is down, and the Netlify proxy then answers "server not responding" (502/504) instead of "no internet".
- The offline worker passed that answer on, so the app showed "server cannot be reached" instead of the saved copy.
- It also forgot who was signed in if the browser had paused it.
- Now it uses the saved copy in both cases, remembers the signed-in person until sign-out, and says *"No connection to the school server right now…"*.
- The offline test passes in **both** layouts.

**Two failures that were the test's own fault:**
- The portal test was changing the wrong database (the normal one instead of the rehearsal copy).
- One test could not accept the rehearsal's home-made HTTPS certificate.

Both were fixed and run again.

**After all fixes:** server suite (with Redis) **165 passed, 0 failed, 0 skipped**. That includes the new container test.

### Not testable here (honest)
- **Building the container:** Docker isn't available in this workspace. Render builds it from the `Dockerfile` on the first deploy.
- **Real-world speeds:** Render (Frankfurt) ↔ Supabase (Ireland) ↔ Nigeria can only be measured live (`npm run verify:deploy` and `scripts/loadtest`).

## Your steps to go live (about 1–2 hours, once)

**Before you start, have ready:**
- your GitHub account (Render and Netlify read the code from there),
- an e-mail sending account (SMTP). Free options: Brevo or Zoho Mail. Without it, password-reset e-mails cannot be sent.

1. **Put the code on GitHub.**
   - Create a **private** repository, for example `abo-school-manager`.
   - Upload the contents of `abo-erp-server.zip`. The `.gitignore` already keeps secrets out.
2. **Supabase (database):**
   - Dashboard → **Connect** → copy the **Session pooler** string (port 5432).
   - Set a strong temporary database password in **Settings → Database**.
   - Then either send me that string once (I run the next part and you reset the password after), **or** run it yourself on any computer with Node 20:
     ```
     SUPABASE_ADMIN_URL='postgres://postgres.fehpqiqqxgqugioowepu:<PASSWORD>@aws-0-eu-west-1.pooler.supabase.com:5432/postgres' bash scripts/supabase-db-setup.sh
     ```
     It prints the **two secret connection strings** for Render and checks school isolation (12/12).
   - **Storage:**
     - Create a **private** bucket called `abo-files`.
     - Then go to **Storage → S3 connection → New access key** and keep the two values secret.
3. **Netlify (website):**
   - **Add new project → Import from Git** → your repo, with base directory = the folder that has `netlify.toml`.
   - Rename the site, for example `abo-school-manager` → `https://abo-school-manager.netlify.app`.
4. **Render (API):**
   - **New → Blueprint** → your repo → choose **`render.supabase.yaml`**.
   - Fill in what it asks for:
     - `PUBLIC_ORIGIN` = your Netlify address
     - the two database strings from step 2
     - the S3 key pair from step 2
     - `SMTP_URL` and `MAIL_FROM`
   - Render makes the other secrets itself.
5. **Link the website to the API.** In Netlify → **Environment variables** (scope **Functions**), set:
   - `API_ORIGIN` = your Render address,
   - `PROXY_SHARED_SECRET` = the same value Render created.

   Then press **Redeploy**.
6. **First platform admin.** In Render → abo-api → **Shell**:
   `PLATFORM_ADMIN_LOGIN=abo.admin PLATFORM_ADMIN_EMAIL=<your e-mail> node scripts/create-platform-admin.js`
   Sign in and turn on two-step sign-in.
7. **Check.**
   - In the Render shell run `npm run preflight`. It must say "ready".
   - From any computer run `npm run verify:deploy -- https://<site>.netlify.app https://<api>.onrender.com`. All checks should pass.
8. **Move a school in.** Sign in as the school, go to **Bring In Old App Data**, and upload the offline app's backup file. The page shows the "check the numbers" summary.
9. **Offline app users:** in the Supabase SQL editor, run the newest `abo_supabase_setup.sql` once, so the school web address and the safety limits work there too.

## Manual actions only you can do
- **Create/own the accounts:** GitHub, Supabase, Render, Netlify, and an e-mail sender.
- **Run (or let me run) the database setup** with a temporary password, then **reset that password**.
- **Paystack keys,** only if you want online fee payment.
- **Your own web address** (optional, e.g. `app.yourschool.com.ng`), plus updating `PUBLIC_ORIGIN`.
- **Backups:** Supabase **Pro** plan (daily backups), or turn on the optional backup job at the bottom of `render.supabase.yaml`.
- **Size up when schools join:** start small (1 Render instance). For a large number of schools, follow the sizing in the Phase 7 report.
