# CBT / Online Examination (v5.2)

A computer-based testing module built **on top of the existing platform**. It reuses the school's students,
classes, subjects, sessions, terms, roles, audit log, notifications, import pipeline and result sheets; nothing is
duplicated. Scores flow into the **existing** result workflow, so the school's own assessment components, weights,
grading bands, positions, remarks and approvals apply unchanged.

## 1. Architecture map (what was reused vs. added)

| Concern | Reused (already existed) | Added in v5.2 |
|---|---|---|
| Tenancy & security | RLS on every table (`app.current_school()`), sessions, CSRF, RBAC (`cbt.view/create/update/publish/grade/results/take`), audit hash chain, security events | per-exam **staff scope** (teachers see exams they created or for classes/subjects they teach); per-session rate limits |
| People & academics | `students`, `student_enrollments`, `classes`, `subjects`, `terms`, `academic_sessions`, `teacher_class_access` | `cbt_exam_candidates` (explicit candidate lists; class-wide stays the default for old exams) |
| Questions | `cbt_questions` (bank = `exam_id IS NULL`), `cbt_options` | 4 new types, topic/sub-topic/difficulty/class/session/term, explanation, `answer_key` (text/numeric keys), status (archive), `source_question_id` |
| Exams | `cbt_exams` (schedule, duration, attempts, shuffling, pass mark) | session, back-nav, review page, show answers, resume, full-screen, autosave, access code (Argon2-hashed), `score_component` + `score_policy`, push tracking |
| Taking | `cbt_attempts` (server deadline, frozen question/option order), `cbt_answers` (idempotent upsert), worker auto-submit sweep | multi-select `option_ids`, mark-for-review `flagged`, `time_spent_seconds`, `furthest_index` (server-side no-back-nav), `void` (reset) |
| Marking & results | `services/cbt.gradeAttempt/finalize`, `cbt_results` | marking for multi-select / numeric (tolerance) / fill-blank / keyed short answer; manual marking for essays & unkeyed short answers; **release / withhold** |
| Result integration | `assessments` (score sheets) + `assessment_scores` + `R.recomputeSheet` + broadsheet + report card + DB lock triggers | `POST /cbt/exams/:id/push-scores` (dry-run preview → confirm) |
| Import / export | `imports` table (preview → commit), CSV/XLSX helpers | `cbt_questions` import kind + bank export + results export |
| Notifications | `notifications` + `jobs` queue | publish / schedule / 30-min reminder (`cbt.reminder` job) / added-as-candidate / result released / attempt reset |
| Audit | `audit_logs` (tamper-evident chain) | ~25 `cbt.*` actions (spec's `cbt_audit_logs` = the existing chain, not a second log) |

**Why exam questions are copies:** an exam holds frozen copies of bank questions (`source_question_id` links them).
Editing or deleting a bank question can never change a live or past exam, and analytics still roll up by the source.

## 2. Workflow

```
Question Bank ──(select / auto-generate)──► Exam (draft) ─► Candidates ─► Review ─► Publish / Schedule
      ▲ import CSV/XLSX                                                              │ notify + reminder
      │                                                                              ▼
      └──── analytics (per question/topic) ◄── Results ◄── marking ◄── Attempt (server timer, autosave)
                                                  │ release / withhold / reset
                                                  ▼
                           push-scores (preview → confirm): CBT % × component max (e.g. 87.5% × 60 = 52.5)
                                                  ▼
                 EXISTING score sheet (draft) → recompute → submit → review → approve → publish
                                                  ▼
                                 EXISTING broadsheet  ·  EXISTING report sheet
```

Rules enforced by the server:
* Publishing is refused until: ≥ 1 question, candidates exist, end time in the future, and (if it feeds the result
  sheet) subject + class + term are set and the component exists.
* Pushing scores is refused if candidates are still writing, if the score sheet is already submitted/approved/published
  (use a correction request), or if the student is not on the class register for that term. Essays still being marked
  are listed and skipped. Resetting an attempt is refused once scores were pushed.

## 3. Menu (🖥️ CBT / Online Examination)

CBT Dashboard · Question Bank · Create Examination (5-step wizard) · All / Scheduled / Active / Completed
Examinations · Candidates · CBT Results · CBT Analytics · CBT Settings. Students: *My School Work › My CBT Exams*.

## 4. Candidate interface

One question per screen; large touch targets; sticky timer anchored to the **server clock** (warnings at 10/5/1 min;
auto-submit at 0 — the server also auto-submits late saves and the worker sweeps abandoned attempts); navigator with
answered / unanswered / current / marked-for-review states (collapsible on phones, right-hand panel on desktop);
answers autosave (instantly for options, after typing pauses for text). If the connection drops, unsent answers are
kept in a small local queue (only that candidate's own pending answers; removed on sync/submit), the banner says
*"Connection temporarily unavailable. Your saved answers are being protected. Please reconnect."*, and they sync
when the connection returns — the server upsert makes re-sending harmless (no duplicates). Refresh → **Resume**
(unless the exam disallows resuming, in which case the saved answers are submitted). Summary page (total / answered
/ unanswered / marked) before final submission; warning if anything is unanswered.

Maths: `x^{2}`, `H_{2}O`, `\frac{a}{b}`, `\sqrt{x}`, `\sqrt[3]{x}`, `\times \div \pm \le \ge \ne \pi \theta \degree`…,
`| table | rows |`, images. Rendered by a small DOM-only renderer (no `innerHTML`, CSP-safe).

## 5. Security checklist

| Threat | Control |
|---|---|
| Question/answer leakage | paper payload has no `is_correct`, `answer_key`, explanations or guides (tested) |
| Score / pass-fail manipulation | marking only on the server; client never sends a score; objective marks can't be overridden manually |
| Timer manipulation | `deadline_at` fixed at start (≤ exam end); saves after deadline + 30 s auto-submit; worker sweep |
| Duplicate submission / replay | row lock + status check → exactly one grading (409 on repeats); answer upsert is idempotent |
| IDOR / broken access control | attempts bound to `req.auth.studentId`; candidates checked on start; staff exam scope; RLS on every table |
| Cross-tenant | RLS + tested 404s for School B on exams, candidates, results, analytics, bank, attempts |
| Back-navigation bypass | server rejects changes to questions before the furthest answered one when back-nav is off |
| Access code guessing | Argon2-hashed code, per-session start limit (20/min) |
| XSS | text nodes only; maths renderer builds DOM nodes |
| Shared school IP | per-session rate limits + per-account login limit + per-IP ceilings (see `lib/ratekey.js`) |

## 6. Tests

* `server/test/cbt_v2.test.js` — 11 end-to-end API tests (bank, import, wizard, candidates & scope, publish, attempt,
  marking, release/withhold, analytics, push → broadsheet → report card, timer expiry, no-back-nav, no-resume, reset,
  close, scheduled, audit).
* `server/test/cbt_hall.test.js` — 30 candidates behind one IP at the production rate limit: 0 × 429, 0 × 5xx,
  every answer stored once, all marked.
* `server/test/cbt.test.js` — original CBT tests (still passing: backward compatibility).
* `server/test/unit.test.js` — marking engine for every type; rate-limit keys.
* `npm run test:cbt` — browser end-to-end (34 checks): UI import + editor + auto-generation + wizard + publish, student
  exam with access code, offline blip, refresh-resume, flag, summary, submit; release; send to result sheet;
  broadsheet + report card; analytics; answer sheet; student result; audit.

## 7. Limitations / next steps (honest)

* Multiple-select is all-or-nothing (no partial credit). Fill-in-the-blank supports one blank per question.
* AI marking of essays is not implemented (manual marking only, as specified).
* PDF = the browser's "Save as PDF" (no server-side PDF engine).
* Full-screen can be requested and leaving it is recorded, but browsers cannot force it (and iOS Safari has no
  full-screen API for pages) — treat it as a deterrent, with invigilation.
* The per-IP ceiling is in-memory per server instance; behind several instances use the Redis-backed limiter.
* The exam-hall test ran in a 2-vCPU sandbox; plan a production-size load test (hundreds of concurrent candidates per
  school, thousands platform-wide) on real infrastructure before the first large exam season.
* The legacy single-file HTML ("offline edition") keeps its own simple CBT and is not connected to this module.
