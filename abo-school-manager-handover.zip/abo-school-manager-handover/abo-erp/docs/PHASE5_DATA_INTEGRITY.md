# Phase 5: Data integrity and sync

**Date:** 9 Oct 2026
**Status:** Done and tested on this computer (sandbox).
**Not yet done on your real Supabase:** that step still needs the temporary database password (see Phase 4).

## In simple words

I tested three ways your school data moves around, using real data made by the app itself:

1. **Old app → new server.** Moving a school from the offline app's backup file into the new server.
2. **Backup and restore** inside the offline app.
3. **Two phones or computers changing the same class while offline**, then syncing.

**I found 4 real problems that could lose, mix up or hide data, and 1 security hole.** All 5 are now fixed.
For each one, the test fails on the old code and passes on the new code.

## What was wrong, and what I did

| # | Problem (measured on the old code) | How bad | Fix | Proof |
|---|---|---|---|---|
| D1 | **Moving to the server lost half the pupils.** A real backup with 2 classes (10 + 10 pupils) brought in only 10; the other 10 were skipped without a clear reason. The old app numbers pupils 1, 2, 3 … again in every class, and the importer used that number as the admission number, so pupil "1" of BASIC 2 looked like pupil "1" of BASIC 1. | High (data loss) | A pupil with no admission number now gets a fixed one made from the class, e.g. `BASIC1-3`, `BASIC2-3`. Real admission numbers are kept. If the same admission number appears twice in the file, the importer says so and skips only the second one. | `legacy_reconcile.test.js`: **failed before (10 skipped), passes now** |
| D2 | **Scores could be wrong after moving.** 1) A real **0** was saved as "no score". 2) Schools that changed their score layout (for example CA 15 + CA 15 + Project 10 + Exam 60, or an exam marked out of 100) lost the extra parts, and the totals came out different. 3) Scores above the maximum were cut down without a word. | High | Once a subject has any marks, a 0 counts as a real 0. The importer reads the school's own score layout. The preview warns if the layout is different, and a tick box ("Use the offline score layout") brings every part in, so the **totals out of 100 match the old app exactly**. Scores above the maximum are counted at the maximum, the same as the old app, and the preview tells you how many. | Every subject total compared one by one with the file: **0 differences** (170 totals with the normal layout; 100+ with a custom weighted layout) |
| D3 | **Importing the same file twice duplicated CBT exams, newsletters and teachers.** | Medium | A second import skips anything already there. Every import now ends with a **count check**: pupils in the file = brought in + already there + same number twice. If the numbers don't add up, nothing is saved. | Same test: the second import adds 0 of everything |
| D4 | **Sync doubled pupils.** When two devices changed the same class while offline, the pupil both of them edited came back **twice**, and edited pupils jumped to the bottom of the class. Real test: 10 pupils plus 1 new one became **14** (3 doubles), and edits were split between the copies. | **High (mixed-up results)** | Sync now recognises each pupil row by name and place, even with two pupils of the same name, renamed pupils, or empty rows. Changes to the same pupil from two devices are joined into one row. If both devices change the **same** score, the device that syncs last keeps its value (this was already the rule). | `sync_register.js` (2 real browsers + local Supabase): **old code 5/11, new code 11/11**. `merge_unit.js` **13/13**, including 2,000 random two-device rounds with 0 lost or doubled pupils |
| D5 | **The server's migration page never showed the preview.** The page made the preview, but a coding slip (`appendChild` with 2 items keeps only the first) meant the result box was never put on the screen, so nobody could check the numbers or press "Commit". A scan of all 37 web files found no other place with this slip. | Medium | Fixed. The page now shows the preview, the score-layout tick box, and a "Done — check the numbers" summary. | `server/test/e2e/migrate.qa.js` in a real browser: **7/7** (preview 20 learners → commit → "Every learner in the file is accounted for") |
| S9 | **Backup file security hole.** Every backup file held the owner password record. A school office user could also restore a changed file to **replace the owner password, the bank account shown to schools, or the list of approved schools**. | High (security) | Backups no longer include the owner password record. On restore, the owner password is always kept, and only the owner can change bank, price or approval settings by restoring. Any blocked change is written in the activity log. | `backup_guard.js` **18/18**: an admin's crafted file can't change bank, approvals or the owner password; the attacker's password is refused; the real one still works |

## What I checked and found already safe (no change needed)
- **Server:** payments can't be counted twice (Idempotency-Key). Two people saving the same score sheet at once: one save wins and the other is told. Submitting a CBT twice gives exactly one grade. Each school can only see its own data (RLS). All of this is covered by the server suite.
- **Offline app sync:** working offline then syncing, clock-ins, files, other schools, and the activity log all passed again in `cloud.js` (45 checks) and `cloud2.js` (36 checks).

## Test results (this run, all on this computer)
| Test | Result |
|---|---|
| `legacy_reconcile.test.js`: real backup → server, every pupil, class and subject total compared | **3/3** (failed on the old importer: 10 of 20 pupils skipped) |
| Full server suite (`npm test`) | **149 passed, 0 failed, 1 skipped** (the skip needs Redis) |
| `migrate.qa.js`: migration page in a real browser | **7/7** |
| `backup_guard.js`: backup and restore safety | **18/18** |
| `sync_register.js`: 2 devices offline, same class, local Supabase | **11/11** (old sync code: 5/11, 14 pupils instead of 11) |
| `merge_unit.js`: merge rules + 2,000 random rounds | **13/13** (old code: 4 of the first 9 failed) |
| Offline app full regression, all 3 versions | **34 runs, 0 failures**. Includes cloud 45/45, cloud2 36/36, sec 19/19, roles 57/57, persist 15/15 ×3 |

Screenshots: `abo-erp/docs/screenshots/phase5-migration-preview.png`, `phase5-migration-done.png`.

## Files changed
- `abo-erp/server/src/routes/migration.js`: importer fixes D1–D3, layout option, count check
- `abo-erp/web/assets/js/pages/records.js`: migration page fix (D5), the "Use the offline score layout" tick box, and a plain count summary
- `abo-erp/legacy/offline-cloud.js`: sync fix D4
- `abo-erp/legacy/offline-security.js`: backup/restore fix S9, then re-applied to all 3 HTML files
- New tests:
  - `server/test/legacy_reconcile.test.js` + `server/test/fixtures/offline-backup-phase5.json`, a real backup made by the app in a browser
  - `server/test/e2e/migrate.qa.js`
  - `.qa/make_backup.js`, `.qa/backup_guard.js`, `.qa/sync_register.js`, `.qa/merge_unit.js`. Copies are in `abo-erp/legacy/qa/`.
- Copies of the old versions: `backups/2026-10-09-before-master-upgrade/*.before-phase5`

## Still open (honest list)
- **Your real Supabase.** Moving data into the server on your real database waits for the temporary password (Phase 4).
- **Pupil photos.** Passport photos in the old backup are not moved to the server yet. The preview lists each one so you can upload it again.
- **Both devices change the very same score.** The last device to sync wins. Nothing is lost silently from the device's point of view, but the other value is replaced. A "pick which one" screen would be a later improvement.
- **Two pupils with exactly the same name.** If both are changed *and* one of them is deleted on another device while offline, the app cannot always tell them apart. Giving pupils admission numbers avoids this.
