# Phase 3 — Security & authentication (9 Oct 2026)

**Scope:** the offline file's urgent fixes (P0 in the plan), Supabase function hardening, and library pinning. The
server edition already has server-side authentication and authorisation; its suite was re-run in Phase 1 with
146 passed, 0 failed, 1 skipped (Redis).

## What changed
| # | Change | Files |
|---|---|---|
| 1 | **Stored-XSS fix.** Plain-text fields (pupil names and details, school name/motto/address, class/head teacher names, comments, account names, subjects, classes) are cleaned on every save, on load, and while typing: `<` → `‹`, `>` → `›`. Rich-text newsletter content is not touched. | `legacy/offline-security.js` (all editions) |
| 2 | **Owner password.** The owner code alone no longer signs in. On first owner sign-in the owner creates a password (8+ characters, letters and numbers). It is stored only as a PBKDF2-SHA-256 hash (150,000 rounds, 16-byte random salt). 5 wrong passwords lock owner sign-in on that device for 5 minutes. | same (code-only editions) |
| 3 | **Sealed owner sessions.** A saved owner session must carry a random 32-byte seal created at password sign-in; only the seal's SHA-256 hash is stored. An edited or made-up session is refused. "Sign in as" keeps the owner's seal for the way back. | same + `offline-roles.js` |
| 4 | **Staff phones can't create an owner password.** A phone linked with a device code is a staff device. It receives the owner record (hash) when linking; if the record is missing it fetches it from the school copy, and otherwise refuses. | `offline-security.js`, `offline-cloud.js` |
| 5 | **Supabase wrong-secret limit.** 20 wrong secrets from one address in 15 minutes block that address. 500 per school from all addresses block the school for the window. The failure table is locked from the public key. | `legacy/supabase/setup.sql` (`abo_check`, `abo_auth_fail`) |
| 6 | **Library integrity (SRI).** All 8 internet libraries are pinned with SHA-384 hashes, so a tampered copy is refused by the browser. | the 3 HTML files |

## Tested (measured in this session)
| Test | Before | After |
|---|---|---|
| Attack text in 21 kinds of field, all 94 owner pages + 4 role screens (`qa/audit_xss.js`) | **39 runs, 12 weak spots** | **0 runs** |
| Phase 3 security suite (`qa/sec.js`): first-time set-up rules, hash only, sealed resume, **S1 code alone refused**, wrong password, 5-try lock, **S2 edited session refused**, made-up seal refused, sign-in-as round trip, teachers unaffected, brackets stored harmlessly | — | **19/19** |
| Linked staff phone (`qa/linked.js`): receives hash, no "create", attacker refused, real owner password works, offline + no record → refused, back online → fetched | — | **8/8** |
| Supabase limit (local PostgREST): 20 wrong guesses → correct secret refused from that address; another address works; failure table not readable | no limit | **blocked as designed** |
| Full regression (all editions) | — | see the test report |

## Still open (honest)
- **S3 / S5 / S8 cannot be fixed in a browser-only file.** Roles are enforced in JavaScript, every linked device
  holds the whole school, and staff, pupils and parents have no password. Someone with full control of a device can
  still edit its local data. **The fix is the server edition (Phases 4–8):** server-side permissions, Row Level
  Security per school, passwords for every user.
- **No strict Content-Security-Policy for the offline file.** It has 803 inline event handlers; this will be done in
  the server UI build instead.
- **The owner password hash travels with the school data** to linked staff phones. That is safe with a strong
  password (PBKDF2, 150k rounds) but guessable if the password is weak, so the app enforces 8+ characters with letters
  and numbers.
- **What you need to do:** run the newest `abo_supabase_setup.sql` once in Supabase. It adds the wrong-secret limit and
  the web-address functions.
