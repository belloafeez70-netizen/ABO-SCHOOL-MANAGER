# Test report (30 Sep 2026 — v5.5, sandbox: 2 vCPU, PostgreSQL 17.11, Node 20, Redis 8)

## After Phase 8 — fingerprint/face clock-in (WebAuthn), passport photos in legacy import (10 Oct 2026)

| Check | Result |
|---|---|
| `passkeys.test.js` (software P-256 authenticator: phishing origin, no UV, forged signature, wrong/old challenge, replay, other user's challenge, failed attempt burns the challenge, removal) | **3/3** |
| Photo/logo import (`legacy_reconcile.test.js`) | **4/4** |
| `e2e/passkeys.qa.js` (Chrome virtual authenticator) | **9/9** |
| Server suite (Redis) | **169 passed, 0 failed, 0 skipped** |
| All 12 browser suites | ✅ |
| `verify-isolation.js` | **12/12**, 86 school tables with RLS |
| Found & fixed | failed passkey attempt rolled back and left its challenge usable → challenge now consumed in its own transaction; 3 buttons stayed disabled after an error (`ev.currentTarget` read after await) |

## Phase 8 — production rehearsal (10 Oct 2026)

| Check | Result |
|---|---|
| `scripts/supabase-db-setup.sh` on a Supabase-like PostgreSQL (non-superuser `postgres`), run twice | 23 migrations · isolation **12/12** · re-run idempotent |
| API `NODE_ENV=staging`, SERVE_FRONTEND=false, REQUIRE_PROXY_SECRET=true, secure cookies, non-owner role | starts; direct access 403 |
| `npm run build:web` | 48 JS files, 150.7 kB gzip; secret scan 53 files clean |
| `scripts/netlify-local.js` (real edge function, HTTPS) + `npm run verify:deploy` | **16/16** |
| All 10 browser suites through the rehearsal | UI 72/72 · menu 291/291 · menu clicks 251/251 · CBT 34/34 · portal 28/28 · school life 19/19 · store 16/16 · materials 17/17 · migration 7/7 · owner tools 14/14 |
| `npm run preflight` (rehearsal) | correctly "NOT ready" for the rehearsal-only gaps (staging, localhost, DB TLS off, no SMTP, demo data) |
| Server suite (Redis) | **165 passed, 0 failed, 0 skipped** |
| Found & fixed | Dockerfile lacked `deploy/certs` (Supabase CA) and `scripts/` → live API could not have verified TLS to Supabase; offline worker ignored 502/504 from the edge proxy and forgot the user after a worker restart |
| Not verifiable here | Docker image build (no Docker), live Render/Netlify/Supabase (no accounts) |

## Phase 7 — testing & load tests at 1,000 schools / 200,000 users (10 Oct 2026)

| Check | Result |
|---|---|
| Load data | 1,002 schools · 200,022 users · 200,054 pupils · 200,000 invoices (629 MB) |
| Logins across 1,000 schools | 1,000/1,000 · 52/s |
| 300 active users | **347 req/s, 0 errors** (265 before the auth_session fix) |
| 800 active users | ≈305 req/s served, ≈18 % 503 BUSY (shedding), **0 × 500** |
| 1,000 users, no think time | **0 × 500** (99 × 500 before the busy/shedding fix) |
| Server suite with Redis | **164 passed, 0 failed, 0 skipped** |
| All browser suites (server) + offline full regression (37 runs) | ✅ all passing |
| `npm audit` | 0 vulnerabilities |

## Phase 6, part 4 — sign in as, school web address, offline mode (10 Oct 2026)

| Check | Result |
|---|---|
| `act_as_web_address.test.js` | **3/3** |
| Server suite | **162 passed, 0 failed, 1 skipped (Redis)** (route-inventory test flagged `/auth/act-as/stop` → documented as self-scoped) |
| `e2e/owner_tools.qa.js` (incl. server stopped → app opens from the saved copy; sign-out clears it) | **14/14** |
| Menu 291/291 · UI 71/71 · menu clicks 251/251 · CBT 34/34 · portal 28/28 · migration 7/7 · school life 19/19 · store 16/16 · materials 17/17 | ✅ |
| `verify-isolation.js` | **12/12**, 84 school tables with RLS |

## Phase 6, part 3 — study materials, live classes, class monitor, simple words (10 Oct 2026)

| Check | Result |
|---|---|
| `materials_monitor.test.js` | **3/3** |
| Server suite | **159 passed, 0 failed, 1 skipped (Redis)** — one earlier run hit a race in the token-reuse alert (event written after the reply) → now awaited |
| `e2e/materials_monitor.qa.js` (incl. simple-words default + switch) | **17/17** |
| Menu 289/289 · UI 71/71 · menu clicks 249/249 · CBT 34/34 · portal 28/28 · migration 7/7 · school life 19/19 · store/comments/ID 16/16 | ✅ (older suites run with "full terms", like a user switching) |
| `verify-isolation.js` | **12/12**, 83 school tables with RLS |

## Phase 6, part 2 — store, comment helper, ID cards; offline message box (10 Oct 2026)

| Check | Result |
|---|---|
| `store_comments_idcards.test.js` (prices set by server, stock never < 0 incl. two tills at once, frozen history, void, roles, isolation; comment rules; ID-card permissions) | **3/3** |
| Server suite | **156 passed, 0 failed, 1 skipped (Redis)** |
| `e2e/store_comments_idcards.qa.js` | **16/16** (first version passed without really testing the comment save → test rewritten) |
| Menu QA 278/278 · UI 71/71 · menu clicks 240/240 · CBT 34/34 · portal 28/28 · migration 7/7 · school life 19/19 | ✅ |
| Code-128 barcode vs JsBarcode | **8/8 identical** |
| `verify-isolation.js` | **12/12**, 80 school tables with RLS |
| Offline: `qa/alert_box.js` (in-app message box), 3 editions | **9/9** each |
| Offline full regression (37 runs) | 34 passed first time; 3 test-harness faults (wiped temp folder; classic-edition sign-in in the new test) fixed → 18/18, 9/9, 9/9 |

## Phase 6, part 1 — clock-in, calendar, birthdays, cashbook in the server edition (9 Oct 2026)

| Check | Result |
|---|---|
| `school_life.test.js` (clock-in distance/rules, calendar audience, birthdays incl. 29 Feb, cashbook rules, roles, isolation) | **4/4** |
| Server suite | **153 passed, 0 failed, 1 skipped (Redis)** |
| `e2e/school_life.qa.js` (real Chrome, emulated phone position) | **19/19** |
| Menu QA, every link for every role | **265/265** (first run found "null" printed on the cashbook page → fixed) |
| UI 71/71 · menu clicks 232/232 · CBT 34/34 · portal 28/28 · migration page 7/7 | ✅ |
| `verify-isolation.js` | **12/12**, 76 school tables with RLS |

## Phase 5 — data integrity and sync (9 Oct 2026)

| Check | Result |
|---|---|
| Real offline backup → server, every pupil, class and subject total reconciled (`legacy_reconcile.test.js`) | **3/3**. The old importer skipped 10 of 20 pupils |
| Server suite | **149 passed, 0 failed, 1 skipped (Redis)** |
| Migration page in a browser (`e2e/migrate.qa.js`) | **7/7**. The preview never showed before the fix |
| Backup/restore safety (`qa/backup_guard.js`) | **18/18** |
| Two devices offline editing one class (`qa/sync_register.js`, local Supabase) | **11/11**. Old sync code: 5/11 (14 pupils instead of 11) |
| Merge rules + 2,000 random rounds (`qa/merge_unit.js`) | **13/13** |
| Offline full regression, 3 versions | **34 runs, 0 failures** |
| On the real Supabase project | ⏳ waiting for the temporary admin password |

## Phase 4 — Supabase database (9 Oct 2026)

| Check | Result |
|---|---|
| Server suite with a Supabase-like non-superuser admin (local PostgreSQL 17) | **146 passed, 0 failed, 1 skipped** (3 runs) |
| `scripts/verify-isolation.js` as `abo_app` | **12/12** |
| `scripts/supabase-db-setup.sh` from empty, and a re-run | ✅ |
| Real Supabase pooler `aws-0-eu-west-1` reached with TLS verified by the bundled CA (password step) | ✅ |
| Migrations and isolation **on the real Supabase project** | ⏳ waiting for the temporary admin password |

## Phase 3 — security (9 Oct 2026)

| Suite | Result |
|---|---|
| `qa/audit_xss.js`: attack text in 21 field types, 94 owner pages + 4 role screens | **0 runs** (was 39 runs / 12 weak spots) |
| `qa/sec.js`: owner password, lock, sealed sessions; audit attacks S1/S2 now refused | **19/19** |
| `qa/linked.js`: staff phone cannot create an owner password | **8/8** |
| Supabase wrong-secret limit (local PostgREST, curl) | blocks after 20 tries per address; other addresses fine; table locked |
| Full regression, all three editions | **31 runs, 0 failures**. Main edition: login, func 8, missing, menu 12, persist 15, features 37, back 24, title arrows, preview 13, words 20, roles 57, preview_roles 10, signin_as 25, sec 19, audit_xss, cloud 45, cloud2 36, site 20, linked 8 |

## v5.10 — Owner signs in AS any person + school access control (9 Oct 2026)

`qa/signin_as.js` → **25/25**:
- The owner signs in as a school office user, a teacher, a pupil and a parent. Each time it is a real account (not a
  preview) with that person's own menu and dashboard, and owner-only pages stay closed.
- Works fully as the teacher: a lesson note is submitted under her name and recorded "(done by owner)".
- Survives a reload; "Back to my owner account" returns, and the work is kept.
- A turned-off login cannot be used; signing out ends it.
- The subscription timer never blocks the owner.
- The Control Centre shows trial vs full access and "Give full access" works; a real teacher of an approved school
  gets no 30-second stop.
- The phone bar fits.

Also fixed: switching schools was logged as dozens of fake changes ("Learners (removed)… 65 more"). The comparison
now restarts on a school switch (`qa/cloud2.js` → 36/36, with a new check).

Full regression: all green on all three editions. Main edition, 16 suites: login, func 8, menu 12, persist 15,
features 37, back 24, title arrows 91/91, preview 13, words 20, roles 57, preview_roles 10, signin_as 25, cloud 45,
cloud2 36, site 20.

## v5.9.1 — owner views: Home shortcuts, view one specific person, preview-window check (9 Oct 2026)

| Suite | Result |
|---|---|
| `qa/roles.js` | **57/57**. Adds: "See their screen" shows that exact pupil (studentIndex and linked name), named in the banner; the pupil screen has no staff "Today" strip; switching to a whole group clears the person; the owner's Home has "See the app as" (5 buttons), which opens the teacher screen and hides itself while viewing. |
| `qa/preview_roles.js` | **10/10**. Inside the sandboxed preview frame (like the in-app viewer), the owner opens School office, Teacher, Pupil and Parent from Home, each with its own menu and dashboard, returns each time, with no errors. |

Full regression: all green on all three editions (main edition 15 suites).

## v5.9 — Owner controls every role + faithful "view as" + access fixes (9 Oct 2026)

`qa/roles.js` → **51/51**. The owner opens each interface and every page in its menu opens with no errors:
- School office: 83 pages
- Teacher: 36 pages
- Pupil: 18 pages
- Parent: 12 pages

The run also proves:
- Settings only shows where it works.
- The banner is navy, not gold.
- Teachers get Staff Clock-in and Birthdays.
- Teachers' Print Centre has no money, export or backup items.
- Pupils and parents cannot open Print Centre, from the menu or directly, but still read Announcements and
  Newsletters.
- **Control Centre:** four groups; the owner creates teacher and pupil logins; turn off → that teacher cannot sign
  in; turn on → they sign in to the teacher interface; approve a School office login; "View their screen".
- The owner can also use the old Teacher form.

Live check of the school's Supabase project (`fehpqiqqxgqugioowepu`), read-only and with a fake school:
- reachable
- tables locked from the public key
- all functions up to the activity log present
- **School Web Address functions missing**: re-run the newest setup script

Full regression: all green on all three editions. Main edition, 14 suites: login, func 8, menu 12, persist 15,
features 37, back 24, title arrows 91/91, preview 13, words 20, roles 51, cloud 45, cloud2 35, site 20.

## v5.8 — simple words (10-year-old friendly) + School Web Address (subdomain) (9 Oct 2026)

| Suite | Result | What it proves |
|---|---|---|
| `qa/words.js` | **20/20** | Sign-in screen, menu names, group headings, page titles/explanations, buttons (symbol kept), column titles and "nothing here yet" messages are in simple words. Search finds pages by the old names. User-typed text is never changed. Menu groups still fold. **Show full terms** restores office words, is remembered after a reload and switches back. Phone menu fits. No errors. |
| `qa/site.js` | **20/20** | Suggests a name from the school name, with ideas including dash and town versions. Simple rule messages; Save is disabled for bad names; "Fix it for me" works. System and too-short names are refused. Own domain shows the address and DNS CNAME. Reserved in Supabase; a second school is refused the same name. The website zip has 4 files, the school name, the address and the public Supabase config, and **no secret**. The generated site greets with the school name. The tap-to-connect link connects the phone by itself and the teacher signs in. |

Full regression on all three editions: all green, no failures.
- Main edition: login 3/3, func 8/8, menu 12/12, persist 15/15, features 37/37, back 24/24, title arrows 91/91, preview
  13/13, words 20/20, cloud 45/45, cloud2 35/35, site 20/20.
- premium_secure and connected: login 3/3, classic 14/14, persist 15/15, back 16/16, title arrows 9/9.

## v5.7 — everything in Supabase: files, other schools, settings, preferences, full activity log (9 Oct 2026)

`legacy/qa/cloud2.js` → **35 / 35**, using three browser profiles (Owner computer, teacher phone, brand-new computer).

| Area | Checked |
|---|---|
| Files | A 150 kB logo and a 1.1 MB document go to `abo_files` (the document in 3 parts). The school record holds references only. A later save re-uploads nothing. The phone receives both byte-for-byte. |
| Records | Pricing/owner settings, payment flags and owner preferences go to `abo_records`. A second school goes to `abo_records` and does not leak into the main school. Data is intact after switching back. |
| Privacy | The phone gets shared settings but not the Owner's other school or preferences. |
| Activity | All kinds reach `abo_activity`: sign-in, page opened, change, action, clock-in, security, sync. Changes are described in words ("Calendar (+1)", "Lesson notes (+1)"). Teacher-phone activity arrives. A failed sign-in is recorded with the attempted ID. Office clock-in is recorded. Activity queued offline is uploaded when back online. |
| Screens | Activity Log loads, filters by type and exports CSV. Cloud Sync lists what is stored where. The top-bar indicator survives page changes. |
| Restore | A new computer connecting with the same School ID and secret, then **Download**, gets back the school, learners, accounts, calendar, the phone's lesson note, logo, document, the other school, shared settings, payment flags and preferences. |

Full regression after the change: every suite on all three editions green, 16 suites in total.
- Main edition: login 3/3, func 8/8, menu 12/12, persist 15/15, features 37/37, cloud 45/45, cloud2 35/35.
- premium_secure and connected: login 3/3, classic 14/14, persist 15/15.

## v5.6 — offline edition: Supabase Cloud Sync, fingerprint/face clock-in, clock-in activation (8 Oct 2026)

`legacy/qa/cloud.js` → **45 / 45**. Two separate browser profiles (Owner computer and teacher phone) run against a
local Supabase-compatible stack: PostgreSQL 17, PostgREST 12, and a gateway that enforces `apikey` like Supabase.
Fingerprints use Chrome's virtual authenticator; GPS is emulated.

| Area | Checked |
|---|---|
| Connect | Setup script embedded. Wrong key gives a clear message. Secret key refused. Legacy anon key works. New publishable key is sent only as `apikey`. School uploaded. Secret stored as a bcrypt hash. Public key cannot read the tables. |
| Activation | Self clock-in, fingerprint and GPS rules saved with the school location and radius. Rules strip shown. |
| Device link | `ABO1.` code. A bad code is refused. The phone downloads the school. The teacher signs in with the account the Owner created. |
| Fingerprint | Activation stores the public key. A clock-in at 9 km is refused with the distance. At 28 m with fingerprint it is recorded and sent as a cloud event. An unverified fingerprint is refused. Fingerprint sign-in works. A deactivated phone must be activated again. |
| Sync | Owner → phone and phone → Owner. Both devices edited while offline: merged on both and in the cloud. Clock-in records survive the merge. An offline clock-out is queued and delivered. |
| General | Phone layout, no page errors. The setup script can be run twice safely. |

Full regression after the change:

| Suite | Main edition | premium_secure | connected |
|---|---|---|---|
| Owner sign-in | 3/3 | 3/3 | 3/3 |
| func / classic | 8/8 | 14/14 | 14/14 |
| menu | 12/12 | — | — |
| persist | 15/15 | 15/15 | 15/15 |
| features | 37/37 | — | — |
| cloud | 45/45 | — | — |

Menu entries with a screen: 95/95.

Also fixed: the phone sign-in card was crushed to about 110 px in the original app (clock and card side by side).

## v5.5.3 — offline editions: data guard, phone menu, Klacify-style features (8 Oct 2026)

**Data loss on reload (bug in the original app), now fixed by `legacy/offline-data-guard.js` in all three editions.**
Every sign-in saved blank memory over the school *before* loading it. Opening the page did the same to the Owner's
key. The Owner's key also changed with every letter typed in the school name. Proof on the untouched original with
`legacy/qa/persist.js`: **3/15 passed**. All data was gone after a reload, and typing the name created 19 storage keys.

| Edition | Owner sign-in (tab / offline / preview) | Persistence | Phone menu | Functions | Features | Menu entries with a screen |
|---|---|---|---|---|---|---|
| bopc_erp (main) | 3/3 | **15/15** | **12/12** (`menu_repro.js`) | 8/8 (`func.js`) | **37/37** (`features.js`) | 94/94 (none hidden) |
| premium_secure | 3/3 | **15/15** | 14/14 (`classic.js`, incl. Esc) | in `classic.js` | — | ok |
| connected | 3/3 | **15/15** | 14/14 (`classic.js`) | in `classic.js` | — | ok |

What the persistence check covers:
- learners, school name, calendar, finance, lesson notes, staff and teacher accounts survive a reload and a
  sign-out/sign-in
- a teacher created by the Owner can sign in after a reload, sees the same school, and keeps the session
- nothing is lost after the teacher's visit
- new edits still save

Run everything with `bash legacy/qa/runall.sh` (needs puppeteer). Screenshots are in `docs/screenshots/offline-*.png`.

## v5.5.2 — "can't log in as owner" (30 Sep 2026)

**Cause (reproduced in a real browser):** the owner login ID worked in a normal Chrome tab. It failed when a file was
opened inside a preview window — the in-app file viewer or any sandboxed frame — because those windows block saving.

| File | Before | After |
|---|---|---|
| `school_broadsheet_manager_bopc_erp.html` (offline edition) | normal tab ✔ · no-internet ✔ · **preview ✖** (sign-in crashed on blocked storage) | ✔ ✔ **✔** — a banner says changes are not saved in a preview |
| `school_broadsheet_manager_premium_secure.html` | ✔ ✔ **✖** (storage blocked; the first-time owner password used `prompt()`, which previews and many phones block) | ✔ ✔ **✔** — owner password setup uses an in-page dialog |
| `school_broadsheet_manager_connected.html` | **✖ everywhere** — "Maximum call stack size exceeded" at sign-in (two functions named `saveSchoolData`) | ✔ ✔ ✔ |
| `abo-school-manager.html` (online, single file) | preview / disconnected site: a sign-in form that can never work | explains "Open the school portal"; `GET /api/v1/public/status` probe (no console noise) |

All three offline files also had a Cloudflare tracking snippet, captured when the page was saved from the web, that
threw errors offline; it was removed. The untouched originals are kept in `/home/user/legacy-originals/`.

## v5.5.1 — single-file edition of the full app (`abo-school-manager.html`)

The complete online app was built into one `index.html` with every page, all JS/CSS and the icon inline
(378 kB, 113 kB gzip; CSP by SHA-256 hash, no `'unsafe-inline'`). It was then served as the site's only file behind the
real edge function and the staging-mode API:

| Suite (single file behind the Netlify proxy) | Result |
|---|---|
| `verify:deploy` | **15 / 15** |
| `single.qa.js`: self-contained, hash CSP, no secrets, opened-from-disk screen, staff + student (admission no., phone screen) sign-in, 8 key pages | **17 / 17** |
| UI | **72 / 72** |
| Portal tabs + lesson notes | **28 / 28** |
| CBT end-to-end (uploads through the proxy) | **34 / 34** |
| Menu clicks, 6 roles, desktop + phone | **398 / 398** |
| Menu pages | **247 / 247** |
| API errors / browser errors reported | **0 / 0** |

After the CSP test was changed to accept hash-only script policies, the UI suite was re-run on the multi-file
Netlify layout (72/72) and on the single-host layout (71/71).

`npm test`: **147 / 147**. That is 146 in the full run, where the Redis test is skipped without a Redis server, plus
the Redis test run separately with Redis 8 (the deploy suite passed 9/9). The deploy suite now includes the
single-file build: CSP hashes match the inline code exactly, there are no external files, all pages are bundled in,
and there are no secrets.

## v5.5 run — Netlify frontend + separate API

Two layouts were tested with the same browser suites:

* **A. single-host** — the API serves the unbundled `web/` (development mode).
* **B. Netlify production layout** — the built `dist/web` with its generated `_headers`, served over HTTPS by
  `scripts/netlify-local.js`, which runs the **real** edge function file. The API runs in `staging` mode with
  `SERVE_FRONTEND=false`, `REQUIRE_PROXY_SECRET=true`, secure `__Host-` cookies and a non-owner, NOBYPASSRLS DB role.

| Suite | A. single-host | B. Netlify layout |
|---|---|---|
| `npm run verify:deploy` (live checker: headers, hashed assets, proxy → API, origin allow/deny, direct access blocked, DB ready) | — | **16 / 16** |
| portal tabs + lesson notes (`test:portal`) | **28 / 28** | **28 / 28** |
| UI (`test:ui`) | **71 / 71** | **72 / 72** |
| CBT end-to-end incl. CSV/XLSX/image uploads through the proxy (`test:cbt`) | **34 / 34** | **34 / 34** |
| Menu clicks, 6 roles, desktop + phone (`test:menu-click`) | **398 / 398** | **398 / 398** |
| Menu pages (`test:menu`) | **247 / 247** | **247 / 247** |
| API errors (level ≥ 50) / browser errors reported | 0 | **0 / 0** |

`npm test` → **146 / 146** (8 new in `deploy.test.js`):
- the API refuses direct traffic and takes the client IP only from a verified proxy;
- the secret header is never visible to handlers;
- health checks and payment webhooks stay reachable; API-only mode;
- CORS/CSRF allow-list, with custom-domain and preview patterns handled as configuration only;
- production start-up guards (bad origins, weak/placeholder secrets, missing proxy secret, http webhook);
- the edge function itself: secret and real IP added, spoofed headers stripped, bodies streamed, both cookies kept,
  redirects not followed, previews disconnected, http/unconfigured API refused, 502 when the API is down;
- alert scrubbing (no emails/phones/tokens/ids);
- web build (hashed, code-split, CSP, no secrets);
- **two API instances sharing one rate-limit budget through a real Redis**;
- own-domain direct mode build.

Also verified by hand:
- encrypted backup → checksum → restore into a scratch DB → audit chains verified (`pg_backup.sh` + `restore_test.sh`
  with pg_dump 17);
- the API refuses to start as a superuser/owner DB role;
- `preflight` detects an owner `DATABASE_URL`.

Not verified here: a deploy to a real Netlify/Render account (needs the owner's logins). Run
`npm run verify:deploy -- https://<site>.netlify.app https://<api>` after the first deploy.

## v5.4 run (website parity)

| Suite | Result |
|---|---|
| `npm test` (API + DB, fresh database per file) | **138 / 138** (7 new in `portal_lesson_notes.test.js`) |
| `npm run test:portal` — portal tabs, admission-number / phone sign-in, access-code first sign-in, Lesson Notes cycle in a real browser | **28 / 28** |
| `npm run test:menu-click` (6 roles, real clicks, desktop + phone) | **398 / 398** |
| `npm run test:menu` | **247 / 247** |
| `npm run test:cbt` | **34 / 34** |
| `npm run test:ui` | **71 / 71** |
| Server errors (level ≥ 50) during all browser runs | **0** |

Defects caught while building 5.4: the new lesson-note detail endpoint had no explicit permission guard (caught by the
route-inventory security test, fixed); a school-suspended account could still activate with an old access code (caught by
the new test, fixed — activation now requires an active membership).

## Automated API/DB suite — `npm test` → **138 / 138 passed** (~60 s) · `npm run lint` → syntax ok (123 files)

Each file runs against a freshly created PostgreSQL database with real migrations, RLS and two seeded schools.

| File | Tests | Covers |
|---|---|---|
| unit.test.js | 14 | grading/ranking parity with legacy, component rules, RFC 6238 vectors, AES-GCM tamper, password policy, CSV injection, magic bytes, S3 SigV4 AWS vector, AI prompt PII, legacy analyser, production config guards |
| tenant.test.js | 10 | School A owner/admin/teacher/bursar/student/parent vs School B students, results, broadsheet, CBT, fees, users, roles, files, documents, announcements, attendance, messages; RLS with/without context; composite FKs; runtime role privileges |
| auth.test.js | 16 | generic login errors, cookie flags, opaque tokens, lockout + events, IP rate limit, CSRF (token, origin, fetch-metadata), logout, rotation + grace, expiry, MFA enrol/verify/replay/recovery/brute force, password change/reset, access codes, device sign-out, disable, suspension |
| rbac.test.js | 7 | per-endpoint permissions, BOLA for students/parents, privilege escalation, mass assignment, platform console & read-only support mode, teacher scope, admin MFA reset |
| results.test.js | 8 | server-computed scores, range checks, workflow, four-eyes, DB lock trigger, publish, report cards, corrections + history + versions, AI suggestion never applied |
| cbt.test.js | 6 | builder rules, no answer key in paper, option ownership, server grading, attempt limits, late answers, worker auto-submit |
| finance.test.js | 5 | provider-down → 502 + attempt marked failed, not-configured → 409; invoice generation with approved scholarship, payment validation, receipts, reversal four-eyes, DB constraints, parent scoping, Paystack signature/verification/amount-mismatch/idempotency (local mock of Paystack API) |
| attendance_comms.test.js | 6 | attendance scope/validation/notifications, announcement targeting + XSS payload inert, messaging rules, newsletters, timetable, promotion (no cascade) + undo |
| onboarding.test.js | 2 | registration → verification → activation → MFA → checklist; settings validation; logo upload attacks; authorised file download |
| security.test.js | 11 | headers, error hygiene, SQLi, size/content-type limits, upload attacks, audit immutability + tamper detection, audit coverage, BOLA sweep (all `:id` routes × 20+ foreign ids), metrics protection, frontend secret scan, route inventory |
| platform.test.js | 17 | `create-platform-admin` ops script (validation, forced change, duplicate); memberships (invite/accept/switch, identity protection), email login & name parts, branch isolation (API + RLS), token-reuse detection, Idempotency-Key (sequential + concurrent), parallel over-payment race, multi-invoice allocations, student charges, concurrent score saves (409), double CBT submit, CORS, automatic security events, DTO guard, OpenAPI, legacy account/audit import, teacher assignments & attendance sessions |
| robustness.test.js | 3 | **crawl of all 178 OpenAPI operations** × 8 roles + anonymous with random/malformed/SQLi/over-long ids, hostile query strings and malformed bodies (3.7k requests), then **schema-generated valid bodies** (min, boundary-max, foreign-school ids) and real deletes (~4.5k more) → asserts never 5xx, never leaks SQL/stack, always the standard envelope; router-level errors never reflect the URL |
| cbt_v2.test.js | 11 | CBT end-to-end: 8 question types + validation, bank search/filters/pagination/duplicate/archive/delete, CSV import (invalid rows never inserted, commit once, uploader-only), export, wizard defaults, auto-generation with shortfall refusal, reorder, readiness gate, candidates (class → explicit), teacher scope, cross-tenant 404s, access code, no key leakage, autosave idempotency, flags, resume, IDOR, automatic + manual marking, duplicate submit, release/withhold, result page, analytics, **push to the existing sheet → broadsheet → report card**, locked-sheet refusal, timer expiry, no-back-nav, no-resume, reset, close, scheduling + reminder job, audit trail |
| cbt_hall.test.js | 1 | 30 candidates behind ONE IP at the production rate limit: 960 requests, 0 × 429, 0 × 5xx, answers stored once, all marked |
| menu_features.test.js | 6 | school approval (pending → verified → approved), approval e-mail with the branded link, public portal exposes only ACTIVE schools and minimal fields; logo/colour/ETag; head of school + signature visible to parents only in-school; results overview, approval queue (four-eyes), processing, annual broadsheet; analytics (scope, cross-tenant 404, student trend), teacher activity; system info without internals; backup workbook job; **every export dataset in CSV + XLSX** (found a crashing Payments export) |
| portal_lesson_notes.test.js | 7 | admission-number & phone sign-in (formats, school scope, ambiguity refused, staff tab, other school), access code in the password box → create password (no session from a code, single use), suspended account cannot activate; lesson notes: assignment scope, drafts private, tenant isolation, versioned edits, attachments (unsafe type refused), submit → notify → return (comment required) → approve → class + parents read (no reviewer fields), other class hidden, locks, reopen, no self-approval, coverage report, audit trail |
| data.test.js | 6 | CSV import preview/commit, error report, bad files, exports (permissions, audit, formula injection, XLSX), async export job, score import, legacy migration |

Defects found **by these tests** and fixed (round 3, 30 Sep: `scripts/create-platform-admin.js` had a syntax error (`await` in a non-async callback) so the first-admin bootstrap could never run; `pay-online` answered **503** when a school had no Paystack keys (would page on-call / trip LB health) → now 409 `NOT_CONFIGURED`; Paystack network failure/timeout escaped as **500** and left a dangling `pending` payment → now 502 `UPSTREAM_UNAVAILABLE` + attempt marked `failed`; router errors (bad %-encoding, over-long params) bypassed the error envelope and echoed the raw URL; three hand-written error bodies lacked `requestId`; npm backup/restore scripts depended on the executable bit. Round 2 additions: a payment **deadlock** under concurrency, an RLS
`INSERT … RETURNING` visibility bug for newly created identities, an unreferenced SQL parameter). Round 1: cross-tenant ids returning `200` with empty data on
6 endpoints (now `404`), broadsheet `500` for foreign ids, a PostgreSQL parameter-type bug in CBT grading, an
unreferenced-parameter bug in staff announcements, webhook tenant resolution blocked by RLS (fixed with a narrow
definer function), privilege-escalation guard blocking legitimate student/parent account creation.

## Menu click QA — `npm run test:menu-click` → **382 / 382 passed** (v5.3 menu)

v5.3 adds: the TOP-BAR menu button collapses/expands the sidebar at 1366 px and 1024 px (the old one was visible on desktop but only worked on phones — a CSS precedence bug), one-section-at-a-time, emoji-free menu, tapping the current page closes the phone drawer.

Previous run (v5.2 menu): 417 / 417

Drives the sidebar with real mouse clicks and taps (6 roles, desktop + phone): every section header toggles, every item navigates and highlights, Back keeps the highlight in sync, open sections survive reload, menu search + Enter, no-match message + clear, collapse to icons, Ctrl+/; on phones the drawer (☰, bottom Menu, scrim), section taps, link taps, bottom-bar shortcuts, and **no page wider than the screen**. Found & fixed: clicking an icon in collapsed mode closed the section instead of opening it; report sheets made phone pages 585 px wide, pushing the bottom **Menu** button off-screen (My Results, Print Reports, Download PDF); empty menu with no hint when a search matched nothing.

## CBT browser QA — `npm run test:cbt` → **34 / 34 passed**

Exam officer imports 19 questions (1 invalid row rejected) and writes 1 in the editor (live maths preview), builds the exam in the 5-step wizard with automatic selection, publishes; the student uses the access code, answers 20 questions with autosave, flags one, goes back, survives an offline blip (banner, local queue, resync) and a page refresh (resume), checks the summary and submits; officer releases, previews and sends scores to the result sheet; broadsheet and report card show the score; analytics, printable answer sheet and the student result page render; the audit trail is complete; no console errors. Found & fixed: `null` text rendered by native `append()` in several pages (now guarded by the menu crawler), a CSS class clash in the maths renderer, cramped phone buttons; CSV exports failing in read-only transactions; login and API rate limits locking out classes that share one school IP.

## Menu QA — `npm run test:menu` → **262 / 262 passed** (headless Chrome 148)

Opens **every menu entry** as owner, teacher, exam officer, bursar, parent, student and platform admin; fails on console errors, 5xx, error states, “access denied” pages (a visible entry the server refuses) and wrong highlighting. Also: logo upload + colour through the UI, menu search, collapse, CA-only sheet mode, batch report printing, the branded `/#/s/<slug>` sign-in page (logo + name, unknown school refused, sign-out returns to it) and the phone menu. Found & fixed: Subject Allocation denied for teachers (fetched staff list they may not read), sidebar header squashed by a long menu, dark brand colours making menu accents invisible, oversized donut charts.

## Browser QA — `npm run test:ui` → **71 / 71 passed** (headless Chrome 148)

Owner (with real MFA enrolment), teacher, student (phone 390×844), parent (dark mode), bursar and platform admin:
30+ pages render without console errors, CSP violations or 5xx; cookie is HttpOnly/SameSite=Strict and unreadable
from JS; nothing sensitive in localStorage; XSS probe not executed; teacher typing a finance URL gets a server 403;
attendance saves; no horizontal overflow on phones. Screenshots: `docs/screenshots/`.

## Backup / restore drill — passed (encrypted dump → checksum → restore → audit chains verified)

## Performance

See **LOAD_TEST.md** (5,222 accounts, 800 concurrent users, 0 × 5xx, slow-query fixes). Earlier micro-benchmark:

### Micro-benchmark (sandbox — indicative only)

Data: 102 schools, 50,054 students, 1,000,000 attendance rows.

* `EXPLAIN ANALYZE` as `abo_app` under RLS: student list → Bitmap Index Scan on `students_school_status_idx`,
  0.30 ms; class attendance for a day → Index Only Scan on `attendance_class_date_idx`, 0.18 ms.
* HTTP (`scripts/bench.js`, mixed authenticated reads, one Node process sharing 2 vCPUs with PostgreSQL):
  * 50 concurrent: 431 req/s, p50 107 ms, p95 168 ms, p99 327 ms, 0 errors
  * 100 concurrent: 466 req/s, p50 206 ms, p95 279 ms, p99 336 ms, 0 errors

The API is stateless, so throughput scales with replicas; production sizing must be confirmed with a load test on
the target infrastructure.

## Dependencies

`npm audit --omit=dev` → **0 vulnerabilities** (9 direct runtime dependencies, exact versions pinned).

## Update 11 Oct 2026: cumulative results, install as app, phone fixes

Details: `docs/CUMULATIVE_INSTALL_MOBILE.md`.

- **`npm test`:** 175 passed, 0 failed (176 tests; the Redis case runs with `TEST_REDIS_URL`: `deploy.test.js` 10/10).
- **Browser suites, run on a fresh demo database each:** `bash legacy/qa/e2e_all.sh` (copy of `.qa/e2e_all.sh`).
  - menu 294/294
  - menu_click 253/253
  - ui 71/71
  - cbt 34/34
  - portal_lessons 28/28
  - school_life 19/19
  - store_comments_idcards 16/16
  - materials_monitor 17/17
  - migrate 8/8
  - owner_tools 14/14
  - passkeys 9/9
  - **cumulative 25/25** (new)
  - **install_layout 23/23** (new)
  - **mobile_tap 972/972** (new)
- **Offline edition:**
  - Full regression: 37 runs, 0 failures.
  - New tests: cumulative_off 24/24, mobile_tap 576/576, device_off 18/18.
- **Phone tests use a real Android user agent.** See `server/test/e2e/phone.js`. The apps now treat "computer browser name on a small touch screen" as the browser's *Desktop site* switch.
