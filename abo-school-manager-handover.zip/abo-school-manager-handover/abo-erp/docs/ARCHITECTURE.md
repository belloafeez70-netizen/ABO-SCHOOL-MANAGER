# Architecture

```
 Browser (untrusted)  ── HTTPS ──►  Cloudflare (CDN · WAF · DDoS · TLS)  ──►  Fastify API (N stateless instances)
   web/ (ES modules,                                                        │  authN (sessions, Argon2id, TOTP)
   strict CSP, no                                                           │  authZ (RBAC + ownership checks)
   secrets, no data                                                         │  validation (JSON schema, no extra fields)
   in localStorage)                                                         │  audit · rate limits · metrics
                                                                            ▼
                                       PostgreSQL 15+ (RLS on every tenant table, runtime role NOBYPASSRLS)
                                       Object storage (private bucket, 60 s presigned URLs)
                                       Worker(s): email, exports, CBT auto-submit, housekeeping (SKIP LOCKED queue)
```

## Repository layout

```
server/src/
  config/        environment config; aborts in staging/production on missing/placeholder secrets
  db/            pool (withTx sets tenant context), migrations/*.sql, grants.sql, bootstrap, migrate, seed-dev
  security/      passwords (Argon2id + policy), totp (RFC 6238), crypto (AES-256-GCM, HMAC, tokens)
  auth/          sessions (opaque tokens, rotation), plugin (authenticate, perm(), CSRF, support mode)
  rbac/          permission catalogue + 14 role templates
  audit/         audit writer (hash chain via app.audit_append), security & login events
  services/      grading (pure, legacy-parity), results (DB compute), cbt grading, provisioning, notify, mailer
  storage/       local + S3 (SigV4) drivers, magic-byte sniffing, ClamAV client
  routes/        20 route modules → 179 endpoints (see docs/API.md)
  jobs/worker.js Postgres-backed job queue + sweeps
server/test/     node:test suites against real PostgreSQL + e2e/ui.qa.js (headless Chrome)
web/             index.html (no inline JS/CSS), assets/css, assets/js/{core,pages}
deploy/          backup/restore scripts, monitoring alert rules
```

## Identities, memberships and branches

`users` are **global identities** (Login ID or email + Argon2id password + MFA). Access to a school is a
`school_memberships` row (`invited → active → suspended/left`, optionally restricted to a `branch_id`). A proprietor
can run several schools with one account: other schools **invite** the existing identity, the user accepts, and
switches school from the menu (`POST /auth/switch-school`, token rotated, MFA re-evaluated for that school).
Identity-level operations (renaming, access codes, MFA reset) are refused to a school when the identity also belongs
to another school — a school can always suspend **its** membership. Branch-restricted members get `app.branch_id`
set per transaction; RESTRICTIVE RLS policies on classes, students, staff and class/student-derived tables
(enrolments, attendance, assessments, invoices, CBT…) hide other branches at the database level.

## Multi-tenancy (defence in depth)

1. **Tenant from the session's active membership only.** `req.auth.schoolId` comes from the server-side session row (validated against an *active* membership on every request); no route accepts a
   school id from the client (bodies with `schoolId` are rejected by schema).
2. **Row-Level Security.** Every school-owned table has `school_id` and a policy
   `USING/WITH CHECK (school_id = app.current_school())`. `withTx()` sets `app.school_id` transaction-locally.
   The runtime role `abo_app` is not the owner and has `NOBYPASSRLS`, so a forgotten `WHERE` still cannot leak.
   No tenant context ⇒ zero rows.
3. **Composite foreign keys** `(school_id, x_id) → parent(school_id, id)` make cross-school links impossible even
   for the schema owner (e.g. enrolling School A's student into School B's class).
4. **Existence checks return 404** for foreign ids (no information leak); an automated BOLA sweep hits every `:id`
   route with other-tenant ids.
5. Cross-tenant operations that must happen before a tenant is known (login lookup, session resolution, webhook
   routing, platform statistics, job claiming) use narrow `SECURITY DEFINER` functions returning only needed columns.

## Authentication & sessions

* Login ID + password (Argon2id, OWASP params, transparent rehash) → opaque 256-bit token in an
  `HttpOnly; Secure; SameSite=Strict` cookie (`__Host-` prefix in production). DB stores only `sha256(token)`.
* Idle (120 min) + absolute (72 h) expiry; rotation every 15 min and on every privilege change (60 s grace).
* Progressive lockout (5 failures → 5, 10, 20… min, capped), per-IP rate limits, credential-stuffing heuristic,
  new-device detection (notification + email), per-user session cap, device list & remote sign-out.
* MFA: TOTP (encrypted seed, replay-protected), 10 single-use recovery codes; **required** for roles flagged
  `mfa_required` or listed in the school's policy (owner, bursar, accountant, administrator, principal, ICT by
  default) and for platform admins in staging/production. Pending/enrol-required sessions can reach only MFA routes.
* First access for staff/students/parents: admin issues a one-time **access code** (hashed, 7-day expiry); user sets
  their own password (preserves the legacy "Login ID" experience without password-less accounts).

## Authorisation

`permissions` (68 keys) → `role_permissions` → `roles` (per school; 14 system templates + custom) → `user_roles`.
Every route declares `app.perm(...)`; handlers add ownership rules (teacher ↔ assigned class-subject, form teacher ↔
attendance, student ↔ self, parent ↔ linked children, message participants). Escalation guard: you can only grant
roles/permissions you hold (self-scoped portal permissions excepted); School Owner role is locked; last owner kept.
Platform admins have no school data access except a time-limited, read-only, reason-stated **support view** that is
written to both the platform and the school's audit chain.

## Results integrity

`draft → submitted → reviewed → approved → published` (the review step can be switched off per school). Neither the
review nor the approval may be done by the submitter. A statement-level DB trigger refuses any change to scores of a
non-draft sheet unless the transaction sets `app.correction_sheet` to that sheet — which only the approved correction
path does. Every save bumps the sheet `version` (optimistic locking: a stale save gets 409). Every score change lands in `assessment_score_history`. Publishing computes term results and
writes a versioned broadsheet snapshot; corrections to published results create a new version.

## CBT integrity

Answer keys never leave the server; question/option order is shuffled server-side with a CSPRNG and stored on the
attempt; the deadline is fixed at start from the server clock; late answers are refused and the attempt is
auto-submitted; the worker sweeps abandoned attempts; objective grading is server-side; theory is teacher-graded;
focus-loss events are recorded.

## Finance integrity

Integer kobo; `fee_categories` → `fee_structures` (per term/class) → invoices with `invoice_items` (structure lines +
student-specific charges) minus **approved** discounts (four-eyes). A payment is split across one or more invoices via
`payment_allocations` (e.g. a parent paying for two children) and gets exactly one `receipt`; allocations are
validated against row-locked balances (invoices locked first, in id order — deadlock-free) and a deferred constraint
trigger guarantees allocations never exceed the payment. `Idempotency-Key` makes retries safe; unique references and gap-free receipt numbers; reversals by a
different officer; DB check constraints (`paid ≤ total`, `total = subtotal − discount`). Online payments are
initialised server-side and credited only after HMAC-SHA512 webhook verification **and** server-to-server
verification of amount/currency with the provider; replays are idempotent.

## Scalability

Stateless API (sessions in DB) → scale horizontally; per-tenant composite indexes; server-side pagination (max 100),
search (trigram index for names), sorting whitelist; permission cache (30 s) to cut per-request queries; background
jobs for heavy exports; object storage for files; CDN for static assets. See `TEST_REPORT.md` for measured numbers.
