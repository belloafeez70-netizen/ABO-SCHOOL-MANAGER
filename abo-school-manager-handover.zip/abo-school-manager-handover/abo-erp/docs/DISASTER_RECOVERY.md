# Backups & disaster recovery

**Targets (recommended):** RPO ≤ 5 minutes (managed PITR/WAL), RTO ≤ 2 hours.

## Layers

1. **Managed PITR** on the production database (continuous WAL archiving by the provider). *Must be enabled in the
   provider console — the application cannot enable it.*
2. **Nightly logical backups** — `deploy/backup/pg_backup.sh`: `pg_dump -Fc`, SHA-256 checksum, AES-256 encryption
   (`BACKUP_ENCRYPTION_KEY`), upload to a separate account/bucket (`BACKUP_S3_URI`) with lifecycle retention
   (e.g. 35 daily, 12 monthly) and ideally Object Lock.
3. **Object storage** — bucket versioning + cross-region replication for uploaded files.
4. **Audit export** — daily CSV/XLSX export of audit logs to WORM storage (`GET /exports/audit`).

## Restore drill (verified in this build)

```bash
BACKUP_DATABASE_URL=postgres://abo_owner:…@host/abo_erp BACKUP_ENCRYPTION_KEY=… bash deploy/backup/pg_backup.sh
RESTORE_ADMIN_URL=postgres://admin:…@scratch-host/postgres BACKUP_FILE=backups/abo-<ts>.dump.enc BACKUP_ENCRYPTION_KEY=… bash deploy/backup/restore_test.sh
```

The drill verifies the checksum, decrypts, restores into a throw-away database, prints row counts and **verifies
every school's audit hash chain**, then drops the scratch DB. Output from the run performed for this build:

```
backup ok: /tmp/abo-backups/abo-20260929T192236Z.dump.enc (264K)
checksum ok
restored into abo_restore_drill_1790709761
schools=2  students=54  audit_rows=10  migrations=10
restore drill ok: all audit chains verified
```

Schedule it weekly (cron/CI) and after any change to backup configuration.

## Scenarios

| Scenario | Action |
|---|---|
| Bad deploy (code) | Redeploy previous image tag. |
| Bad migration / mass data corruption | PITR restore to a new instance at T-1 min before the event → verify → repoint `DATABASE_URL` → rotate DB passwords. |
| Single school's data damaged | PITR restore to a scratch instance; export that school's rows (all tables filter by `school_id`) and re-import in a maintenance transaction; record in the audit log. |
| Region outage | Restore latest PITR/replica in the secondary region, restore bucket replica, switch DNS in Cloudflare. |
| Credential leak | Rotate the affected secret (DB role passwords, `CSRF_SECRET`, S3 keys, Paystack/AI keys); revoke all sessions: `UPDATE sessions SET revoked_at = now() WHERE revoked_at IS NULL;` |
| `DATA_ENCRYPTION_KEY` lost | TOTP seeds cannot be decrypted → users sign in with recovery codes or an admin resets MFA; keep this key in the secrets manager with backup. |

## Data export for schools

Schools can export students, staff, parents, broadsheets, invoices, payments, attendance and audit logs (CSV/Excel)
from **Import & export**; all exports are permission-checked and audited.
