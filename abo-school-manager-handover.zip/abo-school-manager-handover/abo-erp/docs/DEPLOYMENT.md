# Deployment guide

> **Netlify frontend + separate API:** follow **[NETLIFY_DEPLOYMENT.md](NETLIFY_DEPLOYMENT.md)** (recommended, v5.5). This page covers the
> single-host / Docker details that still apply to the API service.

## Environments

| | development | test | staging | production |
|---|---|---|---|---|
| NODE_ENV | development | test | staging | production |
| Secrets | derived dev-only values | derived | **required** (startup aborts) | **required** |
| Cookies | not Secure (http://localhost) | — | `__Host-` Secure | `__Host-` Secure |
| DB TLS | off | off | require | require (+ CA) |
| Worker | in-process | manual | separate process | separate process(es) |
| Email | logged (`dev_logged`), not sent | same | SMTP | SMTP |

Never reuse production secrets or data in other environments.

## 0. Go-live preflight (run on the production server before switching the school over)

```bash
npm run preflight -- --env-file .env     # ✔ PASS / ! WARN / ✖ FAIL per check; exit code 1 on any FAIL
```

Checks: `NODE_ENV=production`, strong secrets, real `https://` origin, secure cookies, DB TLS, runtime DB role cannot bypass
RLS, all migrations applied, a platform admin exists, **no demo data**, SMTP, storage driver, Paystack live vs test key,
Redis for multi-instance rate limits, ClamAV, metrics token, manual school approval. Backups and DNS/HTTPS are listed as
manual confirmations. Suggested minimal stack for one school (~1,000 users): 1 × 2 vCPU/4 GB VPS (API + worker), managed
PostgreSQL with PITR, Cloudflare in front, an SMTP provider, Paystack live keys.

## 1. Database (managed PostgreSQL 15+ recommended: AWS RDS/Aurora, GCP Cloud SQL, Azure Flexible, Neon, Supabase, DO)

Enable automated backups with **point-in-time recovery** (≥ 7–35 days) and a private network endpoint. Then, as the
admin user, run once (equivalent to `server/src/db/bootstrap.js`):

```sql
CREATE ROLE abo_owner LOGIN PASSWORD '<strong>' NOSUPERUSER NOCREATEDB NOCREATEROLE;
CREATE ROLE abo_app   LOGIN PASSWORD '<strong>' NOSUPERUSER NOCREATEDB NOCREATEROLE NOBYPASSRLS NOINHERIT;
CREATE DATABASE abo_erp OWNER abo_owner;
REVOKE ALL ON DATABASE abo_erp FROM PUBLIC; GRANT CONNECT ON DATABASE abo_erp TO abo_app;
\c abo_erp
CREATE EXTENSION IF NOT EXISTS pg_trgm;
ALTER SCHEMA public OWNER TO abo_owner; REVOKE CREATE ON SCHEMA public FROM PUBLIC;
```

Migrations (every deploy, before the new app version starts): `MIGRATION_DATABASE_URL=… npm run migrate`.
Migrations are transactional, checksummed and serialised with an advisory lock.

## 2. Application

```bash
bash scripts/gen-secrets.sh >> .env        # then fill in the rest of .env from .env.example
docker build -t abo-erp:$(git rev-parse --short HEAD) .
docker run --env-file .env -p 127.0.0.1:8080:8080 abo-erp:<tag>              # API + static frontend
docker run --env-file .env abo-erp:<tag> node server/src/jobs/worker.js       # worker (1+ replicas)
PLATFORM_ADMIN_LOGIN=abo.admin PLATFORM_ADMIN_EMAIL=you@… node scripts/create-platform-admin.js
```

Run ≥ 2 API replicas behind the load balancer; set `RATE_LIMIT_REDIS_URL` (and `npm i ioredis`) when > 1 replica.
Container runs as non-root, read-only root FS (compose file shows the hardening flags). Health: `/healthz`
(liveness), `/readyz` (DB). Scale DB connections: `DB_POOL_MAX × replicas` < DB max connections (use PgBouncer in
transaction mode if needed — `withTx` uses only transaction-local settings, which is PgBouncer-compatible).

## 3. Object storage

Create a **private** bucket (Cloudflare R2, S3, B2, Spaces). Block public access, enable versioning + lifecycle
rules, and give the app an access key limited to that bucket (`s3:GetObject`, `s3:PutObject`, `s3:DeleteObject`).
Set `STORAGE_DRIVER=s3` and the `S3_*` variables. Optional malware scanning: run clamd and set `CLAMAV_HOST`.

## 4. Domain, HTTPS, WAF / CDN (Cloudflare example)

1. DNS `app.yourdomain` proxied (orange cloud). SSL/TLS mode **Full (strict)**; enable HSTS (the app also sends it),
   minimum TLS 1.2, Always Use HTTPS.
2. Origin not publicly reachable: use **Cloudflare Tunnel** (`cloudflared`) or firewall the origin to Cloudflare IP
   ranges only. With a tunnel on the same host keep `TRUST_PROXY=loopback`; otherwise list Cloudflare CIDRs.
3. WAF: enable Managed Rules (OWASP core ruleset), Bot Fight Mode; custom rules:
   * rate-limit `POST /api/v1/auth/*` to 20/min per IP; `POST /api/v1/onboarding/register` 5/hour per IP;
   * block non-`GET/POST/PUT/PATCH/DELETE` methods; block requests to `/metrics` from the internet.
4. Cache static assets (`/assets/*`) at the edge; never cache `/api/*` (the app sends `Cache-Control: no-store`).
5. Set `PUBLIC_ORIGIN` / `ALLOWED_ORIGINS` to the exact https origin.

## 5. Email, payments, AI

* `SMTP_URL` for password reset / verification / new-device alerts (SPF, DKIM, DMARC on the sending domain).
* Paystack: set `PAYSTACK_SECRET_KEY`; webhook URL `https://app.yourdomain/api/v1/payments/webhook/paystack`.
* AI (optional): `AI_PROVIDER_URL` (OpenAI-compatible), `AI_API_KEY`; schools opt in under Settings.

## 6. Backups & monitoring

* Managed PITR (primary) + nightly logical backups with `deploy/backup/pg_backup.sh` to **separate** storage
  (encrypted, checksummed), weekly `restore_test.sh` drill (see `DISASTER_RECOVERY.md`).
* Scrape `/metrics` with `Authorization: Bearer $METRICS_TOKEN` (from inside the private network); load
  `deploy/monitoring/alerts.yml`; ship JSON logs to your log platform; alert on high-severity security events
  (`GET /api/v1/platform/security-events?severity=high`).

## 7. API docs, CORS, abuse thresholds

* `API_DOCS=public|authenticated|off` — OpenAPI at `/api/v1/openapi.json` (default: authenticated in staging/production).
* `ALLOWED_ORIGINS` is both the CSRF origin allow-list and the CORS allow-list (exact origins, comma-separated).
* `EXPORT_ALERT_PER_HOUR` (default 20) — exports per user per hour that raise an `abnormal_export_activity` event.
* Load testing: see docs/LOAD_TEST.md (`scripts/loadtest/*`; never against production data).

## 8. Release & rollback

1. CI green (tests + `npm audit`). 2. Backup/snapshot. 3. `npm run migrate` (additive, backwards-compatible
migrations only — drop columns one release later). 4. Rolling deploy of API + worker. 5. Smoke test `/readyz`, sign-in.
**Rollback:** redeploy the previous image tag (schema remains compatible). The latest migration can be reverted with
`npm run migrate:down -- <version>` when it ships a down script (013, 014 do); data-transforming migrations (011, 012) are reverted by restoring the pre-deploy PITR timestamp into a new instance and repointing `DATABASE_URL` (see DR guide).
