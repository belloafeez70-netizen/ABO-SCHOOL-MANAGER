# Specification coverage — "Backend, PostgreSQL, API & Security Implementation" (53 phases)

✅ implemented and verified by automated tests / recorded runs · 🔧 implemented; activation needs an external service
or account · ⚠️ partial (reason given). File paths are relative to `server/src` unless noted.

| # | Phase | Status | Where / evidence |
|---|---|---|---|
| 1 | Architecture (client → HTTPS → CDN/WAF → API → authN → RBAC → services → PostgreSQL → object storage) | ✅🔧 | `app.js`, docs/ARCHITECTURE.md; browser never talks to the DB; no credentials in `web/` (secret-scan test). CDN/WAF = Cloudflare config in DEPLOYMENT.md |
| 2 | PostgreSQL, migrations, normalised schema, UUID PKs, FKs, UNIQUE/NOT NULL/CHECK, indexes, timestamps, soft delete, transactions, UTC | ✅ | 14 checksummed migrations (`db/migrations`), 73 tables, 128 FKs, 118 CHECKs, 201 indexes; `timestamptz` everywhere; soft delete on students/uploads; every handler runs in `withTx` |
| 3 | `schools` (slug, registration_number, subscription…) + `school_branches` (code, status) | ✅ | 001 + 011 |
| 4 | `users` with first/middle/last name, Argon2id hash, email_verified_at, last_login_at | ✅ | 001 + 011 (name trigger); hashes never returned (DTO guard test) |
| 5 | `school_memberships` (user ↔ school ↔ branch) | ✅ | 011; invite/accept/switch + identity protection — platform.test.js |
| 6 | roles / permissions / role_permissions / user_roles; 15 roles | ✅ | 14 school templates + platform super-admin; stored and enforced server-side |
| 7 | Granular permissions (students.update, results.approve, audit_logs.view, settings.update …) | ✅ | 73 keys in `rbac/catalog.js`, synced to DB; route-inventory test proves every endpoint is guarded |
| 8 | students, guardians, student_guardians, student_enrollments, classes, class_members | ✅ | admission no, DOB, contacts, admission date, branch, history, status |
| 9 | teachers, staff, teacher_assignments; teachers only see assigned classes/subjects | ✅ | 012 (`teachers` with TRCN, `teacher_assignments`, `teacher_class_access` view); assignment/revocation test |
| 10 | academic_sessions, terms, classes, streams, subjects, class_subjects, enrollments | ✅ | per-school configuration, nothing hard-coded |
| 11 | assessments, assessment_components, assessment_scores, examinations, examination_scores, result_summaries, report_cards, broadsheets; configurable grading | ✅ | components table + per-school grade bands; `examinations`/`examination_scores` views over the same data |
| 12 | DRAFT → SUBMITTED → REVIEWED → APPROVED → PUBLISHED; locked; audited corrections | ✅ | DB trigger locks every non-draft sheet; four-eyes; correction workflow — results.test.js |
| 13 | cbt_exams/questions/options/attempts/answers/results; timing, randomisation, limits, autosave, auto-submit, server grading | ✅ | cbt.test.js + concurrency test (double submit) + forged-score rejection |
| 14 | attendance_sessions + attendance_records, unique per student/day | ✅ | 012; `UNIQUE (student_id, date)`, `UNIQUE (class_id, date)` |
| 15 | fee_categories, fee_structures, invoices, invoice_items, payments, payment_allocations, receipts; class/student charges, discounts, balances | ✅ | `routes/finance.js`; server-computed totals; allocations across invoices |
| 16 | announcements, messages, conversations, notifications, newsletters — tenant-aware | ✅ | RLS + participant checks |
| 17 | File metadata + private object storage + signed URLs | ✅🔧 | `uploads`/`documents`; S3 SigV4 presign verified against AWS vector; bucket needed |
| 18 | Tenant from server-side identity + membership; never client `school_id`; non-revealing denials | ✅ | `auth/plugin.js`; unknown/foreign ids → 404 (non-revealing, OWASP-recommended); BOLA sweep |
| 19 | Row-Level Security as defence in depth | ✅ | 70 tables with RLS, 90 policies incl. 17 RESTRICTIVE branch policies; runtime role NOBYPASSRLS |
| 20 | Versioned REST API, consistent methods/status/schemas/errors/pagination/filtering/sorting | ✅ | `/api/v1`, 179 endpoints, docs/API.md, docs/openapi.json |
| 21 | Short-lived session + rotation + revocation + secure cookies | ✅ | opaque session, 120 min idle / 72 h absolute, rotation every 15 min & on privilege change, **reuse detection** revokes the family |
| 22 | Argon2id, strength rules, reset/change, expiring one-time tokens, throttling, suspicious logins | ✅ | auth.test.js |
| 23 | TOTP MFA: enrol, verify, disable with re-auth, recovery codes, revocation, enforce for privileged roles | ✅ | auth.test.js, rbac.test.js (admin reset) |
| 24 | Reusable authN → tenant → membership → role → permission → ownership middleware | ✅ | `authenticate`, `perm()`, `ctx()`, ownership helpers; no per-controller auth copies |
| 25 | Schema validation, unknown fields rejected, mass-assignment protection, file/pagination/sort validation | ✅ | Ajv `removeAdditional:false`; tests |
| 26 | Parameterised SQL + SQLi tests | ✅ | security.test.js |
| 27 | IDOR/BOLA on students/results/fees/cbt/documents | ✅ | BOLA sweep (every `:id` route × foreign ids) + tenant.test.js |
| 28 | Rate limits (login, reset, MFA, register, API, reports, exports, CBT submit) | ✅🔧 | per-route limits, per-session keys for exports/reports/payments; Redis for multi-instance |
| 29 | Strict CORS (no `*`) | ✅ | `@fastify/cors` allow-list — platform.test.js |
| 30 | CSRF with cookie auth, tested | ✅ | SameSite=Strict + Origin/Fetch-Metadata + HMAC token — auth.test.js |
| 31 | HSTS, CSP, nosniff, Referrer-Policy, Permissions-Policy, frame protection | ✅ | security.test.js; CSP has no unsafe-inline/eval (browser QA) |
| 32 | Tamper-resistant `audit_logs` with the listed events | ✅ | hash chain, no DML grants, triggers; tamper-detection test |
| 33 | Security events: failed logins, escalation, cross-tenant, export bursts, suspicious API use, repeated denials | ✅ | `lib/secmon.js` + auth/finance hooks — platform.test.js |
| 34 | Indexes from access patterns, composite tenant indexes | ✅ | EXPLAIN evidence in LOAD_TEST.md |
| 35 | Pagination with safe max page size | ✅ | `pageSize ≤ 100` enforced by schema |
| 36 | Transactions for multi-step writes | ✅ | enrolment, invoicing, allocation, approval, publication, CBT submit, role changes |
| 37 | Concurrency: lost updates, duplicate payments/submissions, conflicting edits | ✅ | row locks, optimistic `expectedVersion`, Idempotency-Key, unique constraints — concurrency tests with `Promise.all` |
| 38 | Server-side calculations | ✅ | grading/ranking/CBT/finance on the server; forged client values rejected |
| 39 | Response DTOs, no sensitive data | ✅ | explicit column lists + DTO guard |
| 40 | `{ "error": { "code", "message" } }`, non-revealing | ✅ | global error handler |
| 41 | Migrations + rollback strategy + seeds + test DB | ✅ | checksummed runner, `npm run migrate:down` (down scripts for 013/014; data-transforming 011/012 → PITR/forward-fix), per-test fresh DB |
| 42 | Safe dev/test seed data incl. demo results | ✅ | `db/seed-dev.js` (fictional names, `.example` emails, published demo results) |
| 43 | localStorage → PostgreSQL migration incl. accounts & audit | ✅ | `/migration/legacy/*`: validated; accounts become PENDING + access codes; audit imported flagged unverified |
| 44 | Frontend uses the API (auth, loading, errors, pagination, authz errors) | ✅ | `web/`; browser QA 71/71 |
| 45 | OpenAPI documentation | ✅ | `/api/v1/openapi.json` (public in dev, authenticated in prod) + docs/openapi.json |
| 46 | Security test suite (all listed cases) | ✅ | 106 tests, all passing |
| 47 | Load/performance testing with EXPLAIN | ✅ | docs/LOAD_TEST.md (5.2k accounts, 800 concurrent users) |
| 48 | Backups with a TESTED restore | ✅🔧 | encrypted backup + restore drill executed; enable PITR at the provider |
| 49 | Secrets via env; `.env.example` placeholders only | ✅ | prod config refuses missing/placeholder secrets (unit test) |
| 50 | dev / test / staging / production separation | ✅ | `config/index.js` |
| 51 | Deployment docs (13 items) | ✅ | docs/DEPLOYMENT.md, Dockerfile, docker-compose.yml, CI |
| 52 | No fake security | ✅ | external dependencies listed in QUALITY_GATE.md; dev-only shortcuts clearly labelled |
| 53 | Final audit checklist | ✅ | docs/QUALITY_GATE.md |
