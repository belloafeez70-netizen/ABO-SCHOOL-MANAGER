# Phase 7: testing and load tests (1,000 schools / 200,000 users)

**Date:** 10 Oct 2026
**Where:** this computer (a sandbox with **2 CPU cores and 2 GB memory**). PostgreSQL 17, one API process **and the load
generator all share those 2 cores**. The numbers below are real measurements, but a small computer like this is **not**
a production size. How to size the real servers is explained at the end.

## In simple words
1. I filled the database with **1,000 schools and 200,000 user accounts** (200,000 pupils, 200,000 bills, 1,000 computer tests).
2. I made hundreds of people use the app at the same time: teachers saving whole score sheets, heads searching and printing score sheets, pupils taking computer tests and checking fees. This also covered the new Phase 6 screens.
3. I found **2 real problems** and fixed them, and **1 idea that did not help** (I took it out again):

| # | Finding (measured) | Fix | Result (measured) |
|---|---|---|---|
| P1 | **Every request checks the sign-in in the database. That check cost 1.65–1.9 ms each time** and was 15× more database work than anything else (33.8 s of database time in a 60-second test). The database had to plan this check again on every call. | The same check, rewritten so the database plans it once and reuses it (migration `022`). Same rules, same results. | **0.065 ms per check (25× faster).** Throughput with 300 users went from **265 to 347 requests per second (+31%)**, and waiting times dropped about 25%. |
| P2 | **With 1,000 heads all pressing at once, 99 requests failed with a 500 error** ("Something went wrong"). They had waited more than 5 s for a free database connection. | The server now answers **"The school system is very busy right now. Please try again in a few seconds."** (503 BUSY, with a "try again in 3 s" note). It answers at once when the waiting line is too long, instead of letting everyone wait 5 s. The web app quietly waits and tries a reading screen once more. | **0 errors of the 500 kind** in every later run. In the 800-user test, the people who were served waited about half as long as before (p95 ≈ 2.3 s instead of 4–5 s). |
| P3 | The pupil list sorted all pupils of a school to show 25 | Take the 25 pupils first and look up their classes afterwards; new name index (migration `023`) | 2.9 ms → 0.95 ms per page (more for big schools) |
| ✗ | Idea: send "start" and "who is signed in" to the database in one trip instead of two | Tried, measured: **no difference** (339 vs 347 req/s, within noise) | **Taken out again**, so nothing changed without a reason |

## Measured results (final code)

| Test | Users at the same time | Result |
|---|---|---|
| **Sign-in rush across all 1,000 schools** | 1,000 heads, 40 at a time | **1,000 / 1,000 signed in** in 19.1 s (**52 sign-ins per second**). Sign-in is slow **on purpose**: passwords use Argon2id, which makes guessing hard |
| **Normal busy school day** (100 schools) | 300 (100 teachers, 100 heads, 100 pupils), short pauses | **347 requests per second**, **0 errors**, typical answer 0.6–0.9 s |
| **Very heavy** (200 schools, every 5th school) | 800 (400 teachers, 200 heads, 200 pupils) | Served **≈305 requests per second**, typical answer ≈1.5 s. About **18% were told "busy, try again"**. **0 errors of the 500 kind** |
| **Far beyond capacity** (all 1,000 schools) | 1,000 heads with no pauses at all | ≈74% served (p95 ≈ 2.5 s), the rest told "busy, try again". **0 errors of the 500 kind** |
| **School isolation on the full 1,000-school database** | — | **12/12**. All school tables are locked per school |
| **Several API copies sharing one Redis** (rate limits) | — | **passes** with a real Redis 8 (it was the 1 skipped test before) |
| **Package security check** (`npm audit`) | — | **0 known vulnerabilities** |

Full tables are in `abo-erp/docs/`:
- `loadtest-1000-schools-moderate.txt`
- `loadtest-1000-schools-heavy.txt`
- `loadtest-1000-schools-burst.txt`
- the "before" runs: `loadtest-1000-schools-before-fix.txt` and `loadtest-1000-schools-heavy-before-shedding.txt`

## What this means for 1,000 schools / 200,000 users in real life
- **This 2-core box serves about 300–350 requests per second** of the realistic mix: about **170 per CPU core**, with the database on the same machine. The load generator also used part of the cores, so this is a **careful lower figure**.
- **The database is not the problem.** In the 300-user test it was busy only ~33% of one core. The API process uses most of the CPU, and **the API can simply be copied** (it keeps no memory between requests; sessions are in the database and rate limits in Redis).
- **A realistic peak for 200,000 users:**
  - About 5% online at the busiest time (10,000 people), each clicking about every 10 seconds, gives **about 1,000 requests per second**.
  - Plan for about **3–4 API copies of 2 cores each** (Render), a **managed PostgreSQL with 4–8 cores** (Supabase), the Supabase connection pooler, and **Redis** for shared rate limits.
- Results days and exam weeks are the peaks. The "busy, try again" answer keeps the system **standing** when it is overloaded.
- **Before switching schools over:** run the same load test against the real Render + Supabase setup (Phase 8). The scripts are ready (`scripts/loadtest/`).

## Regression after the changes ("fix errors")

| Test | Result |
|---|---|
| Full server suite **with Redis** (nothing skipped any more) | **164 passed, 0 failed, 0 skipped**. This includes the new overload test, which passed 3 times on its own |
| Server browser tests | Menu **291/291**, UI **71/71**, menu clicks **251/251**, CBT **34/34**, portal **28/28**, migration **7/7**, clock-in/calendar/cashbook **19/19**, store/comments/ID cards **16/16**, materials/monitor/simple words **17/17**, sign in as / web address / offline **14/14** |
| Offline app, all 3 versions | **37 runs, 0 failures**: cloud 45/45, cloud2 36/36, sec 19/19, roles 57/57, sign-in-as 25/25, two-device sync 11/11, backups 18/18, and more |
| School isolation (1,000-school database) | **12/12** |
| `npm audit` | **0 vulnerabilities** |

**The first version of the new overload test checked nothing.** All 120 requests arrived at the same moment, so the waiting line was still empty when each one was checked, and every one was served. I rewrote it the way a real rush happens: a first wave fills the line, and a second wave arrives while it is full. Now it really tests the "busy" answer and passes.

**For the live servers** (Render): `DB_QUEUE_MAX=300` was added to both `render.yaml` files.

## Files changed
- **Database:**
  - `migrations/022_perf_auth_session.sql` (faster sign-in check)
  - `migrations/023_perf_indexes.sql` (pupil list index)
  - reverse scripts for both
- **Server:**
  - `routes/people.js` (pupil list: page first)
  - `app.js` (busy answer + early "busy" when the waiting line is too long)
  - `config/index.js` (`DB_QUEUE_MAX`, default 500)
- **Web app:** `core/api.js` (on "busy", wait and try a reading screen once more)
- **Load tools:**
  - `scripts/loadtest/seed-load.js` (bulk pupil accounts, so 200,000 users take 3 minutes; resumable)
  - `scripts/loadtest/run.js` (spreads users over many schools, includes the Phase 6 screens, waits on "busy" like the app)
- **Tests:**
  - `server/test/overload.test.js` (overload gives "busy", never 500)
  - `.qa/redis.sh` (local Redis for the shared rate-limit test)
