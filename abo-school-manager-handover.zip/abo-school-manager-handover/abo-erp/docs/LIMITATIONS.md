# A.B.O. School Manager (main offline edition): current limitations

Written 9 Oct 2026 in plain words. Most important first.

## 1. Security and privacy (the biggest ones)
1. **(Owner fixed in Phase 3: the owner now needs a password, and owner sessions are sealed.)** For everyone else, **sign-in still uses a login code only, with no password.** Anyone who knows or guesses a code can sign in as that
   person. Fingerprint sign-in exists on activated phones, but the code still works. (The older `premium_secure`
   file has passwords; the main file does not.)
2. **Role limits are enforced inside the app, not by the database.** What a teacher, pupil or parent can see is
   controlled by the app's menus and checks. Every linked device still keeps a full copy of the school record,
   including fees and staff details. Someone with technical skill could read that copy from the device's storage.
3. **Only link staff devices.** The device link code and the tap-to-connect link carry the school secret, which
   gives read/write access to the whole school record. Do not send it to parents or pupils.
4. **Real per-person privacy needs an online edition with Supabase Auth.** That means each person has their own
   Supabase login, and the database shows a parent only their own child, using Row Level Security per user plus a
   small server. This is where the `@supabase/server` package and the **secret key** belong: on a server or a
   Supabase Edge Function, **never inside the app**.

## 2. Data and syncing
5. **The whole school is saved as one record.** It syncs well for normal schools. Very large schools (thousands of
   pupils, many photos and documents) will sync more slowly on weak networks. Photos and documents are uploaded
   only once, which helps.
6. **Edits on two devices at the same time are merged.** If two people change the **same** field (for example the
   same pupil's score) before syncing, the last device to save wins.
7. **Supabase free plan:** 500 MB, and the project pauses after about a week without use (press Restore in the
   dashboard). Use the paid plan for daily school use at scale, and keep exporting backups.
8. **Offline after the first visit:** each device works offline once the app is open. The website version
   (Netlify) needs internet the first time it is opened on a phone.

## 3. Clock-in, fingerprint, location
9. **A phone fingerprint proves the phone's owner is present.** On a shared phone, anyone whose finger is
   registered on that phone can clock in. Clock-in should be done from each teacher's own phone.
10. **GPS can be faked** with special apps on modified phones. Fingerprint plus distance makes cheating hard, not
    impossible.
11. **Fingerprint and GPS need the https web address** (Netlify), not a file opened from the phone.

## 4. Web address (subdomain)
12. **The name is reserved only inside your Supabase project.** Netlify site names are shared by everyone in the
    world, so if Netlify says a name is taken, add your town.
13. **Each school's website is published by dragging the folder onto Netlify.** There is no automatic one-click
    publishing yet; that would need a Netlify token on a server.

## 5. Features not built yet
14. **No online fee payment.** Paystack or Flutterwave are not connected yet; payments are recorded by hand.
15. **No automatic SMS or e-mail sending.** WhatsApp messages open WhatsApp with the text ready, but someone must
    press send. Bulk SMS needs an SMS provider account.
16. **"Comment Helper" and the lesson-note draft are templates, not real AI.**
17. **No QR clock-in, gate devices or class video recording** (Klacify has these; they need hardware or a server).
18. **Muslim holidays (Eid, Mawlid)** follow the moon, so add them in the calendar each year.
19. **PDF, Word and picture exports** use add-ons downloaded from the internet. They need a connection the first
    time.

## 6. Editions
20. **The two older files (`premium_secure`, `connected`)** have the skin, data guard, phone menu and Back arrow,
    but not Supabase, fingerprint clock-in, simple words, the Control Centre or school web address. Use the main file.
21. **Simple words cover:** menus, page titles and explanations, buttons, column titles, the sign-in screen and
    common messages. Some deep texts inside the oldest classic pages (for example parts of the report-card editor)
    still use the original wording.
