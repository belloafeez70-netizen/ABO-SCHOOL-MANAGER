# Phase 6 summary: features and repairs (all 4 parts)

**Dates:** 9–10 Oct 2026
**Status:** built and tested on this computer. It is **not yet** on your real Supabase or live; that is Phases 7–8, plus your temporary database password.

## What the secure server edition can now do (new in Phase 6)

| Part | Feature | Main safety rules (checked on the server) |
|---|---|---|
| 1 | **Staff clock-in / clock-out** | <ul><li>Distance to the school gate worked out on the server.</li><li>One clock-in a day; late time; register for heads.</li></ul> |
| 1 | **School calendar** | Pupils and parents never see "staff only" events. |
| 1 | **Birthdays** | Pupils and staff; 29 February handled. |
| 1 | **Cashbook** (money in/out, petty cash) | <ul><li>Entries are voided, never edited.</li><li>Petty cash can't go below ₦0.</li><li>School fees are added to the totals.</li></ul> |
| 2 | **School store** (items, stock, selling, receipts) | <ul><li>The server sets prices.</li><li>Stock can't go below 0, even with two tills at once.</li><li>Stock history always adds up.</li></ul> |
| 2 | **Comment helper** | <ul><li>Suggestions for the whole class.</li><li>Form teacher / reviewer rules.</li><li>Nothing is saved until you press Save.</li></ul> |
| 2 | **ID cards** | Real Code-128 barcode (checked against an independent library). |
| 3 | **Study materials and live classes** | <ul><li>Teachers share only with the classes they teach.</li><li>https links only.</li><li>The Join button appears 15 minutes before the start.</li></ul> |
| 3 | **Class monitor + bell times** | The lesson on now, and whether its teacher has clocked in. |
| 3 | **Simple words** + "Show full terms" switch | The menu search accepts both names. |
| 4 | **Owner "sign in as"** | <ul><li>Reason and time limit.</li><li>A red bar on screen.</li><li>Security areas closed.</li><li>Recorded under the owner's name; the person is told.</li></ul> |
| 4 | **School web address** | <ul><li>Old addresses keep working.</li><li>An old address is never given to another school.</li></ul> |
| 4 | **Offline mode** | <ul><li>The app opens with the last saved copy.</li><li>Sign-out deletes it.</li><li>Saving needs the internet.</li></ul> |

**Offline app (quick fixes):** the browser's grey `alert` boxes are now the app's own message box, in all 3 versions.

## Problems found and fixed during Phase 6

| Problem | Where |
|---|---|
| The word "null" showed on the cashbook page | Part 1, caught by the menu test |
| A comment-helper browser test passed without really testing; rewritten | Part 2 |
| Two older tests were weak or racy: the token-theft alert was saved after the reply (the server now saves it first), and three offline tests had test-harness faults | Parts 2–3 |
| The new "Back to my account" endpoint was flagged by the security inventory test; it is own-session only, and this is now documented | Part 4 |

## Numbers at the end of Phase 6 (this computer)
- **Server suite:** 162 passed, 0 failed, 1 skipped (the skip needs Redis).
- **Browser suites:** 9 older suites plus 4 new ones, all passing. That includes **291/291** menu links for every role.
- **School isolation:** 12/12. **84 tables** hold school data, and every one has row-level security.
- **Database:** 21 migrations (4 new in Phase 6). Each new one has a reverse script and leaves existing data untouched.
- **API:** 287 endpoints (`docs/API.md` is generated from the live code).

## Still open after Phase 6 (honest)
- **Offline app:** 26 `confirm` and 19 `prompt` boxes are still the browser's own; repeated functions are not removed (quick fixes only, as agreed).
- **Server edition:** saving while offline is not built, and fingerprint/face confirmation for clock-in is not built.
- **Your real Supabase:** nothing has been run against it yet. This needs your temporary password.

## Next phases
- **Phase 7, testing and load tests:**
  - synthetic 1,000 schools / 200,000 users on PostgreSQL
  - measured speed (p50/p95) and throughput
  - the Redis test
  - security re-check
- **Phase 8, deployment:**
  - Render (API) + Netlify (web) + your Supabase
  - preflight checks, security headers, live checks
