# Production deployment: Netlify frontend + separate API + PostgreSQL

This setup is for the free `https://<your-site>.netlify.app` address first. You can connect your own domain later by
changing environment variables only (§5); no code changes are needed.
`abo.school.com.ng` is **not** assumed to exist anywhere in the code or configuration.

## 1. Architecture

```
 Browser (phone / laptop)
   │  https://<your-site>.netlify.app            ← only address users ever see
   ▼
 Netlify CDN ──────────────┬───────────────────────────────────────────────────────────────
   static site dist/web    │  Edge Function  /api/*  (netlify/edge-functions/api-proxy.js)
   (hashed JS/CSS, CSP,    │    + adds x-abo-proxy-secret   (from Netlify env, never in code)
    HSTS, immutable cache) │    + adds x-abo-client-ip      (the visitor's real IP)
                           ▼
                   API service (Docker; Render blueprint included, any host works) — 2+ instances
                   SERVE_FRONTEND=false · REQUIRE_PROXY_SECRET=true · HTTPS by the host
                     ├── PostgreSQL 17 (managed, private network, PITR) — runtime role abo_app (RLS enforced)
                     ├── Redis (shared rate limits across instances)
                     ├── S3-compatible bucket (uploads, private; streamed through the API)
                     ├── Worker (emails, exports, CBT reminders)
                     └── Nightly encrypted backup → a SEPARATE bucket + weekly restore drill
```

**Why the API is reached through `/api/*` on the Netlify address instead of being called directly:**

* `netlify.app` is on the Public Suffix List. A session cookie set by another host (for example `…onrender.com`) would
  count as a third-party cookie, which Safari and Firefox block and Chrome is restricting. Through the edge proxy the
  cookie stays first-party: `__Host-abo_sid; Secure; HttpOnly; SameSite=Strict`. Sign-in works in every browser, and
  no CORS preflight is needed.
* The backend address and the shared secret are Netlify **environment variables** used only at the edge. The
  frontend bundle contains no secrets; `npm run build:web` fails the build if it finds anything that looks like one.
* The API refuses any request that did not come through the proxy (`DIRECT_ACCESS_BLOCKED`), so the API host cannot
  be used to get around rate limits or the frontend. Only health checks, `/metrics` (bearer token) and payment
  webhooks (HMAC signature) are open.

**Authentication is not JWT-based:** sessions are random opaque tokens. Only a SHA-256 hash is stored in PostgreSQL.
Tokens rotate every 15 minutes, the session ends after 2 hours idle or 72 hours at most, and sessions can be revoked
instantly (log out everywhere, when a password changes, when a school suspends someone). So there is **no JWT secret**
to leak. The server-side secrets are `CSRF_SECRET`, `DATA_ENCRYPTION_KEY` (TOTP secrets), `FILE_URL_SECRET`,
`PROXY_SHARED_SECRET` and `METRICS_TOKEN`. All of them live only in the API's environment; `PROXY_SHARED_SECRET` is also
set in Netlify, where only the edge function can read it.

## 2. Environment variables: where each one goes

| Variable | Netlify | API | Secret? | Value today (netlify.app) |
|---|:-:|:-:|:-:|---|
| `API_ORIGIN` | ✔ (Functions) | | no | `https://abo-api.onrender.com` (your API address) |
| `PROXY_SHARED_SECRET` | ✔ (Functions) | ✔ | **yes** | same random value in both places |
| `PREVIEW_API_ENABLED` | deploy-preview only | | no | leave unset (previews stay disconnected) |
| `CSP_IMG_SRC`, `HSTS_INCLUDE_SUBDOMAINS` | optional (Builds) | | no | unset |
| `PUBLIC_API_BASE` | optional (Builds) | | no | **leave empty** — only for own-domain direct mode (§5b) |
| `PUBLIC_ORIGIN` | | ✔ | no | `https://<your-site>.netlify.app` |
| `ALLOWED_ORIGINS`, `ALLOWED_ORIGIN_REGEX` | | ✔ | no | empty |
| `SERVE_FRONTEND` / `REQUIRE_PROXY_SECRET` | | ✔ | no | `false` / `true` |
| `DATABASE_URL` | | ✔ | **yes** | runtime role **abo_app** (never the owner) + `DB_SSL=require` |
| `MIGRATION_DATABASE_URL` | | ✔ | **yes** | schema owner, used only by migrations |
| `CSRF_SECRET`, `DATA_ENCRYPTION_KEY`, `FILE_URL_SECRET`, `METRICS_TOKEN` | | ✔ | **yes** | `openssl rand -base64 48` each (Render generates them) |
| `RATE_LIMIT_REDIS_URL` | | ✔ | **yes** | required with 2+ API instances |
| `S3_*`, `SMTP_URL`, `PAYSTACK_SECRET_KEY`, `ERROR_WEBHOOK_URL` | | ✔ | **yes** | from each provider |

The API refuses to start in production if any of these is true:
- a secret is missing, weak or a placeholder;
- an origin is not `https://` or includes a path;
- `REQUIRE_PROXY_SECRET` is on but there is no shared secret;
- `DATABASE_URL` connects as a superuser, a BYPASSRLS role or the **table owner** (table owners bypass row-level
  security, so tenant isolation would not be enforced).

## 3. Step by step (first deployment, about one hour)

1. **Create the Netlify site first** so you know its address. In Netlify, choose Add new project → Import from Git,
   then select the repository.
   - Base directory: the folder that contains `netlify.toml`.
   - Build command and publish directory are read from `netlify.toml` (`npm run build:web` → `dist/web`).
   - Rename the site, for example `abo-school-manager` → `https://abo-school-manager.netlify.app`.
2. **Database** (Render Postgres from the blueprint, or Neon, Supabase, DigitalOcean or AWS RDS): PostgreSQL 15 or
   newer, private network, automated backups with point-in-time recovery.
   Create the roles once with the provider's admin connection:
   `DATABASE_ADMIN_URL=… DB_OWNER_PASSWORD=… DB_APP_PASSWORD=… node server/src/db/bootstrap.js`.
   If the provider does not allow `CREATE ROLE`, create `abo_owner` and `abo_app` (NOBYPASSRLS) in its dashboard.
3. **API.** On Render: New → Blueprint → select the repo (it uses `render.yaml`), then fill in the prompted values.
   - `PUBLIC_ORIGIN` = the Netlify address from step 1.
   - `DATABASE_URL` = `postgres://abo_app:…@…/abo_erp?sslmode=require`.
   - S3/R2, SMTP, `ERROR_WEBHOOK_URL`, and the backup bucket keys.
   - Migrations run automatically before every deploy (`preDeployCommand`).
   - On any other Docker host, use the same `Dockerfile` and the same variables (see `.env.example`).
4. **Connect Netlify to the API.** In Netlify → Site configuration → Environment variables, set:
   - `API_ORIGIN` = the API address;
   - `PROXY_SHARED_SECRET` = copied from the API service.

   Both variables need the scope **Functions**. Then trigger a redeploy.
5. **First platform administrator.** In the API service shell, run
   `PLATFORM_ADMIN_LOGIN=… PLATFORM_ADMIN_EMAIL=… node scripts/create-platform-admin.js`.
   The admin must enrol two-factor sign-in on first login.
6. **Check everything.** From any computer:
   ```bash
   npm run verify:deploy -- https://abo-school-manager.netlify.app https://abo-api.onrender.com
   ```
   This checks HTTPS redirect, CSP, HSTS, hashed assets, proxy → API, the site's origin accepted and foreign origins
   refused, direct API access blocked, and database readiness.

   On the API host, `npm run preflight` checks secrets, TLS, RLS role, migrations, demo data, SMTP, Redis, alerts and
   backups.
7. **Monitoring** (§6) and **backups** (§7): add the uptime checks and webhook, then trigger the first backup manually
   (Render: cron job → Trigger run, or GitHub: Actions → db-backup → Run workflow).

## 4. Security controls

| Requirement | How it is met |
|---|---|
| HTTPS/SSL | Netlify issues and renews certificates for netlify.app and custom domains; the API host terminates TLS; HSTS header on the site; the API requires `DB_SSL=require` to PostgreSQL |
| Secure environment variables | Secrets only in Render/Netlify/GitHub secret stores; `.env` is git-ignored; the build fails if a secret-like string reaches `dist/web`; secret headers are removed before logging |
| CORS | Browser traffic is same-origin through the proxy (no CORS needed). The API's CORS and CSRF-origin checks allow only `PUBLIC_ORIGIN` + `ALLOWED_ORIGINS` (+ optional anchored regex); `*` is never used |
| Authentication | Argon2id passwords, opaque rotating sessions, lockout, TOTP 2FA (required for owners, admins and bursars), CSRF token + Origin/Fetch-Metadata checks |
| Role-based authorisation | 78 permissions, 14 role templates; every endpoint declares its permission (a test fails the build if one does not) |
| Multi-tenant isolation | PostgreSQL row-level security on 72 tables with the runtime role `abo_app` (NOBYPASSRLS, owns nothing — checked at startup), composite foreign keys, branch scoping |
| Direct-access protection | `REQUIRE_PROXY_SECRET=true`: only Netlify-proxied traffic reaches the API (constant-time secret check). The real client IP comes from Netlify, never from spoofable `X-Forwarded-For` |
| Security headers (site) | CSP `default-src 'self'` with no inline scripts, `frame-ancestors 'none'`, HSTS, nosniff, `X-Frame-Options: DENY`, COOP/CORP, Permissions-Policy, `robots: noindex` |

## 5. Moving to your own domain later (configuration only)

**a) Recommended (keeps the proxy):**
1. In Netlify → Domain management, add e.g. `portal.yourschool.com.ng`. Set the DNS record your registrar shows
   (CNAME to `<site>.netlify.app`). Netlify issues the certificate automatically.
2. On the API: `PUBLIC_ORIGIN=https://portal.yourschool.com.ng` and
   `ALLOWED_ORIGINS=https://abo-school-manager.netlify.app` (keeps the old address working during the move). Redeploy.
3. Optional: in Netlify, redirect the netlify.app address to the new domain (Domain management → primary domain).
   Set `HSTS_INCLUDE_SUBDOMAINS=true` only if every subdomain of your domain uses HTTPS.
4. Run `npm run verify:deploy -- https://portal.yourschool.com.ng https://<api>`. Emails, school sign-in links and
   the Paystack return URL all follow `PUBLIC_ORIGIN` automatically.

**b) Optional at very large scale — direct API mode:** once the API also has a subdomain of **the same** domain
(e.g. `api.yourschool.com.ng`), you can skip the proxy hop:
- Netlify build variable `PUBLIC_API_BASE=https://api.yourschool.com.ng`;
- on the API: `REQUIRE_PROXY_SECRET=false`, `CROSS_ORIGIN_RESOURCE_POLICY=same-site`, and `TRUST_PROXY` set to your
  host's proxy.

The build refuses `PUBLIC_API_BASE` on shared platform domains such as `onrender.com` or `netlify.app`, because the
cookie would become third-party there. This mode is covered by build and unit tests only. Do a browser check with
`verify:deploy` before switching real users to it.

## 6. Error logging and monitoring

| Signal | Where |
|---|---|
| Structured JSON logs (request id on every line; cookies, tokens and passwords redacted) | API host log stream → forward to Better Stack, Grafana Loki, Datadog or Papertrail with the host's log drain |
| **Alerts to your phone**: 5xx errors, crashes, failed background jobs, surges of browser errors | `ERROR_WEBHOOK_URL` (Slack, Discord or Teams incoming webhook; `ERROR_WEBHOOK_FORMAT`). Throttled to one message per error type per 10 min and at most 20/hour. No personal data (emails, phones and ids are scrubbed) |
| Browser JavaScript errors from users' phones | the web app reports uncaught errors to `POST /api/v1/client-errors` (max 5 per page, no query strings) → logged as `client error` and counted |
| Metrics | `/metrics` (Prometheus, bearer `METRICS_TOKEN`) + ready-made rules in `deploy/monitoring/alerts.yml` (error rate, login-failure spikes, DB pool saturation, slow requests, failed jobs) |
| Uptime | point any uptime monitor (UptimeRobot, Better Stack) at `https://<site>/` **and** `https://<api>/readyz` (checks the database) |
| Security events | Platform console → Security Events (credential stuffing, cross-tenant probing, privilege-escalation attempts, new-device sign-ins) |
| Missed backups | `BACKUP_HEARTBEAT_URL` is pinged after each successful backup; the monitor alerts if a ping is missing |

## 7. Automated database backups (three layers)

1. **Provider point-in-time recovery** (continuous WAL): turn it on in the database plan (7–30 days).
2. **Nightly encrypted logical backup to a separate bucket and account.** Use either the Render cron job in
   `render.yaml` (image `deploy/backup/Dockerfile`, pg_dump 17) or the GitHub Actions workflow
   `.github/workflows/db-backup.yml`.
   - The dump is AES-256 encrypted with `BACKUP_ENCRYPTION_KEY` before it leaves the machine. Uploading an
     unencrypted dump is refused.
   - A SHA-256 checksum is stored with each file.
   - Set bucket lifecycle rules for retention, for example 35 daily and 12 monthly copies.
3. **Weekly automated restore drill** (GitHub workflow, Sunday). It downloads the latest backup, checks that it is
   less than 36 h old, verifies the checksum, restores into a scratch database, counts rows and verifies every
   school's tamper-evident audit chain.

Keep an **offline copy of `BACKUP_ENCRYPTION_KEY`** (printed and locked away). Without it, backups cannot be restored.

## 8. Production build

`npm run build:web` (Netlify runs it automatically):
- The entry script is ~12 kB (~4 kB gzip). Every page is a lazily loaded chunk; there are 39 JS files in total.
- One CSS file of ~56 kB (12 kB gzip).
- All asset file names contain content hashes and are cached for a year (`immutable`). `index.html` always
  revalidates, so a new deploy reaches users on their next page load.
- Netlify compresses responses with Brotli/gzip. The API returns JSON with `Cache-Control: no-store`.

## 8b. Single-file edition of the full app (`abo-school-manager.html`)

`npm run build:single -- --copy-to ../abo-school-manager.html` puts **the complete online app into one HTML file**:
every page and module, all JavaScript and CSS, and the icon (~378 kB, ~113 kB gzip). The inline code is allowed by
exact SHA-256 hashes in the Content-Security-Policy, which is also embedded as a `<meta>` tag; there is no
`'unsafe-inline'`.

| How you use it | What happens |
|---|---|
| Drag the `dist/single` folder onto Netlify (or replace `index.html` on the site that has the edge proxy + API) | the full app: sign-in tabs, dashboard, students, results, broadsheets, CBT, lesson notes, fees, messages — identical to the multi-file build |
| Put `abo-school-manager.html` on a site **with** the edge proxy, as `index.html` | same as above |
| Double-click the file on a computer (opened from disk) | a clear "Open the school portal" page with the portal link (`PUBLIC_SITE_URL` at build time). Signing in needs the secure server; browsers do not allow the session cookie on a local file |

The multi-file build (`npm run build:web`, which `netlify.toml` uses) is still recommended for everyday hosting, because
each page is downloaded only when it is opened. The fully offline, one-device edition remains the original
`school_broadsheet_manager_bopc_erp.html`.

## 9. Capacity plan: 1,000+ schools, 200,000+ users

Measured (docs/LOAD_TEST.md): **~230 requests/s per 2 vCPUs** (API + PostgreSQL on one box, heavy write mix), 0 errors
at 800 concurrent active users, with 5,222 accounts across 100 schools. The system is CPU-bound and degrades by
queueing, not by failing.

| Stage | Users | Peak active (≈5 %) | Suggested sizing |
|---|---|---|---|
| Pilot (your school) | ≤ 2,000 | ≤ 100 | 1–2 API × 1 vCPU, DB 1 vCPU/4 GB, Redis small |
| Growth | ~50,000 | ~2,500 | 2–3 API × 2 vCPU, DB 2–4 vCPU/8 GB, PgBouncer (transaction mode) |
| Target | 200,000+ (1,000+ schools) | ~10,000 → ~1,000 req/s | 4–6 API × 2 vCPU (autoscale on CPU 60 %), DB 8 vCPU/32 GB + a read replica for reports/exports, PgBouncer, Redis, worker × 2 |

**Rules that keep it safe at scale:**
- `DB_POOL_MAX × API instances` must stay below the database connection limit (use PgBouncer).
- `RATE_LIMIT_REDIS_URL` is required with more than one instance. This was tested here: two instances share one
  budget.
- Run exports and emails on the worker, never in requests.
- Load-test the real stack with `scripts/loadtest` before the first results-release day.

**Netlify usage:** every API call counts as one edge-function invocation. At 200k users that can reach tens of
millions a month, so check the Netlify plan's included usage. When that becomes expensive, switch to the own-domain
direct mode (§5b), which removes the edge hop for API calls.

## 10. What was verified before handing over (30 Sep 2026)

The site was **not** deployed to a real Netlify account from here (that needs your Netlify and Render logins).
Instead, the exact production layout was exercised locally:
- the built `dist/web` with its generated `_headers`, served over HTTPS;
- the **real** edge function file (`scripts/netlify-local.js`);
- the API in `staging` mode with `SERVE_FRONTEND=false`, `REQUIRE_PROXY_SECRET=true`, secure `__Host-` cookies and a
  non-owner database role.

The full browser suites were run through that layout. Results are in docs/TEST_REPORT.md. After your first real
deploy, run `npm run verify:deploy` (§3 step 6) to confirm the same on `*.netlify.app`.
