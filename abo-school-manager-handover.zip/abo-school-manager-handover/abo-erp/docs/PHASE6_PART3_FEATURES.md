# Phase 6, part 3: study materials, live classes, class monitor, simple words

**Date:** 10 Oct 2026
**Status:** built and tested on this computer (sandbox). This is **not yet** on your real Supabase or live on the internet.

## In simple words

| Feature | Who | What the server makes sure of |
|---|---|---|
| **Study materials** (notes, worksheets, links, videos) | **Teachers** share with the classes they teach. **Heads, owner, principal and admin** can share with any class. **Pupils and parents** see their own class only. | <ul><li>A teacher **cannot share with a class they do not teach**.</li><li>Links must start with `https://`. `http://` and `javascript:` links are refused.</li><li>Files go through the normal file checks: a "PDF" that is really something else is refused.</li><li>Hidden (unpublished) items never reach pupils.</li><li>Only the person who shared an item (or a head) can remove it.</li><li>A file opens only for the right class; another school gets "not found".</li></ul> |
| **Live classes** (Google Meet / Zoom / Teams link) | Same people as above | <ul><li>A class cannot be scheduled in the past.</li><li>Pupils get the **Join** button only from **15 minutes before** the start until the end.</li><li>Cancelled classes disappear for pupils.</li><li>Only the teacher who scheduled it (or a head) can cancel it.</li></ul> |
| **Class monitor** ("Classes Right Now") + **bell times** | Owner, principal, admin and heads (the same people who see the clock-in register). Bell times are set by whoever manages classes. | <ul><li>For every class: which lesson should be on now, which teacher has it, and whether that teacher has **clocked in today**. It also shows a live online class happening now.</li><li>Updates every minute.</li><li>"Show Monday 08:10" previews any moment of the week.</li><li>Bell times are checked: a period cannot end before it starts, and periods cannot overlap.</li></ul> |
| **Simple words** in the server app | Everyone | <ul><li>The menu, page titles and breadcrumbs now use everyday words by default. Examples: "Home" for Dashboard, "Money" for Finance, "Class Score Sheet" for Broadsheet, "Who Did What" for Audit Logs, "Bring In Old App Data" for Legacy Migration.</li><li>The **"Show full terms"** switch at the bottom of the menu brings the office words back.</li><li>The menu search finds a page by **either** name; typing "broadsheet" finds "Class Score Sheet".</li><li>Only labels change, never anything people type.</li></ul> |

**Honest notes**
- **Videos open on YouTube** (or Vimeo) in a new tab. They are not played inside the app, because the app's strict security settings block outside players.
- **The demo school has no timetable,** so its monitor honestly says "No Timetable". It starts working once a school fills in its timetable and bell times.

## Tests (all run on this computer)

| Test | Result |
|---|---|
| New server tests (`materials_monitor.test.js`) | **3/3**: share rules, https-only links, disguised file refused, pupil/parent visibility, file access, 15-minute join rule, cancel rules, bell-time checks, monitor before and after the teacher clocks in, live class shown, preview, school-to-school isolation |
| Browser test (`materials_monitor.qa.js`) | **17/17**: simple words, search by both names, the switch both ways, teacher shares a video and a file, live class, pupil sees and opens the file, Join button, monitor and bell times, preview, teacher blocked from the monitor, no errors |
| Full server suite | **159 passed, 0 failed, 1 skipped** (that one needs Redis), after fixing the timing problem below |
| Older browser tests, run again | Menu **289/289** (every link, every role), UI **71/71**, menu clicks **249/249**, CBT **34/34**, portal **28/28**, migration page **7/7**, clock-in/calendar/cashbook **19/19**, store/comments/ID cards **16/16** |
| School isolation check | **12/12**. All **83** school tables are locked per school |

**Problem found while testing (an older test, now fixed)**
- One run of the full suite had 1 failure in an **older** test: "a stolen login token is replayed → alert".
- The cause: the server stored that safety alert *after* answering, so a fast check sometimes looked before it was saved.
- The server now saves the alert **before** answering. The test then passed in 3 single runs and in the full suite.

The older browser tests were written with the office words. They now switch to "full terms" first, exactly like a user would. The new test checks the simple-words default itself.

Screenshots are in `abo-erp/docs/screenshots/`:
- `phase6-materials-teacher.png`
- `phase6-materials-pupil.png`
- `phase6-monitor.png`

## Files
- **Database:** `server/src/db/migrations/020_materials_live_monitor.sql`, plus a reverse script. It only adds tables and allows the new file type; existing data is not touched.
- **API:**
  - `server/src/routes/materials.js`: `/materials`, `/materials/file`, `/live-classes`, `/school/periods`, `/monitor/now`
  - File access rule for study materials in `files.js`
  - New file type in `storage/index.js`
  - Permissions `materials.create`, `materials.manage`, `materials.view`, `materials.view_own` and `materials.view_children`
- **Screens:**
  - `web/assets/js/pages/materials.js`
  - `web/assets/js/core/words.js` (simple words)
  - Menu entries and the "Show full terms" switch
- **Tests:**
  - `server/test/materials_monitor.test.js`
  - `server/test/e2e/materials_monitor.qa.js`
  - `server/test/e2e/fullwords.js` (helper)

## Still to do in Phase 6 (part 4, the last part)
- **Owner "sign in as" in the server edition.** This needs care: time-limited, written in the audit log, with a banner on screen, and blocked from changing passwords or security settings while acting as someone else.
- **School web address page in the server edition.** A school portal page `/#/s/<school>` already exists. Still to add: a screen to see and share it, and to change the name in the address.
- **Server screens offline:** reading saved pages, and queuing scores/attendance while offline.
- **Offline app:** turn the 45 confirm/prompt boxes into in-app dialogs, and remove repeated functions.
