# Phase 7 — 1,000 schools / 200,000 users (10 Oct 2026)

**Environment:** same 2 vCPU / 2 GB sandbox; PostgreSQL 17, one API process and the load driver share the cores.
**Data:** `LOAD_SCHOOLS=1000 LOAD_STUDENTS=200 LOAD_TEACHERS=9 LOAD_STUDENT_ACCOUNTS=188 node scripts/loadtest/seed-load.js`
→ 1,002 schools · **200,022 user accounts** · 200,054 pupils / enrolments · 200,000 invoices · 494,988 role-permission rows · 629 MB (seeded in 167 s).

| Run | Active users | Result |
|---|---|---|
| Logins across all 1,000 schools | 1,000 (40 at a time) | 1,000/1,000 in 19.1 s · 52 logins/s (Argon2id) |
| Moderate (100 schools) | 300 | **347 req/s · 0 × 5xx** (was 265 req/s before fix P1) |
| Heavy (200 schools) | 800 | ≈305 req/s served · ≈18 % `503 BUSY` (load shedding) · **0 × 500** · served p95 ≈ 2.3 s |
| Burst (1,000 schools, no think time) | 1,000 | ≈74 % served · rest `503 BUSY` · **0 × 500** (before fix P2: 99 × 500 "timeout exceeded when trying to connect") |

**Fixes:** (P1) `app.auth_session` as PL/pgSQL — 1.65 ms → 0.065 ms per call, was 15× the next query by total DB time
(migration 022). (P2) pool-wait timeouts → `503 BUSY` + `Retry-After`; early shedding when `pool.waitingCount ≥ DB_QUEUE_MAX`
(default 500); web client retries reads once. (P3) pupil list pages first, then joins; name index (migration 023):
2.9 → 0.95 ms. Tried and **reverted** (no measurable gain): combining BEGIN + set_config into one round trip.

**CPU profile (Node, 30 s at 300 users):** most API time is socket I/O (writev to PostgreSQL/HTTP on loopback inside
the micro-VM), then pg row parsing and Fastify serialisation — no application hot spot remains. DB execution used ≈ 0.33
of one core at 347 req/s. ⇒ scale the stateless API horizontally; ~170 mixed req/s per vCPU measured here (lower bound).

Files: `loadtest-1000-schools-{moderate,heavy,burst}.txt`, `loadtest-1000-schools-before-fix.txt`, `loadtest-1000-schools-heavy-before-shedding.txt`.

---

# Load & performance test (29 Sep 2026)

**Environment (sandbox — indicative, not production sizing):** 2 vCPU, 2 GB RAM, PostgreSQL 17.11 and ONE Node 20
API process on the same machine, `pg_stat_statements` enabled. Driver: `scripts/loadtest/run.js` (each virtual user
has its own client IP via `X-Forwarded-For`, so per-IP rate limits behave as for real users).

**Data:** `scripts/loadtest/seed-load.js` → 100 load schools (+2 demo) provisioned through the real provisioning
code · **50,054 students · 5,222 user accounts** · 900 classes · 7,200 class-subject assignments · 50,000 invoices ·
published CBT per school. After the runs: 245 k score rows, 792 k score-history rows, 351 MB database.

## Scenarios

| Phase | What | Result |
|---|---|---|
| Concurrent logins | 800 distinct accounts, 40 at a time (Argon2id m=19 MiB) | 800/800 in 14.8 s · **54 logins/s** · p95 823 ms |
| Heavy mix | 800 simultaneously active users (400 teachers, 100 heads, 300 students), think time 0.2–0.8 s, 60 s | 18,732 requests · **228 req/s** · **0 × 5xx** |
| Moderate mix | 200 simultaneously active users, 45 s | 10,206 requests · 206 req/s · p95 ≈ 1.0–1.3 s · **0 × 5xx** |

The mix: teachers open a score sheet and save **the whole class (≈55 learners × 3 components)** with optimistic
locking; heads run trigram student searches, paging and **broadsheet generation**; students run **CBT
start → 10 autosaved answers → submit** and **fee/invoice queries**. Full tables: `loadtest-heavy.txt`,
`loadtest-moderate.txt`, `loadtest-before-optimisation.txt`.

## Slow queries found and fixed (pg_stat_statements → EXPLAIN ANALYZE)

| Finding | Before | Fix (migration 014) | After |
|---|---|---|---|
| Score save dominated by a ROW-level trigger (status lookup + history insert per cell; 350 k history inserts) | 37.1 ms mean | Statement-level triggers with transition tables (one lock check + one bulk history insert per save); unchanged cells not rewritten | **16.9 ms** (−54 %) |
| `invoice_items WHERE invoice_id = $1` — no index (only composite FK) | 4.89 ms | `invoice_items_invoice_idx` | **0.04 ms** |
| Student search `name LIKE … OR admission_no LIKE …` | OR defeated name trigram index for large tenants | trigram index on `lower(admission_no)` | 0.34 ms (RLS + tenant index) |
| Load-driver bug: `cbt.start` sent JSON content-type with empty body | 1,500 × 400 | fixed driver | 600 × 200 |

Concurrency defects found by the concurrency tests during this phase: **deadlock** between two simultaneous payments
on the same invoice (FK key-share locks upgraded to FOR UPDATE) — fixed by locking target invoices first, in id order.

## Interpretation & capacity planning

* No errors under saturation; the server degrades by queueing, not by failing.
* Throughput is flat at ~210–230 req/s whether 200 or 800 users are active ⇒ the box is **CPU-bound**
  (≈ 9–10 ms combined Node+PostgreSQL CPU per request on this mix, which includes heavy writes). Latency at 800
  users is queueing time.
* The API is stateless (sessions in PostgreSQL), so capacity scales by adding API replicas and giving PostgreSQL
  dedicated cores. Rough planning figure from this run: **~100–120 mixed req/s per vCPU**.
* Example for 200,000 users: if 5 % are active at peak and each issues one request every 10 s ⇒ ~1,000 req/s ⇒
  e.g. 6–8 API vCPUs (3–4 replicas × 2 vCPU) + a 4–8 vCPU managed PostgreSQL with read replica for reporting,
  PgBouncer, and Redis for rate limits. **Confirm with a k6/Locust run on the target infrastructure before launch.**
* Other hot spots to watch at larger scale: `app.audit_append` serialises writes per school via an advisory lock
  (2–5 ms); `auth_session` runs on every request (0.84 ms) — both fine at this scale, both have documented options
  (audit batching; short session cache) if needed.

## Reproduce

```bash
NODE_ENV=development node scripts/loadtest/seed-load.js            # 100 schools, 5.2k accounts
TRUST_PROXY=loopback RATE_LIMIT_GLOBAL_PER_MIN=100000 RATE_LIMIT_LOGIN_PER_MIN=1000 npm start
DURATION=60 node scripts/loadtest/run.js                           # heavy profile
SCHOOLS=50 TEACHERS_PER_SCHOOL=2 STUDENTS_PER_SCHOOL=1 node scripts/loadtest/run.js   # moderate
psql -c "SELECT calls, mean_exec_time, query FROM pg_stat_statements ORDER BY total_exec_time DESC LIMIT 15"
```
