# Offline edition → online edition: every page

**Updated:** 12 October 2026, after migration 027 ("all offline features converted to online").

**Source:** all 90 menu pages of the offline edition (`school_broadsheet_manager_bopc_erp.html`, signed in as owner), checked one by one against the online edition.

**Legend:** ✅ online · ⬆ online and stronger (server-checked) · ⛔ replaced on purpose (reason given)

## People

| Offline page | Online | Where |
|---|---|---|
| Pupils, Classes & Pupils, Parents, Link Parents to Children | ✅⬆ | Students, Parents & Guardians (`#/students`, `#/guardians`) |
| Staff List, Staff Jobs | ✅ | Staff Records, Teachers (`#/staff`, `#/teachers`) |
| Birthdays · ID Cards · Saved Documents | ✅ | `#/birthdays` · `#/id-cards` · `#/documents` |
| Add Many at Once | ✅ | Student Import, Import & Export |
| Login Codes, Login Code Slips, All logins | ⬆ | Users (access-code slips; passwords + two-step sign-in) |

## Academics

| Offline page | Online | Where |
|---|---|---|
| School Year & Terms, Classes & Arms, Subjects, Subjects for Each Class, Who Teaches What, Timetable, Move to Next Class | ✅ | Classes & Subjects, Promotion |
| Lesson Notes | ⬆ | Lesson Notes, with review and approval |
| Study Materials, Video Lessons, Online Classes | ✅ | Study Materials (notes, files, video links), Live Classes |
| Attendance, Staff Arrival (Clock-in), Classes Right Now | ⬆ | Attendance, Staff Clock-in (fingerprint / passkey + GPS), Class Monitor |
| Attendance Report | ✅ | Attendance summary + **Print Centre › Attendance Report** (new) |
| **Devices** | ✅ **new** | `#/devices` |

## Tests and results

| Offline page | Online | Where |
|---|---|---|
| Class Test Scores (CA), Exam Scores, Report Cards, Report Card Settings, Class Score Sheet, Fix a Score, Results So Far, Old Results | ⬆ | Scores & Results, Broadsheets & Reports (four-eyes approval, frozen published results) |
| **Design Score Sheet** | ✅ **new** | Marks and maxima: General Settings. **Columns, title and footer: `#/broadsheet/layout`** |
| Question Bank, Computer Tests (CBT), Computer Test Results | ⬆ | CBT Examinations (marking on the server) |
| **Questions from Teachers** | ✅ **new** | `#/cbt/review`: optional approval of teachers' bank questions |
| Comment Helper | ✅ | `#/results/comments` |

## Money

| Offline page | Online | Where |
|---|---|---|
| Fees for Each Pupil, School Bills, Fee Payments, Money Overview, Fees to Pay, My Fees | ⬆ | Fees & Payments (invoices, receipts, Paystack verified on the server) |
| **Old Debts** | ✅ **new** | `#/fees/arrears`: one "brought forward" bill per learner; parents see it and can pay |
| **Petty Cash** (requests, approval, money returned) | ✅ **new** | `#/petty-cash`: ask → another person approves → hand out → settle |
| Money Categories, Money In, Money Out, All Money In & Out, Daily Cash Book, Money Reports | ✅ | Cashbook + **Print Centre › Cash Ledger** (new) |
| Store Items, Sales | ✅ | School Store + **Print Centre › Stock Sheet** (new) |
| Payment Settings | ⬆ | Payments & Plans (owner only; secret never sent to the browser) |

## Communication, settings and tools

| Offline page | Online | Where |
|---|---|---|
| Announcements, Messages, Talk with Parents, Calendar | ✅⬆ | Messages & Notices, School Calendar |
| **Automatic Reminders** | ✅ **new** | `#/alerts`: overdue fees with parent reminders, low attendance, low stock, approvals waiting, subscription ending |
| **Print Centre** | ✅ **new** | `#/print-centre`: all printable documents, plus blank register, attendance report, stock sheet and cash ledger |
| School Details, School Look, School Web Address | ✅ | School (Profile, Logo & Colours, Web Address) |
| Who Did What, Important Actions | ⬆ | Audit Logs (hash-chained, tamper-evident), Teacher Activity |
| See as Another User | ⬆ | Sign In As Someone (owner only, reason + time limit, audited) |
| Who Can See What | ✅ | Roles & Permissions (custom roles) |
| My Account, My Timetable, Settings, App Health Check, Look & About | ✅ | Account, Timetable, General Settings, System Information, Help |
| Dashboards (Learning, Money, People, Activity, My Class, My Children, Control Centre) | ✅ | Role dashboards, Analytics, Platform console |
| Online Backup (Supabase) Cloud Sync | ⛔ → ⬆ | Not needed: the server **is** the online copy. Backup & Data downloads a full copy at any time. |
| Full backup / data from the old app | ✅ | Backup & Data › **From the Old App**. On the same web address it now finds the offline app's data on the device by itself. |

## Kept different on purpose

- **Working with no internet.**
  - Online, pages already opened stay readable offline, but saving needs the connection.
  - The offline edition stays available at `/offline/` on the same web address for schools that need to type with no internet.
- **Rich Word/PDF newsletters.**
  - Announcements are plain, safe text: raw HTML was a script-injection risk.
  - Files are attached through Documents.
