# Closing open items: fingerprint/face clock-in, passport photos

**Date:** 10 Oct 2026
**Status:** built and tested on this computer. Going live still needs your accounts (see `ABO_PHASE8_DEPLOYMENT.md`).

## In simple words
Two of the open items on the handover list are now closed in the secure server edition.

### 1. Fingerprint / face clock-in (checked by the server)
Before, clock-in only checked the phone's GPS, and GPS can be faked with special apps. Now the school can **also require a fingerprint or face check**:
- **Each teacher sets up their own phone once.** Press "Set up fingerprint/face on this phone", then touch the sensor.
- **To clock in,** the phone asks for the fingerprint or face again.
- **The fingerprint or face never leaves the phone.** The phone signs a one-time code with a key that was made on that phone. The server keeps only the public key and checks the signature.
- **The owner switches it on** in Clock-in rules with "Staff must confirm with fingerprint or face".
- **A lost phone** can be removed by the teacher or the head. After that it stops working.

**What the server refuses (all tested with a real passkey):**

| Attempt | Result |
|---|---|
| Clock in without the fingerprint/face answer | refused, with a clear message |
| A passkey made on **another website** (a fake "phishing" copy of the site) | refused |
| A phone where the fingerprint check **did not pass** (touch only, no fingerprint) | refused |
| A **forged** signature (stolen key name, wrong key) | refused |
| An answer signed for an **old or different** one-time code | refused |
| The **same answer used twice** (replay) | refused |
| Another person's one-time code | refused |
| A failed attempt, then trying the same one-time code again | refused: the code is used up even when the attempt fails. **I found and fixed this weakness during testing** |
| A phone that was removed | no longer works |

**Real-browser test:** Chrome's built-in virtual fingerprint reader stood in for the phone.
- Set-up works.
- Clock-in works and the history shows "confirmed".
- A phone whose fingerprint check fails cannot be set up.
- The head sees the clock-in in the register.

**Needs:** a phone with fingerprint or face unlock, Chrome or Safari, and the live **https** address. Fingerprint/face is always tied to the web address set in `PUBLIC_ORIGIN`.

### 2. Passport photos and the school logo when moving from the offline app
Before, photos in the old backup were skipped. Now:
- **The preview counts the usable photos** (PNG/JPEG/WebP up to 1 MB) and lists any that are not real pictures.
- **When you press Commit,** the browser sends the same file again, and the server checks it is **byte for byte the file you previewed**. The photos are then saved and linked to each pupil.
- **The school logo** is added if the school has none yet and the person importing may change school settings.

| Check | Result |
|---|---|
| 2 real photos, 1 fake "photo", 1 pupil without a photo | 2 brought in, the fake one reported and skipped |
| A different file sent at commit | refused ("This is not the same file you previewed") |
| Photo opens afterwards | ✅ as a picture |
| Migration page in the browser | "1 passport photo(s) brought in, and the school logo" ✅ |

## Also fixed (found while testing)
- **A button stayed stuck after an error** in 3 places (Save all comments, Complete sale, Set up fingerprint), and the page logged an error. The code lost track of which button was pressed once the request was sent. Fixed: each button now comes back so you can try again.

## Tests
| Test | Result |
|---|---|
| New server tests: `passkeys.test.js` (real P-256 passkey made by a software "phone") | **3/3** |
| Photo import test (added to `legacy_reconcile.test.js`) | **4/4** in that file |
| New browser test: `passkeys.qa.js` (Chrome virtual fingerprint reader) | **9/9** |
| Full server suite (with Redis) | **169 passed, 0 failed, 0 skipped** |
| All browser suites | fingerprint **9/9**, menu **291/291**, UI **71/71**, menu clicks **251/251**, CBT **34/34**, portal **28/28**, clock-in/calendar/cashbook **19/19**, store/comments/ID cards **16/16**, materials/simple words **17/17**, migration (now with photos) **8/8**, sign in as / web address / offline **14/14** |
| School isolation check | **12/12**, all **86** school tables locked per school |
| `npm audit` (with the new package `@simplewebauthn/server` 14.0.3) | **0 vulnerabilities** |

## Files
- **Database:** `migrations/024_passkeys_clockin.sql`, plus a reverse script.
- **Server:**
  - `routes/school_life.js` (passkeys + the clock-in check)
  - `routes/migration.js` (photos + logo)
  - `package.json` (`@simplewebauthn/server`)
- **Web:**
  - `pages/schoollife.js` (set up, clock in, remove phone, rules)
  - `pages/records.js` (sends the file again for photos)
  - fixes in `pages/store.js` and `pages/comments_idcards.js`
- **Tests:**
  - `server/test/softauthn.js` (software phone)
  - `server/test/passkeys.test.js`
  - `server/test/e2e/passkeys.qa.js`

## Still open
- **Server edition:** saving while offline, then sending later.
- **Offline app:** the confirm/prompt boxes and the repeated functions.
- **Going live:** needs your accounts.
