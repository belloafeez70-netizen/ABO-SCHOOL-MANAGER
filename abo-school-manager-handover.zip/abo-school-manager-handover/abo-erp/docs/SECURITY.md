# Security controls (what is implemented, where, and how it is tested)

## Legacy weaknesses → fixes

| Legacy issue (see LEGACY_AUDIT) | Fix | Code | Test |
|---|---|---|---|
| S1 no password | Argon2id passwords + policy, access-code activation, lockout, MFA | `security/passwords.js`, `routes/auth.js` | auth.test.js |
| S2 client-side authZ | Server RBAC on every route + ownership checks; route inventory test | `auth/plugin.js`, `rbac/catalog.js` | rbac.test.js, security.test.js (inventory) |
| S3 fake isolation | Session-derived tenant + RLS + composite FKs + 404s | `db/migrations/008_rls.sql`, `db/pool.js` | tenant.test.js, BOLA sweep |
| S4 CBT key in browser | Keys server-only, server timing & grading | `routes/cbt.js`, `services/cbt.js` | cbt.test.js |
| S5 result tampering | Workflow + DB lock trigger + corrections + history | `003_results.sql`, `routes/results.js` | results.test.js |
| S6 editable audit | Hash-chained append-only audit via definer function; no DML grants; triggers | `007_audit_jobs.sql`, `audit/audit.js` | security.test.js (tamper detection) |
| S7 AI key in browser | Server-side AI proxy, env key, pseudonymised prompt, never auto-applied | `routes/ai.js` | unit + results tests |
| S8 XSS | DOM builder (text nodes only), newsletters stored as text, strict CSP | `web/assets/js/core/dom.js` | UI QA XSS probe |
| S9 exposed Firebase config | Removed; server API only | — | secret scan test |
| S10 SVG/data-URL files | Private object storage, magic-byte validation, SVG refused, size limits, ClamAV hook | `storage/index.js` | onboarding/security tests |
| S11 no headers | Helmet CSP/HSTS/XFO/nosniff/Referrer/Permissions/COOP/CORP | `app.js` | security.test.js |
| S12 fake payments | Server-computed balances, verified webhooks | `routes/finance.js` | finance.test.js |

## OWASP Top 10 (2021) mapping

* **A01 Broken access control** — RBAC per route, ownership checks, RLS, composite FKs, BOLA sweep (all `:id`
  routes × foreign ids), escalation guards, read-only support mode, route-inventory test.
* **A02 Cryptographic failures** — Argon2id; AES-256-GCM for TOTP seeds; SHA-256 for tokens/codes at rest; TLS
  to DB (`DB_SSL=require` default in prod); HSTS preload; secrets only from env.
* **A03 Injection** — parameterised SQL everywhere; identifiers never interpolated from input (sort whitelist,
  fixed table maps); JSON-schema validation; CSV formula-injection neutralised on export.
* **A04 Insecure design** — four-eyes on result approval, corrections, discounts, payment reversal; server clocks
  for CBT; append-only history; threat-driven tests.
* **A05 Misconfiguration** — config refuses weak/placeholder secrets, insecure cookies and http origins in
  staging/production; `X-Powered-By` removed; generic errors; least-privilege DB grants.
* **A06 Vulnerable components** — 9 runtime deps, pinned (`--save-exact`), `npm audit` = 0 vulnerabilities
  (uuid pinned via overrides), CI runs `npm audit`; no CDN scripts.
* **A07 Identification & authentication** — lockout, rate limits, MFA, session rotation, revocation on password
  change/disable/suspension, generic login errors, dummy-hash timing equalisation.
* **A08 Software & data integrity** — checksummed migrations (edited migration refuses to run), hash-chained audit,
  signed webhooks, backup checksums.
* **A09 Logging & monitoring** — structured logs with redaction, request ids, audit log, login/security events,
  Prometheus metrics + alert rules, high-severity events (credential stuffing, bad webhook signatures, MFA brute
  force, amount mismatch).
* **A10 SSRF** — the server only calls fixed, configured hosts (Paystack, AI provider, S3, SMTP); no user-supplied URLs.

## Added in the backend-hardening round

* **Refresh-token reuse detection:** a rotated-out session token presented after its 60 s grace window revokes the
  whole session and raises a high-severity `session_token_reuse` event.
* **Automatic security events** (`lib/secmon.js`): cross-tenant probes (404 on an id that exists in another school),
  privilege-escalation attempts (403 on users/roles/platform), ≥ 10 denials in 5 minutes, rate-limit abuse, export
  bursts (≥ `EXPORT_ALERT_PER_HOUR`), self-approval attempts.
* **Strict CORS** allow-list (`ALLOWED_ORIGINS`), credentials only for trusted origins, never `*`.
* **DTO safety net:** any API response containing `password_hash`, token/code hashes, MFA seeds or storage keys is
  blocked and logged (500) instead of being sent.
* **Idempotency-Key** on payments and invoice generation; concurrent duplicates collapse to one write.
* **Standard error envelope** `{ "error": { "code", "message", "requestId" } }`; foreign/unknown ids return a
  non-revealing 404.
* **Branch isolation** enforced by RESTRICTIVE RLS policies, not only by application code.

## Other controls

* CSRF: SameSite=Strict + Origin/Fetch-Metadata check + per-session HMAC token on all unsafe methods.
* CORS: not enabled (same-origin only).
* Mass assignment: every body schema has `additionalProperties:false` and Ajv `removeAdditional:false` ⇒ 400.
* Request limits: 1 MB JSON, 5 MB uploads (logo 1.5 MB, passport 1 MB), 5,000-row imports, page size ≤ 100.
* File downloads: authorised per purpose; `Content-Disposition: attachment` for non-images, `CSP: sandbox`,
  `nosniff`; S3 uses 60-second presigned URLs; sensitive downloads audited.
* Privacy: least-privilege field hiding (medical notes need `students.edit`), AI prompt excludes names/IDs/contacts,
  sensitive email bodies redacted after delivery, legacy API keys discarded at import.
* Cloning/IP: grading, authorisation, workflows and data live on the server; the browser bundle contains only
  presentation code. Minification is not relied on for security.

## Known limitations (be honest)

* Rate limiting is per instance unless `RATE_LIMIT_REDIS_URL` is set (login lockout is DB-backed and global).
* Audit logs are tamper-*evident*, not tamper-*proof*, against a database superuser; ship daily exports to WORM
  storage (e.g. S3 Object Lock) for regulatory-grade retention.
* The permission cache allows up to 30 s of stale permissions after a role edit (sessions of disabled users are
  revoked immediately).
* No third-party penetration test has been performed yet — schedule one before handling real student data at scale.
* WebAuthn/passkeys are not implemented (TOTP only).
