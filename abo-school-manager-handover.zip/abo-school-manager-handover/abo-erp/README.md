# A.B.O. School Manager — multi-tenant School ERP (server edition)

Production-oriented rebuild of the offline `school_broadsheet_manager_bopc_erp.html`: the **server and PostgreSQL are
the source of truth**, the browser is an untrusted client, and every school's data is isolated server-side
(RLS + composite foreign keys + per-request authorisation).

* **Backend:** Node 20 · Fastify 5 · PostgreSQL 15+ (tested on 17) · Argon2id · TOTP MFA · S3-compatible storage
* **Frontend:** dependency-free ES modules, strict CSP (no inline JS/CSS), responsive, dark mode, role workspaces
* **238 API endpoints (OpenAPI 3.1) · 75 tables · 72 under RLS · 78 permissions · 14 role templates · 146 automated tests (incl. an 8k-request robustness crawl + a 30-candidate exam-hall test) + 71 UI + 247 menu + 398 menu-click + 34 CBT + 28 portal/lesson-notes browser checks · load-tested with 5.2k accounts / 800 concurrent users**
* Multi-school memberships, branch-level isolation, result workflow DRAFT→SUBMITTED→REVIEWED→APPROVED→PUBLISHED, payment allocations & receipts, idempotent payments

## New in 5.5 — production deployment: Netlify + separate API (see docs/NETLIFY_DEPLOYMENT.md)

* **Frontend on Netlify** (`netlify.toml`, `npm run build:web` → hashed, minified, code-split `dist/web` with CSP/HSTS headers
  and a build-time secret scan). Works on the free `https://<site>.netlify.app` address first; your own domain later is
  **configuration only** (`PUBLIC_ORIGIN` / `ALLOWED_ORIGINS`).
* **Edge proxy** `netlify/edge-functions/api-proxy.js`: `/api/*` → the API with a shared secret and the real client IP, so the
  session cookie stays first-party (netlify.app is a public suffix) and the API refuses direct traffic (`REQUIRE_PROXY_SECRET`).
* **API-only mode** (`SERVE_FRONTEND=false`), startup refusal if the DB role could bypass row-level security, Redis-shared rate
  limits (tested with 2 instances), files streamed through the API from S3/R2.
* **Backups:** nightly encrypted off-site dump (Render cron image or GitHub Actions) + weekly automated restore drill + heartbeat.
* **Monitoring:** error/crash/failed-job alerts to Slack/Discord/Teams (`ERROR_WEBHOOK_URL`, PII-scrubbed), browser error reporting,
  Prometheus metrics + alert rules.
* **Single-file edition:** `npm run build:single` → the complete online app in ONE `index.html` (hash-based CSP, no external files);
  opened from disk it shows how to reach the portal. Copy delivered as `abo-school-manager.html`.
* `render.yaml` blueprint (API ×2, worker, Redis, PostgreSQL 17, backup cron), `npm run verify:deploy -- <site> <api>` live checker,
  `npm run netlify:local` to run the production layout locally.

## New in 5.4 — website parity (see docs/WEBSITE_PARITY.md)

* Sign-in page with **Staff · Student · Parent** tabs; students can use their **admission number**, parents their **phone number**
  (school-scoped, never guessed when ambiguous); first-timers type the **access code in the password box**, then create a password.
  Deep links for the school website: `/#/s/<school>?portal=student` / `?portal=parent`.
* **Lesson Notes** (Academics): write for assigned class/subjects, attachments, submit → review queue → approve / return / reopen,
  coverage report with "not started" gaps, printable note; approved notes shared with the class's students and parents.
* `npm run preflight` — go-live checker for the production server (config, TLS, RLS role, migrations, demo data, SMTP, Paystack…).

## New in 5.2 — CBT / Online Examination

* 🖥️ CBT menu: dashboard, question bank (8 types, maths notation, images, topics/difficulty, import/export), 5-step exam wizard (manual or automatic question selection), candidates, scheduled/active/completed lists, results (release/withhold/reset/export), analytics, settings — see **docs/CBT.md**.
* Mobile-first exam interface: one question at a time, navigator, mark for review, server-anchored timer with warnings, offline-tolerant autosave, resume after refresh, review summary.
* CBT scores go into the EXISTING result sheets (scaled to the school's own component, e.g. Exam /60) → broadsheet → report sheet, through the normal approval workflow.
* Rate limits now work for schools behind one shared IP (per-session / per-account limits + per-IP ceilings).

## New in 5.1 — School Manager menu

* Tree menu (☰ SCHOOL MANAGER) with Students, Academics, Scores & Results, Broadsheet, Report Sheets, Analytics, Teachers, School, Administration and More — see **docs/MENU.md**.
* Platform approval of new schools; each approved school gets its own branded sign-in page `/#/s/<slug>` showing its logo and name.
* New pages: CA/Exam score entry, result processing/approval/publishing, subject/terminal/annual broadsheets, ranking, batch report printing & PDF, result templates, analytics with charts, teacher accounts/activity, school profile/branding/head (signature on report sheets), backup & restore, notifications, help, system information.

## Quick start (development)

```bash
npm ci
# PostgreSQL running locally with a superuser, then:
DATABASE_ADMIN_URL=postgres://postgres@127.0.0.1:5432/postgres bash scripts/dev-reset.sh   # roles, DB, migrations, demo data
npm start                                   # http://localhost:8080
npm test                                    # 90 API/DB tests (creates its own abo_erp_test DB)
npm run test:ui                             # headless-Chrome QA against a running server (needs puppeteer)
```

Demo accounts (development only, password `Demo#School2026`): `bopc.owner` (MFA enrolment on first sign-in),
`bopc.admin`, `bopc.exams`, `bopc.bursar`, `bopc.accounts`, `bopc.teacher1`, `bopc.teacher2`, `bopc.student`,
`bopc.parent`, `bopc.annex` (branch-restricted admin), `demo.proprietor` (member of both demo schools), a second school `gfa.*`, and platform admin `abo.platform`. Login ID **or email** works.

## Documentation

| Doc | Purpose |
|---|---|
| [docs/LEGACY_AUDIT.md](docs/LEGACY_AUDIT.md) | Audit of the original HTML app: modules, storage, 12 security weaknesses, bottlenecks, migration plan |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | Tenancy, auth, RBAC, results/CBT/finance integrity, scalability |
| [docs/SECURITY.md](docs/SECURITY.md) | Control-by-control mapping (legacy issues, OWASP Top 10), known limitations |
| [docs/API.md](docs/API.md) · [docs/openapi.json](docs/openapi.json) | Generated endpoint reference with required permissions; OpenAPI 3.1 (also served at `/api/v1/openapi.json`) |
| [docs/PHASE_COVERAGE.md](docs/PHASE_COVERAGE.md) | The 53-phase backend specification → implementation & evidence |
| [docs/LOAD_TEST.md](docs/LOAD_TEST.md) | Load test, slow-query findings, capacity planning |
| [docs/NETLIFY_DEPLOYMENT.md](docs/NETLIFY_DEPLOYMENT.md) | **Go-live on Netlify + separate API**: architecture, env vars, steps, custom domain later, backups, monitoring, scale plan |
| [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md) | Environments, managed Postgres, Docker, storage, Cloudflare WAF/CDN, email, payments, rollback |
| [docs/DISASTER_RECOVERY.md](docs/DISASTER_RECOVERY.md) | Backups, restore drill (executed), scenarios |
| [docs/FEATURE_MAP.md](docs/FEATURE_MAP.md) | Every legacy feature → preserved / improved / pending / removed (with reasons) |
| [docs/QUALITY_GATE.md](docs/QUALITY_GATE.md) | The checklist with evidence, and what still needs external services |
| [docs/WEBSITE_PARITY.md](docs/WEBSITE_PARITY.md) | Current school website vs this app: what was missing and how it is now covered |
| [docs/TEST_REPORT.md](docs/TEST_REPORT.md) | Test results, defects found, performance numbers |

## Layout

```
server/src/   config · db (migrations, RLS, grants) · security · auth · rbac · audit · services · storage · routes · jobs
server/test/  node:test suites (real PostgreSQL) + e2e/ui.qa.js (Chrome)
web/          index.html + assets (core UI kit, pages per module)
deploy/       backup/restore scripts, Prometheus alert rules
scripts/      dev-reset, gen-secrets, create-platform-admin, gen-api-doc, bench
```

The legacy single-file app is intentionally left untouched as the *offline edition* during migration; schools move
their data with **Legacy migration** (preview → atomic commit).
