/* ==========================================================================================
   A.B.O. cloud + biometrics for the OFFLINE edition (school_broadsheet_manager_bopc_erp.html)

     • Cloud Sync (Supabase)  the school record is kept in your own Supabase project, so the Owner, the office and
                              every teacher's phone see the same data. Works offline first: changes are saved on the
                              device and sent when the internet is back. When two devices changed the school at the
                              same time the changes are merged (nothing is thrown away).
     • Link a device          the Owner shares one code; a teacher pastes it on the sign-in screen and the phone
                              downloads the school.
     • Fingerprint / Face     WebAuthn (the phone's own fingerprint, face or screen lock). Used to activate a phone
                              for clock-in, to confirm each clock-in, and to sign in. The signature returned by the
                              phone is checked against the key saved at activation (not just a yes/no from the phone).
     • Clock-in events        each clock-in is sent to Supabase as its own row, so phones never overwrite each other;
                              the Owner's dashboard picks them up within seconds.

   Talks to Supabase through its REST endpoint (/rest/v1/rpc/...) with plain fetch — no library to download.
   Database side: legacy/supabase/setup.sql (also downloadable from the Cloud Sync screen).
   ========================================================================================== */
(function () {
  'use strict';
  if (window.__aboCloud) return; window.__aboCloud = true;
  if (typeof window.erpData !== 'function' || !window.ERP_MODULES || !window.ERPRender) return;

  var SETUP_SQL = /*__SUPABASE_SQL__*/'';
  // the school's own Supabase project (public values only — the secret key never goes in the app)
  var DEFAULT_PROJECT = { url: 'https://fehpqiqqxgqugioowepu.supabase.co', key: 'sb_publishable_1ziN5ptqF_yI0zjcdMsw8w_Gy9kXE-Q' };
  var CFG_KEY = 'aboSupabase', ST_KEY = 'aboSupabaseState', BIO_DEV_KEY = 'aboBioDevice';
  var HOME = 'broadsheetData_default';

  /* ───────────────────────── helpers ───────────────────────── */
  function G(name) { if (window.aboGlobalGet) return window.aboGlobalGet(name); try { return (0, eval)('typeof ' + name + ' !== "undefined" ? ' + name + ' : undefined'); } catch (e) { return undefined; } }   // CSP-safe accessor first (no eval)
  var E = function (v) { return window.erpEsc(v); };
  var A = function (v) { return window.erpAttr(v); };
  var D = function () { return window.erpData(); };
  var can = function () { try { return window.erpCan(); } catch (e) { return false; } };
  var toast = function (m) { try { window.showToast(m); } catch (e) { /* ignore */ } };
  var ico = function (n) { return (window.ABO_PRO_SKIN && window.ABO_PRO_SKIN.icon) ? window.ABO_PRO_SKIN.icon(n, 'pro-ico-inline') : ''; };
  var me = function () { return G('currentUser'); };
  var myId = function () { var u = me(); return u ? String(u.loginId || u.id || '') : ''; };
  var LS = {
    get: function (k) { try { return window.localStorage.getItem(k); } catch (e) { return null; } },
    set: function (k, v) { try { window.localStorage.setItem(k, v); return true; } catch (e) { return false; } },
    del: function (k) { try { window.localStorage.removeItem(k); } catch (e) { /* ignore */ } },
    json: function (k, d) { try { return JSON.parse(window.localStorage.getItem(k) || 'null') || d; } catch (e) { return d; } }
  };
  function badge(text, tone) { return '<span class="erp-badge ' + (tone || '') + '">' + E(text) + '</span>'; }
  function field(label, inner, wide, hint) { return '<div class="erp-field' + (wide ? ' w2' : '') + '"><label>' + E(label) + '</label>' + inner + (hint ? '<small class="pro-sub">' + hint + '</small>' : '') + '</div>'; }
  function val(id) { var e = document.getElementById(id); return e ? String(e.value || '').trim() : ''; }
  function ago(t) {
    if (!t) return 'never'; var s = Math.round((Date.now() - new Date(t).getTime()) / 1000);
    if (s < 10) return 'just now'; if (s < 60) return s + ' s ago'; if (s < 3600) return Math.round(s / 60) + ' min ago';
    if (s < 86400) return Math.round(s / 3600) + ' h ago'; return new Date(t).toLocaleString('en-NG', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
  }
  function slug(s) { return String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 50); }
  function randHex(n) { var b = new Uint8Array(n); crypto.getRandomValues(b); return Array.prototype.map.call(b, function (x) { return (x < 16 ? '0' : '') + x.toString(16); }).join(''); }
  function newSecret() { var a = 'abcdefghjkmnpqrstuvwxyz23456789', b = new Uint8Array(20), s = ''; crypto.getRandomValues(b); for (var i = 0; i < 20; i++) { s += a[b[i] % a.length]; if (i % 5 === 4 && i < 19) s += '-'; } return s; }
  function deviceLabel() {
    var ua = navigator.userAgent || '', dev = /iPhone/.test(ua) ? 'iPhone' : /iPad/.test(ua) ? 'iPad' : /Android/.test(ua) ? (/Mobile/.test(ua) ? 'Android phone' : 'Android tablet') : /Windows/.test(ua) ? 'Windows PC' : /Mac OS X/.test(ua) ? 'Mac' : /Linux/.test(ua) ? 'Linux PC' : 'Device';
    var br = /Edg\//.test(ua) ? 'Edge' : /OPR\//.test(ua) ? 'Opera' : /Chrome\//.test(ua) ? 'Chrome' : /Firefox\//.test(ua) ? 'Firefox' : /Safari\//.test(ua) ? 'Safari' : 'browser';
    return dev + ' · ' + br;
  }
  function current() { try { return window.ABO && window.ABO.render && window.ABO.render.current ? window.ABO.render.current() : window.erpActiveModule; } catch (e) { return null; } }
  function rerenderIf(ids) { var c = current(); if (c && ids.indexOf(c) >= 0) { var h = document.getElementById('erpHost'); if (h && window.ERPRender[c]) h.innerHTML = window.ERPRender[c](); } }
  function b64u(buf) { var b = new Uint8Array(buf), s = ''; for (var i = 0; i < b.length; i++) s += String.fromCharCode(b[i]); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }
  function unb64u(str) { str = String(str).replace(/-/g, '+').replace(/_/g, '/'); while (str.length % 4) str += '='; var s = atob(str), b = new Uint8Array(s.length); for (var i = 0; i < s.length; i++) b[i] = s.charCodeAt(i); return b; }
  function utf8b64u(s) { return b64u(new TextEncoder().encode(s)); }
  function b64uutf8(s) { return new TextDecoder().decode(unb64u(s)); }
  function hash(str) { var h = 0x811c9dc5; str = String(str || ''); for (var i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0; } return h.toString(16) + ':' + str.length; }

  /* ───────────────────────── small IndexedDB store (the last synced copy, used for merging) ───────────────────────── */
  var idb = (function () {
    var dbp = null;
    function db() {
      if (dbp) return dbp;
      dbp = new Promise(function (res, rej) {
        try { var r = indexedDB.open('abo-cloud', 1); r.onupgradeneeded = function () { r.result.createObjectStore('kv'); }; r.onsuccess = function () { res(r.result); }; r.onerror = function () { rej(r.error); }; }
        catch (e) { rej(e); }
      });
      return dbp;
    }
    function tx(mode, fn) { return db().then(function (d) { return new Promise(function (res, rej) { var t = d.transaction('kv', mode), s = t.objectStore('kv'), r = fn(s); t.oncomplete = function () { res(r && r.result); }; t.onerror = function () { rej(t.error); }; }); }); }
    var mem = {};
    return {
      get: function (k) { return tx('readonly', function (s) { return s.get(k); }).catch(function () { return mem[k]; }); },
      set: function (k, v) { return tx('readwrite', function (s) { return s.put(v, k); }).catch(function () { mem[k] = v; }); },
      del: function (k) { return tx('readwrite', function (s) { return s.delete(k); }).catch(function () { delete mem[k]; }); }
    };
  })();

  /* ───────────────────────── config + state ───────────────────────── */
  function cfg() { var c = LS.json(CFG_KEY, null); return c && c.url && c.anon && c.school && c.secret ? c : null; }
  function setCfg(c) { if (c) LS.set(CFG_KEY, JSON.stringify(c)); else LS.del(CFG_KEY); }
  var st = LS.json(ST_KEY, {}) || {};
  st.pending = st.pending || [];
  function saveSt() { LS.set(ST_KEY, JSON.stringify(st)); }
  function blobKey() { try { return window.getSchoolDataKey(); } catch (e) { return HOME; } }
  function active() { return !!(cfg() && me()); }
  function onPrimary() { var c = cfg(); return !!(c && c.key === blobKey()); }
  function localRaw() { var c = cfg(); return c ? LS.get(c.key) : null; }

  /* ───────────────────────── Supabase REST ───────────────────────── */
  function CloudError(kind, message, status) { this.kind = kind; this.message = message; this.status = status; }
  function rpc(fn, body, c) {
    c = c || cfg(); if (!c) return Promise.reject(new CloudError('config', 'Cloud Sync is not set up on this device.'));
    var ctl = typeof AbortController !== 'undefined' ? new AbortController() : null, timer = setTimeout(function () { if (ctl) ctl.abort(); }, 20000);
    return fetch(c.url.replace(/\/+$/, '') + '/rest/v1/rpc/' + fn, {
      method: 'POST', signal: ctl ? ctl.signal : undefined,
      headers: keyHeaders(c.anon),
      body: JSON.stringify(body)
    }).then(function (r) {
      clearTimeout(timer);
      return r.text().then(function (t) {
        var j = null; try { j = t ? JSON.parse(t) : null; } catch (e) { /* not json */ }
        if (r.status === 401 || r.status === 403) throw new CloudError('key', 'Supabase rejected the key. Copy the Publishable key (sb_publishable_…) again from Project Settings → API Keys.', r.status);
        if (r.status === 404 || (j && /Could not find the function|PGRST202/.test(String(j.message || j.code || '')))) throw new CloudError('setup', 'The setup script has not been run in this Supabase project yet (SQL Editor → paste the script → Run).', r.status);
        if (!r.ok) throw new CloudError('server', (j && (j.message || j.hint)) || ('Supabase error ' + r.status), r.status);
        if (j && j.ok === false) {
          if (j.error === 'wrong_secret') throw new CloudError('secret', 'The school secret does not match — or there were too many wrong tries from this connection (wait 15 minutes). Ask the Owner for a new device link if it keeps failing.');
          if (j.error === 'conflict') throw new CloudError('conflict', 'Another device saved first.', 409);
          if (j.error === 'invite_required') throw new CloudError('invite', 'This cloud only accepts NEW schools with an invitation code from A.B.O. Edu Consultant (0805 144 6681). Type the code in “Invitation code” and connect again.');
          if (j.error === 'too_many_new_schools') throw new CloudError('limit', 'Too many new schools were created from this internet connection today. Try again tomorrow or contact A.B.O.');
          if (j.error === 'too_large') throw new CloudError('size', 'This school record is too large to upload in one go (more than 30 MB). Remove very large photos or documents and try again.');
          throw new CloudError('server', String(j.error || 'Request refused'));
        }
        return j;
      });
    }, function (e) {
      clearTimeout(timer);
      throw new CloudError('network', navigator.onLine === false ? 'No internet connection. Changes are kept on this device and sent when you are back online.' : 'Could not reach Supabase. Check the Project URL and the internet connection.');
    });
  }
  // new Supabase keys (sb_publishable_…) go only in the apikey header; legacy anon keys (JWT) also as the bearer token
  function keyHeaders(k) {
    var h = { apikey: k, 'Content-Type': 'application/json', 'x-client-info': 'abo-school-manager' };
    if (/^eyJ/.test(k)) h.Authorization = 'Bearer ' + k;
    return h;
  }
  function auth(c) { c = c || cfg(); return { p_school: c.school, p_secret: c.secret }; }

  /* ───────────────────────── three-way merge (base = last synced copy) ───────────────────────── */
  function J(x) { return x === undefined ? 'undefined' : JSON.stringify(x); }
  function isObj(x) { return x && typeof x === 'object' && !Array.isArray(x); }
  function itemKey(x) { if (!isObj(x)) return null; var k = x.id || x.loginId || x.uid || x._id; if (k) return 'k:' + k; if (x.name && (x.date || x.createdAt)) return 'n:' + x.name + '|' + (x.date || x.createdAt); return null; }
  function merge3(b, l, r) {
    var jl = J(l), jr = J(r); if (jl === jr) return l;
    var jb = J(b); if (jb === jl) return r; if (jb === jr) return l;
    if (isObj(l) && isObj(r)) {
      var out = {}, bo = isObj(b) ? b : {}, keys = {};
      Object.keys(l).concat(Object.keys(r), Object.keys(bo)).forEach(function (k) { keys[k] = 1; });
      Object.keys(keys).forEach(function (k) {
        var inL = Object.prototype.hasOwnProperty.call(l, k), inR = Object.prototype.hasOwnProperty.call(r, k), inB = Object.prototype.hasOwnProperty.call(bo, k);
        if (inL && inR) out[k] = merge3(inB ? bo[k] : undefined, l[k], r[k]);
        else if (inL) { if (!(inB && J(bo[k]) === J(l[k]))) out[k] = l[k]; }        // remote deleted an unchanged key → stays deleted
        else if (inR) { if (!(inB && J(bo[k]) === J(r[k]))) out[k] = r[k]; }
      });
      return out;
    }
    if (Array.isArray(l) && Array.isArray(r)) return mergeArr(Array.isArray(b) ? b : [], l, r);
    return l;   // both changed the same value: this device's edit is the newest intention
  }
  // merge two edited lists item by item, once every item has a key (k*) that says which item it is
  function keyedMerge(b, l, r, kb, kl, kr) {
    var bm = {}, lm = {}, rm = {}, order = [];
    b.forEach(function (x, i) { bm[kb[i]] = x; }); l.forEach(function (x, i) { lm[kl[i]] = x; }); r.forEach(function (x, i) { rm[kr[i]] = x; });
    kr.concat(kl).forEach(function (k) { if (order.indexOf(k) < 0) order.push(k); });
    return order.map(function (k) {
      var inL = k in lm, inR = k in rm, inB = k in bm;
      if (inL && inR) return merge3(bm[k], lm[k], rm[k]);
      if (inL) return (inB && J(bm[k]) === J(lm[k])) ? undefined : lm[k];   // deleted remotely, untouched here
      return (inB && J(bm[k]) === J(rm[k])) ? undefined : rm[k];
    }).filter(function (x) { return x !== undefined; });
  }
  /* Class registers (learners) have no id. Before: a learner changed on both devices came back TWICE, and edited
     learners moved to the end of the class. Now a row is recognised by its name (1st, 2nd … "Musa Ibrahim"), and a
     row renamed in place keeps its identity, so two devices' edits to the same learner are merged into one. */
  function nameOf(x) { return String((x && x.name) || '').trim().toLowerCase(); }
  function occKeys(a) { var seen = {}; return a.map(function (x) { var n = nameOf(x); seen[n] = (seen[n] || 0) + 1; return 'nm:' + n + '#' + seen[n]; }); }
  function alignKeys(a, b, kb) {
    var out = new Array(a.length), used = {}, seen = {};
    // 0. unchanged rows are matched exactly (this also tells apart two learners with the same name)
    var bj = b.map(J);
    a.forEach(function (x, i) { var j = J(x), at = (i < b.length && bj[i] === j && !used[kb[i]]) ? i : -1;
      if (at < 0) for (var q = 0; q < b.length; q++) if (bj[q] === j && !used[kb[q]]) { at = q; break; }
      if (at >= 0) { out[i] = kb[at]; used[kb[at]] = 1; } });
    // 1. same place, same name → the same row
    a.forEach(function (x, i) { if (!out[i] && i < b.length && !used[kb[i]] && nameOf(x) === nameOf(b[i])) { out[i] = kb[i]; used[kb[i]] = 1; } });
    // 2. moved (e.g. a row above was removed) → the first unused row with that name
    a.forEach(function (x, i) { if (out[i]) return; var n = nameOf(x); for (var j = 0; j < b.length; j++) if (!used[kb[j]] && nameOf(b[j]) === n) { out[i] = kb[j]; used[kb[j]] = 1; return; } });
    // 3. same place, new name → that row was renamed (or an empty row was filled in)
    a.forEach(function (x, i) { if (!out[i] && i < b.length && !used[kb[i]]) { out[i] = kb[i]; used[kb[i]] = 1; } });
    // 4. anything else is a new row
    a.forEach(function (x, i) { if (out[i]) return; var n = nameOf(x); seen[n] = (seen[n] || 0) + 1; out[i] = 'new:' + n + '#' + seen[n]; });
    return out;
  }
  function mergeArr(b, l, r) {
    var keyed = l.concat(r).every(function (x) { return itemKey(x); });
    if (keyed) return keyedMerge(b, l, r, b.map(itemKey), l.map(itemKey), r.map(itemKey));
    var objs = function (a) { return a.every(isObj); };
    if (l.length && r.length && objs(l) && objs(r) && objs(b)) {
      var named = function (a) { return a.every(function (x) { return typeof x.name === 'string'; }); };
      if (named(l) && named(r) && named(b)) { var kb = occKeys(b); return keyedMerge(b, l, r, kb, alignKeys(l, b, kb), alignKeys(r, b, kb)); }
      // rows without names that line up one-to-one (e.g. a learner's scores, one row per subject): merge row by row
      if (b.length === l.length && l.length === r.length) return l.map(function (x, i) { return merge3(b[i], x, r[i]); });
    }
    var bs = b.map(J), ls = l.map(J), rs = r.map(J), out = r.slice();
    l.forEach(function (x, i) { if (bs.indexOf(ls[i]) < 0 && rs.indexOf(ls[i]) < 0) out.push(x); });            // added here
    return out.filter(function (x) { var j = J(x); return !(bs.indexOf(j) >= 0 && ls.indexOf(j) < 0); });      // removed here
  }

  /* ───────────────────────── sync engine ───────────────────────── */
  var busy = false, inflight = null, applying = false, pushTimer = null, lastErr = null, status = 'idle';
  function setStatus(s, err) { status = s; lastErr = err || null; st.lastStatus = s; st.lastError = err ? err.message : null; saveSt(); paintIndicator(); rerenderIf(['cloud-sync']); }
  function userBusy() {
    var mh = document.getElementById('erpModalHost'); if (mh && !mh.classList.contains('hidden') && mh.innerHTML.trim()) return true;
    var a = document.activeElement; return !!(a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName) && a.closest && a.closest('#erpHost'));
  }
  function quietly(fn) { var t = window.showToast; window.showToast = function () {}; try { return fn(); } finally { window.showToast = t; } }
  function writeLocal(key, raw) {
    var g = window.__aboDataGuard, wasOpen = !!(g && g.loadedKeys && g.loadedKeys().indexOf(key) >= 0);
    if (g && g.allow) g.allow(key);
    LS.set(key, raw);
    if (g && g.revoke && !wasOpen) g.revoke(key);   // keys not loaded on this page stay protected (e.g. the sign-in save)
  }
  function applyData(data, version, dirtyAfter, baseData) {
    var c = cfg(); if (!c) return;
    applying = true;
    var raw = JSON.stringify(data);
    writeLocal(c.key, raw);
    if (me()) {
      quietly(function () {
        try { window.ABO && window.ABO.store && window.ABO.store.load ? window.ABO.store.load() : window.loadSchoolData(); } catch (e) { console.warn('[cloud] load', e); }
        try { window.erpEnsure && window.erpEnsure(); } catch (e) { /* ignore */ }
      });
      try { var cur = current(); if (cur && window.ABO && window.ABO.go) window.ABO.go(cur); else if (window.renderRoleDashboard) window.renderRoleDashboard(); } catch (e) { /* ignore */ }
    }
    st.version = version;
    // saves triggered by loading settle first; then the baseline is taken
    setTimeout(function () {
      var now = localRaw();
      st.baseHash = dirtyAfter ? hash(raw) : hash(now); st.dirty = !!dirtyAfter || false; saveSt(); applying = false; baselineChanges();
      if (st.dirty) schedulePush(300);
    }, 900);
    // the merge base stays the cloud copy until this device's merged changes are uploaded
    idb.set('base:' + c.school, baseData !== undefined ? baseData : data);
  }
  function markIfChanged() {
    if (applying || !active() || !onPrimary()) return;
    var raw = localRaw(); if (!raw) return;
    if (hash(raw) !== st.baseHash) { if (!st.dirty) { st.dirty = true; saveSt(); paintIndicator(); } schedulePush(1500); }
  }
  function schedulePush(ms) { clearTimeout(pushTimer); pushTimer = setTimeout(function () { sync(); }, ms == null ? 1500 : ms); }

  function pull(have) {
    return rpc('abo_pull', Object.assign(auth(), { p_have: have == null ? (st.version == null ? -1 : st.version) : have }));
  }
  function mergeWith(remote) {
    var c = cfg();
    return resolveFiles(remote.data || {}).then(function (rd) { remote = Object.assign({}, remote, { data: rd }); return idb.get('base:' + c.school); }).then(function (base) {
      var local = null; try { local = JSON.parse(localRaw() || 'null'); } catch (e) { /* ignore */ }
      var merged = local ? merge3(base || {}, local, remote.data || {}) : remote.data;
      applyData(merged, remote.version, true, remote.data || {});
      toast('Changes from another device were merged with yours.'); activity('sync', 'Merged changes from another device', { version: remote.version });
      return new Promise(function (r) { setTimeout(r, 1000); });   // let the reload settle, then this round uploads the merge
    });
  }
  // one sync round: pull what is new, merge if needed, push local changes, send queued clock-ins, fetch new ones
  function sync(opts) {
    opts = opts || {};
    if (!active()) return Promise.resolve(false);
    // a round is already running: wait for it, then run a fresh one (so "Sync now" really syncs)
    if (busy) return (inflight || Promise.resolve()).then(function () { return sync(opts); });
    busy = true; setStatus('syncing');
    var c = cfg();
    return inflight = (onPrimary() ? pull() : Promise.resolve({ unchanged: true })).then(function (res) {
      if (!res.unchanged && res.version !== st.version) {
        if (!res.data) { st.version = res.version; return; }
        if (st.dirty) return mergeWith(res);
        if (userBusy() && !opts.force) { st.deferred = true; return; }       // do not swap the screen under someone typing
        st.deferred = false;
        return resolveFiles(res.data).then(function (data) {
          var first = st.version == null; applyData(data, res.version, false);
          if (!first) toast('Updated from the school cloud (' + (res.updated_by || 'another device') + ').');
          return new Promise(function (r) { setTimeout(r, 950); });
        });
      }
    }).then(function () {
      if (!st.dirty || applying || !onPrimary()) return;
      var raw = localRaw(); var data = JSON.parse(raw);
      return externalize(data).then(function (wire) {
        return rpc('abo_push', Object.assign(auth(), { p_data: wire, p_base: st.version || 0, p_by: (me() && (me().name || me().loginId)) || 'device', p_device: deviceLabel() }));
      }).then(function (res) {
          st.version = res.version; st.lastPush = new Date().toISOString();
          st.baseHash = hash(raw); st.dirty = hash(localRaw()) !== st.baseHash; saveSt(); idb.set('base:' + c.school, data);
        }, function (e) {
          if (e.kind === 'conflict') return pull(-1).then(mergeWith);
          throw e;
        });
    }).then(function () { return syncRecords(); })
      .then(function () { return flushClock(); })
      .then(function () { return pollClock(); })
      .then(function () { return flushActivity(); })
      .then(function () { st.lastSync = new Date().toISOString(); saveSt(); busy = false; setStatus('ok'); if (st.dirty || st.recAgain) schedulePush(800); return true; },
        function (e) { busy = false; setStatus(e.kind === 'network' ? 'offline' : 'error', e); if (e.kind === 'network') schedulePush(30000); return false; });
  }

  /* ───────────────────────── clock-in events ───────────────────────── */
  function clockEvent(ev) {
    var c = cfg(); if (!c || !onPrimary()) return Promise.resolve(false);
    ev = Object.assign({ device: deviceLabel() }, ev);
    st.pending.push(ev); saveSt();
    return flushClock().then(function () { return st.pending.indexOf(ev) < 0; }, function () { return false; });
  }
  function flushClock() {
    if (!cfg() || !st.pending.length) return Promise.resolve();
    var list = st.pending.slice();
    return list.reduce(function (p, ev) {
      return p.then(function () {
        return rpc('abo_clock_add', Object.assign(auth(), { p_event: ev })).then(function () {
          var i = st.pending.indexOf(ev); if (i < 0) i = st.pending.findIndex(function (x) { return J(x) === J(ev); }); if (i >= 0) st.pending.splice(i, 1); saveSt();
        });
      });
    }, Promise.resolve()).catch(function (e) { if (e.kind !== 'network') console.warn('[cloud] clock', e.message); throw e; });
  }
  function pollClock() {
    if (!active() || !onPrimary()) return Promise.resolve();     // clock-ins belong to the connected school
    var since = st.clockSince || new Date(Date.now() - 2 * 86400000).toISOString();
    return rpc('abo_clock_since', Object.assign(auth(), { p_since: since })).then(function (res) {
      var evs = res.events || []; st.clockSince = res.now || since;
      st.recent = evs.concat(st.recent || []).slice(-40); saveSt();
      if (evs.length) mergeClock(evs);
    });
  }
  function mergeClock(evs) {
    var d = D(); d.staffClock = d.staffClock || { settings: { resume: '07:30', close: '15:00', grace: 10 }, days: {} }; d.staffClock.days = d.staffClock.days || {};
    var changed = false;
    evs.forEach(function (e) {
      var day = String(e.day || '').slice(0, 10); if (!day || !e.staff) return;
      var rec = d.staffClock.days[day] = d.staffClock.days[day] || {}, r = rec[e.staff] = rec[e.staff] || {};
      if (r[e.kind]) return;
      r[e.kind] = e.at_time; r[e.kind + 'By'] = e.staff; r[e.kind + 'Method'] = e.method || 'cloud';
      if (e.lat != null) r[e.kind + 'Loc'] = { lat: e.lat, lng: e.lng, acc: e.accuracy_m, dist: e.distance_m };
      changed = true;
    });
    if (changed) { try { window.erpSave(); } catch (e) { /* ignore */ } rerenderIf(['staff-clockin', 'live-class-monitor', 'dashboard', 'home']); }
  }

  /* ═════════════════════════ FILES: photos, logos, signatures, documents ═════════════════════════
     Large uploads live inside the school record as data URLs. On the way to Supabase each one is replaced by a
     reference ("abo-file:<sha256>") and stored once in abo_files (in parts), so a save no longer re-sends every
     picture. On the way back the references are swapped for the real files (cached on the device). */
  var FILE_MIN = 12000, PART = 400000, REF = 'abo-file:';
  function sha256hex(str) { return crypto.subtle.digest('SHA-256', new TextEncoder().encode(str)).then(function (h) { return Array.prototype.map.call(new Uint8Array(h), function (x) { return (x < 16 ? '0' : '') + x.toString(16); }).join(''); }); }
  function isBig(x) { return typeof x === 'string' && x.length >= FILE_MIN && x.slice(0, 5) === 'data:'; }
  function isRef(x) { return typeof x === 'string' && x.length < 80 && /^abo-file:[a-f0-9]{40,64}$/.test(x); }
  function collect(x, test, out) {
    if (typeof x === 'string') { if (test(x)) out.push(x); }
    else if (Array.isArray(x)) { for (var i = 0; i < x.length; i++) collect(x[i], test, out); }
    else if (x && typeof x === 'object') { for (var k in x) if (Object.prototype.hasOwnProperty.call(x, k)) collect(x[k], test, out); }
    return out;
  }
  function mapStrings(x, fn) {
    if (typeof x === 'string') return fn(x);
    if (Array.isArray(x)) return x.map(function (v) { return mapStrings(v, fn); });
    if (x && typeof x === 'object') { var o = {}; for (var k in x) if (Object.prototype.hasOwnProperty.call(x, k)) o[k] = mapStrings(x[k], fn); return o; }
    return x;
  }
  function knownFiles() { st.files = st.files || {}; return st.files; }
  function uploadFile(id, s) {
    var mime = (/^data:([^;,]+)/.exec(s) || [])[1] || 'application/octet-stream', n = Math.ceil(s.length / PART), chain = Promise.resolve();
    for (var i = 0; i < n; i++) (function (i) {
      chain = chain.then(function () { return rpc('abo_file_put', Object.assign(auth(), { p_id: id, p_mime: mime, p_size: s.length, p_part: i, p_parts: n, p_data: s.slice(i * PART, (i + 1) * PART) })); });
    })(i);
    return chain;
  }
  function externalize(data) {
    var bigs = collect(data, isBig, []); if (!bigs.length) return Promise.resolve(data);
    var uniq = bigs.filter(function (s, i) { return bigs.indexOf(s) === i; }), map = new Map(), known = knownFiles();
    return Promise.all(uniq.map(sha256hex)).then(function (ids) {
      uniq.forEach(function (s, i) { map.set(s, ids[i]); });
      var unknown = ids.filter(function (id) { return !known[id]; });
      return (unknown.length ? rpc('abo_file_has', Object.assign(auth(), { p_ids: unknown })).then(function (r) { (r.ids || []).forEach(function (id) { known[id] = 1; }); }) : Promise.resolve())
        .then(function () {
          return uniq.filter(function (s) { return !known[map.get(s)]; }).reduce(function (p, s) {
            return p.then(function () { var id = map.get(s); return uploadFile(id, s).then(function () { known[id] = 1; idb.set('file:' + id, s); }); });
          }, Promise.resolve());
        });
    }).then(function () { saveSt(); return mapStrings(data, function (x) { return isBig(x) ? REF + map.get(x) : x; }); });
  }
  function downloadFile(id) {
    return rpc('abo_file_get', Object.assign(auth(), { p_id: id, p_part: 0 })).then(function (first) {
      var parts = [first.data || ''], n = first.parts || 1, chain = Promise.resolve();
      for (var i = 1; i < n; i++) (function (i) { chain = chain.then(function () { return rpc('abo_file_get', Object.assign(auth(), { p_id: id, p_part: i })).then(function (r) { parts[i] = r.data || ''; }); }); })(i);
      return chain.then(function () {
        var s = parts.join('');
        return sha256hex(s).then(function (h) { if (h !== id) return null; knownFiles()[id] = 1; return idb.set('file:' + id, s).then(function () { return s; }); });
      });
    }, function (e) { if (e.kind === 'network') throw e; return null; });
  }
  function resolveFiles(data) {
    var refs = collect(data, isRef, []); if (!refs.length) return Promise.resolve(data);
    var ids = refs.map(function (r) { return r.slice(REF.length); }).filter(function (x, i, a) { return a.indexOf(x) === i; }), got = {};
    return ids.reduce(function (p, id) {
      return p.then(function () { return idb.get('file:' + id).then(function (s) { return s || downloadFile(id); }).then(function (s) { if (s) got[id] = s; }); });
    }, Promise.resolve()).then(function () { return mapStrings(data, function (x) { return isRef(x) && got[x.slice(REF.length)] ? got[x.slice(REF.length)] : x; }); });
  }

  /* ═════════════════════════ OTHER RECORDS: other schools, shared settings, preferences ═════════════════════════ */
  var PREF_RE = /^(aboThemeMode|aboWords|aboSidebarMini|aboRailHidden|aboBannerDismissed_.+)$/, FLAG_RE = /^abo_paid_.+$/;
  function isOwner() { var u = me(); return !!(u && u.role === 'owner'); }
  function lsKeys(re) { var out = []; try { for (var i = 0; i < window.localStorage.length; i++) { var k = window.localStorage.key(i); if (k && re.test(k)) out.push(k); } } catch (e) { /* ignore */ } return out.sort(); }
  function composite(re) { var o = {}; lsKeys(re).forEach(function (k) { o[k] = LS.get(k); }); return JSON.stringify(o); }
  function writeComposite(re, raw) { var o = {}; try { o = JSON.parse(raw) || {}; } catch (e) { return; } Object.keys(o).forEach(function (k) { if (re.test(k) && o[k] != null) LS.set(k, String(o[k])); }); }
  function realSchool(raw) { try { var d = JSON.parse(raw); return !!(d && (((d.students || []).length) || (d.schoolData && d.schoolData.name))); } catch (e) { return false; } }
  function schoolChan(lk) {
    return { remote: 'school:' + lk.slice('broadsheetData_'.length), label: 'School: ' + lk.slice('broadsheetData_'.length).replace(/_/g, ' '), read: function () { return LS.get(lk); }, push: true, skip: function (raw) { return !realSchool(raw); },
      write: function (raw) {
        writeLocal(lk, raw);
        if (lk === blobKey() && me()) {      // the school on screen changed on another device: reload it
          applying = true;
          quietly(function () { try { window.ABO && window.ABO.store && window.ABO.store.load ? window.ABO.store.load() : window.loadSchoolData(); } catch (e) { /* ignore */ } try { window.erpEnsure && window.erpEnsure(); } catch (e) { /* ignore */ } });
          try { var cur = current(); if (cur && window.ABO && window.ABO.go) window.ABO.go(cur); } catch (e) { /* ignore */ }
          setTimeout(function () { applying = false; baselineChanges(); }, 900);
        }
      } };
  }
  function channels() {
    var c = cfg(), out = [];
    out.push({ remote: 'shared:pricing', label: 'Shared settings (pricing, owner password hash)', read: function () { return LS.get('broadsheetData_pricing'); }, push: can(),
      write: function (raw) {
        LS.set('broadsheetData_pricing', raw);
        try { window.__aboPricing = (JSON.parse(raw) || {}).pricingData || {}; if (window.aboGlobalSet) { var __pd = window.aboGlobalGet('pricingData'); if (__pd !== undefined) window.aboGlobalSet('pricingData', Object.assign({}, __pd, window.__aboPricing)); } else (0, eval)('if (typeof pricingData !== "undefined") pricingData = Object.assign({}, pricingData, window.__aboPricing)'); } catch (e) { /* ignore */ } finally { delete window.__aboPricing; }
      } });
    out.push({ remote: 'shared:flags', label: 'Payment / activation flags', read: function () { return composite(FLAG_RE); }, write: function (raw) { writeComposite(FLAG_RE, raw); }, push: can() });
    if (me() && myId()) out.push({ remote: 'prefs:' + myId().replace(/[^A-Za-z0-9_.@ -]/g, '_'), label: 'Your preferences', read: function () { return composite(PREF_RE); }, write: function (raw) { writeComposite(PREF_RE, raw); }, push: true });
    if (isOwner()) lsKeys(/^broadsheetData_/).forEach(function (k) { if (k !== 'broadsheetData_pricing' && k !== c.key) out.push(schoolChan(k)); });
    return out;
  }
  function chanFor(key, chans) {
    for (var i = 0; i < chans.length; i++) if (chans[i].remote === key) return chans[i];
    if (/^school:/.test(key) && isOwner()) { var lk = 'broadsheetData_' + key.slice(7); if (lk !== cfg().key && lk !== 'broadsheetData_pricing') return schoolChan(lk); }
    return null;
  }
  function recBase(key) { return 'base:rec:' + cfg().school + ':' + key; }
  function receive(r, chans) {
    var ch = chanFor(r.key, chans); if (!ch || r.data == null) return Promise.resolve();
    st.rec = st.rec || {}; var rs = st.rec[r.key] || {}, raw = ch.read();
    var clean = raw == null || (rs.baseHash != null && hash(raw) === rs.baseHash);
    return resolveFiles(r.data).then(function (data) {
      if (clean) { ch.write(JSON.stringify(data)); st.rec[r.key] = { version: r.version, baseHash: hash(ch.read()) }; return idb.set(recBase(r.key), data); }
      return idb.get(recBase(r.key)).then(function (base) {
        var local = null; try { local = JSON.parse(raw); } catch (e) { /* ignore */ }
        ch.write(JSON.stringify(local ? merge3(base || {}, local, data) : data));
        st.rec[r.key] = { version: r.version, baseHash: 'merged:' + r.version };      // forces an upload of the merge
        return idb.set(recBase(r.key), data);
      });
    }).then(saveSt);
  }
  function send(ch) {
    if (!ch.push) return Promise.resolve();
    var raw = ch.read(); if (raw == null || (ch.skip && ch.skip(raw))) return Promise.resolve();
    st.rec = st.rec || {}; var rs = st.rec[ch.remote] || {};
    if (rs.baseHash === hash(raw)) return Promise.resolve();
    var data; try { data = JSON.parse(raw); } catch (e) { return Promise.resolve(); }
    return externalize(data).then(function (wire) {
      return rpc('abo_rec_push', Object.assign(auth(), { p_key: ch.remote, p_data: wire, p_base: rs.version || 0, p_by: (me() && (me().name || me().loginId)) || 'device', p_device: deviceLabel() }));
    }).then(function (res) { st.rec[ch.remote] = { version: res.version, baseHash: hash(raw) }; saveSt(); return idb.set(recBase(ch.remote), data); },
      function (e) { if (e.kind === 'conflict') { st.recAgain = true; return; } throw e; });
  }
  function syncRecords() {
    var chans = channels(), have = {}; st.rec = st.rec || {}; st.recAgain = false;
    chans.forEach(function (ch) { have[ch.remote] = st.rec[ch.remote] ? st.rec[ch.remote].version : -1; });
    if (isOwner()) Object.keys(st.rec).forEach(function (k) { if (!(k in have)) have[k] = st.rec[k].version; });
    var keys = isOwner() ? null : chans.map(function (ch) { return ch.remote; });   // the Owner also receives every school (new computer = full restore)
    return rpc('abo_rec_pull', Object.assign(auth(), { p_have: have, p_keys: keys })).then(function (res) {
      return (res.records || []).reduce(function (p, r) { return p.then(function () { return receive(r, chans); }); }, Promise.resolve());
    }).then(function () { return channels().reduce(function (p, ch) { return p.then(function () { return send(ch); }); }, Promise.resolve()); });
  }

  /* ═════════════════════════ ACTIVITY LOG: every sign-in, page, change and action ═════════════════════════
     The app's own audit list keeps only the last 100 entries. Here every activity is queued on the device (so
     nothing is lost offline) and uploaded to abo_activity, where it is kept. */
  var ACT_KEY = 'aboActivityQueue', ACT_MAX = 1500, actQ = LS.json(ACT_KEY, []) || [], actTimer = null, actFlushing = null;
  function saveQ() {
    if (actQ.length > ACT_MAX) { var drop = actQ.length - ACT_MAX, kept = []; actQ.forEach(function (e) { if (drop > 0 && e.kind === 'view') { drop--; return; } kept.push(e); }); actQ = kept.slice(-ACT_MAX); }
    LS.set(ACT_KEY, JSON.stringify(actQ));
  }
  function activity(kind, action, detail, who) {
    try {
      var u = who || me() || {}, sd = G('schoolData') || {};
      actQ.push({ id: Date.now().toString(36) + '-' + randHex(6), at: new Date().toISOString(), actor: (u.name || u.loginId || u.id || 'Not signed in') + (u.impersonatedBy ? ' (done by owner)' : ''), login_id: u.loginId || u.id || null,
        role: u.role || null, kind: kind, action: String(action || '').slice(0, 300), detail: detail || null, device: deviceLabel(), school: sd.name || '' });
      saveQ(); if (cfg()) { clearTimeout(actTimer); actTimer = setTimeout(function () { flushActivity().catch(function () {}); }, 4000); }
    } catch (e) { /* never break the app for logging */ }
  }
  function flushActivity() {
    if (!cfg() || !actQ.length) return Promise.resolve();
    if (actFlushing) return actFlushing;
    var batch = actQ.slice(0, 200);
    actFlushing = rpc('abo_activity_add', Object.assign(auth(), { p_events: batch })).then(function () {
      var done = {}; batch.forEach(function (e) { done[e.id] = 1; }); actQ = actQ.filter(function (e) { return !done[e.id]; }); saveQ(); actFlushing = null;
      if (actQ.length) return flushActivity();
    }, function (e) { actFlushing = null; throw e; });
    return actFlushing;
  }
  // what changed in a save, in words ("Calendar (+1), Finance › Income (+1)")
  var SEC = { students: 'Learners', subjects: 'Subjects', globalSettings: 'Class settings', userAccounts: 'User accounts', cbtExams: 'CBT exams', cbtSubmissions: 'CBT submissions',
    parentMessages: 'Parent messages', newsletters: 'Newsletters', appearanceData: 'Appearance', aiSettings: 'AI settings', schoolProfile: 'School profile', lessonNotes: 'Lesson notes',
    staffClock: 'Staff clock-in', finance: 'Finance', calendar: 'Calendar', attendance: 'Attendance', timetable: 'Timetable', staff: 'Staff', parents: 'Parents', classes: 'Classes',
    biometrics: 'Fingerprint devices', announcements: 'Announcements', messages: 'Messages', documents: 'Documents', resources: 'Learning resources', videos: 'Video lessons',
    liveClasses: 'Live classes', questionBank: 'Question bank', reportSettings: 'Report settings', bills: 'School bills', birthdays: 'Birthday wishes', periods_slots: 'Timetable periods',
    classSubjects: 'Class subjects', teacherSubjects: 'Teacher subjects', income: 'Income', expenses: 'Expenses', payments: 'Payments', imprest: 'Imprest', inventory: 'Inventory', sales: 'Sales', outstanding: 'Outstanding fees', accounts: 'Chart of accounts' };
  var SKIP_SEC = /^(erp\.(seeded|lastSaved|updatedAt|_.*|version|migrations?))$/;
  function human(k) { return SEC[k] || String(k).replace(/[_-]+/g, ' ').replace(/([a-z])([A-Z])/g, '$1 $2').replace(/^./, function (c) { return c.toUpperCase(); }); }
  function summ(v) { var j = JSON.stringify(v === undefined ? null : v); return { h: hash(j), n: Array.isArray(v) ? v.length : null }; }
  function sections(obj) {
    var out = {}; if (!obj) return out;
    ['students', 'subjects', 'globalSettings', 'cbtExams', 'cbtSubmissions', 'parentMessages', 'newsletters', 'appearanceData', 'aiSettings'].forEach(function (k) { if (k in obj) out[k] = summ(obj[k]); });
    if (obj.userAccounts) { var ua = {}; Object.keys(obj.userAccounts).forEach(function (k) { if (k !== 'audit') ua[k] = obj.userAccounts[k]; }); out.userAccounts = summ(ua); }
    var sd = obj.schoolData || {}, prof = {}; Object.keys(sd).forEach(function (k) { if (k !== 'erp') prof[k] = sd[k]; }); out.schoolProfile = summ(prof);
    var erp = sd.erp || {};
    Object.keys(erp).forEach(function (k) {
      var v = erp[k];
      if (v && typeof v === 'object' && !Array.isArray(v) && Object.keys(v).some(function (s) { return Array.isArray(v[s]); })) Object.keys(v).forEach(function (s) { out['erp.' + k + '.' + s] = summ(v[s]); });
      else if (!SKIP_SEC.test('erp.' + k)) out['erp.' + k] = summ(v);
    });
    return out;
  }
  function secLabel(k) { var p = k.split('.'); if (p[0] === 'erp') p.shift(); return p.map(human).join(' › '); }
  var lastSec = null, lastKey = null, changeTimer = null;
  function baselineChanges() { lastKey = blobKey(); try { lastSec = sections(JSON.parse(LS.get(lastKey) || 'null')); } catch (e) { lastSec = null; } }
  function noteChanges() {
    clearTimeout(changeTimer);
    changeTimer = setTimeout(function () {
      if (!me() || applying) return;
      var key = blobKey(), now; try { now = sections(JSON.parse(LS.get(key) || 'null')); } catch (e) { return; }
      // another school was opened: that is not a change, start comparing again
      if (!lastSec || key !== lastKey) { lastSec = now; lastKey = key; return; }
      var list = [];
      Object.keys(now).concat(Object.keys(lastSec)).filter(function (k, i, a) { return a.indexOf(k) === i; }).forEach(function (k) {
        var a = lastSec[k], b = now[k]; if (a && b && a.h === b.h) return;
        var d = a && b && a.n != null && b.n != null ? b.n - a.n : null;
        list.push(secLabel(k) + (!a ? ' (new)' : !b ? ' (removed)' : d ? ' (' + (d > 0 ? '+' : '−') + Math.abs(d) + ')' : ' (edited)'));
      });
      lastSec = now;
      if (list.length) activity('change', 'Changed ' + list.slice(0, 4).join(', ') + (list.length > 4 ? ' and ' + (list.length - 4) + ' more' : ''), { sections: list });
    }, 2500);
  }

  /* ───────────────────────── hooks into the app ───────────────────────── */
  var baseSave = window.saveSchoolData;
  if (typeof baseSave === 'function') {
    window.saveSchoolData = function () { var r = baseSave.apply(this, arguments); try { markIfChanged(); if (!applying) noteChanges(); if (active() && !onPrimary() && !applying) schedulePush(2000); } catch (e) { /* ignore */ } return r; };
  }
  var baseEnter = window.enterApp;
  if (typeof baseEnter === 'function') {
    window.enterApp = function () {
      var r = baseEnter.apply(this, arguments);
      var fresh = window.__aboLoginAt && Date.now() - window.__aboLoginAt < 8000, how = window.__aboSigninMethod;
      window.__aboLoginAt = 0; window.__aboSigninMethod = null;
      activity('signin', fresh ? (how === 'fingerprint' ? 'Signed in with fingerprint' : 'Signed in with Login ID') : 'Opened the app (saved session)');
      setTimeout(baselineChanges, 1500);
      setTimeout(function () { if (active()) { if (st.baseHash == null) st.dirty = true; sync({ force: true }); } paintIndicator(); }, 600);
      return r;
    };
  }
  var baseLogin = window.loginUser;
  if (typeof baseLogin === 'function') {
    window.loginUser = function () {
      var tried = val('loginId'); window.__aboLoginAt = Date.now();
      var r = baseLogin.apply(this, arguments);
      setTimeout(function () { if (!me() && tried) activity('security', 'Failed sign-in attempt', { loginId: tried.slice(0, 60) }, { name: 'Not signed in' }); }, 900);
      return r;
    };
  }
  var baseLogout = window.logoutUser;
  if (typeof baseLogout === 'function') {
    window.logoutUser = function () { activity('signout', 'Signed out'); try { flushActivity().catch(function () {}); } catch (e) { /* ignore */ } lastSec = null; return baseLogout.apply(this, arguments); };
  }
  var baseAudit = window.logAudit;
  if (typeof baseAudit === 'function') {
    window.logAudit = function (action, meta) {
      var r = baseAudit.apply(this, arguments);
      var a = String(action || '');
      if (!/^(Signed in|Logged in|Secure login)/i.test(a)) activity(/clock-(in|out)/i.test(a) ? 'clock' : /fingerprint|password|approval|disabled|access|role/i.test(a) ? 'security' : 'action', a, meta && typeof meta === 'object' && Object.keys(meta).length ? meta : null);
      return r;
    };
  }
  var errCount = 0;
  window.addEventListener('error', function (e) { if (errCount++ < 10) activity('error', 'App error: ' + String(e.message || 'unknown').slice(0, 200), { source: String(e.filename || '').slice(-60), line: e.lineno || null }); });
  setInterval(function () { if (active() && document.visibilityState !== 'hidden') sync(); else paintIndicator(); }, 30000);
  window.addEventListener('online', function () { if (active()) sync(); });
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible' && active()) sync(); });

  /* top-bar indicator */
  function paintIndicator() {
    var bar = document.querySelector('.abo-topbar-actions, .abo-topbar-right, .abo-topbar'); if (!bar) return;
    var el = document.getElementById('proCloudDot');
    if (!cfg() || !me()) { if (el) el.remove(); return; }
    if (!el) { el = document.createElement('button'); el.id = 'proCloudDot'; el.className = 'pro-cloud-dot'; el.type = 'button'; el.onclick = function () { try { window.ABO.go('cloud-sync'); } catch (e) { /* ignore */ } }; var bell = bar.querySelector('.abo-icon-btn'); if (bell && bell.parentNode === bar) bar.insertBefore(el, bell); else bar.appendChild(el); }
    var s = !active() ? 'off' : status === 'offline' ? 'offline' : status === 'error' ? 'error' : (st.dirty || st.pending.length) ? 'pending' : status === 'syncing' ? 'syncing' : 'ok';
    var label = { off: 'Cloud: not signed in', offline: 'Cloud: offline — saved on this device', error: 'Cloud: needs attention', pending: 'Cloud: sending changes…', syncing: 'Cloud: syncing…', ok: 'Cloud: up to date' }[s];
    el.setAttribute('data-state', s); el.title = label; el.setAttribute('aria-label', label); el.innerHTML = '<i></i><span>' + (s === 'ok' ? 'Synced' : s === 'offline' ? 'Offline' : s === 'error' ? 'Cloud' : s === 'off' ? 'Cloud' : 'Syncing') + '</span>';
  }

  /* ═════════════════════════ BIOMETRICS (WebAuthn) ═════════════════════════ */
  function bioWhyNot() {
    if (!window.PublicKeyCredential || !navigator.credentials) return 'This browser does not support fingerprint or face sign-in. Use an up-to-date Chrome, Edge or Safari.';
    if (location.protocol === 'file:' || window.origin === 'null' || !window.isSecureContext)
      return 'Fingerprint and face only work when the app is opened from its web address (https://…), for example your Netlify site — not when the file is opened from the phone’s storage or inside a preview.';
    return '';
  }
  function bioStore() { var d = D(); d.biometrics = d.biometrics || {}; return d.biometrics; }
  function devMap() { return LS.json(BIO_DEV_KEY, {}) || {}; }
  function setDevMap(m) { LS.set(BIO_DEV_KEY, JSON.stringify(m)); }
  function credsFor(id) { return (bioStore()[id] || []).filter(function (c) { return !c.revoked; }); }
  function onThisDevice(id) { var mine = devMap()[id] || []; return credsFor(id).filter(function (c) { return mine.indexOf(c.id) >= 0; }); }
  function derToRaw(der) {
    der = new Uint8Array(der); var i = 2; if (der[1] & 0x80) i = 2 + (der[1] & 0x7f);
    function int() { if (der[i] !== 0x02) throw new Error('bad signature'); var len = der[i + 1], v = der.slice(i + 2, i + 2 + len); i += 2 + len; while (v.length > 32 && v[0] === 0) v = v.slice(1); var o = new Uint8Array(32); o.set(v, 32 - v.length); return o; }
    var r = int(), s = int(), out = new Uint8Array(64); out.set(r, 0); out.set(s, 32); return out;
  }
  function sha(buf) { return crypto.subtle.digest('SHA-256', buf).then(function (h) { return new Uint8Array(h); }); }
  function cat(a, b) { var o = new Uint8Array(a.length + b.length); o.set(a, 0); o.set(b, a.length); return o; }
  function verifyAssertion(cred, stored, challenge) {
    var resp = cred.response, cdj = new Uint8Array(resp.clientDataJSON), ad = new Uint8Array(resp.authenticatorData), sig = new Uint8Array(resp.signature), cd;
    try { cd = JSON.parse(new TextDecoder().decode(cdj)); } catch (e) { return Promise.resolve('unreadable response'); }
    if (cd.type !== 'webauthn.get') return Promise.resolve('wrong response type');
    if (cd.challenge !== b64u(challenge)) return Promise.resolve('challenge mismatch');
    if (cd.origin !== location.origin) return Promise.resolve('wrong website');
    if (!(ad[32] & 0x01)) return Promise.resolve('no user presence');
    if (!(ad[32] & 0x04)) return Promise.resolve('the phone did not verify your fingerprint, face or PIN');
    return sha(new TextEncoder().encode(stored.rp || location.hostname)).then(function (rph) {
      for (var i = 0; i < 32; i++) if (rph[i] !== ad[i]) return 'registered for a different website';
      return sha(cdj).then(function (ch) {
        var data = cat(ad, ch), pk = unb64u(stored.pk), alg = stored.alg;
        var imp = alg === -7 ? crypto.subtle.importKey('spki', pk, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']).then(function (k) { return crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, k, derToRaw(sig), data); })
          : alg === -257 ? crypto.subtle.importKey('spki', pk, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['verify']).then(function (k) { return crypto.subtle.verify('RSASSA-PKCS1-v1_5', k, sig, data); })
            : alg === -8 ? crypto.subtle.importKey('spki', pk, { name: 'Ed25519' }, false, ['verify']).then(function (k) { return crypto.subtle.verify('Ed25519', k, sig, data); })
              : Promise.resolve(false);
        return imp.then(function (ok) { return ok ? '' : 'signature check failed'; });
      });
    });
  }
  var BIO = {
    whyNot: bioWhyNot,
    supported: function () { return !bioWhyNot(); },
    platform: function () { if (!BIO.supported()) return Promise.resolve(false); try { return PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable(); } catch (e) { return Promise.resolve(false); } },
    credsFor: credsFor, onThisDevice: onThisDevice,
    activated: function (id) { return onThisDevice(id || myId()).length > 0; },
    enroll: function (id, displayName) {
      id = id || myId(); var why = bioWhyNot(); if (why) return Promise.resolve({ ok: false, message: why });
      if (!id) return Promise.resolve({ ok: false, message: 'Sign in first.' });
      var userId = new Uint8Array(16); crypto.getRandomValues(userId);
      return navigator.credentials.create({ publicKey: {
        challenge: crypto.getRandomValues(new Uint8Array(32)),
        rp: { name: 'A.B.O. School Manager', id: location.hostname },
        user: { id: userId, name: id, displayName: displayName || id },
        pubKeyCredParams: [{ type: 'public-key', alg: -7 }, { type: 'public-key', alg: -8 }, { type: 'public-key', alg: -257 }],
        authenticatorSelection: { authenticatorAttachment: 'platform', userVerification: 'required', residentKey: 'preferred' },
        excludeCredentials: onThisDevice(id).map(function (c) { return { type: 'public-key', id: unb64u(c.id) }; }),
        attestation: 'none', timeout: 60000
      } }).then(function (cred) {
        var r = cred.response, pk = r.getPublicKey ? r.getPublicKey() : null, alg = r.getPublicKeyAlgorithm ? r.getPublicKeyAlgorithm() : null;
        if (!pk || alg == null) return { ok: false, message: 'This browser is too old for fingerprint clock-in. Update Chrome, Edge or Safari and try again.' };
        var ad = r.getAuthenticatorData ? new Uint8Array(r.getAuthenticatorData()) : null;
        if (ad && !(ad[32] & 0x04)) return { ok: false, message: 'The phone did not confirm a fingerprint, face or PIN. Set up a screen lock with fingerprint/face first.' };
        var rec = { id: b64u(cred.rawId), pk: b64u(pk), alg: alg, rp: location.hostname, label: deviceLabel(), created: new Date().toISOString() };
        var s = bioStore(); s[id] = (s[id] || []).concat([rec]); window.erpSave();
        var m = devMap(); m[id] = (m[id] || []).concat([rec.id]); setDevMap(m);
        try { window.logAudit && window.logAudit('Fingerprint/face activated on ' + rec.label + ' for ' + id); } catch (e) { /* ignore */ }
        return { ok: true, cred: rec };
      }, function (e) { return { ok: false, message: e && e.name === 'NotAllowedError' ? 'Fingerprint set-up was cancelled.' : e && e.name === 'InvalidStateError' ? 'This phone is already activated for you.' : 'Could not set up fingerprint: ' + (e && e.message || e) }; });
    },
    // ask the phone for the fingerprint/face of `id` and check the signature against the saved key
    verify: function (id, store) {
      id = id || myId(); var why = bioWhyNot(); if (why) return Promise.resolve({ ok: false, message: why });
      var list = (store || bioStore())[id] || []; list = list.filter(function (c) { return !c.revoked; });
      var mine = devMap()[id] || [], usable = list.filter(function (c) { return mine.indexOf(c.id) >= 0; });
      if (!usable.length) return Promise.resolve({ ok: false, needsActivation: true, message: 'This phone is not activated for your fingerprint yet.' });
      var challenge = crypto.getRandomValues(new Uint8Array(32));
      return navigator.credentials.get({ publicKey: { challenge: challenge, rpId: location.hostname, userVerification: 'required', timeout: 60000,
        allowCredentials: usable.map(function (c) { return { type: 'public-key', id: unb64u(c.id) }; }) } })
        .then(function (cred) {
          var used = b64u(cred.rawId), stored = usable.find(function (c) { return c.id === used; });
          if (!stored) return { ok: false, message: 'Unknown fingerprint key.' };
          return verifyAssertion(cred, stored, challenge).then(function (err) {
            if (err) return { ok: false, message: 'Fingerprint check failed (' + err + ').' };
            stored.lastUsed = new Date().toISOString();
            return { ok: true, credId: used, label: stored.label };
          });
        }, function (e) { return { ok: false, message: e && e.name === 'NotAllowedError' ? 'Fingerprint was cancelled or not recognised.' : 'Fingerprint error: ' + (e && e.message || e) }; });
    },
    revoke: function (id, credId) {
      var s = bioStore(); (s[id] || []).forEach(function (c) { if (c.id === credId) { c.revoked = true; c.revokedAt = new Date().toISOString(); c.revokedBy = (me() && me().name) || ''; } });
      window.erpSave();
    },
    // sign-in screen: find which account this phone's fingerprint belongs to, verify, then sign in
    signIn: function () {
      var why = bioWhyNot(); if (why) { loginMsg(why); return Promise.resolve(false); }
      var m = devMap(), stores = {};
      for (var i = 0; i < window.localStorage.length; i++) {
        var k = window.localStorage.key(i); if (!k || k.indexOf('broadsheetData_') !== 0 || k === 'broadsheetData_pricing') continue;
        try { var b = JSON.parse(LS.get(k)); var bs = b && b.schoolData && b.schoolData.erp && b.schoolData.erp.biometrics; if (bs) Object.keys(bs).forEach(function (id) { stores[id] = (stores[id] || []).concat(bs[id]); }); } catch (e) { /* ignore */ }
      }
      var ids = Object.keys(m).filter(function (id) { return (stores[id] || []).some(function (c) { return !c.revoked && m[id].indexOf(c.id) >= 0; }); });
      if (!ids.length) { loginMsg('No fingerprint is activated on this phone yet. Sign in with your Login ID, then activate it in Staff Clock-in.'); return Promise.resolve(false); }
      var all = []; ids.forEach(function (id) { stores[id].forEach(function (c) { if (!c.revoked && m[id].indexOf(c.id) >= 0) all.push({ id: id, c: c }); }); });
      var challenge = crypto.getRandomValues(new Uint8Array(32));
      return navigator.credentials.get({ publicKey: { challenge: challenge, rpId: location.hostname, userVerification: 'required', timeout: 60000,
        allowCredentials: all.map(function (x) { return { type: 'public-key', id: unb64u(x.c.id) }; }) } })
        .then(function (cred) {
          var used = b64u(cred.rawId), hit = all.find(function (x) { return x.c.id === used; });
          if (!hit) { loginMsg('Unknown fingerprint key.'); return false; }
          return verifyAssertion(cred, hit.c, challenge).then(function (err) {
            if (err) { loginMsg('Fingerprint check failed (' + err + ').'); return false; }
            var user = null; try { user = window.findUserByLoginId(hit.id); } catch (e) { /* ignore */ }
            if (!user) { loginMsg('The account for this fingerprint no longer exists.'); return false; }
            var r = document.getElementById('loginRole'), li = document.getElementById('loginId');
            if (r) { if (![].some.call(r.options, function (o) { return o.value === user.role; })) { var o = document.createElement('option'); o.value = user.role; o.textContent = user.role; r.appendChild(o); } r.value = user.role; }
            if (li) li.value = hit.id;
            window.__aboSigninMethod = 'fingerprint';
            window.loginUser();
            return true;
          });
        }, function (e) { loginMsg(e && e.name === 'NotAllowedError' ? 'Fingerprint was cancelled or not recognised.' : 'Fingerprint error: ' + (e && e.message || e)); return false; });
    }
  };

  /* ═════════════════════════ SIGN-IN SCREEN: fingerprint + connect this device ═════════════════════════ */
  function loginMsg(text, ok) {
    var el = document.getElementById('proLoginMsg'); if (!el) return toast(text);
    el.textContent = text; el.className = 'pro-login-msg' + (ok ? ' ok' : ''); el.hidden = !text;
  }
  function decodeLink(code) {
    code = String(code || '').trim().replace(/\s+/g, '');
    var m = /ABO1\.([A-Za-z0-9_-]+)/.exec(code); if (!m) return null;
    try { var o = JSON.parse(b64uutf8(m[1])); return o && o.u && o.k && o.s && o.x ? { url: o.u, anon: o.k, school: o.s, secret: o.x, name: o.n || '' } : null; } catch (e) { return null; }
  }
  function encodeLink(c) { return 'ABO1.' + utf8b64u(JSON.stringify({ u: c.url, k: c.anon, s: c.school, x: c.secret, n: c.name || '' })); }
  function setupLogin() {
    var btn = document.querySelector('#loginScreen .login-btn'); if (!btn || document.getElementById('proLoginExtra')) return;
    var box = document.createElement('div'); box.id = 'proLoginExtra'; box.className = 'pro-login-extra';
    box.innerHTML =
      '<button type="button" class="btn pro-bio-btn" id="proBioLogin" hidden>' + ico('fingerprint') + '<span>Sign in with fingerprint</span></button>' +
      '<p class="pro-login-msg" id="proLoginMsg" role="status" hidden></p>' +
      '<button type="button" class="pro-link-btn" id="proLinkOpen">' + ico('cloud') + '<span>' + (cfg() ? 'Linked to ' + E(cfg().name || cfg().school) + ' — refresh school data' : 'Connect this phone to your school') + '</span></button>' +
      '<div class="pro-link-form" id="proLinkForm" hidden><label for="proLinkCode">Device link code from the school office</label>' +
      '<textarea id="proLinkCode" rows="3" placeholder="ABO1.…" autocomplete="off" spellcheck="false"></textarea>' +
      '<div class="pro-link-acts"><button type="button" class="btn" id="proLinkCancel">Cancel</button><button type="button" class="btn btn-primary" id="proLinkGo">Connect</button></div></div>';
    btn.parentNode.insertBefore(box, btn.nextSibling);
    var bio = document.getElementById('proBioLogin');
    var has = Object.keys(devMap()).some(function (k) { return (devMap()[k] || []).length; });
    if (has && BIO.supported()) bio.hidden = false;
    bio.onclick = function () { loginMsg(''); BIO.signIn(); };
    document.getElementById('proLinkOpen').onclick = function () {
      var c = cfg();
      if (c) { loginMsg('Downloading the latest school data…', true); linkWith(c); return; }
      var f = document.getElementById('proLinkForm'); f.hidden = !f.hidden; if (!f.hidden) document.getElementById('proLinkCode').focus();
    };
    document.getElementById('proLinkCancel').onclick = function () { document.getElementById('proLinkForm').hidden = true; };
    // opened from a "tap to connect" link (…/#connect=ABO1…): connect straight away
    var hm = /[#&]connect=(ABO1\.[A-Za-z0-9_-]+)/.exec(location.hash || '');
    if (hm) {
      try { history.replaceState(null, '', location.pathname + location.search); } catch (e) { /* ignore */ }
      var lc = decodeLink(hm[1]);
      if (lc) { document.getElementById('proLinkForm').hidden = false; document.getElementById('proLinkCode').value = hm[1]; loginMsg('Connecting this phone to ' + (lc.name || 'your school') + '…', true); setTimeout(function () { linkWith(lc); }, 300); }
      else loginMsg('That connect link is not complete. Ask the school office to send it again.');
    }
    document.getElementById('proLinkGo').onclick = function () {
      var c = decodeLink(val('proLinkCode'));
      if (!c) { loginMsg('That code is not valid. Copy the whole code that starts with ABO1.'); return; }
      loginMsg('Connecting…', true); linkWith(c);
    };
  }
  function linkWith(c) {
    return rpc('abo_pull', Object.assign(auth(c), { p_have: -1 }), c).then(function (res) {
      if (!res.data) { loginMsg('Connected, but the school has not uploaded its data yet. Ask the Owner to open Cloud Sync and press “Sync now”.'); return false; }
      var key = HOME;
      try { var sel = LS.get('ownerSelectedSchool'); if (sel) key = 'broadsheetData_' + sel.replace(/[^a-z0-9]/gi, '_'); } catch (e) { /* ignore */ }
      setCfg({ url: c.url, anon: c.anon, school: c.school, secret: c.secret, name: c.name || (res.data.schoolData && res.data.schoolData.name) || c.school, key: key, linkedAt: new Date().toISOString() });
      st = { pending: st.pending || [] };
      loginMsg('Downloading the school and its files…', true);
      return resolveFiles(res.data).then(function (data) { res.data = data; return res; });
    }).then(function (res) {
      if (!res) return false;
      var key = cfg().key;
      writeLocal(key, JSON.stringify(res.data));
      // bring the school's shared settings too (they include the owner password record, as a hash only)
      try { if (res.data.pricingData) { var cur = JSON.parse(LS.get('broadsheetData_pricing') || '{}'); cur.pricingData = Object.assign({}, cur.pricingData || {}, res.data.pricingData); LS.set('broadsheetData_pricing', JSON.stringify(cur)); } } catch (e) { /* ignore */ }
      st = { version: res.version, baseHash: hash(JSON.stringify(res.data)), dirty: false, pending: st.pending || [], lastSync: new Date().toISOString() }; saveSt();
      activity('sync', 'Phone linked to the school cloud', { school: c.school }, { name: 'Not signed in' });
      return idb.set('base:' + c.school, res.data).then(function () {
        loginMsg('Connected to ' + ((res.data.schoolData && res.data.schoolData.name) || c.school) + '. Reloading…', true);
        setTimeout(function () { location.reload(); }, 700);
        return true;
      });
    }, function (e) { loginMsg(e.message); return false; });
  }

  /* ═════════════════════════ CLOUD SYNC SCREEN ═════════════════════════ */
  var UI = { showSecret: false, draft: null };
  function draft() {
    if (!UI.draft) { var sd = G('schoolData') || {}; UI.draft = { url: DEFAULT_PROJECT.url, anon: DEFAULT_PROJECT.key, school: slug(sd.name) || ('school-' + randHex(3)), secret: newSecret() }; }
    return UI.draft;
  }
  function cloudView() {
    var c = cfg(), head = can();
    if (!head) return window.erpWrap('cloud-sync', '<div class="erp-empty">Only the Owner or School Admin can manage Cloud Sync.</div>');
    return window.erpWrap('cloud-sync', c ? connectedView(c) : setupView());
  }
  function connectedView(c) {
    var on = true, stTone = status === 'error' ? 'rose' : status === 'offline' ? 'gold' : 'green';
    var stText = !on ? 'Paused — another school is selected' : status === 'error' ? 'Needs attention' : status === 'offline' ? 'Offline — will send when online' : (st.dirty || st.pending.length) ? 'Sending changes…' : status === 'syncing' ? 'Syncing…' : 'Up to date';
    var rows = [
      ['Supabase project', E(c.url.replace(/^https?:\/\//, ''))],
      ['School ID', '<code>' + E(c.school) + '</code>'],
      ['Last synced', E(ago(st.lastSync))],
      ['Cloud version', E(st.version == null ? '—' : st.version)],
      ['Changes waiting', st.dirty ? badge('Yes', 'gold') : badge('None', 'green')],
      ['Clock-ins waiting', st.pending.length ? badge(st.pending.length, 'gold') : badge('None', 'green')]
    ].map(function (r) { return '<div class="pro-kv"><span>' + r[0] + '</span><b>' + r[1] + '</b></div>'; }).join('');
    var recent = (st.recent || []).slice(-10).reverse().map(function (e) {
      return '<tr><td>' + E(String(e.day || '').slice(0, 10)) + '</td><td><b>' + E(e.staff) + '</b></td><td>' + (e.kind === 'in' ? 'In' : 'Out') + ' ' + E(e.at_time) + '</td><td>' + E(e.method || '—') + '</td><td class="num">' + (e.distance_m != null ? Math.round(e.distance_m) + ' m' : '—') + '</td><td>' + E(e.device || '') + '</td></tr>';
    }).join('');
    return '<div class="pro-cloud-head"><div><small>Cloud Sync · Supabase</small><b>' + E(c.name || c.school) + '</b>' + badge(stText, stTone) + '</div>' +
        '<div class="pro-wrap"><button class="erp-btn primary" onclick="proCloud.syncNow()">' + ico('refresh') + 'Sync now</button><button class="erp-btn" onclick="proCloud.link()">' + ico('link') + 'Link a device</button></div></div>' +
      (lastErr || st.lastError ? '<div class="erp-note pro-warn">' + E((lastErr && lastErr.message) || st.lastError) + '</div>' : '') +
      '<div class="erp-grid-2">' +
        window.erpPanel('Connection', rows) +
        window.erpPanel('How it works', '<ul class="pro-list"><li>Every save on this device is sent to your Supabase project within a few seconds.</li><li>Other devices pick up changes every 30 seconds, when the app is reopened, or with <b>Sync now</b>.</li><li>No internet? Work normally — changes wait on the device and go out when the connection returns.</li><li>If two devices changed the school at the same time, the changes are merged.</li><li>Staff clock-ins are sent as separate records, so phones never overwrite each other.</li></ul>') +
      '</div>' +
      storedPanel() +
      window.erpPanel('Recent clock-ins from phones', recent ? '<div class="erp-table-wrap"><table class="erp-table"><thead><tr><th>Day</th><th>Staff</th><th>Time</th><th>Checked by</th><th class="num">From school</th><th>Device</th></tr></thead><tbody>' + recent + '</tbody></table></div>' : '<div class="erp-empty">No clock-ins from phones yet.</div>') +
      window.erpPanel('Danger zone', '<div class="pro-wrap"><button class="erp-btn ghost" onclick="proCloud.disconnect()">Disconnect this device</button><span class="pro-sub">Data stays on this device and in Supabase; this device just stops syncing.</span></div>' +
        '<div class="pro-wrap" style="margin-top:10px"><button class="erp-btn ghost" id="cbRekey" onclick="proCloud.rekey()">Change school secret</button><span class="pro-sub">Use this when a staff member leaves or a link code was shared by mistake. All other devices stop syncing until you link them again.</span></div>');
  }
  function setupView() {
    var d = draft();
    return '<div class="erp-note">Keep the school in your own <b>Supabase</b> project (free plan is enough for a school), so the Owner, the office and teachers’ phones share the same data — and nothing is lost if a phone is lost.</div>' +
      '<div class="erp-grid-2">' +
        window.erpPanel('1 · Prepare Supabase (one time)',
          '<ol class="pro-steps"><li>Create a project at <b>supabase.com</b> (any region; Europe West is closest to Nigeria).</li>' +
          '<li>Open <b>SQL Editor → New query</b>, paste the setup script and press <b>Run</b>.</li>' +
          '<li>Copy the <b>Project URL</b> (https://….supabase.co — shown under <b>Connect</b> at the top of the dashboard, or Project Settings → Data API) and the <b>Publishable key</b> (Project Settings → API Keys).</li></ol>' +
          '<div class="pro-wrap"><button class="erp-btn" onclick="proCloud.copySql()">' + ico('copy') + 'Copy setup script</button><button class="erp-btn ghost" onclick="proCloud.downloadSql()">' + ico('download') + 'Download .sql</button></div>') +
        window.erpPanel('2 · Connect this school',
          '<div class="erp-form-grid">' +
            field('Project URL', '<input class="erp-input" id="cbUrl" placeholder="https://abcdefgh.supabase.co" value="' + A(d.url) + '" autocomplete="off">', true) +
            field('Publishable key', '<textarea class="erp-textarea" id="cbAnon" rows="2" placeholder="sb_publishable_…" spellcheck="false">' + E(d.anon) + '</textarea>', true, 'From Project Settings → API Keys. Older projects: the “anon public” key also works. Never use the secret key.') +
            field('School ID', '<input class="erp-input" id="cbSchool" value="' + A(d.school) + '" autocomplete="off">', false, 'Lowercase letters, numbers and dashes.') +
            field('Invitation code (new schools only, if A.B.O. gave you one)', '<input class="erp-input" id="cbInvite" autocomplete="off" placeholder="leave empty if you were not given one">', false, 'Only needed the first time a school connects, when the cloud owner has switched invitations on.') +
            field('School secret', '<div class="pro-wrap"><input class="erp-input" id="cbSecret" type="' + (UI.showSecret ? 'text' : 'password') + '" value="' + A(d.secret) + '" autocomplete="off"><button class="erp-btn xs ghost" onclick="proCloud.toggleSecret()">' + (UI.showSecret ? 'Hide' : 'Show') + '</button></div>', false, 'Protects your data. Generated for you — keep it private.') +
          '</div><div class="pro-wrap" style="margin-top:12px"><button class="erp-btn primary" id="cbConnect" onclick="proCloud.connect()">' + ico('cloud') + 'Connect</button><span class="pro-sub" id="cbMsg" role="status"></span></div>') +
      '</div>' +
      '<div class="erp-note">Security: the tables are locked (Row Level Security on, no public access). The app can only use A.B.O. functions that check the school secret first. The publishable key is public by design; the school secret is what protects the school.</div>';
  }
  function cbMsg(t, bad) { var e = document.getElementById('cbMsg'); if (e) { e.textContent = t; e.style.color = bad ? '#b91c1c' : ''; } else toast(t); }
  window.proCloud = {
    toggleSecret: function () { var d = draft(); d.url = val('cbUrl'); d.anon = val('cbAnon'); d.school = val('cbSchool'); d.secret = val('cbSecret'); UI.showSecret = !UI.showSecret; rerenderIf(['cloud-sync']); },
    copySql: function () { copyText(SETUP_SQL, 'Setup script copied. Paste it in Supabase → SQL Editor and press Run.'); },
    downloadSql: function () { var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([SETUP_SQL], { type: 'text/plain' })); a.download = 'abo_supabase_setup.sql'; document.body.appendChild(a); a.click(); setTimeout(function () { a.remove(); }, 500); },
    connect: function () {
      var c = { url: val('cbUrl').replace(/\/+$/, ''), anon: val('cbAnon').replace(/\s+/g, ''), school: val('cbSchool').toLowerCase(), secret: val('cbSecret') };
      var d = draft(); Object.assign(d, c);
      if (!/^https?:\/\/[^\s/]+/.test(c.url)) return cbMsg('Enter the Project URL, e.g. https://abcdefgh.supabase.co', true);
      if (/^sb_secret_/.test(c.anon)) return cbMsg('That is the SECRET key — never put it in an app. Use the Publishable key (sb_publishable_…).', true);
      if (c.anon.length < 20) return cbMsg('Paste the Publishable key (sb_publishable_…) from Project Settings → API Keys.', true);
      if (!/^[a-z0-9][a-z0-9-]{2,62}$/.test(c.school)) return cbMsg('School ID: at least 3 lowercase letters, numbers or dashes.', true);
      if (c.secret.length < 12) return cbMsg('The school secret must be at least 12 characters.', true);
      var sd = G('schoolData') || {}; c.name = sd.name || c.school; c.key = blobKey();
      var b = document.getElementById('cbConnect'); if (b) b.disabled = true; cbMsg('Connecting…');
      var inv = val('cbInvite');
      rpc('abo_connect', Object.assign(auth(c), { p_name: c.name }, inv ? { p_invite: inv } : {}), c).then(function (res) {
        if (b) b.disabled = false;
        if (res.created || !res.version) {
          setCfg(Object.assign(c, { connectedAt: new Date().toISOString() }));
          st = { version: 0, dirty: true, baseHash: null, pending: [] }; saveSt(); UI.draft = null;
          toast('Connected. Uploading the school to Supabase…');
          activity('sync', 'Connected the school to Supabase', { school: c.school });
          return sync({ force: true }).then(function (ok) { if (ok) toast('This school is now saved in Supabase.'); rerenderIf(['cloud-sync']); });
        }
        // the cloud already holds this school: decide which copy wins
        window.erpModal('This school already exists in Supabase',
          '<p>Supabase already has data for <b>' + E(res.name || c.school) + '</b> (last saved ' + E(ago(res.updated_at)) + (res.updated_by ? ' by ' + E(res.updated_by) : '') + ').</p>' +
          '<ul class="pro-list"><li><b>Download</b> — use the cloud copy on this device (choose this for a new or second device).</li><li><b>Merge</b> — combine both; nothing is deleted.</li><li><b>Upload</b> — replace the cloud copy with this device’s data.</li></ul>',
          '<button class="erp-btn ghost" onclick="erpModalClose()">Cancel</button><button class="erp-btn" onclick="proCloud.first(\'upload\')">Upload</button><button class="erp-btn" onclick="proCloud.first(\'merge\')">Merge</button><button class="erp-btn primary" onclick="proCloud.first(\'download\')">Download</button>');
        UI.pendingCfg = c;
      }, function (e) { if (b) b.disabled = false; cbMsg(e.kind === 'secret' ? 'This School ID already exists in your Supabase project with a different secret. Use the original secret, or choose another School ID.' : e.message, true); });
    },
    first: function (how) {
      var c = UI.pendingCfg; if (!c) return; window.erpModalClose();
      setCfg(Object.assign(c, { connectedAt: new Date().toISOString() })); UI.draft = null; UI.pendingCfg = null;
      rpc('abo_pull', Object.assign(auth(c), { p_have: -1 }), c).then(function (res) {
        if (how === 'download') { st = { version: res.version, dirty: false, pending: [] }; saveSt(); return resolveFiles(res.data).then(function (d) { applyData(d, res.version, false); toast('Downloaded the school from Supabase.'); activity('sync', 'Restored the school from Supabase'); }); }
        else if (how === 'merge') { st = { version: res.version, dirty: true, pending: [] }; saveSt(); return idb.del('base:' + c.school).then(function () { return mergeWith(res); }); }
        else { return rpc('abo_push', Object.assign(auth(c), { p_data: JSON.parse(localRaw()), p_base: res.version, p_force: true, p_by: (me() && me().name) || 'owner', p_device: deviceLabel() }), c).then(function (r) { st = { version: r.version, dirty: false, baseHash: hash(localRaw()), pending: [] }; saveSt(); toast('Uploaded this device’s data to Supabase.'); }); }
      }).then(function () { setTimeout(function () { sync({ force: true }).then(function () { rerenderIf(['cloud-sync']); }); }, 1000); }, function (e) { toast(e.message); });
    },
    syncNow: function () { if (!active()) { toast(cfg() ? 'Sign in first.' : 'Cloud Sync is not set up.'); return Promise.resolve(false); } if (onPrimary()) st.dirty = st.dirty || hash(localRaw()) !== st.baseHash; return sync({ force: true }).then(function (ok) { toast(ok ? 'Synced with Supabase.' : (st.lastError || 'Sync failed.')); return ok; }); },
    link: function () {
      var c = cfg(); if (!c) return; var code = encodeLink(c);
      var site = (D().site || {}), addr = window.ABO_SITE_ADDRESS ? window.ABO_SITE_ADDRESS() : '';
      var tap = addr ? addr + '/#connect=' + code : '';
      var msg = tap ? 'Connect your phone to ' + (c.name || c.school) + ': tap this link, then sign in with your login code.\n\n' + tap
        : 'Connect your phone to ' + (c.name || c.school) + ' on A.B.O. School Manager: open the app, tap "Connect this phone to your school" and paste this code:\n\n' + code;
      window.erpModal('Link a device',
        '<p>On the teacher’s phone, open the app, tap <b>Connect this phone to your school</b> on the sign-in screen and paste this code. The phone downloads the school, then the teacher signs in with their own Login ID.</p>' +
        (tap ? '<p><b>Easiest:</b> send this link. The teacher taps it on their phone and the phone connects by itself.</p><textarea class="erp-textarea pro-code" id="cbTap" rows="3" readonly onclick="this.select()">' + E(tap) + '</textarea><p class="pro-sub">Or paste this code on the sign-in screen:</p>' : '<p class="pro-sub">Tip: set your <b>School Web Address</b> (Settings) to get a link teachers can just tap.</p>') +
        '<textarea class="erp-textarea pro-code" id="cbLink" rows="4" readonly onclick="this.select()">' + E(code) + '</textarea>' +
        '<div class="erp-note pro-warn">Anyone with this code can read and change the school’s data. Share it only with your own staff. To cut off old codes, use <b>Change school secret</b> (Cloud Sync › Danger zone).</div>',
        '<a class="erp-btn" target="_blank" rel="noopener" href="https://wa.me/?text=' + A(encodeURIComponent(msg)) + '">' + ico('whatsapp') + 'Send by WhatsApp</a><button class="erp-btn primary" onclick="proCloud.copyLink()">' + ico('copy') + 'Copy code</button>');
    },
    copyLink: function () { var c = cfg(); if (c) copyText(encodeLink(c), 'Device link code copied.'); },
    // 12 Oct 2026: new school secret — every old link code and every other linked device is cut off at once
    rekey: function () {
      var c = cfg(); if (!c) return Promise.resolve(false);
      if (!window.erpConfirm('Make a new school secret now?\n\nEvery other phone and computer linked to this school will stop syncing until you link it again with "Link a device". Old link codes stop working. This device keeps working.')) return Promise.resolve(false);
      var b = document.getElementById('cbRekey'); if (b) b.disabled = true;
      var ns = newSecret();
      return rpc('abo_rekey', { p_school: c.school, p_secret: c.secret, p_new_secret: ns }, c).then(function () {
        c.secret = ns; setCfg(c); UI.draft = null;
        activity('security', 'Changed the Cloud Sync school secret', { school: c.school });
        toast('New school secret saved. Link your other devices again with "Link a device".');
        rerenderIf(['cloud-sync']); return true;
      }, function (e) {
        if (b) b.disabled = false;
        toast(e.kind === 'setup' ? 'Run the newest setup script in Supabase first (SQL Editor → paste → Run), then try again.' : e.message);
        return false;
      });
    },
    disconnect: function () {
      if (!window.erpConfirm('Stop syncing this device with Supabase? Data stays on this device and in Supabase.')) return;
      var c = cfg(); setCfg(null); st = { pending: [] }; saveSt(); if (c) idb.del('base:' + c.school); setStatus('idle'); paintIndicator(); rerenderIf(['cloud-sync']); toast('This device no longer syncs.');
    },
    status: function () { return { configured: !!cfg(), active: active(), status: status, version: st.version, dirty: !!st.dirty, pending: st.pending.length, lastSync: st.lastSync, error: st.lastError }; },
    _merge3: merge3
  };
  function storedPanel() {
    var rec = st.rec || {}, schools = Object.keys(rec).filter(function (k) { return /^school:/.test(k); }).length;
    var files = Object.keys(st.files || {}).length;
    var row = function (what, where, state) { return '<tr><td><b>' + what + '</b></td><td>' + where + '</td><td>' + state + '</td></tr>'; };
    var ok = function (t) { return badge(t || 'In Supabase', 'green'); };
    return window.erpPanel('What is stored in Supabase', '<div class="erp-table-wrap"><table class="erp-table"><thead><tr><th>Data</th><th>Table</th><th>Status</th></tr></thead><tbody>' +
        row('This school: learners, results, finance, calendar, lesson notes, timetable, attendance, accounts…', 'abo_schools', st.dirty ? badge('Sending…', 'gold') : ok()) +
        (isOwner() ? row('Your other schools', 'abo_records', schools ? ok(schools + ' in Supabase') : badge('None yet', '')) : '') +
        row('Shared settings: pricing, owner password (hashed), payment flags', 'abo_records', rec['shared:pricing'] ? ok() : badge('Next sync', '')) +
        row('Each user’s preferences (dark mode, sidebar)', 'abo_records', ok('Per user')) +
        row('Photos, logos, signatures, documents', 'abo_files', ok(files + ' file' + (files === 1 ? '' : 's'))) +
        row('Staff clock-ins', 'abo_clock_events', st.pending.length ? badge(st.pending.length + ' waiting', 'gold') : ok()) +
        row('Activity log: sign-ins, pages opened, changes, actions, security events', 'abo_activity', actQ.length ? badge(actQ.length + ' waiting', 'gold') : ok()) +
      '</tbody></table></div><p class="pro-sub" style="margin:10px 0 0">Kept only on this device, on purpose: the sign-in session, this phone’s fingerprint key reference, failed-sign-in counters, and the Cloud Sync connection itself (it holds the school secret). The device also keeps a working copy of the school so it works offline.</p>');
  }

  /* ═════════════════════════ ACTIVITY LOG SCREEN ═════════════════════════ */
  function ymdLocal(d) { d = d || new Date(); return d.getFullYear() + '-' + (d.getMonth() < 9 ? '0' : '') + (d.getMonth() + 1) + '-' + (d.getDate() < 10 ? '0' : '') + d.getDate(); }
  var AL = { from: ymdLocal(), to: ymdLocal(), kind: '', actor: '', q: '', rows: [], total: 0, loading: false, loaded: false, err: '' };
  var KINDS = [['', 'All activity'], ['signin', 'Sign-ins'], ['signout', 'Sign-outs'], ['view', 'Pages opened'], ['change', 'Changes'], ['action', 'Actions'], ['clock', 'Clock-in'], ['security', 'Security'], ['sync', 'Cloud sync'], ['error', 'Errors']];
  var KIND_TONE = { signin: 'green', signout: '', view: '', change: 'sky', action: '', clock: 'green', security: 'rose', sync: 'gold', error: 'rose' };
  var KIND_ONE = { signin: 'Sign-in', signout: 'Sign-out', view: 'Page opened', change: 'Change', action: 'Action', clock: 'Clock-in', security: 'Security', sync: 'Cloud sync', error: 'Error' };
  function kindName(k) { return KIND_ONE[k] || k; }
  function actRow(e) {
    var t = new Date(e.at), when = t.toLocaleDateString('en-NG', { day: 'numeric', month: 'short' }) + ' · ' + t.toLocaleTimeString('en-NG', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    var det = e.detail && e.detail.sections ? e.detail.sections.join(', ') : '';
    return '<tr><td class="pro-nowrap">' + E(when) + '</td><td><b>' + E(e.actor || '—') + '</b><small class="pro-sub">' + E(e.role ? (e.role.charAt(0).toUpperCase() + e.role.slice(1)) : '') + (e.login_id ? ' · ' + E(e.login_id) : '') + '</small></td><td>' + badge(kindName(e.kind), KIND_TONE[e.kind] || '') +
      '</td><td>' + E(e.action) + (det && det.length > (e.action || '').length - 8 ? '<small class="pro-sub">' + E(det) + '</small>' : '') + '</td><td><small class="pro-sub">' + E(e.device || '') + '</small></td></tr>';
  }
  function activityView() {
    if (!can()) return window.erpWrap('activity-log', '<div class="erp-empty">Only the Owner or School Admin can view the activity log.</div>');
    var c = cfg();
    if (c && !AL.loaded && !AL.loading) setTimeout(function () { window.proAct.load(); }, 0);
    var opts = KINDS.map(function (k) { return '<option value="' + k[0] + '"' + (AL.kind === k[0] ? ' selected' : '') + '>' + E(k[1]) + '</option>'; }).join('');
    var rows = c ? AL.rows : actQ.slice().reverse().slice(0, 200);
    return window.erpWrap('activity-log',
      (!c ? '<div class="erp-note pro-warn">Cloud Sync is not connected, so only this device’s recent activity is shown. Connect Supabase (System → Cloud Sync) to keep the full history of every device.</div>' : '') +
      window.erpStats([{ label: c ? 'Matching activities' : 'On this device', value: c ? AL.total : actQ.length }, { label: 'Waiting to upload', value: actQ.length, color: actQ.length ? '#b45309' : '' }]) +
      (c ? '<div class="erp-toolbar pro-wrap">' +
        '<input class="erp-input pro-w" type="date" id="alFrom" value="' + A(AL.from) + '" aria-label="From">' +
        '<input class="erp-input pro-w" type="date" id="alTo" value="' + A(AL.to) + '" aria-label="To">' +
        '<select class="erp-select pro-w" id="alKind" aria-label="Type">' + opts + '</select>' +
        '<input class="erp-input pro-w" id="alActor" placeholder="Person or Login ID" value="' + A(AL.actor) + '">' +
        '<input class="erp-input pro-w" id="alQ" placeholder="Search activity" value="' + A(AL.q) + '" onkeydown="if(event.key===\'Enter\')proAct.apply()">' +
        '<button class="erp-btn primary" onclick="proAct.apply()">Show</button><div class="grow"></div>' +
        '<button class="erp-btn ghost" onclick="proAct.csv()">' + ico('download') + 'CSV</button></div>' : '') +
      (AL.err ? '<div class="erp-note pro-warn">' + E(AL.err) + '</div>' : '') +
      '<div class="erp-panel"><div class="erp-panel-b" style="padding:0"><div class="erp-table-wrap"><table class="erp-table" id="alTable"><thead><tr><th>Time</th><th>Person</th><th>Type</th><th>Activity</th><th>Device</th></tr></thead><tbody>' +
        (AL.loading && !rows.length ? '<tr><td colspan="5"><div class="erp-empty">Loading…</div></td></tr>' : rows.length ? rows.map(actRow).join('') : '<tr><td colspan="5"><div class="erp-empty">No activity for this filter.</div></td></tr>') +
      '</tbody></table></div></div></div>' +
      (c && AL.rows.length < AL.total ? '<div class="pro-wrap" style="justify-content:center;margin:12px 0"><button class="erp-btn" onclick="proAct.more()">Load more (' + (AL.total - AL.rows.length) + ' left)</button></div>' : '') +
      '<div class="erp-note">Every sign-in, page opened, change, clock-in and security event from every linked device is kept in Supabase (table <code>abo_activity</code>). Activity done offline is uploaded when the device is back online.</div>');
  }
  function dayStart(s) { var p = s.split('-'); return new Date(+p[0], +p[1] - 1, +p[2], 0, 0, 0).toISOString(); }
  function dayEnd(s) { var p = s.split('-'); return new Date(+p[0], +p[1] - 1, +p[2], 23, 59, 59, 999).toISOString(); }
  window.proAct = {
    apply: function () { AL.from = val('alFrom') || AL.from; AL.to = val('alTo') || AL.to; AL.kind = val('alKind'); AL.actor = val('alActor'); AL.q = val('alQ'); AL.rows = []; AL.total = 0; return window.proAct.load(); },
    load: function (more) {
      if (!cfg()) return Promise.resolve();
      AL.loading = true; AL.err = '';
      var before = more && AL.rows.length ? AL.rows[AL.rows.length - 1].id : null;
      return flushActivity().catch(function () {}).then(function () {
        return rpc('abo_activity_list', Object.assign(auth(), { p_from: dayStart(AL.from), p_to: dayEnd(AL.to), p_kind: AL.kind || null, p_actor: AL.actor || null, p_q: AL.q || null, p_limit: 200, p_before: before }));
      }).then(function (res) { AL.rows = (more ? AL.rows : []).concat(res.rows || []); AL.total = res.total || 0; AL.loading = false; AL.loaded = true; rerenderIf(['activity-log']); },
        function (e) { AL.loading = false; AL.loaded = true; AL.err = e.message; rerenderIf(['activity-log']); });
    },
    more: function () { return window.proAct.load(true); },
    csv: function () {
      var lines = [['Time', 'Person', 'Login ID', 'Role', 'Type', 'Activity', 'Details', 'Device', 'School']];
      AL.rows.forEach(function (e) { lines.push([e.at, e.actor || '', e.login_id || '', e.role || '', e.kind, e.action, e.detail ? JSON.stringify(e.detail) : '', e.device || '', e.school_name || '']); });
      var csv = lines.map(function (l) { return l.map(function (x) { x = String(x == null ? '' : x); return /[",\n]/.test(x) || /^[=+\-@]/.test(x) ? '"' + x.replace(/"/g, '""').replace(/^([=+\-@])/, "'$1") + '"' : x; }).join(','); }).join('\n');
      var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })); a.download = 'activity-' + AL.from + '_to_' + AL.to + '.csv'; document.body.appendChild(a); a.click(); setTimeout(function () { a.remove(); }, 500);
    }
  };
  function copyText(t, okMsg) {
    var done = function () { toast(okMsg); };
    if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(t).then(done, fallback); else fallback();
    function fallback() { var ta = document.createElement('textarea'); ta.value = t; ta.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); done(); } catch (e) { toast('Select the text and copy it.'); } ta.remove(); }
  }

  function addModule(id, meta, render) {
    var prev = window.ERP_MODULES[id] || {};
    window.ERP_MODULES[id] = Object.assign({}, prev, meta, { kind: 'special' });
    window.ERPRender[id] = render;
    try {
      var R = window.ABO && window.ABO.registry;
      if (R) { var m = R.get(id); if (m) { Object.assign(m, { label: meta.label, section: meta.section, roles: meta.roles, desc: meta.desc, kind: 'special', hidden: false }); R.setRenderer(id, render); } else R.register({ id: id, label: meta.label, icon: meta.icon, section: meta.section, kind: 'special', roles: meta.roles, desc: meta.desc, order: meta.order || 500, keywords: meta.keywords || [] }, render); }
    } catch (e) { /* ignore */ }
  }
  addModule('cloud-sync', { label: 'Cloud Sync (Supabase)', icon: '☁️', section: 'System', roles: ['owner', 'admin'], order: 15, keywords: ['supabase', 'cloud', 'sync', 'backup', 'online', 'link device'],
    desc: 'Keep the school in your own Supabase project so every device shares the same data, even after working offline.' }, cloudView);

  addModule('activity-log', { label: 'Activity Log', icon: '📋', section: 'System', roles: ['owner', 'admin'], order: 16, keywords: ['activity', 'audit', 'log', 'history', 'who did', 'sign-in'],
    desc: 'Every sign-in, page opened, change, clock-in and security event from every device — kept in Supabase.' }, activityView);

  window.ABO_BIO = BIO;
  window.ABO_CLOUD = {
    call: function (fn, body) { return rpc(fn, Object.assign(auth(), body || {})); },
    callPublic: function (fn, body, conf) { var c = conf || cfg(); if (!c) return Promise.reject(new CloudError('config', 'Online Backup is not set up.')); return rpc(fn, body || {}, c); },
    schoolId: function () { var c = cfg(); return c ? c.school : null; },
    activity: activity, flushActivity: flushActivity, queue: function () { return actQ.slice(); }, sync: sync, clockEvent: clockEvent, active: active, configured: function () { return !!cfg(); }, config: function () { var c = cfg(); return c ? { url: c.url, school: c.school, name: c.name } : null; }, deviceLabel: deviceLabel, status: function () { return window.proCloud.status(); } };
  // pages opened (same page twice within a minute counts once)
  var lastView = { id: null, at: 0 };
  function hookViews() {
    var A0 = window.ABO; if (!A0 || typeof A0.go !== 'function' || A0.go.__aboView) return;
    var go = A0.go;
    A0.go = function (id) {
      var r = go.apply(this, arguments);
      setTimeout(paintIndicator, 50);      // the top bar may have been redrawn
      try {
        if (me() && id && !(lastView.id === id && Date.now() - lastView.at < 60000)) {
          lastView = { id: id, at: Date.now() };
          var m = (A0.registry && A0.registry.get && A0.registry.get(id)) || window.ERP_MODULES[id] || {};
          activity('view', 'Opened ' + (m.label || id), { page: id });
        }
      } catch (e) { /* ignore */ }
      return r;
    };
    A0.go.__aboView = true;
  }
  function start() { setupLogin(); paintIndicator(); hookViews(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
