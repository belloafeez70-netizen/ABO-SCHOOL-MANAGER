# Offline editions — professional skin

`offline-pro-skin.css` + `offline-pro-skin.js` restyle the offline HTML editions without touching their features:
one navy + teal palette, Inter/system typography, line icons instead of emoji, flat cards, thin borders, quiet
information strip instead of the gold owner banner, white page headers instead of navy→gold gradients, accordion
sidebar groups (only the group you work in is open), each page listed once, and menu entries whose screen was never
built are hidden (11 in the owner menu). Dark mode is supported. User-written content (text boxes, newsletters,
messages) is never altered.

Apply / re-apply (idempotent):  `node scripts/skin-legacy.js ../school_broadsheet_manager_*.html`

Checks (`legacy/qa/`): owner sign-in in a normal tab, without internet and in a sandboxed preview
(`legacy_login.js`); demo data → class form → broadsheet → report sheet → dark mode → phone menu, no emoji left,
no page errors (`func.js`); hidden menu entries = exactly the screens that show nothing (`missing.js`).

## Data guard — `offline-data-guard.js` (all three editions, 8 Oct 2026)

The original app lost saved data. Proven on the untouched original with `qa/persist.js`: **3/15 checks passed**.
Learners, calendar, finance, lesson notes, staff and accounts were all gone after a reload. Typing the school name
created 19 storage keys. After the guard: **15/15**.

| Bug in the original | Effect | Fix |
|---|---|---|
| Every sign-in ran `saveData()` before `enterApp()` loaded the school | Blank memory replaced the saved school on each sign-in | A school key that holds data is never overwritten until this page has loaded it. Before that, only new accounts are merged in. |
| `init()` saved blank data to `broadsheetData_default` before sign-in | The Owner's own key was wiped on every page open | Same rule |
| The Owner's key followed the typed school name | One key per keystroke; after a reload the Owner looked at a different key | The Owner key is the selected school, otherwise `broadsheetData_default`. Staff of a single-school install resolve to the same key. There is a one-time recovery when the default key is empty and exactly one named school holds data. |
| Accounts were only loaded after sign-in | Teachers and parents could not sign in, or resume a session, after a reload | Saved accounts are read on the sign-in screen |

## Feature pack — `offline-features.js` (main edition), ideas taken from the Klacify school app

- **Lesson Notes:** write, submit, approve, or return with a required comment. Includes a template draft, a coverage
  grid for weeks 1–13, and print.
- **Learners' Birthdays:** today, next 7 days and this month, plus staff birthdays. Sends a WhatsApp wish to the
  parent and prints a birthday card.
- **Live Calendar:** live clock, week of term, countdowns, now/next period, and Nigerian public holidays.
- **Staff Clock-in:** lateness against the resumption time, month summary, and CSV export.
- **Live Class Monitor:** timetable compared with clock-in, so idle classes are flagged.
- **Dashboard "Today" strip.**
- The blank record screens are repaired, for example Parents & Guardians, Staff Directory and Learning Resources.

## Phone menu

The burger now toggles: tap to open, tap again to close. The menu also closes on:
- a tap on the dimmed area
- the × button
- the Esc key
- a swipe to the left
- choosing a page

Tapping a menu group folds only that group.

QA: `qa/menu_repro.js` checks the menu (12 checks), `qa/features.js` checks the feature pack (37 checks), and
`qa/persist.js` checks data persistence (15 checks).

## Cloud Sync (Supabase), fingerprint and clock-in activation — `offline-cloud.js` (main edition, 8 Oct 2026)

Owner guide: `legacy/supabase/README.md`. Database script: `legacy/supabase/setup.sql`. The script is also embedded
in the app (Cloud Sync → Copy setup script).

**Cloud Sync**
- Plain `fetch` to Supabase's REST endpoint (`/rest/v1/rpc/…`); no library to download.
- Works with new publishable keys (sent only as `apikey`) and legacy anon keys. Secret keys are refused.
- Offline first. When two devices changed the school at the same time, a three-way merge against the last synced copy
  (kept in IndexedDB) keeps both sets of changes.
- Version checks happen on the server, so a stale device can never overwrite newer data.

**Database security**
- Row Level Security is on with no policies, so tables are not reachable with the public key.
- Five `SECURITY DEFINER` functions each check the school secret (bcrypt) first.

**Linking devices**
- The Owner shares an `ABO1.…` code.
- The phone pastes it on the sign-in screen, downloads the school, and the teacher signs in with their Login ID.

**Fingerprint / face (WebAuthn, platform authenticator, user verification required)**
- Activation saves the phone's public key per Login ID.
- Each clock-in or fingerprint sign-in verifies:
  - the signature (ES256 / Ed25519 / RS256)
  - challenge, origin and RP-ID hash
  - the "user verified" flag
- It needs an `https://` address. `scripts/build-offline-site.js` builds a Netlify-ready folder.

**Clock-in activation**
- Settings: staff self clock-in on/off, require fingerprint, require GPS (school location + radius).
- Each clock-in is also sent as its own `abo_clock_events` row, so phones never overwrite each other. The Owner's
  device merges these within one sync cycle.
- Activated phones are listed and can be deactivated.

**Also fixed:** the phone sign-in screen. In the original app the clock moved into the page flow on small screens,
which crushed the sign-in card to about 110 px.

QA: `qa/cloud.js`, 45 checks, using two browser profiles (Owner computer + teacher phone). It covers:
- connect, wrong key, secret key refused, legacy key
- device link, fingerprint activation
- refused at 9 km, accepted at 28 m
- fingerprint not verified, offline queue
- two-way sync, conflict merge
- fingerprint sign-in, deactivation, no page errors

It runs against a local Supabase-compatible stack: PostgreSQL 17 + PostgREST 12 + a gateway that checks `apikey`
like Supabase does (`qa/supa-stack.sh`, `qa/supa-run.sh`), with Chrome's virtual authenticator and GPS emulation.

## Everything in Supabase (9 Oct 2026)

These tables are added to `supabase/setup.sql`; the script is still safe to re-run:

| Table | Holds |
|---|---|
| `abo_records` | the Owner's other schools, shared settings (pricing, owner password hash, payment flags) and per-user preferences |
| `abo_files` + `abo_file_parts` | uploaded photos, logos, signatures and documents |
| `abo_activity` | the full activity log |

All tables have RLS on and no policies. Every function checks the school secret first.

**Files**
- Uploads of 12 kB or more are replaced in the school record by `abo-file:<sha256>` references.
- They are uploaded once, in 400 kB parts. On download they are resolved, checked against the hash and cached in
  IndexedDB.
- Saves no longer re-send pictures.

**Activity**
- Captured events: sign-in, failed sign-in, sign-out, pages opened, per-save change summaries, every `logAudit`
  action, clock-ins, fingerprint and cloud events, and app errors.
- Change summaries are written in words, for example "Calendar (+1), Finance › Income (+1)".
- Events are queued on the device (up to 1,500) and uploaded in batches; duplicates are ignored by the server.
- **System → Activity Log** has filters and CSV export.

**Sync rules**
- The Owner's device syncs every school and keeps doing so while another school is open.
- Phones receive only the connected school, shared settings and their own preferences.
- A new computer that connects with the same School ID and secret restores everything (Download).

QA: `qa/cloud2.js`, 35 checks, using three profiles (Owner computer, teacher phone, new computer).

## Simple words + School Web Address (9 Oct 2026)

**Simple words** (`offline-plain.js`) are on by default and follow the standing rule in `docs/PLAIN_LANGUAGE.md`.
- All 94 pages get simple names and one-line explanations. Menu headings, sign-in screen, top bar, common buttons,
  column titles and "nothing here yet" messages are simplified too.
- **Show full terms** (bottom of the menu) restores the office words. The choice is saved per user
  (`aboWords`, synced as a preference). Search finds pages by either name.
- User-typed content is never changed.
- Menu headings change through a CSS attribute, so the fold-open logic, which reads the heading text, keeps working.

**School Web Address** (`offline-site.js`) runs a subdomain flow for the main edition:
1. Suggests a name, checks friendly rules live, and offers "Fix it for me".
2. Free `name.netlify.app`, or your own domain (shows the DNS CNAME record to add).
3. Reserved and unique in Supabase: `abo_subdomain_check` (public, yes/no), `abo_subdomain_set` (needs the school
   secret), and `abo_site_lookup`.
4. **Make website files** builds a zip with the app and a `window.ABO_SITE` config (no secret). It uses a tiny built-in
   ZIP writer, so it works offline.
5. The school site shows a welcome on the sign-in screen.
6. `#connect=` links connect a phone in one tap.

QA:
- `qa/words.js` (20 checks)
- `qa/site.js` (20 checks; includes a second school refused the same name, zip contents, and the generated site +
  tap-to-connect + teacher sign-in)

The older QA scripts run with full terms via `qa/fullwords.js`.

## Roles & Owner control (9 Oct 2026) — `offline-roles.js`

**Owner Control Centre** (owner only), covering School office, Teachers, Pupils and Parents:
- counts per group
- "View their screen"
- "Add a login", with a suggested login code (pupils are linked to a learner)
- turn a login off or on (a turned-off login cannot sign in)
- approve School office logins
- a link to "What they can see" (Roles & Permissions)

**Faithful "view as":** pages render as the viewed role. `ABO.render.mount` runs inside `ABO.identity.asEffective`
while previewing.

**Access fixes (defaults; the owner can override them in Roles & Permissions):**
- Print Centre is closed to pupils and parents.
- Teachers' Print Centre hides money, export and backup items.
- Teachers get Staff Clock-in and Birthdays.
- Footer buttons a role cannot use are hidden. A CSS `[hidden]` override fixes an app style that forced them visible.
- The owner can create Teacher and Pupil logins; the old guard allowed only the School Admin.

**Simple-word fix:** "Announcements" and "Newsletters" are readers for pupils and parents, so they are no longer
called "Send a Notice" or "Newsletter Maker".

**Pre-fill:** the Online Backup form is pre-filled with the school's Supabase project URL and publishable key. These
are public values; the secret key is never used.

QA: `qa/roles.js`, 51 checks. Each role's interface is opened by the owner and every page in its menu opens without
errors:
- School office: 83 pages
- Teacher: 36 pages
- Pupil: 18 pages
- Parent: 12 pages

The run also covers the access fixes, the calm banner, the Control Centre flows, and the owner creating logins.

### Owner views (follow-up, 9 Oct 2026)
- **"See the app as"** on the owner's Home: one-tap buttons for School office, Teacher, Pupil and Parent, plus the
  Control Centre. The row is hidden while viewing another screen.
- **"See their screen"** for one specific person, from each login row in the Control Centre.
  - How it works: `ABO.state.set('currentUser')` is wrapped so the preview's shadow user becomes that account
    (`name`, `loginId`, `assignedClass`, `studentIndex`/`linkedStudentName`, `children`); the role's permissions stay.
  - The banner names the person. Switching to a whole group clears the person.
- **The banner says in plain words what you are viewing**, including the sample pupil's name.
- **Faithful preview:** the dashboard's staff "Today" strip now follows the viewed role, so pupils and parents no
  longer see staff clock-in and lesson-note counts.
- **QA:**
  - `qa/roles.js`: 57 checks
  - `qa/preview_roles.js`: 10 checks; the owner switches through all four screens and back, inside the sandboxed
    preview frame

### Owner signs in AS a person (9 Oct 2026)
- **Where:** Control Centre (each login row, or **Sign in as…** on a group) and the owner's Home (**Sign in as
  someone**).
- **How it works:**
  - `currentUser` is set to that real account and the session is written for it, then `enterApp()` runs.
  - It is a real sign-in, not a preview: every function works with that role's own permissions.
  - Owner-only pages stay closed.
- **The way back:** the green bar "Owner: you are signed in as … — **Back to my owner account**" stays on screen and
  survives a reload (`aboActAsOwner`).
- **Records:**
  - Activity is recorded with "(done by owner)".
  - The start and the return are written to the audit log.
  - Signing out ends it.
  - Turned-off logins cannot be used.
- **Subscription timer:** the early-access 30-second timer never blocks the owner while signed in as someone.
- **School access:** a Control Centre panel shows whether the school is approved (full access) or on trial, where
  staff are stopped after 30 seconds. It has **Give full access** / **Back to trial**. Creating a School Office login
  from the Control Centre approves the school, as the original form did.
- **Security note (main edition):**
  - Login is by code only, and local storage can be edited, so this adds no new weakness.
  - Personal logins with server-side checks remain the fix (see `docs/LIMITATIONS.md`).
- **QA:** `qa/signin_as.js` (25 checks)
