/* ==========================================================================================
   A.B.O. offline edition — "This device": screen layout lock, install as an app, phone pop-up fixes (11 Oct 2026)

   1. Screen layout lock. On phones the page kept going back to the phone layout after the user chose the browser's
      "Desktop site" (after a reload, returning to the tab, turning the phone, or a sync refresh). The choice is now
      remembered on this device (localStorage "aboLayout") and re-applied every time:
        auto    — phone layout on phones, computer layout on computers; if the browser's "Desktop site" is on, the
                  computer layout is used and stays.
        desktop — always the computer layout (page drawn 1280 px wide, pinch to zoom).
        phone   — always the phone layout (tablets).
   2. Install as an app (Chrome, Edge, Samsung Internet, Opera: their own install box; Safari / Firefox: exact steps).
      Works on the website copy (https:// — see abo-school-site). A file opened from the phone's storage cannot be
      installed by any browser; the box explains this.
   3. Phone pop-ups (class switcher, "switch interface", alerts) are kept inside the screen — before, half of the list
      was off the left edge and could not be tapped.
   This script runs in <head> (before the page is drawn). It never touches school data.
   ========================================================================================== */
(function () {
  'use strict';
  if (window.__aboDevice) return; window.__aboDevice = true;
  var KEY = 'aboLayout';
  var PHONE = 'width=device-width, initial-scale=1.0, viewport-fit=cover';
  var DESKTOP = 'width=1280, viewport-fit=cover';
  function meta() { var m = document.querySelector('meta[name="viewport"]'); if (!m) { m = document.createElement('meta'); m.name = 'viewport'; (document.head || document.documentElement).appendChild(m); } return m; }
  function get() { try { var v = localStorage.getItem(KEY); return v === 'desktop' || v === 'phone' ? v : 'auto'; } catch (e) { return 'auto'; } }
  function touch() { return (window.matchMedia && matchMedia('(pointer: coarse)').matches) || (navigator.maxTouchPoints || 0) > 1; }
  function browserDesktopSite() {
    var ua = navigator.userAgent || ''; var s = Math.min(screen.width || 0, screen.height || 0);
    return touch() && s > 0 && s < 820 && !/Mobi|Android|iPhone|iPod|Opera Mini|IEMobile/i.test(ua);
  }
  function effective() { var m = get(); return m === 'auto' ? (browserDesktopSite() ? 'desktop' : 'auto') : m; }
  function apply() {
    var e = effective(); var want = e === 'desktop' ? DESKTOP : PHONE; var m = meta();
    if (m.getAttribute('content') !== want) m.setAttribute('content', want);
    var r = document.documentElement; r.classList.toggle('layout-desktop', e === 'desktop'); r.classList.toggle('layout-phone', e === 'phone'); r.setAttribute('data-layout', get());
  }
  apply();
  window.addEventListener('pageshow', apply);
  document.addEventListener('visibilitychange', function () { if (!document.hidden) apply(); });
  window.addEventListener('orientationchange', function () { setTimeout(apply, 150); });
  window.addEventListener('storage', function (ev) { if (ev.key === KEY) apply(); });
  function setLayout(m) { try { if (m === 'auto') localStorage.removeItem(KEY); else localStorage.setItem(KEY, m); } catch (e) { /* private mode */ } apply(); try { window.dispatchEvent(new Event('resize')); } catch (e) { /* */ } }

  /* ── install ── */
  window.addEventListener('beforeinstallprompt', function (ev) { ev.preventDefault(); window.__aboInstallEvent = ev; });
  window.addEventListener('appinstalled', function () { window.__aboInstallEvent = null; toast('Installed. Open the app from the new A.B.O. icon.'); });
  function installed() { return (window.matchMedia && (matchMedia('(display-mode: standalone)').matches || matchMedia('(display-mode: minimal-ui)').matches)) || navigator.standalone === true; }
  function hasManifest() { return !!document.querySelector('link[rel="manifest"][href$="manifest.webmanifest"]'); }
  function secure() { return location.protocol === 'https:' || /^(localhost|127\.0\.0\.1)$/.test(location.hostname); }
  // the website copy (abo-school-site) ships sw.js + manifest; register only there. When a NEW version of the site is
  // published, the new worker waits and a bar offers "Update now" (no half-old, half-new page; nothing reloads by itself
  // while someone is typing scores).
  function updateBar(reg) {
    if (document.getElementById('proUpdateBar') || !reg.waiting) return;
    var bar = document.createElement('div'); bar.id = 'proUpdateBar'; bar.className = 'pro-update-bar'; bar.setAttribute('role', 'status');
    bar.innerHTML = '<span>A new version of the app is ready.</span><button type="button">Update now</button>';
    bar.querySelector('button').addEventListener('click', function () { try { reg.waiting.postMessage({ type: 'skip-waiting' }); } catch (e) { location.reload(); } });
    (document.body || document.documentElement).appendChild(bar);
  }
  if ('serviceWorker' in navigator && secure()) {
    window.addEventListener('load', function () {
      if (!hasManifest()) return;
      var hadController = !!navigator.serviceWorker.controller;
      navigator.serviceWorker.register('sw.js').then(function (reg) {
        if (reg.waiting && hadController) updateBar(reg);
        reg.addEventListener('updatefound', function () { var w = reg.installing; if (!w) return; w.addEventListener('statechange', function () { if (w.state === 'installed' && navigator.serviceWorker.controller) updateBar(reg); }); });
        setInterval(function () { reg.update().catch(function () { /* offline */ }); }, 30 * 60000);
      }).catch(function () { /* optional */ });
      var reloaded = false;
      navigator.serviceWorker.addEventListener('controllerchange', function () { if (hadController && !reloaded) { reloaded = true; location.reload(); } });
    });
  }

  /* ── no double saves: a second tap on the same save/publish/submit button within 1.2 s is ignored ── */
  var lastTap = new Map();   // keyed by what the button does (pages re-draw buttons, so the element itself changes)
  var ACTION = /\b(save|publish|submit|record|approve|archive|pay|post|send|import|restore|create|add)\w*\s*\(/i;
  document.addEventListener('click', function (ev) {
    var b = ev.target && ev.target.closest && ev.target.closest('button, .btn, .erp-btn, [role="button"]'); if (!b) return;
    var oc = b.getAttribute('onclick') || '';
    // NOTE: a <button> without a type attribute reports type "submit" — only count REAL form submit buttons, so menu
    // and toggle buttons (pressed twice on purpose) are never blocked
    var realSubmit = String(b.getAttribute('type') || '').toLowerCase() === 'submit' || (!!b.form && b.type === 'submit');
    // only buttons that SAVE something (by what they call) — not every button styled "primary": a Connect / Next / Search
    // button pressed again after an error message must work at once
    var isAction = ACTION.test(oc) || realSubmit;
    if (b.getAttribute('aria-expanded') != null || b.getAttribute('aria-pressed') != null || /toggle|collapse|expand|burger|menu/i.test(oc + ' ' + b.className)) return;
    if (!isAction) return;
    var key = oc || b.id || (b.textContent || '').trim().slice(0, 40);
    var now = Date.now(), t = lastTap.get(key) || 0;
    if (now - t < 1200) { ev.preventDefault(); ev.stopImmediatePropagation(); return; }
    lastTap.set(key, now); if (lastTap.size > 200) lastTap.clear();
  }, true);
  // the person changed something (typed, picked an option): the next tap is on purpose, never a double tap
  ['input', 'change'].forEach(function (t) { document.addEventListener(t, function () { lastTap.clear(); }, true); });
  function browserName() {
    var ua = navigator.userAgent || ''; var t = (navigator.maxTouchPoints || 0) > 1; var ios = /iPhone|iPad|iPod/.test(ua) || (/Macintosh/.test(ua) && t);
    if (ios) return /CriOS/.test(ua) ? 'ios-chrome' : /FxiOS/.test(ua) ? 'ios-firefox' : /EdgiOS/.test(ua) ? 'ios-edge' : 'ios-safari';
    if (/SamsungBrowser/.test(ua)) return 'samsung';
    if (/Edg\//.test(ua)) return /Android/.test(ua) ? 'edge-android' : 'edge';
    if (/OPR\//.test(ua)) return 'opera';
    if (/Firefox\//.test(ua)) return /Android/.test(ua) ? 'firefox-android' : 'firefox';
    if (/Chrome\//.test(ua)) return /Android/.test(ua) ? 'chrome-android' : 'chrome';
    if (/Safari\//.test(ua) && /Macintosh/.test(ua)) return 'mac-safari';
    return 'other';
  }
  var STEPS = {
    chrome: ['Click the install icon at the right end of the address bar (a small screen with a down arrow).', 'Or open the menu ⋮ › Cast, save and share › Install page as app.', 'Click Install.'],
    edge: ['Click the “App available” icon in the address bar, or menu ⋯ › Apps › Install this site as an app.', 'Click Install.'],
    opera: ['Open the menu › Install app (or the install icon in the address bar), then confirm.'],
    'chrome-android': ['Tap the menu ⋮ at the top right.', 'Tap “Add to Home screen”, then Install (or tap “Install app”).'],
    'edge-android': ['Tap the menu ⋯ at the bottom, then “Add to phone” › Install.'],
    samsung: ['Tap the menu ☰ at the bottom, then “Add page to” › Home screen.'],
    'firefox-android': ['Tap the menu ⋮, then “Add app to Home screen” (older versions: “Install”).'],
    firefox: ['Firefox on computers cannot install apps yet. On Windows you can turn on Settings › Firefox Labs › “Add sites to your taskbar”, then click the new icon in the address bar.', 'For a full app window, open this address in Chrome or Microsoft Edge and click Install.'],
    'mac-safari': ['Safari 17 or newer: File menu (or Share) › “Add to Dock”.'],
    'ios-safari': ['Tap the Share button (square with an arrow up).', 'Tap “Add to Home Screen”, then Add.'],
    'ios-chrome': ['Tap the Share button in the address bar, then “Add to Home Screen”.'],
    'ios-edge': ['Tap the menu ⋯ › Share › “Add to Home Screen”.'],
    'ios-firefox': ['Tap the menu ☰ › Share › “Add to Home Screen”.'],
    other: ['Open your browser menu and look for “Install app”, “Add to Home screen” or “Add to Dock”.']
  };
  var NAMES = { chrome: 'Google Chrome', edge: 'Microsoft Edge', opera: 'Opera', 'chrome-android': 'Chrome on Android', 'edge-android': 'Edge on Android', samsung: 'Samsung Internet', 'firefox-android': 'Firefox on Android', firefox: 'Firefox on a computer', 'mac-safari': 'Safari on Mac', 'ios-safari': 'Safari on iPhone / iPad', 'ios-chrome': 'Chrome on iPhone / iPad', 'ios-edge': 'Edge on iPhone / iPad', 'ios-firefox': 'Firefox on iPhone / iPad', other: 'your browser' };
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function toast(msg) { try { if (window.ABO && ABO.ui && ABO.ui.toast) return ABO.ui.toast(msg); if (window.showToast) return window.showToast(msg); } catch (e) { /* */ } }
  function steps() {
    var b = browserName(); var list = function (k) { return '<ol>' + STEPS[k].map(function (s) { return '<li>' + esc(s) + '</li>'; }).join('') + '</ol>'; };
    var warn = location.protocol === 'file:' || !secure()
      ? '<div class="pro-dev-warn">This copy was opened as a file. Browsers only install apps from a web address (https://). Publish the website copy (abo-school-site folder, about 2 minutes on Netlify), open that address on each phone, then install.</div>'
      : (!hasManifest() ? '<div class="pro-dev-warn">For the best app (own icon, works offline), use the website copy built from the abo-school-site folder.</div>' : '');
    var others = ['chrome-android', 'ios-safari', 'chrome', 'edge', 'firefox-android', 'mac-safari'].filter(function (k) { return k !== b; });
    var body = '<div class="pro-dev-help">' + warn + '<p>Installing puts the A.B.O. icon on your home screen or computer. It opens in its own window, straight to your school.</p>' +
      '<h4>On ' + esc(NAMES[b]) + '</h4>' + list(b) + '<details><summary>Other phones and browsers</summary>' + others.map(function (k) { return '<div><b>' + esc(NAMES[k]) + '</b>' + list(k) + '</div>'; }).join('') + '</details></div>';
    if (window.ABO && ABO.ui && ABO.ui.modal) ABO.ui.modal({ title: 'Install the app on this device', body: body, footer: '<button class="erp-btn primary" type="button" onclick="ABO.ui.close()">Close</button>' });
    else alert('Install: ' + STEPS[b].join(' '));
  }
  function install() {
    if (installed()) return toast('The app is already installed on this device.');
    var ev = window.__aboInstallEvent;
    if (ev && ev.prompt) { ev.prompt(); (ev.userChoice || Promise.resolve({})).then(function (r) { window.__aboInstallEvent = null; if (r && r.outcome === 'accepted') toast('Installing… the A.B.O. icon will appear on this device.'); }); return; }
    steps();
  }

  /* ── "This device" button in the top bar ── */
  var ICON = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="4" width="14" height="10" rx="1.5"/><path d="M6 18h6M9 14v4"/><rect x="16.5" y="8" width="5.5" height="12" rx="1.2"/><path d="M19 17.5h.01"/></svg>';
  function popHtml() {
    var m = get(); var e = effective(); var big = (screen.width || 9999) >= 1100 && !touch();
    var opt = function (v, t, d) { return '<label class="pro-dev-opt"><input type="radio" name="proLayout" value="' + v + '"' + (m === v ? ' checked' : '') + '><span><b>' + t + '</b><small>' + d + '</small></span></label>'; };
    return '<div class="pro-dev-head">This device</div>' +
      (big && m === 'auto' ? '' : '<div class="pro-dev-sec">Screen layout' + (m === 'auto' && e === 'desktop' ? ' <em>(browser “Desktop site” is on)</em>' : '') + '</div>' +
        opt('auto', 'Automatic', 'Phone layout on phones, computer layout on computers') + opt('desktop', 'Computer layout', 'Full menu and wide tables; stays on until you change it') + opt('phone', 'Phone layout', 'Big buttons and a slide-out menu')) +
      '<button type="button" class="pro-dev-install"' + (installed() ? ' hidden' : '') + '>' + '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M12 3v12M7 10l5 5 5-5M5 21h14"/></svg><span>Install app on this device</span></button>' +
      (installed() ? '<div class="pro-dev-note">Running as an installed app.</div>' : '');
  }
  function closePop() { var p = document.getElementById('proDevicePop'); if (p) p.remove(); document.removeEventListener('click', outside, true); }
  function outside(ev) { var p = document.getElementById('proDevicePop'); if (p && !p.contains(ev.target) && !ev.target.closest('#proDeviceBtn')) closePop(); }
  function openPop(btn) {
    if (document.getElementById('proDevicePop')) return closePop();
    var p = document.createElement('div'); p.id = 'proDevicePop'; p.className = 'pro-device-pop'; p.setAttribute('role', 'dialog'); p.setAttribute('aria-label', 'This device'); p.innerHTML = popHtml();
    document.body.appendChild(p); placePop(p, btn);
    p.addEventListener('change', function (ev) { if (ev.target.name === 'proLayout') { setLayout(ev.target.value); toast(ev.target.value === 'desktop' ? 'Computer layout on. It stays on for this device until you change it.' : ev.target.value === 'phone' ? 'Phone layout on for this device.' : 'Automatic layout.'); setTimeout(function () { closePop(); }, 250); } });
    p.querySelector('.pro-dev-install').addEventListener('click', function () { closePop(); install(); });
    setTimeout(function () { document.addEventListener('click', outside, true); }, 0);
  }
  function placePop(p, btn) {
    var r = btn.getBoundingClientRect(); var W = window.innerWidth;
    p.style.top = Math.round(r.bottom + 6) + 'px';
    if (W <= 700) { p.style.left = '8px'; p.style.right = '8px'; } else { p.style.right = Math.max(8, Math.round(W - r.right)) + 'px'; p.style.width = '320px'; }
  }
  function addButton() {
    var bar = document.querySelector('#aboTopbar .abo-topbar-right'); if (!bar || document.getElementById('proDeviceBtn')) return;
    var b = document.createElement('button'); b.type = 'button'; b.id = 'proDeviceBtn'; b.className = 'abo-icon-btn pro-device-btn'; b.title = 'This device: screen layout and install app'; b.setAttribute('aria-label', 'This device: screen layout and install app'); b.innerHTML = ICON;
    b.addEventListener('click', function (ev) { ev.stopPropagation(); openPop(b); });
    var theme = bar.querySelector('[aria-label="Toggle theme"]'); bar.insertBefore(b, theme || null);
  }

  /* ── phone pop-ups stay on the screen ── */
  function clamp(el) {
    if (!el || !el.classList.contains('open') || window.innerWidth > 700) return;
    el.style.position = ''; el.style.left = ''; el.style.right = ''; el.style.top = ''; el.style.width = ''; el.style.maxHeight = '';
    var r = el.getBoundingClientRect(); var W = window.innerWidth, H = window.innerHeight;
    if (r.left >= 4 && r.right <= W - 4 && r.bottom <= H - 4) return;
    var top = Math.max(8, Math.min(Math.round(r.top), H - 160));
    el.style.position = 'fixed'; el.style.left = '8px'; el.style.right = '8px'; el.style.width = 'auto'; el.style.top = top + 'px'; el.style.maxHeight = (H - top - 12) + 'px'; el.style.overflowY = 'auto'; el.setAttribute('data-pro-clamped', '1');
  }
  function unclamp(el) { if (el.getAttribute('data-pro-clamped') && !el.classList.contains('open')) { ['position', 'left', 'right', 'top', 'width', 'maxHeight', 'overflowY'].forEach(function (k) { el.style[k] = ''; }); el.removeAttribute('data-pro-clamped'); } }
  var POP = '.abo-switcher-pop, .abo-classbar-pop, .abo-alert-pop, .abo-ws-pop';

  function ready() {
    addButton();
    new MutationObserver(function (muts) {
      var bar = false;
      muts.forEach(function (m) {
        if (m.type === 'attributes' && m.target.matches && m.target.matches(POP)) { if (m.target.classList.contains('open')) requestAnimationFrame(function () { clamp(m.target); }); else unclamp(m.target); }
        if (m.type === 'childList') bar = true;
      });
      if (bar && !document.getElementById('proDeviceBtn')) addButton();
    }).observe(document.body, { subtree: true, attributes: true, attributeFilter: ['class'], childList: true });
    window.addEventListener('resize', function () { document.querySelectorAll(POP).forEach(function (el) { if (el.classList.contains('open')) clamp(el); }); var p = document.getElementById('proDevicePop'); var b = document.getElementById('proDeviceBtn'); if (p && b) placePop(p, b); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closePop(); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ready); else ready();

  window.ABO_DEVICE = { layout: get, effective: effective, setLayout: setLayout, browserDesktopSite: browserDesktopSite, install: install, steps: steps, installed: installed };
}());
