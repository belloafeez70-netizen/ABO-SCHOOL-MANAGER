/* ==========================================================================================
   A.B.O. professional skin for the OFFLINE editions — behaviour part.
   1. Emoji used as icons become consistent line icons (SVG); emoji sprinkled in labels are removed.
      User-written content (text boxes, editable newsletters, messages) is never touched.
   2. The owner sidebar no longer repeats the same page in several groups (first occurrence kept).
   Purely presentational: no data, storage or business logic is changed.
   ========================================================================================== */
(function () {
  'use strict';
  if (window.__aboProSkin) return; window.__aboProSkin = true;

  /* ── line icons (24×24, stroke) ── */
  var P = {
    chart: 'M4 20V10M10 20V4M16 20v-7M22 20H2', trend: 'M3 17l6-6 4 4 8-8M15 7h6v6',
    megaphone: 'M3 11v2a1 1 0 001 1h2l5 4V6L6 10H4a1 1 0 00-1 1zM15 8a5 5 0 010 8M18 5a9 9 0 010 14',
    news: 'M4 4h13v16H6a2 2 0 01-2-2zM17 8h3v10a2 2 0 01-2 2M8 8h5M8 12h5M8 16h3',
    calendar: 'M3 5h18v16H3zM16 3v4M8 3v4M3 10h18', flask: 'M9 3h6M10 3v6L4.5 19A1.5 1.5 0 006 21h12a1.5 1.5 0 001.5-2L14 9V3M7 15h10',
    building: 'M3 21h18M5 21V8l7-5 7 5v13M9 21v-6h6v6M9 10h.01M15 10h.01',
    users: 'M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2M9 11a4 4 0 100-8 4 4 0 000 8zM22 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75',
    user: 'M20 21v-1a5 5 0 00-5-5H9a5 5 0 00-5 5v1M12 11a4 4 0 100-8 4 4 0 000 8z',
    grad: 'M22 10L12 5 2 10l10 5 10-5zM6 12v5c3 2 9 2 12 0v-5', file: 'M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8zM14 2v6h6M8 13h8M8 17h6',
    trash: 'M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14M10 11v6M14 11v6', check: 'M20 6L9 17l-5-5',
    checkCircle: 'M22 11.1V12a10 10 0 11-5.9-9.1M22 4L12 14l-3-3',
    wallet: 'M3 7h16a2 2 0 012 2v9a2 2 0 01-2 2H3zM3 7V5a2 2 0 012-2h11M17 13.5h.01', message: 'M21 12a8 8 0 01-11.6 7.1L3 21l1.9-6.4A8 8 0 1121 12z',
    clipboard: 'M9 4h6v3H9zM7 5H5v16h14V5h-2M9 12h6M9 16h4', receipt: 'M5 3h14v18l-3-2-2 2-2-2-2 2-2-2-3 2zM9 8h6M9 12h6M9 16h3',
    notebook: 'M6 3h13v18H6a2 2 0 01-2-2V5a2 2 0 012-2zM9 7h6M9 11h6', book: 'M4 19.5A2.5 2.5 0 016.5 17H20V3H6.5A2.5 2.5 0 004 5.5v14z',
    pin: 'M12 17v5M9 3h6l-1 6 3 3H7l3-3z', search: 'M11 19a8 8 0 100-16 8 8 0 000 16zM21 21l-4.35-4.35',
    save: 'M5 3h11l5 5v13H5zM8 3v6h8M8 21v-7h8v7', printer: 'M6 9V3h12v6M6 18H4v-7h16v7h-2M8 14h8v7H8z',
    card: 'M2 6h20v12H2zM2 10h20M6 15h4', refresh: 'M21 12a9 9 0 11-3-6.7L21 8M21 3v5h-5',
    download: 'M12 3v12M7 10l5 5 5-5M5 21h14', upload: 'M12 21V9M7 14l5-5 5 5M5 3h14', zap: 'M13 2L3 14h8l-1 8 10-12h-8z',
    board: 'M3 4h18v12H3zM8 20h8M12 16v4', shield: 'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z', lock: 'M5 11h14v10H5zM8 11V7a4 4 0 018 0v4',
    palette: 'M12 22a10 10 0 110-20c5 0 9 3.6 9 8 0 2.8-2.2 4-4.5 4H15a2 2 0 00-1.5 3.3A2 2 0 0112 22zM7.5 11h.01M10.5 7h.01M15.5 7h.01',
    key: 'M21 2l-2 2m-7.6 7.6a5.5 5.5 0 11-7.8 7.8 5.5 5.5 0 017.8-7.8zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4',
    archive: 'M3 4h18v5H3zM5 9v11h14V9M10 13h4', folder: 'M3 6a2 2 0 012-2h4l2 3h8a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2z',
    calc: 'M5 3h14v18H5zM8 7h8M8 12h.01M12 12h.01M16 12h.01M8 16h.01M12 16h.01M16 16h.01', clock: 'M12 22a10 10 0 100-20 10 10 0 000 20zM12 6v6l4 2',
    settings: 'M12 15a3 3 0 100-6 3 3 0 000 6zM19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 11-4 0v-.1a1.7 1.7 0 00-1.1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 110-4h.1a1.7 1.7 0 001.5-1.1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3H9a1.7 1.7 0 001-1.5V3a2 2 0 114 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8V9a1.7 1.7 0 001.5 1H21a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z',
    home: 'M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10', edit: 'M12 20h9M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z',
    bell: 'M18 8a6 6 0 00-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 01-3.4 0', alert: 'M10.3 3.9L1.8 18a2 2 0 001.7 3h17a2 2 0 001.7-3L13.7 3.9a2 2 0 00-3.4 0zM12 9v4M12 17h.01',
    phone: 'M7 2h10v20H7zM11 18h2', plus: 'M12 5v14M5 12h14', sparkle: 'M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z',
    signal: 'M5 12.55a11 11 0 0114 0M8.5 16.1a6 6 0 017 0M12 20h.01M2 8.82a15 15 0 0120 0', logout: 'M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9',
    cloud: 'M17.5 19H9a7 7 0 116.7-9h1.8a4.5 4.5 0 010 9z', cart: 'M3 3h2l2.4 12.4a2 2 0 002 1.6h9.2a2 2 0 002-1.6L22 7H6M9 21h.01M18 21h.01',
    link: 'M10 13a5 5 0 007.5.5l3-3a5 5 0 00-7-7l-1.7 1.7M14 11a5 5 0 00-7.5-.5l-3 3a5 5 0 007 7l1.7-1.7', eye: 'M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8zM12 15a3 3 0 100-6 3 3 0 000 6z',
    camera: 'M3 7h4l2-3h6l2 3h4v13H3zM12 17a4 4 0 100-8 4 4 0 000 8z', image: 'M3 3h18v18H3zM8.5 10a1.5 1.5 0 100-3 1.5 1.5 0 000 3zM21 15l-5-5L5 21',
    mail: 'M4 4h16v16H4zM22 6l-10 7L2 6', box: 'M21 8l-9-5-9 5v8l9 5 9-5zM3 8l9 5 9-5M12 13v8', award: 'M12 15a6 6 0 100-12 6 6 0 000 12zM8.2 13.9L7 22l5-3 5 3-1.2-8.1',
    target: 'M12 22a10 10 0 100-20 10 10 0 000 20zM12 18a6 6 0 100-12 6 6 0 000 12zM12 14a2 2 0 100-4 2 2 0 000 4z',
    activity: 'M22 12h-4l-3 9L9 3l-3 9H2', moon: 'M21 12.8A9 9 0 1111.2 3a7 7 0 009.8 9.8z',
    sun: 'M12 17a5 5 0 100-10 5 5 0 000 10zM12 1v2M12 21v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M1 12h2M21 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4',
    video: 'M23 7l-7 5 7 5zM1 5h15v14H1z', plug: 'M9 2v6M15 2v6M6 8h12v4a6 6 0 01-12 0zM12 18v4', help: 'M12 22a10 10 0 100-20 10 10 0 000 20zM9.1 9a3 3 0 015.8 1c0 2-3 2.5-3 4.5M12 17.5h.01',
    ban: 'M12 22a10 10 0 100-20 10 10 0 000 20zM4.9 4.9l14.2 14.2', grid: 'M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z', id: 'M3 5h18v14H3zM7 15h4M7 11h2M15 10a2 2 0 100-.01M13 15h4',
    hand: 'M18 11V6a2 2 0 00-4 0v5M14 10V4a2 2 0 00-4 0v6M10 10.5V6a2 2 0 00-4 0v8a8 8 0 0016 0v-3a2 2 0 00-4 0',
    dot: 'M12 13a1 1 0 100-2 1 1 0 000 2z', menu: 'M3 6h18M3 12h18M3 18h18', close: 'M18 6L6 18M6 6l12 12',
    fingerprint: 'M12 11v3a8 8 0 01-1.5 4.6M8.5 7.6A4 4 0 0116 10v2.5M8 11v1a12 12 0 01-1 4.8M12 3a8 8 0 018 8v1.5M4.3 8.5A8 8 0 019 3.6M16 16.5a16 16 0 01-1 4M4 13v-2',
    copy: 'M9 9h11v11H9zM5 15H4V4h11v1',
    'map-pin': 'M12 21s-7-5.6-7-11a7 7 0 0114 0c0 5.4-7 11-7 11zM12 12.5a2.5 2.5 0 100-5 2.5 2.5 0 000 5z',
    'arrow-left': 'M19 12H5M11 18l-6-6 6-6',
    book: 'M4 19.5A2.5 2.5 0 016.5 17H20V3H6.5A2.5 2.5 0 004 5.5v14zM4 19.5A2.5 2.5 0 006.5 22H20v-5',
    globe: 'M12 22a10 10 0 100-20 10 10 0 000 20zM2 12h20M12 2c2.5 2.7 4 6.3 4 10s-1.5 7.3-4 10c-2.5-2.7-4-6.3-4-10s1.5-7.3 4-10z',
    graduation: 'M22 10L12 5 2 10l10 5 10-5zM6 12v5c3 2 9 2 12 0v-5',
    heart: 'M20.8 4.6a5.5 5.5 0 00-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 00-7.8 7.8l1 1.1L12 21l7.8-7.5 1-1.1a5.5 5.5 0 000-7.8z',
    cake: 'M20 21V12a2 2 0 00-2-2H6a2 2 0 00-2 2v9M4 16c1.5 0 1.5-1 3-1s1.5 1 3 1 1.5-1 3-1 1.5 1 3 1 1.5-1 3-1M2 21h20M12 10V7M12 4h.01',
    gift: 'M20 12v10H4V12M2 7h20v5H2zM12 22V7M12 7H7.5a2.5 2.5 0 010-5C11 2 12 7 12 7zM12 7h4.5a2.5 2.5 0 000-5C13 2 12 7 12 7z',
    login: 'M15 3h4a2 2 0 012 2v14a2 2 0 01-2 2h-4M10 17l5-5-5-5M15 12H3', live: 'M12 14a2 2 0 100-4 2 2 0 000 4zM16.24 7.76a6 6 0 010 8.49M7.76 16.24a6 6 0 010-8.49M19.07 4.93a10 10 0 010 14.14M4.93 19.07a10 10 0 010-14.14',
    send: 'M22 2L11 13M22 2l-7 20-4-9-9-4z', whatsapp: 'M21 11.5a8.4 8.4 0 01-12.4 7.4L3 20l1.2-5.4A8.5 8.5 0 1121 11.5z'
  };
  var MAP = {
    '📊': 'chart', '📈': 'trend', '📉': 'trend', '📢': 'megaphone', '📰': 'news', '🗓': 'calendar', '📅': 'calendar', '🎂': 'cake', '🛡️': 'shield', '🛡': 'shield', '🌐': 'globe', '📖': 'book', '☁️': 'cloud', '☁': 'cloud', '👆': 'fingerprint', '📍': 'map-pin', '🎁': 'gift', '🎉': 'gift', '🥳': 'gift', '📆': 'calendar', '🏖': 'calendar',
    '🧪': 'flask', '🏫': 'building', '🏢': 'building', '🏦': 'building', '👥': 'users', '👪': 'users', '👨‍👩‍👧': 'users', '🎭': 'users', '👤': 'user', '🙋': 'user',
    '🧑‍💼': 'user', '🧑‍💻': 'user', '🕵': 'search', '🎓': 'grad', '📄': 'file', '📃': 'file', '📑': 'file', '🗑': 'trash', '🧹': 'trash', '✅': 'checkCircle', '✔': 'check',
    '💰': 'wallet', '💸': 'wallet', '💵': 'wallet', '🪙': 'wallet', '🤲': 'wallet', '💬': 'message', '📋': 'clipboard', '📝': 'clipboard', '🧾': 'receipt',
    '📓': 'notebook', '📒': 'notebook', '📕': 'notebook', '📘': 'notebook', '📖': 'book', '📚': 'book', '📌': 'pin', '📍': 'pin', '🔍': 'search', '🔎': 'search',
    '💾': 'save', '🖨': 'printer', '💳': 'card', '🪪': 'id', '🎫': 'card', '📇': 'id', '🔄': 'refresh', '🔁': 'refresh', '♻': 'refresh', '📥': 'download', '⬇': 'download',
    '📤': 'upload', '⬆': 'upload', '⚡': 'zap', '🚀': 'zap', '🎲': 'grid', '🧑‍🏫': 'board', '👩‍🏫': 'board', '👨‍🏫': 'board', '🛡': 'shield', '🔐': 'lock', '🔒': 'lock',
    '🎨': 'palette', '🔑': 'key', '🗃': 'archive', '🗄': 'archive', '🗂': 'folder', '📁': 'folder', '🧮': 'calc', '🕘': 'clock', '⏰': 'clock', '⏱': 'clock', '🕒': 'clock',
    '⏳': 'clock', '⚙': 'settings', '🏠': 'home', '✏': 'edit', '✍': 'edit', '🖋': 'edit', '🔔': 'bell', '⚠': 'alert', '🐞': 'alert', '📱': 'phone', '📞': 'phone',
    '➕': 'plus', '🧠': 'sparkle', '🤖': 'sparkle', '💡': 'sparkle', '📡': 'signal', '🚪': 'logout', '☁': 'cloud', '🛒': 'cart', '🔗': 'link', '🧷': 'link', '📎': 'link',
    '👀': 'eye', '👁': 'eye', '📷': 'camera', '🖼': 'image', '📧': 'mail', '✉': 'mail', '📭': 'mail', '📦': 'box', '🧱': 'box', '🚚': 'box', '🏅': 'award', '🏆': 'award',
    '⭐': 'award', '🎉': 'award', '🎯': 'target', '🩺': 'activity', '🌙': 'moon', '🌓': 'moon', '☀': 'sun', '🎬': 'video', '🔌': 'plug', '❓': 'help', '🚫': 'ban',
    '🧩': 'grid', '🖥': 'board', '📐': 'grid', '⚖': 'chart', '🏷': 'pin', '🪝': 'link', '🔤': 'edit', '🔘': 'dot'
  };
  var DROP = { '👋': 1, '👑': 1, '🟢': 1, '🔹': 1, '🇳': 1, '🇬': 1 };   // decorative only — removed, no icon

  // emoji (pictographs, dingbats, flags; ZWJ sequences, skin tones and variation selectors) — but never plain text
  // glyphs such as → ← ↑ ↓ ✓ ✕ ★ ☰ © ® ™ that the layout uses as typography
  var EMOJI = /(?:[\u{1F000}-\u{1FAFF}]|[\u2600-\u2604\u2606-\u260F\u2613-\u262F\u2638-\u2712\u2714\u2716-\u2767\u2794-\u279B\u279D-\u27A3\u27A5-\u27BF]|[\u23E9-\u23FA]|\u2B50|\u2B55|[\u2B05-\u2B07]\uFE0F|[\u2753-\u2757])(?:\uFE0F|\u200D(?:[\u{1F000}-\u{1FAFF}]|[\u2600-\u27BF])\uFE0F?|[\u{1F3FB}-\u{1F3FF}])*/gu;
  var ONLY_EMOJI = new RegExp('^\\s*(?:' + EMOJI.source + ')\\s*$', 'u');
  var NS = 'http://www.w3.org/2000/svg';
  function key(e) { return e.replace(/\uFE0F/g, '').replace(/[\u{1F3FB}-\u{1F3FF}]/gu, ''); }
  function iconFor(e) { var k = key(e); if (DROP[k]) return null; return MAP[k] || MAP[k.split('\u200D')[0]] || 'dot'; }
  function svg(name) {
    var s = document.createElementNS(NS, 'svg'); s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('aria-hidden', 'true');
    var p = document.createElementNS(NS, 'path'); p.setAttribute('d', P[name] || P.dot); s.appendChild(p); return s;
  }
  function iconSpan(name, extra) { var sp = document.createElement('span'); sp.className = 'pro-ico' + (extra ? ' ' + extra : ''); sp.appendChild(svg(name)); return sp; }

  var SKIP = /^(SCRIPT|STYLE|TEXTAREA|INPUT|CODE|PRE|svg|SVG|path|NOSCRIPT|IFRAME)$/;
  function userContent(el) {
    for (var e = el; e && e !== document.body; e = e.parentElement) {
      if (e.isContentEditable || (e.getAttribute && (e.getAttribute('contenteditable') === 'true' || e.hasAttribute('data-user-content')))) return true;
      var c = e.classList; if (c && (c.contains('parent-message') || c.contains('erp-bub') || c.contains('newsletter-body') || c.contains('word-page') || c.contains('nl-body'))) return true;
      if (e.id === 'newsletterEditor') return true;
    }
    return false;
  }
  var INLINE_ICON_HOST = /^(BUTTON|A)$/;
  function processText(node) {
    var t = node.nodeValue; if (!t || !EMOJI.test(t)) { EMOJI.lastIndex = 0; return; }
    EMOJI.lastIndex = 0;
    var el = node.parentElement; if (!el || SKIP.test(el.tagName) || userContent(el)) return;
    // an element that holds nothing but one emoji is an icon slot → replace with a line icon
    if (el.tagName === 'OPTION') { node.nodeValue = t.replace(EMOJI, '').replace(/^\s+/, '').replace(/ {2,}/g, ' '); return; }
    if (el.childNodes.length === 1 && ONLY_EMOJI.test(t)) {
      var name = iconFor(t.trim());
      if (!name) { node.nodeValue = ''; return; }
      el.textContent = ''; el.appendChild(svg(name)); el.classList.add('pro-ico'); return;
    }
    // leading emoji on a button/link label → small line icon in front of the text
    var lead = t.match(new RegExp('^\\s*(' + EMOJI.source + ')\\s*', 'u'));
    var host = el.closest && el.closest('button,a,.btn,.mx-tab,.abo-btn,.erp-btn');
    var cleaned = t.replace(EMOJI, '').replace(/^\s+/, function (m) { return lead ? '' : m; }).replace(/ {2,}/g, ' ');
    if (lead && host && node === firstText(host)) {
      var n2 = iconFor(lead[1]);
      if (n2 && n2 !== 'dot') node.parentNode.insertBefore(iconSpan(n2, 'pro-ico-inline'), node);
    }
    node.nodeValue = cleaned;
  }
  function firstText(el) {
    var w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, { acceptNode: function (n) { return n.nodeValue.trim() ? 1 : 3; } });
    return w.nextNode();
  }
  function processAttrs(el) {
    ['placeholder', 'title', 'aria-label'].forEach(function (a) {
      var v = el.getAttribute && el.getAttribute(a);
      if (v && EMOJI.test(v)) { EMOJI.lastIndex = 0; el.setAttribute(a, v.replace(EMOJI, '').replace(/^\s+/, '').replace(/ {2,}/g, ' ')); }
      EMOJI.lastIndex = 0;
    });
  }
  function scan(root) {
    if (!root) return;
    if (root.nodeType === 3) { processText(root); return; }
    if (root.nodeType !== 1 || SKIP.test(root.tagName)) return;
    processAttrs(root);
    var w = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, {
      acceptNode: function (n) { if (n.nodeType === 1) return SKIP.test(n.tagName) ? 2 : 1; return 1; }
    });
    var texts = []; var n;
    while ((n = w.nextNode())) { if (n.nodeType === 3) texts.push(n); else processAttrs(n); }
    for (var i = 0; i < texts.length; i++) processText(texts[i]);
  }

  /* ── sidebar: show each page once (owner menus listed boards in two or three groups) ── */
  function dedupeSidebar() {
    var nav = document.querySelector('#aboSidebar .abo-side-nav'); if (!nav) return;
    var seen = {}; var reg = window.ABO && window.ABO.registry;
    nav.querySelectorAll('.abo-side-item').forEach(function (b) {
      var oc = b.getAttribute('onclick') || '';
      var k = oc + '|' + (b.textContent || '').trim();
      var id = (oc.match(/ABO\.go\('([^']+)'\)/) || [])[1];
      var unbuilt = !!(id && reg && typeof reg.hasRenderer === 'function' && reg.get(id) && !reg.hasRenderer(id));
      if (seen[k] || unbuilt) b.classList.add('pro-dup'); else { seen[k] = 1; b.classList.remove('pro-dup'); }
    });
    nav.querySelectorAll('.abo-side-group').forEach(function (g) {
      var visible = g.querySelectorAll('.abo-side-item:not(.pro-dup)').length;
      g.style.display = visible ? '' : 'none';
    });
    accordion(nav);
  }

  /* ── sidebar groups fold open/closed. Tapping a group header toggles ONLY that group, so nothing above the
     header moves and a second tap on the same spot folds it back (the first version closed the other
     groups, which made the list jump under the finger). The group of the current page is opened on
     navigation; groups you opened stay open until you fold them. ── */
  var userOpen = {}; var userClosed = {}; var lastActive = null;
  function groupName(g) { var t = g.querySelector('.abo-side-group-h .txt') || g.querySelector('.abo-side-group-h'); return t ? t.textContent.trim() : ''; }
  function accordion(nav) {
    var groups = Array.prototype.slice.call(nav.querySelectorAll('.abo-side-group'));
    var active = nav.querySelector('.abo-side-item.on:not(.pro-dup)');
    var activeName = active && active.closest('.abo-side-group') ? groupName(active.closest('.abo-side-group')) : null;
    if (activeName && activeName !== lastActive) { delete userClosed[activeName]; lastActive = activeName; }
    var anyOpen = Object.keys(userOpen).length > 0;
    groups.forEach(function (g, i) {
      var h = g.querySelector('.abo-side-group-h'); if (!h) return;
      var name = groupName(g);
      var open = !!userOpen[name] || (name === activeName && !userClosed[name]) || (!activeName && !anyOpen && i === 0 && !userClosed[name]);
      g.classList.toggle('pro-collapsed', !open);
      h.setAttribute('aria-expanded', String(open));
      if (h.__proBound) return; h.__proBound = true;
      h.setAttribute('role', 'button'); h.tabIndex = 0;
      var toggle = function (e) {
        if (e) { e.preventDefault(); e.stopPropagation(); }
        var n = groupName(g); var opening = g.classList.contains('pro-collapsed');
        if (opening) { userOpen[n] = 1; delete userClosed[n]; } else { delete userOpen[n]; userClosed[n] = 1; }
        g.classList.toggle('pro-collapsed', !opening);
        h.setAttribute('aria-expanded', String(opening));
      };
      h.addEventListener('click', toggle);
      h.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') toggle(e); });
    });
  }

  var pending = new Set(); var scheduled = false;
  function flush() {
    scheduled = false;
    var list = Array.from(pending); pending.clear();
    observer.disconnect();
    try { list.forEach(scan); dedupeSidebar(); syncBurger(); } catch (e) { /* never break the app */ }
    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
  }
  var observer = new MutationObserver(function (muts) {
    muts.forEach(function (m) {
      if (m.type === 'characterData') pending.add(m.target);
      else m.addedNodes.forEach(function (n) { pending.add(n); });
    });
    if (!scheduled) { scheduled = true; (window.requestAnimationFrame || setTimeout)(flush); }
  });
  /* ── phone/tablet menu drawer (≤ 1100 px): opens AND closes ──────────────────────────────────────────
     The original drawer could be opened but never closed: its dark overlay was a CSS pseudo-element that
     cannot receive taps, and the drawer covered the menu button. Now the drawer opens below the top bar,
     the menu button stays visible and turns into a close button, and tapping outside, pressing Esc,
     swiping left or choosing a page all close it. */
  var drawerQuery = window.matchMedia ? window.matchMedia('(max-width: 1100px)') : { matches: false };
  function drawerOpen() { return document.body.classList.contains('sidebar-open'); }
  function setDrawer(open) {
    var top = document.getElementById('aboTopbar');
    if (open && top) document.documentElement.style.setProperty('--pro-top', Math.max(0, Math.round(top.getBoundingClientRect().bottom)) + 'px');
    document.body.classList.toggle('sidebar-open', !!open);
    syncBurger();
  }
  function syncBurger() {
    var b = document.querySelector('.abo-topbar-burger'); if (!b) return;
    var open = drawerOpen();
    if (b.getAttribute('data-pro-state') !== String(open)) {
      b.setAttribute('data-pro-state', String(open));
      b.textContent = ''; b.appendChild(svg(open ? 'close' : 'menu'));
      b.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
      b.setAttribute('aria-expanded', String(open));
    }
    var side = document.getElementById('aboSidebar');
    if (side && !side.querySelector('.pro-drawer-close')) {
      var head = side.querySelector('.abo-side-head') || side.firstElementChild;
      if (head) {
        var x = document.createElement('button'); x.type = 'button'; x.className = 'pro-drawer-close'; x.setAttribute('aria-label', 'Close navigation');
        x.appendChild(svg('close')); x.addEventListener('click', function () { setDrawer(false); });
        head.appendChild(x);
      }
    }
  }
  function setupDrawer() {
    if (!document.querySelector('.pro-backdrop')) {
      var back = document.createElement('div'); back.className = 'pro-backdrop'; back.setAttribute('aria-hidden', 'true');
      back.addEventListener('click', function () { setDrawer(false); });
      document.body.appendChild(back);
    }
    var sh = window.ABO && window.ABO.shell;
    if (sh && !sh.__proDrawer) { sh.__proDrawer = true; sh.toggleMobile = function () { setDrawer(!drawerOpen()); }; }
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && drawerOpen()) setDrawer(false); });
    // choosing a page inside the drawer closes it (also covers items the app does not close itself)
    document.addEventListener('click', function (e) {
      if (!drawerQuery.matches || !drawerOpen()) return;
      var it = e.target.closest && e.target.closest('#aboSidebar .abo-side-item, #aboSidebar .abo-side-search');
      if (it) setTimeout(function () { setDrawer(false); }, 0);
    }, true);   // capture: the app re-renders the menu inside its own click handler
    // swipe the drawer to the left to close it
    var sx = null, sy = null;
    document.addEventListener('touchstart', function (e) { if (!drawerOpen() || !e.target.closest || !e.target.closest('#aboSidebar, .pro-backdrop')) return; sx = e.touches[0].clientX; sy = e.touches[0].clientY; }, { passive: true });
    document.addEventListener('touchend', function (e) {
      if (sx === null) return; var t = e.changedTouches[0]; var dx = t.clientX - sx, dy = Math.abs(t.clientY - sy); sx = null;
      if (dx < -60 && dy < 60) setDrawer(false);
    }, { passive: true });
    // leaving phone width with the drawer open must not leave the page scroll-locked
    if (drawerQuery.addEventListener) drawerQuery.addEventListener('change', function (q) { if (!q.matches) setDrawer(false); });
    new MutationObserver(syncBurger).observe(document.body, { attributes: true, attributeFilter: ['class'] });
  }

  /* classic editions (premium / connected): the dot-button dropdown also closes with Esc, and the button
     reports its state to screen readers */
  function setupClassicMenu() {
    var dd = document.getElementById('menuDropdown'), btn = document.getElementById('menuDotBtn');
    if (!dd || !btn) return;
    btn.setAttribute('aria-haspopup', 'true'); btn.setAttribute('aria-controls', 'menuDropdown');
    var sync = function () { btn.setAttribute('aria-expanded', dd.classList.contains('open') ? 'true' : 'false'); };
    sync(); new MutationObserver(sync).observe(dd, { attributes: true, attributeFilter: ['class'] });
    document.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape' || !dd.classList.contains('open')) return;
      if (typeof window.closeHeaderMenu === 'function') window.closeHeaderMenu(); else dd.classList.remove('open');
      try { btn.focus(); } catch (x) {}
    });
  }
  /* ───────── Back button on every page (+ phone / browser back, Backspace) ─────────
     Keeps an in-app history of the pages opened. The ← Back button, the phone's back button, the browser's back and
     the Backspace key (when not typing) all go to the previous page. Open pop-ups or the menu are closed first. With
     no history yet, Back goes to the Dashboard. */
  var NAV = { stack: [], going: false, pushed: 0, hist: true, home: null, mode: null };
  function navMode() { return (window.ABO && window.ABO.bus && window.ABO.render && document.getElementById('erpHost')) ? 'abo' : 'classic'; }
  function navLabel(id) {
    if (!id) return '';
    if (NAV.mode === 'abo') { try { var m = window.ABO.registry && window.ABO.registry.get(id); if (m && m.label) return m.label.replace(EMOJI, '').trim(); } catch (e) { /* ignore */ } }
    var b = document.querySelector('.menu-item[data-page="' + id + '"], .nav-btn[data-page="' + id + '"]');
    return b ? b.textContent.replace(EMOJI, '').trim() : id.replace(/[-_]/g, ' ').replace(/^./, function (c) { return c.toUpperCase(); });
  }
  function signedIn() { var app = document.getElementById('app'); return !!(app && !app.classList.contains('hidden')); }
  function navGo(id) {
    NAV.going = true; setTimeout(function () { NAV.going = false; }, 0);
    try { if (NAV.mode === 'abo') window.ABO.go(id); else if (typeof window.showPage === 'function') window.showPage(id); } catch (e) { NAV.going = false; }
  }
  function navPush(id) {
    if (!id || !signedIn()) return;
    var top = NAV.stack[NAV.stack.length - 1];
    if (NAV.going) { NAV.going = false; if (top !== id) { NAV.stack.push(id); } syncBack(); return; }
    if (top === id) return;
    if (!NAV.stack.length) { NAV.home = NAV.home || id; NAV.stack.push(id); try { history.replaceState({ aboNav: 0 }, ''); } catch (e) { NAV.hist = false; } syncBack(); return; }
    NAV.stack.push(id); if (NAV.stack.length > 60) NAV.stack.shift();
    if (NAV.hist) { try { history.pushState({ aboNav: NAV.stack.length }, ''); NAV.pushed++; } catch (e) { NAV.hist = false; } }
    syncBack();
  }
  // close whatever is on top: pop-up, alerts, search, phone menu, classic dropdown
  function closeOverlay() {
    var mh = document.getElementById('erpModalHost');
    if (mh && !mh.classList.contains('hidden') && mh.innerHTML.trim()) { try { window.erpModalClose(); } catch (e) { mh.innerHTML = ''; mh.classList.add('hidden'); } return true; }
    var pal = document.querySelector('.abo-palette.open, .abo-palette-wrap.open, #aboPalette.open');
    if (pal) { try { window.ABO.palette.close(); } catch (e) { pal.classList.remove('open'); } return true; }
    var pop = document.getElementById('aboAlertPop');
    if (pop && (pop.classList.contains('open') || pop.classList.contains('show'))) { pop.classList.remove('open'); pop.classList.remove('show'); return true; }
    if (drawerOpen()) { setDrawer(false); return true; }
    var dd = document.getElementById('menuDropdown');
    if (dd && dd.classList.contains('open')) { try { window.closeHeaderMenu(); } catch (e) { dd.classList.remove('open'); } return true; }
    return false;
  }
  function doBack(fromPop) {
    if (!signedIn()) return false;
    if (closeOverlay()) { if (fromPop && NAV.hist) { try { history.pushState({ aboNav: NAV.stack.length }, ''); NAV.pushed++; } catch (e) { /* ignore */ } } return true; }
    if (NAV.stack.length >= 2) { NAV.stack.pop(); navGo(NAV.stack[NAV.stack.length - 1]); syncBack(); return true; }
    var cur = NAV.stack[0], home = NAV.home || (NAV.mode === 'abo' ? 'dashboard' : 'home');
    if (cur !== home) { NAV.stack = [home]; navGo(home); syncBack(); return true; }
    return false;
  }
  function goBack() {
    if (!signedIn()) return;
    var hasOverlay = !!(document.querySelector('#erpModalHost:not(.hidden) .erp-overlay') || drawerOpen() || document.querySelector('#menuDropdown.open'));
    if (NAV.hist && NAV.pushed > 0 && !hasOverlay && NAV.stack.length >= 2) { history.back(); return; }   // popstate does the work and keeps the browser in step
    doBack(false);
  }
  function canBack() { var home = NAV.home || (NAV.mode === 'abo' ? 'dashboard' : 'home'); return NAV.stack.length >= 2 || (NAV.stack.length === 1 && NAV.stack[0] !== home); }
  function backTarget() { var home = NAV.home || (NAV.mode === 'abo' ? 'dashboard' : 'home'); return NAV.stack.length >= 2 ? NAV.stack[NAV.stack.length - 2] : home; }
  function backButton() {
    var b = document.createElement('button');
    b.type = 'button'; b.className = 'pro-back'; b.id = 'proBack';
    b.innerHTML = iconHtml('arrow-left', 'pro-back-ico') + '<span>Back</span>';
    b.addEventListener('click', function (e) { e.preventDefault(); goBack(); });
    return b;
  }
  function placeBack() {
    if (!signedIn()) return;
    var bar = document.getElementById('aboTopbar'), btn = document.getElementById('proBack');
    if (bar && !bar.__proBackObs) { bar.__proBackObs = true; new MutationObserver(function () { if (!document.getElementById('proBack') || document.getElementById('proBack').parentNode !== bar) placeBack(); }).observe(bar, { childList: true }); }
    if (bar) {
      if (btn && btn.parentNode === bar) return;
      if (btn) btn.remove();
      var burger = bar.querySelector('.abo-topbar-burger'); btn = backButton();
      if (burger && burger.nextSibling) bar.insertBefore(btn, burger.nextSibling); else bar.insertBefore(btn, bar.firstChild);
    } else {
      var head = document.querySelector('#app .app-header'); if (!head) return;
      if (btn && btn.parentNode === head) return;
      if (btn) btn.remove();
      btn = backButton(); head.insertBefore(btn, head.firstChild);
    }
    syncBack();
  }
  // a round ← arrow beside the page title (every page except the first), like a phone app
  function pageRoot() {
    var host = document.getElementById('erpHost');
    if (NAV.mode === 'abo' && host && host.offsetParent !== null) return host;
    var pg = [].filter.call(document.querySelectorAll('.page:not(.hidden)'), function (x) { return x.id !== 'page-erp' && x.offsetParent !== null; })[0];
    return pg || host;
  }
  var titleTimer = null;
  function placeTitleBack() {
    clearTimeout(titleTimer);
    titleTimer = setTimeout(function () {
      var root = signedIn() ? pageRoot() : null, need = !!root && canBack(), target = null, cur = NAV.stack[NAV.stack.length - 1];
      if (need) {
        target = root.querySelector('.erp-page-head h2, .abo-page-head h1, .abo-page-head h2, h1, h2');
        if (!target) {          // classic pages and pages with no title: a title row (arrow + page name) above the content
          var row = root.querySelector(':scope .pro-back-row');
          if (!row) { row = document.createElement('div'); row.className = 'pro-back-row'; row.innerHTML = '<h2 class="pro-back-title"></h2>'; var first = root.firstElementChild; (first && first.classList.contains('erp-page') ? first : root).insertBefore(row, (first && first.classList.contains('erp-page') ? first.firstChild : root.firstChild)); }
          row.querySelector('.pro-back-title').textContent = navLabel(cur);
          target = row.querySelector('.pro-back-title');
        }
      }
      [].forEach.call(document.querySelectorAll('.pro-title-back'), function (o) { if (!need || o.parentNode !== target) o.remove(); });
      [].forEach.call(document.querySelectorAll('.pro-back-row'), function (r) { if (!need || !root.contains(r) || (target && !r.contains(target))) r.remove(); });
      if (!need || !target) return;
      var btn = target.querySelector(':scope > .pro-title-back');
      if (!btn) {
        btn = document.createElement('button'); btn.type = 'button'; btn.className = 'pro-title-back';
        btn.innerHTML = iconHtml('arrow-left', 'pro-back-ico');
        btn.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); goBack(); });
        target.insertBefore(btn, target.firstChild); target.classList.add('pro-has-back');
      }
      var to = navLabel(backTarget()); btn.title = 'Back to ' + to; btn.setAttribute('aria-label', 'Back to ' + to);
    }, 30);
  }
  function syncBack() {
    placeTitleBack();
    var b = document.getElementById('proBack'); if (!b) return;
    var ok = canBack(), to = navLabel(backTarget());
    b.disabled = !ok; b.setAttribute('aria-disabled', ok ? 'false' : 'true');
    b.title = ok ? 'Back to ' + to + ' (Backspace)' : 'You are on the first page';
    b.setAttribute('aria-label', ok ? 'Back to ' + to : 'Back');
  }
  function setupBack() {
    NAV.mode = navMode();
    if (NAV.mode === 'abo') {
      // every route the router finishes (dashboard included), plus modules mounted directly
      var onRoute = function (p) { navPush(p && p.id); setTimeout(placeBack, 0); };
      try { window.ABO.bus.on((window.ABO.EVENTS && window.ABO.EVENTS.PAGE_RENDERED) || 'page:rendered', onRoute, 'pro:back-route'); } catch (e) { /* ignore */ }
      try { window.ABO.bus.on('module:mounted', onRoute, 'pro:back-history'); } catch (e) { /* ignore */ }
    } else if (typeof window.showPage === 'function' && !window.showPage.__proBack) {
      var sp = window.showPage;
      window.showPage = function (id) { var r = sp.apply(this, arguments); var v = document.querySelector('.page:not(.hidden)'); navPush(v ? v.id.replace(/^page-/, '') : id); placeBack(); return r; };
      window.showPage.__proBack = true;
    }
    // the top bar is redrawn often: put the button back whenever it disappears
    var keep = new MutationObserver(function () { if (signedIn() && !document.getElementById('proBack')) placeBack(); });
    keep.observe(document.body, { childList: true, subtree: false });
    window.addEventListener('popstate', function () { if (NAV.pushed > 0) NAV.pushed--; doBack(true); });
    document.addEventListener('keydown', function (e) {
      if (e.defaultPrevented || !signedIn()) return;
      var t = e.target, editable = t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName));
      if (e.key === 'Backspace' && !editable && !e.ctrlKey && !e.metaKey && !e.altKey) { e.preventDefault(); goBack(); }
    });
    var hostObs = function () { var host = document.getElementById('erpHost'); if (host && !host.__proTitleObs) { host.__proTitleObs = true; new MutationObserver(placeTitleBack).observe(host, { childList: true }); } };
    hostObs(); setTimeout(hostObs, 1500);
    // the landing page after sign-in is drawn without a router event: record it as the first page
    var ea = window.enterApp;
    if (typeof ea === 'function' && !ea.__proBack) {
      window.enterApp = function () {
        NAV.stack = []; NAV.home = null; NAV.pushed = 0;
        var r = ea.apply(this, arguments);
        setTimeout(function () {
          if (!signedIn() || NAV.stack.length) return;
          var c = NAV.mode === 'abo' ? ((window.ABO.render.current && window.ABO.render.current()) || 'dashboard') : (((document.querySelector('.page:not(.hidden)') || {}).id || '').replace(/^page-/, '') || 'home');
          navPush(c); placeBack(); hostObs();
        }, 0);
        return r;
      };
      window.enterApp.__proBack = true;
    }
    // signing out starts a fresh history
    var lo = window.logoutUser;
    if (typeof lo === 'function' && !lo.__proBack) { window.logoutUser = function () { NAV.stack = []; NAV.home = null; NAV.pushed = 0; var r = lo.apply(this, arguments); var b = document.getElementById('proBack'); if (b) b.remove(); return r; }; window.logoutUser.__proBack = true; }
    setTimeout(function () { if (signedIn()) { var cur = NAV.mode === 'abo' ? (window.ABO.render.current && window.ABO.render.current()) : ((document.querySelector('.page:not(.hidden)') || {}).id || '').replace(/^page-/, ''); if (cur && !NAV.stack.length) navPush(cur); placeBack(); } }, 800);
  }
  function start() {
    setupDrawer(); setupClassicMenu(); setupBack();
    scan(document.body); dedupeSidebar(); syncBurger();
    document.title = document.title.replace(EMOJI, '').trim();
    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
  function iconHtml(name, cls) { var sp = iconSpan(name, cls); var d = document.createElement('div'); d.appendChild(sp); return d.innerHTML; }
  window.ABO_PRO_SKIN = { scan: scan, icon: iconHtml, setDrawer: setDrawer, back: goBack, history: function () { return NAV.stack.slice(); }, version: '1.2' };
})();
/* ==========================================================================================
   Phase 6 quick fix: the browser's grey "alert" pop-up is replaced by the app's own message box.
   Every alert() in the app is a final message (nothing runs after it waiting for the click), so a non-blocking box is
   safe. The box is accessible (role="alertdialog", focus on OK, Escape/Enter close). confirm() and prompt() stay as
   they are, because the app's code waits for their answer.
   ========================================================================================== */
(function () {
  'use strict';
  if (window.__aboAlertBox) return; window.__aboAlertBox = true;
  var nativeAlert = window.alert ? window.alert.bind(window) : null;
  var queue = [], open = false;
  function show(msg) {
    if (!document.body) { if (nativeAlert) nativeAlert(msg); return; }
    if (open) { queue.push(msg); return; }
    open = true;
    var back = document.createElement('div'); back.className = 'abo-msg-back';
    var box = document.createElement('div'); box.className = 'abo-msg'; box.setAttribute('role', 'alertdialog'); box.setAttribute('aria-modal', 'true');
    var id = 'aboMsg' + Date.now(); box.setAttribute('aria-describedby', id);
    var p = document.createElement('p'); p.id = id; p.textContent = String(msg == null ? '' : msg);
    var ok = document.createElement('button'); ok.type = 'button'; ok.className = 'abo-msg-ok'; ok.textContent = 'OK';
    var prev = document.activeElement;
    function close() { document.removeEventListener('keydown', key, true); back.remove(); open = false; try { if (prev && prev.focus) prev.focus(); } catch (e) { /* ignore */ } if (queue.length) show(queue.shift()); }
    function key(e) { if (e.key === 'Escape' || e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); close(); } else if (e.key === 'Tab') { e.preventDefault(); ok.focus(); } }
    ok.addEventListener('click', close);
    box.appendChild(p); box.appendChild(ok); back.appendChild(box); document.body.appendChild(back);
    document.addEventListener('keydown', key, true);
    setTimeout(function () { ok.focus(); }, 0);
  }
  window.alert = function (msg) { show(msg); };
  window.ABO_ALERT = { show: show, native: nativeAlert };
})();
