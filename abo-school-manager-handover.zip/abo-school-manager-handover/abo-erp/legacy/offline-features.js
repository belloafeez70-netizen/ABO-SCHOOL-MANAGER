/* ==========================================================================================
   A.B.O. feature pack for the OFFLINE edition (school_broadsheet_manager_bopc_erp.html)
   Inspired by what schools use in Klacify, built on this app's own data and module system:

     • Lesson Notes        write → submit → approve / return, weekly coverage grid, template draft, print
     • Learners' Birthdays today / this week / this month, WhatsApp wishes, printable cards, staff too
     • Live Calendar       ticking clock, term week, countdowns, today's agenda, holidays + birthdays on the grid
     • Staff Clock-in      clock in / out with lateness against the resumption time, daily + monthly report
     • Live Class Monitor  which class is being taught right now (timetable + staff clock-in), idle classes flagged

   Also repairs a defect in the base app: modules of kind "records" (Parents & Guardians, Staff Directory,
   Digital Document Archive, Teacher Subjects, Learning Resources, Video Lessons, Live Classes, Devices, Imprest,
   Chart of Accounts) were registered without a screen and opened blank. They now open their record tables.

   Everything is stored inside the school's own data (schoolData.erp) and saved with the normal save.
   ========================================================================================== */
(function () {
  'use strict';
  if (window.__aboFeatures) return; window.__aboFeatures = true;
  if (typeof window.erpData !== 'function' || !window.ERP_MODULES || !window.ERPRender) return;

  /* ───────────────────────── helpers ───────────────────────── */
  /* the base app declares these with top-level `let`, so they are globals but NOT properties of window */
  function G(name) { if (window.aboGlobalGet) return window.aboGlobalGet(name); try { return (0, eval)('typeof ' + name + ' !== "undefined" ? ' + name + ' : undefined'); } catch (e) { return undefined; } }   // CSP-safe accessor first (no eval)
  var settings = function () { return G('globalSettings') || {}; };
  var E = function (v) { return window.erpEsc(v); };
  var A = function (v) { return window.erpAttr(v); };
  var D = function () { return window.erpData(); };
  var save = function () { window.erpSave(); };
  var can = function () { return window.erpCan(); };                    // owner / admin
  var role = function () { return window.erpRole(); };
  var me = function () { return window.erpUser(); };
  var toast = function (m) { try { window.showToast(m); } catch (e) { /* ignore */ } };
  var ico = function (n) { return (window.ABO_PRO_SKIN && window.ABO_PRO_SKIN.icon) ? window.ABO_PRO_SKIN.icon(n, 'pro-ico-inline') : ''; };
  var pad = function (n) { return (n < 10 ? '0' : '') + n; };
  function ymd(d) { d = d || new Date(); return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function parseYmd(s) { var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(s || '')); return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null; }
  function hm(d) { d = d || new Date(); return pad(d.getHours()) + ':' + pad(d.getMinutes()); }
  function mins(t) { var m = /^(\d{1,2})[:.](\d{2})\s*(am|pm)?/i.exec(String(t || '').trim()); if (!m) return null; var h = +m[1], mm = +m[2]; if (m[3]) { if (/pm/i.test(m[3]) && h < 12) h += 12; if (/am/i.test(m[3]) && h === 12) h = 0; } return h * 60 + mm; }
  function fmtDate(s, opt) { var d = typeof s === 'string' ? parseYmd(s) : s; return d ? d.toLocaleDateString('en-NG', opt || { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' }) : '—'; }
  function uid() { return 'n' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
  function host() { return document.getElementById('erpHost'); }
  function current() { try { return window.ABO && window.ABO.render && window.ABO.render.current ? window.ABO.render.current() : window.erpActiveModule; } catch (e) { return null; } }
  function rerender(id) { var h = host(); if (h && window.ERPRender[id]) h.innerHTML = window.ERPRender[id](); }
  function badge(text, tone) { return '<span class="erp-badge ' + (tone || '') + '">' + E(text) + '</span>'; }
  function field(label, inner, wide) { return '<div class="erp-field' + (wide ? ' w2' : '') + '"><label>' + E(label) + '</label>' + inner + '</div>'; }
  function input(id, val, type, ph) { return '<input class="erp-input" id="' + id + '" type="' + (type || 'text') + '" value="' + A(val || '') + '" placeholder="' + A(ph || '') + '">'; }
  function textarea(id, val, rows, ph) { return '<textarea class="erp-textarea" id="' + id + '" rows="' + (rows || 3) + '" placeholder="' + A(ph || '') + '">' + E(val || '') + '</textarea>'; }
  function select(id, list, val, ph) { return '<select class="erp-select" id="' + id + '">' + (ph ? '<option value="">' + E(ph) + '</option>' : '') + window.erpOpts(list, val) + '</select>'; }
  function val(id) { var e = document.getElementById(id); return e ? String(e.value || '').trim() : ''; }
  function classNames() { return (D().classes || []).map(function (c) { return c.name; }).filter(Boolean); }
  function subjectNames() {
    var out = [];
    try { (G('subjects') || []).forEach(function (s) { var n = typeof s === 'string' ? s : (s && (s.name || s.subject)); if (n && out.indexOf(n) < 0) out.push(n); }); } catch (e) { /* ignore */ }
    try { (D().subjects || []).forEach(function (s) { var n = typeof s === 'string' ? s : (s && s.name); if (n && out.indexOf(n) < 0) out.push(n); }); } catch (e) { /* ignore */ }
    return out;
  }
  function schoolName() { try { return window.getCurrentSchoolName(); } catch (e) { return 'School'; } }
  function printDoc(title, body) {
    var w = window.open('', '_blank'); if (!w) { toast('Allow pop-ups to print.'); return; }
    w.document.write('<html><head><meta charset="utf-8"><title>' + E(title) + '</title><style>' +
      'body{font-family:Inter,Segoe UI,Arial,sans-serif;color:#0f172a;padding:28px;max-width:820px;margin:auto}h1{font-size:20px;margin:0}' +
      '.sub{color:#475569;font-size:12px;margin:4px 0 16px}.hd{border-bottom:2px solid #0f172a;padding-bottom:10px;margin-bottom:14px}' +
      'table{width:100%;border-collapse:collapse;font-size:12.5px}td,th{border:1px solid #cbd5e1;padding:6px 8px;text-align:left;vertical-align:top}' +
      'th{background:#f1f5f9;width:22%}h3{font-size:12px;text-transform:uppercase;letter-spacing:.06em;margin:16px 0 4px;color:#0f766e}' +
      'p{white-space:pre-wrap;margin:0;font-size:13px;line-height:1.55}.sig{display:flex;justify-content:space-between;margin-top:40px;font-size:12px}' +
      '.sig div{border-top:1px solid #0f172a;padding-top:4px;min-width:200px;text-align:center}@media print{body{padding:0}}</style></head><body>' + body +
      '<script>setTimeout(function(){window.print()},300)<\/script></body></html>');
    w.document.close();
  }

  /* every learner in the school with class + date of birth + guardian contact */
  function allLearners() {
    var out = [], seen = {};
    function push(cn, arr) {
      (arr || []).forEach(function (s) {
        if (!s || !(s.name || '').trim()) return;
        var k = s.name.trim().toLowerCase() + '|' + cn; if (seen[k]) return; seen[k] = 1;
        out.push({ name: s.name.trim(), className: cn, dob: s.dob || '', gender: s.gender || '', phone: s.parentWhatsapp || s.parentPhone || '', email: s.parentEmail || '' });
      });
    }
    try {
      var L = window.ABO && window.ABO.learners;
      if (L && L.store) {
        var active = L.active ? L.active() : null; var store = L.store() || {};
        Object.keys(store).forEach(function (k) { if (k !== active) push(k, store[k]); });
        push(active || (settings().className) || '', window.ABO.state ? window.ABO.state.get('students') : G('students'));
      } else push((settings().className) || '', window.students);
    } catch (e) { push('', G('students')); }
    return out;
  }
  function staffList() {
    var out = [], seen = {};
    function add(name, roleName, dob, phone) { name = String(name || '').trim(); if (!name) return; var k = name.toLowerCase(); if (seen[k]) { if (dob && !seen[k].dob) seen[k].dob = dob; return; } seen[k] = { name: name, role: roleName || 'Staff', dob: dob || '', phone: phone || '' }; out.push(seen[k]); }
    (D().staff || []).forEach(function (s) { add(s.name, s.role, s.dob, s.phone); });
    try { (G('userAccounts') && G('userAccounts').teachers || []).forEach(function (t) { add(t.name || t.loginId, 'Teacher'); }); } catch (e) { /* ignore */ }
    try { (G('userAccounts') && G('userAccounts').admins || []).forEach(function (t) { add(t.name || t.loginId, 'School Admin'); }); } catch (e) { /* ignore */ }
    return out.sort(function (a, b) { return a.name.localeCompare(b.name); });
  }
  function waLink(phone, text) {
    var p = String(phone || '').replace(/\D/g, '');
    if (/^0\d{10}$/.test(p)) p = '234' + p.slice(1);
    return 'https://wa.me/' + (p.length >= 10 ? p : '') + '?text=' + encodeURIComponent(text);
  }

  /* register a module in both the legacy table (page header) and the module registry (menu + routing) */
  function addModule(id, meta, render) {
    var prev = window.ERP_MODULES[id] || {};
    window.ERP_MODULES[id] = Object.assign({}, prev, meta, { kind: 'special' });
    window.ERPRender[id] = render;
    try {
      var R = window.ABO && window.ABO.registry;
      if (R) {
        var m = R.get(id);
        if (m) { Object.assign(m, { label: meta.label, section: meta.section, roles: meta.roles, desc: meta.desc, kind: 'special', hidden: false }); R.setRenderer(id, render); }
        else R.register({ id: id, label: meta.label, icon: meta.icon, section: meta.section, kind: 'special', roles: meta.roles, desc: meta.desc, order: meta.order || 500, keywords: meta.keywords || [] }, render);
      }
    } catch (e) { /* menu will still reach it through the legacy router */ }
  }

  /* ───────────────────────── repair: record modules that opened blank ───────────────────────── */
  (function repairRecords() {
    var R = window.ABO && window.ABO.registry; if (!R || typeof R.setRenderer !== 'function' || typeof window.erpRecordsView !== 'function') return;
    Object.keys(window.ERP_MODULES).forEach(function (id) {
      var m = window.ERP_MODULES[id];
      if (m && m.kind === 'records' && !window.ERPRender[id] && R.get(id) && !(R.hasRenderer && R.hasRenderer(id))) {
        R.setRenderer(id, function () { return window.erpRecordsView(id); });
      }
    });
  })();
  // staff records get a date of birth so staff birthdays can be shown too
  try { var sf = window.ERP_MODULES.staff && window.ERP_MODULES.staff.fields; if (sf && !sf.some(function (f) { return f.k === 'dob'; })) sf.splice(2, 0, { k: 'dob', l: 'Date of Birth', t: 'date' }); } catch (e) { /* ignore */ }

  /* ═════════════════════════ 1. LESSON NOTES ═════════════════════════ */
  var LN = { filter: 'all', cls: '', subject: '', week: '', q: '' };
  function notes() {
    var d = D(); if (!Array.isArray(d.lessonNotes)) d.lessonNotes = [];
    // one-time move of rows written by the old generic form (it saved them in a different list)
    if (Array.isArray(d['lesson-records']) && d['lesson-records'].length) {
      d['lesson-records'].forEach(function (r) { d.lessonNotes.push(Object.assign({ id: uid(), createdAt: new Date().toISOString() }, r)); });
      d['lesson-records'] = []; save();
    }
    d.lessonNotes.forEach(function (n) { if (!n.id) n.id = uid(); if (!n.status) n.status = 'Draft'; });
    return d.lessonNotes;
  }
  var mine = function (n) { return (n.teacher || '').toLowerCase() === me().toLowerCase(); };
  var editable = function (n) { return can() || (mine(n) && (n.status === 'Draft' || n.status === 'Returned')); };
  var TONE = { Draft: '', Submitted: 'gold', Approved: 'green', Returned: 'rose' };

  function lessonNotesView() {
    var all = notes(), isStaffHead = can();
    var list = all.filter(function (n) {
      if (role() === 'teacher' && !isStaffHead && !mine(n) && n.status !== 'Approved') return false;
      if (LN.filter === 'mine' && !mine(n)) return false;
      if (LN.filter === 'review' && n.status !== 'Submitted') return false;
      if (['Draft', 'Approved', 'Returned'].indexOf(LN.filter) >= 0 && n.status !== LN.filter) return false;
      if (LN.cls && n.className !== LN.cls) return false;
      if (LN.subject && n.subject !== LN.subject) return false;
      if (LN.week && String(n.week) !== String(LN.week)) return false;
      if (LN.q && (n.topic + ' ' + (n.subtopic || '') + ' ' + (n.teacher || '')).toLowerCase().indexOf(LN.q.toLowerCase()) < 0) return false;
      return true;
    }).sort(function (a, b) { return (+b.week || 0) - (+a.week || 0) || String(b.updatedAt || b.createdAt || '').localeCompare(String(a.updatedAt || a.createdAt || '')); });
    var c = function (s) { return all.filter(function (n) { return n.status === s; }).length; };
    var filters = [['all', 'All notes'], ['mine', 'My notes'], ['review', 'Awaiting review'], ['Draft', 'Drafts'], ['Approved', 'Approved'], ['Returned', 'Returned']];
    var rows = list.map(function (n) {
      var i = all.indexOf(n);
      var acts = '<button class="erp-btn xs ghost" onclick="proLN.view(' + i + ')">View</button>';
      if (editable(n)) acts += '<button class="erp-btn xs ghost" onclick="proLN.edit(' + i + ')">Edit</button>';
      if (mine(n) && (n.status === 'Draft' || n.status === 'Returned')) acts += '<button class="erp-btn xs ghost" onclick="proLN.submit(' + i + ')">Submit</button>';
      if (isStaffHead && n.status === 'Submitted') acts += '<button class="erp-btn xs primary" onclick="proLN.review(' + i + ')">Review</button>';
      return '<tr><td class="num">' + E(n.week || '—') + '</td><td>' + E(fmtDate(n.date, { day: 'numeric', month: 'short' })) + '</td><td>' + E(n.className || '—') + '</td><td>' + E(n.subject || '—') +
        '</td><td><b>' + E(n.topic || 'Untitled') + '</b>' + (n.subtopic ? '<small class="pro-sub">' + E(n.subtopic) + '</small>' : '') + '</td><td>' + E(n.teacher || '—') + '</td><td>' + badge(n.status === 'Submitted' ? 'Awaiting review' : n.status, TONE[n.status]) +
        '</td><td class="pro-acts">' + acts + '</td></tr>';
    }).join('');
    return window.erpWrap('lesson-records',
      window.erpStats([{ label: 'Lesson notes', value: all.length }, { label: 'Awaiting review', value: c('Submitted'), color: c('Submitted') ? '#b45309' : '' },
        { label: 'Approved', value: c('Approved'), color: '#047857' }, { label: 'Returned for correction', value: c('Returned'), color: c('Returned') ? '#b91c1c' : '' }]) +
      '<div class="erp-toolbar pro-wrap">' +
        '<select class="erp-select pro-w" onchange="proLN.set(\'filter\',this.value)">' + filters.map(function (f) { return '<option value="' + f[0] + '"' + (LN.filter === f[0] ? ' selected' : '') + '>' + f[1] + '</option>'; }).join('') + '</select>' +
        '<select class="erp-select pro-w" onchange="proLN.set(\'cls\',this.value)"><option value="">All classes</option>' + window.erpOpts(classNames(), LN.cls) + '</select>' +
        '<select class="erp-select pro-w" onchange="proLN.set(\'subject\',this.value)"><option value="">All subjects</option>' + window.erpOpts(subjectNames(), LN.subject) + '</select>' +
        '<select class="erp-select pro-w-s" onchange="proLN.set(\'week\',this.value)"><option value="">Any week</option>' + window.erpOpts(Array.from({ length: 14 }, function (_, k) { return String(k + 1); }), LN.week) + '</select>' +
        '<input class="erp-input pro-w" placeholder="Search topic or teacher" value="' + A(LN.q) + '" onchange="proLN.set(\'q\',this.value)">' +
        '<div class="grow"></div>' +
        (window.erpCanEdit() ? '<button class="erp-btn primary" onclick="proLN.edit(-1)">' + ico('plus') + 'New lesson note</button>' : '') +
      '</div>' +
      '<div class="erp-panel"><div class="erp-panel-b" style="padding:0"><div class="erp-table-wrap"><table class="erp-table"><thead><tr><th class="num">Week</th><th>Date</th><th>Class</th><th>Subject</th><th>Topic</th><th>Teacher</th><th>Status</th><th></th></tr></thead><tbody>' +
        (rows || '<tr><td colspan="8"><div class="erp-empty">' + (all.length ? 'No lesson note matches these filters.' : 'No lesson note yet. Use “New lesson note” to write the first one.') + '</div></td></tr>') +
      '</tbody></table></div></div></div>' + coverage(all));
  }
  function coverage(all) {
    var cls = LN.cls || classNames()[0] || ''; if (!cls) return '';
    var subs = subjectNames(); var weeks = Array.from({ length: 13 }, function (_, k) { return k + 1; });
    var grid = subs.map(function (s) {
      return '<tr><td>' + E(s) + '</td>' + weeks.map(function (w) {
        var hit = all.filter(function (n) { return n.className === cls && n.subject === s && +n.week === w; });
        var st = hit.some(function (n) { return n.status === 'Approved'; }) ? 'ok' : hit.some(function (n) { return n.status === 'Submitted'; }) ? 'wait' : hit.length ? 'draft' : '';
        return '<td class="pro-cov ' + st + '" title="' + A(s + ' · week ' + w + (st ? ' · ' + ({ ok: 'approved', wait: 'awaiting review', draft: 'draft/returned' })[st] : ' · no note')) + '"></td>';
      }).join('') + '</tr>';
    }).join('');
    return window.erpPanel('Weekly coverage — ' + E(cls), '<div class="erp-table-wrap"><table class="pro-cov-t"><thead><tr><th>Subject</th>' + weeks.map(function (w) { return '<th>' + w + '</th>'; }).join('') + '</tr></thead><tbody>' + grid + '</tbody></table></div>' +
      '<div class="pro-legend"><span class="pro-cov ok"></span>Approved <span class="pro-cov wait"></span>Awaiting review <span class="pro-cov draft"></span>Draft / returned <span class="pro-cov"></span>No note</div>', 'pick a class above to switch');
  }
  function templateDraft(n) {
    var t = n.topic || 'the topic', s = n.subject || 'the subject', c = n.className || 'the class';
    return {
      objectives: n.objectives || 'By the end of the lesson, pupils should be able to:\n1. Explain the meaning of ' + t + '.\n2. Identify examples of ' + t + ' in everyday life.\n3. Solve / answer simple questions on ' + t + '.',
      previous: n.previous || 'Pupils have learnt the lesson before ' + t + ' in ' + s + '.',
      materials: n.materials || 'Chalkboard / whiteboard, charts on ' + t + ', the recommended ' + s + ' textbook, real objects where possible.',
      content: n.content || 'Introduction (5 min): The teacher revises the previous lesson and asks questions to connect it to ' + t + '.\n\n' +
        'Step 1 (10 min): The teacher explains the meaning of ' + t + ' with simple examples.\n\n' +
        'Step 2 (10 min): The teacher demonstrates with more examples while pupils observe and ask questions.\n\n' +
        'Step 3 (10 min): Pupils work in pairs/groups on an activity about ' + t + '; the teacher moves round to guide them.\n\n' +
        'Conclusion (5 min): The teacher summarises the key points and writes a short note on the board for ' + c + ' to copy.',
      evaluation: n.evaluation || '1. What is ' + t + '?\n2. Give two examples of ' + t + '.\n3. (One short exercise on ' + t + ')',
      assignment: n.assignment || 'Write five examples of ' + t + ' in your notebook.'
    };
  }
  window.proLN = {
    set: function (k, v) { LN[k] = v; rerender('lesson-records'); },
    edit: function (i) {
      var all = notes(), n = i >= 0 ? all[i] : { week: '', date: ymd(), className: (settings().className) || '', teacher: me(), duration: '40 minutes', status: 'Draft' };
      if (i >= 0 && !editable(n)) { toast('Only drafts or returned notes can be edited.'); return; }
      var body = (n.status === 'Returned' && n.reviewNote ? '<div class="erp-note gold" style="margin-bottom:12px"><b>Returned for correction:</b> ' + E(n.reviewNote) + '</div>' : '') +
        '<div class="erp-form-grid">' +
        field('Class', select('lnClass', classNames(), n.className, 'Select class')) + field('Subject', select('lnSubject', subjectNames(), n.subject, 'Select subject')) +
        field('Week', select('lnWeek', Array.from({ length: 14 }, function (_, k) { return String(k + 1); }), String(n.week || ''), 'Week')) + field('Lesson date', input('lnDate', n.date, 'date')) +
        field('Topic', input('lnTopic', n.topic, 'text', 'e.g. Parts of speech: nouns'), true) + field('Sub-topic', input('lnSub', n.subtopic, 'text', 'optional'), true) +
        field('Duration', input('lnDur', n.duration || '40 minutes')) + field('Teacher', input('lnTeacher', n.teacher || me())) +
        field('Behavioural objectives', textarea('lnObj', n.objectives, 3), true) + field('Previous knowledge', textarea('lnPrev', n.previous, 2), true) +
        field('Instructional materials', textarea('lnMat', n.materials, 2), true) + field('Lesson content / presentation steps', textarea('lnContent', n.content, 8), true) +
        field('Evaluation', textarea('lnEval', n.evaluation, 3), true) + field('Assignment', textarea('lnAssign', n.assignment, 2), true) + '</div>';
      window.erpModal(i >= 0 ? 'Edit lesson note' : 'New lesson note', body,
        '<button class="erp-btn ghost" onclick="proLN.draft()">Draft empty sections from template</button><div class="grow"></div>' +
        '<button class="erp-btn ghost" onclick="erpModalClose()">Cancel</button><button class="erp-btn" onclick="proLN.save(' + i + ',false)">Save draft</button>' +
        '<button class="erp-btn primary" onclick="proLN.save(' + i + ',true)">Save &amp; submit</button>');
    },
    draft: function () {
      var t = templateDraft({ topic: val('lnTopic'), subject: val('lnSubject'), className: val('lnClass'), objectives: val('lnObj'), previous: val('lnPrev'), materials: val('lnMat'), content: val('lnContent'), evaluation: val('lnEval'), assignment: val('lnAssign') });
      if (!val('lnTopic')) { toast('Type the topic first.'); return; }
      [['lnObj', 'objectives'], ['lnPrev', 'previous'], ['lnMat', 'materials'], ['lnContent', 'content'], ['lnEval', 'evaluation'], ['lnAssign', 'assignment']].forEach(function (p) { var el = document.getElementById(p[0]); if (el && !el.value.trim()) el.value = t[p[1]]; });
      toast('Empty sections filled with a standard lesson-note structure — edit them to suit your class.');
    },
    save: function (i, submit) {
      var r = { className: val('lnClass'), subject: val('lnSubject'), week: val('lnWeek'), date: val('lnDate'), topic: val('lnTopic'), subtopic: val('lnSub'), duration: val('lnDur'), teacher: val('lnTeacher') || me(),
        objectives: val('lnObj'), previous: val('lnPrev'), materials: val('lnMat'), content: val('lnContent'), evaluation: val('lnEval'), assignment: val('lnAssign') };
      var missing = [['className', 'class'], ['subject', 'subject'], ['week', 'week'], ['topic', 'topic'], ['content', 'lesson content']].filter(function (k) { return !r[k[0]]; }).map(function (k) { return k[1]; });
      if (missing.length) { toast('Please add the ' + missing.join(', ') + '.'); return; }
      var all = notes(), now = new Date().toISOString();
      var n = i >= 0 ? all[i] : { id: uid(), createdAt: now, status: 'Draft' };
      Object.assign(n, r, { updatedAt: now, term: window.erpTerm(), session: window.erpSession() });
      if (submit) { n.status = 'Submitted'; n.submittedAt = now; } else if (n.status !== 'Approved') n.status = n.status === 'Returned' ? 'Returned' : 'Draft';
      if (i < 0) all.push(n);
      save(); window.erpModalClose(); toast(submit ? 'Lesson note submitted for review.' : 'Draft saved.'); rerender('lesson-records');
    },
    submit: function (i) { var n = notes()[i]; if (!n) return; n.status = 'Submitted'; n.submittedAt = new Date().toISOString(); save(); toast('Submitted for review.'); rerender('lesson-records'); },
    review: function (i) {
      var n = notes()[i]; if (!n || !can()) return;
      window.erpModal('Review lesson note', noteHtml(n) + '<div class="erp-field w2" style="margin-top:14px"><label>Comment to the teacher (required when returning)</label>' + textarea('lnReview', '', 3) + '</div>',
        '<button class="erp-btn ghost" onclick="erpModalClose()">Close</button><div class="grow"></div><button class="erp-btn danger" onclick="proLN.decide(' + i + ',false)">Return for correction</button><button class="erp-btn primary" onclick="proLN.decide(' + i + ',true)">Approve</button>');
    },
    decide: function (i, ok) {
      var n = notes()[i]; var note = val('lnReview');
      if (!ok && note.length < 3) { toast('Tell the teacher what to correct.'); return; }
      n.status = ok ? 'Approved' : 'Returned'; n.reviewNote = note || ''; n.reviewedBy = me(); n.reviewedAt = new Date().toISOString();
      save(); window.erpModalClose(); toast(ok ? 'Lesson note approved.' : 'Returned to the teacher.'); rerender('lesson-records');
    },
    view: function (i) {
      var n = notes()[i]; if (!n) return;
      window.erpModal('Lesson note', noteHtml(n), '<button class="erp-btn ghost" onclick="erpModalClose()">Close</button><div class="grow"></div>' +
        (can() || mine(n) ? '<button class="erp-btn ghost danger" onclick="proLN.remove(' + i + ')">Delete</button>' : '') + '<button class="erp-btn primary" onclick="proLN.print(' + i + ')">' + ico('printer') + 'Print</button>');
    },
    remove: function (i) { var all = notes(); if (!window.erpConfirm('Delete this lesson note?')) return; all.splice(i, 1); save(); window.erpModalClose(); rerender('lesson-records'); },
    print: function (i) {
      var n = notes()[i];
      printDoc('Lesson note', '<div class="hd"><h1>' + E(schoolName()) + '</h1><div class="sub">LESSON NOTE · ' + E(n.session || window.erpSession()) + ' · ' + E(n.term || window.erpTerm()) + ' TERM</div></div>' + noteTable(n) +
        '<div class="sig"><div>Teacher: ' + E(n.teacher || '') + '</div><div>' + (n.status === 'Approved' ? 'Approved: ' + E(n.reviewedBy || '') + ' · ' + E(fmtDate(String(n.reviewedAt || '').slice(0, 10))) : 'Head of School') + '</div></div>');
    }
  };
  function noteTable(n) {
    var sec = function (l, v) { return v ? '<h3>' + E(l) + '</h3><p>' + E(v) + '</p>' : ''; };
    return '<table><tr><th>Class</th><td>' + E(n.className) + '</td><th>Subject</th><td>' + E(n.subject) + '</td></tr><tr><th>Week</th><td>' + E(n.week) + '</td><th>Date</th><td>' + E(fmtDate(n.date)) +
      '</td></tr><tr><th>Duration</th><td>' + E(n.duration || '—') + '</td><th>Teacher</th><td>' + E(n.teacher || '—') + '</td></tr></table>' +
      sec('Topic', n.topic) + sec('Sub-topic', n.subtopic) + sec('Behavioural objectives', n.objectives) + sec('Previous knowledge', n.previous) + sec('Instructional materials', n.materials) +
      sec('Lesson content / presentation', n.content) + sec('Evaluation', n.evaluation) + sec('Assignment', n.assignment);
  }
  function noteHtml(n) {
    return '<div class="pro-note">' + '<div class="pro-note-st">' + badge(n.status === 'Submitted' ? 'Awaiting review' : n.status, TONE[n.status]) +
      (n.reviewNote ? ' <span class="pro-sub">Reviewer: ' + E(n.reviewNote) + '</span>' : '') + '</div>' + noteTable(n) + '</div>';
  }
  addModule('lesson-records', { label: 'Lesson Notes', icon: '📓', section: 'Academics', roles: ['owner', 'admin', 'teacher'], order: 40,
    desc: 'Weekly lesson notes: write, submit for review, approve or return, see which weeks each subject has covered, and print.' }, lessonNotesView);

  /* ═════════════════════════ 2. BIRTHDAYS ═════════════════════════ */
  var BD = { tab: 'learners', month: new Date().getMonth() };
  function bdSettings() { var d = D(); d.birthdays = d.birthdays || { message: 'Happy birthday, {name}! Everyone at {school} wishes you a wonderful {age}th birthday. Have a lovely day!', wished: {} }; return d.birthdays; }
  function nextBirthday(dob, from) {
    var b = parseYmd(dob); if (!b) return null; from = from || new Date(); var t = new Date(from.getFullYear(), from.getMonth(), from.getDate());
    var n = new Date(t.getFullYear(), b.getMonth(), b.getDate()); if (b.getMonth() === 1 && b.getDate() === 29 && n.getMonth() !== 1) n = new Date(t.getFullYear(), 1, 28);
    if (n < t) n = new Date(t.getFullYear() + 1, b.getMonth(), b.getDate());
    return { date: n, days: Math.round((n - t) / 86400000), age: n.getFullYear() - b.getFullYear() };
  }
  function people() { return BD.tab === 'staff' ? staffList().map(function (s) { return { name: s.name, className: s.role, dob: s.dob, phone: s.phone, staff: true }; }) : allLearners(); }
  function wishText(p, nb) { return bdSettings().message.replace(/\{name\}/g, p.name.split(' ')[0]).replace(/\{fullname\}/g, p.name).replace(/\{age\}/g, nb ? nb.age : '').replace(/\{school\}/g, schoolName()); }
  function birthdaysView() {
    var list = people(), withDob = list.filter(function (p) { return parseYmd(p.dob); });
    var enriched = withDob.map(function (p) { return Object.assign({}, p, { nb: nextBirthday(p.dob) }); });
    var today = enriched.filter(function (p) { return p.nb.days === 0; });
    var week = enriched.filter(function (p) { return p.nb.days > 0 && p.nb.days <= 7; }).sort(function (a, b) { return a.nb.days - b.nb.days; });
    var monthList = enriched.filter(function (p) { return parseYmd(p.dob).getMonth() === +BD.month; }).sort(function (a, b) { return parseYmd(a.dob).getDate() - parseYmd(b.dob).getDate(); });
    var key = function (p) { return ymd() + '|' + p.name; };
    var wished = bdSettings().wished || {};
    var card = function (p) {
      var k = key(p), done = !!wished[k];
      return '<div class="pro-bd-card"><div class="pro-bd-ava">' + ico('cake') + '</div><div class="grow"><b>' + E(p.name) + '</b><small>' + E(p.className || '') + ' · turns ' + p.nb.age + '</small></div>' +
        '<div class="pro-acts">' + (p.phone ? '<a class="erp-btn xs" target="_blank" rel="noopener" href="' + A(waLink(p.phone, wishText(p, p.nb))) + '" onclick="proBD.mark(\'' + A(k) + '\')">' + ico('whatsapp') + 'WhatsApp</a>' : '') +
        '<button class="erp-btn xs ghost" onclick="proBD.card(\'' + A(p.name) + '\')">' + ico('printer') + 'Card</button>' +
        (done ? badge('Wished', 'green') : '<button class="erp-btn xs ghost" onclick="proBD.mark(\'' + A(k) + '\')">Mark wished</button>') + '</div></div>';
    };
    var row = function (p) { return '<tr><td><b>' + E(p.name) + '</b></td><td>' + E(p.className || '—') + '</td><td>' + E(fmtDate(p.nb.date, { weekday: 'short', day: 'numeric', month: 'short' })) + '</td><td class="num">' + p.nb.age + '</td><td>' + (p.nb.days === 0 ? badge('Today', 'green') : p.nb.days === 1 ? badge('Tomorrow', 'gold') : E('in ' + p.nb.days + ' days')) + '</td></tr>'; };
    var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    return window.erpWrap('birthdays',
      window.erpStats([{ label: 'Birthdays today', value: today.length, color: today.length ? '#0f766e' : '' }, { label: 'Next 7 days', value: week.length }, { label: 'In ' + months[+BD.month], value: monthList.length },
        { label: BD.tab === 'staff' ? 'Staff without a date of birth' : 'Learners without a date of birth', value: list.length - withDob.length, color: list.length - withDob.length ? '#b45309' : '' }]) +
      '<div class="erp-toolbar pro-wrap"><div class="erp-seg"><button class="' + (BD.tab === 'learners' ? 'on' : '') + '" onclick="proBD.set(\'tab\',\'learners\')">Learners</button><button class="' + (BD.tab === 'staff' ? 'on' : '') + '" onclick="proBD.set(\'tab\',\'staff\')">Staff</button></div>' +
        '<div class="grow"></div>' + (can() ? '<button class="erp-btn ghost" onclick="proBD.settings()">' + ico('edit') + 'Wish message</button>' : '') + '</div>' +
      '<div class="erp-grid two">' +
        window.erpPanel('Today · ' + E(fmtDate(new Date(), { weekday: 'long', day: 'numeric', month: 'long' })), today.length ? today.map(card).join('') : '<div class="erp-empty">No birthday today.</div>') +
        window.erpPanel('Coming up this week', week.length ? '<table class="erp-table"><tbody>' + week.map(row).join('') + '</tbody></table>' : '<div class="erp-empty">No birthday in the next 7 days.</div>') +
      '</div>' +
      window.erpPanel('Birthdays by month', '<div class="erp-toolbar" style="margin:0 0 10px"><select class="erp-select pro-w" onchange="proBD.set(\'month\',this.value)">' +
        months.map(function (m, k) { return '<option value="' + k + '"' + (+BD.month === k ? ' selected' : '') + '>' + m + '</option>'; }).join('') + '</select></div>' +
        (monthList.length ? '<div class="erp-table-wrap"><table class="erp-table"><thead><tr><th>Name</th><th>' + (BD.tab === 'staff' ? 'Role' : 'Class') + '</th><th>Birthday</th><th class="num">Turns</th><th>Status</th></tr></thead><tbody>' + monthList.map(row).join('') + '</tbody></table></div>'
          : '<div class="erp-empty">No birthday recorded for ' + months[+BD.month] + '.</div>')) +
      (list.length - withDob.length ? '<div class="erp-note">' + (list.length - withDob.length) + (BD.tab === 'staff' ? ' staff record(s) have no date of birth — add it in Staff Directory.' : ' learner(s) have no date of birth — fill the Date of Birth column in the Class Form (Students).') + '</div>' : ''));
  }
  window.proBD = {
    set: function (k, v) { BD[k] = v; rerender('birthdays'); },
    mark: function (k) { var s = bdSettings(); s.wished = s.wished || {}; s.wished[k] = new Date().toISOString(); save(); setTimeout(function () { if (current() === 'birthdays') rerender('birthdays'); }, 200); },
    settings: function () {
      window.erpModal('Birthday wish message', '<div class="erp-field w2"><label>Message ({name}, {fullname}, {age} and {school} are filled in automatically)</label>' + textarea('bdMsg', bdSettings().message, 4) + '</div>',
        '<button class="erp-btn ghost" onclick="erpModalClose()">Cancel</button><button class="erp-btn primary" onclick="proBD.saveMsg()">Save</button>');
    },
    saveMsg: function () { var m = val('bdMsg'); if (m.length < 5) return toast('Write a message.'); bdSettings().message = m; save(); window.erpModalClose(); toast('Message saved.'); },
    card: function (name) {
      var p = people().find(function (x) { return x.name === name; }); if (!p) return; var nb = nextBirthday(p.dob);
      printDoc('Birthday card', '<div style="border:3px double #0f766e;border-radius:16px;padding:48px 36px;text-align:center;margin-top:40px">' +
        '<div style="font-size:13px;letter-spacing:.2em;color:#0f766e;text-transform:uppercase">' + E(schoolName()) + '</div>' +
        '<h1 style="font-size:34px;margin:22px 0 6px">Happy Birthday</h1><div style="font-size:26px;font-weight:600">' + E(p.name) + '</div>' +
        '<div style="color:#475569;margin:10px 0 26px">' + E(p.className || '') + (nb ? ' · ' + nb.age + ' years old today' : '') + '</div>' +
        '<p style="font-size:15px;max-width:520px;margin:auto">' + E(wishText(p, nb)) + '</p>' +
        '<div class="sig" style="margin-top:60px"><div>Class Teacher</div><div>Head of School</div></div></div>');
    }
  };
  addModule('birthdays', { label: "Learners' Birthdays", icon: '🎂', section: 'School Records', roles: ['owner', 'admin', 'teacher'], order: 60, keywords: ['birthday', 'dob', 'celebrate'],
    desc: 'Who is celebrating today, this week and this month — send a WhatsApp wish to the parent or print a birthday card.' }, birthdaysView);

  /* ═════════════════════════ 3. LIVE CALENDAR ═════════════════════════ */
  function easter(y) { var a = y % 19, b = Math.floor(y / 100), c = y % 100, d = Math.floor(b / 4), e = b % 4, f = Math.floor((b + 8) / 25), g = Math.floor((b - f + 1) / 3), h = (19 * a + b - d - g + 15) % 30, i = Math.floor(c / 4), k = c % 4, l = (32 + 2 * e + 2 * i - h - k) % 7, m = Math.floor((a + 11 * h + 22 * l) / 451), mo = Math.floor((h + l - 7 * m + 114) / 31), da = ((h + l - 7 * m + 114) % 31) + 1; return new Date(y, mo - 1, da); }
  function holidays(y) {
    var e = easter(y), gf = new Date(e), em = new Date(e); gf.setDate(e.getDate() - 2); em.setDate(e.getDate() + 1);
    return [[y + '-01-01', "New Year's Day"], [ymd(gf), 'Good Friday'], [ymd(em), 'Easter Monday'], [y + '-05-01', "Workers' Day"], [y + '-05-27', "Children's Day"],
      [y + '-06-12', 'Democracy Day'], [y + '-10-01', 'Independence Day'], [y + '-12-25', 'Christmas Day'], [y + '-12-26', 'Boxing Day']]
      .map(function (h) { return { date: h[0], title: h[1], type: 'Holiday', auto: true }; });
  }
  var CAL = { y: new Date().getFullYear(), m: new Date().getMonth() };
  function currentPeriod() {
    var d = D(), p = (d.periods || []).filter(function (x) { return x.start; }).sort(function (a, b) { return String(b.start).localeCompare(String(a.start)); });
    var t = ymd(); return p.find(function (x) { return x.start <= t && (!x.end || x.end >= t); }) || p.find(function (x) { return x.start > t; }) || null;
  }
  function calEvents(y) {
    var d = D(), ev = (d.calendar || []).map(function (e, i) { return Object.assign({ idx: i }, e); });
    (d.periods || []).forEach(function (p) {
      if (p.start) ev.push({ title: (p.term || '') + ' term resumes', date: p.start, type: 'Term', auto: true });
      if (p.end) ev.push({ title: (p.term || '') + ' term closes', date: p.end, type: 'Term', auto: true });
      if (p.next) ev.push({ title: 'Next term begins', date: p.next, type: 'Term', auto: true });
    });
    [y - 1, y, y + 1].forEach(function (yy) { ev = ev.concat(holidays(yy)); });
    allLearners().concat(staffList().map(function (s) { return { name: s.name, className: s.role, dob: s.dob }; })).forEach(function (p) {
      var b = parseYmd(p.dob); if (!b) return;
      [y - 1, y, y + 1].forEach(function (yy) { ev.push({ title: p.name + "'s birthday", who: p.name, cls: p.className, date: yy + '-' + pad(b.getMonth() + 1) + '-' + pad(b.getDate()), type: 'Birthday', auto: true }); });
    });
    return ev;
  }
  function liveNow() {
    var now = new Date(), d = D(), cls = (settings().className) || '';
    var day = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][now.getDay()];
    var slots = (d.periods_slots || []).map(function (s, i) { var p = String(s).split(/\s*[-–]\s*/); return { i: i, label: s, a: mins(p[0]), b: mins(p[1]) }; }).filter(function (s) { return s.a !== null && s.b !== null; });
    var t = now.getHours() * 60 + now.getMinutes();
    var cur = slots.find(function (s) { return t >= s.a && t < s.b; }), nxt = slots.find(function (s) { return s.a > t; });
    var cell = function (s) { return s ? ((((d.timetable || {})[cls] || {})[day] || [])[s.i] || (/break/i.test(s.label) ? 'Break' : 'Free period')) : ''; };
    return { cls: cls, day: day, cur: cur, nxt: nxt, curTxt: cell(cur), nxtTxt: cell(nxt) };
  }
  function calendarView() {
    var y = CAL.y, m = CAL.m, today = ymd(), ev = calEvents(y);
    var first = new Date(y, m, 1), start = new Date(first); start.setDate(1 - first.getDay());
    var cells = '';
    for (var k = 0; k < 42; k++) {
      var dt = new Date(start); dt.setDate(start.getDate() + k); var key = ymd(dt);
      var de = ev.filter(function (e) { return e.date === key; });
      var bdays = de.filter(function (e) { return e.type === 'Birthday'; }), other = de.filter(function (e) { return e.type !== 'Birthday'; });
      cells += '<button class="pro-cal-day' + (dt.getMonth() !== m ? ' out' : '') + (key === today ? ' today' : '') + (other.some(function (e) { return e.type === 'Holiday'; }) ? ' hol' : '') + '" onclick="proCal.day(\'' + key + '\')">' +
        '<span class="pro-cal-n">' + dt.getDate() + '</span>' + other.slice(0, 2).map(function (e) { return '<span class="pro-cal-ev ' + E(String(e.type || 'Event').toLowerCase()) + '">' + E(e.title) + '</span>'; }).join('') +
        (other.length > 2 ? '<span class="pro-cal-more">+' + (other.length - 2) + ' more</span>' : '') + (bdays.length ? '<span class="pro-cal-bd">' + ico('cake') + bdays.length + '</span>' : '') + '</button>';
    }
    var upcoming = ev.filter(function (e) { return e.date >= today && e.type !== 'Birthday'; }).sort(function (a, b) { return a.date.localeCompare(b.date); }).slice(0, 8);
    var todayEv = ev.filter(function (e) { return e.date === today; });
    var per = currentPeriod(), weekOfTerm = '';
    if (per && per.start && per.start <= today) weekOfTerm = 'Week ' + (Math.floor((parseYmd(today) - parseYmd(per.start)) / (7 * 86400000)) + 1);
    var nextEv = upcoming.find(function (e) { return e.date > today; });
    var termEnd = per && per.end && per.end >= today ? Math.round((parseYmd(per.end) - parseYmd(today)) / 86400000) : null;
    var ln = liveNow();
    var months = first.toLocaleDateString('en-NG', { month: 'long', year: 'numeric' });
    return window.erpWrap('calendar',
      '<div class="pro-live">' +
        '<div class="pro-live-clock"><span class="pro-live-dot"></span><b id="proClock">' + hm() + '<small>:' + pad(new Date().getSeconds()) + '</small></b><span>' + E(fmtDate(new Date(), { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })) + '</span></div>' +
        '<div class="pro-live-facts">' +
          '<div><small>Session · Term</small><b>' + E(window.erpSession()) + ' · ' + E(window.erpTerm()) + '</b>' + (weekOfTerm ? '<span>' + weekOfTerm + ' of term</span>' : '') + '</div>' +
          '<div><small>Term ends</small><b>' + (termEnd !== null ? (termEnd === 0 ? 'Today' : termEnd + ' day' + (termEnd === 1 ? '' : 's')) : '—') + '</b><span>' + (per && per.end ? E(fmtDate(per.end)) : 'set dates in Academic Periods') + '</span></div>' +
          '<div><small>Next event</small><b>' + (nextEv ? E(nextEv.title) : '—') + '</b><span>' + (nextEv ? E(fmtDate(nextEv.date)) + ' · in ' + Math.round((parseYmd(nextEv.date) - parseYmd(today)) / 86400000) + ' day(s)' : 'nothing scheduled') + '</span></div>' +
          '<div><small>Now in ' + E(ln.cls || 'class') + '</small><b>' + (ln.cur ? E(ln.curTxt) : (['Saturday', 'Sunday'].indexOf(ln.day) >= 0 ? 'Weekend' : 'Outside school hours')) + '</b><span>' + (ln.nxt ? 'Next: ' + E(ln.nxtTxt) + ' at ' + E(String(ln.nxt.label).split(/\s*[-–]\s*/)[0]) : (ln.cur ? 'last period' : '')) + '</span></div>' +
        '</div></div>' +
      '<div class="erp-toolbar pro-wrap"><button class="erp-btn ghost sm" onclick="proCal.move(-1)" aria-label="Previous month">←</button><b class="pro-cal-title">' + E(months) + '</b>' +
        '<button class="erp-btn ghost sm" onclick="proCal.move(1)" aria-label="Next month">→</button><button class="erp-btn ghost sm" onclick="proCal.today()">Today</button><div class="grow"></div>' +
        (can() ? '<button class="erp-btn primary" onclick="erpOpenForm(\'__events\')">' + ico('plus') + 'Add event</button>' : '') + '</div>' +
      '<div class="pro-cal-layout"><div class="erp-panel"><div class="erp-panel-b"><div class="pro-cal">' + ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(function (x) { return '<div class="pro-cal-dow">' + x + '</div>'; }).join('') + cells + '</div>' +
        '<div class="pro-legend"><span class="pro-dot term"></span>Term <span class="pro-dot holiday"></span>Public holiday <span class="pro-dot exam"></span>Exam <span class="pro-dot event"></span>Event ' + ico('cake') + 'Birthdays</div></div></div>' +
        '<div>' + window.erpPanel('Today', todayEv.length ? todayEv.map(function (e) { return '<div class="erp-inline-row"><span><b>' + E(e.title) + '</b><small>' + E(e.type || 'Event') + (e.time ? ' · ' + E(e.time) : '') + (e.cls ? ' · ' + E(e.cls) : '') + '</small></span></div>'; }).join('') : '<div class="erp-empty">Nothing on today’s calendar.</div>') +
        window.erpPanel('Upcoming', upcoming.length ? upcoming.map(function (e) { return '<div class="erp-inline-row"><span><b>' + E(e.title) + '</b><small>' + E(fmtDate(e.date)) + (e.time ? ' · ' + E(e.time) : '') + '</small></span>' + badge(e.type || 'Event', e.type === 'Holiday' ? 'rose' : e.type === 'Exam' ? 'gold' : 'green') + '</div>'; }).join('') : '<div class="erp-empty">No upcoming event.</div>') + '</div></div>' +
      '<div class="erp-note">Nigerian public holidays with fixed dates and Easter are added automatically. Eid-el-Fitr, Eid-el-Kabir and Eid-el-Maulud depend on the moon — add them with “Add event” when the Federal Government announces the dates.</div>');
  }
  window.proCal = {
    move: function (n) { CAL.m += n; if (CAL.m < 0) { CAL.m = 11; CAL.y--; } if (CAL.m > 11) { CAL.m = 0; CAL.y++; } rerender('calendar'); },
    today: function () { var n = new Date(); CAL.y = n.getFullYear(); CAL.m = n.getMonth(); rerender('calendar'); },
    day: function (key) {
      var ev = calEvents(+key.slice(0, 4)).filter(function (e) { return e.date === key; });
      var body = ev.length ? ev.map(function (e) {
        return '<div class="erp-inline-row"><span><b>' + E(e.title) + '</b><small>' + E(e.type || 'Event') + (e.time ? ' · ' + E(e.time) : '') + (e.cls ? ' · ' + E(e.cls) : '') + '</small></span>' +
          (!e.auto && can() ? '<button class="erp-btn xs ghost" onclick="erpModalClose();erpOpenForm(\'__events\',' + e.idx + ')">Edit</button>' : '') + '</div>';
      }).join('') : '<div class="erp-empty">Nothing on this day.</div>';
      window.erpModal(fmtDate(key, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }), body,
        '<button class="erp-btn ghost" onclick="erpModalClose()">Close</button>' + (can() ? '<button class="erp-btn primary" onclick="erpModalClose();erpOpenForm(\'__events\',-1,\'' + key + '\')">Add event on this day</button>' : ''));
    }
  };
  // the existing month buttons call these names — keep them working
  window.erpCalMove = window.proCal.move; window.erpCalToday = window.proCal.today;
  addModule('calendar', { label: 'Live Calendar', icon: '🗓️', section: 'Communication', roles: ['owner', 'admin', 'teacher', 'student', 'parent'], order: 30, keywords: ['calendar', 'holiday', 'event', 'term'],
    desc: 'A live view of the school day and term: clock, week of term, countdowns, today’s agenda, public holidays, birthdays and events.' }, calendarView);

  /* ═════════════════════════ 4. STAFF CLOCK-IN ═════════════════════════
     Activation (Owner / School Admin → "Clock-in settings"):
       • Staff self clock-in on/off            teachers clock themselves in from their own phone
       • Require fingerprint / face            each phone is activated once per teacher (WebAuthn); every clock-in
                                               then needs that teacher's fingerprint/face on that phone
       • Require being at school (GPS)         the school's location + radius; clock-in outside it is refused
     The office can still record anyone (marked "Office"). With Cloud Sync on, every clock-in is sent to Supabase. */
  var CK = { date: ymd(), busy: false };
  function clock() {
    var d = D(); d.staffClock = d.staffClock || { settings: { resume: '07:30', close: '15:00', grace: 10 }, days: {} }; d.staffClock.days = d.staffClock.days || {};
    var s = d.staffClock.settings = d.staffClock.settings || {};
    if (s.selfService === undefined) s.selfService = true;   // as before: staff could clock themselves in
    if (s.radius === undefined) s.radius = 150;
    return d.staffClock;
  }
  function dayRec(date) { var c = clock(); c.days[date] = c.days[date] || {}; return c.days[date]; }
  function lateBy(t) { var s = clock().settings, a = mins(t), r = mins(s.resume); return a === null || r === null ? 0 : Math.max(0, a - r - (+s.grace || 0)); }
  function lateText(lb) { return lb >= 60 ? Math.floor(lb / 60) + ' h ' + (lb % 60) + ' min' : lb + ' min'; }
  function myLogin() { var u = G('currentUser'); return u ? String(u.loginId || u.id || '') : ''; }
  var BIO = function () { return window.ABO_BIO || null; };
  var CLOUD = function () { return window.ABO_CLOUD || null; };
  function distM(a, b) {
    var R = 6371000, t = Math.PI / 180, dLat = (b.lat - a.lat) * t, dLng = (b.lng - a.lng) * t;
    var h = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(a.lat * t) * Math.cos(b.lat * t) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
    return 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
  }
  function distText(m) { return m >= 1000 ? (m / 1000).toFixed(1) + ' km' : Math.round(m) + ' m'; }
  function getPos() {
    return new Promise(function (res, rej) {
      if (!navigator.geolocation) return rej(new Error('This device cannot share its location.'));
      navigator.geolocation.getCurrentPosition(function (p) { res({ lat: p.coords.latitude, lng: p.coords.longitude, acc: p.coords.accuracy || 0 }); }, function (e) {
        rej(new Error(e.code === 1 ? 'Location permission was refused. Allow location for this site in the browser settings, then try again.'
          : e.code === 3 ? 'Getting your location took too long. Move near a window or outside and try again.' : 'Your location is not available. Turn on Location (GPS) and try again.'));
      }, { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 });
    });
  }
  function methodBadge(r, kind) {
    var m = r[kind + 'Method'], loc = r[kind + 'Loc']; if (!m) return '';
    var txt = m === 'office' ? 'Office' : m.replace('fingerprint', 'Fingerprint').replace('location', 'At school').replace(' + ', ' · ');
    return '<small class="pro-sub pro-method">' + (m.indexOf('fingerprint') >= 0 ? ico('fingerprint') : m.indexOf('location') >= 0 ? ico('map-pin') : '') + E(txt) + (loc && loc.dist != null ? ' · ' + E(distText(loc.dist)) : '') + '</small>';
  }
  function rulesPanel() {
    var s = clock().settings, bio = BIO(), cloud = CLOUD();
    var chip = function (on, label) { return '<span class="pro-rule ' + (on ? 'on' : 'off') + '">' + (on ? '●' : '○') + ' ' + E(label) + '</span>'; };
    return '<div class="pro-rules"><div class="pro-rules-l"><b>Clock-in rules</b><div class="pro-wrap">' +
      chip(s.selfService, s.selfService ? 'Staff self clock-in on' : 'Staff self clock-in off') +
      chip(s.requireBio, s.requireBio ? 'Fingerprint / face required' : 'No fingerprint needed') +
      chip(s.requireGeo, s.requireGeo ? (s.site ? 'Must be within ' + s.radius + ' m of school' : 'Location required — school location not set') : 'Location not checked') +
      chip(cloud && cloud.configured(), cloud && cloud.configured() ? 'Synced to Supabase' : 'This device only') +
      '</div></div><button class="erp-btn" onclick="proCK.settings()">' + ico('settings') + 'Clock-in settings</button></div>' +
      (s.requireGeo && !s.site ? '<div class="erp-note pro-warn">Location is required but the school’s location has not been set. Open <b>Clock-in settings</b> on a phone at the school gate and press <b>Use my current location</b>.</div>' : '') +
      (s.requireBio && bio && !bio.supported() ? '<div class="erp-note pro-warn">' + E(bio.whyNot()) + '</div>' : '');
  }
  function selfBox(meStaff, rec) {
    var s = clock().settings, r = rec[meStaff.name] || {}, bio = BIO(), id = myLogin();
    var needAct = s.requireBio && bio && !bio.activated(id);
    var steps = [];
    if (s.requireBio) steps.push(ico('fingerprint') + (needAct ? 'Activate fingerprint on this phone first' : 'Fingerprint / face on this phone'));
    if (s.requireGeo) steps.push(ico('map-pin') + 'Be within ' + E(s.radius) + ' m of school');
    var action;
    if (!s.selfService && !can()) action = badge('Self clock-in is switched off — the office records your time', 'gold');
    else if (r.in && r.out) action = badge('Done for today', 'green');
    else if (needAct) action = '<button class="erp-btn primary" onclick="proCK.activate()">' + ico('fingerprint') + 'Activate this phone</button>';
    else action = '<button class="erp-btn ' + (r.in ? '' : 'primary') + '" ' + (CK.busy ? 'disabled' : '') + ' onclick="proCK.self(\'' + (r.in ? 'out' : 'in') + '\')">' + ico(r.in ? 'logout' : 'login') + (CK.busy ? 'Checking…' : r.in ? 'Clock out' : 'Clock in now') + '</button>';
    return '<div class="pro-self"><div><small>' + E(fmtDate(new Date(), { weekday: 'long', day: 'numeric', month: 'long' })) + '</small><b>' +
      (r.in ? (r.out ? 'You clocked out at ' + E(r.out) : 'You clocked in at ' + E(r.in)) : 'You have not clocked in today') + '</b>' +
      (steps.length ? '<div class="pro-steps-inline">' + steps.map(function (x) { return '<span>' + x + '</span>'; }).join('') + '</div>' : '') +
      (r.in ? methodBadge(r, 'in') : '') + '</div>' + action + '</div>';
  }
  function devicesPanel() {
    var d = D(), bios = d.biometrics || {}, accounts = G('userAccounts') || {}, rows = [];
    var nameOf = function (id) { var all = [].concat(accounts.teachers || [], accounts.admins || [], accounts.students || [], accounts.parents || []); var a = all.find(function (x) { return (x.loginId || x.id) === id; }); return a ? (a.name || id) : ((typeof window.isOwnerCode === 'function' && window.isOwnerCode(id)) ? 'Owner' : id); };
    Object.keys(bios).forEach(function (id) { (bios[id] || []).forEach(function (c) { rows.push({ id: id, c: c }); }); });
    if (!rows.length) return '';
    rows.sort(function (a, b) { return String(b.c.created).localeCompare(String(a.c.created)); });
    return window.erpPanel('Activated phones (fingerprint / face)', '<div class="erp-table-wrap"><table class="erp-table"><thead><tr><th>Staff</th><th>Phone</th><th>Activated</th><th>Last used</th><th>Status</th><th></th></tr></thead><tbody>' +
      rows.map(function (x) {
        return '<tr><td><b>' + E(nameOf(x.id)) + '</b><small class="pro-sub">' + E(x.id) + '</small></td><td>' + E(x.c.label || '—') + '</td><td>' + E(fmtDate(String(x.c.created || '').slice(0, 10))) + '</td><td>' + (x.c.lastUsed ? E(fmtDate(String(x.c.lastUsed).slice(0, 10))) : '—') + '</td><td>' +
          (x.c.revoked ? badge('Deactivated', 'rose') : badge('Active', 'green')) + '</td><td class="pro-acts">' + (!x.c.revoked ? '<button class="erp-btn xs ghost" onclick="proCK.revoke(\'' + A(x.id) + '\',\'' + A(x.c.id) + '\')">Deactivate</button>' : '') + '</td></tr>';
      }).join('') + '</tbody></table></div>', 'A lost or changed phone can be deactivated here');
  }
  function clockView() {
    var staff = staffList(), rec = dayRec(CK.date), s = clock().settings, isToday = CK.date === ymd(), head = can();
    var meName = me().toLowerCase(), meStaff = staff.find(function (p) { return p.name.toLowerCase() === meName; });
    var inN = staff.filter(function (p) { return rec[p.name] && rec[p.name].in; }).length, late = staff.filter(function (p) { return rec[p.name] && rec[p.name].in && lateBy(rec[p.name].in) > 0; }).length;
    var outN = staff.filter(function (p) { return rec[p.name] && rec[p.name].out; }).length;
    var rows = staff.map(function (p) {
      var r = rec[p.name] || {}, lb = r.in ? lateBy(r.in) : 0, self = p.name.toLowerCase() === meName;
      return '<tr><td><b>' + E(p.name) + '</b><small class="pro-sub">' + E(p.role) + '</small></td><td>' + (r.in ? E(r.in) + ' ' + (lb ? badge('Late ' + lateText(lb), 'rose') : badge('On time', 'green')) + methodBadge(r, 'in') : '<span class="pro-sub">—</span>') +
        '</td><td>' + (r.out ? E(r.out) + methodBadge(r, 'out') : '<span class="pro-sub">—</span>') + '</td><td class="pro-acts">' +
        (isToday && head && !self && !r.in ? '<button class="erp-btn xs primary" onclick="proCK.punch(\'' + A(p.name) + '\',\'in\')">Record in</button>' : '') +
        (isToday && head && !self && r.in && !r.out ? '<button class="erp-btn xs" onclick="proCK.punch(\'' + A(p.name) + '\',\'out\')">Record out</button>' : '') +
        (head && r.in ? '<button class="erp-btn xs ghost" onclick="proCK.clear(\'' + A(p.name) + '\')">Reset</button>' : '') + '</td></tr>';
    }).join('');
    return window.erpWrap('staff-clockin',
      (meStaff && isToday ? selfBox(meStaff, rec) : '') +
      (head ? rulesPanel() : '') +
      window.erpStats([{ label: 'Staff', value: staff.length }, { label: 'Clocked in', value: inN, color: '#047857' }, { label: 'Late', value: late, color: late ? '#b91c1c' : '' },
        { label: 'Not in yet', value: staff.length - inN, color: staff.length - inN ? '#b45309' : '' }, { label: 'Clocked out', value: outN }]) +
      '<div class="erp-toolbar pro-wrap"><input class="erp-input pro-w" type="date" value="' + A(CK.date) + '" max="' + ymd() + '" onchange="proCK.set(this.value)">' +
        '<span class="pro-sub">Resumption ' + E(s.resume) + ' · grace ' + E(s.grace) + ' min · closing ' + E(s.close) + '</span><div class="grow"></div>' +
        (head ? '<button class="erp-btn ghost" onclick="proCK.csv()">' + ico('download') + 'Month CSV</button>' : '') + '</div>' +
      '<div class="erp-panel"><div class="erp-panel-b" style="padding:0"><div class="erp-table-wrap"><table class="erp-table"><thead><tr><th>Staff</th><th>Clock in</th><th>Clock out</th><th></th></tr></thead><tbody>' +
        (rows || '<tr><td colspan="4"><div class="erp-empty">No staff yet. Add staff in Staff Directory or create teacher logins.</div></td></tr>') + '</tbody></table></div></div></div>' +
      (head ? monthSummary(staff) + devicesPanel() : '') +
      '<div class="erp-note">Teachers clock in from their own phone when they arrive' + (s.requireBio ? ', confirmed with their fingerprint or face' : '') + (s.requireGeo ? ', and only within ' + E(s.radius) + ' m of the school' : '') + '. The office can record anyone (marked “Office”). Lateness counts from the resumption time plus the grace minutes. The Live Class Monitor uses these records to flag idle classes.</div>');
  }
  function monthSummary(staff) {
    var c = clock(), mo = CK.date.slice(0, 7), days = Object.keys(c.days).filter(function (k) { return k.slice(0, 7) === mo; });
    var rows = staff.map(function (p) {
      var ins = days.map(function (k) { return (c.days[k][p.name] || {}).in; }).filter(Boolean), lates = ins.filter(function (t) { return lateBy(t) > 0; }).length;
      var avg = ins.length ? Math.round(ins.reduce(function (a, t) { return a + mins(t); }, 0) / ins.length) : null;
      return '<tr><td>' + E(p.name) + '</td><td class="num">' + ins.length + '</td><td class="num">' + (lates ? '<b style="color:#b91c1c">' + lates + '</b>' : 0) + '</td><td class="num">' + (avg === null ? '—' : pad(Math.floor(avg / 60)) + ':' + pad(avg % 60)) + '</td></tr>';
    }).join('');
    return window.erpPanel('Month summary — ' + E(new Date(+mo.slice(0, 4), +mo.slice(5, 7) - 1, 1).toLocaleDateString('en-NG', { month: 'long', year: 'numeric' })),
      '<div class="erp-table-wrap"><table class="erp-table"><thead><tr><th>Staff</th><th class="num">Days present</th><th class="num">Days late</th><th class="num">Average arrival</th></tr></thead><tbody>' + rows + '</tbody></table></div>', days.length + ' day(s) recorded');
  }
  // write one punch on this device and send it to the cloud
  function record(name, kind, method, loc) {
    var r = dayRec(ymd()); r[name] = r[name] || {}; if (r[name][kind]) return null;
    var t = hm(); r[name][kind] = t; r[name][kind + 'By'] = me(); r[name][kind + 'Method'] = method; if (loc) r[name][kind + 'Loc'] = loc;
    save();
    var cl = CLOUD(); if (cl && cl.configured()) cl.clockEvent({ staff: name, login_id: method === 'office' ? null : myLogin(), kind: kind, day: ymd(), at_time: t, method: method, lat: loc ? loc.lat : null, lng: loc ? loc.lng : null, accuracy_m: loc ? loc.acc : null, distance_m: loc ? loc.dist : null });
    try { window.logAudit && window.logAudit('Staff ' + (kind === 'in' ? 'clock-in' : 'clock-out') + ': ' + name + ' (' + method + ')'); } catch (e) { /* ignore */ }
    return r[name];
  }
  function fail(msg) { CK.busy = false; rerender('staff-clockin'); window.erpModal('Clock-in not recorded', '<p>' + E(msg) + '</p>', '<button class="erp-btn primary" onclick="erpModalClose()">OK</button>'); return false; }
  window.proCK = {
    set: function (d) { CK.date = d || ymd(); rerender('staff-clockin'); },
    // office: record someone else's time
    punch: function (name, kind) {
      var self = name.toLowerCase() === me().toLowerCase();
      if (self) return window.proCK.self(kind);
      if (!can()) { toast('You can only clock yourself in.'); return; }
      var r = record(name, kind, 'office'); if (!r) return;
      var lb = kind === 'in' ? lateBy(r.in) : 0;
      toast(kind === 'in' ? name + ' clocked in at ' + r.in + (lb ? ' (' + lateText(lb) + ' late)' : '') : name + ' clocked out at ' + r.out);
      rerender('staff-clockin');
    },
    // a staff member clocking themselves in: the activated checks run here
    self: function (kind) {
      if (CK.busy) return Promise.resolve(false);
      var s = clock().settings, name = me(), staff = staffList().find(function (p) { return p.name.toLowerCase() === name.toLowerCase(); });
      if (!staff) { toast('Your name is not on the staff list yet. Ask the office to add you.'); return Promise.resolve(false); }
      if (!s.selfService && !can()) { toast('Self clock-in is switched off. The office records your time.'); return Promise.resolve(false); }
      var methods = [], loc = null, bio = BIO();
      CK.busy = true; rerender('staff-clockin');
      var chain = Promise.resolve();
      if (s.requireBio) chain = chain.then(function () {
        if (!bio) throw new Error('Fingerprint support is not available in this edition.');
        if (!bio.supported()) throw new Error(bio.whyNot());
        return bio.verify(myLogin()).then(function (r) { if (!r.ok) throw new Error(r.message); methods.push('fingerprint'); });
      });
      if (s.requireGeo) chain = chain.then(function () {
        if (!s.site) throw new Error('The school’s location has not been set yet. Ask the office to set it in Clock-in settings.');
        return getPos().then(function (p) {
          var dist = distM(p, s.site);
          if (p.acc > 300) throw new Error('Your GPS reading is not precise enough (±' + Math.round(p.acc) + ' m). Turn on high-accuracy location or step outside, then try again.');
          if (dist > (+s.radius || 150) + Math.min(p.acc, 50)) throw new Error('You are ' + distText(dist) + ' from school. Clock-in only works within ' + s.radius + ' m of the school.');
          loc = { lat: +p.lat.toFixed(6), lng: +p.lng.toFixed(6), acc: Math.round(p.acc), dist: Math.round(dist) }; methods.push('location');
        });
      });
      return chain.then(function () {
        CK.busy = false;
        var r = record(staff.name, kind, methods.length ? methods.join(' + ') : 'self', loc);
        if (!r) { rerender('staff-clockin'); return false; }
        var lb = kind === 'in' ? lateBy(r.in) : 0;
        toast(kind === 'in' ? 'Clocked in at ' + r.in + (lb ? ' (' + lateText(lb) + ' late)' : ' — on time') : 'Clocked out at ' + r.out);
        rerender('staff-clockin'); return true;
      }, function (e) { return fail(e && e.message || String(e)); });
    },
    activate: function () {
      var bio = BIO(); if (!bio) return;
      if (!bio.supported()) return fail(bio.whyNot());
      return bio.enroll(myLogin(), me()).then(function (r) {
        if (!r.ok) return fail(r.message);
        toast('Fingerprint activated on this phone (' + r.cred.label + ').'); rerender('staff-clockin'); return true;
      });
    },
    revoke: function (id, credId) {
      if (!can() || !window.erpConfirm('Deactivate this phone? The staff member will need to activate it again before clocking in with fingerprint.')) return;
      var bio = BIO(); if (bio) bio.revoke(id, credId); rerender('staff-clockin'); toast('Phone deactivated.');
    },
    clear: function (name) { if (!can() || !window.erpConfirm('Reset ' + name + '’s record for this day?')) return; delete dayRec(CK.date)[name]; save(); rerender('staff-clockin'); },
    settings: function () {
      var s = clock().settings, bio = BIO();
      var tog = function (id, on, label, hint) { return '<label class="pro-toggle"><input type="checkbox" id="' + id + '"' + (on ? ' checked' : '') + '><span><b>' + E(label) + '</b><small>' + hint + '</small></span></label>'; };
      window.erpModal('Clock-in settings',
        '<h4 class="pro-h4">School times</h4><div class="erp-form-grid">' + field('Resumption time', input('ckResume', s.resume, 'time')) + field('Closing time', input('ckClose', s.close, 'time')) +
        field('Grace period (minutes)', input('ckGrace', s.grace, 'number')) + '</div>' +
        '<h4 class="pro-h4">Activation</h4>' +
        tog('ckSelf', s.selfService, 'Staff self clock-in', 'Teachers clock themselves in from their own phone. Off: only the office records time.') +
        tog('ckBio', s.requireBio, 'Require fingerprint or face', 'Each teacher activates their phone once; every clock-in then needs their fingerprint/face on that phone.' + (bio && !bio.supported() ? ' <b>Note:</b> ' + E(bio.whyNot()) : '')) +
        tog('ckGeo', s.requireGeo, 'Require being at school (GPS)', 'Clock-in is refused outside the school’s radius.') +
        '<div class="erp-form-grid">' + field('Allowed radius (metres)', input('ckRadius', s.radius, 'number')) +
        field('School location', '<div class="pro-wrap"><span class="pro-sub" id="ckSiteText">' + (s.site ? E(s.site.lat.toFixed(5) + ', ' + s.site.lng.toFixed(5)) + ' (±' + E(Math.round(s.site.acc || 0)) + ' m)' : 'Not set') + '</span><button type="button" class="erp-btn xs" onclick="proCK.here()">' + ico('map-pin') + 'Use my current location</button></div>', false, 'Do this once, standing at the school.') + '</div>',
        '<button class="erp-btn ghost" onclick="erpModalClose()">Cancel</button><button class="erp-btn primary" onclick="proCK.saveSettings()">Save</button>');
    },
    here: function () {
      var t = document.getElementById('ckSiteText'); if (t) t.textContent = 'Getting location…';
      return getPos().then(function (p) {
        CK.site = { lat: +p.lat.toFixed(6), lng: +p.lng.toFixed(6), acc: Math.round(p.acc), setAt: new Date().toISOString(), setBy: me() };
        if (t) t.textContent = CK.site.lat.toFixed(5) + ', ' + CK.site.lng.toFixed(5) + ' (±' + CK.site.acc + ' m) — press Save';
      }, function (e) { if (t) t.textContent = e.message; });
    },
    saveSettings: function () {
      var s = clock().settings, chk = function (id) { var e = document.getElementById(id); return !!(e && e.checked); };
      s.resume = val('ckResume') || s.resume; s.close = val('ckClose') || s.close; s.grace = Math.max(0, parseInt(val('ckGrace'), 10) || 0);
      s.selfService = chk('ckSelf'); s.requireBio = chk('ckBio'); s.requireGeo = chk('ckGeo');
      s.radius = Math.min(5000, Math.max(30, parseInt(val('ckRadius'), 10) || 150));
      if (CK.site) { s.site = CK.site; CK.site = null; }
      save(); window.erpModalClose(); rerender('staff-clockin');
      toast('Clock-in settings saved' + (s.requireGeo && !s.site ? ' — set the school location next.' : '.'));
    },
    csv: function () {
      var c = clock(), mo = CK.date.slice(0, 7), days = Object.keys(c.days).filter(function (k) { return k.slice(0, 7) === mo; }).sort();
      var lines = [['Date', 'Staff', 'Clock in', 'Clock out', 'Late (min)', 'Checked by', 'Distance from school (m)']];
      days.forEach(function (k) { Object.keys(c.days[k]).forEach(function (n) { var r = c.days[k][n]; lines.push([k, n, r.in || '', r.out || '', r.in ? lateBy(r.in) : '', r.inMethod || '', r.inLoc && r.inLoc.dist != null ? r.inLoc.dist : '']); }); });
      var csv = lines.map(function (l) { return l.map(function (x) { x = String(x); return /[",\n]/.test(x) || /^[=+\-@]/.test(x) ? '"' + x.replace(/"/g, '""').replace(/^([=+\-@])/, "'$1") + '"' : x; }).join(','); }).join('\n');
      var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })); a.download = 'staff-clock-in-' + mo + '.csv'; document.body.appendChild(a); a.click(); setTimeout(function () { a.remove(); }, 500);
    }
  };
  addModule('staff-clockin', { label: 'Staff Clock-in', icon: '⏰', section: 'Attendance', roles: ['owner', 'admin', 'teacher'], order: 20, keywords: ['clock', 'late', 'staff attendance', 'punctuality', 'fingerprint', 'biometric', 'geofence'],
    desc: 'Teachers clock in from their own phone — with fingerprint/face and school-location checks when activated; the office can record anyone.' }, clockView);

  /* ═════════════════════════ 5. LIVE CLASS MONITOR ═════════════════════════ */
  function monitorView() {
    var d = D(), now = new Date(), t = now.getHours() * 60 + now.getMinutes();
    var day = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][now.getDay()];
    var slots = (d.periods_slots || []).map(function (s, i) { var p = String(s).split(/\s*[-–]\s*/); return { i: i, label: s, a: mins(p[0]), b: mins(p[1]) }; }).filter(function (s) { return s.a !== null && s.b !== null; });
    var cur = slots.find(function (s) { return t >= s.a && t < s.b; }), nxt = slots.find(function (s) { return s.a > t; });
    var rec = dayRec(ymd()), staff = staffList();
    function teacherIn(text) { var low = String(text || '').toLowerCase(); var hit = staff.find(function (p) { var parts = p.name.toLowerCase().split(/\s+/).filter(function (w) { return w.length > 2; }); return parts.some(function (w) { return low.indexOf(w) >= 0; }); }); return hit ? { name: hit.name, in: !!(rec[hit.name] && rec[hit.name].in && !rec[hit.name].out) } : null; }
    var weekend = now.getDay() === 0 || now.getDay() === 6;
    var cards = classNames().map(function (cn) {
      var cell = cur ? (((d.timetable || {})[cn] || {})[day] || [])[cur.i] || '' : '';
      var next = nxt ? (((d.timetable || {})[cn] || {})[day] || [])[nxt.i] || '' : '';
      var st, tone, detail = '';
      if (weekend) { st = 'Weekend'; tone = 'muted'; }
      else if (!cur) { st = slots.length && t < slots[0].a ? 'Before school' : 'After school'; tone = 'muted'; }
      else if (/break/i.test(cur.label + ' ' + cell)) { st = 'Break'; tone = 'muted'; }
      else if (!cell) { st = 'Free period'; tone = 'gold'; }
      else { var tch = teacherIn(cell); if (!tch) { st = 'In timetable'; tone = 'info'; detail = 'teacher not matched to staff'; } else if (tch.in) { st = 'In session'; tone = 'green'; detail = tch.name + ' is in school'; } else { st = 'Idle'; tone = 'rose'; detail = 'Idle — ' + tch.name + ' has not clocked in'; } }
      return { cn: cn, st: st, tone: tone, cell: cell, next: next, detail: detail };
    });
    var count = function (k) { return cards.filter(function (c) { return c.st === k || (k === 'Idle' && /^Idle/.test(c.st)); }).length; };
    return window.erpWrap('live-class-monitor',
      '<div class="pro-live slim"><div class="pro-live-clock"><span class="pro-live-dot"></span><b id="proClock">' + hm() + '<small>:' + pad(now.getSeconds()) + '</small></b><span>' + E(day) +
        (cur ? ' · ' + E(cur.label) : '') + (nxt ? ' · next period at ' + E(String(nxt.label).split(/\s*[-–]\s*/)[0]) : '') + '</span></div></div>' +
      window.erpStats([{ label: 'Classes', value: cards.length }, { label: 'In session', value: count('In session'), color: '#047857' }, { label: 'Idle', value: count('Idle'), color: count('Idle') ? '#b91c1c' : '' }, { label: 'Free periods', value: count('Free period') }]) +
      (slots.length ? '' : '<div class="erp-note gold">Set your period times in Timetable (e.g. “8:00 - 8:40”) so the monitor knows which period is running.</div>') +
      '<div class="pro-mon">' + cards.map(function (c) {
        return '<div class="pro-mon-card ' + c.tone + '"><div class="pro-mon-h"><b>' + E(c.cn) + '</b>' + badge(c.st, c.tone === 'muted' || c.tone === 'info' ? '' : c.tone) + '</div>' +
          '<div class="pro-mon-now">' + (c.cell ? E(c.cell) : '<span class="pro-sub">' + (cur && !weekend ? 'No lesson in the timetable' : '—') + '</span>') + '</div>' +
          (c.detail ? '<small class="pro-sub">' + E(c.detail) + '</small>' : '') + (c.next ? '<small class="pro-sub">Next: ' + E(c.next) + '</small>' : '') + '</div>';
      }).join('') + '</div>' +
      '<div class="erp-note">Status comes from the class timetable and today’s Staff Clock-in. A class is flagged <b>idle</b> when a lesson is timetabled but its teacher has not clocked in. The page refreshes itself every 30 seconds.</div>');
  }
  addModule('live-class-monitor', { label: 'Live Class Monitor', icon: '📡', section: 'Attendance', roles: ['owner', 'admin'], order: 25, keywords: ['idle class', 'live', 'monitor', 'teaching now'],
    desc: 'See which subject every class should be taking right now and flag idle classes whose teacher has not clocked in.' }, monitorView);

  /* ───────────────────────── live ticking (only while a live page is open) ───────────────────────── */
  setInterval(function () {
    var c = document.getElementById('proClock'); if (!c) return;
    var n = new Date(); c.innerHTML = hm(n) + '<small>:' + pad(n.getSeconds()) + '</small>';
    var id = current();
    if (n.getSeconds() === 0 && id === 'calendar' && !document.querySelector('.erp-overlay')) rerender('calendar');
    if (n.getSeconds() % 30 === 0 && id === 'live-class-monitor' && !document.querySelector('.erp-overlay')) rerender('live-class-monitor');
  }, 1000);

  /* ───────────────────────── "Today" strip on the dashboard ───────────────────────── */
  function todayStrip() {
    var hello = document.querySelector('.mx-dash .mx-hello'); if (!hello) return;
    var eff0 = (window.ABO && window.ABO.identity && window.ABO.identity.role) ? window.ABO.identity.role() : role();
    if (hello.parentNode.querySelector('.pro-today') && ['owner', 'admin', 'teacher'].indexOf(eff0) >= 0) return;
    var effective = (window.ABO && window.ABO.identity && window.ABO.identity.role) ? window.ABO.identity.role() : role();   // what the viewed screen's role should see
    if (['owner', 'admin', 'teacher'].indexOf(effective) < 0) { var stale = hello.parentNode.querySelector('.pro-today'); if (stale) stale.remove(); return; }
    var t = ymd(), learners = allLearners().filter(function (p) { var nb = nextBirthday(p.dob); return nb && nb.days === 0; });
    var rec = dayRec(t), staff = staffList(), inN = staff.filter(function (p) { return rec[p.name] && rec[p.name].in; }).length;
    var nextEv = calEvents(new Date().getFullYear()).filter(function (e) { return e.date >= t && e.type !== 'Birthday'; }).sort(function (a, b) { return a.date.localeCompare(b.date); })[0];
    var pending = notes().filter(function (n) { return n.status === 'Submitted'; }).length;
    var el = document.createElement('div'); el.className = 'pro-today';
    el.innerHTML =
      '<button onclick="ABO.go(\'birthdays\')">' + ico('cake') + '<span><b>' + learners.length + '</b> birthday' + (learners.length === 1 ? '' : 's') + ' today' + (learners[0] ? ' · ' + E(learners[0].name) + (learners.length > 1 ? ' +' + (learners.length - 1) : '') : '') + '</span></button>' +
      '<button onclick="ABO.go(\'staff-clockin\')">' + ico('clock') + '<span><b>' + inN + '/' + staff.length + '</b> staff clocked in</span></button>' +
      '<button onclick="ABO.go(\'lesson-records\')">' + ico('notebook') + '<span><b>' + pending + '</b> lesson note' + (pending === 1 ? '' : 's') + ' awaiting review</span></button>' +
      '<button onclick="ABO.go(\'calendar\')">' + ico('calendar') + '<span>' + (nextEv ? 'Next: <b>' + E(nextEv.title) + '</b> · ' + E(fmtDate(nextEv.date, { day: 'numeric', month: 'short' })) : 'No upcoming event') + '</span></button>';
    hello.parentNode.insertBefore(el, hello.nextSibling);
  }
  new MutationObserver(function () { try { todayStrip(); } catch (e) { /* never break the dashboard */ } }).observe(document.body, { childList: true, subtree: true });

  window.ABO_FEATURES = { version: '1.0', modules: ['lesson-records', 'birthdays', 'calendar', 'staff-clockin', 'live-class-monitor'] };
})();
