/* ==========================================================================================
   A.B.O. offline edition — one place for each job (11 Oct 2026)

   • Newsletters are retired: Announcements are the one place for school news. Old links to Newsletter Studio open
     Announcements (old newsletters stay saved in the school data and are listed at the bottom of Announcements).
   • Menu entries that opened the same screen twice are folded together:
       Notices → Announcements · Audit Logs (second copy) → Audit Logs · Staff Accounts → Login Accounts ·
       Academic Periods → Sessions & Terms · Design System (developer page) hidden.
   • Share an announcement with parents: one WhatsApp message to a group/broadcast list, parent-by-parent WhatsApp
     buttons (numbers from the pupils' records and the Parents list), and one email to all parents (opens your email
     app with parents in BCC — this offline file has no email server; the online edition sends emails itself).
   ========================================================================================== */
(function () {
  'use strict';
  if (window.__aboMerge) return; window.__aboMerge = true;
  if (!window.ERP_MODULES || !window.ERPRender) return;
  function G(name) { if (window.aboGlobalGet) return window.aboGlobalGet(name); try { return (0, eval)('typeof ' + name + ' !== "undefined" ? ' + name + ' : undefined'); } catch (e) { return undefined; } }   // CSP-safe accessor first (no eval)
  var E = function (v) { return window.erpEsc ? window.erpEsc(v) : String(v == null ? '' : v); };
  var toast = function (m) { try { window.showToast(m); } catch (e) { /* */ } };
  var MOVED = { newsletters: 'announcements', notices: 'announcements', auditlogs: 'audit-logs', 'staff-accounts': 'users', 'academic-periods': 'academic-sessions', 'style-guide': null };
  var WHY = { newsletters: 'Newsletters are now part of Announcements.', notices: 'Notices are now part of Announcements.' };

  /* ── hide the repeated menu entries (registry flag + DOM, so every menu builder agrees) ── */
  try { var R = window.ABO && ABO.registry; Object.keys(MOVED).forEach(function (id) { var m = R && R.get && R.get(id); if (m) m.hidden = true; }); } catch (e) { /* */ }
  function sweep() {
    document.querySelectorAll('#aboSidebar .abo-side-item, .abo-palette-item, .erp-app-tile').forEach(function (b) {
      var id = ((b.getAttribute('onclick') || '').match(/ABO\.go\('([^']+)'\)|erpOpenModule\('([^']+)'\)/) || []).slice(1).filter(Boolean)[0];
      if (id && Object.prototype.hasOwnProperty.call(MOVED, id)) b.classList.add('pro-merged');
    });
    // the old top-menu entry for the newsletter page
    document.querySelectorAll('[data-page="newsletter"], .menu-item[onclick*="newsletter"]').forEach(function (b) { b.classList.add('pro-merged'); });
  }
  var mo = new MutationObserver(function () { if (!sweep.q) { sweep.q = true; requestAnimationFrame(function () { sweep.q = false; sweep(); }); } });
  function boot() { sweep(); mo.observe(document.body, { childList: true, subtree: true }); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();

  /* ── old links land on the merged page ── */
  function wrapGo() {
    if (!window.ABO || typeof ABO.go !== 'function' || ABO.go.__merged) return;
    var go = ABO.go; var w = function (id) { if (Object.prototype.hasOwnProperty.call(MOVED, id)) { if (WHY[id]) toast(WHY[id]); id = MOVED[id] || 'dashboard'; } return go.apply(this, [id].concat([].slice.call(arguments, 1))); };
    w.__merged = true; ABO.go = w;
  }
  wrapGo(); setTimeout(wrapGo, 0); window.addEventListener('load', wrapGo);
  if (typeof window.showPage === 'function' && !window.showPage.__merged) {
    var sp = window.showPage; var w2 = function (id) { if (id === 'newsletter') { toast(WHY.newsletters); try { return ABO.go('announcements'); } catch (e) { /* */ } } return sp.apply(this, arguments); };
    w2.__merged = true; window.showPage = w2;
  }

  /* ── parents' contacts from everything the school saved ── */
  function waNumber(raw) { var d = String(raw || '').replace(/\D/g, ''); if (d.indexOf('00') === 0) d = d.slice(2); if (/^0[789]\d{9}$/.test(d)) d = '234' + d.slice(1); else if (/^[789]\d{9}$/.test(d)) d = '234' + d; return /^\d{11,15}$/.test(d) ? d : null; }
  function parents() {
    var out = {}; var add = function (name, child, cls, phone, wa, email) {
      var n = waNumber(wa) || waNumber(phone); var em = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email || '').trim()) ? String(email).trim().toLowerCase() : null;
      if (!n && !em) return; var k = n || em; var o = out[k] || (out[k] = { name: name || 'Parent / Guardian', children: [], wa: n, phone: phone || wa || '', email: em });
      if (child && o.children.indexOf(child) < 0) o.children.push(child + (cls ? ' (' + cls + ')' : '')); if (!o.email && em) o.email = em;
    };
    var gs = G('globalSettings') || {};
    (G('students') || []).forEach(function (s) { add(s.parentName, s.name, gs.className, s.parentPhone, s.parentWhatsapp, s.parentEmail); });
    try { var L = (window.erpData() || {}).learners || {}; Object.keys(L).forEach(function (cn) { if (cn === gs.className) return; (L[cn] || []).forEach(function (s) { add(s.parentName, s.name, cn, s.parentPhone, s.parentWhatsapp, s.parentEmail); }); }); } catch (e) { /* */ }
    try { ((window.erpData() || {}).parents || []).forEach(function (p) { add(p.name || p.fullName, p.child || p.ward || '', p.className || '', p.phone, p.whatsapp, p.email); }); } catch (e) { /* */ }
    return Object.keys(out).map(function (k) { return out[k]; }).sort(function (a, b) { return String(a.name).localeCompare(String(b.name)); });
  }
  function message(a) { var school = ''; try { school = window.getCurrentSchoolName(); } catch (e) { /* */ } return '*' + school + '*\n*' + (a.title || '') + '*\n\n' + (a.body || '') + '\n\n— ' + school; }

  var SHARE = window.ABO_SHARE = {
    open: function (idx) {
      var a = (window.erpData().announcements || [])[idx]; if (!a) return;
      var text = message(a); var list = parents(); SHARE._a = a; SHARE._text = text; SHARE._list = list;
      var emails = list.filter(function (p) { return p.email; }).map(function (p) { return p.email; });
      var rows = list.length ? list.map(function (p, i) {
        return '<tr><td><b>' + E(p.name) + '</b><div class="pro-sh-sub">' + E(p.children.join(', ')) + '</div></td><td>' + E(p.phone || '—') + '</td><td>' + E(p.email || '—') + '</td><td>' +
          (p.wa ? '<a class="erp-btn xs" target="_blank" rel="noopener noreferrer" href="https://wa.me/' + p.wa + '?text=' + encodeURIComponent(text) + '" onclick="this.classList.add(\'done\');this.textContent=\'Opened\'">WhatsApp</a>' : '<span class="pro-sh-sub">no number</span>') + '</td></tr>';
      }).join('') : '<tr><td colspan="4">No parent phone numbers or emails saved yet. Add them on the class form (Parent Phone / WhatsApp / Email) or in Parents &amp; Guardians.</td></tr>';
      var body = '<div class="pro-share">' +
        '<h4>1. WhatsApp — one message to a group</h4><p class="pro-sh-sub">Opens WhatsApp with the message ready. Choose your parents’ group or broadcast list.</p>' +
        '<pre class="pro-sh-pre">' + E(text) + '</pre>' +
        '<div class="pro-sh-row"><a class="erp-btn primary" target="_blank" rel="noopener noreferrer" href="https://wa.me/?text=' + encodeURIComponent(text) + '">Share on WhatsApp</a> <button type="button" class="erp-btn ghost" onclick="ABO_SHARE.copy()">Copy message</button></div>' +
        '<h4>2. WhatsApp — parent by parent (' + list.filter(function (p) { return p.wa; }).length + ' with a number)</h4>' +
        '<div class="erp-table-wrap pro-sh-list"><table class="erp-table"><thead><tr><th>Parent / child</th><th>Phone</th><th>Email</th><th></th></tr></thead><tbody>' + rows + '</tbody></table></div>' +
        '<h4>3. Email every parent (' + emails.length + ' with an email)</h4>' +
        '<p class="pro-sh-sub">Opens your email app with the notice and all parents in BCC (they do not see each other’s addresses). Large lists open in groups of 40.</p>' +
        '<div class="pro-sh-row">' + (emails.length ? '<button type="button" class="erp-btn primary" onclick="ABO_SHARE.email()">Email ' + emails.length + ' parent(s)</button> <button type="button" class="erp-btn ghost" onclick="ABO_SHARE.copyEmails()">Copy email addresses</button>' : '<span class="pro-sh-sub">No parent emails saved yet.</span>') + '</div></div>';
      ABO.ui.modal({ title: 'Share: ' + (a.title || 'announcement'), wide: true, body: body, footer: '<button class="erp-btn ghost" type="button" onclick="ABO.ui.close()">Close</button>' });
      try { window.logAudit && window.logAudit('Opened sharing for announcement: ' + a.title); } catch (e) { /* */ }
    },
    copy: function () { (navigator.clipboard ? navigator.clipboard.writeText(SHARE._text) : Promise.reject()).then(function () { toast('Message copied.'); }, function () { toast('Select the message and copy it.'); }); },
    copyEmails: function () { var e = SHARE._list.filter(function (p) { return p.email; }).map(function (p) { return p.email; }).join(', '); (navigator.clipboard ? navigator.clipboard.writeText(e) : Promise.reject()).then(function () { toast('Email addresses copied.'); }, function () { toast(e); }); },
    email: function () {
      var a = SHARE._a; var all = SHARE._list.filter(function (p) { return p.email; }).map(function (p) { return p.email; });
      var subject = encodeURIComponent(((function () { try { return window.getCurrentSchoolName(); } catch (e) { return 'School'; } })()) + ': ' + (a.title || 'Notice'));
      var body = encodeURIComponent('Dear Parent / Guardian,\n\n' + (a.title || '') + '\n\n' + (a.body || '') + '\n\n— ' + ((function () { try { return window.getCurrentSchoolName(); } catch (e) { return ''; } })()));
      for (var i = 0; i < all.length; i += 40) { var href = 'mailto:?bcc=' + encodeURIComponent(all.slice(i, i + 40).join(',')) + '&subject=' + subject + '&body=' + body; setTimeout(function (h) { return function () { window.location.href = h; }; }(href), (i / 40) * 1200); }
      try { window.logAudit && window.logAudit('Emailed announcement to ' + all.length + ' parent(s): ' + a.title); } catch (e) { /* */ }
      toast('Your email app opens with ' + all.length + ' parent(s) in BCC.');
    },
  };

  /* ── Announcements page: Share buttons + the old newsletters kept below ── */
  if (typeof window.ERPRender.announcements === 'function' && !window.ERPRender.announcements.__merged) {
    var base = window.ERPRender.announcements;
    var wr = function () {
      var html = base.apply(this, arguments);
      html = html.replace(/<button class="erp-btn xs ghost" onclick="erpPinAnnouncement\((\d+)\)">/g, '<button class="erp-btn xs" onclick="ABO_SHARE.open($1)">Share with parents</button><button class="erp-btn xs ghost" onclick="erpPinAnnouncement($1)">');
      html = html.replace('Share to WhatsApp group</button>', 'Share draft on WhatsApp</button>');
      var old = (G('newsletters') || []).filter(function (n) { return n && (n.title || n.html); });
      if (old.length) {
        var tmp = document.createElement('div');
        html += '<div class="erp-panel pro-old-news"><h3>Old newsletters (kept for reference)</h3><p class="pro-sh-sub">Newsletters are now part of Announcements. Post new letters above; these older ones are kept as they were.</p>' +
          old.slice(0, 50).map(function (n) { tmp.innerHTML = String(n.html || ''); var txt = (tmp.textContent || '').trim(); return '<details><summary>' + E(n.title || 'Newsletter') + '</summary><p style="white-space:pre-wrap">' + E(txt.slice(0, 4000)) + '</p></details>'; }).join('') + '</div>';
      }
      return html;
    };
    wr.__merged = true; window.ERPRender.announcements = wr;
    try { if (window.ABO && ABO.registry && ABO.registry.setRenderer) ABO.registry.setRenderer('announcements', wr); } catch (e) { /* menu still reaches ERPRender */ }
  }
}());

/* ==========================================================================================
   Owner-only Payment Settings (offline edition): plan prices, bank details, the preview countdown for schools that
   have not paid yet (1–5 minutes, default 5), and links to the payment requests waiting for approval.
   Honest limits: this file runs only in the browser, so it cannot take card payments safely or keep secret keys —
   online payment (Paystack, verified by the server) is part of the online edition. Never paste a secret key here.
   ========================================================================================== */
(function () {
  'use strict';
  if (window.__aboPaySettings || !window.ERP_MODULES || !window.ERPRender) return; window.__aboPaySettings = true;
  function G(name) { if (window.aboGlobalGet) return window.aboGlobalGet(name); try { return (0, eval)('typeof ' + name + ' !== "undefined" ? ' + name + ' : undefined'); } catch (e) { return undefined; } }   // CSP-safe accessor first (no eval)
  var E = function (v) { return window.erpEsc ? window.erpEsc(v) : String(v == null ? '' : v); };
  var ID = 'payment-settings';
  function owner() { try { return window.erpRole && window.erpRole() === 'owner'; } catch (e) { return false; } }
  function render() {
    if (!owner()) return window.erpWrap(ID, '<div class="erp-empty">Only the owner can open Payment Settings.</div>');
    var p = G('pricingData') || {};
    var reqs = (p.paymentRequests || []); var pending = reqs.filter(function (r) { return r.status === 'pending'; });
    var f = function (id, label, val, type, extra) { return '<div class="erp-field"><label for="' + id + '">' + E(label) + '</label><input class="erp-input" id="' + id + '" type="' + (type || 'text') + '" value="' + E(val == null ? '' : val) + '"' + (extra || '') + '></div>'; };
    return window.erpWrap(ID,
      (window.erpStats ? window.erpStats([{ label: 'Term plan', value: '₦' + Number(p.termlyPrice || 15000).toLocaleString() }, { label: 'Yearly plan', value: '₦' + Number(p.yearlyPrice || 50000).toLocaleString() },
        { label: 'Preview for unpaid schools', value: (p.previewMinutes || 5) + ' min' }, { label: 'Payment requests waiting', value: pending.length }, { label: 'Approved schools', value: (p.approvedSchools || []).length }]) : '') +
      '<div class="erp-panel"><h3>Prices and bank details</h3><div class="erp-form-grid">' +
        f('psTerm', 'Term plan price (₦)', p.termlyPrice || 15000, 'number', ' min="0" step="500"') + f('psYear', 'Yearly plan price (₦)', p.yearlyPrice || 50000, 'number', ' min="0" step="500"') +
        f('psBank', 'Bank name', p.bankName || '') + f('psAccName', 'Account name', p.accountName || '') + f('psAccNo', 'Account number', p.accountNumber || '', 'text', ' inputmode="numeric" maxlength="10"') +
        f('psPreview', 'Preview countdown for schools that have not paid (1–5 minutes)', p.previewMinutes || 5, 'number', ' min="1" max="5"') +
      '</div><p class="pro-sh-sub">The countdown only reminds unpaid schools to subscribe — it is not a lock. Access for paying schools is given by approving them below.</p>' +
      '<div class="pro-sh-row"><button class="erp-btn primary" type="button" onclick="ABO_PAYSET.save()">Save payment settings</button></div></div>' +
      '<div class="erp-panel"><h3>Payment requests</h3>' + (reqs.length ? '<div class="erp-table-wrap"><table class="erp-table"><thead><tr><th>School</th><th>Plan</th><th class="num">Amount</th><th>Reference</th><th>Date</th><th>Status</th></tr></thead><tbody>' +
        reqs.slice(0, 100).map(function (r) { return '<tr><td>' + E(r.schoolName) + '</td><td>' + E(r.plan) + '</td><td class="num">₦' + Number(r.amount || 0).toLocaleString() + '</td><td>' + E(r.reference || '—') + '</td><td>' + E(String(r.requestedAt || '').slice(0, 10)) + '</td><td>' + E(r.status) + '</td></tr>'; }).join('') +
        '</tbody></table></div><p class="pro-sh-sub">Check each transfer in your bank app, then approve it in Owner Control Centre › School approvals.</p>' : '<div class="erp-empty">No payment requests yet.</div>') + '</div>' +
      '<div class="erp-panel"><h3>Online card payments</h3><p>Paying by card (Paystack) needs a server that checks every payment with Paystack before giving access. That is built into the <b>online edition</b> (Payments &amp; Plans). This offline file only records bank transfers for you to approve.</p></div>');
  }
  window.ABO_PAYSET = {
    save: function () {
      if (!owner()) return;
      var p = G('pricingData'); if (!p) return;
      var n = function (id) { return Number((document.getElementById(id) || {}).value); }; var t = function (id) { return String((document.getElementById(id) || {}).value || '').trim(); };
      var term = n('psTerm'), year = n('psYear'), prev = Math.round(n('psPreview'));
      if (!(term >= 0) || !(year >= 0)) return window.showToast('Prices must be numbers.');
      if (!(prev >= 1 && prev <= 5)) return window.showToast('The preview countdown must be between 1 and 5 minutes.');
      if (t('psAccNo') && !/^\d{10}$/.test(t('psAccNo'))) return window.showToast('A Nigerian account number has 10 digits.');
      p.termlyPrice = term; p.yearlyPrice = year; p.bankName = t('psBank'); p.accountName = t('psAccName'); p.accountNumber = t('psAccNo'); p.previewMinutes = prev;
      try { window.saveData(); } catch (e) { /* */ }
      try { window.logAudit && window.logAudit('Owner updated payment settings'); } catch (e) { /* */ }
      window.showToast('Payment settings saved.'); try { ABO.go(ID); } catch (e) { /* */ }
    },
  };
  var meta = { label: 'Payment Settings', icon: '💳', section: 'System', roles: ['owner'], order: 5, desc: 'Plan prices, bank details, the preview countdown for unpaid schools and payment requests. Owner only.', keywords: ['payment', 'subscription', 'price', 'bank', 'trial', 'countdown'] };
  window.ERP_MODULES[ID] = Object.assign({}, window.ERP_MODULES[ID] || {}, meta, { kind: 'special' });
  window.ERPRender[ID] = render;
  try { var R = window.ABO && window.ABO.registry; if (R) { if (R.get(ID)) R.setRenderer(ID, render); else R.register({ id: ID, label: meta.label, icon: meta.icon, section: meta.section, kind: 'special', roles: meta.roles, desc: meta.desc, order: meta.order, keywords: meta.keywords }, render); } } catch (e) { /* */ }
}());
