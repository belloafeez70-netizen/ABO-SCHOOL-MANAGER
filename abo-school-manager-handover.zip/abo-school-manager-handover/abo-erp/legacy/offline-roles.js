/* ==========================================================================================
   A.B.O. roles & Owner control (added 9 Oct 2026)

   The Owner controls everyone and can open every interface:
     • Owner Control Centre — one page for School office (admins), Teachers, Pupils and Parents: how many logins,
       view their screen, add a login, turn a login off/on, approve a School office login, choose what they can see.
     • "View the app as" is now faithful: pages are drawn exactly as that role would see them (before, some pages
       still showed Owner-only buttons inside the preview).
   Fixes to what each role can open (defaults — the Owner can still change anything in "Who Can See What"):
     • Print Centre: no longer open to pupils and parents; teachers see only teaching documents (score sheets, report
       cards, ID cards, registers, timetable) — no fee receipts, money ledger, store stock, data export or backup.
     • Teachers get Staff Clock-in and Birthdays in their menu (they could not clock in from their own interface).
     • Menu buttons a role cannot use (e.g. Settings for teachers, pupils, parents) are hidden instead of answering
       "Your role cannot open Settings".
     • The Owner can create Teacher and Pupil logins too (the old code allowed only the School Admin).
   ========================================================================================== */
(function () {
  'use strict';
  if (window.__aboRoles) return; window.__aboRoles = true;
  var A0 = window.ABO; if (!A0 || !A0.registry || !window.ERP_MODULES || !window.ERPRender) return;
  var R = A0.registry;

  function G(name) { if (window.aboGlobalGet) return window.aboGlobalGet(name); try { return (0, eval)('typeof ' + name + ' !== "undefined" ? ' + name + ' : undefined'); } catch (e) { return undefined; } }   // CSP-safe accessor first (no eval)
  var E = function (v) { return window.erpEsc(v); };
  var Q = function (v) { return window.erpAttr(v); };
  var toast = function (m) { try { window.showToast(m); } catch (e) { /* ignore */ } };
  var ico = function (n) { return (window.ABO_PRO_SKIN && window.ABO_PRO_SKIN.icon) ? window.ABO_PRO_SKIN.icon(n, 'pro-ico-inline') : ''; };
  function badge(text, tone) { return '<span class="erp-badge ' + (tone || '') + '">' + E(text) + '</span>'; }
  function realRole() { var u = G('currentUser'); return (u && u.role) || ''; }
  function effRole() { try { return A0.identity && A0.identity.role ? A0.identity.role() : realRole(); } catch (e) { return realRole(); } }
  function audit(t) { try { window.logAudit && window.logAudit(t); } catch (e) { /* ignore */ } }

  /* ───────── 1. default access per role ───────── */
  function setRoles(id, roles) { var m = R.get(id); if (m) m.roles = roles.slice(); if (window.ERP_MODULES[id]) window.ERP_MODULES[id].roles = roles.slice(); }
  setRoles('print-center', ['owner', 'admin', 'teacher']);
  var W = (A0.workspaces && A0.workspaces.all) || {};
  function only(role, remove, add) {
    var ws = W[role]; if (!ws || !Array.isArray(ws.only)) return;
    ws.only = ws.only.filter(function (x) { return remove.indexOf(x) < 0; });
    add.forEach(function (x) { if (ws.only.indexOf(x) < 0) ws.only.push(x); });
  }
  only('student', ['print-center'], []);
  only('parent', ['print-center'], []);
  only('teacher', [], ['staff-clockin', 'birthdays']);
  if (W.owner && Array.isArray(W.owner.actions) && !W.owner.actions.some(function (a) { return /control-centre/.test(a.go); }))
    W.owner.actions.unshift({ icon: '🛡️', label: 'Control Centre', go: "ABO.go('control-centre')" });

  /* ───────── 2. Print Centre: only what the role should print ───────── */
  var pcBase = window.ERPRender['print-center'];
  if (typeof pcBase === 'function') {
    var pc = function () {
      var html = pcBase.apply(this, arguments), role = effRole();
      if (role === 'owner' || role === 'admin') return html;
      var box = document.createElement('div'); box.innerHTML = html;
      [].forEach.call(box.querySelectorAll('.pc-tile'), function (t) {
        if (/student-payments|__bills|__inventory|transactions|imports|exportBackup/.test(t.getAttribute('onclick') || '')) t.remove();
      });
      return box.innerHTML;
    };
    window.ERPRender['print-center'] = pc; try { R.setRenderer('print-center', pc); } catch (e) { /* ignore */ }
  }

  /* ───────── 3. faithful "view as": draw pages as the viewed role ───────── */
  if (A0.render && typeof A0.render.mount === 'function' && A0.identity && A0.identity.asEffective) {
    var mount = A0.render.mount;
    A0.render.mount = function () {
      var self = this, args = arguments;
      if (A0.identity.previewing && A0.identity.previewing()) return A0.identity.asEffective(function () { return mount.apply(self, args); });
      return mount.apply(self, args);
    };
  }

  /* ───────── 4. hide menu buttons the current role cannot use ───────── */
  function tidyMenu() {
    var foot = document.querySelector('#aboSidebar .abo-side-foot'); if (!foot) return;
    [].forEach.call(foot.querySelectorAll('.abo-side-item'), function (b) {
      var m = /ABO\.go\('([^']+)'\)/.exec(b.getAttribute('onclick') || ''); if (!m) return;
      var allowed = true; try { allowed = R.canAccess(m[1], effRole()); } catch (e) { /* ignore */ }
      if (b.hidden !== !allowed) b.hidden = !allowed;
    });
  }
  new MutationObserver(function () { tidyMenu(); }).observe(document.body, { childList: true, subtree: false });
  function watchRail() { var r = document.getElementById('aboSidebar'); if (r && !r.__proTidy) { r.__proTidy = true; new MutationObserver(tidyMenu).observe(r, { childList: true }); tidyMenu(); } }
  setTimeout(watchRail, 0); setTimeout(watchRail, 1500);
  try { A0.bus.on('workspace:changed', function () { setTimeout(function () { watchRail(); tidyMenu(); }, 50); }, 'pro:tidy-menu'); } catch (e) { /* ignore */ }

  /* ───────── 5. the Owner may create every kind of login ───────── */
  function ownerAsOffice(fn) {
    return function () {
      var u = G('currentUser'); if (!u || u.role !== 'owner') return fn.apply(this, arguments);
      window.__aboOwnerU = u;
      try { window.aboGlobalSet ? window.aboGlobalSet('currentUser', Object.assign({}, window.aboGlobalGet('currentUser'), { role: 'admin', actingOwner: true })) : (0, eval)('currentUser = Object.assign({}, currentUser, { role: "admin", actingOwner: true })'); return fn.apply(this, arguments); }
      finally { window.aboGlobalSet ? window.aboGlobalSet('currentUser', window.__aboOwnerU) : (0, eval)('currentUser = window.__aboOwnerU'); delete window.__aboOwnerU; try { window.renderUserPortal && window.renderUserPortal(); } catch (e) { /* ignore */ } }
    };
  }
  ['createTeacherAccount', 'createStudentAccount'].forEach(function (n) { if (typeof window[n] === 'function' && !window[n].__ownerOk) { window[n] = ownerAsOffice(window[n]); window[n].__ownerOk = true; } });

  /* ───────── 6. Owner Control Centre ───────── */
  var GROUPS = [
    { role: 'admin', key: 'admins', title: 'School Office', sub: 'School admins who run the school day to day', icon: 'shield', manage: 'users' },
    { role: 'teacher', key: 'teachers', title: 'Teachers', sub: 'Teach classes, enter scores, write lesson notes', icon: 'users', manage: 'staff-accounts' },
    { role: 'student', key: 'students', title: 'Pupils', sub: 'See their results, tests and timetable', icon: 'graduation', manage: 'portal-access' },
    { role: 'parent', key: 'parents', title: 'Parents', sub: 'See their children’s results, fees and attendance', icon: 'heart', manage: 'parent-links' }
  ];
  var CC = { filter: '', q: '' };
  function accounts() { var ua = G('userAccounts') || {}; return GROUPS.map(function (g) { return { g: g, list: Array.isArray(ua[g.key]) ? ua[g.key] : [] }; }); }
  function statusOf(a, g) { if (a.active === false) return ['Turned off', 'rose']; if (g.role === 'admin' && !a.ownerApproved) return ['Waiting for your approval', 'gold']; return ['Active', 'green']; }
  function extraOf(a, g) {
    if (g.role === 'teacher') return a.assignedClass ? 'Class: ' + a.assignedClass : '';
    if (g.role === 'student') return a.linkedStudentName ? 'Pupil: ' + a.linkedStudentName : '';
    if (g.role === 'parent') return a.children ? 'Children: ' + a.children : '';
    if (g.role === 'admin') return a.schoolName ? 'School: ' + a.schoolName : '';
    return '';
  }
  function schoolNameNow() { var sd = G('schoolData') || {}; return (window.getCurrentSchoolName && window.getCurrentSchoolName()) || sd.name || ''; }
  function approvedList() { var pd = G('pricingData') || {}; pd.approvedSchools = Array.isArray(pd.approvedSchools) ? pd.approvedSchools : []; return pd.approvedSchools; }
  function schoolApproved(name) { name = String(name || '').toLowerCase(); return !!name && approvedList().some(function (x) { return String(x).toLowerCase() === name; }); }
  function approveSchool(name) { if (name && !schoolApproved(name)) approvedList().push(name); }
  function accessPanel() {
    var name = schoolNameNow(), ok = schoolApproved(name);
    return '<div class="pro-cc-access ' + (ok ? 'ok' : 'trial') + '"><div><small>School access</small><b>' + E(name || 'This school') + '</b>' +
      (ok ? badge('Full access — staff, pupils and parents can use everything', 'green') : badge('Trial only — school office, teachers, pupils and parents are stopped after 30 seconds', 'gold')) + '</div>' +
      (ok ? '<button class="erp-btn ghost" onclick="proCC.unapprove()">Back to trial</button>' : '<button class="erp-btn primary" onclick="proCC.approveSchool()">' + ico('check') + 'Give full access</button>') + '</div>';
  }
  function controlView() {
    if (realRole() !== 'owner') return window.erpWrap('control-centre', '<div class="erp-empty">Only the school owner can open the Control Centre.</div>');
    var all = accounts();
    var cards = all.map(function (x) {
      var total = x.list.length, off = x.list.filter(function (a) { return a.active === false; }).length;
      var waiting = x.g.role === 'admin' ? x.list.filter(function (a) { return a.active !== false && !a.ownerApproved; }).length : 0;
      return '<div class="pro-cc-card"><div class="pro-cc-h"><span class="pro-cc-ico">' + ico(x.g.icon) + '</span><div><b>' + E(x.g.title) + '</b><small>' + E(x.g.sub) + '</small></div></div>' +
        '<div class="pro-cc-nums"><span><b>' + total + '</b>logins</span><span><b>' + (total - off) + '</b>on</span><span><b>' + off + '</b>off</span>' + (x.g.role === 'admin' ? '<span' + (waiting ? ' class="warn"' : '') + '><b>' + waiting + '</b>to approve</span>' : '') + '</div>' +
        '<div class="pro-cc-acts"><button class="erp-btn primary" onclick="proCC.view(\'' + x.g.role + '\')">' + ico('eye') + 'View their screen</button>' +
        '<button class="erp-btn" onclick="proCC.chooser(\'' + x.g.role + '\')">' + ico('login') + 'Sign in as…</button>' +
        '<button class="erp-btn" onclick="proCC.add(\'' + x.g.role + '\')">' + ico('plus') + 'Add a login</button>' +
        '<button class="erp-btn ghost" onclick="ABO.go(\'roles-permissions\')">What they can see</button></div></div>';
    }).join('');
    var rows = [];
    all.forEach(function (x) {
      if (CC.filter && CC.filter !== x.g.role) return;
      x.list.forEach(function (a, i) {
        var hay = [a.name, a.loginId, extraOf(a, x.g)].join(' ').toLowerCase();
        if (CC.q && hay.indexOf(CC.q.toLowerCase()) < 0) return;
        var s = statusOf(a, x.g);
        rows.push('<tr><td><b>' + E(a.name || '—') + '</b><small class="pro-sub">' + E(extraOf(a, x.g)) + '</small></td><td><code>' + E(a.loginId || a.id || '') + '</code></td><td>' + E(x.g.title.replace(/s$/, '').replace('School Office', 'School office')) + '</td><td>' + badge(s[0], s[1]) + '</td><td class="pro-acts">' +
          (x.g.role === 'admin' && a.active !== false && !a.ownerApproved ? '<button class="erp-btn xs primary" onclick="proCC.approve(' + i + ')">Approve</button>' : '') +
          '<button class="erp-btn xs' + (a.active === false ? ' primary' : '') + '" onclick="proCC.toggle(\'' + x.g.key + '\',' + i + ')">' + (a.active === false ? 'Turn on' : 'Turn off') + '</button>' +
          '<button class="erp-btn xs ghost" onclick="proCC.person(\'' + x.g.key + '\',' + i + ')">See their screen</button>' +
          (a.active !== false ? '<button class="erp-btn xs" onclick="proCC.signInAs(\'' + x.g.key + '\',' + i + ')">Sign in as them</button>' : '') + '</td></tr>');
      });
    });
    var opts = '<option value="">Everyone</option>' + GROUPS.map(function (g) { return '<option value="' + g.role + '"' + (CC.filter === g.role ? ' selected' : '') + '>' + E(g.title) + '</option>'; }).join('');
    return window.erpWrap('control-centre',
      '<div class="erp-note">You are the owner, so you control everyone. <b>See their screen</b> lets you look without changing anything. <b>Sign in as them</b> lets you use the app fully as that person (for example enter scores as a teacher) — a bar at the top brings you back to your owner account. You can also add or turn off logins and choose which pages each group can open.</div>' +
      accessPanel() +
      '<div class="pro-cc-grid">' + cards + '</div>' +
      window.erpPanel('All logins',
        '<div class="erp-toolbar pro-wrap"><select class="erp-select pro-w" onchange="proCC.set(\'filter\', this.value)" aria-label="Group">' + opts + '</select>' +
        '<input class="erp-input pro-w" placeholder="Search a name or login code" value="' + Q(CC.q) + '" oninput="proCC.search(this.value)" id="ccSearch"></div>' +
        '<div class="erp-table-wrap"><table class="erp-table"><thead><tr><th>Name</th><th>Login code</th><th>Group</th><th>Status</th><th></th></tr></thead><tbody id="ccRows">' +
          (rows.join('') || '<tr><td colspan="5"><div class="erp-empty">No logins yet. Press “Add a login” on a group above.</div></td></tr>') + '</tbody></table></div>', rows.length + ' shown'));
  }
  function suggestId(role, name) {
    var pre = { admin: 'ADM', teacher: 'TCH', student: 'STU', parent: 'PAR' }[role] || 'USR';
    var base = String(name || '').trim().split(/\s+/)[0] || 'USER'; base = base.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6) || 'USER';
    for (var n = 1; n < 1000; n++) { var id = pre + '-' + base + '-' + (n < 10 ? '0' : '') + n; try { if (!window.findUserByLoginId(id)) return id; } catch (e) { return id; } }
    return pre + '-' + Date.now().toString(36).toUpperCase();
  }
  function rerender() { var h = document.getElementById('erpHost'); if (h && A0.render && A0.render.current() === 'control-centre') h.innerHTML = controlView(); }
  window.proCC = {
    view: function (role) { try { A0.workspaces.switchTo(role); } catch (e) { toast('Could not open that screen.'); } },
    approveSchool: function () { var n = schoolNameNow(); if (!n) return toast('Give the school a name first (School Details).'); approveSchool(n); window.saveData(); audit('Owner gave full access to ' + n); toast(n + ' now has full access.'); rerender(); },
    unapprove: function () { var n = schoolNameNow(), l = approvedList(); for (var i = l.length - 1; i >= 0; i--) if (String(l[i]).toLowerCase() === n.toLowerCase()) l.splice(i, 1); window.saveData(); audit('Owner moved ' + n + ' back to trial'); toast(n + ' is back on trial.'); rerender(); },
    person: function (key, i) { viewPerson(key, i); },
    set: function (k, v) { CC[k] = v; rerender(); },
    search: function (v) { CC.q = v; var h = document.getElementById('erpHost'); if (!h) return; var tmp = document.createElement('div'); tmp.innerHTML = controlView(); var nb = tmp.querySelector('#ccRows'), ob = document.getElementById('ccRows'); if (nb && ob) ob.innerHTML = nb.innerHTML; },
    toggle: function (key, i) {
      var ua = G('userAccounts') || {}, a = (ua[key] || [])[i]; if (!a) return;
      a.active = a.active === false; window.saveData();
      audit((a.active ? 'Turned on' : 'Turned off') + ' login ' + (a.loginId || a.id) + ' (' + key.replace(/s$/, '') + ')');
      toast((a.name || a.loginId) + (a.active ? ' can sign in again.' : ' can no longer sign in.')); rerender();
    },
    approve: function (i) {
      var ua = G('userAccounts') || {}, a = (ua.admins || [])[i]; if (!a) return;
      a.ownerApproved = true; a.approvedBy = G('OWNER_APPROVAL_EMAIL') || 'owner'; a.approvedAt = new Date().toISOString(); window.saveData();
      audit('Approved School Admin login ' + (a.loginId || a.id)); toast((a.name || a.loginId) + ' is approved and can sign in.'); rerender();
    },
    add: function (role) {
      var g = GROUPS.filter(function (x) { return x.role === role; })[0]; if (!g) return;
      var roster = (G('students') || []).filter(function (s) { return (s.name || '').trim(); });
      var classes = []; try { classes = (window.erpData().classes || []).map(function (c) { return c.name; }).filter(Boolean); } catch (e) { /* ignore */ }
      var f = function (label, inner, hint) { return '<div class="erp-field w2"><label>' + E(label) + '</label>' + inner + (hint ? '<small class="pro-sub">' + E(hint) + '</small>' : '') + '</div>'; };
      var extra = role === 'teacher' ? f('Class they teach (optional)', '<select class="erp-select" id="ccClass"><option value="">—</option>' + classes.map(function (c) { return '<option>' + E(c) + '</option>'; }).join('') + '</select>')
        : role === 'student' ? f('Which pupil is this?', '<select class="erp-select" id="ccPupil"><option value="">Choose a pupil</option>' + roster.map(function (s, i) { return '<option value="' + i + '">' + E(s.name) + '</option>'; }).join('') + '</select>', 'Pupils of the class that is open now.')
          : role === 'parent' ? f('Their children', '<input class="erp-input" id="ccKids" placeholder="e.g. Afeez Bello, Bola Adeyemi">')
            : f('Email (optional)', '<input class="erp-input" id="ccEmail" type="email">');
      window.erpModal('Add a ' + g.title.replace(/s$/, '').replace('School Office', 'School office') + ' login',
        '<div class="erp-form-grid">' + f('Full name', '<input class="erp-input" id="ccName" oninput="proCC.suggest(\'' + role + '\')" placeholder="e.g. Ada Obi">') +
        f('Login code', '<input class="erp-input" id="ccId" value="' + Q(suggestId(role, '')) + '">', 'They type this to sign in. You can change it.') + extra + '</div>',
        '<button class="erp-btn ghost" onclick="erpModalClose()">Cancel</button><button class="erp-btn primary" onclick="proCC.create(\'' + role + '\')">Create login</button>');
    },
    suggest: function (role) { var n = document.getElementById('ccName'), i = document.getElementById('ccId'); if (n && i && !i.__touched) i.value = suggestId(role, n.value); if (i && !i.__bound) { i.__bound = true; i.addEventListener('input', function () { i.__touched = true; }); } },
    create: function (role) {
      var g = GROUPS.filter(function (x) { return x.role === role; })[0], val = function (id) { var e = document.getElementById(id); return e ? String(e.value || '').trim() : ''; };
      var name = val('ccName'), id = val('ccId');
      if (name.length < 2) return toast('Type the person’s full name.');
      if (!/^[A-Za-z0-9._-]{4,40}$/.test(id)) return toast('The login code needs 4 to 40 letters or numbers (no spaces).');
      try { if (window.findUserByLoginId(id)) return toast('That login code is already used. Try another.'); } catch (e) { /* ignore */ }
      var sd = G('schoolData') || {}, fields = { loginId: id, id: id, name: name, schoolName: (window.getCurrentSchoolName && window.getCurrentSchoolName()) || sd.name || '', active: true, createdBy: 'owner', createdAt: new Date().toISOString() };
      if (role === 'admin') { fields.email = val('ccEmail'); fields.ownerApproved = true; fields.approvedBy = G('OWNER_APPROVAL_EMAIL') || 'owner'; approveSchool(fields.schoolName); }
      if (role === 'teacher') fields.assignedClass = val('ccClass');
      if (role === 'student') { var ix = val('ccPupil'), st = ix === '' ? null : (G('students') || [])[+ix]; if (!st) return toast('Choose which pupil this login is for.'); fields.studentIndex = +ix; fields.linkedStudentName = st.name; fields.admissionNo = st.attendanceNo || ''; }
      if (role === 'parent') fields.children = val('ccKids');
      window.createSecuredAccount(g.key, fields);
      audit('Owner created ' + g.title.replace(/s$/, '') + ' login ' + id);
      window.erpModalClose(); rerender();
    }
  };
  (function addModule(id, meta, render) {
    var prev = window.ERP_MODULES[id] || {};
    window.ERP_MODULES[id] = Object.assign({}, prev, meta, { kind: 'special' });
    window.ERPRender[id] = render;
    try { var m = R.get(id); if (m) { Object.assign(m, meta, { kind: 'special', hidden: false }); R.setRenderer(id, render); } else R.register({ id: id, label: meta.label, icon: meta.icon, section: meta.section, kind: 'special', roles: meta.roles, desc: meta.desc, order: meta.order, keywords: meta.keywords }, render); } catch (e) { /* ignore */ }
  })('control-centre', { label: 'Owner Control Centre', icon: '🛡️', section: 'Overview', roles: ['owner'], order: 2,
    keywords: ['control', 'owner', 'logins', 'accounts', 'view as', 'admins', 'teachers', 'pupils', 'parents', 'turn off', 'approve'],
    desc: 'Control everyone: view each group’s screen, add or turn off logins, approve the school office, and choose what each group can see.' }, controlView);


  /* ───────── 7. view one specific person's screen (their class, results or children) ───────── */
  var PA = null, paPending = false;
  var KEY_ROLE = { admins: 'admin', teachers: 'teacher', students: 'student', parents: 'parent' };
  if (A0.state && typeof A0.state.set === 'function') {
    var set0 = A0.state.set;
    A0.state.set = function (k, v) {
      // while previewing, the shadow user becomes that exact person (role and permissions stay the role's)
      if (k === 'currentUser' && v && v._previewOf && PA && PA.role === v.role) v = Object.assign({}, v, PA.fields, { role: v.role, _previewOf: v._previewOf, _realName: v._realName, _person: PA.name });
      return set0.call(this, k, v);
    };
  }
  if (A0.workspaces && typeof A0.workspaces.switchTo === 'function') {
    var sw0 = A0.workspaces.switchTo;
    A0.workspaces.switchTo = function (role) {
      if (!paPending) PA = null; paPending = false;
      var r = sw0.apply(this, arguments);
      setTimeout(paintBanner, 30); setTimeout(paintBanner, 400);
      return r;
    };
  }
  function sampleText(role) {
    var ctx = {}; try { ctx = A0.identity.previewContext ? A0.identity.previewContext(role) : {}; } catch (e) { /* ignore */ }
    if (role === 'student' && ctx.linkedStudentName) return ', using <b>' + E(ctx.linkedStudentName) + '</b> as a sample pupil';
    if (role === 'parent' && ctx.children) return ', using <b>' + E(ctx.children) + '</b> as sample children';
    return '';
  }
  function paintBanner() {
    var bar = document.querySelector('.abo-preview-bar'); if (!bar) return;
    var txt = bar.querySelector('.txt'); if (!txt) return;
    var role = effRole(), title = { admin: 'School office', teacher: 'Teacher', student: 'Pupil', parent: 'Parent' }[role] || role;
    var html = PA ? 'You are viewing <b>' + E(PA.name) + '</b>’s screen (' + E(title) + ') — exactly what they see. Nothing you look at changes their account.'
      : 'You are viewing the <b>' + E(title) + '</b> screen — exactly what a ' + E(title.toLowerCase()) + ' sees' + sampleText(role) + '.';
    if (txt.__html !== html) { txt.innerHTML = html; txt.__html = html; }
  }
  try { A0.bus.on('workspace:changed', function () { setTimeout(paintBanner, 30); }, 'pro:banner'); } catch (e) { /* ignore */ }
  function viewPerson(key, i) {
    if (realRole() !== 'owner') return toast('Only the owner can do this.');
    var ua = G('userAccounts') || {}, a = (ua[key] || [])[i], role = KEY_ROLE[key]; if (!a || !role) return;
    var fields = {}; ['name', 'loginId', 'id', 'assignedClass', 'linkedStudentName', 'studentIndex', 'admissionNo', 'children', 'schoolName', 'email'].forEach(function (f) { if (a[f] !== undefined && a[f] !== '') fields[f] = a[f]; });
    if (role === 'parent' && a.children) fields.children = a.children;
    PA = { role: role, name: a.name || a.loginId, fields: fields }; paPending = true;
    audit('Owner viewed the screen of ' + (a.name || a.loginId) + ' (' + role + ')');
    A0.workspaces.switchTo(role);
  }

  /* ───────── 8. "See the app as" on the owner's Home ───────── */
  var stripTimer = null;
  function ownerStrip() {
    var hello = document.querySelector('.mx-dash .mx-hello'); if (!hello) return;
    var previewing = A0.identity && A0.identity.previewing && A0.identity.previewing();
    var old = hello.parentNode.querySelector('.pro-viewas');
    if (realRole() !== 'owner' || previewing) { if (old) old.remove(); return; }
    if (old) return;
    var el = document.createElement('div'); el.className = 'pro-viewas';
    el.innerHTML = '<span class="pro-viewas-l">' + ico('eye') + 'See the app as</span>' +
      [['admin', 'School office', 'shield'], ['teacher', 'Teacher', 'users'], ['student', 'Pupil', 'graduation'], ['parent', 'Parent', 'heart']].map(function (x) {
        return '<button type="button" onclick="ABO.workspaces.switchTo(\'' + x[0] + '\')">' + ico(x[2]) + '<span>' + x[1] + '</span></button>';
      }).join('') + '<button type="button" onclick="proCC.chooser()">' + ico('login') + '<span>Sign in as someone</span></button>' +
      '<button type="button" class="pro-viewas-cc" onclick="ABO.go(\'control-centre\')">' + ico('settings') + '<span>Control Centre</span></button>';
    var after = hello.parentNode.querySelector('.pro-today') || hello;
    after.parentNode.insertBefore(el, after.nextSibling);
  }
  new MutationObserver(function () { clearTimeout(stripTimer); stripTimer = setTimeout(function () { try { ownerStrip(); } catch (e) { /* never break the dashboard */ } }, 40); }).observe(document.body, { childList: true, subtree: true });


  /* ───────── 9. Owner signs in AS a person (full use of their screen), and comes back with one tap ─────────
     Unlike "view", this really signs in as that account: everything works as for them (enter scores, mark
     attendance, reply to messages…). The owner's way back is kept, and every action is recorded as done by the owner. */
  var ACT_KEY = 'aboActAsOwner';
  function actAs() { try { return JSON.parse(window.localStorage.getItem(ACT_KEY) || 'null'); } catch (e) { return null; } }
  function setActAs(v) { try { if (v) window.localStorage.setItem(ACT_KEY, JSON.stringify(v)); else window.localStorage.removeItem(ACT_KEY); } catch (e) { /* preview: memory only */ } MEM_ACT = v; }
  var MEM_ACT = null;
  function acting() { return MEM_ACT || actAs(); }
  function sessionFor(user, seal) {
    var s = { id: user.loginId || user.id, role: user.role, time: Date.now(), expiresAt: Date.now() + 10 * 86400000, authenticated: true };
    if (user.role === 'owner' && seal) s.ownerSeal = seal;   // keep the owner's sealed session (Phase 3 security)
    try { window.localStorage.setItem('broadsheetSession', JSON.stringify(s)); } catch (e) { /* ignore */ }
  }
  function becomeUser(user, seal) {
    try { A0.identity && A0.identity.preview && A0.identity.preview(null); } catch (e) { /* ignore */ }   // leave any "view as"
    PA = null;
    window.__aboNextUser = user;
    window.aboGlobalSet ? window.aboGlobalSet('currentUser', window.__aboNextUser) : (0, eval)('currentUser = window.__aboNextUser'); delete window.__aboNextUser;
    sessionFor(user, seal);
    window.enterApp();
    setTimeout(paintActBar, 60); setTimeout(paintActBar, 600);
  }
  function signInAs(key, i) {
    if (realRole() !== 'owner' || acting()) return toast('Only the owner can do this.');
    var ua = G('userAccounts') || {}, a = (ua[key] || [])[i], role = KEY_ROLE[key]; if (!a || !role) return;
    if (a.active === false) return toast('This login is turned off. Turn it on first.');
    var target = null; try { target = window.findUserByLoginId(a.loginId || a.id); } catch (e) { /* ignore */ }
    if (!target) return toast('Could not find that login.');
    try { window.erpModalClose && window.erpModalClose(); } catch (e) { /* ignore */ }
    try { window.saveData(); } catch (e) { /* ignore */ }
    audit('Owner signed in as ' + (a.name || a.loginId) + ' (' + role + ')');
    var seal = (window.ABO_SEC && window.ABO_SEC.currentSeal) ? window.ABO_SEC.currentSeal() : null;
    setActAs({ owner: G('OWNER_LOGIN_ID') || 'owner', as: target.loginId || target.id, name: target.name || target.loginId, role: role, at: new Date().toISOString(), ownerSeal: seal });
    target = Object.assign({}, target, { impersonatedBy: 'Owner' });
    becomeUser(target);
    toast('You are now signed in as ' + (a.name || a.loginId) + '.');
  }
  function backToOwner() {
    var st = acting(); if (!st) return;
    var me = G('currentUser'); audit('Owner returned from ' + ((me && (me.name || me.loginId)) || 'another account'));
    try { window.saveData(); } catch (e) { /* ignore */ }
    setActAs(null);
    var owner = null; try { owner = window.findUserByLoginId(st.owner || G('OWNER_LOGIN_ID')); } catch (e) { /* ignore */ }
    if (!owner) { try { window.logoutUser(); } catch (e) { /* ignore */ } return; }
    becomeUser(owner, st.ownerSeal || null);
    try { A0.go('control-centre'); } catch (e) { /* ignore */ }
    toast('Back in your owner account.');
  }
  // keep the "signed in as" bar on screen
  function paintActBar() {
    var st = acting(), me = G('currentUser'), bar = document.getElementById('proActAsBar');
    var on = !!(st && me && (me.loginId || me.id) === st.as);
    if (!on) { if (bar) bar.remove(); return; }
    if (me && !me.impersonatedBy) me.impersonatedBy = 'Owner';
    var title = { admin: 'School office', teacher: 'Teacher', student: 'Pupil', parent: 'Parent' }[st.role] || st.role;
    var html = '<span class="ico">' + ico('shield') + '</span><span class="txt">Owner: you are signed in as <b>' + E(st.name) + '</b> (' + E(title) + '). Everything works as it does for them, and it is recorded as done by you.</span>' +
      '<button type="button" onclick="proCC.backToOwner()">' + ico('arrow-left') + 'Back to my owner account</button>';
    if (!bar) { bar = document.createElement('div'); bar.id = 'proActAsBar'; bar.className = 'pro-actas-bar no-print'; bar.setAttribute('role', 'status'); }
    var anchor = document.getElementById('aboWsBanner') || document.getElementById('aboTopbar');
    if (anchor && bar.previousSibling !== anchor) anchor.parentNode.insertBefore(bar, anchor.nextSibling);
    else if (!anchor && !bar.parentNode) document.body.insertBefore(bar, document.body.firstChild);
    if (bar.__html !== html) { bar.innerHTML = html; bar.__html = html; }
  }
  var actTimer = null;
  new MutationObserver(function () { clearTimeout(actTimer); actTimer = setTimeout(paintActBar, 50); }).observe(document.body, { childList: true });
  // signing out while signed in as someone ends it too; a reload keeps it (the bar comes back)
  var lo = window.logoutUser;
  if (typeof lo === 'function' && !lo.__actAs) { window.logoutUser = function () { setActAs(null); var b = document.getElementById('proActAsBar'); if (b) b.remove(); return lo.apply(this, arguments); }; window.logoutUser.__actAs = true; }
  setTimeout(paintActBar, 1200);
  // chooser: pick a person to sign in as
  function chooser(roleFilter) {
    var rows = [];
    accounts().forEach(function (x) {
      if (roleFilter && roleFilter !== x.g.role) return;
      x.list.forEach(function (a, i) {
        var off = a.active === false;
        rows.push('<tr><td><b>' + E(a.name || a.loginId) + '</b><small class="pro-sub">' + E(extraOf(a, x.g)) + '</small></td><td>' + E(x.g.title) + '</td><td><code>' + E(a.loginId || a.id) + '</code></td><td class="pro-acts">' +
          (off ? badge('Turned off', 'rose') : '<button class="erp-btn xs primary" onclick="proCC.signInAs(\'' + x.g.key + '\',' + i + ')">Sign in as them</button>') + '</td></tr>');
      });
    });
    var title = roleFilter ? 'Sign in as a ' + ({ admin: 'school office user', teacher: 'teacher', student: 'pupil', parent: 'parent' }[roleFilter]) : 'Sign in as someone';
    window.erpModal(title, '<p>You will use the app exactly as this person does. A bar at the top lets you come back to your owner account at any time.</p>' +
      (rows.length ? '<div class="erp-table-wrap"><table class="erp-table"><thead><tr><th>Name</th><th>Group</th><th>Login code</th><th></th></tr></thead><tbody>' + rows.join('') + '</tbody></table></div>'
        : '<div class="erp-empty">No logins in this group yet. Close this and press “Add a login” first.</div>'),
      '<button class="erp-btn ghost" onclick="erpModalClose()">Close</button>');
  }
  var cea = window.checkEarlyAccess;
  if (typeof cea === 'function' && !cea.__actAs) {
    window.checkEarlyAccess = function () { if (acting()) { try { window.stopEarlyAccess(); } catch (e) { /* ignore */ } return; } return cea.apply(this, arguments); };
    window.checkEarlyAccess.__actAs = true;
  }
  window.proCC.signInAs = signInAs;
  window.proCC.backToOwner = backToOwner;
  window.proCC.chooser = chooser;

  window.ABO_ROLES = { acting: function () { return acting(); }, effRole: effRole, groups: GROUPS, viewPerson: viewPerson, person: function () { return PA ? { role: PA.role, name: PA.name } : null; } };
})();
