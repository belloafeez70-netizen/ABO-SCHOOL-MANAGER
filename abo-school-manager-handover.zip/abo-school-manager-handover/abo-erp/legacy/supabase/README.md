# Cloud Sync (Supabase) + fingerprint clock-in — set-up guide

This applies to the main offline edition, `school_broadsheet_manager_bopc_erp.html`. The steps follow the Supabase
dashboard as of October 2026.


## Your project (checked 9 Oct 2026)
- **Project:** `https://fehpqiqqxgqugioowepu.supabase.co`. It is reachable, and the tables are locked from the public
  key, which is correct.
- **Setup status:** everything up to the activity log is installed. The **School Web Address** functions are
  missing, so run the newest `abo_supabase_setup.sql` once more in SQL Editor. It is safe to re-run.
- **Pre-filled in the app:** the Project URL and **publishable key** are already filled in on the Online Backup
  screen. Press **Connect**.
- **`@supabase/server` and the secret key (`sb_secret_…`):** these are for a backend server or Edge Function. This
  app talks to Supabase directly with the publishable key, so it does **not** need them.
  - **Never put the secret key in the app or send it to anyone.** It bypasses all security.
  - The secret key becomes useful only for a future online edition with personal logins (see `docs/LIMITATIONS.md`).

## What is stored in Supabase
Everything the school creates is stored in your Supabase project:

| Data | Supabase table |
|---|---|
| The school: learners, scores and results, report settings, finance, calendar, lesson notes, timetable, attendance, staff, parents, user accounts, CBT, messages, newsletters… | `abo_schools` |
| The Owner's **other schools** | `abo_records` (`school:…`) |
| Shared settings: pricing, owner password (hashed), payment flags | `abo_records` (`shared:…`) |
| Each user's preferences (dark mode, sidebar) | `abo_records` (`prefs:<Login ID>`) |
| Photos, logos, signatures, uploaded documents (stored once, in parts) | `abo_files`, `abo_file_parts` |
| Staff clock-ins: one row per clock-in, with how it was checked and the distance from school | `abo_clock_events` |
| **Activity log**: every sign-in (and failed attempt), page opened, change, approval, clock-in, fingerprint event, cloud event and app error, from every device | `abo_activity` |

**Kept only on the device, on purpose:**
- the sign-in session
- the phone's own fingerprint key reference (the public key is in Supabase)
- failed-sign-in counters
- the Cloud Sync connection itself, because it holds the school secret

Each device also keeps a working copy of the school, so the app still works with no internet. The copy in Supabase
is the master.

**Activity Log screen (System → Activity Log):** filter by date, type, person or text, then export to CSV. The app's
old built-in list kept only the last 100 entries; Supabase keeps everything. Activity done offline is uploaded when
the device reconnects.

**New computer or lost laptop:** sign in as Owner, open Cloud Sync, and enter the same Project URL, key, School ID and
**school secret**. Press **Download**. Everything comes back: all schools, files, settings and preferences.
**Write the school secret down and keep it safe.**

## Other features
- **Offline first:** changes wait on the device and go out when the connection returns.
- **Changes are merged:** if two devices changed the school at the same time, both sets of changes are kept.
- **Fingerprint / face clock-in** from each teacher's own phone, optionally required to be at school (GPS radius).
- **Fingerprint sign-in** on activated phones.

## Step 1: Supabase (one time, about 5 minutes)
1. Sign up at **supabase.com** and create a project. The free plan is enough. *Europe West (London)* is the closest
   region to Nigeria.
2. Open **SQL Editor → New query**. Paste the setup script and press **Run**.
   - Get the script from the app (**Cloud Sync → Copy setup script**) or from `legacy/supabase/setup.sql`.
   - It is safe to run again.
3. Copy two values:
   - **Project URL**, which looks like `https://abcdefgh.supabase.co`. It is shown under **Connect** at the top of the
     dashboard, or in Project Settings → Data API.
   - **Publishable key**, which looks like `sb_publishable_…`. It is in Project Settings → API Keys.
   - Older projects can use the "anon public" key instead. **Never use the secret key** (`sb_secret_…`); the app
     refuses it.

## Step 2: Put the app on a web address (needed for fingerprint and GPS)
Browsers only allow fingerprint, face and location on `https://` sites, not on a file opened from the phone's storage.
1. Unzip `abo-school-site.zip`.
2. Go to **app.netlify.com/drop** and drag the `abo-school-site` folder onto the page. You get an address like
   `https://bright-oak-123.netlify.app`.
3. Open that address on each phone. In Chrome, use menu → **Add to Home screen** so it opens like an app.
4. Keep one address. Fingerprints are tied to it: if you change it, staff must activate their phones again.

## Step 3: Connect the school (Owner)
1. Sign in as Owner and go to **System → Cloud Sync (Supabase)**.
2. Paste the Project URL and the Publishable key.
3. The School ID and the school secret are filled in for you. Keep the secret private, then press **Connect**.
4. The school uploads. The top bar shows **Synced**.

## Step 4: Link the teachers' phones
1. **Cloud Sync → Link a device → Send by WhatsApp** (or copy the code).
2. On the teacher's phone, open the web address and tap **Connect this phone to your school**. Paste the code.
3. The phone downloads the school. The teacher then signs in with their own Login ID.

> Anyone with the link code can read and change the school's data, so share it only with your own staff.
> To cancel all old codes, connect again with a new School ID.

## Step 5: Activate clock-in (Owner / School Admin)
1. Go to **Attendance → Staff Clock-in → Clock-in settings** and set:
   - school times and grace minutes
   - **Staff self clock-in:** on
   - **Require fingerprint or face:** on
   - **Require being at school (GPS):** on, with a radius (150 m is typical)
2. Stand at the school, press **Use my current location**, then **Save**.
3. Each teacher, once on their own phone: **Staff Clock-in → Activate this phone**, then confirm with their fingerprint
   or face.
4. Every day: **Clock in now**. The phone asks for the fingerprint/face and checks the distance from school.
   - It refuses with a clear reason, for example "You are 9.1 km from school".
5. The Owner sees each clock-in with "Fingerprint · At school · 27 m". The office can still record anyone; those
   entries are marked "Office".
6. A lost or changed phone can be deactivated under **Activated phones**.


## School web address (Settings → School Web Address)
1. The app suggests a name from your school name, for example **brightoak** → `https://brightoak.netlify.app`.
   You can edit it.
2. **Rules:** small letters, numbers and dashes, 3–40 characters. The app explains anything wrong in simple words, and
   **Fix it for me** corrects it.
3. **Reserved for you:** with Online Backup on, the name is reserved in Supabase (`abo_schools.subdomain`), so no other
   school can use the same name.
4. **Make website files:** you get `<name>-website.zip`, the app with your school name and address built in.
   - Drag the folder onto **app.netlify.com/drop**.
   - In Netlify, go to **Site configuration → Change site name** and type the same name.
5. **Your own domain later:** choose **My own domain** and type it, for example `aboedu.com.ng`.
   - The app shows the record to add at your domain company: `CNAME  brightoak → brightoak.netlify.app`.
   - Then add `brightoak.aboedu.com.ng` in Netlify → Domain management.
6. **Tap-to-connect for teachers:** once the address is saved, **Online Backup → Add a phone** gives a link like
   `https://brightoak.netlify.app/#connect=…`. The teacher taps it and their phone joins the school by itself.
7. **The school's own website greets visitors** with the school name on the sign-in page.
8. **The school secret is never put inside the website files.** Only the phone link carries it, so share that link only
   with your staff.

## How the security works
- **Locked tables.** Both tables have Row Level Security on and no public policies. The publishable key cannot read
  or write them (tested).
- **Secret-checked functions.** The app can only call the A.B.O. database functions. Each one checks the school secret
  first. The secret is stored as a bcrypt hash, never in plain text.
- **Real fingerprint checks.** Activation saves the phone's public key. Each clock-in, the phone signs a fresh random
  challenge after checking the fingerprint or face. The app verifies that signature, the website address and the
  "user verified" flag.
- **Honest limits:**
  - Phone fingerprints prove *the phone's owner* is present. On a phone shared by several people, any fingerprint
    enrolled on that phone works. That is why clock-in is done from each teacher's own phone.
  - GPS can be faked with special apps on rooted phones. Fingerprint plus GPS makes cheating much harder, but not
    impossible.
  - Supabase free projects pause after about a week with no activity. Daily school use keeps the project active. If it
    does pause, press **Restore** on the project in the Supabase dashboard. While it is paused the app keeps working on
    each device and syncs again after the restore. Paid plans never pause.
  - Back up regularly (**Backup → Export**) in addition to the cloud.
