-- ============================================================================================================
-- A.B.O. School Manager — Supabase storage: school records, files, settings, activity log, staff clock-in
-- Run ONCE in your Supabase project: Dashboard → SQL Editor → New query → paste this file → Run.
-- Safe to run again (it only creates what is missing and replaces the functions).
--
-- Security model
--   • The tables have Row Level Security ON and NO policies, so the public "anon" key cannot read or write them.
--   • The app only talks to the functions below (abo_check itself is not callable). Each one checks the school's secret (stored as a bcrypt
--     hash, never in plain text) before it reads or writes anything.
--   • The anon key is public by design (it ships inside every Supabase web app). The school secret is what protects
--     your data: keep it private, and share it only through the "Link a device" code inside the app.
-- ============================================================================================================

create schema if not exists extensions;
create extension if not exists pgcrypto with schema extensions;

-- one row per school: the whole school record (same shape the app saves on the device)
create table if not exists public.abo_schools (
  school_id    text primary key check (school_id ~ '^[a-z0-9][a-z0-9-]{2,62}$'),
  secret_hash  text not null,
  name         text,
  version      integer not null default 0,
  data         jsonb,
  updated_at   timestamptz not null default now(),
  updated_by   text,
  device       text,
  created_at   timestamptz not null default now()
);

-- staff clock-in / clock-out events, one row per tap (phones never overwrite each other)
create table if not exists public.abo_clock_events (
  id          bigint generated always as identity primary key,
  school_id   text not null references public.abo_schools(school_id) on delete cascade,
  staff       text not null,
  login_id    text,
  kind        text not null check (kind in ('in', 'out')),
  day         date not null,
  at_time     text not null,                     -- HH:MM on the phone's clock
  method      text,                               -- e.g. "fingerprint + location", "office"
  lat         double precision,
  lng         double precision,
  accuracy_m  double precision,
  distance_m  double precision,
  device      text,
  created_at  timestamptz not null default now()
);
create index if not exists abo_clock_events_school_created on public.abo_clock_events (school_id, created_at);
create unique index if not exists abo_clock_events_once on public.abo_clock_events (school_id, staff, day, kind);

alter table public.abo_schools enable row level security;
alter table public.abo_clock_events enable row level security;
revoke all on public.abo_schools, public.abo_clock_events from anon, authenticated;

-- ── helper: check a school's secret (with a limit on wrong attempts — Phase 3, 9 Oct 2026) ─────────────────
-- 20 wrong secrets from one internet address in 15 minutes → that address is refused for the rest of the window;
-- 500 wrong secrets for one school from all addresses → the school is refused for the window (distributed guessing).
create table if not exists public.abo_auth_fail (
  school_id text not null,
  ip        text not null,
  at        timestamptz not null default now()
);
create index if not exists abo_auth_fail_recent on public.abo_auth_fail (school_id, ip, at);
alter table public.abo_auth_fail enable row level security;
revoke all on public.abo_auth_fail from anon, authenticated;

drop function if exists public.abo_check(text, text);
create or replace function public.abo_check(p_school text, p_secret text)
returns boolean language plpgsql volatile security definer set search_path = public, extensions as $$
declare
  h jsonb := coalesce(nullif(current_setting('request.headers', true), '')::jsonb, '{}'::jsonb);
  v_ip text := coalesce(nullif(h->>'cf-connecting-ip', ''), nullif(h->>'x-real-ip', ''), nullif(trim(split_part(coalesce(h->>'x-forwarded-for', ''), ',', 1)), ''), 'unknown');
  n_ip int; n_all int; ok boolean;
begin
  select count(*) filter (where ip = v_ip), count(*) into n_ip, n_all
    from public.abo_auth_fail where school_id = p_school and at > now() - interval '15 minutes';
  if n_ip >= 20 or n_all >= 500 then return false; end if;
  select exists (select 1 from public.abo_schools s
                 where s.school_id = p_school and s.secret_hash = extensions.crypt(coalesce(p_secret, ''), s.secret_hash)) into ok;
  if not ok then
    insert into public.abo_auth_fail (school_id, ip) values (coalesce(p_school, ''), v_ip);
    delete from public.abo_auth_fail where at < now() - interval '1 day';
  end if;
  return ok;
end $$;
revoke all on function public.abo_check(text, text) from public, anon, authenticated;

-- ── connect: create the school on first use, or confirm the secret ─────────────────────────────────────────
-- 12 Oct 2026 hardening: (a) one internet address may create at most 5 new schools per day (stops spam / name
-- squatting scripts); (b) OPTIONAL invitation code: when the platform owner stores one in abo_config
-- ('new_school_code_hash', a bcrypt hash), nobody can create a NEW school without it (existing schools are unaffected).
create table if not exists public.abo_create_log (ip text not null, at timestamptz not null default now());
create index if not exists abo_create_log_ip on public.abo_create_log (ip, at);
create table if not exists public.abo_config (key text primary key, value text not null);
alter table public.abo_create_log enable row level security;
alter table public.abo_config enable row level security;
revoke all on public.abo_create_log, public.abo_config from anon, authenticated;
drop function if exists public.abo_connect(text, text, text);
create or replace function public.abo_connect(p_school text, p_secret text, p_name text default null, p_invite text default null)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare r public.abo_schools;
  h jsonb := coalesce(nullif(current_setting('request.headers', true), '')::jsonb, '{}'::jsonb);
  v_ip text := coalesce(nullif(h->>'cf-connecting-ip', ''), nullif(h->>'x-real-ip', ''), nullif(trim(split_part(coalesce(h->>'x-forwarded-for', ''), ',', 1)), ''), 'unknown');
  v_code text;
begin
  if p_school !~ '^[a-z0-9][a-z0-9-]{2,62}$' then return jsonb_build_object('ok', false, 'error', 'bad_school_id'); end if;
  if length(coalesce(p_secret, '')) < 12 then return jsonb_build_object('ok', false, 'error', 'weak_secret'); end if;
  select * into r from public.abo_schools where school_id = p_school;
  if not found then
    select value into v_code from public.abo_config where key = 'new_school_code_hash';
    if v_code is not null and v_code <> extensions.crypt(coalesce(p_invite, ''), v_code) then
      perform pg_sleep(0.5); return jsonb_build_object('ok', false, 'error', 'invite_required');
    end if;
    -- 5 new schools per internet address per day. Requests that arrive WITHOUT any address (should not happen on
    -- Supabase, which sends cf-connecting-ip / x-forwarded-for) share one larger budget of 100, so a missing header
    -- can never block every new school.
    if (select count(*) from public.abo_create_log where ip = v_ip and at > now() - interval '1 day') >= (case when v_ip = 'unknown' then 100 else 5 end) then
      return jsonb_build_object('ok', false, 'error', 'too_many_new_schools');
    end if;
    insert into public.abo_schools (school_id, secret_hash, name)
    values (p_school, extensions.crypt(p_secret, extensions.gen_salt('bf', 10)), left(p_name, 160)) returning * into r;
    insert into public.abo_create_log (ip) values (v_ip);
    delete from public.abo_create_log where at < now() - interval '2 days';
    return jsonb_build_object('ok', true, 'created', true, 'version', r.version);
  end if;
  if not public.abo_check(p_school, p_secret) then
    perform pg_sleep(0.5);
    return jsonb_build_object('ok', false, 'error', 'wrong_secret');
  end if;
  return jsonb_build_object('ok', true, 'created', false, 'version', r.version, 'name', r.name, 'updated_at', r.updated_at, 'updated_by', r.updated_by);
end $$;
-- ── pull the school record ────────────────────────────────────────────────────────────────────────────────
create or replace function public.abo_pull(p_school text, p_secret text, p_have integer default -1)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare r public.abo_schools;
begin
  if not public.abo_check(p_school, p_secret) then perform pg_sleep(0.5); return jsonb_build_object('ok', false, 'error', 'wrong_secret'); end if;
  select * into r from public.abo_schools where school_id = p_school;
  if r.version = p_have then   -- nothing new: do not send the whole record again
    return jsonb_build_object('ok', true, 'version', r.version, 'unchanged', true);
  end if;
  return jsonb_build_object('ok', true, 'version', r.version, 'data', r.data, 'updated_at', r.updated_at, 'updated_by', r.updated_by, 'device', r.device);
end $$;

-- ── push the school record (only if nobody else saved in between) ─────────────────────────────────────────
create or replace function public.abo_push(p_school text, p_secret text, p_data jsonb, p_base integer, p_by text default null, p_device text default null, p_force boolean default false)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare cur integer;
begin
  if not public.abo_check(p_school, p_secret) then perform pg_sleep(0.5); return jsonb_build_object('ok', false, 'error', 'wrong_secret'); end if;
  if p_data is null or jsonb_typeof(p_data) <> 'object' then return jsonb_build_object('ok', false, 'error', 'bad_data'); end if;
  if pg_column_size(p_data) > 30000000 then return jsonb_build_object('ok', false, 'error', 'too_large'); end if;   -- 30 MB per school record
  select version into cur from public.abo_schools where school_id = p_school for update;
  if cur <> p_base and not p_force then
    return jsonb_build_object('ok', false, 'error', 'conflict', 'version', cur);
  end if;
  update public.abo_schools
     set data = p_data, version = cur + 1, updated_at = now(), updated_by = left(p_by, 120), device = left(p_device, 120),
         name = coalesce(p_data #>> '{schoolData,name}', name)
   where school_id = p_school;
  return jsonb_build_object('ok', true, 'version', cur + 1);
end $$;

-- ── record one clock-in / clock-out ───────────────────────────────────────────────────────────────────────
create or replace function public.abo_clock_add(p_school text, p_secret text, p_event jsonb)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare new_id bigint;
begin
  if not public.abo_check(p_school, p_secret) then perform pg_sleep(0.5); return jsonb_build_object('ok', false, 'error', 'wrong_secret'); end if;
  insert into public.abo_clock_events (school_id, staff, login_id, kind, day, at_time, method, lat, lng, accuracy_m, distance_m, device)
  values (p_school, left(p_event->>'staff', 120), left(p_event->>'login_id', 120), p_event->>'kind', (p_event->>'day')::date,
          left(p_event->>'at_time', 5), left(p_event->>'method', 60), (p_event->>'lat')::float8, (p_event->>'lng')::float8,
          (p_event->>'accuracy_m')::float8, (p_event->>'distance_m')::float8, left(p_event->>'device', 120))
  on conflict (school_id, staff, day, kind) do nothing
  returning id into new_id;
  return jsonb_build_object('ok', true, 'id', new_id, 'duplicate', new_id is null);
end $$;

-- ── clock events since a moment (the owner's dashboard polls this) ────────────────────────────────────────
create or replace function public.abo_clock_since(p_school text, p_secret text, p_since timestamptz default now() - interval '2 days')
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
begin
  if not public.abo_check(p_school, p_secret) then perform pg_sleep(0.5); return jsonb_build_object('ok', false, 'error', 'wrong_secret'); end if;
  return jsonb_build_object('ok', true, 'now', now(), 'events', coalesce((
    select jsonb_agg(to_jsonb(e) - 'school_id' order by e.created_at)
      from public.abo_clock_events e where e.school_id = p_school and e.created_at > p_since), '[]'::jsonb));
end $$;

grant execute on function public.abo_connect(text, text, text, text) to anon, authenticated;
grant execute on function public.abo_pull(text, text, integer) to anon, authenticated;
grant execute on function public.abo_push(text, text, jsonb, integer, text, text, boolean) to anon, authenticated;
grant execute on function public.abo_clock_add(text, text, jsonb) to anon, authenticated;
grant execute on function public.abo_clock_since(text, text, timestamptz) to anon, authenticated;

-- ============================================================================================================
-- Everything else the app stores (added 9 Oct 2026)
--   abo_records   other schools of the Owner, shared settings (pricing, owner password hash, payment flags),
--                 each user's preferences (dark mode, sidebar)
--   abo_files     uploaded photos, logos, signatures and documents (stored once, in parts, by content hash)
--   abo_activity  the full activity log: sign-ins, pages opened, every change, clock-ins, security events
-- ============================================================================================================
create table if not exists public.abo_records (
  school_id   text not null references public.abo_schools(school_id) on delete cascade,
  key         text not null check (key ~ '^(school|shared|prefs):[A-Za-z0-9_.@ -]{1,120}$'),
  version     integer not null default 0,
  data        jsonb,
  updated_at  timestamptz not null default now(),
  updated_by  text,
  device      text,
  primary key (school_id, key)
);
create table if not exists public.abo_files (
  school_id   text not null references public.abo_schools(school_id) on delete cascade,
  id          text not null check (id ~ '^[a-f0-9]{40,64}$'),
  mime        text,
  size        integer,
  parts       integer not null check (parts between 1 and 400),
  created_at  timestamptz not null default now(),
  primary key (school_id, id)
);
create table if not exists public.abo_file_parts (
  school_id   text not null,
  id          text not null,
  part        integer not null,
  data        text not null,
  primary key (school_id, id, part),
  foreign key (school_id, id) references public.abo_files(school_id, id) on delete cascade
);
create table if not exists public.abo_activity (
  id          bigint generated always as identity primary key,
  school_id   text not null references public.abo_schools(school_id) on delete cascade,
  client_id   text not null,
  at          timestamptz not null,
  received_at timestamptz not null default now(),
  actor       text,
  login_id    text,
  role        text,
  kind        text not null,
  action      text not null,
  detail      jsonb,
  device      text,
  school_name text
);
create unique index if not exists abo_activity_once on public.abo_activity (school_id, client_id);
create index if not exists abo_activity_school_at on public.abo_activity (school_id, at desc);
alter table public.abo_records enable row level security;
alter table public.abo_files enable row level security;
alter table public.abo_file_parts enable row level security;
alter table public.abo_activity enable row level security;
revoke all on public.abo_records, public.abo_files, public.abo_file_parts, public.abo_activity from anon, authenticated;

-- ── records: pull what changed (p_have = {"key": version}), push one record ───────────────────────────────
create or replace function public.abo_rec_pull(p_school text, p_secret text, p_have jsonb default '{}'::jsonb, p_keys text[] default null)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
begin
  if not public.abo_check(p_school, p_secret) then perform pg_sleep(0.5); return jsonb_build_object('ok', false, 'error', 'wrong_secret'); end if;
  return jsonb_build_object('ok', true, 'records', coalesce((
    select jsonb_agg(jsonb_build_object('key', r.key, 'version', r.version, 'data', r.data, 'updated_at', r.updated_at, 'updated_by', r.updated_by))
      from public.abo_records r
     where r.school_id = p_school and (p_keys is null or r.key = any(p_keys))
       and (p_have ->> r.key is null or (p_have ->> r.key)::int <> r.version)), '[]'::jsonb));
end $$;

create or replace function public.abo_rec_push(p_school text, p_secret text, p_key text, p_data jsonb, p_base integer, p_by text default null, p_device text default null)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare cur integer;
begin
  if not public.abo_check(p_school, p_secret) then perform pg_sleep(0.5); return jsonb_build_object('ok', false, 'error', 'wrong_secret'); end if;
  if p_data is null then return jsonb_build_object('ok', false, 'error', 'bad_data'); end if;
  if pg_column_size(p_data) > 30000000 or length(coalesce(p_key, '')) > 200 then return jsonb_build_object('ok', false, 'error', 'too_large'); end if;
  select version into cur from public.abo_records where school_id = p_school and key = p_key for update;
  if not found then
    if coalesce(p_base, 0) <> 0 then return jsonb_build_object('ok', false, 'error', 'conflict', 'version', 0); end if;
    insert into public.abo_records (school_id, key, version, data, updated_by, device) values (p_school, p_key, 1, p_data, left(p_by, 120), left(p_device, 120));
    return jsonb_build_object('ok', true, 'version', 1);
  end if;
  if cur <> p_base then return jsonb_build_object('ok', false, 'error', 'conflict', 'version', cur); end if;
  update public.abo_records set data = p_data, version = cur + 1, updated_at = now(), updated_by = left(p_by, 120), device = left(p_device, 120)
   where school_id = p_school and key = p_key;
  return jsonb_build_object('ok', true, 'version', cur + 1);
end $$;

-- ── files: which are already stored, upload one part, download one part ───────────────────────────────────
create or replace function public.abo_file_has(p_school text, p_secret text, p_ids text[])
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
begin
  if not public.abo_check(p_school, p_secret) then perform pg_sleep(0.5); return jsonb_build_object('ok', false, 'error', 'wrong_secret'); end if;
  return jsonb_build_object('ok', true, 'ids', coalesce((
    select jsonb_agg(f.id) from public.abo_files f
     where f.school_id = p_school and f.id = any(p_ids)
       and (select count(*) from public.abo_file_parts p where p.school_id = f.school_id and p.id = f.id) = f.parts), '[]'::jsonb));
end $$;

create or replace function public.abo_file_put(p_school text, p_secret text, p_id text, p_mime text, p_size integer, p_part integer, p_parts integer, p_data text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
begin
  if not public.abo_check(p_school, p_secret) then perform pg_sleep(0.5); return jsonb_build_object('ok', false, 'error', 'wrong_secret'); end if;
  if p_part < 0 or p_part >= p_parts or p_parts > 40 or coalesce(p_size, 0) > 20000000 or length(p_data) > 600000 or length(coalesce(p_id, '')) > 120 then return jsonb_build_object('ok', false, 'error', 'bad_part'); end if;
  insert into public.abo_files (school_id, id, mime, size, parts) values (p_school, p_id, left(p_mime, 100), p_size, p_parts)
  on conflict (school_id, id) do nothing;
  insert into public.abo_file_parts (school_id, id, part, data) values (p_school, p_id, p_part, p_data)
  on conflict (school_id, id, part) do nothing;
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.abo_file_get(p_school text, p_secret text, p_id text, p_part integer default 0)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare f public.abo_files; d text;
begin
  if not public.abo_check(p_school, p_secret) then perform pg_sleep(0.5); return jsonb_build_object('ok', false, 'error', 'wrong_secret'); end if;
  select * into f from public.abo_files where school_id = p_school and id = p_id;
  if not found then return jsonb_build_object('ok', false, 'error', 'no_file'); end if;
  select data into d from public.abo_file_parts where school_id = p_school and id = p_id and part = p_part;
  return jsonb_build_object('ok', true, 'mime', f.mime, 'size', f.size, 'parts', f.parts, 'data', d);
end $$;

-- ── activity log: add a batch (duplicates ignored), list with filters ─────────────────────────────────────
create or replace function public.abo_activity_add(p_school text, p_secret text, p_events jsonb)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare n integer;
begin
  if not public.abo_check(p_school, p_secret) then perform pg_sleep(0.5); return jsonb_build_object('ok', false, 'error', 'wrong_secret'); end if;
  if jsonb_typeof(p_events) <> 'array' then return jsonb_build_object('ok', false, 'error', 'bad_data'); end if;
  with ins as (
    insert into public.abo_activity (school_id, client_id, at, actor, login_id, role, kind, action, detail, device, school_name)
    select p_school, left(e->>'id', 64), coalesce((e->>'at')::timestamptz, now()), left(e->>'actor', 120), left(e->>'login_id', 120), left(e->>'role', 30),
           left(coalesce(e->>'kind', 'action'), 30), left(coalesce(e->>'action', ''), 300), e->'detail', left(e->>'device', 120), left(e->>'school', 120)
      from (select value as e from jsonb_array_elements(p_events) limit 500) x
     where e->>'id' is not null
    on conflict (school_id, client_id) do nothing returning 1)
  select count(*) into n from ins;
  return jsonb_build_object('ok', true, 'added', n);
end $$;

create or replace function public.abo_activity_list(p_school text, p_secret text, p_from timestamptz default now() - interval '1 day', p_to timestamptz default now() + interval '1 day',
  p_kind text default null, p_actor text default null, p_q text default null, p_limit integer default 200, p_before bigint default null)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
begin
  if not public.abo_check(p_school, p_secret) then perform pg_sleep(0.5); return jsonb_build_object('ok', false, 'error', 'wrong_secret'); end if;
  return jsonb_build_object('ok', true, 'total', (select count(*) from public.abo_activity a where a.school_id = p_school and a.at between p_from and p_to
      and (p_kind is null or a.kind = p_kind) and (p_actor is null or a.actor ilike '%' || p_actor || '%' or a.login_id ilike '%' || p_actor || '%')
      and (p_q is null or a.action ilike '%' || p_q || '%')),
    'rows', coalesce((select jsonb_agg(to_jsonb(r) - 'school_id' - 'client_id') from (
      select * from public.abo_activity a where a.school_id = p_school and a.at between p_from and p_to
        and (p_kind is null or a.kind = p_kind) and (p_actor is null or a.actor ilike '%' || p_actor || '%' or a.login_id ilike '%' || p_actor || '%')
        and (p_q is null or a.action ilike '%' || p_q || '%') and (p_before is null or a.id < p_before)
      order by a.at desc, a.id desc limit least(greatest(coalesce(p_limit, 200), 1), 500)) r), '[]'::jsonb));
end $$;

grant execute on function public.abo_rec_pull(text, text, jsonb, text[]) to anon, authenticated;
grant execute on function public.abo_rec_push(text, text, text, jsonb, integer, text, text) to anon, authenticated;
grant execute on function public.abo_file_has(text, text, text[]) to anon, authenticated;
grant execute on function public.abo_file_put(text, text, text, text, integer, integer, integer, text) to anon, authenticated;
grant execute on function public.abo_file_get(text, text, text, integer) to anon, authenticated;
grant execute on function public.abo_activity_add(text, text, jsonb) to anon, authenticated;
grant execute on function public.abo_activity_list(text, text, timestamptz, timestamptz, text, text, text, integer, bigint) to anon, authenticated;

-- ============================================================================================================
-- School web address (subdomain) — one name per school, e.g. brightoak → brightoak.netlify.app (added 9 Oct 2026)
-- ============================================================================================================
alter table public.abo_schools add column if not exists subdomain text;
create unique index if not exists abo_schools_subdomain on public.abo_schools (lower(subdomain)) where subdomain is not null;

create or replace function public.abo_sub_valid(p_sub text) returns boolean language sql immutable as $$
  select p_sub ~ '^[a-z0-9]([a-z0-9-]{1,38}[a-z0-9])$' and p_sub !~ '--'
     and p_sub <> all (array['www','mail','admin','api','app','apps','abo','support','help','login','portal','test','demo','owner','root','ftp','smtp','netlify','school','schools','static','cdn','status']);
$$;

-- is a name free? (public: only says yes/no)
create or replace function public.abo_subdomain_check(p_sub text, p_school text default null)
returns jsonb language plpgsql stable security definer set search_path = public, extensions as $$
declare owner text;
begin
  if not public.abo_sub_valid(lower(coalesce(p_sub, ''))) then return jsonb_build_object('ok', true, 'valid', false, 'available', false); end if;
  select school_id into owner from public.abo_schools where lower(subdomain) = lower(p_sub);
  return jsonb_build_object('ok', true, 'valid', true, 'available', owner is null or owner = p_school, 'mine', owner is not null and owner = p_school);
end $$;

-- reserve / change the school's name (needs the school secret)
create or replace function public.abo_subdomain_set(p_school text, p_secret text, p_sub text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
begin
  if not public.abo_check(p_school, p_secret) then perform pg_sleep(0.5); return jsonb_build_object('ok', false, 'error', 'wrong_secret'); end if;
  if not public.abo_sub_valid(lower(coalesce(p_sub, ''))) then return jsonb_build_object('ok', false, 'error', 'bad_name'); end if;
  if exists (select 1 from public.abo_schools where lower(subdomain) = lower(p_sub) and school_id <> p_school) then
    return jsonb_build_object('ok', false, 'error', 'taken');
  end if;
  update public.abo_schools set subdomain = lower(p_sub) where school_id = p_school;
  return jsonb_build_object('ok', true, 'subdomain', lower(p_sub));
end $$;

-- the school's public name for its own web address (sign-in page welcome)
create or replace function public.abo_site_lookup(p_sub text)
returns jsonb language sql stable security definer set search_path = public, extensions as $$
  select coalesce((select jsonb_build_object('ok', true, 'name', name) from public.abo_schools where lower(subdomain) = lower(p_sub)), jsonb_build_object('ok', false, 'error', 'no_school'));
$$;

grant execute on function public.abo_subdomain_check(text, text) to anon, authenticated;
grant execute on function public.abo_subdomain_set(text, text, text) to anon, authenticated;
grant execute on function public.abo_site_lookup(text) to anon, authenticated;


-- 12 Oct 2026: CHANGE the school secret. Every device, link and old code that knows the old secret is cut off at once
-- (the owner then re-links staff phones with "Link a device"). Needs the current secret; same rate limit as all calls.
create or replace function public.abo_rekey(p_school text, p_secret text, p_new_secret text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
begin
  if length(coalesce(p_new_secret, '')) < 12 or length(p_new_secret) > 200 then return jsonb_build_object('ok', false, 'error', 'weak_secret'); end if;
  if not public.abo_check(p_school, p_secret) then perform pg_sleep(0.5); return jsonb_build_object('ok', false, 'error', 'wrong_secret'); end if;
  if p_new_secret = p_secret then return jsonb_build_object('ok', false, 'error', 'same_secret'); end if;
  update public.abo_schools set secret_hash = extensions.crypt(p_new_secret, extensions.gen_salt('bf', 10)) where school_id = p_school;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.abo_rekey(text, text, text) from public;
grant execute on function public.abo_rekey(text, text, text) to anon, authenticated;

-- make the new functions available to the app immediately
notify pgrst, 'reload schema';
