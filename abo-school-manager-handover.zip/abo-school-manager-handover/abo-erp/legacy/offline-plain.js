/* ==========================================================================================
   A.B.O. simple words (added 9 Oct 2026) — the app speaks plainly, so a 10-year-old can find their way.

   • Every page has a short, simple name and a one-line explanation ("Imprest" → "Petty Cash",
     "Chart of Accounts" → "Money Categories", "Broadsheet" → "Class Score Sheet").
   • Menu group headings, the sign-in screen, the top bar and common buttons use simple words too.
   • "Full terms" switch (menu, bottom) brings back the original words for bursars/accountants.
     The choice is remembered per user (localStorage "aboWords", also synced with Cloud Sync preferences).
   • Search still finds pages by their old names, and nothing typed by users is ever changed.
   Rules for new screens: docs/PLAIN_LANGUAGE.md
   ========================================================================================== */
(function () {
  'use strict';
  if (window.__aboPlain) return; window.__aboPlain = true;
  if (!window.ERP_MODULES) return;
  var KEY = 'aboWords';

  /* page id → [simple name, simple one-line explanation] */
  var PAGES = {
    'control-centre': ['Control Centre', 'You control everyone: see each group’s screen, add or turn off logins, and choose what they can see.'],
    'dashboard': ['Home', 'Your school at a glance: numbers, money, alerts and quick buttons.'],
    'dash-academics': ['Learning Summary', 'How the classes are doing: average scores, subjects, lesson notes and computer tests.'],
    'dash-finance': ['Money Summary', 'Money that came in, money spent and school fees paid.'],
    'dash-people': ['People Summary', 'Pupils, teachers and parents — and who still needs a login code.'],
    'dash-activity': ['Activity Summary', 'Who used the app, what they did, and any warnings.'],
    'diagnostics': ['App Health Check', 'For technical help: checks that every part of the app is working.'],
    'dash-mychildren': ['My Children', 'Each child’s scores, position in class, attendance and fees to pay.'],
    'learners-by-class': ['Classes & Pupils', 'Every class and how many pupils are in it. Tap a class to switch to it.'],
    'staff-catalog': ['Staff Jobs', 'The jobs in the school and who does what.'],
    'birthdays': ['Birthdays', 'Who has a birthday today, this week and this month. Send a WhatsApp wish or print a card.'],
    'students': ['Pupils', 'Add pupils with their photos, parents and scores.'],
    'parents': ['Parents', 'Parents and guardians, their phone numbers and which child is theirs.'],
    'staff': ['Staff List', 'All teachers and workers, their jobs and phone numbers.'],
    'document-archive': ['Saved Documents', 'Keep school letters, rules, certificates and scanned papers in one place.'],
    'id-cards': ['ID Cards', 'Print pupil ID cards with photo, class and a parent’s phone number.'],
    'dash-myclass': ['My Class', 'Your class list, who came to school, and a score summary.'],
    'academic-sessions': ['School Year & Terms', 'Set the school year and its terms, and choose the one you are in now.'],
    'promotion': ['Move to Next Class', 'At the end of the year, move pupils up to their next class, or move one pupil to another arm.'],
    'academic-structure': ['Classes & Arms', 'Make classes and arms (like Basic 1A and 1B) and choose class teachers.'],
    'subjects': ['Subjects', 'The list of subjects used for scores, report cards and tests.'],
    'class-subjects': ['Subjects for Each Class', 'Choose which subjects each class takes.'],
    'teacher-subjects': ['Who Teaches What', 'Choose which teacher teaches each subject and class.'],
    'academic-periods': ['Current Term', 'The school year and term the app is working in now.'],
    'timetables': ['Timetable', 'What each class learns at each time, Monday to Friday.'],
    'lesson-records': ['Lesson Notes', 'Teachers write weekly lesson notes; the head teacher checks and approves them.'],
    'learning-resources': ['Study Materials', 'Share notes, past questions, book links and worksheets.'],
    'video-lessons': ['Video Lessons', 'Links to video lessons for each topic.'],
    'live-classes': ['Online Classes', 'Plan online classes and share the meeting link.'],
    'dash-myassessment': ['Tests Summary', 'Tests given, who took them and how many passed.'],
    'dash-myreport': ['My Results', 'Your scores, grades and comments from your teacher and head teacher.'],
    'dash-mycbt': ['My Computer Tests', 'Tests you can take, tests you finished, and your scores.'],
    'score-corrections': ['Fix a Score', 'Ask to correct a wrong score. Someone checks it and approves it.'],
    'results-archive': ['Old Results', 'Keep each term’s results so you can look at them again later.'],
    'payment-settings': ['Payment Settings', 'Prices, bank details and the reminder countdown for schools that have not paid. Only you (the owner) see this.'],
    'cumulative-results': ['Results So Far (All Terms)', 'Add up the terms of this school year: each subject’s scores, total so far, average and position — and the overall average and position.'],
    'ca-scores': ['Class Test Scores (CA)', 'Type in the class test scores (CA1 and CA2) for each pupil.'],
    'exam-scores': ['Exam Scores', 'Type in exam scores. Totals, grades and positions are worked out for you.'],
    'results': ['Report Cards', 'Print report cards and see the class score sheet with positions.'],
    'report-card-settings': ['Report Card Settings', 'Grades, pass mark and comments that appear on report cards.'],
    'question-bank': ['Question Bank', 'Save test questions by subject and class, and use them in computer tests.'],
    'question-submissions': ['Questions from Teachers', 'Teachers send questions; the exam officer checks them and adds them to the bank.'],
    'cbt-assessments': ['Computer Tests (CBT)', 'Make tests that pupils take on a computer or phone — with a timer and automatic marking.'],
    'cbt-results': ['Computer Test Results', 'Scores, how many passed, and which questions were hard.'],
    'broadsheet': ['Class Score Sheet', 'All scores for the class on one page: tests, exam, totals and positions.'],
    'broadsheet-studio': ['Design Score Sheet', 'Choose the columns and the kinds of tests on your class score sheet.'],
    'staff-clockin': ['Staff Arrival (Clock-in)', 'Teachers mark when they arrive and leave — with fingerprint and school location if switched on.'],
    'live-class-monitor': ['Classes Right Now', 'What each class should be learning now, and which class has no teacher.'],
    'attendance': ['Attendance (Who Came)', 'Mark who is present, late or absent each day.'],
    'attendance-report': ['Attendance Report', 'How often each pupil came to school this term.'],
    'devices': ['Devices', 'Fingerprint readers, card scanners and tablets the school uses.'],
    'dash-myfees': ['My Fees', 'Fees charged, fees paid and what is left to pay for each child.'],
    'my-charges': ['Fees to Pay', 'Every fee — school fees, levies, uniform — what is paid and what is left.'],
    'fee-charges': ['Fees for Each Pupil', 'Each pupil’s fees — school fees, levies, uniform — paid and not paid.'],
    'finance': ['Money Overview', 'Money in, money out, fees not paid yet, and cash at hand.'],
    'finance-reports': ['Money Reports', 'Money reports for any dates you choose. Print or download them.'],
    'student-payments': ['Fee Payments', 'Record the fees each pupil pays and print a receipt.'],
    'outstanding-import': ['Old Debts', 'Add fees still owed from last term and check them against payments.'],
    'imprest': ['Petty Cash', 'Small money for daily spending: requests, approvals and what is left.'],
    'inventory': ['Store Items', 'Things kept in the school store, how many are left, and when to buy more.'],
    'sales': ['Sales', 'Sell uniforms, books and stationery, and print receipts.'],
    'accounts': ['Money Categories', 'The groups that money is sorted into for reports.'],
    'income': ['Money In', 'Record all the money the school receives.'],
    'expenses': ['Money Out', 'Record all the money the school spends.'],
    'transactions': ['All Money In & Out', 'Every payment in and out, with the balance.'],
    'cashbook': ['Daily Cash Book', 'Cash and bank money for each day, with the start and end balance.'],
    'notices': ['Notices', 'News and notices from the school.'],
    'announcements': ['Announcements', 'School news and notices. The school office can post new ones; everyone sees them at once.'],
    'messages': ['Messages', 'Chat between staff, parents and the school office.'],
    'calendar': ['Calendar', 'The time now, the school week, holidays, birthdays and events.'],
    'school-bills': ['School Bills', 'Fees for each class or pupil: paid, cancelled and not paid yet.'],
    'access-slips': ['Login Code Slips', 'Find login codes, make the missing ones, and print slips for parents.'],
    'portal-access': ['Login Codes', 'Make and reset login codes for pupils and parents.'],
    'parent-links': ['Link Parents to Children', 'Connect each parent to their child or children.'],
    'imports': ['Add Many at Once', 'Paste a list to add many pupils, staff, parents or classes at once.'],
    'school-profile': ['School Details', 'School name, address, phone, email, logo and classes.'],
    'school-subdomain': ['School Web Address', 'Your school’s own address on the internet — choose it, change it, and make the website.'],
    'cloud-sync': ['Online Backup (Supabase)', 'Keep the school safe online, so every phone and computer sees the same information.'],
    'activity-log': ['Who Did What', 'Every sign-in, page opened and change made, from every phone and computer.'],
    'my-timetable': ['My Timetable', 'Your class timetable.'],
    'act-as': ['See as Another User', 'See the app the way a teacher, pupil or parent sees it.'],
    'my-profile': ['My Account', 'Your details and your login.'],
    'audit-logs': ['Important Actions', 'Important changes, who made them and when.'],
    'auditlogs': ['Important Actions', 'Important changes, who made them and when.'],
    'staff-accounts': ['Create Logins', 'Make login codes for office staff, teachers, pupils and parents.'],
    'users': ['All Logins', 'All login codes, who they belong to, and turning them on or off.'],
    'roles-permissions': ['Who Can See What', 'Choose which pages each kind of user can open.'],
    'school-branding': ['School Look', 'School name, motto, logo, colours and the report card heading.'],
    'automation': ['Automatic Reminders', 'Automatic warnings for unpaid fees, attendance and more.'],
    'ai-assistant': ['Comment Helper', 'Writes teacher and head teacher comments from the scores.'],
    'newsletters': ['Newsletters', 'Read school newsletters. The school office can also write and send them.'],
    'parent-page': ['Talk with Parents', 'Parents’ comments on results, and messages with the school.'],
    'about': ['Look & About', 'Change how the app looks, and learn about it.'],
    'print-center': ['Print Centre', 'Print anything in one place: score sheets, report cards, receipts, lists, timetables and ID cards.'],
    'settings-hub': ['Settings', 'School details, grades, tests, logins, reminders and appearance in one place.'],
    'style-guide': ['Design Guide', 'For technical help: colours, text styles and buttons used in the app.']
  };
  /* menu group headings */
  var SECTIONS = {
    'Dashboards': 'Summaries', 'Platform': 'All Schools', 'Overview': 'Home', 'School Records': 'People',
    'Academics': 'Teaching', 'Digital Learning': 'Online Learning', 'Assessment': 'Tests & Results', 'Attendance': 'Attendance',
    'Finance': 'Money', 'Communication': 'Messages & Calendar', 'Portal Management': 'Logins', 'System': 'Settings',
    'Shortcuts': 'Shortcuts', 'My Classes': 'My Classes', 'My Learning': 'My Learning', 'My School': 'My School', 'My Family': 'My Family', 'Notices': 'Notices'
  };
  /* short pieces of screen text (exact match on buttons, labels, column titles and number cards) */
  var PHRASES = {
    'All modules': 'All pages', 'Collapse': 'Smaller menu', 'Settings hub': 'Settings', 'Search everything': 'Search',
    'Export CSV': 'Download list', 'Month CSV': 'Download month', 'Add new': 'Add',
    'Total records': 'Total', 'Showing': 'On screen', 'Designation': 'Job', 'Department / Section': 'Department',
    'Awaiting review': 'Waiting to be checked', 'Returned for correction': 'Sent back to fix', 'Approved': 'Approved',
    'Outstanding': 'Not paid yet', 'Fees collected': 'Fees paid', 'Attendance rate': 'Came to school',
    'Approved schools': 'Schools', 'Matching activities': 'Activities found', 'Waiting to upload': 'Waiting to send',
    'Clock-in rules': 'Arrival rules', 'Clock-in settings': 'Arrival settings', 'Activated phones (fingerprint / face)': 'Phones set up for fingerprint',
    'Changes waiting': 'Changes not sent yet', 'Clock-ins waiting': 'Arrivals not sent yet', 'Cloud version': 'Copy number',
    'Sync now': 'Save online now', 'Link a device': 'Add a phone', 'Up to date': 'All saved online',
    'Not in yet': 'Not here yet', 'Clocked in': 'Arrived', 'Clocked out': 'Left',
    'Customise': 'Change look', 'All logins': 'All logins', 'HD Picture': 'Picture', 'Grade Keys:': 'Grades:',
    'Amount Retired': 'Amount returned', 'Voucher No': 'Receipt number', 'Voucher Number': 'Receipt number', 'Payee': 'Paid to', 'Payer': 'Paid by',
    'Reorder Level': 'Buy more when below', 'Valuation': 'Value', 'Ledger': 'Money record', 'Debit': 'Money out', 'Credit': 'Money in',
    'Opening Balance': 'Start balance', 'Closing Balance': 'End balance', 'Waived': 'Cancelled', 'Remarks': 'Comments', 'Date Hired': 'Started work',
    'Admission No': 'Admission number', 'Admission No.': 'Admission number', 'Retired': 'Returned', 'Expenditure': 'Money spent'
  };
  /* sentences inside "nothing here yet" messages */
  var SENTENCES = [[/Use “Add new” to create the first record\./, 'Press “Add” to add the first one.'], [/Use "Add new" to create the first record\./, 'Press “Add” to add the first one.']];
  /* sign-in screen */
  var LOGIN_TEXT = { 'Sign in with your Login ID': 'Sign in with your login code' };
  var LOGIN = [
    ['#loginScreen .login-card label', 'Login As', 'Who are you?'],
    ['#loginScreen .login-card label', 'Login ID', 'Your login code'],
    ['#loginScreen .login-btn', 'Sign In →', 'Sign in'],
    ['#loginScreen .login-card .login-tab, #loginScreen .login-card .login-mode', 'Sign in with your Login ID', 'Sign in with your login code']
  ];
  var ROLE_OPTS = { owner: ['Owner', 'School owner'], admin: ['School Admin', 'School office'], teacher: ['Teacher', 'Teacher'], student: ['Student', 'Pupil / Student'], parent: ['Parent / Guardian', 'Parent'] };

  var PH = {}; Object.keys(PHRASES).forEach(function (k) { PH[k.toLowerCase()] = PHRASES[k]; });
  var mode = function () { try { return window.localStorage.getItem(KEY) === 'full' ? 'full' : 'simple'; } catch (e) { return 'simple'; } };
  var simple = function () { return mode() === 'simple'; };

  /* ───── page names: registry + legacy table, originals kept ───── */
  function relabel() {
    var on = simple(), R = window.ABO && window.ABO.registry;
    Object.keys(PAGES).forEach(function (id) {
      [R && R.get && R.get(id), window.ERP_MODULES[id]].forEach(function (m) {
        if (!m) return;
        if (m.__fullLabel === undefined) { m.__fullLabel = m.label; m.__fullDesc = m.desc; }
        m.label = on ? PAGES[id][0] : m.__fullLabel;
        m.desc = on ? PAGES[id][1] : m.__fullDesc;
        // search still finds a page by either name
        m.keywords = Array.isArray(m.keywords) ? m.keywords : [];
        [m.__fullLabel, PAGES[id][0]].forEach(function (k) { k = String(k || '').toLowerCase(); if (k && m.keywords.indexOf(k) < 0) m.keywords.push(k); });
      });
    });
  }
  /* ───── chrome text: section headings via a data attribute (the text itself stays, the menu fold logic keys on it) ───── */
  function sectionsPaint(root) {
    [].forEach.call((root || document).querySelectorAll('.abo-side-group-h .txt, .erp-crumbs'), function (el) {
      var orig = el.getAttribute('data-full') || el.textContent.trim();
      var s = SECTIONS[orig];
      if (el.classList.contains('txt')) {        // sidebar heading: show the simple word without changing the text node
        if (s && simple() && s !== orig) { el.setAttribute('data-simple', s); el.setAttribute('data-full', orig); } else el.removeAttribute('data-simple');
      } else if (s) { if (el.getAttribute('data-full') !== orig) el.setAttribute('data-full', orig); var w = simple() ? s : orig; if (el.textContent !== w) el.textContent = w; }
    });
  }
  function phrasesPaint(root) {
    if (!root) return;
    var nodes = root.querySelectorAll('button, th, label, .erp-stat span, .erp-att-stat span, .abo-side-item .txt, .abo-side-search-txt, .pro-rules-l > b, .erp-panel-h h3, .pro-kv span, .pro-cloud-head .erp-badge, h3');
    [].forEach.call(nodes, function (el) {
      if (el.closest('[contenteditable], .erp-table td, .pro-user-text')) return;
      // only single text-node elements (or a single trailing text node after an icon) — never user content
      var tn = null; for (var i = el.childNodes.length - 1; i >= 0; i--) { var n = el.childNodes[i]; if (n.nodeType === 3 && n.textContent.trim()) { tn = n; break; } }
      if (!tn) return;
      var cur = tn.textContent.trim(), full = tn.__full || cur;
      var split = /^([^A-Za-z]*)([\s\S]*)$/.exec(full), pre = split[1], words = split[2];
      var simpleWords = PH[words.toLowerCase()];
      if (!tn.__full && !simpleWords) return;
      tn.__full = full;
      var want = simple() && simpleWords ? pre + simpleWords : full;
      if (cur !== want) tn.textContent = tn.textContent.replace(cur, want);
    });
  }
  function emptyPaint(root) {
    if (!root) return;
    [].forEach.call(root.querySelectorAll('.erp-empty, .erp-empty *'), function (el) {
      [].forEach.call(el.childNodes, function (n) {
        if (n.nodeType !== 3) return; var full = n.__full || n.textContent, out = full;
        SENTENCES.forEach(function (x) { out = out.replace(x[0], x[1]); });
        if (out === full && !n.__full) return; n.__full = full;
        var want = simple() ? out : full; if (n.textContent !== want) n.textContent = want;
      });
    });
  }
  function loginPaint() {
    LOGIN.forEach(function (x) {
      [].forEach.call(document.querySelectorAll(x[0]), function (el) {
        var t = el.getAttribute('data-full') || el.textContent.trim();
        if (t !== x[1]) return;
        if (el.getAttribute('data-full') !== x[1]) el.setAttribute('data-full', x[1]); var w = simple() ? x[2] : x[1]; if (el.textContent !== w) el.textContent = w;
      });
    });
    [].forEach.call(document.querySelectorAll('#loginScreen .login-card *'), function (el) {
      if (el.children.length) return; var t = el.getAttribute('data-full') || el.textContent.trim(); if (!LOGIN_TEXT[t]) return;
      if (el.getAttribute('data-full') !== t) el.setAttribute('data-full', t); var w = simple() ? LOGIN_TEXT[t] : t; if (el.textContent !== w) el.textContent = w;
    });
    var sel = document.getElementById('loginRole');
    if (sel) [].forEach.call(sel.options, function (o) { var r = ROLE_OPTS[o.value]; if (r) { var w = simple() ? r[1] : r[0]; if (o.textContent !== w) o.textContent = w; } });
    var id = document.getElementById('loginId'); if (id) { var ph = simple() ? 'Type your login code' : 'Enter your Login ID'; if (id.placeholder !== ph) id.placeholder = ph; }
    var note = document.querySelector('#loginScreen .login-idnote');
    if (note) { if (!note.__full) note.__full = note.innerHTML; var nh = simple() ? 'Type the <b>login code</b> your school gave you. You don’t need a password. Forgot it? Ask the school office.' : note.__full; if (note.__shown !== nh) { note.innerHTML = nh; note.__shown = nh; } }
    var srch = [].filter.call(document.querySelectorAll('.abo-topbar-search span'), function (x) { return !x.querySelector('svg') && !x.classList.contains('pro-ico') && /search/i.test(x.textContent); })[0]; if (srch) { var st = simple() ? 'Search for a pupil, page or payment…' : 'Search learners, modules, payments…'; if (srch.textContent !== st) srch.textContent = st; }
  }
  /* ───── the switch (bottom of the menu) ───── */
  function placeSwitch() {
    var foot = document.querySelector('#aboSidebar .abo-side-foot'); if (!foot || foot.querySelector('.pro-words')) return;
    var b = document.createElement('button'); b.type = 'button'; b.className = 'abo-side-item pro-words';
    b.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); setMode(simple() ? 'full' : 'simple'); });
    var settings = [].filter.call(foot.querySelectorAll('.abo-side-item'), function (x) { return /settings/i.test(x.getAttribute('onclick') || ''); })[0];
    foot.insertBefore(b, settings || foot.firstChild);
    paintSwitch();
  }
  function paintSwitch() {
    var b = document.querySelector('.pro-words'); if (!b) return;
    var ico = (window.ABO_PRO_SKIN && window.ABO_PRO_SKIN.icon) ? window.ABO_PRO_SKIN.icon('book', 'pro-ico') : '';
    var html = '<span class="ico">' + ico + '</span><span class="txt">' + (simple() ? 'Show full terms' : 'Show simple words') + '</span>';
    if (b.__html !== html) { b.innerHTML = html; b.__html = html; }
    b.title = simple() ? 'Show the full office words (for example “Imprest”, “Chart of Accounts”)' : 'Show simple words that everyone understands';
    b.setAttribute('aria-pressed', simple() ? 'false' : 'true');
  }
  function paintAll() {
    sectionsPaint(document);
    phrasesPaint(document.getElementById('aboSidebar'));
    phrasesPaint(document.getElementById('erpHost'));
    phrasesPaint(document.getElementById('erpModalHost'));
    emptyPaint(document.getElementById('erpHost'));
    loginPaint(); placeSwitch(); paintSwitch();
  }
  function setMode(m) {
    try { window.localStorage.setItem(KEY, m === 'full' ? 'full' : 'simple'); } catch (e) { /* preview: this visit only */ }
    MEM = m;
    relabel();
    try { window.ABO.shell.renderRail(); } catch (e) { /* ignore */ }
    try { window.ABO.topbar.render(); } catch (e) { /* ignore */ }
    try { var cur = window.ABO.render.current(); if (cur) window.ABO.go(cur); else if (window.renderRoleDashboard) window.renderRoleDashboard(); } catch (e) { /* ignore */ }
    setTimeout(paintAll, 30);
    try { window.showToast(m === 'full' ? 'Showing full office terms.' : 'Showing simple words.'); } catch (e) { /* ignore */ }
  }
  var MEM = null;
  // when storage is blocked (preview windows) keep the choice for this visit
  var _mode = mode; mode = function () { return MEM || _mode(); };

  var timer = null;
  function schedule() { clearTimeout(timer); timer = setTimeout(paintAll, 60); }
  function start() {
    try { var q = new URLSearchParams(location.search).get('words'); if (q === 'full' || q === 'simple') { MEM = q; try { window.localStorage.setItem(KEY, q); } catch (e) { /* ignore */ } } } catch (e) { /* ignore */ }
    relabel(); paintAll();
    new MutationObserver(schedule).observe(document.body, { childList: true, subtree: true });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
  window.ABO_WORDS = { mode: function () { return mode(); }, set: setMode, toggle: function () { setMode(simple() ? 'full' : 'simple'); }, pages: PAGES, sections: SECTIONS };
})();
