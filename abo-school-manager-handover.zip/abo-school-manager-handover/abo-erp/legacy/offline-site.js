/* ==========================================================================================
   A.B.O. School Web Address (subdomain) — added 9 Oct 2026

   • Suggests a web address from the school name (Bright Oak Academy → brightoak.netlify.app); you can edit it.
   • Checks it as you type (simple messages), and — with Online Backup (Supabase) on — reserves it so no other school
     can take the same name.
   • Free Netlify address now (name.netlify.app); switch to your own domain later (name.yourdomain.com).
   • "Make website files": one zip with this app + the school's name/address built in, ready to drag onto Netlify.
   • A school's own website greets visitors with the school name on the sign-in page, and a "tap to connect" link
     (address/#connect=…) lets a teacher's phone join the school in one tap.
   ========================================================================================== */
(function () {
  'use strict';
  if (window.__aboSite) return; window.__aboSite = true;

  var SITE = window.ABO_SITE || null;          // set when this copy was made for one school's website
  var RESERVED = ['www', 'mail', 'admin', 'api', 'app', 'apps', 'abo', 'support', 'help', 'login', 'portal', 'test', 'demo', 'owner', 'root', 'ftp', 'smtp', 'netlify', 'school', 'schools', 'static', 'cdn', 'status'];
  var STOP = ['the', 'of', 'and', 'school', 'schools', 'academy', 'college', 'international', 'group', 'nursery', 'primary', 'secondary', 'high', 'comprehensive', 'model', 'ltd', 'limited', 'int'];

  /* ───── the welcome on a school's own website (works before sign-in, also outside the main edition) ───── */
  function welcome() {
    if (!SITE || !SITE.schoolName) return;
    document.title = SITE.schoolName + ' — School Portal';
    var card = document.querySelector('#loginScreen .login-card'); if (!card || document.getElementById('proSiteHello')) return;
    var box = document.createElement('div'); box.id = 'proSiteHello'; box.className = 'pro-site-hello';
    var esc = function (t) { return String(t || '').replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
    box.innerHTML = (SITE.logo ? '<img src="' + esc(SITE.logo) + '" alt="">' : '') + '<div><small>Welcome to</small><b>' + esc(SITE.schoolName) + '</b>' + (SITE.host ? '<span>' + esc(SITE.host) + '</span>' : '') + '</div>';
    card.insertBefore(box, card.firstChild);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', welcome); else welcome();

  if (typeof window.erpData !== 'function' || !window.ERP_MODULES || !window.ERPRender) return;

  /* ───── helpers ───── */
  function G(name) { if (window.aboGlobalGet) return window.aboGlobalGet(name); try { return (0, eval)('typeof ' + name + ' !== "undefined" ? ' + name + ' : undefined'); } catch (e) { return undefined; } }   // CSP-safe accessor first (no eval)
  var E = function (v) { return window.erpEsc(v); };
  var A = function (v) { return window.erpAttr(v); };
  var D = function () { return window.erpData(); };
  var can = function () { try { return window.erpCan(); } catch (e) { return false; } };
  var toast = function (m) { try { window.showToast(m); } catch (e) { /* ignore */ } };
  var ico = function (n) { return (window.ABO_PRO_SKIN && window.ABO_PRO_SKIN.icon) ? window.ABO_PRO_SKIN.icon(n, 'pro-ico-inline') : ''; };
  var CLOUD = function () { return window.ABO_CLOUD || null; };
  function badge(text, tone) { return '<span class="erp-badge ' + (tone || '') + '">' + E(text) + '</span>'; }
  function el(id) { return document.getElementById(id); }
  function site() { var d = D(); d.site = d.site || {}; return d.site; }
  function schoolName() { var sd = G('schoolData') || {}; return sd.name || ''; }

  /* ───── names ───── */
  function slugify(s) {
    return String(s || '').toLowerCase().replace(/&/g, ' and ').normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '').slice(0, 40).replace(/-$/, '');
  }
  function suggestions(name, address) {
    var words = String(name || '').toLowerCase().replace(/&/g, ' ').replace(/[^a-z0-9 ]+/g, ' ').split(/\s+/).filter(Boolean);
    var core = words.filter(function (w) { return STOP.indexOf(w) < 0; }); if (!core.length) core = words;
    var town = (String(address || '').split(/[,\n]/).map(function (x) { return x.trim(); }).filter(Boolean).pop() || '').toLowerCase().replace(/[^a-z]+/g, '');
    var out = [core.join(''), core.join('-'), words.join('-'), words.length >= 3 ? words.map(function (w) { return w[0]; }).join('') : '', town && core.length ? core.join('') + '-' + town : '', core.join('') + '-school'];
    var seen = {};
    return out.map(slugify).filter(function (x) { if (!x || seen[x] || problems(x).length) return false; seen[x] = 1; return true; }).slice(0, 5);
  }
  // simple, friendly rules
  function problems(sub) {
    var p = [];
    if (!sub) return ['Type a name for your school’s address.'];
    if (/[A-Z]/.test(sub)) p.push('Use small letters only (a–z), not capital letters.');
    if (/\s/.test(sub)) p.push('No spaces. Use a dash (-) instead, like bright-oak.');
    if (/[^a-zA-Z0-9\s-]/.test(sub)) p.push('Use only letters, numbers and dashes (-). No dots, commas or other signs.');
    if (sub.length < 3) p.push('Too short. Use at least 3 letters.');
    if (sub.length > 40) p.push('Too long. Use 40 letters or fewer.');
    if (/^-|-$/.test(sub)) p.push('Don’t start or end with a dash.');
    if (/--/.test(sub)) p.push('Don’t put two dashes together.');
    if (RESERVED.indexOf(sub.toLowerCase()) >= 0) p.push('“' + sub + '” is kept for the system. Please choose another name.');
    return p;
  }
  function validDomain(d) { return /^(?=.{4,200}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,24}$/.test(String(d || '')); }
  function hostOf(sub, s) { s = s || site(); return s.mode === 'own' && validDomain(s.domain) ? sub + '.' + s.domain : sub + '.netlify.app'; }
  function addressOf(sub, s) { return 'https://' + hostOf(sub, s); }
  // used by Online Backup's "Add a phone" (tap-to-connect link)
  window.ABO_SITE_ADDRESS = function () { var s = site(); return s.subdomain ? addressOf(s.subdomain, s) : (SITE && SITE.address) || ''; };

  /* ───── page ───── */
  var UI = { draft: null, mode: null, domain: null, avail: { sub: null, state: 'idle' }, timer: null };
  function draft() {
    var s = site();
    if (UI.draft === null) UI.draft = s.subdomain || suggestions(schoolName(), (G('schoolData') || {}).address)[0] || '';
    if (UI.mode === null) UI.mode = s.mode || 'netlify';
    if (UI.domain === null) UI.domain = s.domain || '';
    return UI.draft;
  }
  function view() {
    if (!can()) return window.erpWrap('school-subdomain', '<div class="erp-empty">Only the school owner or the school office can change the school’s web address.</div>');
    var s = site(), sub = draft(), cl = CLOUD(), connected = !!(cl && cl.configured && cl.configured());
    var saved = s.subdomain ? addressOf(s.subdomain, s) : '';
    var sugg = suggestions(schoolName(), (G('schoolData') || {}).address);
    var tempS = { mode: UI.mode, domain: UI.domain };
    return window.erpWrap('school-subdomain',
      (saved ? '<div class="pro-site-now"><div><small>Your school’s web address</small><b id="sdSaved">' + E(saved) + '</b>' +
          (s.reserved ? badge('Reserved for your school', 'green') : connected ? badge('Not reserved yet — press Save', 'gold') : badge('Saved on this device', '')) + '</div>' +
          '<div class="pro-wrap"><button class="erp-btn" onclick="proSite.copy()">' + ico('copy') + 'Copy</button><a class="erp-btn ghost" target="_blank" rel="noopener" href="https://wa.me/?text=' + A(encodeURIComponent('Our school website: ' + saved)) + '">' + ico('whatsapp') + 'Share</a></div></div>'
        : '<div class="erp-note">Give your school its own address on the internet, like <b>' + E(addressOf(sub || 'yourschool', tempS)) + '</b>. Teachers and parents open it on their phones.</div>') +

      window.erpPanel('1 · Choose the name',
        '<label class="pro-sd-label" for="sdName">School name in the address</label>' +
        '<div class="pro-sd-input"><span>https://</span><input id="sdName" value="' + A(sub) + '" autocomplete="off" autocapitalize="none" spellcheck="false" oninput="proSite.input(this.value)" aria-describedby="sdRules sdAvail"><span id="sdSuffix">.' + E(UI.mode === 'own' && validDomain(UI.domain) ? UI.domain : 'netlify.app') + '</span></div>' +
        '<div id="sdRules" class="pro-sd-rules" role="status"></div>' +
        '<div id="sdAvail" class="pro-sd-avail" role="status"></div>' +
        (sugg.length ? '<div class="pro-sd-sugg"><small>Ideas:</small>' + sugg.map(function (x) { return '<button type="button" class="pro-chip" onclick="proSite.pick(\'' + A(x) + '\')">' + E(x) + '</button>'; }).join('') + '</div>' : '') +
        '<div class="pro-wrap" style="margin-top:12px"><button class="erp-btn primary" id="sdSave" onclick="proSite.save()">' + ico('check') + 'Save address</button><button class="erp-btn ghost" id="sdFix" onclick="proSite.fix()">Fix it for me</button></div>' +
        (!connected ? '<p class="pro-sub" style="margin:10px 0 0">Tip: turn on <b>Online Backup</b> (Settings) so this name is reserved for your school and no other school can take it.</p>' : '')) +

      window.erpPanel('2 · Where the address lives',
        '<label class="pro-toggle"><input type="radio" name="sdMode" value="netlify"' + (UI.mode !== 'own' ? ' checked' : '') + ' onchange="proSite.mode(\'netlify\')"><span><b>Free address</b><small>' + E((sub || 'yourschool') + '.netlify.app') + ' — free, works today.</small></span></label>' +
        '<label class="pro-toggle"><input type="radio" name="sdMode" value="own"' + (UI.mode === 'own' ? ' checked' : '') + ' onchange="proSite.mode(\'own\')"><span><b>My own domain</b><small>' + E((sub || 'yourschool') + '.' + (UI.domain || 'yourdomain.com')) + ' — if you have bought a domain (for example aboedu.com.ng).</small></span></label>' +
        (UI.mode === 'own' ? '<div class="erp-form-grid" style="margin-top:8px"><div class="erp-field w2"><label>Your domain</label><input class="erp-input" id="sdDomain" placeholder="aboedu.com.ng" value="' + A(UI.domain) + '" oninput="proSite.domain(this.value)" autocapitalize="none" spellcheck="false"><small class="pro-sub" id="sdDomainMsg"></small></div></div>' : '')) +

      window.erpPanel('3 · Make the website',
        '<p>Press the button to get your school’s website files. They have your school name and address inside.</p>' +
        '<div class="pro-wrap"><button class="erp-btn primary" onclick="proSite.make()">' + ico('download') + 'Make website files</button><input type="file" id="sdSrc" accept=".html,text/html" hidden onchange="proSite.fromFile(this)"></div>' +
        '<ol class="pro-steps" style="margin-top:12px">' +
          '<li>Unzip the file you downloaded.</li>' +
          '<li>Open <b>app.netlify.com/drop</b> and drag the folder onto the page.</li>' +
          '<li>In Netlify: <b>Site configuration → Change site name</b> → type <b id="sdNameStep">' + E(sub || 'yourschool') + '</b> → Save.</li>' +
          '<li>Done! Open <b id="sdAddrStep">' + E(addressOf(sub || 'yourschool', tempS)) + '</b> on any phone.</li></ol>' +
        '<p class="pro-sub">If Netlify says the name is taken, add your town, like <b>' + E((sub || 'brightoak') + '-ikeja') + '</b>, and save it here too.</p>' +
        (UI.mode === 'own' ? '<div id="sdDns">' + dnsBox(sub, tempS) + '</div>' : '')) +

      window.erpPanel('4 · Share with teachers and parents',
        '<ul class="pro-list"><li>Send the address on WhatsApp or print it on letters and report cards.</li>' +
        '<li>Teachers: in <b>Online Backup → Add a phone</b> you get a link they just tap — their phone joins the school by itself.</li>' +
        '<li>Fingerprint clock-in and location only work on the school’s web address (https), not on a file opened from the phone.</li></ul>'));
  }
  function dnsBox(sub, s) {
    if (!validDomain(s.domain)) return '<p class="pro-sub">Type your domain above to see the setting to add at your domain company.</p>';
    return '<p><b>At your domain company (for example Whogohost, Qservers or Namecheap)</b>, add this record:</p>' +
      '<div class="erp-table-wrap"><table class="erp-table"><thead><tr><th>Type</th><th>Name / Host</th><th>Points to / Value</th></tr></thead><tbody><tr><td><b>CNAME</b></td><td><code>' + E(sub || 'yourschool') + '</code></td><td><code>' + E((sub || 'yourschool') + '.netlify.app') + '</code></td></tr></tbody></table></div>' +
      '<p class="pro-sub">Then in Netlify: <b>Domain management → Add a domain</b> → type <b>' + E((sub || 'yourschool') + '.' + s.domain) + '</b>. Netlify adds the padlock (https) for free. It can take up to a few hours to start working.</p>';
  }
  /* live checks without redrawing the page (so typing is never interrupted) */
  function paint() {
    var sub = UI.draft || '', p = problems(sub), tempS = { mode: UI.mode, domain: UI.domain };
    var r = el('sdRules'); if (r) r.innerHTML = p.length ? p.map(function (x) { return '<div class="bad">✗ ' + E(x) + '</div>'; }).join('') : '<div class="ok">✓ Good name. Your address will be <b>' + E(addressOf(sub, tempS)) + '</b></div>';
    var sv = el('sdSave'); if (sv) sv.disabled = !!p.length || UI.avail.state === 'taken';
    var fx = el('sdFix'); if (fx) fx.hidden = !p.length || !slugify(sub) || slugify(sub) === sub;
    var sf = el('sdSuffix'); if (sf) sf.textContent = '.' + (UI.mode === 'own' && validDomain(UI.domain) ? UI.domain : 'netlify.app');
    var ns = el('sdNameStep'); if (ns) ns.textContent = sub || 'yourschool';
    var as = el('sdAddrStep'); if (as) as.textContent = addressOf(sub || 'yourschool', tempS);
    var dn = el('sdDns'); if (dn) dn.innerHTML = dnsBox(sub, tempS);
    var dm = el('sdDomainMsg'); if (dm) dm.textContent = UI.domain && !validDomain(UI.domain) ? 'Type it like aboedu.com.ng — no https://, no spaces.' : '';
    var av = el('sdAvail'); if (av) {
      var st = UI.avail.sub === sub ? UI.avail.state : 'idle';
      av.innerHTML = p.length ? '' : st === 'checking' ? '<span class="pro-sub">Checking if the name is free…</span>' : st === 'free' ? '<span class="ok">✓ Free to use</span>' : st === 'mine' ? '<span class="ok">✓ This is your school’s name</span>'
        : st === 'taken' ? '<span class="bad">✗ Another school already uses this name. Try one of the ideas below, or add your town.</span>' : st === 'offline' ? '<span class="pro-sub">Could not check right now (no internet). You can still save it.</span>' : '';
    }
  }
  function checkSoon() {
    clearTimeout(UI.timer);
    var cl = CLOUD(), sub = UI.draft;
    if (!cl || !cl.configured || !cl.configured() || problems(sub).length) { UI.avail = { sub: sub, state: 'idle' }; paint(); return; }
    UI.avail = { sub: sub, state: 'checking' }; paint();
    UI.timer = setTimeout(function () {
      cl.callPublic('abo_subdomain_check', { p_sub: sub, p_school: cl.schoolId() }).then(function (r) {
        if (UI.draft !== sub) return;
        UI.avail = { sub: sub, state: r.mine ? 'mine' : r.available ? 'free' : 'taken' }; paint();
      }, function () { if (UI.draft === sub) { UI.avail = { sub: sub, state: 'offline' }; paint(); } });
    }, 450);
  }

  /* ───── tiny ZIP writer (stored, no compression) — works offline, no library ───── */
  var CRC = (function () { var t = new Uint32Array(256); for (var n = 0; n < 256; n++) { var c = n; for (var k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  function crc32(b) { var c = 0xFFFFFFFF; for (var i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
  function zip(files) {
    var enc = new TextEncoder(), parts = [], central = [], offset = 0, now = new Date();
    var time = (now.getHours() << 11) | (now.getMinutes() << 5) | (now.getSeconds() >> 1), date = ((now.getFullYear() - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate();
    files.forEach(function (f) {
      var name = enc.encode(f.name), data = typeof f.data === 'string' ? enc.encode(f.data) : f.data, crc = crc32(data);
      var h = new DataView(new ArrayBuffer(30));
      h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint16(6, 0x0800, true); h.setUint16(8, 0, true); h.setUint16(10, time, true); h.setUint16(12, date, true);
      h.setUint32(14, crc, true); h.setUint32(18, data.length, true); h.setUint32(22, data.length, true); h.setUint16(26, name.length, true); h.setUint16(28, 0, true);
      parts.push(new Uint8Array(h.buffer), name, data);
      var c = new DataView(new ArrayBuffer(46));
      c.setUint32(0, 0x02014b50, true); c.setUint16(4, 20, true); c.setUint16(6, 20, true); c.setUint16(8, 0x0800, true); c.setUint16(10, 0, true); c.setUint16(12, time, true); c.setUint16(14, date, true);
      c.setUint32(16, crc, true); c.setUint32(20, data.length, true); c.setUint32(24, data.length, true); c.setUint16(28, name.length, true); c.setUint32(42, offset, true);
      central.push(new Uint8Array(c.buffer), name);
      offset += 30 + name.length + data.length;
    });
    var csize = central.reduce(function (a, b) { return a + b.length; }, 0), e = new DataView(new ArrayBuffer(22));
    e.setUint32(0, 0x06054b50, true); e.setUint16(8, files.length, true); e.setUint16(10, files.length, true); e.setUint32(12, csize, true); e.setUint32(16, offset, true);
    return new Blob(parts.concat(central, [new Uint8Array(e.buffer)]), { type: 'application/zip' });
  }
  function download(blob, name) { var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); setTimeout(function () { a.remove(); }, 800); }

  function buildSite(html) {
    var s = site(), sub = s.subdomain; if (!sub) { toast('Save the address first (step 1).'); return false; }
    if (!/ABO-PRO-SKIN|abo-pro-skin/.test(html) || !/loginScreen/.test(html)) { toast('That file is not the A.B.O. app. Choose school_broadsheet_manager_bopc_erp.html.'); return false; }
    var sd = G('schoolData') || {}, cl = CLOUD(), cconf = null;
    try { var raw = JSON.parse(window.localStorage.getItem('aboSupabase') || 'null'); if (raw && raw.url) cconf = { url: raw.url, key: raw.anon, school: raw.school }; } catch (e) { /* ignore */ }
    var conf = { subdomain: sub, host: hostOf(sub, s), address: addressOf(sub, s), schoolName: sd.name || '', motto: sd.motto || '', builtAt: new Date().toISOString(), supabase: cconf };
    if (sd.logo && sd.logo.length < 250000) conf.logo = sd.logo;
    // built in pieces: these markers must never appear literally inside this page's own script
    var M0 = '<' + '!-- ABO-SITE -->', M1 = '<' + '!-- /ABO-SITE -->', S0 = '<' + 'script>', S1 = '<' + '/script>';
    var block = M0 + '\n' + S0 + 'window.ABO_SITE=' + JSON.stringify(conf).replace(/</g, '\\u003c') + ';' + S1 + '\n' + M1 + '\n';
    html = html.replace(new RegExp(M0 + '[\\s\\S]*?' + M1.replace('/', '\\/') + '\\n?', 'g'), '');
    html = html.replace(/<head([^>]*)>/i, function (m) { return m + '\n' + block; });
    html = html.replace(/<title>[^<]*<\/title>/i, '<title>' + E(sd.name || 'School') + ' — School Portal</title>');
    var headers = ['/*', '  Permissions-Policy: geolocation=(self), publickey-credentials-get=(self), publickey-credentials-create=(self), camera=(), microphone=(), payment=()',
      '  X-Content-Type-Options: nosniff', '  Referrer-Policy: strict-origin-when-cross-origin', '  X-Frame-Options: SAMEORIGIN', '  Strict-Transport-Security: max-age=31536000', '  Cache-Control: no-cache', ''].join('\n');
    var readme = [(sd.name || 'School') + ' — website files', '', 'Address: ' + conf.address, '',
      'How to put it online (free, about 2 minutes):', '  1. Unzip this file.', '  2. Open https://app.netlify.com/drop and drag the "' + sub + '-website" folder onto the page.',
      '  3. In Netlify: Site configuration -> Change site name -> type ' + sub + ' -> Save.', '  4. Open ' + (s.mode === 'own' ? 'https://' + sub + '.netlify.app' : conf.address) + ' on any phone.',
      s.mode === 'own' && validDomain(s.domain) ? '\nOwn domain: at your domain company add  CNAME  ' + sub + '  ->  ' + sub + '.netlify.app\nThen in Netlify: Domain management -> Add a domain -> ' + conf.host : '', '',
      'Keep one address: phone fingerprints are tied to it.', ''].join('\n');
    var dir = sub + '-website/';
    download(zip([{ name: dir + 'index.html', data: html }, { name: dir + '_headers', data: headers }, { name: dir + 'netlify.toml', data: '[build]\n  publish = "."\n' }, { name: dir + 'README.txt', data: readme }]), sub + '-website.zip');
    try { window.logAudit && window.logAudit('Made website files for ' + conf.address); } catch (e) { /* ignore */ }
    toast('Website files ready: ' + sub + '-website.zip');
    return true;
  }

  window.proSite = {
    input: function (v) { UI.draft = String(v || '').trim(); paint(); checkSoon(); },
    pick: function (v) { UI.draft = v; var i = el('sdName'); if (i) i.value = v; paint(); checkSoon(); },
    fix: function () { window.proSite.pick(slugify(UI.draft)); },
    mode: function (m) { UI.mode = m === 'own' ? 'own' : 'netlify'; rerender(); },
    domain: function (v) { UI.domain = String(v || '').trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, ''); paint(); },
    save: function () {
      var sub = UI.draft, p = problems(sub);
      if (p.length) { toast(p[0]); return Promise.resolve(false); }
      if (UI.mode === 'own' && !validDomain(UI.domain)) { toast('Type your domain like aboedu.com.ng, or choose the free address.'); return Promise.resolve(false); }
      var cl = CLOUD(), s = site();
      var done = function (reserved) {
        var before = s.subdomain;
        s.subdomain = sub; s.mode = UI.mode; s.domain = UI.mode === 'own' ? UI.domain : (s.domain || ''); s.reserved = !!reserved; s.savedAt = new Date().toISOString();
        window.erpSave();
        try { window.logAudit && window.logAudit((before && before !== sub ? 'Changed the school web address to ' : 'Set the school web address to ') + addressOf(sub, s)); } catch (e) { /* ignore */ }
        toast('Saved: ' + addressOf(sub, s)); rerender(); return true;
      };
      if (cl && cl.configured && cl.configured()) {
        return cl.call('abo_subdomain_set', { p_sub: sub }).then(function () { return done(true); }, function (e) {
          if (e && e.message === 'taken') { UI.avail = { sub: sub, state: 'taken' }; paint(); toast('Another school already uses “' + sub + '”. Please choose another name.'); return false; }
          if (e && e.kind === 'network') { toast('No internet — saved on this device. It will be reserved when you save again online.'); return done(false); }
          toast(e && e.message || 'Could not save.'); return false;
        });
      }
      return Promise.resolve(done(false));
    },
    copy: function () {
      var t = window.ABO_SITE_ADDRESS(); if (!t) return;
      var ok = function () { toast('Address copied.'); };
      if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(t).then(ok, fb); else fb();
      function fb() { var ta = document.createElement('textarea'); ta.value = t; ta.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); ok(); } catch (e) { toast(t); } ta.remove(); }
    },
    make: function () {
      if (!site().subdomain) { toast('Save the address first (step 1).'); return Promise.resolve(false); }
      // the app's own file: read it from where it was opened; if the browser does not allow that, ask for it
      return fetch(location.href.split('#')[0], { cache: 'no-store' }).then(function (r) { if (!r.ok) throw new Error('no'); return r.text(); })
        .then(function (html) { return buildSite(html); }, function () {
          toast('Choose the app file (school_broadsheet_manager_bopc_erp.html) to build the website.');
          var f = el('sdSrc'); if (f) f.click(); return false;
        });
    },
    fromFile: function (input) {
      var f = input.files && input.files[0]; if (!f) return;
      var rd = new FileReader(); rd.onload = function () { buildSite(String(rd.result || '')); input.value = ''; }; rd.readAsText(f);
    },
    _slugify: slugify, _problems: problems, _suggest: suggestions, _zip: zip
  };
  function rerender() { var h = el('erpHost'); if (h && window.ERPRender['school-subdomain'] && window.ABO && window.ABO.render && window.ABO.render.current() === 'school-subdomain') { h.innerHTML = view(); setTimeout(function () { paint(); checkSoon(); }, 0); } }

  function addModule(id, meta, render) {
    var prev = window.ERP_MODULES[id] || {};
    window.ERP_MODULES[id] = Object.assign({}, prev, meta, { kind: 'special' });
    window.ERPRender[id] = render;
    try { var R = window.ABO && window.ABO.registry; if (R) { var m = R.get(id); if (m) { Object.assign(m, meta, { kind: 'special', hidden: false }); R.setRenderer(id, render); } else R.register({ id: id, label: meta.label, icon: meta.icon, section: meta.section, kind: 'special', roles: meta.roles, desc: meta.desc, order: meta.order || 500, keywords: meta.keywords || [] }, render); } } catch (e) { /* ignore */ }
  }
  addModule('school-subdomain', { label: 'School Web Address', icon: '🌐', section: 'System', roles: ['owner', 'admin'], order: 14,
    keywords: ['subdomain', 'domain', 'website', 'web address', 'url', 'netlify', 'link'],
    desc: 'Choose, change and publish your school’s own web address (subdomain).' }, function () {
      setTimeout(function () { paint(); checkSoon(); }, 0);
      return view();
    });
})();
