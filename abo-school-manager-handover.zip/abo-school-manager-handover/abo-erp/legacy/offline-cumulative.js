/* ==========================================================================================
   A.B.O. offline edition — Cumulative Results ("results so far this session")   (11 Oct 2026)

   The offline app keeps ONE term at a time. Earlier terms come from:
     1. Old Results (Results Archive) — "Archive current term" at the end of each term (best: automatic);
     2. a backup file of last term (the normal "Backup" .json) — "Bring in from a backup file";
     3. typing last term's totals in — "Type past term totals".
   This page adds them to the current term, per subject and overall, for the current class and session:
     • each subject: 1st / 2nd / 3rd term totals, total so far, cumulative average, grade, remark, position
     • overall: each term's average, cumulative average, grade, cumulative position, change since last term, result,
       and one plain-English sentence a parent can read.
   3rd term = the whole-session (annual) result. 2nd and 3rd term report cards get a "Results so far" block.

   Cumulative average (Settings on this page):
     'taken' (default) — divide by the terms the pupil was scored in (fair to new pupils);
     'all'             — divide by every term the subject was taught in the class (a missed term counts as 0).
   Overall cumulative average = average of the subject cumulative averages. Positions are 1-2-2-4 (ties share).
   Pupils are matched across terms by admission number, then by name.
   Everything is stored in the school's own data (schoolData.erp.cumulative) and saved with the normal save.
   ========================================================================================== */
(function () {
  'use strict';
  if (window.__aboCumulative) return; window.__aboCumulative = true;
  if (typeof window.erpData !== 'function' || !window.ERP_MODULES || !window.ERPRender) return;

  function G(name) { if (window.aboGlobalGet) return window.aboGlobalGet(name); try { return (0, eval)('typeof ' + name + ' !== "undefined" ? ' + name + ' : undefined'); } catch (e) { return undefined; } }   // CSP-safe accessor first (no eval)
  var D = function () { return window.erpData(); };
  var save = function () { window.erpSave(); };
  var E = function (v) { return window.erpEsc(v); };
  var toast = function (m) { try { window.showToast(m); } catch (e) { /* ignore */ } };
  var ORDER = { '1ST': 1, '2ND': 2, '3RD': 3 };
  var LABEL = { '1ST': '1st term', '2ND': '2nd term', '3RD': '3rd term' };
  var WORD = { '1ST': 'first', '2ND': 'second', '3RD': 'third' };
  var ID = 'cumulative-results';
  var r2 = function (n) { return Math.round((Number(n) + Number.EPSILON) * 100) / 100; };
  var sum = function (xs) { return xs.reduce(function (a, b) { return a + b; }, 0); };
  var avg = function (xs) { return xs.length ? r2(sum(xs) / xs.length) : null; };
  var ord = function (n) { if (!n) return '–'; var s = ['th', 'st', 'nd', 'rd'], v = n % 100; return n + (s[(v - 20) % 10] || s[v] || s[0]); };
  var dash = function (v) { return v === null || v === undefined || v === '' ? '–' : String(v); };

  function termKey(t) {
    var s = String(t || '').toUpperCase().replace(/TERM/g, '').trim();
    if (/^(1|1ST|FIRST)$/.test(s)) return '1ST'; if (/^(2|2ND|SECOND)$/.test(s)) return '2ND'; if (/^(3|3RD|THIRD)$/.test(s)) return '3RD';
    return s;
  }
  var norm = function (s) { return String(s || '').toLowerCase().replace(/\s+/g, ' ').trim(); };
  function store() { var d = D(); d.cumulative = d.cumulative || {}; var c = d.cumulative; if (!Array.isArray(c.terms)) c.terms = []; if (c.divisor !== 'all') c.divisor = 'taken'; if (c.showOnReport === undefined) c.showOnReport = true; return c; }
  function passMark() { try { var p = Number(D().reportSettings && D().reportSettings.passMark); return p > 0 ? p : 40; } catch (e) { return 40; } }
  function grade(a) { try { return window.computeGrade ? window.computeGrade(a) : ''; } catch (e) { return ''; } }
  function remark(g, a) { try { return window.getRemark ? window.getRemark(g, a) : ''; } catch (e) { return ''; } }
  function liveSubjects() { var s = G('subjects') || []; return s.map(function (x) { return typeof x === 'string' ? x : (x && (x.name || x.subject)) || ''; }); }
  function liveStudents() { try { if (typeof window.recalculateAll === 'function') window.recalculateAll(); } catch (e) { /* ignore */ } return (G('students') || []).filter(function (s) { return s && String(s.name || '').trim(); }); }
  function cur() { var gs = G('globalSettings') || {}; return { term: termKey(gs.term || '1ST'), session: String(gs.session || '').trim(), className: String(gs.className || '').trim() }; }

  /* every earlier term we know about, in one shape: {term, session, className, source, at, subjects[], students:[{name, adm, totals:{subject:n}}]} */
  function sources() {
    var out = []; var d = D(); var subjNow = liveSubjects();
    (d.resultsArchive || []).forEach(function (a) {
      var names = Array.isArray(a.subjectNames) && a.subjectNames.length ? a.subjectNames : null;
      out.push({ id: a.id, term: termKey(a.term), session: String(a.session || '').trim(), className: String(a.className || '').trim(), source: 'archived', at: a.at, by: a.by, assumedOrder: !names && !(a.students[0] && a.students[0].subjects && a.students[0].subjects[0] && a.students[0].subjects[0].name),
        students: (a.students || []).map(function (s) {
          var t = {}; (s.subjects || []).forEach(function (x, i) { var n = (x && x.name) || (names && names[i]) || subjNow[i]; if (n) t[n] = Number(x && x.total) || 0; });
          return { name: s.name, adm: s.admissionNo || '', totals: t };
        }) });
    });
    store().terms.forEach(function (e) { out.push({ id: e.id, term: termKey(e.term), session: e.session, className: e.className, source: e.source, at: e.at, by: e.by, students: e.students }); });
    return out;
  }
  function pastTermsFor(c) {
    var best = {};
    sources().forEach(function (s) {
      if (norm(s.session) !== norm(c.session) || norm(s.className) !== norm(c.className) || !(ORDER[s.term] < ORDER[c.term])) return;
      if (!best[s.term] || String(s.at || '') > String(best[s.term].at || '')) best[s.term] = s;
    });
    return Object.keys(best).sort(function (a, b) { return ORDER[a] - ORDER[b]; }).map(function (k) { return best[k]; });
  }

  function summary(r, ctx) {
    var first = String(r.name || '').trim().split(/\s+/)[0] || 'This pupil';
    if (r.cumulativeAverage === null) return first + ' has no scores yet this session.';
    var multi = ctx.terms.length > 1;
    var p = [(multi ? 'After the ' + (WORD[ctx.term] || ctx.term.toLowerCase()) + ' term, ' : 'This term, ') + first + '’s ' + (multi ? 'cumulative ' : '') + 'average is ' + r.cumulativeAverage + '% (' + (r.grade || '') + '), which is ' +
      (r.cumulativeAverage >= 85 ? 'outstanding' : r.cumulativeAverage >= 70 ? 'very good' : r.cumulativeAverage >= 60 ? 'good' : r.cumulativeAverage >= 50 ? 'fair' : r.cumulativeAverage >= 40 ? 'just passing' : 'below the pass mark') + '.'];
    if (multi && r.change !== null) p.push(Math.abs(r.change) < 0.5 ? 'That is about the same as last term.' : 'This term’s average is ' + Math.abs(r.change) + ' points ' + (r.change > 0 ? 'higher' : 'lower') + ' than last term.');
    if (r.position) p.push(first + ' is ' + ord(r.position) + ' of ' + ctx.size + ' in the class ' + (multi ? 'so far this session.' : 'this term.'));
    if (r.best) p.push('Best subject so far: ' + r.best.name + ' (' + r.best.avg + '%).');
    if (r.weakest && r.weakest.name !== (r.best && r.best.name) && r.weakest.avg < Math.max(ctx.pass + 15, 55)) p.push('Needs more attention: ' + r.weakest.name + ' (' + r.weakest.avg + '%).');
    if (r.status === 'Fail') p.push('Extra help at home and in school is advised.');
    return p.join(' ');
  }

  /* the calculation — pure function of the data above */
  function compute() {
    var c = cur(); var st = store(); var past = pastTermsFor(c); var pass = passMark();
    var subjNow = liveSubjects(); var live = liveStudents();
    var terms = past.map(function (p) { return { term: p.term, label: LABEL[p.term] || p.term, source: p.source, assumedOrder: !!p.assumedOrder } }).concat([{ term: c.term, label: (LABEL[c.term] || c.term) + ' (now)', source: 'current' }]);
    var subjects = subjNow.filter(Boolean).slice();
    past.forEach(function (p) { p.students.forEach(function (s) { Object.keys(s.totals || {}).forEach(function (n) { if (subjects.indexOf(n) < 0) subjects.push(n); }); }); });
    // index past pupils by admission number and by name
    var idx = past.map(function (p) { var a = {}, n = {}; p.students.forEach(function (s) { if (String(s.adm || '').trim()) a[norm(s.adm)] = s; n[norm(s.name)] = s; }); return { a: a, n: n }; });
    var offered = subjects.map(function (sn) { return terms.map(function (t, ti) {
      if (ti === terms.length - 1) return live.some(function (s) { var i = subjNow.indexOf(sn); return i >= 0 && s.subjects && s.subjects[i] && Number(s.subjects[i].total) > 0; });
      return past[ti].students.some(function (s) { return Number((s.totals || {})[sn]) > 0; });
    }); });
    var rows = live.map(function (s) {
      var match = idx.map(function (ix) { return (String(s.attendanceNo || '').trim() && ix.a[norm(s.attendanceNo)]) || ix.n[norm(s.name)] || null; });
      var subj = subjects.map(function (sn, si) {
        var tt = terms.map(function (t, ti) {
          if (ti === terms.length - 1) { var i = subjNow.indexOf(sn); var v = i >= 0 && s.subjects && s.subjects[i] ? Number(s.subjects[i].total) : 0; return v > 0 ? r2(v) : null; }
          var m = match[ti]; var pv = m && m.totals ? Number(m.totals[sn]) : 0; return pv > 0 ? r2(pv) : null;
        });
        var got = tt.filter(function (v) { return v !== null; });
        if (!got.length) return { tt: tt, taken: 0, total: null, avg: null, grade: '', remark: '', pos: null };
        var n = st.divisor === 'all' ? Math.max(got.length, offered[si].filter(Boolean).length) : got.length;
        var a = r2(sum(got) / n); var g = grade(a);
        return { tt: tt, taken: got.length, total: r2(sum(got)), avg: a, grade: g, remark: remark(g, a), pos: null };
      });
      var termAvgs = terms.map(function (t, ti) { return avg(subj.map(function (x) { return x.tt[ti]; }).filter(function (v) { return v !== null; })); });
      var cums = subj.map(function (x) { return x.avg; }).filter(function (v) { return v !== null; });
      var ca = avg(cums); var now = termAvgs[terms.length - 1]; var prev = terms.length > 1 ? termAvgs[terms.length - 2] : null;
      var ranked = subj.map(function (x, i) { return { name: subjects[i], avg: x.avg }; }).filter(function (x) { return x.avg !== null; }).sort(function (a, b) { return b.avg - a.avg; });
      return { name: s.name, adm: s.attendanceNo || '', subj: subj, termAvgs: termAvgs, cumulativeAverage: ca, grade: ca === null ? '' : grade(ca), status: ca === null ? 'Pending' : ca >= pass ? 'Pass' : 'Fail',
        change: now !== null && prev !== null ? r2(now - prev) : null, marks: r2(sum(subj.map(function (x) { return x.total || 0; }))), obtainable: sum(subj.map(function (x) { return x.taken; })) * 100,
        best: ranked[0] || null, weakest: ranked.length > 1 ? ranked[ranked.length - 1] : null, matched: match.map(function (m) { return !!m; }), position: null };
    });
    var rank = function (list, get) { var srt = list.filter(function (r) { return get(r) !== null; }).sort(function (a, b) { return get(b) - get(a); }); var last = null, lr = 0; srt.forEach(function (r, i) { var v = get(r); if (last === null || v !== last) lr = i + 1; last = v; r.__rank = lr; }); return srt; };
    rank(rows, function (r) { return r.cumulativeAverage; }).forEach(function (r) { r.position = r.__rank; });
    subjects.forEach(function (sn, si) { rank(rows, function (r) { return r.subj[si].avg; }).forEach(function (r) { r.subj[si].pos = r.__rank; }); });
    rows.forEach(function (r) { delete r.__rank; });
    var ctx = { term: c.term, terms: terms, size: rows.length, pass: pass };
    rows.forEach(function (r) { r.summary = summary(r, ctx); });
    rows.sort(function (a, b) { return (a.position || 1e9) - (b.position || 1e9) || String(a.name).localeCompare(String(b.name)); });
    var stat = function (xs) { return xs.length ? { avg: avg(xs), hi: Math.max.apply(null, xs), lo: Math.min.apply(null, xs), n: xs.length } : { avg: null, hi: null, lo: null, n: 0 }; };
    var subjStats = subjects.map(function (sn, si) { var o = stat(rows.map(function (r) { return r.subj[si].avg; }).filter(function (v) { return v !== null; })); o.termAvgs = terms.map(function (t, ti) { return avg(rows.map(function (r) { return r.subj[si].tt[ti]; }).filter(function (v) { return v !== null; })); }); return o; });
    var overall = stat(rows.map(function (r) { return r.cumulativeAverage; }).filter(function (v) { return v !== null; }));
    overall.passed = rows.filter(function (r) { return r.status === 'Pass'; }).length;
    overall.termAvgs = terms.map(function (t, ti) { return avg(rows.map(function (r) { return r.termAvgs[ti]; }).filter(function (v) { return v !== null; })); });
    var unmatched = rows.filter(function (r) { return r.matched.some(function (m) { return !m; }); }).length;
    // keep only subjects somebody actually has
    var keep = subjects.map(function (sn, si) { return rows.some(function (r) { return r.subj[si].taken > 0; }); });
    return { cur: c, terms: terms, past: past, subjects: subjects, keep: keep, rows: rows, subjStats: subjStats, overall: overall, pass: pass, divisor: st.divisor, unmatched: unmatched,
      method: st.divisor === 'all' ? 'Cumulative subject average = total marks so far ÷ number of terms the subject was taught (a missed term counts as 0). Overall cumulative average = average of the subject cumulative averages.'
        : 'Cumulative subject average = total marks so far ÷ number of terms the pupil was scored in that subject. Overall cumulative average = average of the subject cumulative averages.' };
  }

  /* ───────────────────────── page ───────────────────────── */
  var view = { mode: 'class', cols: 'all', subject: 0, pupil: 0 };
  function seg(name, opts, val) { return '<div class="cum-seg" role="group">' + opts.map(function (o) { return '<button type="button" class="cum-seg-btn' + (o[0] === val ? ' on' : '') + '" aria-pressed="' + (o[0] === val) + '" onclick="ABO_CUM.set(\'' + name + '\',\'' + o[0] + '\')">' + E(o[1]) + '</button>'; }).join('') + '</div>'; }
  function classTable(b) {
    var every = view.cols === 'all' && b.terms.length > 1; var per = every ? b.terms.length + 1 : 1; var subs = b.subjects.map(function (s, i) { return i; }).filter(function (i) { return b.keep[i]; });
    var h1 = '<tr><th rowspan="2">Pos</th><th rowspan="2" class="nm">Name</th>' + subs.map(function (i) { return '<th colspan="' + per + '">' + E(b.subjects[i]) + '</th>'; }).join('') +
      (b.terms.length > 1 ? '<th colspan="' + b.terms.length + '">Term averages</th>' : '') + '<th rowspan="2">Cum. avg</th><th rowspan="2">Grade</th>' + (b.terms.length > 1 ? '<th rowspan="2">Change</th>' : '') + '<th rowspan="2">Result</th></tr>';
    var h2 = '<tr>' + subs.map(function () { return every ? b.terms.map(function (t) { return '<th class="sub">' + t.term + '</th>'; }).join('') + '<th class="sub">CUM</th>' : '<th class="sub">' + (b.terms.length > 1 ? 'CUM' : 'TOT') + '</th>'; }).join('') +
      (b.terms.length > 1 ? b.terms.map(function (t) { return '<th class="sub">' + t.term + '</th>'; }).join('') : '') + '</tr>';
    var body = b.rows.map(function (r, ri) {
      return '<tr><td class="c"><b>' + ord(r.position) + '</b></td><td class="nm"><a href="#" onclick="ABO_CUM.pupil(' + ri + ');return false">' + E(r.name) + '</a></td>' +
        subs.map(function (i) { var s = r.subj[i]; return every ? s.tt.map(function (v) { return '<td class="c">' + dash(v) + '</td>'; }).join('') + '<td class="c b">' + dash(s.avg) + '</td>' : '<td class="c b">' + dash(s.avg) + '</td>'; }).join('') +
        (b.terms.length > 1 ? r.termAvgs.map(function (v) { return '<td class="c">' + dash(v) + '</td>'; }).join('') : '') +
        '<td class="c b">' + dash(r.cumulativeAverage) + '</td><td class="c">' + E(r.grade) + '</td>' + (b.terms.length > 1 ? '<td class="c ' + (r.change > 0 ? 'up' : r.change < 0 ? 'down' : '') + '">' + (r.change === null ? '–' : (r.change > 0 ? '+' : '') + r.change) + '</td>' : '') + '<td class="c">' + r.status + '</td></tr>';
    }).join('');
    var foot = '<tr><th></th><th class="nm">Class average</th>' + subs.map(function (i) { var s = b.subjStats[i]; return every ? s.termAvgs.map(function (v) { return '<th>' + dash(v) + '</th>'; }).join('') + '<th>' + dash(s.avg) + '</th>' : '<th>' + dash(s.avg) + '</th>'; }).join('') +
      (b.terms.length > 1 ? b.overall.termAvgs.map(function (v) { return '<th>' + dash(v) + '</th>'; }).join('') : '') + '<th>' + dash(b.overall.avg) + '</th><th></th>' + (b.terms.length > 1 ? '<th></th>' : '') + '<th>' + b.overall.passed + ' passed</th></tr>';
    return '<div class="cum-wrap"><table class="cum-t"><thead>' + h1 + h2 + '</thead><tbody>' + body + '</tbody><tfoot>' + foot + '</tfoot></table></div>';
  }
  function subjectTable(b) {
    var subs = b.subjects.map(function (s, i) { return i; }).filter(function (i) { return b.keep[i]; }); if (subs.indexOf(view.subject) < 0) view.subject = subs[0] || 0; var i = view.subject; var st = b.subjStats[i];
    var rows = b.rows.filter(function (r) { return r.subj[i].taken; }).sort(function (x, y) { return (x.subj[i].pos || 1e9) - (y.subj[i].pos || 1e9); });
    return '<div class="cum-tools"><label>Subject <select class="erp-select" onchange="ABO_CUM.set(\'subject\',this.value)">' + subs.map(function (k) { return '<option value="' + k + '"' + (k === i ? ' selected' : '') + '>' + E(b.subjects[k]) + '</option>'; }).join('') + '</select></label>' +
      '<span class="cum-chip">Class cumulative average <b>' + dash(st.avg) + '</b></span><span class="cum-chip">Highest <b>' + dash(st.hi) + '</b></span><span class="cum-chip">Lowest <b>' + dash(st.lo) + '</b></span></div>' +
      '<div class="cum-wrap"><table class="cum-t"><thead><tr><th>Pos</th><th class="nm">Name</th>' + b.terms.map(function (t) { return '<th>' + E(t.label) + '</th>'; }).join('') + '<th>Total so far</th><th>Cum. avg</th><th>Grade</th><th class="nm">Remark</th></tr></thead><tbody>' +
      rows.map(function (r) { var s = r.subj[i]; return '<tr><td class="c"><b>' + ord(s.pos) + '</b></td><td class="nm">' + E(r.name) + '</td>' + s.tt.map(function (v) { return '<td class="c">' + dash(v) + '</td>'; }).join('') + '<td class="c">' + dash(s.total) + '</td><td class="c b">' + dash(s.avg) + '</td><td class="c">' + E(s.grade) + '</td><td class="nm">' + E(s.remark) + '</td></tr>'; }).join('') +
      '</tbody><tfoot><tr><th></th><th class="nm">Class average</th>' + st.termAvgs.map(function (v) { return '<th>' + dash(v) + '</th>'; }).join('') + '<th></th><th>' + dash(st.avg) + '</th><th></th><th></th></tr></tfoot></table></div>';
  }
  function pupilBlock(b, r, opts) {
    opts = opts || {};
    var subs = b.subjects.map(function (s, i) { return i; }).filter(function (i) { return r.subj[i].taken; });
    var facts = '<div class="cum-facts"><div><span>Cumulative average</span><b>' + (r.cumulativeAverage === null ? '–' : r.cumulativeAverage + '% · ' + E(r.grade)) + '</b></div>' +
      '<div><span>Cumulative position</span><b>' + (r.position ? ord(r.position) + ' of ' + b.rows.length : '–') + '</b></div>' +
      (b.terms.length > 1 ? '<div><span>Change since last term</span><b>' + (r.change === null ? '–' : (r.change > 0 ? '+' : '') + r.change + ' points') + '</b></div>' : '') +
      '<div><span>Result</span><b>' + r.status + '</b></div></div>';
    var table = '<table class="cum-t' + (opts.report ? ' cum-rep' : '') + '"><thead><tr><th class="nm">Subject</th>' + b.terms.map(function (t) { return '<th>' + E(t.label.replace(' (now)', '')) + '</th>'; }).join('') + '<th>Total so far</th><th>Cumulative average</th><th>Grade</th><th>Pos</th><th>Class avg</th></tr></thead><tbody>' +
      subs.map(function (i) { var s = r.subj[i]; return '<tr><td class="nm">' + E(b.subjects[i]) + '</td>' + s.tt.map(function (v) { return '<td class="c">' + dash(v) + '</td>'; }).join('') + '<td class="c">' + dash(s.total) + '</td><td class="c b">' + dash(s.avg) + '</td><td class="c">' + E(s.grade) + '</td><td class="c">' + ord(s.pos) + '</td><td class="c">' + dash(b.subjStats[i].avg) + '</td></tr>'; }).join('') +
      '</tbody><tfoot><tr><th class="nm">Term average</th>' + r.termAvgs.map(function (v) { return '<th>' + (v === null ? '–' : v + '%') + '</th>'; }).join('') + '<th>' + (r.obtainable ? r.marks + ' / ' + r.obtainable : '–') + '</th><th>' + (r.cumulativeAverage === null ? '–' : r.cumulativeAverage + '%') + '</th><th>' + E(r.grade) + '</th><th>' + ord(r.position) + '</th><th>' + (b.overall.avg === null ? '–' : b.overall.avg + '%') + '</th></tr></tfoot></table>';
    return facts + '<p class="cum-sum">' + E(r.summary) + '</p>' + '<div class="cum-wrap">' + table + '</div>';
  }
  function pupilView(b) {
    if (!b.rows.length) return ''; if (view.pupil >= b.rows.length) view.pupil = 0; var r = b.rows[view.pupil];
    var names = b.rows.map(function (x, i) { return { i: i, n: x.name }; }).sort(function (x, y) { return String(x.n).localeCompare(String(y.n)); });
    return '<div class="cum-tools"><label>Pupil <select class="erp-select" onchange="ABO_CUM.set(\'pupil\',this.value)">' + names.map(function (x) { return '<option value="' + x.i + '"' + (x.i === view.pupil ? ' selected' : '') + '>' + E(x.n) + '</option>'; }).join('') + '</select></label></div>' + pupilBlock(b, r);
  }
  function sourcesNote(b) {
    if (!b.past.length) return '';
    return '<div class="cum-src">' + b.past.map(function (p) {
      var src = p.source === 'archived' ? 'from Old Results' : p.source === 'imported' ? 'from a backup file' : 'typed in';
      return '<span class="cum-chip">' + E(LABEL[p.term]) + ' — ' + src + (p.assumedOrder ? ' (subjects matched by order)' : '') + (p.source !== 'archived' ? ' <button type="button" class="cum-x" title="Remove this term" aria-label="Remove ' + E(LABEL[p.term]) + '" onclick="ABO_CUM.remove(\'' + E(p.id) + '\')">×</button>' : '') + '</span>';
    }).join('') + (b.unmatched ? '<span class="cum-chip warn">' + b.unmatched + ' pupil(s) not found in an earlier term — check names / admission numbers</span>' : '') + '</div>';
  }
  function title(b) { return b.cur.term === '3RD' && b.terms.length === 3 ? 'Whole-session (annual) cumulative result' : b.terms.length > 1 ? 'Cumulative result — 1st term to ' + LABEL[b.cur.term] : LABEL[b.cur.term] + ' result'; }
  function render() {
    var b = compute(); var st = store();
    var head = '<div class="cum-head"><b>' + E((G('schoolData') || {}).name || 'School') + '</b><span>' + E(b.cur.className) + ' · ' + E(b.cur.session) + ' session · ' + b.terms.map(function (t) { return E(t.label.replace(' (now)', '')); }).join(' + ') + '</span><h3>' + E(title(b)) + '</h3></div>';
    var none = b.terms.length === 1 ? '<div class="cum-note">' + (b.cur.term === '1ST'
      ? 'This is the 1st term, so the cumulative result is the same as this term’s result. In 2nd and 3rd term the earlier terms are added automatically.'
      : 'No earlier term was found for ' + E(b.cur.className) + ', ' + E(b.cur.session) + '. Add it in one of three ways: (1) at the end of each term press “Archive current term” in Old Results; (2) bring it in from last term’s backup file; (3) type last term’s totals.') +
      ' Tip: archive every term at the end of the term — it is the easiest way.</div>' : '';
    var stats = window.erpStats ? window.erpStats([{ label: 'Pupils', value: b.rows.length }, { label: 'Terms added up', value: b.terms.length }, { label: 'Class cumulative average', value: dash(b.overall.avg) }, { label: 'Highest / lowest', value: dash(b.overall.hi) + ' / ' + dash(b.overall.lo) }, { label: 'Passed', value: b.overall.passed + ' of ' + b.overall.n }]) : '';
    var tools = '<div class="erp-toolbar cum-bar">' + seg('mode', [['class', 'Whole class'], ['subject', 'One subject'], ['pupil', 'One pupil']], view.mode) +
      (view.mode === 'class' && b.terms.length > 1 ? seg('cols', [['all', 'Every term'], ['cum', 'Cumulative only']], view.cols) : '') + '<div class="grow"></div>' +
      '<button type="button" class="erp-btn ghost" onclick="ABO_CUM.print()">Print</button><button type="button" class="erp-btn ghost" onclick="ABO_CUM.csv()">Excel (CSV)</button>' +
      (window.erpCan && window.erpCan() ? '<button type="button" class="erp-btn ghost" onclick="ABO_CUM.importFile()">Bring in from a backup file</button><button type="button" class="erp-btn ghost" onclick="ABO_CUM.typeIn()">Type past term totals</button>' : '') + '</div>';
    var settings = window.erpCan && window.erpCan() ? '<details class="cum-set"><summary>Settings</summary><label><input type="checkbox"' + (st.showOnReport ? ' checked' : '') + ' onchange="ABO_CUM.setOpt(\'showOnReport\',this.checked)"> Show “Results so far” on 2nd and 3rd term report cards</label>' +
      '<label>When a pupil missed a term: <select class="erp-select" onchange="ABO_CUM.setOpt(\'divisor\',this.value)"><option value="taken"' + (st.divisor === 'taken' ? ' selected' : '') + '>divide by the terms the pupil took (recommended)</option><option value="all"' + (st.divisor === 'all' ? ' selected' : '') + '>divide by every term the subject was taught (missed term = 0)</option></select></label></details>' : '';
    var main = !b.rows.length ? '<div class="abo-empty"><b>No pupils in this class yet</b><small>Add pupils and scores first.</small></div>' : view.mode === 'class' ? classTable(b) : view.mode === 'subject' ? subjectTable(b) : pupilView(b);
    return window.erpWrap(ID, stats + tools + none + sourcesNote(b) + '<div class="cum-doc" id="cumDoc">' + head + main + '<p class="cum-meth">' + E(b.method) + ' Positions: two pupils on the same average share a place (1-2-2-4). Pass mark ' + b.pass + '%.</p></div>' + settings);
  }
  function rerender() { var h = document.getElementById('erpHost'); if (h && (window.ABO && ABO.render && ABO.render.current && ABO.render.current() === ID)) h.innerHTML = render(); else if (h && window.erpActiveModule === ID) h.innerHTML = render(); else try { ABO.go(ID); } catch (e) { /* */ } }

  /* ── bring in past terms ── */
  function newId() { return 'cum' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
  function importFile() {
    var inp = document.createElement('input'); inp.type = 'file'; inp.accept = '.json,application/json';
    inp.onchange = function () {
      var f = inp.files && inp.files[0]; if (!f) return; var rd = new FileReader();
      rd.onload = function () {
        var data; try { data = JSON.parse(rd.result); } catch (e) { return toast('That file is not an A.B.O. backup (.json).'); }
        var c = cur(); var gs = data.globalSettings || {}; var t = termKey(gs.term); var sess = String(gs.session || '').trim();
        if (!Array.isArray(data.students) || !ORDER[t]) return toast('That file is not an A.B.O. backup with scores.');
        if (norm(sess) !== norm(c.session)) return toast('That backup is for the ' + (sess || 'unknown') + ' session. Cumulative results add up terms of the same session (' + c.session + ').');
        if (!(ORDER[t] < ORDER[c.term])) return toast('That backup is for ' + LABEL[t] + '. Only earlier terms than ' + LABEL[c.term] + ' can be added.');
        var list = null; var subj = Array.isArray(data.subjects) ? data.subjects.map(function (x) { return typeof x === 'string' ? x : (x && x.name) || ''; }) : liveSubjects();
        if (norm(gs.className) === norm(c.className)) list = data.students;
        else { try { var L = data.schoolData && data.schoolData.erp && data.schoolData.erp.learners; var k = L && Object.keys(L).find(function (n) { return norm(n) === norm(c.className); }); if (k && Array.isArray(L[k])) list = L[k]; } catch (e) { /* */ } }
        if (!list) return toast('That backup has no pupils for ' + c.className + '. Open the right class first, or use the backup of this class.');
        var entry = { id: newId(), term: t, session: c.session, className: c.className, source: 'imported', at: new Date().toISOString(), by: (window.erpUser && (window.erpUser().name || window.erpUser().loginId)) || '', file: String(f.name).slice(0, 80),
          students: list.filter(function (s) { return s && String(s.name || '').trim(); }).map(function (s) { var tt = {}; (s.subjects || []).forEach(function (x, i) { if (subj[i]) tt[subj[i]] = Number(x && x.total) || 0; }); return { name: s.name, adm: s.attendanceNo || '', totals: tt }; }) };
        if (!entry.students.length) return toast('No pupil scores found in that backup.');
        var st = store(); st.terms = st.terms.filter(function (e) { return !(e.term === t && norm(e.session) === norm(c.session) && norm(e.className) === norm(c.className) && e.source !== 'archived'); }); st.terms.push(entry);
        save(); try { window.logAudit && window.logAudit('Cumulative: brought in ' + LABEL[t] + ' scores for ' + c.className + ' from ' + entry.file); } catch (e) { /* */ }
        toast(LABEL[t] + ' scores added for ' + entry.students.length + ' pupils.'); rerender();
      };
      rd.readAsText(f);
    };
    inp.click();
  }
  function typeIn() {
    var c = cur(); var earlier = ['1ST', '2ND'].filter(function (t) { return ORDER[t] < ORDER[c.term]; });
    if (!earlier.length) return toast('This is the 1st term — there is no earlier term to type in.');
    var t = earlier[earlier.length - 1]; var subj = liveSubjects(); var pupils = liveStudents();
    var draw = function (term) {
      var prev = pastTermsFor(c).find(function (p) { return p.term === term; }) || { students: [] }; var byN = {}; prev.students.forEach(function (s) { byN[norm(s.name)] = s; });
      return '<div class="cum-type"><label>Term <select class="erp-select" id="cumTypeTerm" onchange="ABO_CUM.typeTerm(this.value)">' + earlier.map(function (x) { return '<option value="' + x + '"' + (x === term ? ' selected' : '') + '>' + LABEL[x] + '</option>'; }).join('') + '</select></label>' +
        '<p class="cum-meth">Type each pupil’s TOTAL (out of 100) for ' + LABEL[term] + '. Leave a box empty if the pupil did not take the subject.</p><div class="cum-wrap"><table class="cum-t cum-grid"><thead><tr><th class="nm">Pupil</th>' + subj.map(function (s) { return '<th>' + E(s) + '</th>'; }).join('') + '</tr></thead><tbody>' +
        pupils.map(function (p, pi) { var o = byN[norm(p.name)]; return '<tr><td class="nm">' + E(p.name) + '</td>' + subj.map(function (s, si) { var v = o && o.totals && Number(o.totals[s]) > 0 ? o.totals[s] : ''; return '<td><input class="cum-in" inputmode="decimal" type="number" min="0" max="100" step="0.5" data-p="' + pi + '" data-s="' + si + '" value="' + v + '" aria-label="' + E(p.name + ' ' + s) + '"></td>'; }).join('') + '</tr>'; }).join('') +
        '</tbody></table></div></div>';
    };
    window.ABO_CUM.typeTerm = function (x) { t = x; var m = document.querySelector('.cum-type'); if (m) m.outerHTML = draw(x); };
    window.ABO_CUM.saveTyped = function () {
      var bad = 0; var entry = { id: newId(), term: t, session: c.session, className: c.className, source: 'typed', at: new Date().toISOString(), by: (window.erpUser && (window.erpUser().name || window.erpUser().loginId)) || '', students: [] };
      pupils.forEach(function (p, pi) { var tt = {}; subj.forEach(function (s, si) { var el = document.querySelector('.cum-in[data-p="' + pi + '"][data-s="' + si + '"]'); var v = el && el.value !== '' ? Number(el.value) : 0; if (v < 0 || v > 100 || isNaN(v)) { bad++; if (el) el.classList.add('bad'); } else if (v > 0) tt[s] = v; }); entry.students.push({ name: p.name, adm: p.attendanceNo || '', totals: tt }); });
      if (bad) return toast(bad + ' box(es) are not between 0 and 100. Fix the red boxes.');
      var st = store(); st.terms = st.terms.filter(function (e) { return !(e.term === t && norm(e.session) === norm(c.session) && norm(e.className) === norm(c.className) && e.source !== 'archived'); }); st.terms.push(entry);
      save(); try { window.logAudit && window.logAudit('Cumulative: typed ' + LABEL[t] + ' totals for ' + c.className); } catch (e) { /* */ }
      try { ABO.ui.close(); } catch (e) { /* */ } toast(LABEL[t] + ' totals saved.'); rerender();
    };
    ABO.ui.modal({ title: 'Type past term totals — ' + c.className, wide: true, body: draw(t), footer: '<button type="button" class="erp-btn ghost" onclick="ABO.ui.close()">Cancel</button> <button type="button" class="erp-btn primary" onclick="ABO_CUM.saveTyped()">Save totals</button>' });
  }
  function remove(id) {
    var st = store(); var e = st.terms.find(function (x) { return x.id === id; }); if (!e) return;
    window.ABO_CUM.doRemove = function () { st.terms = st.terms.filter(function (x) { return x.id !== id; }); save(); try { ABO.ui.close(); } catch (er) { /* */ } toast('Removed ' + LABEL[e.term] + ' (' + e.source + ').'); rerender(); };
    ABO.ui.modal({ title: 'Remove ' + LABEL[e.term] + '?', body: '<p>The ' + E(e.source) + ' ' + E(LABEL[e.term]) + ' scores will no longer be added up. Old Results are not touched.</p>',
      footer: '<button type="button" class="erp-btn ghost" onclick="ABO.ui.close()">Keep</button> <button type="button" class="erp-btn danger" onclick="ABO_CUM.doRemove()">Remove</button>' });
  }

  /* ── print & export ── */
  var PRINT_CSS = 'body{font-family:Inter,Segoe UI,Arial,sans-serif;color:#0f172a;margin:14px}.cum-head b{font-size:18px;display:block}.cum-head span{font-size:12px;color:#475569}.cum-head h3{font-size:14px;text-transform:uppercase;letter-spacing:.06em;margin:10px 0;text-align:center}' +
    'table{border-collapse:collapse;width:100%;font-size:10.5px}th,td{border:1px solid #94a3b8;padding:3px 4px;text-align:center}td.nm,th.nm{text-align:left}th{background:#eef2f6}th.sub{font-size:9px}td.b{font-weight:700}tfoot th{background:#f1f5f9}' +
    '.cum-facts{display:flex;gap:8px;flex-wrap:wrap;margin:8px 0}.cum-facts div{border:1px solid #cbd5e1;border-radius:8px;padding:6px 8px;font-size:11px}.cum-facts span{display:block;color:#64748b;text-transform:uppercase;font-size:9px}.cum-sum{font-size:12px;border-left:3px solid #0a7d61;padding:6px 10px}.cum-meth{font-size:10px;color:#475569}' +
    'a{color:inherit;text-decoration:none}.up{color:#067647}.down{color:#b42318}@page{size:A4 landscape;margin:10mm}';
  function print() {
    var el = document.getElementById('cumDoc'); if (!el) return; var w = window.open('', '_blank'); if (!w) return toast('Allow pop-ups to print.');
    w.document.write('<html><head><meta charset="utf-8"><title>Cumulative results</title><style>' + PRINT_CSS + '</style></head><body>' + el.innerHTML + '<script>setTimeout(function(){window.print()},300)<\/script></body></html>'); w.document.close();
  }
  function csv() {
    var b = compute(); var subs = b.subjects.map(function (s, i) { return i; }).filter(function (i) { return b.keep[i]; });
    var head = ['Cum. position', 'Name', 'Adm. No']; subs.forEach(function (i) { b.terms.forEach(function (t) { head.push(b.subjects[i] + ' ' + t.label.replace(' (now)', '')); }); head.push(b.subjects[i] + ' cum. average', b.subjects[i] + ' grade'); });
    b.terms.forEach(function (t) { head.push(t.label.replace(' (now)', '') + ' average'); }); head.push('Cumulative average', 'Grade', 'Result', 'Summary');
    var lines = [head].concat(b.rows.map(function (r) { var o = [r.position || '', r.name, r.adm]; subs.forEach(function (i) { var s = r.subj[i]; s.tt.forEach(function (v) { o.push(v === null ? '' : v); }); o.push(s.avg === null ? '' : s.avg, s.grade); }); r.termAvgs.forEach(function (v) { o.push(v === null ? '' : v); }); o.push(r.cumulativeAverage === null ? '' : r.cumulativeAverage, r.grade, r.status, r.summary); return o; }));
    var txt = '\ufeff' + lines.map(function (l) { return l.map(function (v) { var s = String(v); if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; }).join(','); }).join('\r\n');
    var name = ('cumulative_' + b.cur.className + '_' + b.cur.session + '_' + b.cur.term).replace(/[^a-z0-9_]+/gi, '_') + '.csv';
    var blob = new Blob([txt], { type: 'text/csv;charset=utf-8' });
    if (typeof window.downloadBlob === 'function') window.downloadBlob(blob, name); else { var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); a.remove(); }
  }

  /* ── report card: "Results so far this session" on 2nd / 3rd term ── */
  function reportBlock(idx) {
    try {
      var st = store(); if (!st.showOnReport) return;
      var c = cur(); if (c.term === '1ST') return;
      var sheet = document.getElementById('report-' + idx); if (!sheet || sheet.querySelector('.cum-report')) return;
      var b = compute(); if (b.terms.length < 2) return;
      var s = (G('students') || [])[idx]; if (!s) return;
      var r = b.rows.find(function (x) { return x.name === s.name && String(x.adm) === String(s.attendanceNo || ''); }) || b.rows.find(function (x) { return x.name === s.name; }); if (!r) return;
      var div = document.createElement('div'); div.className = 'cum-report';
      div.innerHTML = '<h4>' + (c.term === '3RD' && b.terms.length === 3 ? 'Whole-session result (cumulative of all three terms)' : 'Results so far this session (1st term to ' + LABEL[c.term] + ')') + '</h4>' + pupilBlock(b, r, { report: true }) + '<p class="cum-meth">' + E(b.method) + '</p>';
      var tbl = sheet.querySelector('.report-subjects'); if (tbl && tbl.parentNode) tbl.parentNode.insertBefore(div, tbl.nextSibling); else sheet.appendChild(div);
    } catch (e) { /* the report card itself must never break */ }
  }
  if (typeof window.renderReportCard === 'function' && !window.renderReportCard.__cum) {
    var orig = window.renderReportCard;
    var wrapped = function (idx) { var out = orig.apply(this, arguments); reportBlock(idx); return out; }; wrapped.__cum = true;
    window.renderReportCard = wrapped;
  }

  /* ── Old Results: remember subject names with each archived term (so later subject changes cannot shift scores) ── */
  if (typeof window.erpArchiveNow === 'function' && !window.erpArchiveNow.__cum) {
    var arc = window.erpArchiveNow;
    var w2 = function () { var d = D(); var before = (d.resultsArchive || []).length; var out = arc.apply(this, arguments); try { var a = (D().resultsArchive || [])[0]; if (a && D().resultsArchive.length > before && !a.subjectNames) { a.subjectNames = liveSubjects(); save(); } } catch (e) { /* */ } return out; };
    w2.__cum = true; window.erpArchiveNow = w2;
  }

  /* ── register the page ── */
  var meta = { label: 'Cumulative Results', icon: '📈', section: 'Assessment', roles: ['owner', 'admin', 'teacher'], order: 43,
    desc: 'Results added up across the terms of the session: each subject’s term totals, total so far, cumulative average and position, and the overall cumulative average and position. 3rd term = whole session.',
    keywords: ['cumulative', 'annual', 'session', 'so far', 'total', 'average', 'position', 'b/f', 'brought forward'] };
  window.ERP_MODULES[ID] = Object.assign({}, window.ERP_MODULES[ID] || {}, meta, { kind: 'special' });
  window.ERPRender[ID] = render;
  try { var R = window.ABO && window.ABO.registry; if (R) { if (R.get(ID)) R.setRenderer(ID, render); else R.register({ id: ID, label: meta.label, icon: meta.icon, section: meta.section, kind: 'special', roles: meta.roles, desc: meta.desc, order: meta.order, keywords: meta.keywords }, render); } } catch (e) { /* legacy router still reaches it */ }

  window.ABO_CUM = {
    compute: compute, render: render, print: print, csv: csv, importFile: importFile, typeIn: typeIn, remove: remove, reportBlock: reportBlock,
    set: function (k, v) { if (k === 'subject' || k === 'pupil') v = Number(v); view[k] = v; rerender(); },
    pupil: function (i) { view.mode = 'pupil'; view.pupil = i; rerender(); },
    setOpt: function (k, v) { var st = store(); st[k] = k === 'showOnReport' ? !!v : (v === 'all' ? 'all' : 'taken'); save(); toast('Saved.'); rerender(); },
  };
}());
