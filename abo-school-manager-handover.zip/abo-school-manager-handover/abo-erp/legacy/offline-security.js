/* ==========================================================================================
   A.B.O. offline-file security (Phase 3, 9 Oct 2026)

   1. Stored-XSS fix (all editions). The audit found attack text in pupil names and report-card fields (school
      address/motto, teacher/head names, teacher comment) running as code on 6 pages. Plain-text fields now have "<"
      and ">" replaced by the look-alike signs ‹ › whenever data is saved or loaded, so text can never turn into HTML.
      Real names and comments never need angle brackets; rich-text content (newsletters) is not touched.
   2. Owner password (login-code-only editions). The owner code was readable in the page source and was enough to
      become the owner. Now the owner also needs a password:
        • created on first owner sign-in (8+ characters, letters and numbers), stored only as a PBKDF2-SHA-256 hash
          (150,000 rounds, random salt) — never the password itself;
        • 5 wrong passwords lock owner sign-in on that device for 5 minutes.
   3. Sealed owner sessions. Editing the saved session to the owner's code no longer works: an owner session must
      carry a random seal created at password sign-in; only its hash is stored.
   HONEST LIMIT: this is a browser-only app. Someone with full control of a device (developer tools) can still change
   local data. Real protection is the server edition (server-side permissions + database Row Level Security).
   ========================================================================================== */
(function () {
  'use strict';
  if (window.__aboSec) return; window.__aboSec = true;
  function G(name) { if (window.aboGlobalGet) return window.aboGlobalGet(name); try { return (0, eval)('typeof ' + name + ' !== "undefined" ? ' + name + ' : undefined'); } catch (e) { return undefined; } }   // CSP-safe accessor first (no eval)

  /* ───────── 1. plain-text fields can never become HTML ───────── */
  var clean = function (v) { return typeof v === 'string' && /[<>]/.test(v) ? v.replace(/</g, '‹').replace(/>/g, '›') : v; };
  var STUDENT_FIELDS = ['name', 'attendanceNo', 'admissionNo', 'gender', 'className', 'teacherComment', 'principalComment', 'headComment', 'remark', 'comment', 'parentName', 'parentPhone', 'parentWhatsapp', 'parentEmail', 'address', 'club', 'house'];
  var SCHOOL_FIELDS = ['name', 'motto', 'address', 'email', 'phone', 'website'];
  var SETTING_FIELDS = ['teacher', 'headTeacher', 'principal', 'className', 'term', 'session', 'customBroadsheetType'];
  var ACCOUNT_FIELDS = ['name', 'loginId', 'id', 'email', 'assignedClass', 'linkedStudentName', 'children', 'schoolName'];
  function cleanObj(o, fields) { var n = 0; if (!o || typeof o !== 'object') return 0; fields.forEach(function (f) { var c = clean(o[f]); if (c !== o[f]) { o[f] = c; n++; } }); return n; }
  function sanitizeAll() {
    var n = 0;
    try { (G('students') || []).forEach(function (s) { n += cleanObj(s, STUDENT_FIELDS); if (s && s.scores && typeof s.scores === 'object') Object.keys(s.scores).forEach(function (k) { var sc = s.scores[k]; if (sc && typeof sc === 'object') n += cleanObj(sc, ['remark', 'comment', 'grade']); }); }); } catch (e) { /* ignore */ }
    try { n += cleanObj(G('schoolData'), SCHOOL_FIELDS); } catch (e) { /* ignore */ }
    try { n += cleanObj(G('globalSettings'), SETTING_FIELDS); } catch (e) { /* ignore */ }
    try { var ua = G('userAccounts') || {}; Object.keys(ua).forEach(function (g) { if (Array.isArray(ua[g]) && g !== 'audit') ua[g].forEach(function (a) { n += cleanObj(a, ACCOUNT_FIELDS); }); }); } catch (e) { /* ignore */ }
    try {
      var subj = G('subjects'); if (Array.isArray(subj)) for (var i = 0; i < subj.length; i++) { if (typeof subj[i] === 'string') { var c = clean(subj[i]); if (c !== subj[i]) { subj[i] = c; n++; } } else n += cleanObj(subj[i], ['name', 'subject']); }
    } catch (e) { /* ignore */ }
    try {
      var erp = (G('schoolData') || {}).erp;
      if (erp) {
        (erp.classes || []).forEach(function (c) { n += cleanObj(c, ['name', 'arm', 'teacher', 'base']); });
        // learners kept per class by the multi-class register
        Object.keys(erp.learners || {}).forEach(function (k) { (erp.learners[k] || []).forEach(function (s) { n += cleanObj(s, STUDENT_FIELDS); }); });
      }
    } catch (e) { /* ignore */ }
    return n;
  }
  var baseSave = window.saveSchoolData;
  if (typeof baseSave === 'function') window.saveSchoolData = function () { try { sanitizeAll(); } catch (e) { /* ignore */ } return baseSave.apply(this, arguments); };
  var baseLoad = window.loadSchoolData;
  if (typeof baseLoad === 'function') window.loadSchoolData = function () { var r = baseLoad.apply(this, arguments); try { if (sanitizeAll()) { /* stored attack text neutralised on load */ } } catch (e) { /* ignore */ } return r; };
  // the class form writes straight into these inputs' values; clean them as they are typed
  document.addEventListener('input', function (e) {
    var t = e.target; if (!t || !/^(INPUT|TEXTAREA)$/.test(t.tagName) || t.closest('[contenteditable], .word-shell, #newsletterPortal')) return;
    if (/[<>]/.test(t.value || '')) { var pos = t.selectionStart; t.value = clean(t.value); try { t.setSelectionRange(pos, pos); } catch (x) { /* ignore */ } }
  }, true);

  /* ───────── 1b. backups: never carry the owner password; a restore cannot change the owner's own settings ─────────
     The backup file used to contain the owner password record (pricingData.ownerPass). Anyone holding the file could
     try to guess it at home, and restoring a crafted file could replace the owner password, the bank account shown to
     schools, or the list of approved schools. Now: the record is left out of every backup; on restore the owner
     password is always kept, and only the owner may change the bank/price/approval settings by restoring. */
  function pricingNow() { var p = G('pricingData'); return p && typeof p === 'object' ? p : null; }
  var baseExport = window.exportBackup;
  if (typeof baseExport === 'function') window.exportBackup = function () {
    var p = pricingNow(), op = p && p.ownerPass;
    if (op) delete p.ownerPass;
    try { return baseExport.apply(this, arguments); } finally { if (op) p.ownerPass = op; }
  };
  var restoreGuard = null;
  var baseImport = window.importBackup;
  if (typeof baseImport === 'function') window.importBackup = function () {
    var p = pricingNow();
    restoreGuard = { obj: p, snap: p ? JSON.stringify(p) : null, until: Date.now() + 10 * 60000 };
    return baseImport.apply(this, arguments);
  };
  function applyRestoreGuard() {
    var g = restoreGuard; if (!g) return;
    if (g.until < Date.now()) { restoreGuard = null; return; }
    var p = pricingNow(); if (!p || p === g.obj || !g.snap) return;      // the restore replaces the object; nothing to do before that
    restoreGuard = null;
    var before = JSON.parse(g.snap), u = G('currentUser'), owner = !!(u && u.role === 'owner'), changed = false;
    if (!owner) {
      if (JSON.stringify(p) !== g.snap) { Object.keys(p).forEach(function (k) { delete p[k]; }); Object.keys(before).forEach(function (k) { p[k] = before[k]; }); changed = true; }
    } else if (JSON.stringify(p.ownerPass || null) !== JSON.stringify(before.ownerPass || null)) {
      if (before.ownerPass) p.ownerPass = before.ownerPass; else delete p.ownerPass; changed = true;
    }
    if (changed) { try { window.logAudit && window.logAudit(owner ? 'Backup restore: owner password kept as it was' : 'Backup restore: owner settings (bank, prices, approvals, owner password) kept as they were'); } catch (e) { /* ignore */ } }
  }
  var baseSave2 = window.saveSchoolData;
  if (typeof baseSave2 === 'function') window.saveSchoolData = function () { try { applyRestoreGuard(); } catch (e) { /* ignore */ } return baseSave2.apply(this, arguments); };

  /* ───────── 2 + 3. owner password and sealed owner sessions (login-code-only editions) ───────── */
  // the owner's login code is only kept as a hash (isOwnerCode); older copies still have the plain constant
  var isOwner = function (v) { return typeof window.isOwnerCode === 'function' ? window.isOwnerCode(v) : (!!v && v === G('OWNER_LOGIN_ID')); };
  var codeOnly = !document.getElementById('loginPassword');
  if ((typeof window.isOwnerCode !== 'function' && !G('OWNER_LOGIN_ID')) || !codeOnly) { window.ABO_SEC = { sanitize: sanitizeAll }; return; }
  var enc = new TextEncoder();
  var hex = function (b) { return Array.prototype.map.call(new Uint8Array(b), function (x) { return (x < 16 ? '0' : '') + x.toString(16); }).join(''); };
  var unhex = function (h) { var o = new Uint8Array(h.length / 2); for (var i = 0; i < o.length; i++) o[i] = parseInt(h.substr(i * 2, 2), 16); return o; };
  function rand(n) { var b = new Uint8Array(n); crypto.getRandomValues(b); return hex(b); }
  function sha(t) { return crypto.subtle.digest('SHA-256', enc.encode(t)).then(hex); }
  function pbkdf2(pass, saltHex, iter) {
    return crypto.subtle.importKey('raw', enc.encode(pass), 'PBKDF2', false, ['deriveBits'])
      .then(function (k) { return crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: unhex(saltHex), iterations: iter }, k, 256); }).then(hex);
  }
  function pricing() { var p = G('pricingData'); if (p && typeof p === 'object') return p; return null; }
  // the owner password record: this device's settings, or any school copy downloaded to this device
  function rec() {
    var p = pricing(); if (p && p.ownerPass && p.ownerPass.hash) return p.ownerPass;
    try {
      for (var i = 0; i < window.localStorage.length; i++) {
        var k = window.localStorage.key(i); if (!k || k.indexOf('broadsheetData_') !== 0) continue;
        var d = JSON.parse(window.localStorage.getItem(k) || 'null'); var op = d && d.pricingData && d.pricingData.ownerPass;
        if (op && op.hash) { if (p) p.ownerPass = op; return op; }
      }
    } catch (e) { /* ignore */ }
    return null;
  }
  // a phone that joined the school with a link code is a staff device: it may not create an owner password
  function linkedStaffDevice() { try { var c = JSON.parse(window.localStorage.getItem('aboSupabase') || 'null'); return !!(c && c.linkedAt && !c.connectedAt); } catch (e) { return false; } }
  function fetchFromCloud() {
    var cl = window.ABO_CLOUD; if (!cl || !cl.configured || !cl.configured()) return Promise.resolve(null);
    return cl.call('abo_rec_pull', { p_have: {}, p_keys: ['shared:pricing'] }).then(function (r) {
      var rr = (r.records || [])[0], op = rr && rr.data && rr.data.pricingData && rr.data.pricingData.ownerPass;
      if (op && op.hash) { var pd = pricing(); if (pd) { pd.ownerPass = op; } return op; } return null;
    }, function () { return null; });
  }
  function persist() { try { window.saveData(); } catch (e) { try { window.saveSchoolData(); } catch (x) { /* ignore */ } } }
  var LOCK = 'aboOwnerLock';
  function lockInfo() { try { return JSON.parse(window.localStorage.getItem(LOCK) || '{}'); } catch (e) { return {}; } }
  function setLock(v) { try { window.localStorage.setItem(LOCK, JSON.stringify(v)); } catch (e) { /* ignore */ } }
  function strong(p) { return typeof p === 'string' && p.length >= 8 && /[A-Za-z]/.test(p) && /\d/.test(p); }

  // password box on the sign-in card (shown when the owner signs in)
  function ensureBox() {
    var idEl = document.getElementById('loginId'); if (!idEl || document.getElementById('proOwnerBox')) return;
    var box = document.createElement('div'); box.id = 'proOwnerBox'; box.className = 'form-group pro-owner-box'; box.hidden = true;
    box.innerHTML = '<label for="proOwnerPass" id="proOwnerLbl">Owner password</label>' +
      '<input type="password" id="proOwnerPass" autocomplete="current-password" placeholder="Type your owner password">' +
      '<input type="password" id="proOwnerPass2" autocomplete="new-password" placeholder="Type it again" hidden>' +
      '<small class="pro-owner-hint" id="proOwnerHint"></small>';
    var grp = idEl.closest('.form-group') || idEl.parentNode; grp.parentNode.insertBefore(box, grp.nextSibling);
    [document.getElementById('proOwnerPass'), document.getElementById('proOwnerPass2')].forEach(function (i) { i.addEventListener('keydown', function (e) { if (e.key === 'Enter') window.loginUser(); }); });
  }
  function isOwnerTyped() {
    var idEl = document.getElementById('loginId'), r = document.getElementById('loginRole');
    return !!idEl && ((r && r.value === 'owner') || isOwner(idEl.value.trim()));
  }
  function paintBox() {
    ensureBox();
    var box = document.getElementById('proOwnerBox'); if (!box) return;
    var show = isOwnerTyped(); if (box.hidden === show) box.hidden = !show;
    var first = !rec() && !linkedStaffDevice();
    var lbl = document.getElementById('proOwnerLbl'), p2 = document.getElementById('proOwnerPass2'), p1 = document.getElementById('proOwnerPass'), hint = document.getElementById('proOwnerHint');
    var t = first ? 'Create your owner password' : 'Owner password';
    if (lbl.textContent !== t) lbl.textContent = t;
    if (p2.hidden !== !first) p2.hidden = !first;
    var ph = first ? 'New password (8+ letters and numbers)' : 'Type your owner password'; if (p1.placeholder !== ph) p1.placeholder = ph;
    var h = first ? 'First time: choose a password only you know. You will need it every time you sign in as owner.' : ''; if (hint.textContent !== h) hint.textContent = h;
  }
  function msg(t, ok) { var m = document.getElementById('proLoginMsg'); if (m) { m.textContent = t; m.className = 'pro-login-msg' + (ok ? ' ok' : ''); m.hidden = !t; } else { try { window.showToast(t); } catch (e) { /* ignore */ } } }
  // typing the login code: check it after a short pause (the owner check is a deliberately slow hash)
  var paintT = null;
  ['input', 'change'].forEach(function (ev) { document.addEventListener(ev, function (e) { if (e.target && (e.target.id === 'loginId' || e.target.id === 'loginRole')) { clearTimeout(paintT); if (ev === 'change' || e.target.id === 'loginRole') paintBox(); else paintT = setTimeout(paintBox, 450); } }, true); });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', paintBox); else paintBox();
  setTimeout(paintBox, 800);

  var baseLogin = window.loginUser, passing = false;
  function sealSession() {
    var token = rand(32);
    return sha(token).then(function (h) {
      var r = rec(); if (!r) return;
      r.seals = (r.seals || []).concat([h]).slice(-8); persist();
      try { var s = JSON.parse(window.localStorage.getItem('broadsheetSession') || '{}'); s.ownerSeal = token; window.localStorage.setItem('broadsheetSession', JSON.stringify(s)); } catch (e) { /* ignore */ }
      try { window.sessionStorage.setItem('aboOwnerSeal', token); } catch (e) { /* ignore */ }
      window.__aboOwnerSeal = token;
    });
  }
  window.loginUser = function () {
    if (passing) return baseLogin.apply(this, arguments);
    var idEl = document.getElementById('loginId'); var id = idEl ? idEl.value.trim() : '';
    if (!isOwner(id)) return baseLogin.apply(this, arguments);
    paintBox();
    var l = lockInfo(); if (l.until && l.until > Date.now()) { msg('Too many wrong passwords. Try again in ' + Math.ceil((l.until - Date.now()) / 60000) + ' minute(s).'); return; }
    var p1 = (document.getElementById('proOwnerPass') || {}).value || '', p2 = (document.getElementById('proOwnerPass2') || {}).value || '';
    var self = this, args = arguments, r = rec();
    var go = function () {
      setLock({}); passing = true;
      try { baseLogin.apply(self, args); } finally { passing = false; }
      ['proOwnerPass', 'proOwnerPass2'].forEach(function (x) { var e = document.getElementById(x); if (e) e.value = ''; });
      return sealSession();
    };
    if (!r && linkedStaffDevice()) {
      msg('Checking the owner password with the school’s online copy…', true);
      return fetchFromCloud().then(function (op) {
        if (!op) { msg('This phone was linked as a staff device, so an owner password cannot be created here. Sign in as owner on your own device first, then refresh the school data on this phone.'); return; }
        persist(); paintBox(); return window.loginUser.apply(self, args);
      });
    }
    if (!r) {
      if (!strong(p1)) { msg('Choose an owner password with at least 8 characters, using letters and numbers.'); return; }
      if (p1 !== p2) { msg('The two passwords are not the same. Type them again.'); return; }
      var salt = rand(16), iter = 150000;
      return pbkdf2(p1, salt, iter).then(function (h) {
        var pd = pricing(); if (!pd) { msg('Could not save the password. Reload the page and try again.'); return; }
        pd.ownerPass = { v: 1, salt: salt, iter: iter, hash: h, createdAt: new Date().toISOString(), seals: [] }; persist();
        msg('Owner password created.', true); return go();
      });
    }
    if (!p1) { msg('Type your owner password.'); var e1 = document.getElementById('proOwnerPass'); if (e1) e1.focus(); return; }
    return pbkdf2(p1, r.salt, r.iter || 150000).then(function (h) {
      if (h !== r.hash) {
        var li = lockInfo(), n = (li.n || 0) + 1, out = { n: n }; if (n >= 5) out.until = Date.now() + 5 * 60000; setLock(out);
        try { window.logAudit && window.logAudit('Wrong owner password (' + n + ')'); } catch (e) { /* ignore */ }
        msg(n >= 5 ? 'Too many wrong passwords. Owner sign-in is locked for 5 minutes on this device.' : 'Wrong owner password. ' + (5 - n) + ' tries left.'); return;
      }
      msg(''); return go();
    });
  };

  // a saved owner session must carry a valid seal (editing the session to the owner's code no longer works)
  var baseValidate = window.validateSessionUser;
  if (typeof baseValidate === 'function') {
    var sealOk = {};
    window.validateSessionUser = function (session) {
      var user = baseValidate.apply(this, arguments);
      if (!user || user.role !== 'owner') return user;
      var r = rec(), tok = session && session.ownerSeal;
      if (!r || !tok) return null;
      if (sealOk[tok] === true) return user;
      return null;   // checked asynchronously below before the app starts
    };
    // pre-check the stored seal before init() runs (window.onload), so a valid owner session resumes normally
    var pre = (function () {
      try {
        var s = JSON.parse(window.localStorage.getItem('broadsheetSession') || 'null'); if (!s || !s.ownerSeal) return Promise.resolve();
        var pd = JSON.parse(window.localStorage.getItem('broadsheetData_pricing') || 'null'); var r = pd && pd.pricingData && pd.pricingData.ownerPass;
        if (!r || !r.seals) return Promise.resolve();
        return sha(s.ownerSeal).then(function (h) { if (r.seals.indexOf(h) >= 0) sealOk[s.ownerSeal] = true; });
      } catch (e) { return Promise.resolve(); }
    })();
    var onload0 = window.onload;
    if (typeof onload0 === 'function') { window.onload = null; window.addEventListener('load', function () { pre.then(function () { onload0.call(window); }); }); }
  }

  window.ABO_SEC = {
    sanitize: sanitizeAll,
    ownerPasswordSet: function () { return !!rec(); },
    // used when the owner returns from "sign in as": keep the owner's sealed session
    currentSeal: function () { try { return window.__aboOwnerSeal || window.sessionStorage.getItem('aboOwnerSeal') || (JSON.parse(window.localStorage.getItem('broadsheetSession') || '{}').ownerSeal) || null; } catch (e) { return window.__aboOwnerSeal || null; } }
  };
})();
