/* A.B.O. data guard (added 8 Oct 2026) — protects saved school data in the offline editions.

   Bugs in the original app that this closes:
   1. Every sign-in path ran saveData() BEFORE enterApp() had loaded the school's data, so the blank in-memory
      defaults were written over the saved school (students, results, finance, calendar, lesson notes…).
   2. init() saved blank data to "broadsheetData_default" before anyone signed in — the Owner's own key.
   3. The Owner's storage key followed the typed school name, so every keystroke in the name box created a new key
      ("broadsheetData_B", "_BO", "_BOP"…) and after a reload the Owner was looking at a different key.
   4. Accounts created by the Owner were only in memory after sign-in, so after a reload teachers/parents could not
      sign in or resume a saved session.

   Rules enforced here:
   - A school key that already holds data is never overwritten until this page has actually loaded it.
     Before that, only brand-new sign-in accounts are merged in (nothing is removed).
   - The Owner's key is stable: the selected school, otherwise "broadsheetData_default". Renaming the school no longer
     moves the data. Staff of a single-school install resolve to the same key as the Owner.
   - Saved accounts are made available on the sign-in screen. */
(function () {
  'use strict';
  if (window.__aboDataGuard) return;
  var PREFIX = 'broadsheetData_', PRICING = 'broadsheetData_pricing', HOME = 'broadsheetData_default';
  var G = function (n) { if (window.aboGlobalGet) return window.aboGlobalGet(n); try { return (0, eval)(n); } catch (e) { return undefined; } };
  var store = window.localStorage;
  if (!store) return;
  var loaded = {};            // keys this page has loaded (safe to overwrite)
  var preloaded = {};         // loginIds read from storage for the sign-in screen
  var blocked = 0;
  var rawGet = function (k) { try { return store.getItem(k); } catch (e) { return null; } };
  var parse = function (k) { try { return JSON.parse(rawGet(k) || 'null'); } catch (e) { return null; } };
  var keyFor = function (name) { return PREFIX + String(name || 'default').replace(/[^a-z0-9]/gi, '_'); };
  var schoolKeys = function () {
    var out = [];
    try { for (var i = 0; i < store.length; i++) { var k = store.key(i); if (k && k.indexOf(PREFIX) === 0 && k !== PRICING) out.push(k); } } catch (e) {}
    return out;
  };
  var GROUPS = function (acc) { return Object.keys(acc || {}).filter(function (g) { return Array.isArray(acc[g]); }); };
  var idOf = function (a) { return a && (a.loginId || a.id); };

  /* ---------- 1. never overwrite a school that has not been loaded ---------- */
  function mergeNewAccounts(stored, incoming) {
    var su = stored.userAccounts, iu = incoming && incoming.userAccounts, changed = false;
    if (!iu) return false;
    if (!su || typeof su !== 'object') { stored.userAccounts = su = {}; }
    GROUPS(iu).forEach(function (g) {
      var list = su[g] = Array.isArray(su[g]) ? su[g] : [];
      iu[g].forEach(function (a) {
        var id = idOf(a);
        if (!id || preloaded[id]) return;                       // came from storage: not new
        if (list.some(function (b) { return idOf(b) === id; })) return;
        list.push(a); changed = true;
      });
    });
    return changed;
  }
  function guardedSet(orig, ctx, k, v) {
    k = String(k);
    if (k.indexOf(PREFIX) !== 0 || k === PRICING || loaded[k]) return orig.call(ctx, k, v);
    var prev = rawGet(k);
    if (prev == null) return orig.call(ctx, k, v);            // nothing saved there yet
    blocked++;
    try {
      var p = JSON.parse(prev), n = JSON.parse(v);
      if (p && mergeNewAccounts(p, n)) return orig.call(ctx, k, JSON.stringify(p));
    } catch (e) {}
    if (blocked === 1 && window.console) console.info('[A.B.O. data guard] kept saved data in ' + k + ' (not loaded yet on this page).');
  }
  if (typeof Storage !== 'undefined' && store instanceof Storage) {
    var protoSet = Storage.prototype.setItem;
    Storage.prototype.setItem = function (k, v) {
      if (this === window.localStorage) return guardedSet(protoSet, this, k, v);
      return protoSet.call(this, k, v);
    };
  } else if (typeof store.setItem === 'function') {           // in-memory fallback (preview windows)
    var memSet = store.setItem;
    store.setItem = function (k, v) { return guardedSet(memSet, store, k, v); };
  }

  /* ---------- 2. stable storage key ---------- */
  function exists(k) { return rawGet(k) != null; }
  function ownerKey() {
    var sel = rawGet('ownerSelectedSchool');
    if (sel) return keyFor(sel);
    if (!window.__aboOwnerKeyChecked) {
      window.__aboOwnerKeyChecked = true;
      // one-time recovery for installs hit by bug 3: no data on the default key but exactly one named school with data
      var home = parse(HOME);
      var homeEmpty = !home || (!(home.students || []).length && !(home.schoolData && home.schoolData.erp && home.schoolData.erp.seeded));
      if (homeEmpty) {
        var named = schoolKeys().filter(function (k) {
          if (k === HOME) return false;
          var d = parse(k); return d && ((d.students || []).length || (d.schoolData && d.schoolData.erp && d.schoolData.erp.seeded));
        });
        if (named.length === 1) {
          var d = parse(named[0]), nm = d && d.schoolData && d.schoolData.name;
          if (nm && keyFor(nm) === named[0]) { try { store.setItem('ownerSelectedSchool', nm); } catch (e) {} return named[0]; }
        }
      }
    }
    return HOME;
  }
  function resolveKey() {
    var me = G('currentUser');
    if (!me) return HOME;
    if (me.role === 'owner') return ownerKey();
    var sd = G('schoolData') || {};
    var k = keyFor(me.schoolName || sd.name || 'default');
    if (exists(k)) return k;
    var home = ownerKey(), h = parse(home);
    if (h && (!h.schoolData || !h.schoolData.name || keyFor(h.schoolData.name) === k)) return home;   // single-school install
    return k;
  }
  if (typeof window.getSchoolDataKey === 'function') window.getSchoolDataKey = resolveKey;

  /* ---------- 3. remember what was loaded ---------- */
  var baseLoad = window.loadSchoolData;
  if (typeof baseLoad === 'function') {
    window.loadSchoolData = function () {
      var k = resolveKey();
      try { return baseLoad.apply(this, arguments); }
      finally { loaded = {}; loaded[k] = true; }
    };
  }

  /* ---------- 4. saved accounts on the sign-in screen ---------- */
  function preloadAccounts() {
    var acc = G('userAccounts');
    if (!acc || typeof acc !== 'object') return;
    var keys = schoolKeys(), first = ownerKey();
    keys.sort(function (a, b) { return (a === first ? -1 : 0) - (b === first ? -1 : 0); });
    keys.forEach(function (k) {
      var d = parse(k), su = d && d.userAccounts;
      if (!su) return;
      GROUPS(su).forEach(function (g) {
        var list = acc[g] = Array.isArray(acc[g]) ? acc[g] : [];
        su[g].forEach(function (a) {
          var id = idOf(a); if (!id) return;
          preloaded[id] = true;
          if (!list.some(function (b) { return idOf(b) === id; })) list.push(a);
        });
      });
    });
  }
  var baseInitAccess = window.initializeAccess;
  if (typeof baseInitAccess === 'function') {
    window.initializeAccess = function () {
      try { if (!G('currentUser')) preloadAccounts(); } catch (e) {}
      return baseInitAccess.apply(this, arguments);
    };
  }
  var baseLogout = window.logoutUser;
  if (typeof baseLogout === 'function') {
    window.logoutUser = function () { var r = baseLogout.apply(this, arguments); loaded = {}; try { preloadAccounts(); } catch (e) {} return r; };
  }

  window.__aboDataGuard = { loadedKeys: function () { return Object.keys(loaded); }, blockedWrites: function () { return blocked; }, key: resolveKey,
    // a trusted full copy of the school (cloud download) may replace the saved one
    allow: function (k) { loaded[String(k)] = true; },
    revoke: function (k) { delete loaded[String(k)]; } };
})();
