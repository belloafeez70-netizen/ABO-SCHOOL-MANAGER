# A.B.O. School Manager — honest rating (1 to 100)

**Date:** 12 October 2026, after the online-only work, the premium menu, larger text and owner-only demos.

**What was rated:** the **online app** (`abo-erp`). This is now the only product; the offline edition is retired and archived.

**How:** from the tests run on this computer (real PostgreSQL, real Chrome) and from reading the code.
- Nothing has run on a live server, real phones, real e-mail or real payments yet.
- That is why "readiness" scores low.

## Score: **82 / 100**

| Area | Score | Why |
|---|---|---|
| Features for Nigerian schools | **93** | Students, parents, staff, classes (Creche – SS 3 and custom classes), attendance, staff clock-in with fingerprint/passkey and GPS, lesson notes with approval, CBT with server marking, CA/exam scores with four-eyes approval, broadsheets, cumulative results, report cards, fees with Paystack, old debts, cashbook, petty cash, store, announcements shared to WhatsApp, messages, calendar, ID cards, print centre, reminders, analytics. Every page of the old offline edition is online. |
| Security | **88** | **Login:** passwords (Argon2id), two-step sign-in for owners and bursars, passkeys, e-mail verification and reset, sessions with CSRF protection. **Access:** 30+ roles checked on the server, Row Level Security on all 91 school tables (isolation check 12/12). **Records:** hash-chained audit log, encrypted secrets. **Headers:** strict CSP and noindex. **Demos:** demo links stored only as hashes. *Minus:* no outside penetration test yet, and never run live. |
| Data safety | **85** | One PostgreSQL database, money never edited (only reversed), approved results locked, Backup & Data download. *Minus:* Point-in-Time Recovery needs a paid Supabase plan; backups not yet practised on the live system. |
| Ease of use and look | **85** | Premium, calm design. One three-line button shows or hides the whole menu. About 20 menu entries, with related pages as tabs. Text about 12% larger. Simple-words option, light and dark mode. *Minus:* not yet tried by real teachers and parents. Some long pages and wide tables still need scrolling on small phones. |
| Phones and tablets | **84** | Every page and tab tested at phone size (1029 checks, no sideways scrolling); installs as an app; pages already opened stay readable offline. *Minus:* not tested on real Android or iPhone handsets. Saving needs internet. |
| Speed at scale | **80** | Load-tested locally with 1,000 schools / 200,000 users. *Minus:* not measured from Nigeria to a live server; Render's free plan sleeps (use a paid instance). |
| Tests and code quality | **89** | **Server:** 191 automated tests. **Browser:** 17 suites, about 2,000 checks, each on a fresh database, all passing with 0 server errors. Isolation check, migrations with undo scripts. |
| Ready to sell today | **55** | Everything is built, but it is **not live**. It still needs: your GitHub, Supabase, Render and Netlify set-up; an e-mail sender (SMTP); Paystack keys; a short pilot with one or two real schools. |
| Documentation and handover | **86** | Start-here guide, step-by-step upload guides, feature map, menu guide, test reports, honest limits. |

**Weighting:** features, security and readiness count most, so the overall comes to **82/100**.

**Realistic next step:** after a successful live deployment and a pilot with 1–2 schools, about **90/100**.

## Limitations (please read)

### 1. Going live
1. **Not deployed yet.** abosch.netlify.app still shows the old offline edition until the online app is connected (GitHub → Supabase → Render → Netlify).
2. **Netlify alone cannot run it.** It needs the Render server and the Supabase database. Render's free plan sleeps after inactivity, so schools need a paid instance (from about USD 7/month).
3. **E-mail needs an SMTP provider** (for example Brevo, Mailgun or Zoho). Without it there are no password-reset, verification or reminder e-mails; in-app notifications still work.
4. **Paystack keys are needed** for online fee and subscription payments. Until then, schools record cash and bank transfers.
5. **Never tested live:** live servers, real e-mail delivery, real Paystack payments, Nigerian mobile networks and real handsets.

### 2. How the app works
6. **Saving needs internet.** Pages already opened can still be read offline. The old fully-offline typing is retired. Schools with poor internet should plan for data bundles or school Wi-Fi.
7. **Schools move their old offline data in by themselves:** Backup & Data › From the Old App, on each device that held data, or with the old backup file.
8. **Demos:**
   - Only you (the platform owner) can open them, with a demo link.
   - Each demo is limited to 5 minutes, two sample schools, and no owner controls.
9. **AI comment suggestions** need an AI provider key on the server. Without it, the built-in rule-based comment helper works.
10. **Announcements are plain text** (safe against harmful code). Rich Word/PDF letters are attached as documents.

### 3. Not done yet
11. **No outside security audit** or penetration test yet. Recommended before many schools join.
12. **Supabase backups:** Point-in-Time Recovery is a paid feature. Practise a restore once after going live.
13. **Real users:** the larger text and new menu were checked in screenshots and automated tests, not with real staff. Expect small wording and layout requests after the pilot.
