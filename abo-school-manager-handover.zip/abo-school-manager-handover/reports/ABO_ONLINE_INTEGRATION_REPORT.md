# A.B.O. School Manager: all offline features now online

**Date:** 12 October 2026

**Request:** "Integrate all files to be online, all offline features should be converted to online."

## 1. What was checked first

I opened all **90 menu pages of the offline edition**, signed in as owner, and compared each one with the online edition (`abo-erp`).
- About 85 were already online, many with stronger rules (server-checked approvals, real passwords, audit trail).
- The rest were missing or only partly there. They are listed in section 2.

The full page-by-page table is in `abo-erp/docs/FEATURE_MAP.md`.

## 2. What was added to the online edition

All of this is in database migration **027**, one undo script, 4 new server files and 1 new screen file:

| Offline feature | Online now | Rules the server enforces |
|---|---|---|
| **Old Debts** | Fees & Payments › Old Debts | Paste from Excel or upload a CSV, then **Check** (finds each learner by admission number or full name), then **Create bills**. Each learner gets one "brought forward" bill. The same old debt can never be billed twice. Parents see it in their portal and can pay it, including online. |
| **Petty Cash** | Cashbook › Petty Cash | Any staff member can ask. **A different person** approves (nobody approves their own request; also a database rule). The cashier hands it out, recorded as spent from petty cash; the box can never go below zero. On settling, only the amount really spent stays in the books, and the change goes back into the box. |
| **Questions from Teachers** | CBT › Questions from Teachers | Optional switch. When on, teachers' new or changed bank questions **wait** until the exam officer approves them or sends them back with a note. A waiting question can never be used in a test. Restoring from the archive cannot skip the check. The teacher is notified. |
| **Automatic Reminders** | Administration › Reminders & Alerts | Overdue fees, learners below the attendance floor, store items running low, approvals waiting, and the subscription ending. **Remind all these parents** sends an in-app and e-mail reminder, and never twice in a day for the same bill. The rules can be changed. |
| **Devices** | Staff & Teachers › Devices | List of fingerprint readers, scanners and tablets. Serial numbers are unique. Status can be working, in repair or retired. |
| **Print Centre** | Broadsheets & Reports › Print Centre | All printable documents in one place, plus 4 new ones: blank attendance register, attendance report, store stock sheet, and cash ledger with a running balance. |
| **Design Score Sheet** | Class Broadsheet › Sheet Layout | Choose whether the score sheet shows the CA/Exam split, position, total, average, grade and pass/fail, plus your own title and footer. The printed score sheet follows it. |
| **Moving offline data in** | Backup & Data › From the Old App | When the online app runs on the same web address as the offline edition, the page **finds the offline data on that device**. One click previews it, and **Commit** brings it in. No backup file is needed, and nothing changes before Commit. |

**Labels:** parents' fee pages and invoices now say "Fees owed from before" for old debts.

**Permissions** (new schools get them automatically; existing schools get them from migration 027):

| Who | What they can do |
|---|---|
| All staff | Ask for petty cash |
| Owner, principal, administrator, bursar | Approve petty cash; send reminders |
| Accountant, vice principal | See alerts |
| ICT officer, administrator | Manage devices |

**Kept different on purpose:**
- The online edition does not let people **save** with no internet. Pages already opened stay readable offline.
  - For typing with no internet, the offline edition stays at **/offline/** on the same address.
  - Schools then move the data in with one click, as described above.
- Cloud Sync is not needed online: the server is the online copy.

## 3. Test results (all run on this computer)

| Test | Result |
|---|---|
| New server tests (old debts, petty cash, questions, reminders, devices, print data, layout; school B never sees school A) | **5 / 5** |
| All server tests (`npm test`) | **190 / 190** (185 earlier + 5 new) |
| New browser test (`parity.qa.js`): every new page used as owner, teacher and exam officer, the menu per role, phone screens | **35 / 35** |
| School separation check: every table with a school id is locked to its school | **12 / 12, 91 tables** (3 new) |
| All 17 server browser suites, each on a fresh database: menu 240, menu clicks 216, UI 71, CBT 34, portal 28, school life 19, store 16, materials 18, migration 8, owner tools 14, passkeys 9, cumulative 25, install/layout 23, phone taps 802, nav/share 60, master 23, new parity 35 | **all passed, 0 server errors** (nav/share re-run after updating its tab count) |

### Found and fixed while testing
- **One older browser test** expected exactly 4 tabs on the Class Broadsheet. There are 5 now, with Sheet Layout added on purpose, so the test was updated and re-run: 60/60.
- **An older migration test (025)** rolled back exactly two steps, which only worked while 026 was the newest. It now rolls back until 025 is undone, and that also runs the new 027 undo script.
- **Cards without a title** quietly dropped their buttons, so the **Change layout** button and the question-review buttons were missing. Both fixed and re-tested.
- **Reminders wording:** a 0-day rule read "more than 0 days after the due date". It now says "past the due date".

## 4. What you need to know (honest)

1. **The online edition is built and tested, but not live.** It needs your own accounts:
   - **GitHub:** keeps the code.
   - **Supabase:** the database.
   - **Render:** the server.
   - **Netlify:** the website.
   The steps are in `UPLOAD_GUIDE.md`.

   Netlify alone cannot run it: the online version needs the server (Render) and the database (Supabase). Until then, abosch.netlify.app can only run the offline edition.
2. **When it goes live:** abosch.netlify.app shows the online app (online only, see Part 2). Schools move their offline data in with one click.
3. **Not tested here:** a live server, real e-mail sending, real Paystack payments and real phones. The tests use the same code and database rules.

## 5. Files

| What | Where |
|---|---|
| Everything | `abo-complete-project.zip` |
| Upload packages | `upload-1-github.zip` (now includes the offline site, so Netlify serves it at /offline/), `upload-2-supabase.zip`, `upload-3-netlify.zip`, `upload-4-render.zip` |
| Database change | `abo-erp/server/src/db/migrations/027_offline_parity.sql` (+ `down/`) |
| New server code | `abo-erp/server/src/routes/{arrears,petty_cash,alerts,school_tools}.js` |
| New screens | `abo-erp/web/assets/js/pages/tools.js` |
| Tests | `abo-erp/server/test/offline_parity.test.js`, `abo-erp/server/test/e2e/parity.qa.js` |
| Backup taken before the work | `backups/2026-10-12-before-online-integration/` |

---

# Part 2 (same day): premium menu, repeated entries merged, everything online

**Request:** "three lines to open the menu on desktop, merge repeated menus, no Collapse, no small menu, professional; all offline parts online."

## What changed

| Before | Now |
|---|---|
| On a computer, ☰ squeezed the menu into an icon strip, and a collapse arrow sat at the top of the menu | **☰ shows or hides the whole menu.** The page then uses the full width, and the choice is remembered. There is no icon-only mode and no collapse arrow. On a phone the menu slides in, with an **X** to close it. |
| Owner menu: about 60 entries in 17 open/close groups, with repeats (Teachers *and* Staff Records; Student Report *and* Class Reports; Audit Logs *and* Security Events; Users *and* Roles; "Add Student", "Write Lesson Note" and "Create Examination" as menu entries…) | **About 20 entries.** Pages that belong together are **one entry, with tabs at the top of the page** (e.g. Students: List · Parents · Promotion · Import · ID Cards). The action entries became buttons on their pages. Full list: `abo-erp/docs/MENU.md`. |
| Each role could see menu entries leading to pages it could not open | Each entry opens the **first tab that person may see**, and is named after it when it is the only one (a teacher's Cashbook entry reads "Petty Cash"). |
| Plain underline tabs, "Show full terms" in the menu footer | **New look:** calm segmented tabs, a refined dark menu with the school colour on the current page, and a sticky see-through top bar. "Show full terms" moved to the account menu. Checked in light and dark mode, on a computer and a phone. |
| Offline edition published, with the online app planned at `/` and the offline edition at `/offline/` | **Online only.** The upload packages no longer contain the offline website. Schools bring their old data in with **Backup & Data › From the Old App**, which finds it on the same device. The old offline files are kept only in `archive/` inside the project zip. |

**Found by the wider tests:** the **Subscription** page printed the word "null" when no bank details were set. It was never visited by the old menu test, because it had no menu entry. Fixed.

## Test results (this round, each suite on a fresh database)

| Suite | Result |
|---|---|
| Menu: every menu entry **and every tab**, all roles | **308 / 308** (was 240; tabs are visited now) |
| Menu clicks: real mouse/taps, ☰ show/hide at 1366 and 1024 px, remembered after reload, tabs keep the entry highlighted, phone close button | **146 / 146** |
| Phone taps: every page **and tab** on a phone | **1029 / 1029** (was 802) |
| Navigation and tabs (merged entries gone from the menu, tab counts per group) | **98 / 98** |
| New features (old debts, petty cash, questions, alerts, devices, print, layout) | **38 / 38** |
| Lesson notes portal | **28 / 28** |
| Materials and monitor | **18 / 18** |
| Owner tools / sign-in-as | **14 / 14** |
| UI, CBT, school life, store, migration, passkeys, cumulative, install/layout, master (first full run of this round) | **all passed** |
| Server errors in the logs | **0** |

Five older tests were updated because they checked the old menu on purpose (the collapse arrow, menu names, tab counts, where "Show full terms" lives). The server tests (190/190) were not affected: no server code changed this round.

---

# Part 3: demos only through the platform owner

**Request:** "make the demo only be in the owner interface". You confirmed: **only the A.B.O. platform owner can start a demo.**

| Before | Now |
|---|---|
| The public sign-in page had **"Try the demo — 5 minutes, no sign-up"** for anyone | **No demo button.** `#/demo` without a link only says **"Demo by invitation"**, with your phone number. |
| Anyone could start demos | **Platform console › Demo Links.** You make a link, choosing who it is for, one demo school or both, how long it works (1 hour – 7 days) and how many demos it may open (1–50). You then **Copy** it or **Send by WhatsApp**, and can **cancel** it at any time. |
| — | **The server refuses** to start a demo without a valid link (wrong, used up, expired, cancelled, or for the other demo school). Using a link is atomic: two people pressing at once on the last use, only one starts. A demo that fails to start gives its use back. |
| — | **Storage:** only a SHA-256 hash of each link is stored, and the full link is shown once, when it is made. Demo links are visible only to the platform; school owners and teachers get "not allowed". |

**Files:**

| What | Where |
|---|---|
| Database change | migration **028_demo_passes.sql** (+ undo script) |
| New server file | `server/src/routes/demo_links.js` |
| Changed server file | `server/src/routes/public.js` |
| New screen | `web/assets/js/pages/demolinks.js` |
| Changed screen | `web/assets/js/pages/auth.js` (sign-in and demo page) |

**Tests:**

| Test | Result |
|---|---|
| New server test for demo links (every refusal above, the race, the hash-only storage, platform-only access) | **pass** |
| All demo tests | **pass** (they now use links) |
| Security tests, including "no endpoint accidentally public" | **19 / 19** |
| Master browser test: the platform owner makes a link in the console; the sign-in page has no demo button; the demo address without a link shows "by invitation"; the link opens the demo with its 5-minute countdown; phone check | **27 / 27** |
| Full server and browser runs after this change | **server 191 / 191**; all 17 browser suites pass, each on a fresh database (menu 309, menu clicks 146, UI 71, CBT 34, portal 28, school life 19, store 16, materials 18, migration 8, owner tools 14, passkeys 9, cumulative 25, install/layout 23, phone taps 1029, nav/share 98, master 27, new features 38), **0 server errors** |

---

# Part 4: larger text, demo on the owner dashboard, fixes, rating

| Change | Details |
|---|---|
| **Larger text everywhere** ("too tiny") | The base text goes from 14px to 15.5px, about 12% larger. The type scale, menu, buttons, tabs, tables, labels and badges all grow together, and menu rows and buttons are a little taller. **Printed documents** (report cards, broadsheets, receipts, CBT answer sheets, lesson notes) keep their exact sizes, so they still fit one page. ID cards are unchanged. |
| **Demo on the owner dashboard** | Your platform home page (the Schools list) now opens with a **Give a demo** panel, with "Make a demo link" (the form opens straight away) and "My demo links". Demos still cannot be opened by anyone without your link. |
| **Fix: "1ST term"** | Term names looked like "1ST term" on screen. They are stored that way by a database rule, but are now **shown as "1st / 2nd / 3rd term"** everywhere (about 25 places). The stored data is unchanged. |
| **Rating** | **82 / 100**, with the limitations: see `ABO_APP_RATING.md`. |

**Tests:**

| Test | Result |
|---|---|
| Server tests | **191 / 191** |
| Browser suites (all 17, each on a fresh database, with the larger text) | **all pass, 0 server errors**: menu 309, menu clicks 146, UI 71, CBT 34, portal 28, school life 19, store 16, materials 18, migration 8, owner tools 14, passkeys 9, cumulative 25, install/layout 23, phone taps 1029 (no page wider than the screen), nav/share 98, master 27, new features 38 |

Three browser tests were adjusted because they chose terms by the old capital text "2ND / 3RD".
