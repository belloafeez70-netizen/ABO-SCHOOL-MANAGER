# A.B.O. School Manager — Critical Improvement Report

**Date:** 12 October 2026
**Live site:** https://abosch.netlify.app. It runs the **offline edition**, and it still has the **old** build until you upload the new folder (see "How to update" below).

Everything marked **tested** was run on this computer, in a real Chrome browser and a real PostgreSQL database. Things that could not be tested here are listed clearly as **not tested**.

---

## 1. Backups taken first

`backups/2026-10-12-before-critical/` holds:
- the live page and its headers as they were;
- the old `abo-school-site.zip`;
- the 3 offline HTML files;
- the full source;
- SHA-256 checksums.

Older backups are kept too.

*Note:* to fit the workspace save limit, the source archives in the backups were repacked **without the documentation screenshots** (pictures only). All source code is still in them. The screenshots are kept separately in `abo-erp/docs/screenshots`, compressed.

---

## 2. What changed, phase by phase

### Security and owner login (offline edition = abosch.netlify.app)

| Before (live today) | Now |
|---|---|
| The owner code was written in plain text in the page source. Anyone could press Ctrl+U and see it. | Only a salted, 2,000-round SHA-256 **hash** is in the page. The build stops with an error if the code ever appears in a file. Checked in all 3 editions and the website copy. |
| No way to change the owner code | New: `OWNER_CODE='…' node abo-erp/scripts/patch-offline-core.js <files>`. It needs at least 12 characters, with letters and numbers. **Tested:** the new code works and the old one is refused. |
| Cloud Sync: anyone could create unlimited schools, and there were no size limits | At most 5 new schools per internet address per day. An optional **invitation code** for new schools. Size limits of 30 MB per record and 20 MB per file. **New: "Change school secret"** cuts off old link codes and devices at once. |

**Important:** your current owner code was publicly visible on the old site. Anyone who saw it can still use it, because it is the same code. **Please choose a new owner code** and I will build it in (one command; see section 6).

### Email + password login, password reset, email verification, sessions, roles

- **Online edition:** all of these are built and tested. That includes server sessions, two-step sign-in for owners, 30+ roles with server-checked permissions, password reset and email verification (npm test 185/185).
- **Offline edition:** **not** added. It has no server, so a "password reset by email" cannot be made safe inside a single HTML file. The honest fix is to move abosch.netlify.app to the online edition, with the offline edition kept at `/offline/` (section 5, step C). That layout is built and tested locally.

### Classes, demos, payments (from the previous round, re-tested)

These live in the online edition. Their tests passed again this round:
- **Classes:** Creche, Nursery 1–2, KG, Primary 1–6, JSS 1–3, SS 1–3, plus custom classes, with rename, reorder and switch off.
- **Demo schools:** two separate DEMO schools, with a 5-minute timer that the server enforces, and a reset afterwards.
- **Payments:** owner-only Paystack settings. The secret is never sent to the browser, and payments are verified on the server.

### Supabase Cloud Sync and Row Level Security

- **Every table:** RLS is on, there are no direct permissions for the public key, and everything goes through checked functions.
- **Secrets:** bcrypt-hashed school secrets.
- **Wrong secrets:** blocked after 20 wrong tries per internet address.
- **New `abo_rekey` function** to change a school's secret.
- **Old phones keep working:** phones still running the old offline file can still connect (tested).
- **Online edition:** 88 tables with RLS, and the 12/12 school-isolation check.

### PWA and HTTP security (website copy)

- **`Content-Security-Policy`:**
  - Without `unsafe-eval`. The old code used `eval` in many places; it was replaced with a safe lookup.
  - `'unsafe-inline'` is still needed. The old file has about 1,000 inline `onclick` handlers, and removing them safely is a large rewrite.
  - `object-src 'none'`, `base-uri 'self'` and `frame-ancestors 'self'`.
  - **Tested:** 90 pages walked with **zero** CSP violations.
- **`X-Robots-Tag: noindex, nofollow, noarchive`**, plus `robots.txt` and a robots meta tag. Added to the online edition too.
- **Kept:** HSTS, `nosniff`, Referrer-Policy, frame protection, and GPS + fingerprint (WebAuthn) permission.
- **Service worker:**
  - The cache name is a hash of the content, so every deploy replaces old copies.
  - Phones see a **"A new version of the app is ready — Update now"** bar.
- **Branded pages:** "You are offline" and "Page not found".

### Performance (measured: slow phone with 4× slower CPU, 1.6 Mbps, 150 ms delay)

| | Live today | New | |
|---|---|---|---|
| First paint | 4,340 ms | **566 ms** | 7.7× faster |
| Ready to sign in | 4,814 ms | **2,339 ms** | 2× faster |
| Data downloaded | 909 kB | **393 kB** | −57% |
| Requests | 9 | 6 | |

How:
- The 8 big libraries (PDF, Word, picture export, Firebase and others, about 2.2 MB) now load **only when needed**. They come from the site itself, with integrity checks, instead of 8 blocking CDN scripts.
- The page is minified.
- The font no longer blocks the page.

Exports were tested: PNG, PDF and Word all work under the new CSP.

**Duplicate submissions:** a double-tap guard was added on action buttons (tested).

### Repetitions

Newsletters were merged into Announcements, with "Share with parents" by WhatsApp and email. Page groups with tabs replace the long duplicate menus in the online edition (previous round, re-tested).

---

## 3. Actual test results (this round)

| Test | Result |
|---|---|
| Server automated tests (`npm test`, with Redis) | **185 / 185** |
| Website copy under its real headers (`site_secure`) | **22 / 22** |
| Website copy regression: functions 8, features 37, data kept 15, roles 57, security 19, words 20, back button 24, cumulative 24, master 24, phone taps 546, device/install 18 | **all passed** |
| Supabase RLS / Cloud Sync attack test (`supa_rls_probe`) | **35 / 35** |
| Change school secret, 2 devices in a real browser (`rekey`) | **9 / 9** |
| Speed test (above) | measured |
| Combined package: online at `/`, offline at `/offline/`, real Netlify header rules (`combined`) | **19 / 19** |
| Server browser suites (fresh database each): menu 225, menu clicks 207, UI 71, CBT 34, portal 28, school life 19, store 16, materials 18, migration 8, owner tools 14, fingerprint/passkeys 9, cumulative 25, install/layout 23, phone taps 738, nav/share 60, master 23 | **all passed, 0 server errors** |
| Full offline regression (`runall`, all 3 editions): functions 8, menu 12, data kept 15, features 37, back button 24, preview 13 + 10, words 20, roles 57, sign-in-as 25, security 19, XSS audit 1, Cloud Sync 45 + 36, web address 20, linked devices 8, sync register 11, older editions 14 + 15 + 16 each, cumulative 24, phone taps 546, device 18, master 24, merge 13, site security 22, Supabase probe 35, change secret 9 | **all passed** (Cloud Sync tests re-run after the new-school limit fix) |
| Cloud Sync test 1 (`cloud.js`: phone links with a code, fingerprint clock-in, offline, conflicts) | **45 / 45** (fixed — see below) |

### Found and fixed during testing

- **Lost server files.** The workspace had lost several server files from the last round: `routes/billing.js`, plus older copies of 5 route files. The cause: the workspace was too big to save fully (200 MB against a limit of about 128 MB). They were restored from the verified package, and the workspace was shrunk to about 100 MB, mostly by compressing screenshots. Then all tests were re-run.
- **Header clash on real Netlify.** Netlify **joins** repeated headers. The combined package would have sent two Permissions-Policy headers, so it now sends one. The local Netlify stand-in now joins headers the same way, so this kind of mistake gets caught.
- **Minifier bug** (previous session): it damaged 3 scripts. Fixed and re-tested.
- **Double-tap guard was too wide.** A button with no `type` counts as "submit" in browsers, so the menu button could not be pressed twice quickly. Now only real save/publish/submit buttons are guarded. Menu test 12/12.
- **Offline worker under `/offline/`.** With no internet it showed "You are offline" instead of the app, because it assumed it lived at `/`. Now it works out its own folder. Tested at both `/` and `/offline/`.
- **Preview frame.** Inside a sandboxed preview (origin "null") the export libraries now come from the CDN, so there are no blocked-load errors. Preview tests 13/13 and 10/10.
- **Phone linking was blocked by the double-tap guard.** The guard treated every "primary" styled button as a save button. So pressing **Connect** again right after a wrong code was ignored. Now only buttons that really save something are guarded, and typing in between always clears the guard. Phone linking test 45/45; a double tap on Publish is still blocked (22/22).
- **New-school limit when the internet address is missing.** If a request ever reached Supabase without the visitor's address, every school would have shared one "5 per day" limit. Those requests now share a larger budget of 100 per day. On Supabase the address is normally sent (`cf-connecting-ip` / `x-forwarded-for`).
- **Rebuild was not repeatable.** Rebuilding the HTML files added blank lines each time. Now a rebuild gives exactly the same file.

---

## 4. Remaining risks (honest)


1. **The offline edition can never be as secure as the online one.** Everything runs inside the browser:
   - a determined person with the device can get round the menus;
   - there is one shared Cloud Sync secret per school, not one login per person on the server;
   - payments are not server-verified.
   Use it as a local tool. For selling to many schools, go live with the online edition.
2. **Owner code:** hashed now, but the old code was public. **Change it** (section 6).
3. **CSP still allows inline scripts** (`'unsafe-inline'`) in the offline edition, because of about 1,000 inline handlers. `eval` is blocked. The online edition has a strict CSP with no inline scripts.
4. **Not tested on a live server:**
   - real Netlify, Supabase, Render, Paystack and email;
   - real Android/iPhone handsets;
   - the network from Nigeria.
   The local tests use the same header files, the same SQL and the same code.
5. **The online edition is not live yet.** It needs your accounts (GitHub, Supabase, Render, Netlify, email, Paystack). See `UPLOAD_GUIDE.md`.

**Scores:**

| Edition | Before | Now | Why |
|---|---|---|---|
| Offline website copy | 6 / 10 | **7 / 10** | Faster, no visible owner code, CSP + noindex, safer Cloud Sync |
| Online edition | 8.4 / 10 | **8.5 / 10** | Unchanged in features. Robots header, branded 404 and the tested combined deploy were added. |

---

## 5. Exactly how to update https://abosch.netlify.app

**A. Now (2 minutes, nothing else changes):**
1. Go to app.netlify.com › site **abosch** › **Deploys**.
2. Drag the folder **`abo-school-site`** onto the page. It is also inside `abo-school-site.zip`, and in `upload-3-netlify.zip` (folder `offline-website`).
3. Check:
   - the site opens and you can sign in;
   - Ctrl+U shows no owner code;
   - securityheaders.com shows a CSP and X-Robots-Tag.
4. Undo if needed: Deploys › previous deploy › **Publish deploy**.

**B. Supabase (if you use Cloud Sync):**
1. SQL Editor › paste all of `abo_supabase_setup.sql` › **Run**. It is safe to re-run, and data is kept.
2. Optional: switch on invitation codes for new schools (see `upload-docs/2-supabase.md`).

**C. Later, when the online server is live (recommended):**
1. Link the same Netlify site to GitHub (`upload-docs/3-netlify.md`, section A).
2. Result: the online app is at `/`, and the offline edition stays at `/offline/` with the same data.

---

## 6. Changing the owner code (recommended)

Tell me the new code (at least 12 characters, with letters and numbers). I will rebuild and re-test.

Or run it yourself on a computer with Node.js, from the folder that holds the files:
```
OWNER_CODE='YourNewCode2026' node abo-erp/scripts/patch-offline-core.js school_broadsheet_manager_bopc_erp.html school_broadsheet_manager_premium_secure.html school_broadsheet_manager_connected.html
node abo-erp/scripts/build-offline-site.js school_broadsheet_manager_bopc_erp.html abo-school-site
```
Then upload `abo-school-site` again (5A).
