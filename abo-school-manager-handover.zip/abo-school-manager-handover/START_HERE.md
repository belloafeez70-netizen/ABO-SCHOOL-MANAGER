# A.B.O. School Manager — START HERE (handover for a new AI chat)

**Owner:** A.B.O. Edu Consultant (Nigeria) · 0805 144 6681
**Prepared:** 12 October 2026
**Live site today:** https://abosch.netlify.app. It still shows the **old offline edition**, until the online app below is deployed.

## 1. Paste this into the new chat (together with this zip)

> I am attaching `abo-school-manager-handover.zip`. Please read `START_HERE.md` first.
> It is my school management app "A.B.O. School Manager" (Fastify + PostgreSQL API, static web app with a Netlify edge proxy).
> Help me, step by step and in simple words, to:
> 1. put the folder `abo-erp/` into a **private GitHub repository**;
> 2. set up the database on **Supabase** with `scripts/supabase-db-setup.sh` and create the private storage bucket;
> 3. deploy the API on **Render** with `render.supabase.yaml`;
> 4. connect my existing **Netlify** site *abosch.netlify.app* to the GitHub repository;
> 5. create my platform owner account and test the live site.
>
> Never put secret keys or passwords in the code or in GitHub. Follow `deployment-guides/` for the exact steps.

## 2. What is in this zip

| Folder / file | What it is |
|---|---|
| `abo-erp/` | **The whole project — this folder IS the GitHub repository.** It contains: the API server (`server/`), web app (`web/`), database migrations 001–028 (`server/src/db/migrations/`), Netlify edge proxy (`netlify/`), `netlify.toml`, `render.supabase.yaml`, `Dockerfile`, scripts and documents (`docs/`). There is no `node_modules`, no `.env` and no secrets. |
| `deployment-guides/` | Step-by-step guides: `UPLOAD_GUIDE.md` (order and overview), then `1-github.md`, `2-supabase.md`, `4-render.md`, `3-netlify.md`. |
| `reports/` | What was built and tested, with the actual results (`ABO_ONLINE_INTEGRATION_REPORT.md` is the latest). |
| `archive-offline-edition/` | The **retired** offline edition (single HTML files and its old website copy). **Do not publish it, and do not put it in GitHub.** It is kept only for reference and so schools can move their old data in (see section 6). |

## 3. How the online app fits together

```
Browser (staff, parents, pupils, platform owner)
   │  https://abosch.netlify.app
   ▼
NETLIFY  — static web app (dist/web, strict security headers) + edge function netlify/edge-functions/api-proxy.js
   │  /api/*  →  forwards to the API with a shared secret (PROXY_SHARED_SECRET)
   ▼
RENDER   — Node 20 Fastify API (server/src/server.js), background jobs in-process
   │  DATABASE_URL (role abo_app, Row Level Security, cannot bypass it)   ·   S3 storage for files
   ▼
SUPABASE — PostgreSQL database "abo_erp" (separate from Supabase's public API) + private storage bucket "abo-files"
```

## 4. Connection steps (summary; details in `deployment-guides/`)

### 4.1 GitHub
- Create a **private** repository, e.g. `abo-school-manager`.
- Upload the **contents** of `abo-erp/` so that `package.json` is at the top of the repository.
- `.gitignore` already keeps out `node_modules/`, `.env*`, `var/` and `dist/`.

### 4.2 Supabase
1. Create a project, region close to Nigeria, e.g. EU West.
2. Copy the **session pooler** connection string (port 5432, user `postgres.<project-ref>`).
3. On a computer with Node.js 20, inside `abo-erp/`, run `npm ci`, then:
   ```
   SUPABASE_ADMIN_URL='postgres://postgres.<ref>:<db-password>@aws-0-<region>.pooler.supabase.com:5432/postgres' bash scripts/supabase-db-setup.sh
   ```
   This creates the roles `abo_owner` / `abo_app` and the database `abo_erp`, runs all 28 migrations, and runs the school-isolation check (12/12). It then **prints the two connection strings** for Render: `MIGRATION_DATABASE_URL` (owner) and `DATABASE_URL` (app).
4. **Storage:** create a **private** bucket `abo-files`, then create S3 access keys (Project Settings › Storage).
5. **Check the storage address:** `render.supabase.yaml` sets `S3_ENDPOINT=https://fehpqiqqxgqugioowepu.storage.supabase.co/storage/v1/s3`. If the new Supabase project has a different reference, change it to `https://<your-ref>.storage.supabase.co/storage/v1/s3`.

### 4.3 Render (the API)
- **New › Blueprint**, choose the GitHub repo, use `render.supabase.yaml`.
- **Secret settings** (Environment):

| Setting | Value |
|---|---|
| `DATABASE_URL`, `MIGRATION_DATABASE_URL` | from step 4.2 |
| `PUBLIC_ORIGIN` | `https://abosch.netlify.app` (the address people type) |
| `PROXY_SHARED_SECRET` | 32+ random bytes, e.g. `openssl rand -base64 48`. **Same value in Netlify.** |
| `CSRF_SECRET`, `DATA_ENCRYPTION_KEY`, `FILE_URL_SECRET`, `METRICS_TOKEN` | Run `bash scripts/gen-secrets.sh` to make them. Keep `DATA_ENCRYPTION_KEY` safe forever. |
| `S3_ACCESS_KEY_ID`, `S3_SECRET_ACCESS_KEY` (and `S3_BUCKET=abo-files`) | from Supabase Storage |
| `SMTP_URL`, `MAIL_FROM` | e-mail sending (password reset, verification, fee reminders), e.g. Brevo, Mailgun, Zoho |
| `PLATFORM_PAYSTACK_SECRET_KEY` (optional) | subscription payments; or set it later in the app (stored encrypted) |
| `PAYSTACK_SECRET_KEY` (optional) | school fee payments online |

- The blueprint already sets the fixed values: `NODE_ENV=production`, `SERVE_FRONTEND=false`, `REQUIRE_PROXY_SECRET=true`, `DB_SSL=require`, `STORAGE_DRIVER=s3`, `SCHOOL_APPROVAL=manual`.
- Database migrations run **automatically before every deploy** (`preDeployCommand: node server/src/db/migrate.js` in `render.supabase.yaml`, using `MIGRATION_DATABASE_URL`).
- After deploy, check `https://<render-app>.onrender.com/health/ready`.

### 4.4 Netlify (abosch.netlify.app)
1. Open the existing site **abosch**, then **Site configuration › Build & deploy › Link repository**, and choose the GitHub repo.
2. `netlify.toml` sets the build: `npm run build:web`, publish `dist/web`, edge functions in `netlify/edge-functions`.
3. Environment variables (scope **Functions**):
   - `API_ORIGIN` = `https://<render-app>.onrender.com`
   - `PROXY_SHARED_SECRET` = the same value as in Render
4. Deploy, then open https://abosch.netlify.app. It shows the sign-in page, with no public demo button.
5. Optional check from a computer: `node scripts/verify-deployment.js` (see `docs/NETLIFY_DEPLOYMENT.md`).

### 4.5 First platform owner account
Run once with Render's `MIGRATION_DATABASE_URL` / `DATABASE_URL`, for example from the Render shell:
```
PLATFORM_ADMIN_LOGIN=abo.owner PLATFORM_ADMIN_EMAIL=you@example.com node scripts/create-platform-admin.js
```
- A strong password is printed **once**. Two-step sign-in is set up at first sign-in.
- **Platform console:** approve schools, Payments & Plans (Paystack, plans, demo timer, bank details) and **Demo Links**.

## 5. What the app already does (all tested locally)

- **Every feature of the old offline edition, online.** Old debts, petty cash, questions from teachers, reminders and the print centre are among them. See `abo-erp/docs/FEATURE_MAP.md`.
- **Security:**
  - email + password login, password reset, email verification;
  - two-step sign-in for owners and bursars, passkeys / fingerprint;
  - 30+ roles with server-checked permissions;
  - Row Level Security on every table (91 school tables, isolation check 12/12);
  - hash-chained audit log, encrypted secrets.
- **Results:** CA/exam scores with four-eyes approval, broadsheets, cumulative results, report cards, CBT with server marking.
- **Money:** fees and invoices (Paystack verified on the server), cashbook, school store.
- **Demos:** two DEMO schools, 5 minutes, wiped afterwards.
  - They open **only from a demo link** made by the platform owner.
  - You make links from the **Give a demo** panel on the platform home page, or from **Demo Links** in the menu.
  - The public sign-in page has no demo button.
- **Menu:** the three-line button shows or hides the whole menu, and repeated entries are merged into tabs. See `abo-erp/docs/MENU.md`.
- **Text size:** all text is about 12% larger (base 15.5px). Printed report cards and broadsheets keep their sizes.
- **Rating:** **82/100**, with the limitations listed in `reports/ABO_APP_RATING.md`.
- **Last test results:**

| Test | Result |
|---|---|
| Server tests | **191/191** |
| Browser suites (17, each on a fresh database, e.g. menu 309, phone taps 1029, master 27) | **all pass, 0 server errors** |

  Details: `reports/ABO_ONLINE_INTEGRATION_REPORT.md`.

## 6. Moving schools from the old offline edition

After the online app is live on abosch.netlify.app (the same web address as the old offline site):
1. On each device that held a school, open the site and sign in as that school's owner.
2. Go to **Backup & Data › From the Old App**. The page finds the old data on that device.
3. Press **Preview**, then **Commit migration**.

The old app's "Full backup" file also works.

## 7. Open items / honest limits

- **Not tested live yet:** Netlify, Render and Supabase deployment, real e-mail sending, real Paystack payments, real phones. Everything was tested locally with the same code, headers and database rules.
- **Costs:**
  - Render free instances sleep, so use a paid instance for schools.
  - Supabase Point-in-Time Recovery is a paid feature; the app's Backup & Data download works on any plan.
- **Old offline owner code:** it was once visible on the old site. It no longer matters once the offline edition is retired.
- **Before going live, run the safety check:** `npm run preflight` with the production settings.

## 8. Useful commands (inside `abo-erp/`, Node 20)

```
npm ci                      # install
npm run build:web           # build the web app into dist/web
npm test                    # server tests (needs PostgreSQL; see docs/TEST_REPORT.md)
node scripts/verify-isolation.js   # school data isolation check (needs DATABASE_URL + MIGRATION_DATABASE_URL)
node scripts/preflight.js   # production readiness check
```

**Never paste into chats or GitHub:**
- database passwords;
- `DATA_ENCRYPTION_KEY`, `CSRF_SECRET`, `PROXY_SHARED_SECRET`;
- Supabase `sb_secret_…` / `service_role` keys;
- Paystack `sk_live_…`.
