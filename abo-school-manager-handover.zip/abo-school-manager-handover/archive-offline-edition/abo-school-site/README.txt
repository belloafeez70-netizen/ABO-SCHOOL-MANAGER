A.B.O. School Manager — offline edition as a website (version e85bf047c872)

Publish / update https://abosch.netlify.app (about 2 minutes):
  1. Go to https://app.netlify.com → your site (abosch) → Deploys.
  2. Drag THIS FOLDER onto the "Drag and drop your site output folder here" box. Same address, no settings to change.
  3. Phones that already installed the app see "A new version of the app is ready — Update now".

What is inside: index.html (the app), vendor/ (PDF/picture/Word export libraries — loaded only when you export),
icons/, manifest.webmanifest + sw.js (install as an app, opens offline), offline.html, 404.html, robots.txt,
_headers (security headers: CSP, HSTS, noindex, fingerprint/GPS permissions).

Keep ONE address: fingerprints are tied to the website address.
Data on a device stays on that device; use Cloud Sync (Supabase) so all devices share the school.
