/* A.B.O. offline edition — website copy service worker (version e85bf047c872).
   • The app (index.html) is network-first, so a new release arrives as soon as the phone is online; the saved copy opens it offline.
   • Export libraries (vendor/) and icons are cache-first (they never change for a given version).
   • School data is NOT cached here — it lives in the browser storage of the app itself.
   • A new version waits until the page says "Update now" (message 'skip-waiting'), then old caches are deleted.
   Cache update procedure: publish the new site; phones get the "A new version of the app is ready" bar; tap Update now. */
const VERSION = 'abo-site-e85bf047c872';
const SCOPE = new URL(self.registration ? self.registration.scope : './', self.location.href).pathname;
const CORE = ['./', 'index.html', 'offline.html', 'manifest.webmanifest', 'icons/icon-192.png', 'icons/icon-512.png'];
self.addEventListener('install', (e) => { e.waitUntil(caches.open(VERSION).then((c) => c.addAll(CORE)).catch(() => {})); });
self.addEventListener('message', (e) => { if (e.data && e.data.type === 'skip-waiting') self.skipWaiting(); });
self.addEventListener('activate', (e) => { e.waitUntil(caches.keys().then((k) => Promise.all(k.filter((x) => x.startsWith('abo-site') && x !== VERSION).map((x) => caches.delete(x)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', (e) => {
  const r = e.request; const u = new URL(r.url);
  if (r.method !== 'GET' || u.origin !== self.location.origin) return;
  if (r.mode === 'navigate') {
    // the app's own address: the folder this worker lives in ("/" on abosch today, "/offline/" in the combined site)
    const isApp = u.pathname === SCOPE || u.pathname === SCOPE + 'index.html';
    e.respondWith(fetch(r).then((res) => { if (res.ok && isApp) { const cp = res.clone(); caches.open(VERSION).then((c) => c.put('index.html', cp)); } return res; })
      .catch(() => caches.match(isApp ? 'index.html' : 'offline.html').then((x) => x || caches.match('index.html')).then((x) => x || caches.match('offline.html'))));
    return;
  }
  if (/\/(vendor|icons)\//.test(u.pathname) || u.pathname.endsWith('manifest.webmanifest')) {
    e.respondWith(caches.match(r).then((hit) => hit || fetch(r).then((res) => { if (res.ok) { const cp = res.clone(); caches.open(VERSION).then((c) => c.put(r, cp)); } return res; })));
  }
});
