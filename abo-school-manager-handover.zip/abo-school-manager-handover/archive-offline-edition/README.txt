Old offline edition — RETIRED on 12 Oct 2026.
Kept only for reference and so schools can move old data into the online app (Backup & Data > From the Old App).
Do NOT publish it and do NOT put it in GitHub.
